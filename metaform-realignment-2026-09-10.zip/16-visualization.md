# Visualization, navigation, and provenance disclosure

## Three views of the same model

The namespace browser answers where a Type lives and what can be targeted. The canvas answers how the selected region's actuals meet through OP joins. The inspector answers what a selected record means and why its knowledge applies. None is a substitute for the other two.

Do not make the entire graph the default visual representation of project understanding. Begin with the coarse artifact account and progressively reveal meaningful regions. Keep all data addressable through the shared read model even when it is not rendered as a card.

## Namespace view

Display direct narrowing children, their Function/Encounter relationship to the parent, and actual membership counts. The breadcrumb is the canonical semantic ancestry, not the user's click history. Back is separate. A Type with several relevant graph connections retains one canonical namespace address; additional relationships are inspected as graph relationships.

Selecting a Type shows its universal EF and known receiver-purpose clauses. The member list distinguishes exact bindings from bindings beneath its narrower branch. Selecting an actual from that list opens its local graph while leaving the namespace row visible. The actual can have several Type breadcrumbs; show the currently selected binding and make the others available rather than inventing one permanent primary Type.

## Local actual view

For an actual focus, show only incident OP joins and their participants, plus the necessary join records for multi-participant or join-to-join relationships. A neighboring actual's other ordinary neighbors do not automatically appear. Clicking that actual replaces the view with its own incident neighborhood; Back restores the previous scene.

Provider-to-receiver arrows remain the convention. On a hard-dependency join, the arrow therefore runs from the required provider toward the receiver that needs it. Labels state the receiver's purpose. A supportive or property meeting is distinguishable by text and line style, not merely color.

The focal actual has a stronger outline, not a larger paragraph. A neighbor outside the current viewport has an offscreen indication and a corresponding list row. The graph shows returned/total relation counts when paged or filtered. A filtered scene never claims to be the full local neighborhood.

## Join view

A simple binary OP join is inspected through its edge. A join with additional participants or a join participating in another relation is shown as a reified join node when needed to avoid a false binary picture. Inspecting it exposes all participant roles, the receiver-purpose-provider-Type conjunction, and the relationship-specific logic.

Group identical historical source renderings only as a visual comparison convenience, with explicit source count and expandable source-specific fields. Do not rewrite stored joins or collapse different purposes into one edge. In the normal single-foundation view, the old Native/Latent duplicate edge problem should largely disappear because the data projection has been corrected.

## Transitivity disclosure

Knowledge rows initially show a short statement, origin label, and applicability-path label. Examples are “Direct property,” “Type expectation · via code.cpp,” “Join implication · receiver purpose …,” and “Layer: porting practices · via Type binding.” A backward-visible property reads “Visible here from installer; applies to installer branch,” not “Inherited by all code.”

An Explain action opens a drawer containing the origin record, source/generation, applicable scope, and ordered path. Highlight only that chosen path on the canvas. A Type path can be shown in the namespace panel; an actual refinement or OP path can be shown in the canvas. Do not draw every possible transitive path at once.

The path includes actual relation IDs and direction. The user can inspect each step. Alternative paths are listed as additional explanations, not exhaustively rendered. Conflicting applicable items remain separately visible with their different scopes/sources. A layer recommendation is not visually promoted to a native structural property.

## Information allocation

| Surface | Default content | Deferred content |
| --- | --- | --- |
| Namespace browser | Name, address, direct children, narrowing kind, membership counts | Full Type prose, aliases/history, applicability proofs |
| Canvas | Focused actuals/Types, short labels, direct joins and direction | Full descriptions, source assessments, generated recommendations |
| Actual inspector | Functional account, Type bindings, relevant boundary | Implementation evidence, full JSON, long run history |
| Join inspector | Receiver, purpose, provider, provider Type EF, role | Additional logic and provenance details |
| Type inspector | Universal EF/description, placement, members, known clauses | Complete attached layer payloads and historical definitions |
| Layer inspector | Request, target scope, schema, generation, coverage/freshness | Full rendered prompt and all raw outputs |
| Explanation drawer | One origin and its applicability path | Alternative paths and complete derivation history |

## Navigation state transitions

`Open model` resolves a revision and opens its Defining Element plus coarse account. `Browse namespace` changes the semantic region but not the model. `Open actual` changes graph focus and selection. `Inspect Type` can replace only the inspector selection; `Browse Type` changes region explicitly. `Inspect join` changes selection without changing the actual focus. `Explain knowledge` adds a temporary explanation overlay. `Close explanation` restores the unchanged scene. `Back` restores the prior region/selection/filter/viewport state. `Change revision` resolves the same target through retained identity or reports its removal/relocation.

Search results are addresses, not a separate ontology. A result can be opened through the same resolver used by all other navigation. Copy target produces the exact owner-qualified semantic reference accepted by CLI and MCP.

## Large-model behavior

Index namespace children, Type members, and incident participants on the server. Virtualize long member and relationship lists; retain accessible row context. Fetch only the selected details and bounded neighborhood. Cache against model/revision and query parameters. Separate comparison and expensive derived analyses from ordinary graph reads.

Do not convert every internal operation into a graph animation. Batch Cytoscape updates and preserve positions when topology is unchanged. Use compact cards and a readable starting scale; an explicit overview fit is a user choice. Measure actual interactions with the real sample and a synthetic high-degree fixture before choosing more complex layout technology. [R06](20-research-and-decisions.md#r06)

## Accessible equivalents

Every canvas record must be reachable through the namespace/member/relationship lists. Keyboard users can select a target, open its joins, inspect a Type, follow an explanation, and return without pointer-only gestures. Preserve current keyboard zoom/Back and reduced-motion support. Focus and selection remain separately visible, and opening/closing drawers restores focus to the originating control.

This visualization is successful when a user can explain the selected Element and one of its joins, then trace a property's origin without consulting raw schema JSON. A graph that merely contains all the records is not sufficient.
