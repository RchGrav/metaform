# Review basis, evidence, and limits

## Reviewed state

This package diagnoses `RchGrav/metaform` at `ba6421e232532e4a52565c53320f61af2b4df0f9`, the remote `main` read for this review. The latest substantive implementation is `8c2f4a3ae6f8d858a14939f11a85450d9d5f3157`, compared with its parent `c115a6cea8ad01d7aa76a2d13bed25b83a2d2651`. The two subsequent commits concern handoff documentation, not another intake or GUI implementation. References in this archive are pinned to the reviewed state rather than whatever `main` becomes later. [S01](evidence/source-index.md#s01)

Rich clarified during this review that the handoff he meant was in his local origin and had not been pushed. That local document was not accessible here. Remote handoff material was read as evidence of the published baseline, not as a substitute for his unpublished instructions. This archive is self-contained and does not require that local handoff to select the implementation work.

The user's current realignment request is the intended-model authority for this package. Repository code establishes what exists. Maintained semantic documents establish important mechanisms to preserve, but their older requirements for two complete Native/Latent graphs are explicitly superseded by the current request for one collected shape plus additional knowledge. These are different sources of authority, not competing guesses about the same implementation.

## Investigation performed

The sample README was read before interpreting `native.json` or `latent.json`. The full current repository and the pre-implementation snapshot were obtained through a temporary, isolated GitHub Actions review branch. Intake, prompt preparation, rule sources, schemas, graph stores, owner-qualified assembly, service integration, CLI, MCP, workflow instructions, browser models/rendering, styles, templates, tests, prior reviews, semantic documents, feature briefs, and recent changes were inspected. No application repair is included in this delivery. [S02](evidence/source-index.md#s02), [S03](evidence/source-index.md#s03), [S04](evidence/source-index.md#s04)

The sample was measured by parsing its original JSON, not by counting rendered nodes. The manifest's graph hashes were verified. Comparisons distinguish record identity, content changes, join identity, and participant/role/purpose changes. The sample is preserved as evidence, not silently corrected into a reference answer. See [sample analysis](04-sample-intake.md) and [measured evidence](evidence/measurements.json).

The current wheel was built and installed into an isolated Python 3.13 environment with the repository's locked dependencies. Fresh verification produced **546 passing Python tests** and **22 passing JavaScript model/renderer tests**. The installed-distribution smoke check separately reproduced `KeyError: 'id'` in `tools/check_distribution.py:76`. That check still expects a removed per-Type assignment input. Passing source tests and a successful wheel build therefore do not establish a passing installed smoke check. [S05](evidence/source-index.md#s05), [verification](evidence/verification.md)

## Direct interface examination

The packaged GUI scripts and styles were executed in headless Chromium at 1600×1000 and 390×844. Responses came from the unmodified Flask application through its in-process test client, populated with the archived Native and Latent graphs in an isolated fixture. The normal browser navigation to localhost was blocked by the browser environment. The review consequently used in-process request transport rather than claiming a successful live browser HTTP session. The canvas renderer, application JavaScript, layouts, DOM, and Flask response construction were actually exercised. [S06](evidence/source-index.md#s06)

The examination covered initial Defining Element focus, the Types control, selected `mgm:dnsresponders`, the inspector, source separation, and resizing to a narrow viewport. It also inspected existing browser tests and ran the JavaScript model/renderer suite. The existing two browser suites were not independently rerun in their original Node/Playwright harness. The archive distinguishes these facts instead of carrying forward every historical handoff claim as fresh verification.

## What this evidence does not establish

There is no matched, fresh, exhaustive MGM intake run from both sides of the implementation commit. The before/after assessment is a source-and-contract comparison supported by the new sample; it is not a controlled quality or inference-cost experiment. Native-versus-Latent differences within the sample are not before-versus-after-commit differences.

The MGM source itself was not independently re-audited at its recorded source revision. Its sample README expressly says Native reused an earlier inspection map and did not perform an exhaustive fresh source audit or runtime validation. Statements about MGM below are statements about the recorded account unless explicitly described otherwise.

Inference amortization is the architectural objective. This review establishes where reusable Type context and selective access are supported or obstructed; it does not claim a measured token, latency, hallucination, or task-success improvement. The implementation plan includes localized comparisons that can measure those outcomes without making a performance claim a prerequisite to useful work.

## Reading evidence

`evidence/source-index.md` maps source IDs to pinned files and relevant symbols. JSON-pointer-like references name exact sample records. `evidence/measurements.json` records quantitative observations and probes. `evidence/verification.md` records commands, results, and execution scope. Proposed records and workflows under `examples/` are design examples, not a rewritten MGM intake or claims that its proposed contracts already exist.
