# Core model and target architecture

## One foundation, multiple uses

A Metaform is an artifact-shaped semantic foundation. It records the artifact's meaningful Elements, reusable Types, their narrowing typology, classifications, and receiver-owned OP joins. Additional knowledge refers to that foundation; it does not redefine the foundation merely by being generated.

The same foundation supports orientation, metaprompting, selective expansion, blind-spot analysis, planning, refactoring, porting, and human exploration. These are uses of one collected shape, not reasons to build competing intake graphs. The initial shape is coarse by purpose. It remains precise about identities and relationships even when it does not enumerate implementation details.

This design preserves the repository's actual/Type separation, reified relations, namespace naming, and owner-qualified storage. It replaces the mandatory second shape and supplies missing layer, explanation, and transformation semantics. [S07](evidence/source-index.md#s07), [S08](evidence/source-index.md#s08), [S13](evidence/source-index.md#s13)

## The tripartite relationship

Preserve the foundation's expression:

```text
C(T) = { (r_i AND p_i AND e) }
```

For Type `T`, each receiver `r_i` is bound to its own operative purpose `p_i` and the Type's single Encounter Function `e`. The conjunction is the meaning. Independent arrays of receivers and purposes would permit false combinations; a bag of capability keywords would lose the relationship entirely.

An OP join is a first-class record of a meeting: **this receiver receives this provider's Type EF for this purpose**. It has an identity, role, participants, provenance, and, when useful, a signal and join logic. `purpose` states the receiver's why. `signal` describes how that purpose is satisfied in the meeting; it is not automatically an acceptance test, authorization condition, or success gate.

`hard dependency`, `property`, and `supportive` describe the OP join's role for its receiver. They are not permanent classes of Elements. The same provider can be required by one receiver and supportive to another. A Defining Element is the artifact's representative composite at the selected resolution, not necessarily a program entry point. A model's reference to that Element is not a replacement for its upstream receiver-purpose joins.

### Type EF versus implementation function

A source method, procedure, callback, class, document section, or image region can provide evidence. The Type captures the functional meaning through which the artifact is understood. A connectivity evaluator may be implemented by several functions; a single function may support several artifact capabilities. Neither direction authorizes a one-to-one source-symbol ontology.

A Type has one EF at the represented resolution. An actual can participate in several Types while remaining one Element. Therefore an actual OP join identifies **which provider Type** supplies the EF used in that relationship. The actual's Type binding can carry a contextual realization of that EF without replacing the universal Type definition. Different facets are not collapsed into a concatenated EF string.

For example, an actual module can be both a connectivity evaluator and an interface adapter. A receiver wanting path viability receives the evaluator EF; a receiver wanting translation between interfaces receives the adapter EF. Both joins can name the same actual provider but must retain their different Type facets and purposes.

### Stored contracts and known witnesses

Type-level OP joins can express reusable receiver-Type/purpose/EF clauses. Actual OP joins express their artifact-specific realizations. The Type inspector returns these separately. It can show a known contract clause and the actual joins supporting or instantiating it.

The mathematical relationship describes Type meaning. A finite intake does not claim to enumerate every possible receiver of every Type in existence. Store the known clauses and actual witnesses with their scope. Do not turn `C(T)` into a content hash, Cartesian product, admission score, or demand for an exhaustive global receiver census. Reuse established Type understanding and add a newly needed clause when the artifact meaning warrants it.

## Distinct concepts

| Concept | Identity and responsibility | Must not be confused with |
| --- | --- | --- |
| Namespace address | Stable semantic name for a Type in a particular revision, with aliases for meaning-preserving moves | A source path or arbitrary graph edge |
| Type | Reusable universal description and one EF, situated through narrowing relationships | A project-specific instance or source-code class |
| Actual Element | A particular thing within or relevant to the artifact, with its own identity and description | Its Type definition |
| Type binding | An actual's classification under a Type, including contextual realization when useful | An OP join invented to say “is a” |
| Narrowing relationship | Explains how one Type is more specific than another through Function or Encounter | A folder grouping or universal property transmission |
| OP join | Receiver + purpose + provider's Type EF, with a receiver-relative role | An unlabelled dependency arrow |
| Refinement relationship | Identifies a more detailed account of an existing actual region | A renamed parent or a new competing whole Metaform |
| Knowledge layer | A named, separately versioned collection of attached knowledge with a generation request and schema | The structural foundation or the old `layer: elements` storage bucket |
| Provenance | Evidence and generation lineage, including the basis of applicability | A trust score or a Native/Latent scope label alone |
| Variant | A derived foundation revision expressing a destination shape | A claim that implementation files have already been ported |

Everything remains representable as an Element in Metaform's broad sense. Separate record schemas and relation kinds do not impose an ontology in which a join or a workflow can never itself be examined as an Element. They prevent connected concepts from being flattened into one ambiguous object.

## Boundaries and resolution

Preserve the current five namespace bases: `code`, `document`, `media`, `data`, and `exterior`; retain `ext` as an alias where currently supported. Exterior means outside the project. External-to-the-functionality but still inside the repository is a different boundary, not a new root. Environment, person, group, system, and framework remain useful exterior examples rather than a closed inventory. [S13](evidence/source-index.md#s13)

A repository is a source location, not necessarily one artifact. A folder can contain one artifact, several projects, supporting assets, or reference material. The model identifies its artifact and Defining Element explicitly. Several models may belong to one registered project without changing the existing project owner's identity.

Resolution is an attribute of an account or analysis, not a new Type category. Initial intake follows the Defining Element's receiver purposes and its meaningful requirements/properties. It stops elaborating when the represented capability and its role are clear enough for orientation. A named expansion opportunity preserves where deeper work can occur without speculatively creating all of that work.

## Target component architecture

```text
Artifact evidence + reusable Type registry
                 |
           coarse intake
                 |
          Foundation revision
           /       |        \
 semantic reads  expansion  variant/transform
      |             |           |
 GUI / CLI / MCP  local patch   changed foundation
      |                         |
 task grounding          dependency impact
      |                         |
 authored prompts <---- layer reinference
      |
 layers / blind-spot reports / task-specific knowledge
```

The knowledge service remains the owner-aware storage and transaction boundary. Existing workflow/continuation machinery remains the execution mechanism. Add small modules for namespace resolution, common semantic reads, applicability explanations, layer recipes, and transformations. They share records and references rather than introducing another storage engine or job scheduler.

`read_model.py` resolves a model/revision and returns semantic projections. `namespace.py` handles names, aliases, direct children, and direct/descendant members. `properties.py` computes applicability and explanation paths. `layers.py` owns definitions, recipes, attachment generations, and reinference requests. `transform.py` applies structural patches and produces impact reports. Existing `intake.py` orchestrates coarse intake and delegates optional outside analysis into a layer job.

## Semantic versus structural validation

JSON Schema expresses the shape of records. Reference checks identify missing or ambiguous links. Semantic review asks whether the Type, purpose, EF, role, boundary, and resolution actually mean what they should. These checks are complementary.

Preserve the existing annotation-oriented validation approach. An incomplete draft remains inspectable; a diagnostic must not be “fixed” by inventing a receiver or purpose. Transaction conflicts must identify the records they concern rather than silently overwriting them. Do not require a universal rubric score, approval cycle, or full latent pass before a useful foundation can exist.

## Amortization in concrete terms

Prepare reusable Type descriptions, bound purposes, selected relation context, and applicable knowledge before the task prompt is specialized. Reuse that prepared context at its recorded revision. A task asks for a semantic region and its relevant connections, not the entire database. Expansion occurs where the task benefits from it. Layer generation reuses Type-level material before authoring actual-specific differences.

This is not “infer once forever.” Changed Type meaning, actual relationships, or task-relevant context can require new inference. The architecture makes those dependencies explicit so the system can reuse what still applies and re-infer what changed, instead of forcing every agent to reconstruct orientation from source files.
