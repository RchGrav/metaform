# Illustrative implementation fixtures

These examples are proposed v2 contracts and semantic witnesses, not generated MGM output or claims that the target architecture is implemented.

`foundation.json` represents a small illustrative connectivity coordinator with one actual engine, an installer and a receiver. The engine realizes a functional Type and a language Type. Its joins retain the provider Type facet. Local language properties are placed on their actual receiving regions, not on the common code trunk.

`non-code-foundation.json` uses the same model for a maintenance guide. It demonstrates that the intake contract does not require software-specific categories or a repository-shaped ontology.

`layer.json` shows an illustrative outside-review layer, exact request, prompt/component/schema snapshots, a generation and an attachment with record and selector dependencies. The output is explicitly marked illustrative; it was not produced by a live model. The payload schema is separate from the generic layer engine.

`transformation.json` changes the example engine's language binding and property meeting in a destination variant. It does not rename the global C++ Type to JavaScript or claim that source files have already been ported. `impact.json` explains the affected and unaffected knowledge regions. `read-envelope.json` illustrates a canonical inspection result and its coverage.

`gui-wireframe.html` is a static implementation reference for desktop regions, semantic labels, information hierarchy and responsive drawers. It is deliberately labelled as a target layout, not as the current application or a working implementation. Current GUI evidence is under `../evidence/browser-reproduction/` and the unchanged source sample is under `../evidence/original-sample/`.

The instance builder is included as `../verification/build_examples.py`, and `../verification/validate_package.py` checks the generated examples against the registered schemas. The behavioral cases in the main archive specify the stronger application/semantic verification needed during implementation.
