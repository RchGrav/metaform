#!/usr/bin/env python3
"""Build illustrative schema instances; these are not live-model outputs."""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=pathlib.Path)
    root = parser.parse_args().package.resolve()
    out = root / 'examples'
    out.mkdir(parents=True, exist_ok=True)
    owner = 'project:illustrative'
    model = {'project': 'illustrative', 'model': 'coordinator', 'revision': 'example-source-1'}

    def ref(kind: str, identity: str) -> dict:
        return {'owner': owner, 'kind': kind, 'id': identity}

    def save(name: str, value: object) -> None:
        (out / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

    def fingerprint(value: object) -> str:
        return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

    def type_record(identity: str, description: str, ef: str, length: int = 1) -> dict:
        return {'id': identity, 'owner': owner, 'description': description, 'ef': ef, 'length': length, 'aliases': [], 'parametric_elements': []}

    definitions = [
        ('code', 'Code directs a computer to perform operations.', 'Directs execution to produce a result.', 1),
        ('code.coordinator', 'Coordinator code brings participating operations into a coherent result.', 'Coordinates participating operations to provide their combined result.', 1),
        ('code.evaluator', 'Evaluator code interprets evidence to determine a result.', 'Evaluates supplied evidence to determine a result.', 1),
        ('code.evaluator.connectivity', 'Connectivity evaluator code interprets evidence about usable connectivity.', 'Determines usable connectivity from supplied observations.', 2),
        ('code.installer', 'Installer code provisions an artifact for use.', 'Provisions the artifact in its intended environment.', 1),
        ('code.cpp', 'C++ code expresses executable behavior using C++.', 'Expresses executable behavior through C++ constructs.', 1),
        ('code.javascript', 'JavaScript code expresses executable behavior using JavaScript.', 'Expresses executable behavior through JavaScript constructs.', 1),
        ('code.shell', 'Shell code expresses command-driven operations.', 'Expresses operations through a command shell.', 1),
        ('exterior', 'An exterior entity lies outside the artifact being examined.', 'Participates from outside the artifact boundary.', 1),
        ('exterior.person', 'An exterior person participates from outside the artifact.', 'Acts as a person in an interaction with the artifact.', 1),
    ]
    types = {identity: type_record(identity, description, ef, length) for identity, description, ef, length in definitions}
    artifact = ref('element', 'demo:project')
    elements = {}
    for identity, name, description, boundary in [
        ('demo:project', 'Connectivity coordinator', 'Coordinates connectivity evaluation into a usable result for its user.', 'artifact'),
        ('demo:engine', 'Connectivity engine', 'Interprets observations to determine connectivity usable by the coordinator.', 'internal'),
        ('demo:installer', 'Installer', 'Provisions the coordinator for use.', 'internal'),
        ('demo:user', 'User', 'Uses the coordinator to obtain a useful connectivity result.', 'exterior'),
    ]:
        elements[identity] = {'id': identity, 'owner': owner, 'name': name, 'description': description, 'summary': description, 'artifact': artifact, 'boundary': boundary}
    bindings = []
    for identity, slot, type_id, realization in [
        ('demo:project', 'function', 'code.coordinator', 'Coordinates the supplied connectivity functions.'),
        ('demo:engine', 'function', 'code.evaluator.connectivity', 'Evaluates connectivity evidence for the coordinator.'),
        ('demo:engine', 'medium', 'code.cpp', 'The example source engine is implemented in C++.'),
        ('demo:installer', 'function', 'code.installer', 'Provisions this coordinator.'),
        ('demo:installer', 'medium', 'code.shell', 'The example installer uses shell commands.'),
        ('demo:user', 'encounter', 'exterior.person', 'Receives the coordinator result as its user.'),
    ]:
        bindings.append({'id': 'binding:' + identity + ':' + slot, 'owner': owner, 'element': ref('element', identity), 'type': ref('type', type_id), 'realization': realization})
    narrowings = []
    for identity in types:
        if '.' in identity:
            parent = identity.rpartition('.')[0]
            category = 'encounter' if identity in ('code.cpp', 'code.javascript', 'code.shell', 'exterior.person') else 'function'
            narrowings.append({'id': 'narrowing:' + identity, 'owner': owner, 'parent': ref('type', parent), 'child': ref('type', identity), 'category': category,
                              'reason': 'This position narrows its parent by the meaning stated in the child Type.'})
    joins = []
    for identity, receiver, provider, kind, provider_type, purpose, role in [
        ('join:user-result', 'demo:user', 'demo:project', 'element', 'code.coordinator', 'Obtain a coordinated connectivity result.', 'hard dependency'),
        ('join:project-evaluation', 'demo:project', 'demo:engine', 'element', 'code.evaluator.connectivity', 'Determine usable connectivity for the coordinated result.', 'hard dependency'),
        ('join:project-installation', 'demo:project', 'demo:installer', 'element', 'code.installer', 'Make the coordinator available in the deployment environment.', 'supportive'),
        ('join:engine-medium', 'demo:engine', 'code.cpp', 'type', 'code.cpp', 'Realize the engine operations in the source implementation medium.', 'property'),
        ('join:installer-medium', 'demo:installer', 'code.shell', 'type', 'code.shell', 'Realize provisioning through shell operations.', 'property'),
    ]:
        joins.append({'id': identity, 'owner': owner, 'receiver': ref('element', receiver), 'provider': ref(kind, provider), 'provider_type': ref('type', provider_type), 'purpose': purpose, 'role': role})
    foundation = {'schema_version': '2', 'model': model, 'artifact': artifact,
                  'understanding': 'Illustrative fixture, not a source-audited project. The user receives a coordinated result; the engine evaluates connectivity and the installer provisions use.',
                  'types': types, 'elements': elements, 'bindings': bindings, 'narrowings': narrowings, 'refinements': [], 'joins': joins}
    save('foundation.json', foundation)

    guide_artifact = ref('element', 'guide:project')
    guide_types = {'document': type_record('document', 'A document communicates recorded information.', 'Communicates recorded information to its reader.'),
                   'document.guide': type_record('document.guide', 'A guide document supports a reader in performing an activity.', 'Guides the reader through the activity it addresses.'),
                   'exterior': types['exterior'], 'exterior.person': types['exterior.person']}
    guide = {'schema_version': '2', 'model': {'project': 'illustrative', 'model': 'maintenance-guide', 'revision': 'example-guide-1'},
             'artifact': guide_artifact, 'understanding': 'A maintenance guide gives a reader actionable understanding of a maintenance activity. Encoding is not its defining function.',
             'types': guide_types, 'elements': {}, 'bindings': [], 'narrowings': [], 'refinements': [], 'joins': []}
    for identity, name, desc, type_id in [('guide:project', 'Maintenance guide', 'Guides its reader through maintenance.', 'document.guide'), ('guide:reader', 'Reader', 'Uses the guide to perform maintenance.', 'exterior.person')]:
        guide['elements'][identity] = {'id': identity, 'owner': owner, 'name': name, 'description': desc, 'artifact': guide_artifact}
        guide['bindings'].append({'id': 'binding:' + identity, 'owner': owner, 'element': ref('element', identity), 'type': ref('type', type_id)})
    for child, parent in [('document.guide', 'document'), ('exterior.person', 'exterior')]:
        guide['narrowings'].append({'id': 'narrowing:' + child, 'owner': owner, 'parent': ref('type', parent), 'child': ref('type', child), 'category': 'function' if parent == 'document' else 'encounter', 'reason': 'A meaningful narrower Type for this account.'})
    guide['joins'].append({'id': 'join:reader-guidance', 'owner': owner, 'receiver': ref('element', 'guide:reader'), 'provider': guide_artifact, 'provider_type': ref('type', 'document.guide'), 'purpose': 'Understand how to perform the maintenance activity.', 'role': 'supportive'})
    save('non-code-foundation.json', guide)

    layer_id, recipe_id, generation_id = 'layer:connectivity-blindspots', 'recipe:connectivity-blindspots', 'generation:illustrative-1'
    selector = {'kind': 'neighbors', 'target': ref('element', 'demo:engine'), 'depth': 1, 'description': 'Engine incident OP joins, their participants and the Type context needed to interpret them.'}
    engine_joins = [j for j in joins if j['provider']['id'] == 'demo:engine' or j['receiver']['id'] == 'demo:engine']
    engine_bindings = [b for b in bindings if b['element']['id'] in ('demo:engine', 'demo:project')]
    context_records = [{'ref': ref('element', identity), 'value': elements[identity]} for identity in ('demo:engine', 'demo:project')]
    context_records += [{'ref': ref('binding', b['id']), 'value': b} for b in engine_bindings]
    context_records += [{'ref': ref('join', j['id']), 'value': j} for j in engine_joins]
    context_records += [{'ref': ref('type', identity), 'value': types[identity]} for identity in sorted({b['type']['id'] for b in engine_bindings} | {j['provider_type']['id'] for j in engine_joins})]
    dependencies = [{'kind': 'record', 'target': item['ref'], 'fields': ['*'], 'fingerprint': fingerprint(item['value']), 'reason': 'This complete illustrative record is supplied in the prepared context.'} for item in context_records]
    dependencies.append({'kind': 'selector', 'selector': selector, 'fingerprint': fingerprint(sorted([item['ref'] for item in context_records], key=lambda r: (r['owner'], r['kind'], r['id']))), 'reason': 'Selection membership, including newly added or removed incident context.'})
    request = 'Examine the connectivity engine for overlooked implications and questions worth investigating.'
    prompt_text = (root / 'prompts/runtime/blindspots.md').read_text()
    component_text = (root / 'prompts/components/attachment-semantics.md').read_text()
    schema = json.loads((root / 'schemas/blindspot-report.schema.json').read_text())
    payload = {'summary': 'Illustrative outside-in finding; not produced by a live model.', 'findings': [{'id': 'finding:stale-evidence', 'target': ref('element', 'demo:engine'),
               'account': 'The supplied coarse account does not describe how observation freshness affects a connectivity result.',
               'basis': 'The engine description, its Type meaning and its direct evaluation-purpose join are the supplied context.',
               'question': 'How does the implementation distinguish current observations from stale evidence?',
               'suggested_work': 'Inspect that boundary in a targeted expansion; absence from this coarse account does not prove missing implementation.'}]}
    assignment_inputs = {'request': request, 'model': model, 'subject': ref('element', 'demo:engine'), 'context_records': context_records}
    layer = {'layer': {'id': layer_id, 'owner': owner, 'name': 'Connectivity engine blind spots', 'description': 'Questions derived from the supplied connectivity account.', 'schema_ref': schema['$id'], 'recipe_ref': ref('recipe', recipe_id), 'selector': selector},
             'recipe': {'id': recipe_id, 'owner': owner, 'request': request, 'source_prompt': {'id': 'prompt:blindspots', 'revision': '2', 'text': prompt_text},
                        'components': [{'id': 'component:attachment-semantics', 'revision': '2', 'text': component_text}], 'schema_snapshots': {schema['$id']: schema},
                        'selector': selector, 'source_model': model, 'dependencies': dependencies,
                        'rendered_assignments': [{'id': 'assignment:illustrative-1', 'revision': '1', 'text': prompt_text + '\n\n' + component_text + '\n\n' + json.dumps(assignment_inputs, ensure_ascii=False)}],
                        'execution': {'mode': 'illustrative fixture', 'live_model_executed': False}},
             'generation': {'id': generation_id, 'owner': owner, 'layer': ref('layer', layer_id), 'recipe': ref('recipe', recipe_id), 'model': model, 'state': 'illustrative'},
             'attachments': [{'id': 'knowledge:engine-blindspots', 'owner': owner, 'layer': ref('layer', layer_id), 'subject': ref('element', 'demo:engine'), 'schema_ref': schema['$id'],
                              'payload': payload, 'generation': ref('generation', generation_id), 'applicability': {'scope': selector, 'reason': 'The finding concerns this engine and its direct receiving-purpose context.'}, 'dependencies': dependencies}]}
    save('layer.json', layer)
    old_binding = next(b for b in bindings if b['id'] == 'binding:demo:engine:medium')
    new_binding = {**old_binding, 'type': ref('type', 'code.javascript'), 'realization': 'The destination design realizes the engine in JavaScript; implementation work is not yet performed.'}
    old_join = next(j for j in joins if j['id'] == 'join:engine-medium')
    new_join = {**old_join, 'provider': ref('type', 'code.javascript'), 'provider_type': ref('type', 'code.javascript'), 'purpose': 'Realize the engine operations in the destination implementation medium.'}
    transformation = {'id': 'transform:engine-medium', 'source': model, 'destination_model': 'coordinator-javascript', 'purpose': 'Represent a destination engine realization while preserving the functional roles and the shell installer.',
                      'operations': [{'op': 'update', 'target': ref('binding', old_binding['id']), 'record': new_binding, 'reason': 'Change the destination actual realization, not the universal source Type.'},
                                     {'op': 'update', 'target': ref('join', old_join['id']), 'record': new_join, 'reason': 'Realign the receiver-specific medium meeting.'}],
                      'mapping': [{'from': ref('type', 'code.cpp'), 'to': ref('type', 'code.javascript'), 'meaning_preserved': False, 'scope': {'kind': 'target', 'target': ref('element', 'demo:engine')}, 'reason': 'Replacement in the engine region of this variant, not a global alias or an equivalence claim.'}]}
    save('transformation.json', transformation)
    save('impact.json', {'illustrative': True, 'source': model, 'destination_model': 'coordinator-javascript', 'decisions': [
        {'target': 'demo:installer', 'action': 'preserve', 'reason': 'Its scope and shell realization are unchanged.'},
        {'target': 'demo:engine', 'action': 'preserve', 'reason': 'Actual identity and intended evaluator function remain; its language facet changes.'},
        {'target': 'join:engine-medium', 'action': 'regenerate', 'reason': 'Knowledge depending on this meeting is generated again using destination context; the structural join itself is updated by the patch.'},
        {'target': 'knowledge:engine-blindspots', 'action': 'regenerate', 'reason': 'A supplied context record changed. Reapply the same question to the destination; the new analysis can retain its conclusion if still appropriate.'}]})
    inspect_records = [item for item in context_records if item['ref']['kind'] == 'type' and item['ref']['id'] in ('code.cpp', 'code.evaluator.connectivity') or item['ref']['kind'] == 'binding' and item['value']['element']['id'] == 'demo:engine' or item['ref'] == ref('element', 'demo:engine')]
    selected_refs = {(item['ref']['kind'], item['ref']['id']) for item in inspect_records}
    inspect_dependencies = [d for d in dependencies if d['kind'] == 'selector' or (d['target']['kind'], d['target']['id']) in selected_refs]
    save('read-envelope.json', {'model': model, 'query': {'operation': 'element.inspect', 'target': 'demo:engine'}, 'resolved_target': ref('element', 'demo:engine'),
         'records': inspect_records, 'coverage': {'returned': len(inspect_records), 'available': len(inspect_records), 'complete': True, 'next_cursor': None},
         'dependencies': inspect_dependencies, 'diagnostics': [], 'related_operations': [{'operation': 'graph.neighbors', 'target': ref('element', 'demo:engine')}]})
    print('Built five schema-bound illustrative instances plus an impact example.')


if __name__ == '__main__':
    main()
