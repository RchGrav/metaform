# Reproduction and archive checks

`reproduce_evidence.py` repeats the saved-sample counts/hashes, actual-seeded prompt composition and two localized graph probes against the reviewed package. `render_current_gui.py` renders the current application with an isolated sample fixture and in-process Flask transport. Neither applies the proposed architecture or mutates the original sample.

`build_examples.py` constructs illustrative target-schema fixtures. These are authored examples, not live-model output. `validate_package.py` validates the archive's schema registry, examples, references, prompt composition, local links and file hashes.

Use the pinned repository and its dependencies for current-state probes. The example builder needs only Python's standard library. Package validation needs `jsonschema` and `referencing`. Browser reproduction needs Playwright and Chromium. Commands and original execution scope are in [the verification record](../evidence/verification.md).

The implementation's meaningful verification is specified in [22-verification-cases.md](../22-verification-cases.md). A passing archive validator is not a claim that a new runtime, prompt or GUI has been implemented.
