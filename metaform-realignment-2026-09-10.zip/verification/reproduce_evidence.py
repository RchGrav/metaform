#!/usr/bin/env python3
"""Reproduce localized review measurements without changing the source repository."""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import pathlib
import tempfile


def save(path: pathlib.Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--out', type=pathlib.Path, required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    sample = repo / 'examples/intake/mgm-main'
    native = json.loads((sample / 'native.json').read_text())
    latent = json.loads((sample / 'latent.json').read_text())
    manifest = json.loads((sample / 'manifest.json').read_text())

    def metrics(graph: dict, path: pathlib.Path) -> dict:
        actuals = {k: v for k, v in graph['elements'].items() if v['entity_schema'] == 'metaform:actual-element'}
        types = {k: v for k, v in graph['elements'].items() if v['entity_schema'] == 'metaform:element'}
        refs = {t for value in actuals.values() for t in value['entity_json_obj'].get('type_ids', [])}
        return {
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'file_bytes': path.stat().st_size,
            'elements': len(graph['elements']), 'actual_elements': len(actuals), 'types': len(types),
            'joins': len(graph['joins']), 'roles': dict(collections.Counter(j.get('type') for j in graph['joins'])),
            'distinct_type_svgs': len({v['entity_json_obj'].get('svg') for v in types.values()}),
            'actuals_with_latent_provenance': [k for k, v in actuals.items() if any(isinstance(p, dict) and p.get('perspective') == 'latent' for p in v['entity_json_obj'].get('provenance', []))],
            'missing_type_refs': sorted(refs - types.keys()),
            'missing_type_parents': sorted({k.rpartition('.')[0] for k in types if '.' in k} - types.keys()),
            'missing_join_endpoints': sorted({j.get(f) for j in graph['joins'] for f in ('object_id', 'element_id')} - graph['elements'].keys()),
            'type_parametrics': {k: v['entity_json_obj']['parametric_elements'] for k, v in types.items() if v['entity_json_obj'].get('parametric_elements')},
        }

    def join_key(join: dict) -> tuple:
        return (join.get('object_id'), join.get('element_id'), join.get('type'), json.dumps(join.get('purpose'), sort_keys=True, ensure_ascii=False))

    common = set(native['elements']) & set(latent['elements'])
    nk, lk = {join_key(j) for j in native['joins']}, {join_key(j) for j in latent['joins']}
    counts = {'native': metrics(native, sample / 'native.json'), 'latent': metrics(latent, sample / 'latent.json'), 'comparison': {
        'retained_ids': len(common), 'identical_records': sum(native['elements'][k] == latent['elements'][k] for k in common),
        'changed_ids': [k for k in sorted(common) if native['elements'][k] != latent['elements'][k]],
        'new_ids': sorted(set(latent['elements']) - set(native['elements'])),
        'removed_ids': sorted(set(native['elements']) - set(latent['elements'])),
        'same_receiver_provider_role_purpose': len(nk & lk), 'native_only_receiver_provider_role_purpose': len(nk - lk),
        'latent_only_receiver_provider_role_purpose': len(lk - nk),
        'identical_join_ids': len({j['id'] for j in native['joins']} & {j['id'] for j in latent['joins']}),
    }}
    # The saved manifest contains the source hashes; verify the exact values occur in it.
    manifest_text = json.dumps(manifest)
    counts['manifest_hashes_match'] = all(counts[name]['sha256'] in manifest_text for name in ('native', 'latent'))
    if not counts['manifest_hashes_match']:
        raise RuntimeError('Sample bytes do not match the archived manifest hashes')
    save(out / 'sample-metrics.json', counts)
    lines = ['# Original sample record index', '', 'Generated from the saved Native file. These are recorded descriptions, not newly verified MGM implementation claims.', '']
    for key, record in native['elements'].items():
        if record['entity_schema'] == 'metaform:actual-element':
            value = record['entity_json_obj']
            lines.extend(['## ' + key, '', 'Types: ' + ', '.join(value.get('type_ids', [])), '', str(value.get('ef', '')), '', '```json', json.dumps(value.get('description'), indent=2, ensure_ascii=False), '```', ''])
    (out / 'sample-record-index.md').write_text('\n'.join(lines), encoding='utf-8')

    from metaform.app import App
    from metaform.graph import Graph, renamed_elements
    from metaform.prompts import snapshot
    from metaform.util import write_json

    def rec(name: str, actual: bool = False, types: list | None = None) -> dict:
        return {'entity_schema': 'metaform:actual-element' if actual else 'metaform:element', 'entity_desc': name,
                'entity_json_obj': {'en': name, 'ef': name, **({'type_ids': types or []} if actual else {})}, 'layer': 'elements'}

    graph = {'elements': {'code.engine': rec('Engine'), 'demo:engine': rec('Main engine', True, ['code.engine'])}, 'joins': [], 'observations': []}
    renamed, changed = renamed_elements(graph, {'code.engine': 'code.coordinator'})
    probes = {'rename': {'requested_mapping': {'code.engine': 'code.coordinator'}, 'returned_counts': changed,
                        'actual_type_ids_after': renamed['elements']['demo:engine']['entity_json_obj']['type_ids'],
                        'available_ids': sorted(renamed['elements']),
                        'dangling_type_refs': [t for t in renamed['elements']['demo:engine']['entity_json_obj']['type_ids'] if t not in renamed['elements']]}}
    with tempfile.TemporaryDirectory(prefix='metaform-review-probe-') as temp:
        db = Graph(pathlib.Path(temp) / 'graph.sqlite3')
        records = {'code': rec('Code'), 'code.engine': rec('Engine'), 'code.engine.game': rec('Game engine'),
                   'demo:engine': rec('Engine instance', True, ['code.engine']), 'demo:game': rec('Game instance', True, ['code.engine.game'])}
        db.put({'elements': records, 'joins': []}, 'native')
        probes['type_depth_zero'] = {'requested': 'code.engine', 'returned_ids': sorted(db.assemble('code.engine', depth=0)['elements'])}
    save(out / 'semantic-probes.json', probes)

    semantics = repo / 'src/metaform/data/semantics'
    names = ('native.md', 'archaeology.md', 'proof.md', 'glossary.md', 'aliases.md', 'latent-role.md')
    inventory = {'units': 'characters, not model tokens', 'source_chars': {name: len((semantics / name).read_text()) for name in names}, 'seeded_roles': {}}
    glossary = (semantics / 'glossary.md').read_text()
    with tempfile.TemporaryDirectory(prefix='metaform-review-prompts-') as temp:
        p = pathlib.Path(temp)
        write_json(p / 'home/config.json', {'knowledge_mode': 'legacy'})
        app = App(p / 'project', p / 'home')
        for role in ('native', 'archaeology', 'proof'):
            prepared = snapshot(app, 'prompt:metaform.intake.' + role)
            inventory['seeded_roles'][role] = {'source_prompt_chars': len(prepared['source_prompt']),
                'contains_full_glossary': glossary in prepared['source_prompt'],
                'rule_payload_chars': len(json.dumps(prepared['rules'], ensure_ascii=False))}
        for role in ('workflow.convert', 'workflow.lexicalize', 'workflow.specialize', 'continuity'):
            prepared = snapshot(app, 'prompt:metaform.' + role)
            inventory['seeded_roles'][role] = {'source_prompt_chars': len(prepared['source_prompt']), 'contains_full_glossary': glossary in prepared['source_prompt']}
    save(out / 'prompt-inventory.json', inventory)
    save(out / 'measurements.json', {
        'baseline': 'ba6421e232532e4a52565c53320f61af2b4df0f9', 'sample': counts, 'semantic_probes': probes, 'prompt_inventory': inventory,
        'original_local_browser_observations': {
            'method': 'Original scripts/styles and Flask test-client responses in headless Chromium; localhost page navigation was blocked.',
            'desktop': {'width': 1600, 'height': 1000, 'actual_nodes': 17, 'joins': 28, 'fit': '36%'},
            'types': {'visible_records': 36, 'fit': '12%'},
            'dns_selected': {'actual_nodes': 3, 'joins': 3, 'fit': '87%'},
            'mobile': {'width': 390, 'height': 844, 'scroll_height': 4052},
            'initial_network_response_bytes': 1073063, 'page_errors': [],
            'selection_method': 'Types control click; DNS actual navigation controller and inspector; resize of selected scene.',
        },
    })
    print(json.dumps({'hashes_match': counts['manifest_hashes_match'], 'native_actuals': counts['native']['actual_elements'],
                      'latent_actuals': counts['latent']['actual_elements'], 'rename_dangling_refs': probes['rename']['dangling_type_refs']}, indent=2))


if __name__ == '__main__':
    main()
