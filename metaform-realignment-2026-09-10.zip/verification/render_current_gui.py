#!/usr/bin/env python3
"""Render the original GUI via in-process Flask transport in an isolated fixture."""
from __future__ import annotations
import argparse
import json
import pathlib
import re
import shutil
import tempfile
import time
from playwright.sync_api import sync_playwright
from metaform.app import App
from metaform.util import write_json
from metaform.viewer import create_app


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--out', type=pathlib.Path, required=True)
    parser.add_argument('--chromium', help='Optional Chromium executable; otherwise use PATH or Playwright Chromium')
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    sample = args.repo.resolve() / 'examples/intake/mgm-main'
    with tempfile.TemporaryDirectory(prefix='metaform-browser-review-') as temp:
        root = pathlib.Path(temp)
        write_json(root / 'home/config.json', {'knowledge_mode': 'legacy'})
        app = App(root / 'MGM archived sample', root / 'home')
        native = json.loads((sample / 'native.json').read_text())
        latent = json.loads((sample / 'latent.json').read_text())
        app.graph.put(native, 'native')
        app.graph.put(latent, 'archaeology')
        app.graph.merge_perspectives()
        app.set('native_context', {k: v for k, v in native.items() if k not in ('elements', 'joins')})
        client = create_app(app).test_client()
        html = client.get('/').get_data(as_text=True)
        html = re.sub(r'<script src="([^"]+)"></script>', lambda match: '<script>' + client.get(match[1]).get_data(as_text=True).replace('</script', '<\\/script') + '</script>', html)
        html = html.replace('<link rel="stylesheet" href="/static/workbench.css">', '<style>' + client.get('/static/workbench.css').get_data(as_text=True) + '</style>')
        html = html.replace('<head>', '<head><script>window.fetch=async(url,options={})=>{const r=await window.hostFetch(String(url),options);return {ok:r.status<400,status:r.status,statusText:String(r.status),json:async()=>r.data,text:async()=>JSON.stringify(r.data)}};</script>')
        requests = []

        def host_fetch(url: str, options: dict) -> dict:
            started = time.monotonic()
            response = client.open(url, method=options.get('method', 'GET'), data=options.get('body'), headers=options.get('headers', {}))
            requests.append({'url': url, 'method': options.get('method', 'GET'), 'status': response.status_code,
                             'bytes': len(response.data), 'ms': round((time.monotonic() - started) * 1000, 2)})
            return {'status': response.status_code, 'data': response.get_json()}

        with sync_playwright() as playwright:
            executable = args.chromium or shutil.which('chromium') or shutil.which('chromium-browser')
            browser = playwright.chromium.launch(**({'executable_path': executable} if executable else {}), headless=True, args=['--no-sandbox'])
            page = browser.new_page(viewport={'width': 1600, 'height': 1000}, device_scale_factor=1)
            page.expose_function('hostFetch', host_fetch)
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.set_content(html, wait_until='load')
            page.wait_for_function("typeof structure !== 'undefined' && structure.scene && structure.scene.nodes.length > 0")
            page.wait_for_timeout(800)

            def record(name: str) -> None:
                page.screenshot(path=str(out / (name + '.png')), full_page=True)
                state = page.evaluate("""() => ({title:document.title,bodyText:document.body.innerText,viewport:{width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,scrollHeight:document.documentElement.scrollHeight},scene:{focus:structure.focus,nodes:structure.scene.nodes.map(n=>n.id),edges:structure.scene.edges.length},zoom:document.getElementById('zoom-level').textContent})""")
                state['page_errors'] = list(errors)
                (out / (name + '.json')).write_text(json.dumps(state, indent=2, ensure_ascii=False) + '\n')

            record('initial')
            page.locator('#graph-types').click()
            page.wait_for_timeout(700)
            record('types')
            page.evaluate("async()=>{await structure.navigate('mgm:dnsresponders');await inspect(structure.scene.nodes.find(n=>n.id==='mgm:dnsresponders'));}")
            page.wait_for_timeout(800)
            record('selected')
            page.set_viewport_size({'width': 390, 'height': 844})
            page.wait_for_timeout(700)
            record('mobile')
            (out / 'requests.json').write_text(json.dumps({'method': 'Archive-assembly reproduction: original GUI and Flask test-client responses via in-process transport.',
                'browser_version': browser.version, 'requests': requests, 'page_errors': errors}, indent=2) + '\n')
            browser.close()
            if errors:
                raise RuntimeError('Page errors occurred; see requests.json')
    print('Rendered initial, Types, selected DNS and mobile scenes with no page-script errors.')


if __name__ == '__main__':
    main()
