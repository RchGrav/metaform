#!/usr/bin/env python3
"""Validate archive schemas, illustrative instances, references, links and integrity."""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import re
import sys
from urllib.parse import unquote, urlsplit
from jsonschema import Draft202012Validator
from referencing import Registry, Resource


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=pathlib.Path)
    args = parser.parse_args()
    root = args.package.resolve()
    errors: list[str] = []
    schemas = {}
    for path in sorted((root / 'schemas').glob('*.json')):
        try:
            schema = json.loads(path.read_text())
            Draft202012Validator.check_schema(schema)
            schemas[schema['$id']] = schema
        except Exception as exc:
            errors.append(f'{path.relative_to(root)}: {exc}')
    registry = Registry().with_resources((identity, Resource.from_contents(schema)) for identity, schema in schemas.items())

    def validate(name: str, identity: str) -> dict:
        path = root / 'examples' / name
        try:
            value = json.loads(path.read_text())
            for error in Draft202012Validator(schemas[identity], registry=registry).iter_errors(value):
                errors.append(f'examples/{name} {list(error.absolute_path)}: {error.message}')
            return value
        except Exception as exc:
            errors.append(f'examples/{name}: {exc}')
            return {}

    foundation = validate('foundation.json', 'urn:metaform:schema:foundation:2')
    guide = validate('non-code-foundation.json', 'urn:metaform:schema:foundation:2')
    layer = validate('layer.json', 'urn:metaform:schema:layer:2')
    transform = validate('transformation.json', 'urn:metaform:schema:transformation:2')
    validate('read-envelope.json', 'urn:metaform:schema:read-envelope:2')

    def key(ref: dict) -> tuple:
        return ref.get('owner'), ref.get('kind'), ref.get('id')

    def check_foundation(value: dict, label: str) -> set:
        records = set()
        for collection, kind in [('types', 'type'), ('elements', 'element')]:
            for map_id, record in value.get(collection, {}).items():
                if record.get('id') != map_id:
                    errors.append(f'{label}: map key differs from record ID: {map_id}')
                records.add((record.get('owner'), kind, record.get('id')))
        for collection, kind in [('bindings', 'binding'), ('narrowings', 'narrowing'), ('refinements', 'refinement'), ('joins', 'join')]:
            for record in value.get(collection, []):
                item = (record.get('owner'), kind, record.get('id'))
                if item in records:
                    errors.append(f'{label}: duplicate identity {item}')
                records.add(item)

        def exists(ref: dict, context: str) -> None:
            if key(ref) not in records:
                errors.append(f'{label}: unresolved {context}: {ref}')

        exists(value.get('artifact', {}), 'artifact')
        pairs = set()
        for binding in value.get('bindings', []):
            exists(binding['element'], 'binding actual')
            exists(binding['type'], 'binding Type')
            pairs.add((key(binding['element']), key(binding['type'])))
        for narrowing in value.get('narrowings', []):
            exists(narrowing['parent'], 'narrowing parent')
            exists(narrowing['child'], 'narrowing child')
            if narrowing['child']['id'].rpartition('.')[0] != narrowing['parent']['id']:
                errors.append(f'{label}: illustrative canonical narrowing disagrees with its address: {narrowing["id"]}')
        for refinement in value.get('refinements', []):
            exists(refinement['parent'], 'refinement parent')
            exists(refinement['child'], 'refinement child')
        for join in value.get('joins', []):
            for field in ('receiver', 'provider', 'provider_type'):
                exists(join[field], f'{join["id"]}.{field}')
            if join['provider']['kind'] == 'element' and (key(join['provider']), key(join['provider_type'])) not in pairs:
                errors.append(f'{label}: OP provider lacks the declared Type facet: {join["id"]}')
            if join['provider']['kind'] == 'type' and key(join['provider']) != key(join['provider_type']):
                errors.append(f'{label}: Type provider differs from its EF Type: {join["id"]}')
            for participant in join.get('participants', []):
                exists(participant['ref'], 'join participant')
        return records

    records = check_foundation(foundation, 'foundation')
    check_foundation(guide, 'non-code foundation')
    for attachment in layer.get('attachments', []):
        if key(attachment['subject']) not in records:
            errors.append('Layer example has an unresolved foundation subject')
        for error in Draft202012Validator(schemas[attachment['schema_ref']], registry=registry).iter_errors(attachment['payload']):
            errors.append(f'layer payload: {error.message}')
    for operation in transform.get('operations', []):
        if operation['op'] != 'add' and key(operation['target']) not in records:
            errors.append(f'Transformation target unresolved: {operation["target"]}')

    composition = json.loads((root / 'prompts/composition.json').read_text())
    for role, spec in composition['roles'].items():
        for relative in [spec['prompt'], *spec['components']]:
            if not (root / 'prompts' / relative).is_file():
                errors.append(f'{role}: missing prompt component {relative}')
        try:
            registry.resolver().lookup(spec['output_schema'])
        except Exception as exc:
            errors.append(f'{role}: output schema cannot resolve: {exc}')
    foundation_marker = 'This MetaformFoundation defines the minimum core of expertise'
    for path in (root / 'prompts/runtime').glob('*.md'):
        if foundation_marker in path.read_text():
            errors.append(f'Complete platform foundation leaked into {path.relative_to(root)}')
    expert = (root / 'prompts/platform/platform-expert.md').read_text()
    if expert.count(foundation_marker) != 1:
        errors.append('Platform expert prompt does not contain one preserved foundation block')

    checked_links = 0
    for path in root.rglob('*.md'):
        text = path.read_text(encoding='utf-8')
        text = re.sub(r'```[\s\S]*?```', '', text)
        for match in re.finditer(r'!?\[[^\]]*\]\(([^)]+)\)', text):
            target = match[1].split(' "', 1)[0].strip('<>')
            parsed = urlsplit(target)
            if parsed.scheme or target.startswith('//'):
                if 'github.com/RchGrav/metaform/blob/' in target:
                    revision = target.split('/blob/', 1)[1].split('/', 1)[0]
                    if re.fullmatch('[0-9a-f]+', revision) and len(revision) != 40:
                        errors.append(f'{path.relative_to(root)}: malformed pinned revision in {target}')
                continue
            local = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
            if not local.exists():
                errors.append(f'{path.relative_to(root)}: missing linked file {target}')
            checked_links += 1
    required = ['README.md', '00-review-clarifications.md', '23-implementation-plan.md', '24-requirement-map.md', 'evidence/measurements.json', 'evidence/verification.md', 'evidence/source-index.md', 'examples/gui-wireframe.html']
    for name in required:
        if not (root / name).is_file():
            errors.append(f'Missing required package artifact: {name}')
    manifest_path = root / 'MANIFEST.json'
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text())
        expected_paths = set(manifest['files'])
        actual_paths = {str(p.relative_to(root)).replace('\\', '/') for p in root.rglob('*') if p.is_file() and p != manifest_path}
        if actual_paths != expected_paths:
            errors.append(f'Manifest file set differs: missing={sorted(expected_paths-actual_paths)}, extra={sorted(actual_paths-expected_paths)}')
        for relative, expected in manifest['files'].items():
            path = root / relative
            if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() != expected['sha256']:
                errors.append(f'Manifest hash mismatch: {relative}')
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f'Validated {len(schemas)} registered schemas, five schema-bound examples, layer payload, cross-record references, {len(composition["roles"])} prompt compositions and {checked_links} local Markdown links.')
    print('Manifest integrity checked.' if manifest_path.exists() else 'Pre-manifest content check complete.')
    print('This verifies archive integrity/contracts, not implemented platform behavior or generated semantic truth.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
