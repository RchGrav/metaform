# Research used and architectural decisions

Research was used to strengthen specific mechanisms, not to replace Metaform with an existing framework. Sources below were consulted on 2026-09-10. The conclusions labelled “Decision” are this review's design choices; cited external work does not independently prove Metaform's intended semantics or its performance.

## R01

**MCP tools, 2026-07-28 specification.** [Official source](https://modelcontextprotocol.io/specification/2026-07-28/server/tools).

The specification describes structured tool results/output schemas, a newer input-required interaction, deterministic tool discovery, and explicit handles rather than implicit connection state. Decision: retain Metaform's version-aware router and answer-loop machinery, add explicit model/revision references, and put shared semantic results behind that existing surface. Do not apply the older direct-tool-list pattern indiscriminately to the newer protocol.

## R02

**MCP resources, 2026-07-28 specification.** [Official source](https://modelcontextprotocol.io/specification/2026-07-28/server/resources).

Resources provide URI-addressable context. Decision: expose selected, revision-addressed Element/Type/join/layer resources and schema resources through the same read model. Whole-store dumps remain explicit exports, not an agent's default orientation payload.

## R03

**W3C PROV-DM.** [Recommendation](https://www.w3.org/TR/prov-dm/), especially derivation, generation, usage and revision.

The distinction between an entity, its generating activity, and the inputs it used provides a useful provenance pattern. Decision: store source evidence, recipes, rendered assignments, input dependencies, outputs and revision lineage separately. A transport label such as Native is not sufficient provenance. Adopt this pattern without requiring an RDF/PROV implementation or importing a new ontology into runtime intake.

## R04

**JSON Schema Draft 2020-12.** [Official specification index](https://json-schema.org/draft/2020-12).

Versioned identifiers and referenced schema definitions support a modular contract. Decision: use the existing registry with versioned `$id` values and registered `$ref` resolution. Separate structural, layer, transformation and runtime-contribution schemas. Schema conformance remains distinct from semantic correctness; extensible knowledge payloads do not become a fixed catalogue of layer types.

## R05

**WAI-ARIA Tree View Pattern.** [Official pattern](https://www.w3.org/WAI/ARIA/apg/patterns/treeview/).

The pattern distinguishes focus from selection and specifies keyboard expansion/navigation and metadata for partially rendered trees. Decision: use a persistent namespace browser with those interactions, keeping semantic selection and canvas focus separate. A relationship list provides access to canvas records without requiring pointer interaction.

## R06

**Cytoscape.js documentation.** [Official documentation](https://js.cytoscape.org/), especially performance, labels, events and layouts.

The existing library supports the required local scenes and interaction hooks. Its performance guidance makes label/edge rendering and batched updates relevant engineering concerns. Decision: retain the renderer, reduce default card/label density, fetch local scenes server-side, and measure the existing sample before introducing a new layout engine. A DOM explanation overlay is this review's proposed collision repair, not a claimed library feature that automatically solves overlap.

## R07

**W3C SKOS Reference, semantic relations.** [Recommendation](https://www.w3.org/TR/skos-reference/#semantic-relations).

SKOS distinguishes direct broader/narrower links from transitive closure. Decision: preserve direct canonical narrowing records separately from derived ancestor/descendant results. This is a useful implementation distinction, not an instruction to turn Metaform into SKOS, a domain/class taxonomy, or an RDF dataset. Metaform's Function/Encounter and OP semantics remain its own.

## R08

**Anthropic, Effective context engineering for AI agents.** [Primary engineering article](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents), 2025-09-29.

The article discusses curated task-relevant context and just-in-time retrieval. Decision: replace blanket full-glossary injection with role-specific semantic components and bounded addressable context. This supports a testable design hypothesis; it does not establish that any shorter prompt is better or that the proposed Metaform prompts have already improved task success.

## R09

**Liu et al., Lost in the Middle: How Language Models Use Long Contexts.** [Primary paper record](https://aclanthology.org/2024.tacl-1.9/), TACL 2024, DOI 10.1162/tacl_a_00638.

The study reports sensitivity to relevant-information position in the models/tasks it evaluated. Decision: test the actual target harness with representative artifact tasks rather than equating context-window capacity with useful orientation. Do not extrapolate the paper's numerical results to current models or claim it proves Metaform's amortization benefit.

## Decisions consolidated

Keep one artifact-shaped foundation; preserve actual/Type separation and receiver-owned OP conjunctions; represent Function/Encounter on narrowing relationships; distinguish canonical namespace identity from graph connectivity; track origin and scope during transitivity; put generated knowledge in separately versioned layers with reproducible semantic requests; use explicit transformation mappings and dependency impact; share one semantic read contract across GUI/CLI/MCP; and refine the existing GUI rather than replacing its successful direction.

Keep SQLite/service ownership, portable JSON, the current workflow runner, editable prompt records, Flask, and Cytoscape. A new database, vector index, frontend framework, distributed scheduler, or external ontology is not required by the present evidence.

## Material unknowns, not competing architectures

Some imported OP joins may not identify which provider Type facet they receive; targeted semantic work must resolve those specific joins. Historical sample provenance cannot reconstruct every prior inference input. The optimal prompt/component size and context-page defaults need actual task measurements. These are localized evidence/implementation questions, not reasons to leave the core architecture undecided.
