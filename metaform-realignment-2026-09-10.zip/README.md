# Metaform realignment — implementation kickoff

**Keep the improved, coarser artifact structure and the useful GUI direction. Make them the foundation of one coherent Metaform, with focused runtime prompts, separately attached knowledge, explainable properties, and a shared GUI/CLI/MCP model.**

This archive is the architectural, semantic, prompting, interface and implementation package for `RchGrav/metaform`. It diagnoses the published implementation at `ba6421e232532e4a52565c53320f61af2b4df0f9`, assesses the substantive changes in `8c2f4a3ae6f8d858a14939f11a85450d9d5f3157`, and specifies the next implementation work. It contains **specifications and evidence, not an already-applied application rewrite**.

Rich's clarifications are in [00-review-clarifications.md](00-review-clarifications.md). In particular, the newer structure looks more organized and meaningfully coarser; latent analysis remains unresolved; some graph text is covered; and prompt quality and demonstrable usefulness remain essential. The local handoff Rich referred to was not accessible to this review. This README is a self-contained starting point for the agent pulling the archive.

## The model to preserve

The Metaform is the collected structural and typological shape of the artifact. Its initial resolution is coarse enough to orient an unfamiliar agent, but its identities and relationships are precise enough to target and expand. Reusable Type understanding prepares the expertise through which subsequent work is performed.

Preserve `C(T) = { (r_i AND p_i AND e) }`: each Receiving Entity is bound to its own Operative Purpose and the Type's single Encounter Function. An OP join expresses that meeting, not an unlabelled dependency and not independent lists whose entries can be cross-paired. An actual can realize several Types without losing its own identity; the join identifies the provider Type facet whose EF it receives.

Keep namespace identity, Type definition, actual Element, Type binding, narrowing relationship, OP join and attached knowledge distinct. Function and Encounter describe meaningful narrowing relationships; they are not two new namespace roots or permanent mutually exclusive labels on all nodes. Backward visibility of a property at a trunk retains its origin and does not create inheritance into unrelated siblings.

The complete supplied Foundation is preserved in [the platform-expert prompt](prompts/platform/platform-expert.md). It belongs in platform-development expertise, not in ordinary runtime intake or analysis prompts.

## What is already useful

The latest implementation separates actual artifact records from universal Type records, uses Type references without invented membership OP joins, allows a freeform whole-artifact account, and removes the former normal proof/per-Type Latent recursion. These are important improvements to preserve.

The GUI's directed Cytoscape view, authored Type artwork, local-neighborhood replacement, DE return control, Back navigation and source-separated inspection are also useful. Keep the current visual language and renderer. The plan refines their density, information hierarchy and semantic data projection rather than replacing them for novelty.

[03-recent-commit-assessment.md](03-recent-commit-assessment.md) explicitly separates preservation, refinement, supersession and unresolved alignment. The newer organization/coarseness is not negated by remaining defects.

## Main problems to repair

The outside pass still returns a complete second structural graph and publishes proposed contracts as actual Elements. It receives a better context now, but that does not implement the requested outside-in blind-spot layer. Initial intake should complete with one foundation; requested outside analysis attaches distinct knowledge.

The current prompt seeding automatically includes the full glossary in Native, archaeology and the still-seeded proof prompt. That glossary contains superseded two-shape instructions. Focused role instructions should supply the needed semantics and context without losing the conjunction, naming mechanisms or necessary evidence. The measurement is about those intake seeds, not a claim that every workflow prompt has the same dump.

The sample's Native actual records already contain latent-assessment provenance. That is observed contamination in the saved account, not proof of a hidden instruction or a particular current mutation bug. Keep raw evidence and capture source/reuse/generation lineage. Several descriptions also need localized resolution refinement; do not discard the improved whole shape.

The schema/read surfaces do not yet make provider Type facets, property applicability, layer recipes and transformation dependencies explicit. A Type rename probe leaves `type_ids` dangling. Generic adjacency is not an explanation of inheritance, and loading a whole graph before drawing a small neighborhood is not bounded grounding.

The GUI exposes the right ingredients but hides them behind tiny auto-fit scenes, covered relation text, long flattened descriptions, duplicate detail regions, ambiguous source/layer terminology and weak narrow-screen behavior. Fix the concrete text obstruction immediately while the shared semantic model is built.

## Target architecture

```text
Artifact evidence + reusable Type knowledge
                   |
            focused coarse intake
                   |
          one foundation revision
            /       |        \
     semantic reads |    variant / structural patch
       /    |    \  |              |
     GUI   CLI  MCP local expansion  dependency impact
       \    |    /                  |
       task grounding       layer reinference
                   \          /
                    task work

Requested knowledge and blind-spot reports attach as named layers.
Their prompts, schemas, inputs, applicability and provenance remain recoverable.
```

Keep the existing service ownership, SQLite authority, portable JSON, optional Ladybug analysis copies, workflow/continuation engine, editable prompts, CLI/MCP registry, Flask and Cytoscape. Add focused semantic modules over these foundations. The evidence does not require a new database, frontend framework or orchestration platform.

Layers retain their original semantic requests, payload schemas, source/rendered prompts, selected components, context dependencies and target selectors. A changed foundation can preserve unaffected knowledge and reinfer affected knowledge against destination Types and joins. Porting is an explicit structural transformation followed by realigned knowledge and task work, not a global language-name substitution.

## Target human experience

Open a model and understand its defining result. Browse a persistent meaningful namespace. Select an actual and see only its direct joins, with a readable functional account and Type bindings in one inspector. Inspect a join as receiver + purpose + provider Type EF. See which knowledge is native, which arrived through a Type or join, and which comes from an added layer. Reveal one explanation path at a time. Go deeper, switch revision or return without losing context.

The same selected target and explanation should resolve through CLI and MCP. A human learning the GUI should recognize the semantic names used by an agent's prompt.

## Reading order

Begin with [05 — core model](05-core-model.md), [06 — namespace and graph](06-namespace-and-graph.md), and [07 — schemas/storage](07-schema-and-storage.md). Then read [08 — intake](08-intake-pipeline.md), [09 — rubric](09-intake-rubric.md), and [19 — focused prompts and usefulness](19-prompt-quality.md).

[10](10-property-transitivity.md) specifies applicability. [11](11-blindspot-analysis.md), [12](12-layers-and-reinference.md) and [13](13-transformations-and-porting.md) specify outside analysis, layers and transformations. [17](17-common-access-contract.md) defines the shared operations and response model.

For the interface, read the actual review in [14](14-gui-current-review.md), concrete changes in [15](15-gui-implementation-spec.md), immediate text repair in [15a](15a-text-visibility-repair.md), and visualization behavior in [16](16-visualization.md). [The layout wireframe](examples/gui-wireframe.html) illustrates regions and information hierarchy; it is not a screenshot of implemented changes.

[18](18-guidance-audit.md) identifies conflicting guidance. [20](20-research-and-decisions.md) records external techniques and decisions. [21](21-migration.md) specifies compatibility. [22](22-verification-cases.md) supplies meaningful outcomes. **[23 — implementation plan](23-implementation-plan.md)** contains the task sequence, affected files, interfaces and verification witnesses. [24](24-requirement-map.md) maps the original request to the package.

`schemas/` contains versioned target contracts; `prompts/` contains role texts and composition instructions; `examples/` contains illustrative schema instances; `evidence/` contains measurements, source references, original sample material and rendering evidence. `verification/validate_package.py` validates this archive's internal artifacts; it does not certify application behavior or generated semantics.

## Implementation order

Start with T01's installed-smoke-check correction and localized covered-text repair. Establish the v2 record facade and common namespace/read contract in T02–T03. Implement focused one-foundation intake in T04 and generic layers/outside reports in T05. Add property explanations in T06 and move the GUI onto those shared semantics in T07. Implement local expansion, transformations/reinference and grounded specialization in T08–T10. Finish with the end-to-end demonstration and current-documentation migration in T11.

The text repair can proceed independently. Basic namespace/inspection UI can follow the read contract before every layer feature is complete. Do not let parallel client work invent incompatible semantics. Platform subagents receive [the expert prompt](prompts/platform/platform-expert.md) plus the named task contract, not a differently paraphrased foundation.

## Superseded active mechanisms

Replace the mandatory second structural archaeology pass, ordinary merged Native/Latent foundation presentation, current-facing two-complete-graph guidance, unused proof-role seeding and automatic full-glossary concatenation. Preserve historical snapshots and source comparison explicitly. Preserve meaningful recursive purpose discovery; do not restore per-Type completion work under another name.

Do not rewrite unrelated collaboration instructions or user-authored prompts. Managed templates and authored overrides retain their provenance, and issued v1 assignments retain their recorded contracts during migration.

## What is verified, and what is still to demonstrate

The baseline passed 546 Python tests and 22 JavaScript model/renderer tests in the review environment. The installed-wheel smoke check separately reproduced `KeyError: 'id'`. Sample hashes/counts, prompt composition and the dangling-Type rename witness were measured. The actual browser application was rendered and inspected through in-process Flask transport; the original browser suites were not independently rerun in their original harness. [Verification scope](evidence/verification.md)

These facts establish the exercised behavior, not complete semantic correctness. The revised runtime prompts have not been live-model evaluated here. There is no matched pre/post MGM source run proving a numerical coarseness or inference-saving improvement. T11's matched prompt comparison and end-to-end intake → exploration → layer → transformation → reinference → grounded-task demonstration establish the useful outcome the architecture is intended to enable.

**Begin implementation at [23-implementation-plan.md](23-implementation-plan.md), with the core model understood and the recent improvements preserved.**
