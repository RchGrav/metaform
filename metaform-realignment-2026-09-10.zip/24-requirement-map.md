# Requirement coverage and implementation map

| Requested work | Primary documents/artifacts | Execution |
| --- | --- | --- |
| Current intake and recent changes | 01–04, evidence source index/measurements | T01–T04 |
| Sample README and generated-output interpretation | 04, original sample files and manifest | T02, T04, T11 |
| Universal intake rubric | 09, V01–V09/V21–V23 | T04, T11 |
| Tripartite semantic realignment | 05, foundation schema, structural component | T02–T04 |
| Coarse initial shape and distinct records | 05, 07, 08, runtime intake schema/prompt | T02, T04 |
| Namespace versus typological graph | 06, narrowing/binding schemas, namespace component | T02, T03, T07 |
| Property transitivity and explanation | 10, 16, V10–V15 | T06, T07, T09 |
| Progressive/deferred expansion | 08, runtime expand prompt, transformation schema | T08 |
| Streamlined initial intake | 08, 19, role composition | T04 |
| Outside-in latent blind-spot analysis | 11, blindspot prompt/report schema | T05 |
| Extensible layers and reinference provenance | 12, layer schema, layer prompts | T05, T09 |
| Porting and structural transformations | 13, transformation schema/examples | T09, T10 |
| Existing GUI and latest improvement assessment | 03, 14, direct-render evidence | T01, T07 |
| Concrete visual/usability improvements | 15, 15a, 16, GUI wireframe | T01, T07 |
| Namespace browser, actual/Type/join inspection | 15–17, read envelope | T03, T07 |
| Transitivity/provenance visualization | 10, 15, 16 | T06, T07 |
| GUI/CLI/MCP conceptual alignment | 17, read-envelope schema, V16–V17 | T03, T07, T10 |
| Agent-useful MCP and CLI design | 17, target examples | T03, T10 |
| Legacy guidance audit and replacements | 18, platform/runtime prompts, source index | T04, T11 |
| Platform expert versus runtime separation | prompts/platform, prompts/runtime, composition.json | T04, all specialist assignments |
| Focused prompts instead of glossary dumps | 00, 19, role components, prompt inventory | T04, T11 |
| Demonstrable usefulness beyond appearance | 19, 22 V21–V24, 23 | T10, T11 |
| External research and adopted techniques | 20 | Relevant subsystem task |
| Sequencing and migration | 21, 23 | All tasks |
| Kickoff for an agent entering cold | README | Start here |

## Recent changes disposition

Preserve actual identity/Type distinction, membership references rather than OP inventions, whole-artifact understanding, removal of per-Type recursive proof/Latent work, fresh outside context, scoped result ownership, Cytoscape, authored SVG handling, local-neighborhood replacement, and DE/Back controls.

Refine initial description resolution, Type-facet binding, namespace placement metadata, context size, prompt composition, card/edge readability, inspector hierarchy, and bounded retrieval.

Treat individual sample semantic claims, Type selections and provenance-cleanliness as not established merely by the commit. Preserve the user's observation of improved organization/coarseness and the actual measured implementation evidence.

Supersede mandatory second structural archaeology publication, current-facing two-complete-graph guidance, ordinary merged-source GUI semantics, unused proof-role seeding, and blanket full-glossary role concatenation. Historical source comparison remains explicitly available.
