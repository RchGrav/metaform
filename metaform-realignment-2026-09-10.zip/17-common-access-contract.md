# One semantic access contract for GUI, CLI, and MCP

## Architecture

Implement semantic operations once behind the knowledge service and expose them through the existing command registry. GUI handlers, CLI commands, and MCP tools/router calls use the same handlers and response envelopes. They must not each implement their own Type membership, direction conventions, transitivity, or target resolution.

Keep the current manifest-driven chassis, explicit dynamic blacklist, module-owned execution, project ownership, and continuation transport. New read operations are not a reason to replace those mechanisms. The current CLI already derives named flags from manifest schemas; current MCP uses the same registry and supplies a router for the 2026-07-28 protocol path. [S10](evidence/source-index.md#s10)

## Context and targets

Every result contains a resolved `model` object with `project`, `model`, and immutable `revision`. For convenience, requests can use the current project/model and a short target string. A stateless MCP caller or persisted prompt uses the explicit model reference. The resolver returns the canonical owner-qualified target and any alias/relocation path. It never lets a display label silently select a different owner's record.

Canonical input shape:

```json
{
  "model": {"project": "project-id", "model": "model-id", "revision": "revision-id"},
  "target": {"owner": "project:project-id", "kind": "element", "id": "mgm:project"}
}
```

`code.cpp` is a semantic Type address, not a file path. `mgm:project` is an actual identity. A caller can pass either as `target`; a short string resolves through the declared current model and existing project/global convention. Explicit `Ref` input is available when the owner or record kind would be ambiguous. The GUI's Copy target emits that exact reference.

## Read operations

| Command key | Main inputs | Question answered and result |
| --- | --- | --- |
| `model.discover` | Optional model/project context | Available models, current revisions, DE summaries, source coverage and useful entry targets; no full graph dump |
| `namespace.browse` | `model`, optional `target`, `category`, `cursor`, `limit` | Direct meaningful Type children, narrowing category/reason, direct and descendant actual counts |
| `model.search` | `model`, `query`, optional `kind`, `cursor`, `limit` | Grouped Type/actual/join/layer matches with canonical references and context |
| `type.inspect` | `model`, `target` | One universal Type definition, placement, known Type clauses, binding/member counts, applicable knowledge summaries |
| `type.members` | `model`, `target`, `descendants`, `cursor`, `limit` | Actuals bound to that Type or its narrower branch, explicitly distinguishing the two scopes |
| `element.inspect` | `model`, `target` | Actual account, Type bindings/realizations, artifact boundary, direct relationship counts, expansion/layer references |
| `join.inspect` | `model`, `target` | Complete receiver-purpose-provider-Type conjunction, role, signal, participants, logic and sources |
| `graph.neighbors` | `model`, `target`, optional `direction`, `role`, `cursor`, `limit` | Exactly the incident joins and required participants at the requested focal record |
| `graph.traverse` | `model`, `target`, `depth`, optional `direction`, `role`, `limit`, `cursor` | Bounded relationship traversal with paths, complete join semantics and coverage |
| `knowledge.get` | `model`, `target`, optional `layers`, `cursor`, `limit` | Direct and applicable knowledge, with origin, applicability route and freshness separate |
| `knowledge.explain` | `model`, `target`, `knowledge` | Why one property/attachment is relevant here, including exact origin, scope and relation path |
| `layer.list` / `layer.inspect` | `model`, optional layer `target` | Named knowledge collections, schema, recipe, generation and coverage |
| `model.ground` | `model`, optional `target`, `task`, `depth`, `limit`, `max_chars`, `layers` | Compact orientation bundle for the selected region and task, with handles for deeper reads |
| `expansion.list` | `model`, `target` | Existing deeper accounts, evidence handles, pending analyses and recorded expansion opportunities |
| `model.compare` | Source and destination model references, optional target | Structural patch, relation/binding changes, and layer-impact summary; not a confidence verdict |

Operation-specific filters describe the requested read, not a permanent taxonomy or content blacklist. An OP step means crossing one semantic meeting to a participant; physical reification must not double the reported depth. Namespace descent and actual refinement are separate from OP traversal.

## Mutating/inference operations

`model.expand` accepts model, target, and purpose/question and returns the existing workflow-style run/assignment envelope. `analysis.blindspots` creates a report layer from the outside-in prompt. `layer.create` accepts the semantic request and optional target; `layer.regenerate` names an existing layer and destination revision/region; `layer.remove` removes the chosen active layer association. `model.clone`, `model.transform`, and `model.impact` implement variant creation, explicit patches, and dependency impact.

These operations reuse run IDs, request IDs, receipts, idempotent answer submission, source snapshots, and continuation. They do not require a new scheduler or a universal human approval state. Model-level change conflicts are reported with their exact base/current records. A malformed or unfinished generated record stays inspectable with its annotations; semantic repair is not invented by schema normalization.

## Read envelope and bounded context

The shared result includes:

```json
{
  "model": {"project": "project-id", "model": "model-id", "revision": "revision-id"},
  "query": {"operation": "graph.neighbors", "target": "mgm:project", "direction": "both"},
  "resolved_target": {"owner": "project:project-id", "kind": "element", "id": "mgm:project"},
  "records": [],
  "coverage": {"returned": 0, "available": 0, "complete": true, "next_cursor": null},
  "dependencies": [],
  "diagnostics": [],
  "related_operations": []
}
```

`records` carry their semantic kind and typed payload. Return the source Type EF and receiver purpose needed to interpret an included OP join, or an explicit versioned reference when the caller requested references only. Do not return a dangling edge as though it were a complete explanation.

Use a default page size of 50 records for browsing, configurable by the caller. `model.ground` begins with a depth-one requested region and a 24,000-character compact context target; these are proposed presentation defaults, not limits on what a Metaform can represent or what work is authorized. It returns exact coverage, omissions and next handles. Never cut a purpose or EF midway to fit. If one required bundle is larger, return its concise record summary and a full-content handle, explicitly identifying the omitted body.

Pagination cursors bind the operation, selected revision, filters and last stable sort key. A later model revision starts a new query rather than silently mixing pages. Count unique actuals in Type membership, not multiple bindings as multiple actuals. Report totals only when known; an unknown available count is `null`, not zero.

`model.ground` is a deterministic projection when a target is given. It does not secretly invoke another model just to read saved knowledge. With no target, it returns the coarse DE orientation and candidates. A task-specialization agent can use the task's meaning to choose narrower targets and call it again. Record how the region was selected; do not claim a keyword match is a demonstrated semantic relevance ranking.

## MCP transport

Expose the semantic operation names through the existing registry/router. The newer protocol path can keep a small stable top-level tool list (`metaform`, `abort`, and currently required stable controls), with `metaform` discovering/invoking commands. Older clients can receive direct dotted command tools. Both dispatch exactly the same operation keys and schemas. The dynamic blacklist remains the source of disabled commands; do not substitute a hardcoded set of permitted domain operations.

The official 2026-07-28 specification supports structured results, output schemas and explicit state handles; it also changes protocol interaction details from older versions. Preserve the repository's version-specific adapter and host-answer fallback while adding the semantic operations. For the newer path, explicit project/model/run references must carry state rather than depending only on a connection's previous project selection. Do not replace the newer protocol's fixed router with a changing per-connection tool list. [R01](20-research-and-decisions.md#r01)

Return the common envelope in `structuredContent`; maintain compatible text content as needed by the supported clients. Attach output schemas at the transport definition, using bundled `$ref` resolution. A tool output schema is an API contract, not proof of the semantics of model-generated records.

Offer version-addressed resources such as `metaform://model/<project>/<model>/<revision>/element/<encoded-id>` and corresponding Type, join, layer and schema resources. URI path segments are encoded, not reparsed as dot-separated graph edges. The resource reader uses the same semantic read handlers. Whole-graph export remains an explicit export operation, not default grounding. [R02](20-research-and-decisions.md#r02)

## CLI mapping

Keep the existing two-word command syntax and named flags:

```sh
metaform --project /work/mgm model discover
metaform --project /work/mgm namespace browse --target code
metaform --project /work/mgm type inspect --target code.cpp
metaform --project /work/mgm type members --target code --descendants
metaform --project /work/mgm element inspect --target mgm:dnsresponders
metaform --project /work/mgm graph neighbors --target mgm:dnsresponders
metaform --project /work/mgm model ground --target mgm:project --task 'Plan a port of the connectivity engine'
metaform --project /work/mgm layer create --request 'Add implementation practices relevant to this project'
```

These are target commands to implement, not claims they already exist. Complex `model`, `target`, selector or patch values use the existing JSON/file input conventions. A CLI convenience for model/revision selection can normalize into the canonical ModelRef before dispatch; document it in the manifest rather than implementing a separate parser ontology.

Preserve JSON output for scripting. Add a human-readable view only as a rendering of the same envelope, not a second interpretation. Existing `graph.get`, `graph.browse`, and export commands remain available for historical/admin access during migration. Their older behavior is documented; they must not silently change meaning underneath a running old assignment.

## Shared implementation seam

Add `read_model.py:read_model(app, operation, arguments)` as the common entry. Thin manifest handlers delegate to it; Flask read routes invoke the same handler. `namespace.py:resolve_target` and `properties.py:explain_applicability` are shared helpers. Generation and transformation handlers are separate operations but return these same canonical references.

Every read returns dependencies on the records and selectors it used. Those descriptors support layer recipes, prepared-context caches, and transformation impact. This is the point at which GUI browsing and agent grounding become two views of the same architecture rather than three independent clients of generic database rows.
