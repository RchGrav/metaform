# Target schema registry

These are proposed versioned interchange contracts, not silently substituted definitions for existing stored v1 records. Register all `$id` values locally and resolve `$ref` through the registry. The runtime keeps draft diagnostics separate from semantic truth.

`foundation.schema.json` defines separate Types, actuals, bindings, narrowing/refinement relations, and OP joins, plus shared references, selectors, dependencies and activities. `layer.schema.json` specifies the layer/recipe/generation/attachment envelope. `transformation.schema.json` carries explicit graph changes and mappings. `read-envelope.schema.json` is the common GUI/CLI/MCP result contract. `blindspot-report.schema.json` is one possible knowledge payload, not a catalogue that limits layer kinds.

The schema documents intentionally leave extension fields available. Custom record/payload schemas remain part of the existing registry model. The built-in role and narrowing values express the current Metaform semantics; artifact-specific knowledge remains extensible.

The reference validator in `verification/validate_package.py` checks the schemas and illustrative instances. Its successful run means those artifacts are structurally consistent. It does not prove that a model-generated Type, EF, purpose, or inheritance claim is semantically correct.

Additional cross-record checks implemented by the platform should annotate duplicate map-key/ID mismatches, unresolved refs, a binding with an absent Type, OP joins whose provider Type is not a facet of the provider, malformed canonical placements, and cycles in canonical narrowing/aliases. Preserve original draft observations; do not invent missing semantic content to obtain a passing schema result.

For transformation execution, `add`/`update` require the relevant typed record, `remove` names the exact current target, `replace` includes an explicit replacement reference/record, and `relocate` includes a meaning-preserving mapping. The engine applies the operation as a transaction against `source.revision`; undefined or incomplete operations return their exact diagnostic rather than silently doing something else. Historical prompt/source strings remain unchanged while structured references are realigned.
