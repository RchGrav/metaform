# Guidance audit and supersession map

## Authority and scope

The current user request establishes the intended realignment. Current code establishes the implemented baseline. Maintained semantic sources preserve operative mechanisms such as the receiver-owned conjunction, namespace naming, alias scope, and property transitivity. Older development plans and imported source prose explain history; they do not select new runtime work when they conflict with this request.

Keep platform-expert instructions separate from runtime role prompts. Preserve the user's complete supplied foundation verbatim in the platform-expert prompt included in this archive. Runtime prompts receive concise, role-relevant semantics, not the complete foundation or collaboration policy.

## Observed guidance

| Source | Observed influence | Action |
| --- | --- | --- |
| `src/metaform/data/semantics/native.md` | Actual IDs, Type references, receiver-owned OP roles, whole-account description; also broad detail capture, SVG requirement, handoff to Latent | Retain useful actual/Type mechanics; replace with coarse-purpose frontier prompt and remove automatic outside stage/artwork obligation |
| `src/metaform/data/semantics/archaeology.md` | Requires Latent Elements/joins and proposed missing actuals | Replace with outside-in report/layer prompt |
| `src/metaform/data/semantics/glossary.md` | Defines complete separate Latent/Contextual graphs and a structural similarity layer; mixes platform ontology and role instructions | Keep an updated reference glossary; remove automatic blanket prompt inclusion and superseded two-shape instructions |
| `src/metaform/prompts.py:seed/get` | Concatenates role+full glossary, seeds unused proof role, supplies r1–r5 defaults, upgrades known prompt hashes | Replace seeding with versioned role-component composition and explicit managed/custom provenance |
| `src/metaform/intake.py:_assignment` | Appends full Aliases block and complete graph schema to both Native and outside assignments | Give structural authoring its namespace/alias rules; report-only analysis gets reference semantics and its own payload schema |
| `src/metaform/data/semantics/proof.md` | Describes `new_type_ids`, `handoff_ids`, corrected namespace batches and archaeology preparation | Retire from current runtime seeds; retain historic snapshots to interpret old runs |
| `src/metaform/data/semantics/latent-role.md` | Fresh outside analyst framing | Retain independence, change the product to blind-spot knowledge rather than a second graph |
| `src/metaform/data/semantics/sources.json` | Describes the two-stage Native/whole-Latent runtime as current | Update paths, provenance and supersession notes with the new lifecycle |
| `src/metaform/data/rulebook.json` | Runtime r1 still says independently authored EN while newer maintained naming guidance derives name through namespace and length | Align bundled concise rule and examples with the accepted naming mechanism; retain historic revisions |
| `docs/SPEC.md`, architecture/workflows/primer documents | Contain useful semantic contracts and two-graph explanations in the same documents | Update current architecture coherently; preserve quoted historical discussions as history |
| `docs/semantics/names-receivers-and-variants.md` and variant briefs | Already describe source-shape cloning and rerunning originating prompts | Retain the mechanism; implement the concrete layer/dependency records specified here |
| `README.md`, GUI labels, graph similarity manifests | Public description still centers Contextual/Latent/Inference comparison | Explain one foundation plus layers and explicit variants; keep old comparison under historical analysis |
| `AGENTS.md`, `CLAUDE.md`, generated platform prompts | Platform foundation and current/historical development instructions coexist | Point platform agents at this archive, preserve user-authored collaboration intent, replace only conflicting semantic/lifecycle guidance |
| `out.md`, imported `.source.md`, old handoffs/reviews | Historical model outputs and earlier assumptions | Keep as evidence; remove them from automatic current prompt composition or task selection where applicable |

Sources and exact paths: [S03](evidence/source-index.md#s03), [S09](evidence/source-index.md#s09), [S13](evidence/source-index.md#s13), [S14](evidence/source-index.md#s14).

## Prompt contamination that is directly demonstrated

`prompts.seed()` constructs Native and archaeology text with the full glossary. The glossary explicitly says the Contextual and Latent Metaforms remain complete, independently observable graphs. Thus the competing-shape requirement is not a guessed hidden instruction; it is a current bundled input that conflicts with the new user request.

The proof prompt is still seeded even though the latest intake no longer dispatches a proof stage. That is a maintenance/surface inconsistency, not proof the dead stage currently executes. The package removes it from normal seeding and migrates its historical records rather than claiming unseen workers are running it.

The naming rule mismatch is also visible: maintained documentation records reverse-name/length placement while the bundled r1 concise statement still centers an authored Name. Fix the actual runtime rule selection, not only another explanatory page.

## What is inferred or unknown

The sample's Native records contain latent-assessment provenance. The sample alone does not establish whether an earlier map, a previous pass, reused records, or another step produced that content. Do not invent a hidden system instruction or assert that the current `_native_snapshot` mutated Native incorrectly. Record the observed data contamination and add source/activity lineage that can locate the cause in a fresh run.

The user's unpublished local handoff was not inspected. No replacement guidance in this package claims to supersede unknown local instructions by pretending they were read. The user-supplied task and clarifications are sufficient to specify this archive's intended architecture.

## Replacement project guidance

Use `prompts/platform/platform-expert.md` for agents implementing or troubleshooting Metaform. It includes the supplied foundation and the one-foundation/layer architecture, source/Type distinction, and relevant document map. A subagent gets its named subsystem assignment plus that shared platform prompt and the relevant contract documents. Avoid copying a differently paraphrased foundation into each task.

Update `AGENTS.md` with a concise active architecture pointer and the explicit supersession of the mandatory second graph, full-glossary runtime concatenation, and per-Type proof/Latent completion model. Preserve unrelated user-authored collaboration instructions. Do not rewrite the entire file merely because part of its architecture changed.

Runtime prompts in `prompts/runtime/` are separately authored. Their instructions express only the role's work, operative semantics, target context and intended output. The implementation agent should not copy platform review checklists, generic caution habits, approval flows, or collaboration rules into them.

## Managed prompt migration

Record bundled template/component identity and revision separately from authored overrides. For a known managed seed, migrate to the new role composition while preserving its old snapshot. For a user-authored override, retain the text and expose a concrete difference report showing which old requirements conflict. An override that still asks for a second graph cannot be silently advertised as the new report prompt.

Resolve migration explicitly in the selected operation/version; do not infer managed/custom status solely from a growing list of historical text hashes forever. Existing hash mappings are useful for one-time recognition of older seeds. Preserve every already-issued assignment with its exact schema and prompt; new assignments use the revised version.

## Documentation updates as one coherent change

Update the current-facing README, SPEC, architecture, workflows, workbench navigation, semantic source manifest, runtime module descriptions, schema documentation, and active agent pointer in the same implementation sequence. Historical examples retain their provenance and a link to the current model. Do not rename old `archaeology` scope bytes in the archived sample to make history appear as if it used the new architecture.
