# Immediate GUI refinement: uncovered, readable text

## Observed defect

Rich reported partially covered text in the latest graph view. In the review's 1600×1000 selected DNS scene, the purpose labels between `mgm:dnsresponders` and `mgm:dnsbench` / `mgm:sentry` run beneath the node cards. Two source-specific joins also produce closely stacked text for the same local meeting. The three-node scene is otherwise a useful, substantially more legible direction than the larger initial scene. Preserve it. [S06](evidence/source-index.md#s06)

The current renderer computes fixed node dimensions, puts a 72px artwork inside the card, shifts the label by 42px, and uses edge labels up to 170px wide while Dagre primarily lays out nodes and edges. The normal scene does not reserve a readable label region between cards. Hover increases edge text width to 260px and z-index, which can move the obstruction rather than reliably making all labels readable. These are observed rendering choices; the exact collision mechanism should be confirmed with the fixture after the repair. [S06](evidence/source-index.md#s06)

## Localized repair before broader GUI work

Keep `cytoscape-view.js`, Dagre, the palette, directed arrows, authored SVGs, and one-hop replacement. Change how text competes for space:

1. Default edges show the relationship role or a concise purpose title, with the complete receiver purpose available on focus/selection in a dedicated overlay and the relationship list. Do not draw long full-purpose paragraphs on every parallel edge at once.
2. Reserve a measured text corridor in local layouts. For a left-to-right layout, derive the needed rank separation from the rendered label bounds and node bounds, rather than treating a fixed universal gap as sufficient. Re-layout only when topology or card geometry changes.
3. Render the selected/hovered full-purpose explanation in a DOM overlay anchored to the edge midpoint. Measure its rectangle after layout; shift it within the canvas bounds so it does not cover the focal card or toolbar. Keep it keyboard reachable. Do not rely solely on raising the canvas edge's z-index above the nodes.
4. Separate artwork and text within compact cards. Use the short actual name and Type label on the canvas; the inspector carries the full description. Compute card height from the visible lines and artwork region. Preserve the underlying full strings and accessible labels; a visual ellipsis is not a data edit.
5. Keep parallel purposes distinct. When several edges share a corridor, show a relationship count and selectable rows in the inspector, or route distinguishable parallel curves. Do not merge stored joins or pretend source duplicates are identical meanings.

The broader one-foundation projection removes the routine Native/Latent duplication. Until that data change is in place, an explicit comparison mode can group overlapping source renderings visually and expose their separate records. Do not apply silent deduplication to the semantic store as a layout fix.

## Concrete checks

Use the real archived DNS neighborhood, the DE's larger neighborhood, a long multi-line name, an actual with multiple Types, and parallel joins. At 1600×1000 and a narrower desktop width, inspect every default visible label and select each overlapping relation. Text must not disappear behind a card, toolbar, or inspector. The full purpose must be accessible without requiring the user to discover that zooming changes its z-order.

At 390×844, open the selected actual and a join through the relationship list. Its name, complete purpose, and provider/receiver identities remain readable in the responsive inspector. Recenter the focus after resizing. A passing canvas-model test is not sufficient for this issue: retain a rendered screenshot plus pointer/keyboard observations.

Treat this as a focused repair, not a precondition for completing the semantic design. It can proceed independently while the foundation/layer work is implemented. The task-level demonstration must ultimately exercise both the repaired text and the correct underlying semantics.
