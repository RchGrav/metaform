# Reproduced current application views

The PNG and JSON files in this directory are generated during archive assembly by `verification/render_current_gui.py`. They render the original reviewed application with the unchanged saved sample, using the same in-process Flask transport method as the original local examination. They are not images of the proposed GUI.

`initial` opens the Defining Element neighborhood; `types` uses the Types control; `selected` opens `mgm:dnsresponders` through the application's actual controller and inspector; `mobile` resizes that selected view to 390×844. Each JSON file records the DOM text, scene, viewport and zoom, and `requests.json` records backend responses and page errors.

The original local measurements remain explicitly labelled in `../measurements.json`. The sample author's original installed-viewer screenshot is separately preserved at `../original-sample/viewer.png`. Browser/font/environment differences can alter exact layout geometry; no reproduction should be mistaken for a controlled live-model intake experiment.
