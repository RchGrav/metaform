# Verification record and evidence limits

## Original review environment

The reviewed repository snapshot was `ba6421e232532e4a52565c53320f61af2b4df0f9`. The before snapshot was `c115a6cea8ad01d7aa76a2d13bed25b83a2d2651`. They were obtained through the connected repository's isolated review workflow, not through a public copy. The local environment used Python 3.13.5, Node 22 and Chromium. Application dependencies were installed at the lockfile versions. The build produced the 0.2.0 wheel, which was installed into the isolated environment.

Equivalent commands, with paths adjusted to the local checkout/environment:

```sh
python -m pytest -q
node --test tests/test_structure_model.cjs tests/test_cytoscape_renderer.cjs
python tools/build_distribution.py
python -m pip install --no-deps --force-reinstall dist/metaform_chassis-0.2.0-py3-none-any.whl
python tools/check_distribution.py
```

The Python suite passed **546 tests in 81.19 seconds**. The JavaScript model/renderer suite passed **22 tests**, with no failures. The build and wheel installation succeeded. The installed smoke check separately failed at `tools/check_distribution.py:76`, where it still expects the removed per-Type `job["inputs"]["id"]`. The preserved original local trace is in `installed-wheel-check.log`; the original Python result is in `python-tests.log`.

The remote baseline CI run also passed source tests/build and failed the installed check on both configured Python jobs. Its Python 3.11 log reports 546 tests passing before the same KeyError. See [S05](source-index.md#s05). Dependency versions changed during that CI's unlocked wheel install, but the observed stack failure is the missing assignment key; this review does not attribute that failure to an unproven dependency incompatibility.

## Semantic probes

`verification/reproduce_evidence.py` parses the original sample bytes, verifies manifest hashes, compares record/semantic-join identities, measures seeded prompt composition, and runs two small graph probes. It preserves the original sample rather than constructing corrected output.

The rename probe updates `code.engine` to `code.coordinator` through `renamed_elements`; the actual's structured `type_ids` still contains `code.engine`. The depth-zero Type probe returns the selected Type, a narrower Type and their actual members. This establishes that the current `assemble` operation is broader than exact Type inspection; it does not establish a property-inheritance implementation.

Sample metrics count 58/72 actuals, 47/47 Types and 101/204 joins in Native/Latent. All 58 Native actuals already carry latent-perspective provenance. The exact earlier activity that introduced this content is not recoverable from the supplied historical data. The source MGM checkout was not independently re-audited.

Prompt inventory counts characters, not tokens. It measures the actual seeded source prompt and selected rule payload in a fresh isolated application. The full glossary appears in Native, archaeology and proof seeds, not in the inspected workflow/continuity seeds. The revised role prompts have not been run through a live model in this review.

## Browser examination

The original application was executed in headless Chromium at 1600×1000, then 390×844. The browser environment blocked normal localhost page navigation, so the examination inlined the original packaged scripts/styles and bridged `fetch` into the unmodified Flask application's test client. This exercised the real controller, renderer, DOM and backend response construction without claiming a live browser HTTP session.

The initial DE scene, Types control, DNS responder neighborhood/inspector and narrow viewport were examined. Types was opened through its actual control; the DNS scene was selected through the real navigation controller and inspector. Not every action was independently pointer-tested. No page-script errors occurred in the successful examination. The original two browser suites were not independently rerun in their original Node/Playwright harness.

Original measurements retained in `measurements.json` are 17 actuals/28 joins and 36% fit initially; 36 visible Type-view records and 12% fit; 3 actuals/3 joins and 87% fit for DNS; 4,052px page height after narrow resizing; and a 1,073,063-byte initial network response. These are fixture-specific observations. Timing from the test client is not a production performance guarantee.

`verification/render_current_gui.py` repeats the same in-process examination during archive assembly and saves screenshots and DOM/request records under `browser-reproduction/`. Those files are explicitly an **archive-assembly reproduction**, not a mislabelled copy of the first local rendering. The original repository-supplied screenshot is preserved separately under `original-sample/viewer.png`. Differences in browser/font/environment can affect exact geometry; the substantive findings must be read with that scope.

## Package verification

`verification/validate_package.py` checks registered JSON Schemas, illustrative example instances, cross-record example references, role composition file/schema references, internal Markdown file links, required kickoff/spec files and manifest hashes when present. The assembler records its output in `package-validation.log` and its environment metadata in `assembly.json`.

A successful package check proves the delivered files are internally consistent and intact. It does not prove the target platform behavior or the semantic correctness of future generated output. V01–V24 in `../22-verification-cases.md` specify the implementation's meaningful behavioral and task-level evidence.

## Reproduction commands

From a checkout of the pinned baseline with its dependencies installed:

```sh
python /path/to/archive/verification/reproduce_evidence.py --repo . --out /tmp/metaform-evidence
python /path/to/archive/verification/render_current_gui.py --repo . --out /tmp/metaform-browser
python /path/to/archive/verification/validate_package.py /path/to/archive
```

The browser script requires Playwright and a Chromium executable or Playwright's installed Chromium. It writes only to the supplied output and temporary fixture directories. The evidence script creates isolated graph/application fixtures. Neither modifies the source sample or applies the proposed architecture to the repository.
