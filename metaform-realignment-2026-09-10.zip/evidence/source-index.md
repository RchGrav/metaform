# Pinned repository evidence index

All repository links below refer to reviewed remote revision `ba6421e232532e4a52565c53320f61af2b4df0f9` unless an explicit before/after commit is named. Source code establishes implementation, not intended-model authority. The current user request and clarifications establish the realignment described by the specifications.

## S01

**Baseline and change history.** [Reviewed tip](https://github.com/RchGrav/metaform/commit/ba6421e232532e4a52565c53320f61af2b4df0f9), [substantive implementation](https://github.com/RchGrav/metaform/commit/8c2f4a3ae6f8d858a14939f11a85450d9d5f3157), [implementation parent](https://github.com/RchGrav/metaform/commit/c115a6cea8ad01d7aa76a2d13bed25b83a2d2651), [published handoff](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/handoff/2026-09-10-awaiting-next-steps.md). The user's separately mentioned local handoff was not read. Full implementation diff and recent history are retained in this evidence directory as `implementation.patch` and `history.txt`.

## S02

**MGM sample context and raw records.** [README](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/examples/intake/mgm-main/README.md), [Native](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/examples/intake/mgm-main/native.json), [Latent](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/examples/intake/mgm-main/latent.json), [manifest](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/examples/intake/mgm-main/manifest.json). Exact sample bytes are under `original-sample/`, including its supplied viewer image. Measurements preserve the distinction between IDs, record content and join semantic tuples.

## S03

**Current intake lifecycle.** [intake.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/intake.py): `start`, `examine`, `_native_snapshot`, `_assignment`, `put`, `submit`, `_finish`. [Module handler](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/modules/intake.py), [manifest](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/modules/intake.json), [Native role](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/native.md), [archaeology role](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/archaeology.md). These demonstrate the whole-artifact assignment, automatic outside stage and structural publication.

## S04

**Before/after intake and GUI changes.** [Parent intake implementation](https://github.com/RchGrav/metaform/blob/c115a6cea8ad01d7aa76a2d13bed25b83a2d2651/src/metaform/intake.py) compared with S03; the implementation diff includes prompt/schema changes and addition of `structure.js` and `cytoscape-view.js`. [Native/Latent tests](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/tests/test_native_latent_intake.py), [scope replacement tests](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/tests/test_scope_replacement.py), [Type assembly tests](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/tests/test_type_assembly.py). This is a source/contract comparison, not a controlled pre/post model-quality trial.

## S05

**Verification and installed smoke defect.** [check_distribution.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/tools/check_distribution.py), especially line 76 in `check_intake`; [build script](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/tools/build_distribution.py), [CI workflow](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/.github/workflows/wheel.yml), [package metadata](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/pyproject.toml). Remote run [34510014044](https://github.com/RchGrav/metaform/actions/runs/34510014044) passed source tests/build but failed installed smoke. Local review reproduced that failure; see `verification.md` and retained logs.

## S06

**GUI implementation and direct rendering.** [viewer.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/viewer.py), [structure.js](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/static/structure.js), [cytoscape-view.js](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/static/cytoscape-view.js), [workbench.js](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/static/workbench.js), [styles](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/static/workbench.css), [template](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/templates/index.html). Inspect `network`, Type/actual assembly, `definingRelation`, `inspect`, canvas label/card styles and viewport state. Direct-render evidence and reproduction script are included; they use the original application, not the proposed wireframe.

## S07

**Graph identity, joins, assembly and rename.** [graph.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/graph.py), especially `renamed_elements`, `Graph.assemble`, scope replacement and attributed observations; [backends.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/backends.py). `semantic-probes.json` supplies the localized dangling-`type_ids` and depth-zero Type expansion witnesses.

## S08

**Owner-qualified knowledge and portability.** [knowledge.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/knowledge.py), [service.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/service.py), [knowledge_export.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/knowledge_export.py), [portable.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/portable.py). Preserve `RecordKey`, project/global ownership, normalized joins, service authority and portable representations.

## S09

**Prompt composition and workflows.** [prompts.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/prompts.py), especially `seed`, `get` and `snapshot`; [glossary](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/glossary.md), [proof](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/proof.md), [Aliases](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/aliases.md), [workflow handler](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/modules/workflow.py), [workflow engine](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/workflow.py). `prompt-inventory.json` measures actual seeded composition, not merely file sizes.

## S10

**CLI/MCP and dispatch model.** [cli.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/cli.py), [mcp_server.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/mcp_server.py), [portable_mcp.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/portable_mcp.py), [registry.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/registry.py), [continuation.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/continuation.py). Retain named manifest flags, version-specific MCP routing, explicit host-answer continuation and the dynamic blacklist/module dispatch model.

## S11

**Variant intent versus implemented file/project machinery.** [Variant specification](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/feature-briefs/native-metaform-variants-specification.md), [variant plan](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/feature-briefs/native-metaform-variants-implementation-plan.md), [names/receivers/variants semantics](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/semantics/names-receivers-and-variants.md), [history.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/history.py). The briefs are intent/design evidence, not proof semantic variants and reinference are implemented.

## S12

**Existing schema contracts.** [schemas.json](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/schemas.json), [schemas.py](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/schemas.py). Inspect `metaform:element`, `metaform:actual-element`, `metaform:join`, `metaform:op-join`, `metaform:graph` and `metaform:learning`. Type EF/classification requirements and the generic graph join reference are the specific gaps; new target schemas are in `../schemas/`.

## S13

**Maintained core semantics.** [SPEC](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/SPEC.md), especially Encounter propagation and naming; [artifact/functional intake](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/semantics/artifacts-and-functional-intake.md), [Name rule](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/rulebook/element/name.md), [Description rule](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/rulebook/element/description.md). The archive preserves meaningful current rules and explicitly supersedes the conflicting mandatory two-shape lifecycle.

## S14

**Rulebook and guidance provenance.** [Bundled rulebook](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/rulebook.json), [rulebook documentation](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/docs/rulebook/README.md), [semantic source manifest](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/src/metaform/data/semantics/sources.json), [AGENTS](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/AGENTS.md), [CLAUDE](https://github.com/RchGrav/metaform/blob/ba6421e232532e4a52565c53320f61af2b4df0f9/CLAUDE.md). Preserve user-authored collaboration scope; update only conflicting semantic/runtime guidance. Imported source notes, older handoffs and `out.md` are historical evidence, not automatically current runtime instructions.
