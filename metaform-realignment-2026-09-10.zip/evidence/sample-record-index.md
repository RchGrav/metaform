# Original sample record index

Generated from the saved Native file. These are recorded descriptions, not newly verified MGM implementation claims.

## mgm:analysis

Types: code.tester

Runs the explicit SDK/Clang analysis path and validates findings through static_analysis_verify.py.

```json
{
  "account": "Repository analyzer tooling builds compile context and evaluates static-analysis evidence with a maintained allowlist.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Static analysis is complementary evidence with a stated compilation context and allowlist. Availability of a target is not execution, and analysis success is not dynamic connectivity acceptance. Native-reported scope and qualifications: make static-analysis may use MVM_SDK_PATH; no analysis run was performed in this pass."
}
```

## mgm:autoap

Types: code.daemon

Keeps a DHCP client running, adds a fallback address after timeout, enables owned DHCP service, and withdraws fallback when upstream addressing returns.

```json
{
  "account": "Per-interface autoapd tries upstream DHCP and maintains fallback management access when no non-fallback IPv4 address is present.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Management fallback addresses a different receiving purpose from upstream usability. Ownership/restoration is a sound boundary. Passive DHCP silence and a fixed fallback address leave coexistence and partition-merge questions that need scenario-based verification. Native-reported scope and qualifications: Opt-in proto=autoap; not a wireless radio configurator or an Internet connectivity tester. Defaults: timeout 25 s, fallback 172.16.16.1/24, leases 5 m, loss debounce 5 s. Ownership marker autoap_managed and saved prior DHCP section values govern restoration. A 200 ms passive DHCP-response listen is precautionary, not proof that no DHCP server exists."
}
```

## mgm:autoapproto

Types: code.adapter

Resolves profile/device mapping, launches autoapd, applies leases via netifd, and delivers events to autoap.<logical-interface>.

```json
{
  "account": "Shell protocol launcher and udhcpc helper connecting one management-interface daemon to netifd lifecycle and DHCP lease changes.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The profile/device mapping and lease lifecycle must preserve ownership across renewals, restart and user reconfiguration. The graph supplies a mechanism, but not an acceptance signal for concurrent changes."
}
```

## mgm:batman

Types: exterior.system

Carries mesh frames and exposes current topology/reachability measurements via batman netlink and control interfaces.

```json
{
  "account": "External batman-adv subsystem supplies underlying mesh forwarding plus neighbor, originator and throughput observations.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:build

Types: code.builder

Root targets register/export this checkout, validate profile-appropriate packages, cross-build them, and invoke optional verification hooks.

```json
{
  "account": "Root and package Makefiles assemble and verify the five maintained packages through an external MVM/C3Lab checkout.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Configured profiles and package lists are intent. Installation closure must account for runtime protocols actually selected by profiles, including pi-demo AutoAP, and requires profile-specific build/install evidence. Native-reported scope and qualifications: Configured profiles: x86_64-generic, tplink_eap615-wall-v1, rpi-4. EAP builds runtime packages only; x86 adds mgm-config; rpi-4 also adds pi-demo. A configured profile is not proof of a successful build. src/Makefile.inc builds mgmd and mgm-ready-observe; package Makefile separately builds dnsbench."
}
```

## mgm:c

Types: code.c

Package compilers turn ipgen.c and autoapd.c into their runtime executables.

```json
{
  "account": "C source implementation of the standalone identity generator and management daemon.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Keep ordinary C encounter attribution for IPGen and AutoAP separate from MGM GNU C11 flags. Compilation language does not establish runtime reliability. Native-reported scope and qualifications: These package compile lines do not explicitly request -std=gnu11; the GNU C11 property on mgmd is not assumed for these siblings."
}
```

## mgm:c11

Types: code.c.c11

Compilers turn the C implementation into target binaries under the relevant package flags.

```json
{
  "account": "The MGM daemon and embedded core, readiness observer, and DNS benchmark are compiled with explicit GNU C11 flags.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Retain GNU C11 only for the compiled MGM implementation slice described by Native. Correct the description so it does not imply that IPGen and AutoAP were independently shown to select GNU C11. Native-reported scope and qualifications: -std=gnu11 includes GNU extensions; host MGM tests enforce -Wall -Wextra -Werror. This property is attached to compiled MGM elements, not to shell or documentation siblings.",
  "scope": {
    "applies_to": [
      "mgm:daemon",
      "mgm:observer",
      "mgm:dnsbench"
    ],
    "basis": "Explicit -std=gnu11 in MGM src/Makefile.inc and package Makefile.",
    "siblings": "IPGen and AutoAP have separate C compilation evidence in mgm:c; their package compile lines do not explicitly select GNU C11."
  }
}
```

## mgm:c3lab

Types: exterior.framework

Provides repository staging, OpenWrt SDK/profile package builds, platform overlays, and multi-node lab commands.

```json
{
  "account": "External build and virtual-lab facilities invoked by repository tooling.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review. Native-reported scope and qualifications: C3Lab EAP package overlay belongs outside this repository and supplies shared-br-lan policy. It was described by repository documentation, not inspected in this pass."
}
```

## mgm:ci

Types: code.tester

Pipeline runs make test and make change-contract against the PR destination; checker combines committed, staged, unstaged and untracked change scope.

```json
{
  "account": "Bitbucket pipeline and change-contract checker require tests and scope-related documentation evidence for submitted changes.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. A change-contract gate is supportive maintenance infrastructure. Stale rule references should not create runtime Elements for removed packages; verify contract coverage against the current active package map. Native-reported scope and qualifications: The current contract config still includes an old c3act rule and docs/C3ACT.md reference. That is not proof of an active C3Act package. Protected instruction/tooling files are not changed by this mapping task."
}
```

## mgm:cli

Types: code.interface

Commands invoke mgm, mgm.route, and mgm.batadv ubus methods; mgm status can fall back to /tmp/mgm/status.json when ubus is unavailable.

```json
{
  "account": "Installed mgm, mgmctl, mgm-cli and nodelist wrappers expose daemon status, state, routing, wireless, and debugging interfaces.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The running daemon is necessary for live controls, but the status fallback can serve a narrower diagnostic purpose without it. File-backed status should carry freshness/origin so operators cannot mistake retained observations for a live answer.",
  "surfaces": {
    "compiled_service": "mgm.c registers and implements the mgm, mgm.route and mgm.batadv ubus controls.",
    "property_scope": "mgm:shell describes only shell wrapper execution; compiled daemon handlers receive the GNU C11 encounter through mgm:daemon.",
    "shell_wrappers": [
      "mgm",
      "mgmctl",
      "mgm-cli.sh",
      "nodelist"
    ]
  }
}
```

## mgm:codec

Types: code.codec

Builds and parses CBOR status messages used by multicast synchronization.

```json
{
  "account": "Current wire codec for sender state and the other-node witness array.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that CBOR is the exchange representation of this function. A receiver contract should specify payload bounds, invalid-field handling and mixed-version behavior; those are missing assurances in the graph, not evidence that parsing is unsafe. Native-reported scope and qualifications: Serializes/parses one primary route despite the larger C capacity. CBOR is the codec’s exchange representation, not a standalone functional Type. Unused packed packet design is not the active protocol."
}
```

## mgm:configuration

Types: data.configuration

glue_load_config reads effective UCI values and applies supported settings to daemon behavior.

```json
{
  "account": "The shipped MGM skeleton and source-consumed configuration for bridge identity, multicast, ranking, and experimental routing.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Only consumed values are effective controls. UI/config presence is not feature implementation. Document desired, effective, inactive and invalid values so operators can tell which choices affect the running result. Native-reported scope and qualifications: Defaults include br-mesh, ff02::114:9876, 10.128.0.0/16, seed crius, rerank_cadence_ms=500 (minimum 50), experimental_indirect_uplink_routes=0. enabled is not read by mgmd; ipgen_enabled is not a live boolean; safetynet/probe skeleton values do not establish an active probing feature. mesh_originator_timeout_ms is exposed but does not drive the active originator loss algorithm."
}
```

## mgm:daemon

Types: code.daemon

Runs one uloop integration boundary that consumes kernel/service/peer events, updates state, and applies route decisions.

```json
{
  "account": "The MGM control-plane daemon integrating local state, peer multicast, routing, and embedded connectivity testing.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that a single authoritative integration boundary reduces conflicting ownership. It also concentrates progress dependencies: unrelated observation/publication work must not prevent state withdrawal and route actions. Bounded progress is a requirement to verify, not a claim of current blocking.",
  "ownership": {
    "connectivity_authority": "Embedded mgm:sentry; direct callback via mgm:sentryhandoff.",
    "event_loop": "Single uloop integration boundary.",
    "forwarding": "IPv4 kernel route actions with firewall reconciliation.",
    "peer_transport": "IPv6 link-local sender state and witnesses.",
    "route_authority": "MGM event dispatch and route manager.",
    "state": "Authoritative local record plus receiver-local remote cache."
  }
}
```

## mgm:dictionary

Types: data.dictionary

Associates generated identity indices with adjective/noun words used in human-facing names.

```json
{
  "account": "Embedded mnemonic word tables and the shipped mnem001.txt asset provide a readable vocabulary for node identity.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The vocabulary is necessary to the stated mnemonic mapping, whereas a particular installed text file is not established as a runtime requirement. Correct the native join signal that attributes this effect to installed words. Native-reported scope and qualifications: mgm_mnemonic.c directly uses an embedded 512-word table. The package also installs mnem001.txt; installation alone does not establish runtime reading of that text file. The naming dependency is on the vocabulary, not necessarily on an external word-list file."
}
```

## mgm:dnsbench

Types: code.tester

Benchmarks DNS targets and supplies ranked responder candidates to Sentry.

```json
{
  "account": "Installed dnsbench measures resolver response behavior for probe-pool renewal.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:dnsresponders

Types: exterior.system

Return DNS replies used as evidence that the selected outbound path works.

```json
{
  "account": "External DNS servers reached through candidate direct uplinks.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review. Native-reported scope and qualifications: A probe response supplies bounded reachability evidence, not universal reachability of all destinations."
}
```

## mgm:events

Types: code.dispatcher.event

Converts observations to local/remote processing, alignment, deletion/ejection and broadcast actions dispatched to owning components.

```json
{
  "account": "Ordered immediate-drain event queue joining local connectivity, inbound peer state, route changes and advertisements.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review. Native-reported scope and qualifications: Inactive/offline peers lose routes. Indirect gateway creation is gated by experimental_indirect_uplink_routes, default off."
}
```

## mgm:firewall

Types: code.manager.firewall

Generates a fw4 include, reconciles on network/reload events, verifies live markers, and retries missing installation.

```json
{
  "account": "Maintains mesh multicast admission and forwarding/NAT between the mesh and discovered direct uplinks.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Marker presence establishes a weaker condition than effective per-uplink forwarding and return-path permission. Keep reconciliation and restart continuity, but make semantic rule coverage and actual traffic success separate acceptance signals. Native-reported scope and qualifications: Includes mesh-to-uplink forwarding, established return traffic, masquerading and multicast input. Live check tests expected comment markers rather than full per-uplink semantic equality. Restart marker preserves continuity across daemon restarts."
}
```

## mgm:guide

Types: document.guide

Provides reading order, package ownership, configuration consumption, runtime commands, build profile composition and bounded validation interpretation.

```json
{
  "account": "README, documentation authority guide, package guide and operations guide orient maintainers and operators to the active package set.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Treat documentation authority and drift as operating concerns, not runtime capabilities. Align package counts, configuration consumption and profile dependencies with the accepted functional model. Native-reported scope and qualifications: Current source, installed assets, UCI consumers and tests win over prose. docs/README.md still says six-package map although actual package table/build has five; older pi-demo README and packages/manifest.txt contain stale dependency/topology references. These are evidence qualifications, not active contracts."
}
```

## mgm:hosttests

Types: code.tester

Root make test builds and runs six host C executables and Python change-contract, static-analysis-verifier and protocol-contract suites.

```json
{
  "account": "Repository-only checks for metrics, throughput ranking, originator timeout, Sentry behavior/telemetry/route loss, and protocol contracts.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Host checks establish only their covered deterministic conditions when run. They cannot substitute for actual kernel, forwarding, profile-installation or multi-node outcomes. No passing run is claimed. Native-reported scope and qualifications: Not installed package payloads. This intake pass inspected tests and wiring without executing them or claiming passing results."
}
```

## mgm:identityadapter

Types: code.adapter

Discovers configured/logical mesh interfaces and addresses, detects IPGen ownership metadata, and combines Sentry findings with real default routes and mesh-prefix gateway classification.

```json
{
  "account": "OpenWrt integration selecting MGM’s actual mesh-L3 identity and distinguishing direct uplinks from mesh routes.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that actual mesh-L3 identity, not a specific identity generator, is the prerequisite. Shared-bridge directness classification and eligible probe selection must agree about the actual gateway path; a device name by itself is insufficient evidence. Native-reported scope and qualifications: Valid mesh-L3 addressing is a runtime prerequisite; IPGen is one provider. Shared bridges require gateway-prefix classification rather than treating all traffic on the bridge as mesh or all as direct uplink."
}
```

## mgm:identitytests

Types: code.tester

Shell and Python harnesses exercise identity mapping and protocol installation cases.

```json
{
  "account": "Focused repository checks for stable selected identity, shared mnemonic mapping and first-install netifd/static handoff.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Deterministic identity and install-handoff checks do not by themselves cover post-partition collisions, fallback acceptance or restored management reachability. Native-reported scope and qualifications: These focused checks are separate from the root make test recipe. Inspected, not executed in this pass."
}
```

## mgm:ipgen

Types: code.generator.identity

Uses seeded FNV-1a, a usable host window, ARP conflict probing and mnemonic generation to output addressing and identity metadata.

```json
{
  "account": "Separate package generating stable mesh IPv4 and mnemonic identity from a selected MAC and seed.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Stable deterministic generation and finite ARP probing reduce manual work but cannot establish uniqueness under partition, probe failure or later merges. Preserve static addressing as an alternative. Distinguish a generated candidate from verified address usability. Native-reported scope and qualifications: Explicit macsrc wins; otherwise /etc/ipgen.mac persists the selected identity, initially the lowest-ifindex valid non-loopback interface. Supports IPv4 /8 through /24; reserves 1/32 at each end and tries ten conflict candidates. Probe errors do not establish conflict; exhaustion can return a fallback with failed=true and exit 2. Not guaranteed collision-free. MGM does not have a package dependency on IPGen; static mesh-L3 configuration is an alternative."
}
```

## mgm:ipgenproto

Types: code.adapter

netifd proto=ipgen invokes the generator, publishes addresses/metadata and gratuitous ARP; install handoff uses persistent static addressing if that running netifd has not learned the protocol.

```json
{
  "account": "Shell protocol/defaults assets apply generated identity to an actual mesh-L3 device and persist first-install addressing.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accepting exit 2 is a described behavior, not verified collision freedom. An adoption contract should state how degraded identity is exposed and whether it may authorize publication or routes. Do not prescribe rejecting all such output without deployment recovery policy. Native-reported scope and qualifications: MAC identity source and ARP DAD device may differ. Shell accepts generator exit 2, so a generated fallback must not be interpreted as collision-free success."
}
```

## mgm:javascript

Types: code.javascript

LuCI loads the scripts to render forms and request configuration/status operations.

```json
{
  "account": "The JavaScript implementation of installed protocol/configuration web interfaces.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Scope this encounter to the named web interface assets; their use of backend services does not turn those services into JavaScript."
}
```

## mgm:labtests

Types: code.tester

Drive external MVM lab nodes and capture route, state, timing and diagnostic evidence during controlled scenarios.

```json
{
  "account": "Repository lab scripts inspect convergence, route failover/recovery, multicast restart behavior, ubus responsiveness and control-loop performance.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Multi-node scenarios are the natural receiver of end-to-end and convergence acceptance contracts. Evidence must identify origin, destination, selected gateway, return path, timing and fault conditions; topology snapshots alone do not establish traffic success. Native-reported scope and qualifications: Requires the exterior lab; scripts are validation tooling outside shipped runtime functionality. No live lab actions were performed for this pass."
}
```

## mgm:leds

Types: code.observer

Reads MGM status and presents LED patterns through libgpiod and uloop timers.

```json
{
  "account": "Conditional GPIO output for direct WAN and mesh state on supported Pi builds.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Keep the hardware and compile scope. A coarse indication is useful only with an explicit legend distinguishing tester confidence, mesh visibility and delivered access; no hardware validation is asserted. Native-reported scope and qualifications: Compiled platform behavior guarded by MGM_PLATFORM_RPI; hardware indication was not exercised during this mapping pass. Sentry also contains tester LED logic; this record names the separate MGM Pi GPIO output boundary."
}
```

## mgm:luci

Types: code.interface

JavaScript forms select interface/profile settings and read AutoAP status through RPC/ubus permissions.

```json
{
  "account": "Installed LuCI assets expose protocol configuration and AutoAP management status.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:maintainers

Types: exterior.group.maintainer

Use source, canonical guides, host tests, and profile builds to change and validate the system.

```json
{
  "account": "Contributors maintaining the OpenWrt package set and its verification tooling.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:metrics

Types: code.policy

Calculates start metrics used to align and pack default routes.

```json
{
  "account": "Converts local/remote role, uplink type and throughput band into class-aligned route preference.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Metric ordering expresses policy after eligibility, not evidence of usability. Stable failover, gateway return behavior and experimental indirect-route safety require explicit acceptance criteria; changing constants alone is not acceptance. Native-reported scope and qualifications: Current bases: local wired 100, remote direct 125/225/325, forwarder 650, stale 775, degraded 800; ordinary direct paths add wireless 50 or other 300. These constants describe preference, not connectivity proof."
}
```

## mgm:mgmconfig

Types: code.provisioner

UCI defaults and init assets create bat0/br-mesh/mesh_l3, disable mesh DHCP service, and connect MGM to discovered/configured interface names.

```json
{
  "account": "Config-only OpenWrt package establishing a BATMAN_V interface, generic mesh bridge, and mesh L3 provider wiring.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Generic br-mesh provisioning and the external EAP shared-br-lan policy are different actual deployment choices. Applying one profile does not prove the other topology is correctly prepared. Native-reported scope and qualifications: Optional image composition. Generic br-mesh policy does not implement the EAP shared-br-lan profile; dependencies include ipgen, kmod-batman-adv, and batctl-full."
}
```

## mgm:multicast

Types: code.synchronizer

Encodes a local status and sender-scoped FNV1a32 witnesses; a receiver processes the sender, checks its own witness, and schedules its own advertisement when knowledge differs.

```json
{
  "account": "Bridge-bound IPv6 link-local exchange advertises only sender-owned state and witnesses of other nodes’ state knowledge.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Sender attribution, witness comparison, freshness, authenticity and route-relevant completeness are different assurances. Equal-token packets still process, so token equality is not an update-suppression bug. Gateway-only and metric-only changes need an eventual-delivery contract even though they need not bump tokens. A resettable coalescing timer raises a progress question under repeated triggers; starvation is not proven. Native-reported scope and qualifications: mgm_other_node_hash scopes witness to sender MAC, remote MAC, and remote state token; third-party state is not relayed. Missing own witness arms/resets a one-second coalescing timer. Equal sender tokens do not suppress remote upsert/processing. Token bumps cover participation, online, direct, and primary uplink-name transitions; gateway or metric change alone is not sufficient. ff02::114:9876 is configured default; only IPv6 link-local multicast is accepted."
}
```

## mgm:names

Types: code.publisher

Derives deterministic mnemonic labels and coalesces local/remote state into /tmp/hosts/mgm for dnsmasq addnhosts consumption.

```json
{
  "account": "Makes mesh identities understandable through names in daemon status and local DNS.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Mnemonic readability is supportive to gateway use. Mnemonic generation itself requires its vocabulary, while actual DNS resolution additionally requires a consuming resolver. Determinism does not make names authoritative or globally unique. Native-reported scope and qualifications: Host refresh is coalesced at 250 ms rather than performed inline on observation hot paths. IPGen and MGM mnemonic generation share tested mapping expectations."
}
```

## mgm:network

Types: exterior.system.network

Presents links, peer nodes, and uplinks over which MGM coordinates access.

```json
{
  "account": "The physical or virtual deployment carrying mesh traffic and providing candidate upstream connections.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:observer

Types: code.observer

Subscribes to ubus events and watches fw4 state files, combining observations into readiness timing and optional JSON summaries.

```json
{
  "account": "Installed diagnostic executable correlating lifecycle, peer reception, batman originators, interface events, and firewall reload evidence.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Readiness diagnostics are evidence of observed phases, not proof of client reachability. Missing events or observation loss should produce unknown/incomplete evidence rather than invented success; the graph does not establish current behavior in that case. Native-reported scope and qualifications: Diagnostic evidence, not a route owner or end-to-end Internet connectivity guarantee."
}
```

## mgm:openwrt

Types: exterior.framework

Exposes procd, UCI, ubus/uloop, netifd, Linux netlink, nftables/firewall4, and dnsmasq integration used by the packages.

```json
{
  "account": "The external OpenWrt environment providing service supervision, configuration, event messaging, network lifecycle, and packet forwarding.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:operators

Types: exterior.group.operator

Configure images and services, inspect connectivity and routes, and respond to faults.

```json
{
  "account": "People deploying and operating the MGM OpenWrt package set.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Operational success includes explaining why a path was chosen, knowing what evidence remains current, and retaining management access through faults. Configuration visibility alone does not establish these outcomes."
}
```

## mgm:originators

Types: code.observer, code.adapter

core_adapter reads throughput/last_seen, ejects routes and purges peer records above prior EWMA plus 1000 ms, then requests rediscovery after two consecutive sub-1000 ms samples.

```json
{
  "account": "Collects best-originator measurements, identifies loss against a local age baseline, and prompts rediscovery after recovery.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Topology reachability and originator age support a failure detector but do not establish freshness of peer daemon state or its current upstream access. Preserve the described EWMA-based mechanism; do not infer that the unused timeout setting supplies a lease. Native-reported scope and qualifications: Recovery triggers clear when originators disappear or remote records return. Bootstrap polling is 200 ms; live polling uses rerank_cadence_ms. This active age logic is distinct from the unused configured mesh_originator_timeout_ms expiry control."
}
```

## mgm:pidemo

Types: code.provisioner

First-boot UCI config sets eth0/br-lan to autoap, builds bat0 and br-mesh with IPGen mesh_l3, and supplies USB Ethernet hotplug and operator menu/status assets.

```json
{
  "account": "Config-only Raspberry Pi demonstration package establishing IBSS Wi-Fi through batman-adv with mesh addressing and local management.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The reported undeclared AutoAP runtime need is a package-composition mismatch, even if root rpi-4 builds supply it. Distinguish standalone package dependency closure from success of the enclosing image composition. Native-reported scope and qualifications: Source uses proto=autoap for LAN although the embedded README describes DHCP. Package Makefile does not declare autoap; root rpi-4 package verification includes it via the runtime package set. Target guard is bcm27xx. This discrepancy is recorded, not repaired. Fixed demo radio/BSSID settings are profile policy, not MGM-wide requirements."
}
```

## mgm:pool

Types: code.pool

Acquires responders through Fast Fill, refills depleted sets, and uses a last-good sentinel after failed acquisition batches.

```json
{
  "account": "Maintains proven DNS probe candidates, seeds and replacement resources per interface.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review. Native-reported scope and qualifications: Current target is 25 entries, capacity 32, refill below 7; Fast Fill batches four. These are tunables/limits, not proof of usable connectivity."
}
```

## mgm:project

Types: code.coordinator.gateway

Coordinates available gateways into usable upstream forwarding paths as local and peer connectivity changes.

```json
{
  "account": "The combined MGM package-set result: mesh nodes discover and share gateway availability, choose usable upstream routes, and adapt local forwarding as connectivity changes.",
  "assessment_status": "accepted with qualifications",
  "identity_test": "Without the combined discovery, connectivity interpretation, gateway choice and route application, the remaining provisioning and observation tools would no longer constitute a mesh gateway coordinator.",
  "notes": "Current main at the recorded revision contains five active packages. This pass reuses the supplied inspection evidence and verifies selected repository boundaries. No builds or live connectivity tests were run. Existing untracked .metaform/ and mesh-gateway-manager/core/sentry/src/CLAUDE.md are preserved; graph updates use the supplied actor intake transport.",
  "receivers": [
    {
      "ref": "mgm:users",
      "role": "Primary recipient of upstream forwarding."
    },
    {
      "ref": "mgm:operators",
      "role": "Recipient of operational gateway coordination."
    }
  ]
}
```

## mgm:prototype

Types: code.coordinator.gateway

Lets maintainers reconstruct prior approaches to gateway coordination from a preserved implementation.

```json
{
  "account": "Historical gateway-manager implementation retained for archaeology and excluded from active package inputs.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that archival code remains inside the repository but outside active runtime functionality. Its Type does not make it substitutable for the current coordinator. Native-reported scope and qualifications: External to current runtime functionality but inside this repository; not exterior. Archive README identifies upstream commit 0b15a7f39a7b7ecbc6a54842819a53b0e536789c from 2024-12-10. Its presence does not establish a supported runtime or compatibility contract."
}
```

## mgm:ranker

Types: code.ranker

Fits fastest/middle/slowest groups using k-means on eligible direct-provider observations and supplies rank to route metric policy.

```json
{
  "account": "Groups online direct gateway providers into throughput preference bands.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Mesh-path throughput grouping supplies comparative preference among eligible providers; it does not measure total Internet-path capacity or application quality. No hysteresis or churn bound is established by the functional description. Native-reported scope and qualifications: Forwarders are excluded from direct-provider fitting; topology throughput is not Sentry connectivity telemetry."
}
```

## mgm:reports

Types: document.report

Preserves observed command outcomes and source rationale that explain current behavior without making universal support claims.

```json
{
  "account": "Change reports and retained event-flow artifacts record earlier fixes and their specific validation circumstances.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Keep historical evidence bounded to its reported run and scope. The Latent review has not repeated any of those executions. Native-reported scope and qualifications: Historical evidence proves only the reported run, date, profile and scope. It does not replace current executable authority or establish that this intake reran validation."
}
```

## mgm:routes

Types: code.manager.route

Aligns and packs class metrics, ejects/deletes obsolete routes, retries peer routes with on-link handling when necessary, and refreshes advertised primary state after alignment.

```json
{
  "account": "Owns applying MGM route decisions to current IPv4 kernel routes.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree with exclusive MGM route-action ownership and the IPv4/main-table scope. Separate intended selection, accepted kernel operation, observed installed route and successful traffic. Reconciliation after interruption and coexistence with netifd-owned routes require an explicit ownership contract. Native-reported scope and qualifications: Active route boundary is IPv4 gateways/main routing table while discovery transport is IPv6. Kernel netlink notifications return observed changes to MGM; Sentry does not install MGM routes."
}
```

## mgm:routeverify

Types: code.tester

Builds a focused route verifier and checks real kernel route operations in isolated test namespaces.

```json
{
  "account": "Source-only C/shell validation of route-library behavior against Linux network namespaces.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Real-kernel route checks validate a narrower boundary than mesh client forwarding and NAT. Retain this useful layer and join it to broader acceptance rather than treating it as end-to-end proof. Native-reported scope and qualifications: make route-verify requires iproute2 and CAP_NET_ADMIN. It is not installed by package Makefiles and was not run during intake."
}
```

## mgm:rto

Types: code.estimator

First accepted replies update the estimator; rounds and correction windows distinguish delayed replies from sustained loss.

```json
{
  "account": "Derives probe deadlines from accepted response timing.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:securitylimit

Types: data.constraint

Constrains interpretation of received state: current peer acceptance must not be treated as enforced signature authentication.

```json
{
  "account": "Authentication-related code exists, but current configuration loading forces MGM_MODE_DEBUG.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The known absence of enforced peer authentication limits trust in peer-controlled route and name inputs. This property must remain visible through state consumption to the defining result; it does not imply that unrelated OpenWrt management access is unauthenticated. Native-reported scope and qualifications: Security configuration/signing/TOFU surfaces are not evidence of authenticated deployment."
}
```

## mgm:sentry

Types: code.tester.connectivity

Observes interface eligibility, probes resolver responders, and runs OFFLINE/FAST_FILL/TESTING/ONLINE transitions with adaptive timing.

```json
{
  "account": "The maintained tester inside mgmd that determines reachability on eligible non-mesh interfaces.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that this is an embedded connectivity tester, not a route installer or throughput ranker. Its accepted replies are interface/path/destination/time-scoped evidence. ONLINE and TESTING being treated as connected is an explicit availability policy, not proof of equal confidence. Native-reported scope and qualifications: Not a separate daemon or package. Does not probe mesh interfaces, own MGM routes, or supply mesh throughput ranking. Startup may use compiled seeds without successful DNS benchmarking. Telemetry never drives the scheduling loop."
}
```

## mgm:sentryconfig

Types: data.configuration

Sentry consumes effective settings and target lists for its probe behavior.

```json
{
  "account": "Installed /etc/config/sentry and DNS list supply current tester controls and responder input.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Responder lists and tester settings need to be interpreted with the same path-scoped evidence and eligibility contract as the engine. Configured capacity or cadence alone does not prove responsiveness or coverage."
}
```

## mgm:sentryhandoff

Types: code.adapter

sentry_ubus_init receives mgm_apply_sentry_state; callbacks update MGM route/local connectivity state before sentry.link publication; sentry ubus also exposes status, stats, history, stream, DNS benchmark and apply controls.

```json
{
  "account": "Embedded adapter directly applies Sentry transitions to MGM, then publishes exterior telemetry.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Preserve direct in-process application before telemetry. The same-process callback is authoritative. A remaining event subscriber motivates an idempotence contract for repeated observations; duplicate harmful actions are not established. Native-reported scope and qualifications: MGM treats ONLINE and TESTING as connected. MGM resolves lost gateway identity and owns route actions. A sentry.link subscriber remains, but same-process ubus event delivery is not the authoritative embedded handoff."
}
```

## mgm:sentrynet

Types: code.observer

Kernel interface/route observations enable or withdraw tester eligibility while excluding batman and mesh-bound interfaces.

```json
{
  "account": "Tracks carrier, IPv4 addressing and default gateways for direct-uplink testing.",
  "assessment_status": "accepted within supplied scope",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Accept the described function and receiver relationships, subject to the stated Native limits and the cross-component requirements added by this review."
}
```

## mgm:service

Types: code.provisioner

procd starts and respawns mgmd; startup ensures dnsmasq addnhosts; interface-up hotplug requests multicast_bind for the configured mesh; restart marker preserves firewall continuity.

```json
{
  "account": "Installed init/hotplug assets connect daemon lifetime and multicast rebinding to OpenWrt.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Supervisor lifecycle and restart continuity are scoped to the installed deployment. Persistence of firewall artifacts must be interpreted separately for restart, intentional shutdown and package removal; the graph does not define all those lifecycle outcomes."
}
```

## mgm:shell

Types: code.shell

OpenWrt shell interprets command procedures to configure and interact with runtime facilities.

```json
{
  "account": "Shell execution used by provisioning, service lifecycle, and CLI integration assets.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Scope this encounter to the named shell procedures; invoking a C binary does not make that binary shell code. The property contributes to the composite through those procedures."
}
```

## mgm:specs

Types: document.specification

Explains intended functional boundaries and directs readers to executable sources for implementation details.

```json
{
  "account": "Canonical design explanations for ownership, state exchange, route policy and direct-uplink testing.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Preserve existing architectural intent, but add receiver-level acceptance contracts that cross component boundaries. The proposed contracts in this review are not claims that current docs already contain them. Native-reported scope and qualifications: Map records source differences: direct embedded Sentry callback, one-second absent-witness coalescing, equal-token processing, active originator loss/recovery algorithm, and disabled authentication gating. docs/connectivity_monitor_led_ui_spec.md is a design/specification artifact, not proof that every described UI exists."
}
```

## mgm:state

Types: data.state

Provides the shared node record consumed by advertisement, routing and status.

```json
{
  "account": "mgm_node_state_t represents active/online/direct state, identity, alert token, topology hints, and primary route information; remote entries carry locally stamped liveness metadata.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree that sender equality inputs are not global time and receiver last_seen is not wire truth. Distinguish current local authority, peer-reported claims, and receiver observations. One transmitted primary route limits remote knowledge even when local storage can hold more. Native-reported scope and qualifications: Remote cache key is orig_address. last_seen_ms belongs to the receiver and is not wire state. C primary_routes capacity is four, while the current wire codec carries entries[0] only. alert_mono_ns is a sender-owned equality input, not a globally ordered time."
}
```

## mgm:store

Types: code.store

Updates local state separately from remote upserts and supplies snapshots to consumers.

```json
{
  "account": "Maintains authoritative local state and observed remote records keyed by originator.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. Agree with local authority versus attributed remote cache. Missing from the functional account is the validity rule when peer MGM stops advertising while its batman originator remains reachable; record existence alone must not imply current gateway authority."
}
```

## mgm:users

Types: exterior.group.user

Send traffic through mesh nodes and the upstream gateways selected there.

```json
{
  "account": "People and workloads whose traffic needs an available path from the mesh to upstream networks.",
  "assessment_status": "accepted with qualifications",
  "notes": "Latent assessment based exclusively on the supplied Native functional account; no implementation inspected. The receiving purpose must distinguish restored access for new traffic from continuity of existing sessions. No service availability target, destination coverage, or session-preservation promise is established by the supplied graph. Native-reported scope and qualifications: Receiving purpose inferred from gateway routing behavior; the repository does not identify a narrower customer population."
}
```
