# Implementation-ready GUI realignment

## Target experience

A user opens one model and sees its artifact identity, Defining Element, principal receiving purposes, and a persistent namespace browser. Selecting an actual opens its direct neighborhood and a readable inspector. Selecting a Type explains its universal EF, position, actual members, and applicable knowledge. A layer is visibly additional knowledge. Every inherited or implied item can explain its origin and path. Going deeper preserves a route back to the prior region and revision.

Retain Flask, the current vanilla JavaScript modules, Cytoscape/Dagre, vendored assets, palette, and authored SVG handling. The primary architectural change is a common semantic read service plus explicit UI state, not a new frontend framework.

## Shell and screen regions

**Desktop:** keep the existing global workbench navigation, reduced from 205px to approximately 160px. Use the main region for a 56px title/project bar, a compact model/revision/breadcrumb row, and a viewport-height exploration workspace. Avoid repeating the full project path in both a context strip and footer during normal exploration; expose it from the project details control.

The exploration workspace uses a namespace panel of 200–240px, a flexible canvas with at least 400px available width, and a 320–360px inspector, separated by 12px gaps. Suggested CSS is `grid-template-columns: minmax(200px,240px) minmax(400px,1fr) minmax(320px,360px)`. Let users resize the two semantic panels within those useful ranges; persist the layout locally, not as project semantics.

At widths below 1280px, compact the global navigation before shrinking semantic text. Below 1080px, turn the inspector into a right-side drawer while preserving the namespace and canvas. Below 760px, the namespace is a drawer and the inspector a full-height or bottom-sheet detail surface. The graph/list choice remains visible. Drawers preserve the selected target, scroll position, and return focus to the initiating control.

The canvas occupies the remaining viewport height with a useful minimum around 420px. On narrow screens use the remaining dynamic viewport height rather than stacking the full desktop inspector below it. Resize recenters the selected focal region; it must not preserve a desktop pan offset that leaves the selected node offscreen.

## Visual language and typography

Keep current background `#101719`, panel `#172123`, secondary panel `#1d2b2c`, line `#304143`, text `#e8eeea`, muted `#9aaca9`, mint `#a5dec7`, copper `#e4ad81`, and purple `#b7acf1` where they remain readable. Reuse existing root/role colors, but accompany semantic distinctions with text and shape. Color alone must not be the only indication of source, role, or selection.

Use 14px base interface text with approximately 1.5 line height; 12px metadata; 16px section headings; 22–24px model title. IDs use the existing monospace style at 12px and wrap in the inspector. Long prose uses normal text rather than JSON in a textarea. Use a consistent 4/8/12/16/24px spacing scale: 12–16px panel padding, 8px between closely related fields, 16px between semantic sections.

Selected rows/cards have a 2px mint outline and a restrained filled background. Keyboard focus has an independently visible outline. Hover adds a border/background change without changing selection. Preserve disabled-control styling for actual unavailable actions; do not use faded text to represent semantically uncertain knowledge without a readable label.

## Namespace browser

Add `static/namespace-browser.js` and a left workspace region. The initial tree shows the meaningful roots present in the model, not every descendant. Each row has an expand control, derived Type name, compact namespace address on demand, and member counts. Show direct and descendant actual counts distinctly; counts are unique actuals, not duplicate bindings summed across branches.

Expanding loads direct children through `namespace.browse`. Function/Encounter filters operate on narrowing relationships at the current branch. They do not create new roots or permanently relabel a Type. Search returns grouped results for Types, actuals, joins, and layers; each result includes its kind, canonical address, and local context. Choosing a result reveals its ancestors and preserves the previous navigation state.

Use the WAI tree pattern for keyboard expansion and movement, keeping focus distinct from selection. Provide a regular list alternative where appropriate. The actual implementation should use `aria-expanded`, level/position metadata for virtualized rows, and a visible focus indicator. [R05](20-research-and-decisions.md#r05)

Affected files: `templates/index.html`, `workbench.css`, new `namespace-browser.js`, and the shared target/read endpoints. Remove renderer-created namespace placeholders from semantic counts; display an unresolved prefix distinctly when imported data lacks its definition.

## Canvas and node cards

Keep the current single-click actual navigation: clicking a different actual opens its one-hop neighborhood; clicking the focused actual inspects it. Clicking an edge inspects that join without changing graph focus. A Type row/card can inspect its Type; a separate Browse action opens that Type region. Back restores target, filters, pan/zoom, and panel state. DE remains a fixed return control.

Replace 250×148-plus-prose card bodies with compact cards, generally 180–220px wide. Show the actual name in at most two visual lines, a Type label or count of additional Types, and an optional short EF/summary line. Keep full content in the inspector and accessible label. Render Type artwork around 24–32px, preserving the original artwork rather than asking intake to redraw it. Retain useful exterior shapes and add an explicit Actual/Type/Join label so semantic kind is not inferred from root color alone.

Default to a directed provider-to-receiver layout for a local OP neighborhood. Reified multi-participant joins use explicit join nodes; ordinary binary OP joins remain edges. Preserve parallel purposes. Do not merge different joins merely because endpoints match. Edge labels are concise in the canvas and fully available on hover/focus/selection; the inspector presents the complete purpose and signal.

Do not automatically shrink the neighborhood below a readable scale. Center the focal node and permit panning; indicate offscreen neighbors and provide the complete adjacency list. An explicit Fit all action may show an overview at smaller scale. For high-degree targets, request paged neighbors, display the returned/total counts and continuation, and allow the user to broaden the display. These are presentation/read bounds, not restrictions on the stored Metaform.

Affected files: `cytoscape-view.js`, `structure.js`, `workbench.js`, styles, and server-side neighborhood reads. Preserve existing position retention for unchanged topology, pointer navigation, SVG normalization, and reduced-motion behavior.

## Inspector hierarchy

Replace the parallel bottom detail panel and edit-first inspector with one selected-record inspector. Its sticky header shows name, kind, canonical reference, model/revision, and Copy target. The main sections are Overview, Connections, Knowledge, and Sources. Use tabs or clearly grouped progressive sections; do not require all sections to be loaded at once.

**Actual overview:** functional summary, relevant boundary, Type bindings and their contextual realizations, and the role of this actual in the artifact. The selected Type EF is visible without opening raw JSON. An Edit action reveals the existing revision editor; ordinary inspection stays read-only.

**Connections:** group into “Receives from” and “Provides to,” then show the join role and receiver purpose. A dependency claim is shown only for the relevant directed hard-dependency meeting. Supportive relations are labelled as support, not indiscriminate dependents. Each row opens join inspection and can navigate to the other actual.

**Type overview:** universal description and single EF, derived name/length, direct parent and Function/Encounter narrowing reason, direct/descendant members, known Type-level receiver-purpose clauses, actual witnesses, Parametric names, and attached Type knowledge. Actual-specific descriptions do not overwrite the Type's universal account.

**Knowledge:** list applicable items with separate origin and applicability-path labels. “Layer: … · via Type …” is valid and more informative than choosing one of those labels. Show freshness and target scope; open an explanation drawer for details.

**Sources:** source evidence, reused-input lineage, generating activity, prompt/rule/schema snapshots, and historical observations. Keep raw JSON and local source paths in advanced disclosure. Run-level coverage appears once on the activity, not repeated as the Element's EF.

Affected files: `workbench.js` inspection functions, new `inspector.js`, template inspector markup, and `read_model.py` projections. Remove `#type-detail` as a duplicate information destination after its unique source-separated content has moved into the inspector.

## Join inspection

Show a join as a complete semantic sentence: receiver, operative purpose, provider, provider Type/EF, and role. Then show signal, additional participants, and join logic when present. Each participant is an addressable link. The direction displayed matches provider → receiver. The join's stable ID and provenance are available without pretending the edge itself is the receiving entity.

“Connection to Defining Element” is a separate action. Generic paths are labelled connection paths, with direction and role at every step. A dependency path requires the matching dependency semantics. Opening a path highlights that selected explanation temporarily; closing it returns to the previous one-hop scene instead of growing the exploration graph permanently.

## Layers and comparison

Replace ordinary Native/Latent/Inference perspective switching with a single Foundation view and a Layers panel. Layers shows named knowledge collections, target region, schema, generating request, generation state, freshness, and coverage. Selecting a layer filters visible attachments, not the foundation's identity. Create/regenerate/remove actions invoke the same layer operations as CLI/MCP.

Move the existing source comparison into History/Compare. It can compare old Native/Latent snapshots or foundation revisions/variants explicitly. Keep structural correspondence separate from quality or confidence. The old `layer` storage bucket filter becomes Record kind under advanced inspection, not the new layer selector.

Keep existing prompt/rule editors, workflow tools, and file-history views. Clarify that file versions and semantic variants are distinct. Advanced backend and Cypher operations move out of the main graph toolbar into storage/analysis settings; retain their functionality rather than deleting useful developer features.

## State, loading, empty results, and errors

Use one state object for model/revision, namespace region, graph focus, selected record, selected inspector section, layer filters, search, history, and viewport. Encode shareable semantic state in the URL: project/model/revision/target plus relevant view filters. Pan/zoom and panel widths can remain local. A reload resolves the same semantic target, including aliases and relocation traces.

For a pending read, keep the previous region visible with a small loading indicator; do not clear the whole workspace and lose context. Ignore a late response for a previously selected target. Empty states distinguish an empty model, a branch without direct members, a filter with no matches, an unresolved reference, and a failed request. Each states the actual condition and preserves access to the parent or prior view.

Selecting background clears both highlight and inspector selection consistently, while preserving graph focus. Searching, changing layers, and moving between graph/list views preserve target identity where it remains in scope. When a target is no longer in the selected revision, show its historical reference and relocation/removal information instead of silently selecting another node.

## Completion evidence

Exercise the MGM DE, Types, DNS neighborhood, a multi-Type actual, a reified join, a layer attachment inherited through a Type, a stale attachment after a variant edit, a namespace relocation, and a high-degree target. Verify that each interaction answers the intended user question and that GUI/CLI/MCP resolve the same target and semantic records. Use viewport screenshots and DOM/keyboard checks at desktop and narrow widths. Do not accept a more attractive screenshot as proof that the new data model is correctly represented.
