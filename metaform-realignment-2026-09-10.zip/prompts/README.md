# Prompt package

`platform/platform-expert.md` is for agents building or troubleshooting Metaform. It retains the user's complete supplied foundation. `runtime/` contains task-specific replacement prompts. `components/` contains only the semantics those runtime roles need; `composition.json` identifies the component/input/output contract for each role.

These are complete task texts plus explicitly selected input components, not prompts that depend on the runtime agent reading this archive. The implementation composes the selected text, resolves schema references through the registry, and supplies the named input data. Record the source prompt, component texts/revisions and rendered assignment as provenance.

`components/aliases.md` is copied verbatim from the reviewed repository's bundled Aliases source. Namespace author's three naming paragraphs preserve the accepted concise Name rule. Its Description sentence is a grammatical repair of the maintained concise Description rule: ancestral proper nouns, reverse namespace order, universal Type meaning and exclusion of child definitions are retained. This wording change is declared here rather than hidden in a prompt migration.

The complete glossary is not automatically included. A role may retrieve a relevant reference definition when the task needs it. Ordinary outside analysis receives the coarse account and attachment semantics, not a Type-authoring tutorial or the graph-construction output schema.

Runtime contributions are deliberately distinct from finalized storage envelopes. The service assigns the model/revision and producing activity, aggregates incremental structural contributions into the foundation, and decorates knowledge contributions with ownership, generation and automatically captured context dependencies. The model is not asked to fabricate timestamps, hashes or missing execution metadata.

The prompt texts have been reviewed for their intended mechanisms and included in package validation. They have not been independently run through a live model in this review. The implementation plan supplies the matched comparison and task demonstration that must establish their practical quality.
