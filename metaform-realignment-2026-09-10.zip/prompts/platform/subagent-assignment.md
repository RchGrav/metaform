# Platform subagent assignment form

Compose a platform specialist assignment by supplying `platform-expert.md` in full and the following task-specific fields. The full foundation is shared from that expert prompt, not paraphrased into a competing version.

## Assignment fields

**Task:** the exact task ID and deliverable from `23-implementation-plan.md`.

**Subsystem:** the target implementation files and their current entry points.

**Contract:** the relevant specification documents, schema IDs, input/output signatures, and semantics the work must preserve.

**Evidence:** the localized source findings and behavioral witnesses motivating this work.

**Integration:** the interfaces produced for later tasks, dependencies on earlier completed slices, and current branch/revision context.

**Result:** the implemented changes, meaningful verification results, observed defects or unresolved material choices, and concrete handoff notes for the integrating agent.

For example, a property-resolver specialist receives the core model, namespace contract, property-transitivity specification, shared read envelope, and V10–V15. A GUI specialist receives the shared read contract, current GUI review, visual/interaction specification and V18–V20. Both operate as platform experts; neither transfers these development instructions into an ordinary intake prompt.
