# Current web GUI: direct review

## What was exercised

The current packaged JavaScript/Cytoscape application was rendered with the archived MGM graphs through the unmodified Flask test-client endpoints. At 1600×1000, opening the project focused `mgm:project`; the Types control opened its current namespace projection; opening `mgm:dnsresponders` replaced the graph with three actuals and three joins. The same selected view was resized to 390×844. There were no page-script errors in the completed examination. The in-process transport and browser restriction are documented in [01](01-review-basis.md). [S06](evidence/source-index.md#s06)

## Retain the current visual direction

The charcoal/green surfaces, mint accent, restrained borders, grouped controls, source glyphs, project selector, and clear DE/Types/Back controls form a useful baseline. The recent shift to a directed graph renderer and non-accumulating neighborhood exploration is a concrete improvement. Keep the stack and visual language; solve the semantic hierarchy and density problems rather than replacing the application for novelty.

## Findings tied to user tasks

| ID | Observed current behavior | User task impeded | Required disposition |
| --- | --- | --- | --- |
| UI01 | Initial DE neighborhood shows 17 actuals/28 joins at 36% fit | Understand the unfamiliar artifact without immediately zooming and searching for readable labels | Retain DE focus; use compact cards, readable initial scale, explicit offscreen/neighbor access |
| UI02 | Types opens 36 visible records at 12% fit, with no persistent tree | Browse the narrowing namespace and know the current location | Replace the all-branches canvas entry with a persistent progressive namespace browser |
| UI03 | Three-node DNS neighborhood is useful, but cards include flattened assessment fields and long descriptions | Identify the selected capability and compare its neighbors | Preserve one-hop replacement; show name, Type and short functional summary, move prose to inspector |
| UI04 | The first inspector section is a path to the DE, followed by all joins; actual fields occur much later | Answer “what is this?” before studying every connection | Put identity, EF/Type, boundary, and summary first; move path tracing into an explicit action |
| UI05 | The bottom detail panel repeats actual and Type material already available in the inspector | Explore without parallel scrolling and repeated context | Consolidate into one selected-record inspector with progressive sections |
| UI06 | Native and Latent joins both appear in ordinary Inference view, including near-duplicate purposes | Understand why a join exists and distinguish structure from review | Show one foundation; move outside results into Layers; keep source comparison in an explicit history/compare mode |
| UI07 | Proposed `mgm:latent:trust` and `mgm:latent:serviceacceptance` appear as actual neighbors of the DE | Distinguish current artifact structure from suggested work | Rework underlying data projection, not only node colors |
| UI08 | “Every layer” selects store record buckets such as `elements` | Find named additional knowledge and understand its origin | Add true Layers; rename the old filter to Record kind in advanced views |
| UI09 | Breadcrumb area shows only the current label; Back records visits, not namespace ancestry | Know where a Type lives and return to a meaningful parent | Keep history Back; add canonical namespace breadcrumbs and parent navigation |
| UI10 | “Relation to the Defining Element” uses an undirected shortest connection | Understand dependencies versus a merely recorded connection | Label generic paths accurately and show direction/role at each step; use directed semantics for dependency claims |
| UI11 | Network response loads 1,073,063 bytes before local display narrowing; similarity is built for ordinary requests | Explore large models without paying full-model cost for every load | Add server-side bounded semantic reads and separate comparison calculation |
| UI12 | Backend switching and Ladybug query console are present in the ordinary exploration surface | Focus on project meaning rather than storage implementation | Move storage controls to advanced/settings; show query console only in its relevant context |
| UI13 | At 390×844, the document is 4,052px tall; resizing preserves 87% zoom/pan, leaving the focused graph mostly offscreen | Inspect on a narrow screen and retain selection context | Use responsive drawers and recenter the selected focal region on resize |
| UI14 | Inspector is an edit form with Save revision mixed into routine browsing | Read meaning without interpreting fields as a required editing workflow | Default to read-only semantic sections; expose a separate Edit action using the same saved-revision machinery |

Measurements are fixture-specific, not performance guarantees. Source locations: `viewer.py`, `structure.js`, `cytoscape-view.js`, `workbench.js`, `workbench.css`, and `templates/index.html`. [S06](evidence/source-index.md#s06)

## Selection and navigation details

The actual-node click behavior correctly replaces the neighborhood rather than extending an ever-growing path. The renderer also preserves positions when topology is unchanged. Keep both. The renderer's background handler clears visual highlighting but does not invoke the inspector's selection callback; source inspection therefore identifies a potential stale-inspector state. Exercise this behavior when implementing the shared selection model rather than claiming it was separately pointer-tested in this review.

Type membership is already accessible in the inspector without invented OP edges. Preserve that distinction. Provide separate “Inspect Type” and “Browse Type” interactions so a human can read its universal meaning without unexpectedly losing the actual's local graph.

The current keyboard controls and reduced-motion handling are useful. The graph still needs an accessible equivalent through the namespace tree and relationship list. Keyboard focus, selected record, graph focus, and current namespace region should be separate state fields rather than accidental consequences of which DOM element last received input.

## Data versus display responsibility

The repeated latent qualifications under “Native · actual project detail” are present in the Native sample itself. Do not attribute that entire issue to a viewer source-selection bug. The GUI does need clearer origins and less flattening, but the provenance/model repair belongs underneath it.

Likewise, small nodes are not solved only by a larger font. Current auto-fit, all-branch Type entry, long card bodies, duplicated source joins, and a persistent second detail panel combine to reduce usable space. The implementation specification addresses the whole workflow, not isolated decorative tweaks.
