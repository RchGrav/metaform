# Current implementation and architectural diagnosis

## Main finding

Metaform already has a useful chassis and a materially improved artifact-level representation. Its principal remaining conflict is not the absence of a graph database or a graph renderer. It is that the runtime still publishes an outside review as a second structural graph, while the requested product needs **one artifact-shaped foundation, reusable Type understanding, and separately owned knowledge that can be regenerated**.

The second conflict is that namespace browsing, ordinary adjacency, classification, property applicability, and provenance are not yet exposed as distinct semantic operations. The code can retrieve related records, but that is not equivalent to explaining why a property applies. The GUI inherits these distinctions incompletely. [S03](evidence/source-index.md#s03), [S07](evidence/source-index.md#s07), [S08](evidence/source-index.md#s08)

## Existing flow

`Intake.start()` creates a Native assignment. Native can read the project and incrementally submit actual Elements, universal Type records, OP joins, and a freeform `understanding`. Actuals have stable project identities and `type_ids`; Types retain namespace identities, universal descriptions, and an EF. Native completion automatically advances to one fresh `archaeology` assignment. That assignment receives the full Native snapshot and applicable referenced records, not repository read tools. Its answers are stored as graph records. Completion replaces its scope and constructs a merged comparison. `intake.examine` runs the same outside examination against saved Native understanding. [S03](evidence/source-index.md#s03)

This is much better than the preceding Native → Type proofreader → recursively enqueued per-Type Latent pipeline. It nevertheless makes a complete second graph part of normal intake completion. The outside prompt still asks for Latent Elements and joins, including missing actuals. The target repair is to change that output and transition, not to restore the discarded per-Type pipeline. [S04](evidence/source-index.md#s04)

## What each subsystem currently provides

| Subsystem | Existing capability | Realignment needed |
| --- | --- | --- |
| Runtime chassis | Manifest-driven commands, shared CLI/MCP registry, dynamic command disabling, module takeover, continuation and receipts | Retain. Register semantic read/layer/expansion operations without replacing the dispatch model |
| Knowledge service | Owner-qualified records, project/global partitions, shared installed service, portable JSON, analysis copies | Retain ownership and portability. Add foundation/layer revision metadata and common semantic reads |
| Graph storage | Elements, attributed observations, reified joins and role-bearing participants, joins referencing joins | Retain. Distinguish structural relations, Type bindings, layers, and historical source observations in projections |
| Intake | Whole-artifact account, actual identity, Type references, receiver-owned OP joins | Make coarse first; finish the foundation independently of optional blind-spot work |
| Prompt infrastructure | Editable prompt records, source text, revisions, selected rule snapshots, workflow conversion and specialization | Extend into complete generation recipes and dependency-aware reinference; retire dead proof seeding and perpetual digest-based upgrade maintenance |
| Assembly | Focal retrieval, adjacency traversal, Type members and referenced Type definitions, owner resolution | Separate exact inspection, branch membership, bounded traversal, property applicability, and task grounding |
| Comparison | Native/Latent structural correspondence and source links | Keep as historical/variant comparison, not as the ordinary meaning of a Metaform |
| GUI | Local neighborhoods, Type browsing, DE navigation, source-separated details, readable controls, authored artwork | Preserve renderer/navigation direction; add persistent namespace context, compact semantic cards, layer and explanation views |
| CLI/MCP | Same command registry and structured results; modern-protocol router and answer-loop fallback | Add one semantic query contract and explicit model/revision targets rather than exposing whole storage exports as default grounding |
| Variants | Useful design documents, project copying and file-history machinery | Implement semantic graph variants and layer impact/reinference; do not mislabel existing file checkpoints as this capability |

Sources: [S03](evidence/source-index.md#s03), [S07](evidence/source-index.md#s07), [S08](evidence/source-index.md#s08), [S09](evidence/source-index.md#s09), [S10](evidence/source-index.md#s10), [S11](evidence/source-index.md#s11).

## Specific architectural defects

**F01 — Review-as-structure.** The outside pass retains and revises the entire account and creates proposed contracts as actual artifact Elements. The sample contains 14 new `mgm:latent:*` actuals. Useful analysis is present, but a proposed requirement is not automatically an existing artifact component. Publish findings as a layer and let a structural correction be an explicit graph change. [04](04-sample-intake.md)

**F02 — Transport provenance is mistaken for semantic provenance.** Every one of the 58 actual Native records in the archived sample already contains latent-perspective provenance. A Native storage scope cannot be treated as proof of independent source observation. Keep recorded source, generating activity, reused input, and interpretation status separately. The exact path by which the sample acquired this content remains unknown. [04](04-sample-intake.md)

**F03 — Structural schemas underdescribe the model.** The actual schema does not require an EF or classification; the Type schema does not require its single EF; the graph's join array references the generic join rather than the OP-specific schema. Neither a generic `type` string nor a `type_ids` array identifies which Type EF a particular actual OP join is receiving. New schemas must express the distinction without turning schema validity into a semantic correctness verdict. [S12](evidence/source-index.md#s12), [07](07-schema-and-storage.md)

**F04 — Transitivity has a semantic contract but no corresponding explanation surface.** The specification correctly distinguishes backward visibility and forward branch effect. Current assembly is generic incident-edge traversal plus classification lookup. It does not return the applicability proof requested by the user. Implement `knowledge.explain`, not a broader untyped BFS. [S13](evidence/source-index.md#s13), [10](10-property-transitivity.md)

**F05 — A Type rename can strand classifications.** The localized probe renamed `code.engine` to `code.coordinator`; the actual's `type_ids` still contained `code.engine`. `renamed_elements` deliberately avoids rewriting authored payloads, including these structured references. Repair reference-aware transformation while preserving authored prose. [S07](evidence/source-index.md#s07), [evidence](evidence/measurements.json)

**F06 — Bounded display is not bounded retrieval.** The sample's initial network response was 1,073,063 bytes before browser selection reduced it to a neighborhood. The endpoint constructs similarity even when the user is not in the similarity view. Type member selection also differs between graph assembly and the browser's direct-membership view. A common read model should select the semantic region before serialization. [S06](evidence/source-index.md#s06), [S08](evidence/source-index.md#s08)

**F07 — Porting provenance is insufficient.** Prompt snapshots and source observations are useful ingredients, but the current representation lacks a general layer definition, generation recipe, resolved dependency set, selector dependency, and per-target replacement/reinference record. The variant feature briefs recognize the need but do not implement it. [S09](evidence/source-index.md#s09), [S11](evidence/source-index.md#s11)

**F08 — Installed verification still encodes a removed intake contract.** The installed check fails on `inputs.id`. Update its behavioral expectation, not the improved intake back into the old shape. This is a concrete delivery defect separate from the semantic realignment. [S05](evidence/source-index.md#s05)

## Structure to retain

Keep Flask, the current JavaScript/Cytoscape stack, the command manifests, owner-qualified knowledge, portable JSON, editable prompts, reified relations, and existing continuation machinery. None needs replacement by a new frontend framework, RDF platform, vector database, or second orchestration engine to deliver this plan. New semantic modules should sit behind the existing surfaces and storage adapters. Each migration should preserve original source observations and independently owned work.
