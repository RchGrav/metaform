# Behavioral and semantic verification cases

## What has already been verified

The reviewed baseline passed 546 Python tests and 22 JavaScript model/renderer tests in this review's isolated environment. The installed-distribution smoke check reproduced `KeyError: 'id'`. Current GUI rendering and selected navigation were exercised through the in-process Flask transport; original browser suites were not independently rerun in their original harness. Sample counts/hashes and the Type-rename witness were measured. See [evidence](evidence/verification.md).

The target architecture and runtime prompts below are not implemented or live-model-tested by this archive. The cases specify meaningful outcomes for the implementation agent. Do not present a package-schema check as evidence these platform behaviors already pass.

## Structural semantics

**V01 — Receiver-purpose conjunction.** Use one provider Type with two receivers and two different purposes. Inspect the Type clauses and actual OP joins. Each purpose remains paired with its own receiver and the same Type EF; no cross-product or flattened arrays appear. Add a multi-Type actual and verify each OP names the facet whose EF it receives.

**V02 — Actual versus Type.** Two actual adapters share a Type. Their descriptions, evidence and purposes remain distinct; the Type's universal definition is stored once in the model projection. No membership OP is generated. Inspecting one actual retrieves its Type but does not include every same-Type actual as an ordinary neighbor.

**V03 — Namespace meanings.** Use a Driver branch with Video Driver and Network Driver. Network Driver resolves to the shared Driver position with `length: 2`. Function/Encounter is shown on the parent-child relationship. Type inspection, direct members and descendant members are different reads with consistent counts across clients.

**V04 — Rename regression.** Relocate `code.engine` to a meaning-preserving target in a fixture with bindings, provider-Type joins, selectors and dependencies. All current structured references resolve; the old address resolves through recorded relocation; the source revision remains unchanged. Do not globally replace text in descriptions or original prompts.

## Intake and layers

**V05 — Intake completes independently.** Start v2 intake, save contributions incrementally, submit the final empty contribution, and inspect the completed model. Exactly one foundation is published; no automatic archaeology assignment appears. Repeated answer submission returns its existing receipt without duplicate records.

**V06 — Focused role composition.** Capture actual rendered assignments, not only template files. Native receives required structural/naming semantics and selected evidence. Blind-spot analysis receives its coarse account and report schema, not the full glossary, graph-construction schema or platform foundation. Managed/custom prompt provenance and issued v1 snapshots remain distinguishable.

**V07 — Outside report remains knowledge.** Run the outside role against the fixture. A proposed missing acceptance contract appears in its report layer and can target an existing join/region. Foundation record identities and structural hash do not change merely because the report is stored. A deliberately applied correction creates an explicit new structural revision.

**V08 — General layer creation.** Create two differently requested layers using different schemas, one for a software artifact and one for a non-code artifact. No best-practice-specific engine branch is needed. Type-level knowledge is reused through bindings, while local advice remains attached to its actual/join scope. Remove one layer and verify it is absent from current layers while the foundation and the other layer remain unchanged.

**V09 — Reinference provenance.** Inspect one generated attachment. Recover its exact original request, source prompt, rendered assignment, component/schema snapshots, resolved context and selector dependencies. Regenerate one subject partition and verify it does not overwrite unrelated or independently authored outputs.

## Transitivity and change impact

**V10 — Backward visibility is not sibling inheritance.** Attach Bash to an installer and C++ to an engine. Both are visible at the trunk with their origins. Bash does not apply to the engine through shared ancestry. A named refinement in the engine's applicable scope receives its engine property with a traceable path.

**V11 — Type and layer axes coexist.** Attach a layer recommendation to `code.cpp`, then inspect a C++ actual. The result says the knowledge originates in that layer and reaches the actual through its Type binding. It is not labelled native merely because the path uses typology.

**V12 — Join context and cycles.** A compatibility statement applies to one adapter/consumer meeting. A third node connected by an unrelated dependency does not inherit it automatically. A cyclic OP graph terminates traversal while retaining the recorded cycle. Canonical narrowing or alias cycles yield exact diagnostics.

**V13 — Selector dependency.** A layer targets all current members of a Type branch. Add a newly matching actual and remove another. The impact report includes new/missing subjects even though previously selected records have not all changed. A negative claim about absence of a relationship is reconsidered when the examined neighborhood gains that relationship.

**V14 — Port one branch.** Clone the source model and replace only the engine's language property/binding. Preserve the installer and source model. The impact report classifies affected advice for regeneration and unaffected advice for preservation. Reapply the same semantic request to destination Types/joins; destination advice is not a textual language-name substitution.

**V15 — Structural versus presentation change.** Change only a Type SVG and verify semantic dependencies do not all invalidate. Change the Type EF or a receiver's purpose and verify the relevant context fingerprints/knowledge are reconsidered. Changing a layer does not change the foundation's identity.

## Access and GUI

**V16 — Shared reads.** Resolve the same Type, actual and join through CLI, MCP and GUI handlers. Compare canonical model/target, returned record identities, direction, coverage and explanation paths. Test old and new supported MCP protocol paths, explicit model selection and the no-sampling host-answer loop.

**V17 — Bounded completeness.** Use a high-degree actual and a paginated Type branch. Returned counts and continuation describe exactly what is visible; required OP semantics are not truncated. Following all pages in the same revision recovers the same logical region as an explicit complete export. A later revision cannot silently mix into the page sequence.

**V18 — Readable local view.** Use the archived DNS neighborhood and parallel long-purpose joins. Default text is not covered by cards; selecting a relation reveals its complete purpose. A screenshot and pointer/keyboard observation establish this, not a JavaScript array equality test. Preserve authored SVG identity and one-hop replacement.

**V19 — Context-preserving navigation.** Browse namespace → Type → actual → join → knowledge explanation → Back. The correct namespace, target, selected section and prior viewport return. Background selection clearing updates inspector/highlight consistently. A late response for an old target does not replace the newly selected inspector.

**V20 — Responsive and accessible use.** Exercise 1600×1000, a narrower desktop and 390×844. Resizing keeps the focus visible; drawers preserve state and return keyboard focus. A user can select every relevant canvas record through lists and inspect relationships without pointer-only gestures. Long IDs and purposes wrap in details rather than hiding under fixed controls.

## Demonstration of actual usefulness

**V21 — Unfamiliar-artifact orientation.** Give a fresh task agent the coarse model and read tools, not an implementation tour. Ask it to explain the artifact's result, principal receivers, requirements, boundaries and one meaningful join. Compare its answer with the retained artifact evidence and note specific mistakes or gaps.

**V22 — Useful task output.** Ask the same agent to prepare a concrete refactoring/porting plan for one target. It should name actual affected Elements and relationships, preserve relevant receiver purposes, and use applicable knowledge with its provenance. Inspect whether the plan is actionable against the repository rather than a generic list of recommendations.

**V23 — Matched prompt comparison.** Compare the existing full-glossary intake assignment with the proposed focused composition using the same source evidence and available harness settings. Record semantic rubric findings, Type duplication, repeated source/context work, latency/tokens when available, and task outcomes. Do not judge solely by node count, prompt length or fluent wording. A single trial is a witness, not a population performance claim.

**V24 — End-to-end round trip.** Intake → namespace exploration → one property explanation → requested knowledge layer → destination variant → affected-layer reinference → task grounding. Retain the inputs/outputs and a screen/CLI/MCP walkthrough. This is the primary demonstrable product result, not a new universal gate on ordinary artifact intake.

## Verification discipline

Run localized tests for uncertain behavior and semantic regressions. Do not add tests that merely repeat implementation dictionaries or demand one exact generated sentence. Preserve meaningful existing tests; replace obsolete per-Type assignment expectations with the actual new lifecycle. Report observed outcomes and remaining uncertainty separately. Runtime quality annotations are not converted into mandatory approval or score thresholds.
