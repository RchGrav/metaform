# Metaform realignment implementation plan

**Goal:** make the improved artifact-shaped Metaform a demonstrably useful orientation and metaprompting surface, with focused intake, separate knowledge layers, explainable applicability, transformation reinference, and one GUI/CLI/MCP model.

**Architecture:** retain the current chassis, stores, workflows, editable prompts and renderer. Add explicit semantic records and a common read layer; migrate one structural foundation plus generated knowledge onto those existing mechanisms.

**Stack:** existing Python package, SQLite-backed shared knowledge service, portable JSON, existing optional Ladybug analysis copies, Flask, vanilla JavaScript, Cytoscape/Dagre, current CLI/MCP registry and harnesses.

**Specifications:** [05](05-core-model.md) through [21](21-migration.md). Meaningful witnesses are V01–V24 in [22](22-verification-cases.md). The executable package validator verifies this archive's schemas/examples/links only.

## Begin here

Read the root README and [00](00-review-clarifications.md), then the core model, recent-commit assessment and prompt-quality specification. Compare the current checkout with reviewed commit `ba6421e232532e4a52565c53320f61af2b4df0f9`; preserve newer useful work and local uncommitted changes. The user's local handoff can provide additional execution context, but this archive does not claim to have read it.

Keep work scoped to each deliverable. The text-obscuration repair can proceed independently of the structural data work. The schema, read-model and prompt-lifecycle slices should proceed before the GUI begins inventing another representation of the same concepts.

## Shared implementation interfaces

These signatures are target seams to implement over the existing service, not claims they already exist:

```python
# src/metaform/models.py — model/revision facade over existing knowledge storage
capture_model(app, model=None) -> dict
publish_foundation(app, snapshot: dict, base=None) -> dict
import_v1(app, snapshot: dict, source_context: dict) -> dict

# src/metaform/namespace.py
resolve_target(snapshot: dict, target) -> dict
browse_namespace(snapshot: dict, target=None, *, category=None, cursor=None, limit=50) -> dict

# src/metaform/read_model.py
read_model(app, operation: str, arguments: dict) -> dict

# src/metaform/properties.py
explain_applicability(snapshot: dict, subject: dict, origin: dict, layer_records: list) -> dict

# src/metaform/layers.py — jobs run through the existing workflow engine
create_layer(app, request: str, target=None, model=None) -> dict
publish_generation(app, run_id: str, contributions: dict) -> dict
regenerate_layer(app, layer: dict, model: dict, target=None) -> dict

# src/metaform/expansion.py
start_expansion(app, model: dict, target, purpose: str) -> dict

# src/metaform/transform.py
apply_transformation(app, patch: dict) -> dict
impact(app, source: dict, destination: dict, mapping: list) -> dict

# src/metaform/prompts.py
compose_role(app, role: str, inputs: dict) -> dict
```

`capture_model` returns the foundation interchange snapshot, including resolved Type definitions and retained source references. `publish_foundation` returns a resolved ModelRef and records a new revision without modifying layers. `import_v1` returns `{model, mapping, diagnostics}`. `resolve_target` returns `{ref, via, diagnostics}`. Public read handlers wrap results in the shared read envelope; generation methods return the existing run/assignment/receipt style.

## T01 — Repair concrete baseline delivery and text defects

**Files:** modify `tools/check_distribution.py`, `src/metaform/static/cytoscape-view.js`, `src/metaform/static/workbench.css`, and the existing browser fixtures/tests that exercise labels. Read `tests/test_native_latent_intake.py`, `tests/test_structure_browser.cjs`, and the current handoff verification record.

The installed smoke check still expects `job["inputs"]["id"] == "code"`, a removed per-Type assignment contract. Replace that expectation with the actual whole-artifact assignment/context and completion behavior being exercised. Do not reintroduce `inputs.id` into the improved runtime merely to satisfy the old smoke test.

Implement the localized label/card/overlay repair in [15a](15a-text-visibility-repair.md). Keep the current graph stack, glyph identity and neighborhood navigation. Separate long edge explanations from default canvas text, and measure card/label rectangles in the rendered fixture.

**Evidence:** rerun the installed-wheel smoke check and retain its full result. For GUI, save rendered DNS/parallel-label screenshots and a pointer/keyboard observation. Exercise V18 and preserve existing renderer/SVG tests. These two repairs are independent and can be separate commits.

## T02 — Introduce the semantic record facade and lossless v1 adapter

**Files:** create `src/metaform/models.py`; extend `src/metaform/knowledge.py`, `service.py`, `knowledge_export.py`, `schemas.py` and bundled schemas; use existing `graph.py`/`backends.py` transactions rather than replacing them. Add `tests/test_foundation_records.py` and `tests/test_foundation_migration.py`.

Register the versioned schema IDs from `schemas/`. Store model/revision membership, Type bindings, narrowing/refinement records and OP provider-Type references as explicit semantic records over the existing owner-qualified store. Keep Type and actual identities separate. Add rebuildable indexes for namespace children, bindings, incident joins and model revision membership.

Implement `capture_model`, `publish_foundation`, and `import_v1`. The v1 adapter keeps raw observations, normalizes `type_ids` into bindings, preserves OP direction/purpose/role/logic, and reports unresolved provider facets or narrowing meanings. Historical archaeology becomes an explicitly labelled outside-result snapshot/layer association, not new current actuals.

**Example behavioral assertion:**

```python
before = capture_model(app, source_ref)
report = import_v1(app, legacy_snapshot, {"source": "archived fixture"})
after = capture_model(app, report["model"])
assert set(after["elements"]) == expected_native_actual_ids
assert not any(j.get("purpose") == "Type membership" for j in after["joins"])
assert original_source_bytes == retained_source_bytes
```

Use V01, V02, V04 and the migration cases. A diagnostic on incomplete historical semantics is an expected observable result, not a reason to manufacture a passing Type facet.

## T03 — Shared namespace and bounded semantic reads

**Files:** create `src/metaform/namespace.py` and `read_model.py`; add thin manifest handlers under `src/metaform/modules/` for model, namespace, Type, Element, join, knowledge, layer and expansion reads; extend existing graph handlers for neighbors/traverse. Add matching `data/modules/*.json` entries. Extend `registry.py` to carry optional output schemas; update `mcp_server.py`, `portable_mcp.py`, `viewer.py` and CLI help as needed.

Implement all deterministic reads in [17](17-common-access-contract.md). Resolve canonical names/aliases with owner and revision. Separate exact Type inspection, direct members, descendant members, incident OP joins and bounded traversal. Return complete receiver-purpose-EF bundles and honest coverage/cursors. Record dependency descriptors for supplied records and selector results.

The existing active-module intake/workflow endpoints delegate to these same semantic helpers when they need reads. Preserve current module ownership and dynamic disabling rather than making every new operation unconditionally available.

For MCP, preserve the supported protocol adapters and host-answer loop. Use explicit model/run handles on the newer path; do not create a second per-connection semantic state. For CLI, use the existing manifest-driven named flags. For GUI, add a thin semantic endpoint that dispatches to `read_model`, not a separate traversal implementation.

**Example parity assertion:**

```python
args = {"model": model_ref, "target": "demo:engine"}
expected = read_model(app, "graph.neighbors", args)
assert cli_result["resolved_target"] == expected["resolved_target"]
assert mcp_result["records"] == expected["records"]
assert gui_result["coverage"] == expected["coverage"]
```

Add `tests/test_semantic_reads.py`, `test_namespace_targets.py`, and protocol/CLI parity cases. Exercise V02, V03, V16 and V17. Keep the old `graph.browse` contract explicit for legacy callers.

## T04 — Focused prompts and one-foundation intake completion

**Files:** modify `prompts.py`, `intake.py`, `modules/intake.py`, `data/modules/intake.json`, `data/semantics/native.md`, managed prompt metadata and semantic source manifest. Install runtime prompt/component texts and schemas from this archive. Update current rulebook naming/description material. Add `tests/test_role_prompt_composition.py` and revise intake lifecycle/continuation tests.

Implement `compose_role`: retain exact source task text, selected component snapshots, output schema and named inputs. Remove blanket glossary concatenation and current proof-role seeding. Preserve managed/custom provenance and already-issued old assignments.

Use the v2 intake-contribution schema for incremental answers. The runtime owns revision/activity metadata and publishes the combined foundation at completion. Native completion no longer emits an automatic archaeology assignment. Preserve current receipts, run locking and resumability. Keep v1 continuation under its recorded version rather than interpreting an old graph answer as a new report.

**Example lifecycle assertion:**

```python
job = start_v2_intake(app)
assert job["contract_version"] == "2"
save_fixture_contributions(app, job, coarse_fixture)
submit_final_contribution(app, job, {})
result = next_intake_result(app, job)
assert result["status"] == "complete"
assert result["model"]["revision"]
assert no_new_archaeology_assignment(app, job["run_id"])
```

The test helpers exercise the existing public intake transport; implement them in the new lifecycle test fixture rather than in production. Run V05 and V06, then retain actual rendered assignments for the later prompt comparison.

## T05 — Generic layers and the outside-in report vertical slice

**Files:** create `src/metaform/layers.py`, `modules/layer.py`, `modules/analysis.py` and manifests; extend schema/knowledge export as needed. Replace active archaeology task text with the report prompt and retain its v1 snapshot support. Add `tests/test_knowledge_layers.py`, `test_blindspot_layer.py` and generation-resume cases.

Implement layer definitions, recipes, generation records and attachments. Capture exact semantic requests, prompt/component/schema snapshots, context dependencies and selector results. Use existing Engine runs for design/generation assignments. Generate reusable Type knowledge once and local attachments where their subject/joins warrant them.

Implement `analysis.blindspots` and the v2 `intake.examine` compatibility route. Store the report as layer knowledge. Index its declared target subjects without copying the entire report into each actual. A projected per-finding view can reference the original report payload by locator.

Implement selected-layer regeneration and current-layer removal. Replacement affects the chosen generation/subject slots only. Preserve independently authored knowledge and other layers. A partial job retains receipts and completed results with visible generation state.

**Example isolation assertion:**

```python
foundation_before = capture_model(app, model_ref)
layer_result = finish_fixture_layer_job(app, request="Review blind spots", payload=report)
assert capture_model(app, model_ref) == foundation_before
assert layer_result["layer"]["id"] in current_layer_ids(app, model_ref)
assert proposed_contract_id not in foundation_before["elements"]
```

Exercise V07–V09 with software and non-code requests. This completes a useful intake → outside report slice before full transformation support.

## T06 — Applicability and explanation paths

**Files:** create `src/metaform/properties.py`; extend shared reads, layer applicability records and graph indexes. Add `tests/test_property_applicability.py`, `test_knowledge_explanations.py`.

Implement the origin-carrying resolver from [10](10-property-transitivity.md). Compute backward visibility separately from forward applicability. Treat Type inheritance, named actual refinement and join-context implications according to their own semantics. Return origin/layer/path as separate fields. Generic graph reachability is not a property rule.

Handle OP cycles with origin/current/scope visitation; preserve competing qualified results rather than selecting the latest arbitrarily. Memoize by model and relevant record/selector revisions, not by target spelling alone.

**Example semantic assertion:**

```python
engine = read_model(app, "knowledge.get", {"model": model_ref, "target": "demo:engine"})
trunk = read_model(app, "knowledge.get", {"model": model_ref, "target": "code"})
assert applies(engine, "code.cpp")
assert not applies(engine, "code.shell")
assert visible_from(trunk, "code.shell", "demo:installer")
assert explanation(engine, cpp_knowledge)["origin"] == cpp_origin
```

Helpers inspect the returned envelope; they do not encode a new language rule into the resolver. Exercise V10–V12 and the layer-origin case V11.

## T07 — Namespace-centered GUI over the common contract

**Files:** modify `templates/index.html`, `workbench.css`, `workbench.js`, `structure.js`, `cytoscape-view.js`, and `viewer.py`; create focused `namespace-browser.js` and `inspector.js` modules. Extend existing browser fixtures rather than adopting a new frontend stack.

Implement [15](15-gui-implementation-spec.md) and [16](16-visualization.md): persistent progressive namespace, compact actual cards, one inspector, source-separated details, join explanation, named layers, focused provenance paths, explicit comparison/history, and responsive drawers. Use actual declared Type bindings and narrowing metadata. Remove duplicate `#type-detail` presentation only after its unique content is retained in the inspector.

Use one semantic selection/navigation state, preserving Back and DE control. Handle late responses, background clearing, empty branches, missing targets and revision changes as specified. Fetch bounded scenes before serialization; do not load the entire graph and compute unused similarity for ordinary browsing.

**Evidence:** record the complete V19 workflow, V18 text visibility and V20 responsive/keyboard use. Keep exact request/response targets alongside screenshots. Verify displayed inherited/layer facts against the shared resolver, not only label appearance.

## T08 — Purposeful local expansion

**Files:** create `src/metaform/expansion.py`; extend model/expansion manifests, workflow assignment inputs, source dependency capture and GUI expansion controls. Add `tests/test_local_expansion.py` and continuation/overlap cases.

Implement `start_expansion` over the existing Engine. Build context for one Element, Type, namespace branch, join or bounded region. Use the supplied purpose and expansion prompt, then apply an explicit structural patch with refinement links and preserved actual identities. Distinguish adding depth from correcting earlier meaning.

Record expansion opportunities and completed deeper accounts as addressable metadata. A pending question is not automatically a scheduled exhaustive project pass. Concurrent non-overlapping patches can be replayed by identity; conflicts expose the competing record versions.

Exercise the stable-parent refinement case and update dependency selectors. Verify that unrelated model regions and layers remain unchanged except for their explicit impact state.

## T09 — Variants, structural impact and reinference

**Files:** create `src/metaform/transform.py`; extend model manifests, layer regeneration, namespace relocation, knowledge dependency indexes and comparison projections. Add `tests/test_model_transformations.py`, `test_layer_reinference.py` and selector-impact cases.

Implement source-preserving model clone, explicit patch/mapping operations, reference-aware relocation and a new immutable destination revision. Compute record and selector changes, including newly matching subjects and negative-context dependencies. Walk dependencies of derived layers transitively.

Return preserve/relocate/invalidate/regenerate/reconsider decisions with reasons and exact targets. Reapply original semantic requests to destination Type/join context for generated knowledge. Keep original prompt strings and source answers as provenance, not text to substitute mechanically. A semantic variant remains distinct from the source-file port.

Exercise V04 and V13–V15. Use the engine/installer fixture to show one changed language region without contaminating the sibling or source model. Preserve manual attachments and interrupted generation state.

## T10 — Grounding, lexicalization and workflow integration

**Files:** extend `modules/workflow.py`, `prompts.py`, `workflow.py` only where prepared context is built; add the grounding/specialization role and recorded context handles. Update prompt/workflow GUI views to show the selected model and targets. Add `tests/test_grounded_specialization.py`.

Replace implicit generic graph assembly for new specialization with the common selected-region grounding envelope. Preserve the source instruction and its control flow. Resolve semantic targets and relevant Type/OP knowledge before the task-specific agent acts. Reuse unchanged Type and context material by revision; record the actual dependencies used.

Task selection can be performed by the grounding specialist through read tools. `model.ground` itself remains a deterministic region projection rather than a hidden new inference pass. Workflow conversion retains the existing semantic-equation source as attributed input.

Exercise V21 and V22 with a concrete repository task. Verify a specialized instruction does not acquire extra approval steps, conditions, or unrelated tasks merely because a knowledge layer suggested them.

## T11 — Demonstration, migration completion and current documentation

**Files:** update current-facing README, `docs/SPEC.md`, `architecture.md`, `workflows.md`, workbench navigation, semantic source manifest and the active architecture pointer in `AGENTS.md`; preserve unrelated user-authored text and historical quotations. Add a reproducible demonstration under `examples/realignment/` and its readme/evidence.

Run the matched prompt comparison V23 with retained source input and actual harness metadata. Use MGM plus a non-code artifact and a multi-Type fixture. Publish measured outcomes without claiming that a smaller prompt or passing schema proves semantic quality.

Run V24 end to end: one-foundation intake, namespace/local exploration, property explanation, requested layer, destination variant, affected-layer reinference and grounded task output. Include GUI/CLI/MCP references to the same targets. This demonstration is the evidence that the project is practically useful, not just more organized.

Complete v1 adapters, prompt migration and public terminology updates. Remove superseded active mechanisms rather than leaving inverted versions in the default path. Retain historical scope/source views explicitly. Run the relevant full regression suites, both browser suites in a functioning browser harness, wheel build and installed smoke test after code changes.

## Dependency order and parallel work

T01 can start immediately. T02 → T03 establishes the common model. T04 follows T02/T03. T05 uses T02–T04. T06 uses the shared model/layer records. T07 can develop namespace and basic inspection after T03, then finish layer/provenance interactions after T05/T06. T08 uses T02–T04. T09 follows T05/T06/T08. T10 builds on T03/T05/T06 and can integrate with T09 when porting is demonstrated. T11 closes the end-to-end workflow and current documentation.

Parallel subagents work on independently bounded slices with the shared platform prompt and exact interface contracts. Integrate semantic record/read definitions before allowing client implementations to diverge. There is one target architecture in this archive, not a choice among competing rewrites.
