# Focused prompting and demonstrable usefulness

## The improvement to preserve and the work still needed

The latest artifact structure is a useful, visibly coarser direction. Prompt refinement should improve that direction, not restore the former per-Type proliferation. It also must do more than shorten text. A focused prompt needs the correct semantic question, enough context to answer it, a suitable output model, and examples that distinguish artifact functionality from implementation detail.

The target change is **role-specific instructions plus selected semantic context**, with the glossary remaining a browsable reference. No runtime role receives the complete platform-expert foundation. No ordinary report role receives all structural-authoring rules merely because another role needs them.

## Measured current composition

A fresh seed/snapshot probe against the reviewed package produced the following character counts. These are characters, not model-token measurements. Rule payload size is the serialized selected rule records and includes provenance/examples.

| Role | Role source alone | Complete seeded prompt | Full glossary included | Selected rule payload |
| --- | ---: | ---: | --- | ---: |
| Native | 4,044 | 11,621 | Yes, 7,575 characters | 9,951 characters |
| Archaeology | 2,460 | 10,037 | Yes, 7,575 characters | 9,951 characters |
| Proof, still seeded | 1,573 | 9,150 | Yes, 7,575 characters | 9,951 characters |

`Intake._assignment` additionally appends 1,173 characters of Aliases text and supplies bundled schemas. Workflow conversion, lexicalization, specialization and continuity seed prompts did **not** contain the full glossary in this probe. The observed issue is blanket inclusion across the intake-role seeds, not a verified claim about every prompt in the system. [S09](evidence/source-index.md#s09), [evidence](evidence/prompt-inventory.json)

The glossary is not merely verbose: it contains superseded instructions for two complete graphs. Removing that contradiction is a semantic repair. Reducing duplicated definitions and role-irrelevant rule examples is an efficiency opportunity whose effect on task quality still needs to be observed.

## Role composition matrix

| Role | Needed semantic context | Task/output context | Kept outside its automatic payload |
| --- | --- | --- | --- |
| Coarse intake | DE; receiver/OP/Type EF conjunction; actual/Type distinction; join roles; Function/Encounter narrowing; naming/description/aliases; local property placement | Source scope, reusable Type matches, current frontier, foundation schema | Complete platform foundation, variants architecture, full outside-review glossary, artwork instructions |
| Local expansion | Same local relationship semantics and any rules for records it will author | Target's stable identity, relevant joins/Types, evidence, expansion purpose, patch schema | Unrelated full project implementation and full intake rediscovery |
| Blind-spot analysis | Artifact account, receiver purposes, principal Types/joins, structural versus attached knowledge | Selected region, source coverage, report schema, exact question | Namespace-authoring tutorials, alias examples, full graph-output schema |
| Layer design/generation | Subject and applicable Types/joins; attachment scope; structural versus generated knowledge | Exact semantic request, selected/constructed payload schema, target selector, generation context | A fixed best-practice taxonomy or all unrelated layers |
| Task grounding/specialization | Prepared selected-region context and the requested imperative | Original instruction, resolved references, applicable knowledge and preserved workflow control flow | Platform development guidance and automatic broad architecture review |
| Transformation reinference | Destination Type/binding/join context, source-to-destination mapping, relevant recipe | Exact original semantic request and destination payload schema | Old answers as authoritative destination truth or global text replacement rules |
| Platform expert | Complete supplied foundation and relevant subsystem specifications | Named implementation assignment and baseline evidence | Runtime prompt composition is not copied from this role |

Use stable semantic component IDs and stored revision/text snapshots. Include a needed component once in an assignment. Component selection is part of role composition, separate from execution authorization. Preserve the existing dynamic blacklist model for executable commands separately.

## Prompt-construction changes

Replace `seed()`'s string concatenation with a role definition containing its task text and explicit semantic component references. Keep editable prompts and selected rule snapshots. Update managed seeds to the new composition; preserve custom text and issued assignments as described in [18](18-guidance-audit.md).

Use complete concise rules when they are the operative mechanism. The accepted namespace naming rule must not be paraphrased into a vague “choose good names.” Preserve the Aliases semantic material when a role authors Types, and remove it from a report-only role that only references existing targets. Selected supporting examples should teach a distinction that the current task needs, not repeat a whole glossary.

Separate instruction text from data: the original request, current artifact account, Type definitions, source evidence, schemas and previous-generation metadata are named inputs. Keep original source prompts and rendered assignments in provenance; do not send duplicate source/rendered text to the model merely to retain that provenance. The current MCP transport already removes one such duplicate for intake—retain that improvement.

Use `prompts/runtime/` as the supplied replacement task texts. `composition.json` specifies which semantic components and schemas accompany each. The runtime resolves those references from its versioned registry; it does not assume the model can read an archive-relative Markdown link.

## Semantic examples for intake

Prefer a few contrastive examples over a large domain taxonomy. A connectivity evaluator's EF describes interpreting observations to determine viable connectivity; source thresholds remain evidence unless they define the artifact-level meaning. A maintenance guide provides a reader with actionable maintenance understanding; its PDF encoding is not its defining function. Two actual adapters can share one Type while meeting different receiver purposes. The examples in this archive are illustrative and not mandatory output templates for every artifact.

A Type with one EF can participate in several actual contexts. A provider actual with multiple Type facets retains a binding for each; a join names the facet it receives. An OP role is relative to the receiver. These examples directly protect mechanisms the current schemas leave implicit.

## Evaluation that demonstrates use

Run localized comparisons of the current bundled assignment and the proposed focused assignment on the same recorded artifact evidence and model/harness settings. Use MGM plus a non-code artifact and a small multi-Type fixture. Retain raw assignments/outputs, source snapshots, model metadata when available, and the rubric findings. Do not hand-correct outputs before comparing them.

Measure: initial semantic passes and repeated context bytes; actual prompt tokens when the harness reports them; amount of source rereading; Type reuse versus duplicate definitions; incorrect receiver-purpose pairings; implementation-detail leakage; ability to target a region; and task-level usefulness. Repeated trials can reveal inconsistency, but there is no arbitrary iteration count or universal score that blocks normal intake.

A demonstration should show a fresh agent orienting from the Metaform, explaining one join, tracing a locally scoped property without sibling contamination, preparing an actionable refactor or porting step, then regenerating one affected layer after a structural change. Compare its statements to source evidence and the user's task. A smaller prompt that loses the conjunction fails semantically even if it is cheaper. A longer prompt that repeatedly produces proposed components as facts also fails.

The archive supplies specifications and semantic witnesses, not a claim that these revised prompts have already been executed through a live model. That quality experiment remains implementation work with explicit inputs and expected observable behavior in [22](22-verification-cases.md) and [23](23-implementation-plan.md).

## Completion is not a screenshot

The intended product result is a reusable orientation surface that saves reconstruction work and improves the next task's grounding. The recent GUI and coarseness improvements help reach it. Completing the focused prompt path, single foundation, layers, shared semantic reads, and a visible end-to-end task demonstration is what makes that direction demonstrably useful. Keep those deliverables in the execution plan rather than postponing them indefinitely behind cosmetic work.
