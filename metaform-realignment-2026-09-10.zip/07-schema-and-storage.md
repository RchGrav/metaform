# Record schemas, storage, and reference semantics

## Design boundary

The schemas in `schemas/` specify the target interchange model. They are not a second database and are not replacements for every existing generic Element-table record. Implement adapters over the present owner-qualified store, reified joins, schema registry, and portable export. Ordinary foundation reads expose these semantic collections; historical/runtime administration can still inspect the original records. [S07](evidence/source-index.md#s07), [S08](evidence/source-index.md#s08), [S12](evidence/source-index.md#s12)

A `ModelRef` identifies project, model, and immutable revision. A `Ref` identifies owner, kind, and record ID; a record revision may be supplied when the reference must pin an exact historical value. The built-in kinds include `type`, `element`, `binding`, `narrowing`, `refinement`, `join`, `layer`, `knowledge`, `recipe`, and `activity`. The reference schema leaves `kind` extensible. New kinds are registered through their schemas and adapters rather than encoded as another namespace trunk.

The generic reference must not fall back across project owners just because an ID matches. Existing project/global resolution remains available for unqualified convenience inputs; the resolved result is always explicit.

## Foundation collections

| Collection | Required meaning | Main fields |
| --- | --- | --- |
| `types` | Universal Type definitions | `id`, `description`, one `ef`, `length`, aliases, Parametric names, optional presentation |
| `elements` | Actual artifact-relevant things | `id`, `name`, freeform `description`, artifact reference, optional concise summary |
| `bindings` | Actual-to-Type classification | `id`, actual `element`, `type`, optional contextual `realization` |
| `narrowings` | Direct canonical Type placement | `id`, `parent`, `child`, Function/Encounter `category`, semantic `reason` |
| `refinements` | A deeper account of a particular actual | `id`, coarse `parent`, more-detailed `child`, `reason` |
| `joins` | Receiver-owned OP meetings | `id`, `receiver`, `provider`, `provider_type`, `purpose`, `role`, optional signal/logic/participants |

The model's `artifact` reference names its Defining Element. Its outward receiving-purpose relationships remain in `joins`. A Type record can itself be examined through ordinary Metaform operations; keeping the collections distinct does not contradict Element primacy.

### Why `provider_type` is explicit

The join receives `types[provider_type].ef`. It does not contain a separate, independently editable universal EF. When the provider is an actual, a corresponding Type binding establishes that facet. When the provider is a Type in a reusable Type-level contract, the provider and provider Type refer to that Type. The receiver and its purpose remain paired on the join.

This makes the preserved conjunction inspectable without duplicating Type definitions into every relationship. The Type inspector can collect Type-level clauses and actual witnesses separately. An actual with several Type bindings is never forced to choose one permanent identity or to merge all EFs into an ambiguous paragraph.

### Descriptions and summaries

An actual description may remain text or structured content. The optional `summary` is a concise functional account authored with the Element, not a second autonomous interpretation pass. Cards use that summary, or a plain-text description/account when one exists; they do not concatenate assessment metadata, nested provenance, and every key into a label.

Type `description` is universal. Source paths, callback names, measured constants, assessment conclusions, and source-audit coverage do not belong in it. An actual's implementation-specific evidence can be retained in provenance or a deeper analysis attachment without making it a Type property.

Presentation data, including existing SVGs, is optional and excluded from structural meaning. Retain authored SVG identity and the tested renderer. Do not make artwork generation a required intake inference operation.

## Knowledge and provenance records

A layer definition identifies a meaningful knowledge collection, its payload schema, generating recipe, selectors, and current generations. An attachment identifies its subject, schema-specific payload, applicability, producing activity, and dependencies. A recipe retains the exact semantic request and enough prepared context to reproduce the operation against another foundation revision. These records are specified separately in `layer.schema.json` and [12](12-layers-and-reinference.md).

A provenance activity records inputs, source revisions, prompt and rule snapshots, the actual rendered assignment, outputs, and execution metadata available from the harness. Evidence is referenced rather than copied into every actual description. Preserve imported raw observations unchanged. `native`, `archaeology`, and `authored` remain historical source labels where present; none is used as a substitute for the full provenance relationship.

## Revision semantics

A foundation revision is immutable and belongs to one model lineage. Store a content hash of its structural projection: Type meanings, actual descriptions/summaries, bindings, narrowing/refinement relations, and OP joins. Exclude timestamps, SVG bytes, model execution logs, and attached layer payloads from that structural hash. Record-level and selector-level fingerprints support more localized change detection.

The revision identifier need not claim that two hashes prove semantic equivalence. Hashes establish unchanged serialized inputs. A changed meaning can require reinference even when a human retains the same Type name. Conversely, an artwork or timestamp change need not invalidate every knowledge layer.

Layer revisions are independent of foundation revisions. A new layer does not create a different artifact identity. A structural variant has its own lineage/reference; its layer associations can point to preserved generations or new destination-specific generations with explicit provenance.

## Storage implementation

Reuse the service transaction and owner partitions. Store Type definitions and actuals as schema-specific Element records. Store binding, narrowing, refinement, and OP records as typed reified relations or equivalent normalized rows, retaining first-class IDs. Add model/revision membership and layer/generation associations rather than inferring them from a free-form `layer` string.

Build indexes for `(owner, kind, id)`, model revision membership, Type namespace parent, alias target, actual-to-Type and Type-to-actual bindings, incident participants, layer subject, generating recipe/activity, and dependency targets. Indexes are derived access structures, not new semantic sources of truth. Preserve SQLite as the installed service's authority and JSON as the portable representation; Ladybug remains an analysis copy where currently configured.

A small snapshot/patch journal plus existing record storage is sufficient. Do not introduce a distributed graph cluster, event bus, or separate job queue. Local per-run continuations already provide durable execution. The new modules should invoke them rather than maintaining a parallel lifecycle.

## Schema registry and compatibility

Use versioned `$id` values, registered references, and the existing bundled-schema mechanism. The supplied schema documents use `urn:metaform:schema:*:2` IDs and Draft 2020-12. `foundation.schema.json` contains reusable definitions; layer, transformation, and read-envelope schemas reference them. Payload schemas are independently registered and not restricted to the examples in this package. [R04](20-research-and-decisions.md#r04)

Do not mutate the historical meaning of `metaform:element` in place. The v1 adapter recognizes it as a Type definition and `metaform:actual-element` as an actual. New normalized bindings are derived from `type_ids`; compatibility views may expose `type_ids` as a computed projection. Do not store editable bindings and editable `type_ids` as two competing authorities.

The v1 adapter maps `object_id` to receiver and `element_id` to provider. A single unambiguous matching provider Type can be carried forward. With several plausible functional Types, preserve the original join and report the unresolved facet; do not silently select the first array entry. Targeted semantic refinement supplies the missing binding when needed.

## Diagnostics, not invented meaning

Required fields in the schemas define the intended well-formed interchange record. Keep the current annotation-oriented behavior for draft output. Missing information stays visible with its exact record/path; it is not filled with invented text to satisfy a validator. Reference errors, duplicate IDs, and conflicting transactional writes must be reported concretely.

Semantic verification separately checks whether the selected Type EF, receiver purpose, role, namespace placement, and resolution are correct. The example validator verifies schema/ref consistency of this package, not the truth of a generated Type. The behavioral cases in [22](22-verification-cases.md) exercise the architectural distinctions that ordinary shape validation cannot prove.
