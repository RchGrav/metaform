# Extensible knowledge layers and reinference

## A layer is an instruction-produced knowledge collection

A layer adds knowledge to an existing foundation without changing its structural identity. “Add some best practices” is one possible semantic request, not a special API type. The same mechanism can produce design implications, operational guidance, opportunities, migration advice, quality criteria, audience considerations, or a requested analysis with its own suitable schema.

The layer records what was asked, which region it concerns, how its payload is structured, what context generated it, and why each attachment applies. It is addressable from the GUI, CLI, and MCP. Its generation can be repeated against another foundation revision or a destination variant.

The current schema registry, editable prompts, workflow execution, owner-qualified knowledge, source observations, and portable export are reused. The existing `metaform:learning` arrays are not the general layer model; they become one importable legacy payload shape. [S08](evidence/source-index.md#s08), [S09](evidence/source-index.md#s09), [S12](evidence/source-index.md#s12)

## Records

**Layer definition:** stable `id`, meaningful `name` and description, payload `schema_ref`, source `recipe_ref`, target selector, and associations with model revisions. The name should state the requested knowledge, such as “Gateway coordination blind spots” or “Language-specific implementation practices.” A collision produces a distinct identity; it does not silently replace a prior layer with the same display name.

**Recipe:** the exact original semantic request; source prompt ID and text; prepared/rendered assignment snapshots; selected rule text and revisions; input schema snapshots; target selector; resolved targets and context references; model/source revisions; and available harness/model/sampling metadata. The recipe's raw request is not rewritten when a prompt is specialized.

**Generation:** one application of a recipe to a model/revision and target set. It records its assignments, outputs, state, and parent generation when regenerating. Reuse the current run/receipt machinery rather than creating a separate scheduler.

**Knowledge attachment:** stable subject/slot identity within the layer, payload conforming to the chosen schema, subject reference, applicability descriptor, producing generation/activity, and dependencies. It can target an actual, Type, OP join, refinement, or named region. A Type-level attachment is not copied into each actual's structural record.

**Applicability result:** a read-time projection identifying the attachment's origin, any Type/join/refinement path, current scope, and freshness. Layer origin and inherited path can both be present. See [10](10-property-transitivity.md).

## Generation flow

1. Interpret the semantic request against the model's coarse shape. Resolve the requested region, or use the current model when no narrower region was supplied. Preserve the request verbatim.
2. Select an existing payload schema that fits the requested knowledge, or author and register a new one with its own `$id`. The schema is chosen for the meaning being expressed, not by a hardcoded catalogue of layer names.
3. Group work around reusable Type knowledge and relevant relationship contexts. Generate shared Type-level knowledge once, then actual- or join-specific additions where the request and local context warrant them. Do not automatically create a separate identical paragraph for every node.
4. Supply each assignment with its subject, Type meanings, relevant joins, applicability context, and source handles needed for that request. The complete repository is not its default input.
5. Store produced attachments under the layer generation and return their references, coverage, unresolved targets, and any failed assignments. Publishing a layer does not alter the foundation.

Use `prompts/runtime/layer-design.md` and `prompts/runtime/layer-generate.md`. The design step produces the layer definition, schema, selector, and meaningful grouping. It is not a questionnaire or approval step. Simple requests can perform design and generation within one assignment when the schema and targets are already clear.

## Relevance and scope

A selector is a recorded semantic region: an explicit record, a namespace branch, a set of Types, a join neighborhood, or another named region. The selector records its interpretation and resolved targets. “Relevant nodes” does not mean every object in the database, and it does not mean a static whitelist of node kinds. The generation identifies relevance through the request, Type meanings, and connected joins.

Universal advice belongs at Type level when its meaning is genuinely reusable. Project-specific advice stays with the project, actual, or join that makes it applicable. Merely placing a record under a globally named Type does not authorize promoting a project's private details into global knowledge. Preserve the existing owner partitions and make any shared record's scope explicit.

An attachment's applicability can be direct, through Type specialization/binding, through named actual refinement, or within a declared relationship context. Use those existing semantic paths; do not allow generic connectivity to spread every layer statement globally. A custom schema can express richer knowledge, while its attachment envelope still identifies the applicable subject and path.

## Provenance sufficient for regeneration

Retain the **exact question**, not only the generated answer or a short label. Retain the source prompt and the actual rendered assignment, not only a mutable prompt ID. Retain the Type/Element/join revisions and selectors used to assemble context, not only the repository commit. Include schemas and selected rules in the snapshot.

The context builder automatically records the inputs it supplied. The model may additionally identify which premises materially influenced a conclusion, but those self-reported premises are not the sole dependency record. Otherwise an omitted dependency would make change impact silently incomplete.

Record both dependencies on known records and dependencies on selection results. A layer targeting `code.cpp` depends on which actuals currently bind within that region; adding a newly matching actual can require a new attachment even though no old record changed. A claim that the model shows no recovery path depends on the examined neighborhood's membership, including its absence of such a path. Store the selector and the selected-result fingerprint, not an invented placeholder node for the missing concept.

Execution metadata is provenance, not semantic identity. Retain model/harness versions and sampling values when available; absence of unavailable metadata is stated rather than fabricated. Do not embed credentials or unrelated environment data in recipes.

## Reinference after change

Resolve the original request and selector against the destination foundation. Use recorded relocations for meaning-preserving address moves and the explicit transformation mapping for replaced regions. Build new Type and join context from the destination. The old output may be available for a requested comparison, but it is not authoritative context that the new answer must reproduce.

A generated record whose relevant serialized inputs are unchanged can be preserved. A meaning-preserving target move can relocate its attachment. Changed premises make it stale or invalid for its prior applicability and place it in the impact report for regeneration or reconsideration. A deleted subject can leave historical knowledge with an orphaned target; it must not be silently attached to the nearest surviving node.

Reinfer at the smallest useful unit: one Type grouping, actual, join, or selector partition. A single Type's changed EF does not justify replaying every unrelated layer over the entire project. Conversely, a layer whose question is genuinely project-wide may depend on the overview and need a broader regeneration.

## Replacement, manual edits, and removal

Regeneration replaces only the selected layer's generated subject/slot outputs. Other layers, the foundation, and independently authored knowledge are not its write targets. A manually edited attachment retains its own provenance and is not silently overwritten by a later generator; the new generated revision and the authored revision remain distinguishable.

Use per-subject generation state. Interrupted work keeps its saved receipts and completed outputs; remaining assignments resume from the recorded request. A previous generation's record remains retrievable with its freshness state instead of disappearing because one new worker failed. Invalidated historical knowledge is not presented as a currently applicable native property.

`layer.remove` removes that layer's association and active attachments from the selected model. It does not implement removal as a still-active record with an inverted flag. Existing historical revisions remain inspectable through history, as with other removed project material; they are not listed as current layers.

Two layers can make different recommendations. Show their different requests, sources, and scopes. Do not manufacture a universal latest-wins or confidence ranking. A user-requested synthesis can be another layer whose sources are those layers and whose own request is retained.

## Exposure

The GUI's Layers view lists the actual named knowledge collections, their target regions, current generation, schema, coverage, and freshness. The Element inspector shows applicable attachments grouped by origin and expandable provenance. A Type-level attachment can be inspected once and followed to its actual applications.

CLI and MCP expose `layer.list`, `layer.inspect`, `layer.create`, `layer.regenerate`, `layer.remove`, `knowledge.get`, and `knowledge.explain` through the common command model. Responses include stable references and explicit coverage. A payload too large for an orientation result is returned through a versioned handle rather than embedded repeatedly.

## Example request

For “Use Metaform to add some best practices,” infer a meaningful layer name from the actual request and scope, select or create a practice-oriented payload schema, and reason over relevant Types and their joins. Shared C++ guidance may attach to `code.cpp`; advice specific to a cross-language boundary may attach to the relevant OP join. The same pipeline works for a photograph collection's presentation guidance or a maintenance guide's reader-support analysis. No memory-management rule, language list, or best-practice array is built into the layer engine.
