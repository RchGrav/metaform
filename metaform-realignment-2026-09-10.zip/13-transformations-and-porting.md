# Foundation transformations, variants, and project porting

## Scope

A variant is a derived foundation that can represent a destination architecture. Cloning and reshaping that model does not itself port implementation files. It creates a coherent destination understanding from which task-specific prompts and workflows can plan and perform the actual port.

The repository already documents cloning Native, replacing language properties, detaching affected reasoning, and reissuing its source prompts. Existing project-copy and file-history mechanisms are useful infrastructure, but semantic variant lineage and generated-knowledge impact still need implementation. [S11](evidence/source-index.md#s11)

## Variant lifecycle

Clone a selected foundation revision into a new model lineage or named variant. Keep a reference to the source revision and a source-to-destination record map. Initially preserve structural record identities within the variant's explicit model context; do not copy everything into global Type storage or confuse the variant with the source's current revision.

Apply a structural patch: add, remove, replace, relocate, reclassify, refine, or change an OP/narrowing/refinement relationship. Record the semantic purpose of the transformation and its before/after references. A destination under design is labelled as such; observations about running source code do not become evidence that the destination already exists.

Compute the impact on attached knowledge and prepared task contexts. Preserve unaffected knowledge, relocate meaning-preserving attachments, invalidate old applicability where premises changed, and enqueue the affected recipes for reinference. Publish the destination layer generations as they are produced. The source foundation and its knowledge remain independently inspectable.

## Operation semantics

| Operation | Structural action | Identity and knowledge consequence |
| --- | --- | --- |
| Remove Element | Remove its current membership and the explicitly addressed incident structural relations | Original remains in source/history; affected attachments become orphaned or are removed according to the transformation; do not attach them elsewhere implicitly |
| Replace Element | Introduce or select the destination Element and record what source role it replaces | Same source/destination purpose can guide realignment, but replacement does not assert semantic equivalence |
| Relocate Type | Change canonical address while preserving Type meaning | Update structured references and retain a relocation alias; preserved knowledge can follow that lineage |
| Replace Type/binding | Change the Type facet through which an actual is understood | Re-evaluate joins receiving that EF and knowledge depending on the binding; this is not a rename alias |
| Modify OP join | Change receiver, provider, provider Type, purpose, role, signal, or logic explicitly | Assess knowledge depending on that meeting, including join-specific recommendations and path-derived properties |
| Reorganize narrowing | Change the meaningful parent/child relationship and its category/reason | Recompute membership-region results and Type-scoped applicability; preserve unrelated actual identity |
| Expand/refine | Add a finer account beneath a stable coarse actual | Preserve coarse identity, add refinement provenance, and evaluate whether previous coarse advice remains applicable |

A remove operation removes the selected current structure; it does not keep an inverted dependency or a disabled pseudo-Element in the active foundation. Historical lineage is separate from the current shape.

## Reference-aware transformation

The current rename helper updates element keys, join endpoints/participants, and observation addresses, but does not update `type_ids`. The localized probe produced a dangling Type binding after a rename. Use this as a concrete repair witness, not as justification for rewriting all prose. [S07](evidence/source-index.md#s07), [evidence](evidence/measurements.json)

A transformation updates structured reference fields declared by schemas/adapters: bindings, provider Types, narrowing/refinement references, selectors, applicable-layer subjects, and dependency descriptors. Keep the exact historical source prompt text unchanged. A new rendered assignment uses a relocation map or resolved destination references while retaining the original request's provenance.

Do not perform global textual substitution of source-language names inside arbitrary prose. That would mechanically copy assumptions the reinference process is intended to reconsider.

## Change-impact decisions

| Decision | Evidence required | Action |
| --- | --- | --- |
| Preserve | Relevant record projections and selector results are unchanged | Associate the existing generation with the destination and retain its original provenance |
| Relocate | An explicit meaning-preserving mapping changes only the target address/location | Update the current attachment reference; retain origin and relocation trace |
| Invalidate | A premise or target on which applicability depends is removed or contradicted | Remove its current-applicability claim; retain the historical record and reason |
| Regenerate | A generated record's relevant Type, binding, join, region, or selected population changed | Reapply its recorded recipe to destination context |
| Reconsider | Impact is semantically material but not mechanically classifiable, or provenance is insufficient | Produce a targeted analysis request naming the exact uncertainty and affected record |

These are knowledge-state decisions, not a new approval workflow. The system can perform authorized regeneration and targeted analysis directly. It must not label mechanically unchanged input as proven semantic correctness, or label a changed timestamp as a reason to regenerate everything.

## Dependency calculation

Maintain reverse indexes from record/selector dependencies to attachment generations and prepared contexts. For a patch, calculate changed structural projections and reevaluate affected selectors. Include newly matched targets and targets no longer matched. Walk derived-knowledge dependencies transitively: a synthesized layer can depend on another layer's generation, not only the foundation.

Keep origin and applicability separate. A language property merely visible at a trunk must not make every descendant layer appear dependent on that language. Use the applicability scope from [10](10-property-transitivity.md), not undirected graph reachability.

When a recipe lacks sufficient historical dependency data, record that limitation and reconsider the relevant legacy layer as a unit. Do not claim precision that the source data does not support. New generations capture the missing context descriptors so later changes can be localized.

## Language-porting example

Suppose an engine actual receives its implementation-medium property through `code.cpp`. Clone the foundation. Replace the relevant language binding/property meeting with `code.javascript` in the destination, while retaining the engine's functional role and its receiver purposes where those remain intended. A separate installer can remain shell-based; the source model still uses C++.

The impact report identifies Type-level or join-specific knowledge whose context included the old realization: memory behavior, runtime assumptions, interoperability, build/deployment practices, or other concerns actually present in the layers. These are examples of likely context, not hardcoded engine rules. Re-run each affected layer's original semantic request against the destination Type and joins. The model supplies appropriate destination knowledge from its expertise instead of replacing the word “C++” in old advice.

Then ground an implementation workflow in the destination region: the engine's intended EF, its receivers/OPs, required interfaces, retained and changed relationships, and regenerated knowledge. The source implementation is evidence for preserving behavior; the destination Metaform is the plan's semantic target. Validation checks the promised artifact function and relevant receiver purposes, not merely whether translated files compile.

## General transformations

The same method applies to separating a service, reorganizing a document set, adapting an exhibition to a different audience, replacing a data representation, or porting a developer tool to another runtime. The engine operates on model relationships and recipe provenance rather than a language-specific migration matrix.

Not every structural change invalidates every layer. A moved document with unchanged Type/purpose may retain reader guidance. A new audience receiver can require reconsidering guidance even when the underlying files did not change. A changed OP can be more important than a changed pathname; the dependency model must account for both.

## Execution and comparison

Use the existing workflow runner for transformation and reinference assignments. A patch references its base revision and provides record-level operations; the service creates a new revision and an impact report. Non-overlapping updates can be replayed onto a later base with a recorded rebase. Conflicting updates name the exact competing records rather than silently winning by time.

Use the current structural comparison machinery as a starting point for a source/destination view, supplemented with Type binding, narrowing, refinement, and layer-impact differences. Retain the existing principle that structural similarity is not confidence or correctness. The GUI offers side-by-side or focused changed-region inspection, while CLI/MCP return the same patch and impact references.
