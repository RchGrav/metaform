# Assessment of the latest substantive commit

The relevant implementation change is `8c2f4a3ae6f8d858a14939f11a85450d9d5f3157`. The remote tip used for review adds handoff documentation after it. This assessment compares the implementation with `c115a6cea8ad01d7aa76a2d13bed25b83a2d2651`; it does not treat the date of a change as evidence of semantic correctness. [S01](evidence/source-index.md#s01)

## Preserve

| Change | Why it advances Metaform | Disposition |
| --- | --- | --- |
| Actual artifact identities separate from Type identities | Two actual things can share a Type without becoming one object; universal knowledge no longer has to carry all project detail | Preserve the separation and migrate it faithfully |
| `type_ids` rather than invented membership OP joins | Classification no longer manufactures a receiver purpose | Preserve the semantics; normalize bindings as addressable classification records |
| Whole-artifact freeform `understanding` | An agent can establish the artifact's functional account before organizing its typology | Preserve; keep run assessments outside the structural account |
| Whole-Native handoff to a fresh outside assignment | The outside analyst sees how the system fits together instead of disconnected Type fragments | Preserve complete coarse context and independent reasoning frame |
| Removal of normal Type-proofreader/per-Type Latent recursion | Avoids repeatedly rediscovering Types and expanding work without a project-purpose frontier | Preserve; do not revive it through a compatibility migration |
| Scoped replacement of the outside result | Removes stale records owned by one generation without simply appending forever | Preserve the ownership/replacement mechanism for layer generations |
| Cytoscape/Dagre and reusable authored SVG support | Provides a sound renderer and improves navigation over an undifferentiated graph | Preserve the stack, artwork fidelity, and tested SVG handling |
| Clicking an actual replaces the visible neighborhood | Exploration remains local instead of accumulating an unreadable trail | Preserve this default behavior |
| Fixed Defining Element, Types, Back, zoom, keyboard controls | Useful escape routes and orientation controls already exist | Preserve; distinguish true namespace ancestry from navigation history |
| Inspector shows receiver, provider, purpose, signal, and source | The right semantic ingredients are accessible | Preserve the data; reorder and progressively disclose it |

Implementation evidence: [S03](evidence/source-index.md#s03), [S04](evidence/source-index.md#s04), [S06](evidence/source-index.md#s06), [S07](evidence/source-index.md#s07).

## Retain and refine

**Actual descriptions:** freeform detail is valuable, but the initial EF should explain the artifact capability, not list callback names or timing thresholds. Keep rich evidence available through expansion/source details. Provide an explicit compact summary for cards when the description is structured, rather than flattening every key into the node label.

**Type assembly:** adding Type definitions to selected actuals without traversing all their same-Type siblings is correct. Split the remaining overload in `assemble`: exact Type inspection, branch membership, one-hop adjacency, and property inheritance are distinct operations. Expose direct and descendant member counts consistently across GUI, CLI, and MCP.

**Outside independence:** keep the fresh assignment and the full coarse Native account. Its result becomes an attached blind-spot report, not a replacement account. A requested follow-up may examine targeted evidence; that is recorded as a different analysis activity rather than pretending it remained blind to implementation.

**Scope replacement:** use the same concept to replace one layer generation or a selected target partition. Preserve the source foundation, other layers, and independently authored entries. Do not run full-store replacement merely to refresh a handful of attachments.

**Graph cards and layouts:** retain the mint/charcoal visual language and source glyph fidelity. At 1600×1000, the sample's 17-node opening neighborhood fitted to 36%, and Types fitted to 12%. Readability must take priority over fitting every card simultaneously. The selected three-node view was substantially clearer but still exposed assessment prose on cards. [evidence](evidence/measurements.json), [GUI review](14-gui-current-review.md)

## Supersede

Normal intake must stop requiring a second structural `archaeology` graph. Supersede `archaeology.md`'s instruction to return revised Native-like Elements and joins; `Intake.submit`'s automatic Native-to-archaeology transition; `_finish`'s normal merged-perspective publication; and the ordinary GUI's Native/Latent/similarity model selector. These are one coupled architectural change, not a cosmetic rename.

Keep historical Native/archaeology observations and the comparison engine available for inspecting old runs. Reuse comparison for explicitly selected foundation revisions or destination variants. A difference is a difference, not a confidence score and not proof one source is correct.

Remove the requirement that intake author a new SVG for every Type. Continue to display existing artwork unchanged. A Type without artwork uses the existing recognizable fallback; artwork creation becomes a presentation task or reusable presentation record, not semantic work on every intake.

Retire unused proof-prompt seeding and current-facing per-Type inference-completion instructions after migrating their historic records. Their files can remain clearly indexed as historical sources when needed to interpret old runs. They must not quietly re-enter current assignments through seed defaults or old stored prompt revisions. [S09](evidence/source-index.md#s09), [18](18-guidance-audit.md)

## Alignment not established by the commit

The sample's Type/actual separation and navigable neighborhood are verified implementation facts. Its individual Type choices, exact EF meanings, and all OP roles are not thereby proven. The sample already carries reused latent interpretation inside Native. There is no controlled pre-commit MGM sample establishing the size of a semantic-quality improvement.

The graph's property behavior is not proven by the written transitivity account or by generic traversal tests. Layer reinference and semantic graph porting are still missing capabilities. The improved GUI also does not yet separate structural facts from proposed contracts, or native visibility from actual property applicability.

The correct continuation is therefore **preserve the real progress, replace the competing-shape mechanism, and build a shared semantic read model underneath the existing interface**. A wholesale renderer or storage rewrite would discard useful work without resolving the main conflict.
