# Property applicability, transitivity, and explanation

## Preserve the settled distinction

The repository's semantic contract already states that a property can be visible backward toward a Defining Element or namespace trunk and have forward effects in its applicable named, more-specific branch. Bash on an installer and C++ on an engine can both be visible at `code` without the installer’s Bash property applying to the engine. This plan implements that distinction; it does not reopen it as a speculative blocker. [S13](evidence/source-index.md#s13)

The essential implementation rule is: **a fact visible at an ancestor does not become a new ancestor-native fact from which propagation restarts into every child**. Retain its origin and scope throughout traversal.

## Origins and paths are independent axes

A property may be native to a Type and inherited by an actual. A generated layer may attach knowledge to a Type and reach an actual through that same binding. A property may be exposed at a trunk only as a summary of a descendant. Therefore “native,” “inherited,” and “layer” must not be one mutually exclusive enum.

Return both:

- **Origin:** the original Element/Type/join, any layer and generation, and its provenance.
- **Applicability path:** direct, through a Type binding and narrowing, through named actual refinement, or through a particular OP meeting.

A result also distinguishes `applies` from `visible_here`. A trunk can display a descendant property's existence while `applies` is false for unrelated descendants. The GUI and task-grounding output must use the same resolver.

## Native, inherited, implied, and layered knowledge

**Direct/native:** a structural record or locally attached assertion supplies the property at the examined target. Explain that direct origin without inventing a traversal.

**Type-inherited:** a universal Type expectation reaches a more-specific Type through the relevant narrowing relationship, then an actual through its binding. The original expectation's scope remains part of the result. A specialization can qualify an expectation; it is not automatically interchangeable with its parent's full semantics.

**Join-implied:** the relationship makes a statement relevant to this receiver/provider meeting. The join's role, purpose, signal, and applicable scope explain it. Ordinary connectivity alone does not prove the statement. A C++ library dependency does not imply that every caller is implemented in C++; a receiver can consume its function across another realization.

**Layer-supplied:** a knowledge record applies through its declared subject and applicability descriptor. Its origin stays the layer even when the path includes Type inheritance or an OP join. A best-practice recommendation is not thereby a native structural fact.

## Scope records

An applicable-property result contains:

```json
{
  "subject": {"owner": "project:demo", "kind": "element", "id": "demo:engine"},
  "origin": {"owner": "project:demo", "kind": "join", "id": "join:engine-medium"},
  "origin_layer": null,
  "applies": true,
  "visible_here": true,
  "claim": {"name": "implementation medium", "value": "code.cpp"},
  "path": [
    {"relation": "join:engine-medium", "step": "property meeting", "from": "code.cpp", "to": "demo:engine"}
  ],
  "explanation": "The engine receives this C++ property through its own medium-purpose join."
}
```

The public record also includes model/revision, source refs, freshness when generated knowledge is involved, and any qualifications. A path is evidence of applicability under declared semantics, not a model-authored decorative chain.

Property placement on a Type has Type scope. Placement on an actual has that actual's scope. Both can be summarized at appropriate ancestors, but a project-specific actual property does not become universal Type knowledge merely because its origin binds to that Type. Shared global knowledge and project-local attachments remain owner-qualified.

## Resolver algorithm

1. Resolve the subject and revision. Gather direct structural property meetings, direct knowledge attachments, Type bindings, canonical narrowing ancestors, and actual refinement ancestors relevant to that subject.
2. For each origin, carry a state containing origin reference/revision, subject scope, relation semantics, layer generation if any, and explanation predecessor. Never replace the origin with a visited ancestor.
3. Apply the permitted semantic step: Type specialization for Type-scoped knowledge; named actual refinement for an actual-scoped property whose scope includes that refinement; a declared OP-context implication for that meeting. Return a reason for each step.
4. Compute backward visibility as a separate projection. It reports where an origin can be summarized and preserves the originating branch. It does not feed a new universal assertion into forward applicability.
5. Collect applicable results by origin and semantic claim. Preserve conflicting or differently qualified origins separately. Return one representative explanation path and references to alternatives rather than enumerating every possible path by default.

Use existing adjacency indexes plus Type/refinement indexes. Memoize against model revision, target, origin revisions, selected layers, and relevant relation semantics. Invalidate those entries through the same dependency mechanism used for generated layers.

The resolver should not implement a general-purpose theorem prover or run a new model inference merely to follow a recorded inheritance path. When a novel implication requires reasoning, generate a separately attributed knowledge attachment whose premises and generating activity are recorded. Subsequent reads can then explain that attachment.

## Cycles, conflicts, and missing detail

Ordinary OP graphs may contain cycles. Use visited state keyed by origin, current reference, and scope to avoid repeated propagation; retain the relationships rather than deleting them to make the graph tree-shaped. Canonical narrowing cycles contradict narrowing and should be reported as a concrete namespace diagnostic. Alias cycles are resolution errors with their path displayed.

Two origins can supply different values or recommendations. Return both with their scopes and sources. An explicit specialization can qualify a more general expectation, but do not invent a global “latest wins” or numeric confidence precedence rule. A layer cannot overwrite a native property merely by being newer.

A missing refinement or unclear implication means the applicability explanation cannot assert that path. Show the known direct origin and the unresolved relationship. The system can still expose the underlying records and offer targeted expansion; it does not need to reject the entire Metaform.

## Required witnesses

**Installer/engine:** attach Bash to `demo:installer` and C++ to `demo:engine`. At the trunk, both are visible with origins. At the engine, Bash is not applicable solely through the shared `code` ancestry. A renderer refinement of the engine receives the engine-scoped property where that refinement is in scope.

**Type reuse:** attach a reusable Type-level expectation to `code.cpp`. Two C++ actuals can receive it through their own bindings; a project-local configuration value on one of those actuals does not travel to the other.

**Join context:** a protocol compatibility expectation may apply to a particular adapter/consumer meeting. A third node reachable through another dependency does not receive it merely because BFS reaches it.

**Layer + inheritance:** a generated recommendation attached to a Type reaches an actual. Its explanation identifies both the layer origin and the Type path, never mislabelling the recommendation as native data.

**Transformation:** replace one branch's C++ medium meeting. Its old generated advice is no longer current for the replacement; unaffected C++ branches retain their own origins. The source model still resolves its original explanations.

See [22](22-verification-cases.md) for behavioral assertions and [16](16-visualization.md) for the disclosure model.
