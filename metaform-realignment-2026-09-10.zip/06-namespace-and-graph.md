# Namespace identity and the typological graph

## Namespace is an addressable projection, not the whole graph

A namespace supplies a human- and prompt-readable Type identity and a narrowing path. The graph supplies classifications, OP joins, alternative typological connections, refinements, and knowledge attachments. A dot does not mean every graph relation is inheritance; an OP join does not need to become a dot in a namespace.

Keep canonical Type IDs as dotted semantic addresses. Actual IDs, such as `mgm:project`, identify particular Elements and remain independent of Type placement and source paths. Owner-qualified references prevent a project-specific definition from being confused with a global record of the same spelling. The existing `RecordKey(owner, kind, id)` and knowledge partitions are the starting point. [S07](evidence/source-index.md#s07), [S08](evidence/source-index.md#s08)

## Function and Encounter belong to the narrowing relationship

The existing rulebook treats Function and Encounter relationally. `code.cpp` is an Encounter of code; a narrower C++ version is an Encounter of `code.cpp`, which then serves as the more general functional branch in that relationship. This is not a permanent node flag that makes a Type forever and exclusively “Function” or “Encounter.” [S14](evidence/source-index.md#s14)

Persist each direct narrowing edge with its parent, child, `category: function | encounter`, and a short reason. The categories explain the edge being inspected. A GUI filter labelled Function or Encounter filters the displayed narrowing relationships at the current branch. It does not create `function.*` and `encounter.*` namespaces or duplicate every Type into two taxonomies.

A Function narrowing identifies a more specific operative capability. An Encounter narrowing identifies a recognizable way that the Type is encountered or instantiated. Both children must still name meaningful Types. A classification label that merely says “language,” “genre,” or “format” is not made meaningful by having children beneath it.

## Preserve the naming mechanism

Reuse the repository's maintained naming rule: the namespace narrows as it extends; use the most common universal singular Type name, reverse its words into period-separated components, locate the existing position expressing its most general specificity, and append the remaining modifiers. `length` counts the words of the complete name, including reused components. Reading the final `length` components backward recovers the name. [S13](evidence/source-index.md#s13)

For Network Driver, reuse `code.system.driver` even when the existing example is `code.system.driver.video`; create `code.system.driver.network` with `length: 2`. Do not append `network` to `video`, and do not insert a new classifier node to make the folder tree look tidy.

Maintain the existing alphanumeric component rule; do not revive the older alphabetic-only rule and thereby break version names such as C11. Preserve the stated exterior naming exception and established root labels. The sample's root `code` has a label that cannot simply be recovered as “Program Code” from one segment; a migration should retain the root's explicit display label rather than silently rewriting its meaning to satisfy a mechanical name extractor.

Aliases map alternate names or meaning-preserving prior addresses to a canonical Type. Ordinary search aliases are not new canonical nodes. Retain authored spellings and the reason for a relocation. Parameter names in a Type's `parametric_elements` remain acknowledged tunables rather than being minted as trivial Type children; their reservation is interpreted in that Type's context, not as a global ban on those words everywhere.

## Structural records

A foundation stores Type definitions separately from narrowing relations and actual Type bindings. The canonical path determines the direct namespace parent syntactically; the narrowing record supplies the semantic explanation. These are two views of one placement, not separately editable competing parent definitions. A namespace move updates the canonical address and its associated narrowing relation together.

Additional typological connections can exist in the graph without becoming another canonical address. A Type may be relevant through several relationships, while its canonical name remains stable. An actual may bind to several Types. None of these relationships implies that actuals sharing one Type become siblings in a physical composition tree or inherit each other's local properties.

A missing prefix in imported data is shown as an unresolved namespace position, not promoted from a renderer-created placeholder into a valid Type. New intake should author or reuse meaningful prefixes. Existing imports remain readable with a diagnostic and original identity intact.

## Target grammar

Public operations accept a `target` and a model context:

```json
{
  "model": {"project": "project-id", "model": "model-id", "revision": "revision-id"},
  "target": {"kind": "type", "id": "code.cpp"}
}
```

A short string such as `code.cpp` or `mgm:project` is a convenience input to the resolver. The response always returns the owner-qualified canonical reference and the resolution path. A Type target is not an assertion that only one actual has that Type.

`type.inspect` inspects exactly the Type. `type.members` returns direct bindings and, when requested, bindings beneath the namespace branch. `namespace.browse` returns the next meaningful children and direct/descendant counts. `model.ground` can use a Type target as a region and reports the actual region selected. Different operations are explicit about these different questions rather than silently broadening all reads.

Unknown addresses return the unresolved target and nearby candidates, not a fabricated Type. Ambiguous labels return actual candidates with enough context to select correctly. An explicit owner or canonical address resolves ambiguity without an extra conversational gate.

## Meaning-preserving moves versus transformations

A move that changes only canonical placement retains the Type's lineage and records the old address as an alias. A destination revision can still resolve old prompt targets through that recorded relocation. Rewrite structured references: Type bindings, join provider Types, narrowing/refinement references, selectors, and dependency descriptors. Do not run global string replacement through prose or historical prompt text.

Changing a C++ realization to JavaScript is not a rename and must not make `code.cpp` a global alias for `code.javascript`. It is a variant-local replacement of the relevant binding/property relationship. The source Type retains its meaning. The transformation records a source-to-destination mapping for affected actual regions and asks their generated knowledge to be reinferred.

A collision between two different definitions of the same canonical name remains visible as competing records at their respective owners/revisions. Preserve the existing explicit project/global resolution convention and return which record was selected. Do not silently merge semantic differences merely because strings match.

## Indexing and traversal

Build indexes for owner-qualified record lookup, canonical namespace children, alias resolution, Type bindings, incident joins, and refinement parent/child relations. Persist canonical facts once; indexes are rebuildable. Prefix lookup can accelerate candidate selection, but applicability uses the recorded semantic relationships and attachment scope, not prefix matching alone.

Expose bounded graph traversal separately from namespace descent. OP traversal counts moving across one OP join to its participating record as one semantic step, even when the physical database reifies that join. Return the join record alongside its participants. Joins referring to joins remain first-class and are not forced into false binary edges.

The namespace should let a person or prompt name the expertise-bearing region they need. The graph should then explain that region's role in this artifact. Neither a filesystem tree nor an unbounded neighborhood dump satisfies both purposes.
