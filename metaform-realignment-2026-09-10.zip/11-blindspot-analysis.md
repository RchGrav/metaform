# Outside-in latent analysis

## Purpose

Latent analysis examines an already represented artifact from outside its implementation frame. It looks for overlooked implications, missing considerations, unusual structural choices, opportunities, contradictions, assumptions, and questions worth deeper examination. It can agree with the account. It does not have to produce a criticism to justify its existence.

Its output is a report or knowledge layer attached to the existing foundation. It does not re-create the foundation, revise every actual description, or turn each recommended contract into an existing artifact component. This explicitly replaces the current `archaeology.md` output requirement while preserving the valuable whole-Native context and fresh outside role. [S03](evidence/source-index.md#s03), [S04](evidence/source-index.md#s04)

## Input

Supply the foundation's complete coarse functional account, Defining Element, receivers and purposes, relevant Types, principal joins, and structural scope/evidence-coverage metadata. For a large model, provide the coherent overview plus addressable region handles; retain access to the whole coarse account rather than handing the analyst isolated Type fragments.

The initial outside assignment does not read source implementation details. That preserves the current useful separation. It still sees what the artifact is reported to do and how its functions meet. Being unaware of the Native structure is not neutrality.

When the user asks the analyst to inspect particular evidence, provide it as a separately recorded follow-up or expanded analysis activity. The report states which source evidence was actually examined. Do not keep labelling a source-reading activity as implementation-blind.

## Output

Use the generic layer mechanism with a report payload schema suited to the request. The supplied example schema records a summary and findings. A finding can include a target, the observed basis, the implication or question, its reasoning, and a suggested investigation or structural change. Fields are used when relevant; the schema does not force every artifact through software risk categories.

Distinguish three things in each material conclusion:

1. What the supplied representation says or does not show.
2. What the analyst infers from that account and broader Type knowledge.
3. What would need artifact evidence or an actual change to establish.

A missing statement in the Metaform is not automatically missing implementation. A proposed contract is a proposed contract. A suggested role correction can refer to the existing join and explain the receiver-specific reason without duplicating the whole graph.

## MGM conversion example

The sample's `mgm:latent:trust` and `mgm:latent:serviceacceptance` can become findings under a layer such as `layer:gateway-coordination-blindspots`, targeted to the project's defining relationship, peer-derived state, and forwarding region. Their original prose, qualifications, source revision, and authoring provenance remain available.

The naming/vocabulary join correction becomes a finding targeting that join: the naming function may require the vocabulary even though naming is only supportive to gateway coordination. The report can propose a role/purpose patch and state its basis. Applying that patch is a structural transformation, not an incidental side effect of storing the report.

Do not copy the sample's repeated “accepted with qualifications” text into every actual. Agreement or overall coverage belongs in the report summary and activity metadata.

## Runtime behavior

`intake.examine` becomes a compatibility alias for an outside-analysis layer job. A new `analysis.blindspots` operation can expose the clearer name while retaining old invocation compatibility. It accepts a model reference, optional target region, and the user's semantic request. The existing workflow engine handles assignments, receipts, and continuation.

Completion attaches the report generation and returns its layer reference. A repeat invocation can create a new named analysis or regenerate an explicitly selected existing layer. It replaces only the selected generation/target partition, not the structural foundation or other analyses.

Use `prompts/runtime/blindspots.md`. It receives only the semantics needed for outside analysis, not the full platform-expert foundation. Retain the generating request so a destination variant can be re-examined under the same question after its shape changes.
