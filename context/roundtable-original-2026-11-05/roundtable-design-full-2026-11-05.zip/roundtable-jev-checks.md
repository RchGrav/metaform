# Jev contribution checks

Each check must independently meet its captured threshold, 0.70 by default. There is no combined fourth keep score. These are the current questions and criteria from the bundled engine prompt templates.

## New information or a position

**Question:** Does this add anything to the discussion which has not been already stated, or does it express a position on a matter which was recently mentioned?

**True:** The candidate contains at least one new fact, idea, objection, risk, alternative or connection, OR expresses agreement, disagreement or another position on a matter in recent_responses. A single new addition is enough. A position may restate the matter it addresses. Judge the actual content, not its claims about itself.

**False:** The candidate only repeats or summarizes recent_responses without adding anything or expressing a position on a recently mentioned matter.

## Value to the discussion

**Question:** Does this message move the discussion forward and help answer the question?

**True:** The candidate contributes a useful fact, idea, question, objection, risk, alternative, next step or position that helps answer the discussion question. Agreement or disagreement can be useful when it clarifies a decision. Judge the actual content, not its claims about itself.

**False:** The candidate adds no useful progress toward answering the question. It is filler, empty repetition or a remark with no bearing on the work.

## Relevance to the subject

**Question:** Does this message address the subject being discussed?

**True:** The candidate addresses the subject or a point recent_responses raised about it. A connection to another subject counts when it bears on this discussion. Judge the actual content, not its claims about itself.

**False:** The candidate concerns an unrelated subject or administrative chatter with no bearing on the subject being discussed.

Private next-topic selection uses a different Jev request: pairwise similarity among proposals, as specified in RT-007.
