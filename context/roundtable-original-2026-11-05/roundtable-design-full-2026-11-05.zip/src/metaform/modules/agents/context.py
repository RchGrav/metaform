"""Context delivery evidence, independent of assigned tasks and dynamically loaded skills."""
from __future__ import annotations

import hashlib
import hmac
import secrets
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from typing import Any, cast

from metaform import home, prompt_files
from metaform.data import Column, Index, Table, TableTx
from metaform.module import Context, Stop, context

TABLES = (
    Table('definition_history', place='project', key=('name', 'seq'), columns=(
        Column('name', required=True), Column('seq', 'int', required=True), Column('purpose', required=True),
        Column('prompts', 'json', required=True), Column('source', 'json', required=True),
        Column('version_id', required=True), Column('at', required=True))),
    Table('contexts', place='project', key=('session_id',), columns=(
        Column('session_id', required=True), Column('epoch', 'int', required=True), Column('reason'),
        Column('at', required=True))),
    Table('receipts', place='project', key=('session_id', 'epoch', 'name'), columns=(
        Column('session_id', required=True), Column('epoch', 'int', required=True), Column('name', required=True),
        Column('fingerprint', required=True), Column('actual_version_id'), Column('selected_version_id'),
        Column('component', 'json', required=True), Column('channel', required=True), Column('at', required=True)),
        indexes=(Index(('name',)), Index(('session_id', 'epoch', 'fingerprint')))),
    Table('delivered_text', place='project', key=('session_id', 'epoch', 'fingerprint'), columns=(
        Column('session_id', required=True), Column('epoch', 'int', required=True),
        Column('fingerprint', required=True), Column('at', required=True))),
    Table('change_notices', place='project', key=('session_id', 'epoch', 'name'), columns=(
        Column('session_id', required=True), Column('epoch', 'int', required=True), Column('name', required=True),
        Column('fingerprint', required=True))),
    Table('context_checks', place='project', key=('session_id',), columns=(
        Column('session_id', required=True), Column('epoch', 'int', required=True),
        Column('checkpoint', required=True), Column('marker', required=True),
        Column('pending', 'bool', required=True), Column('confirmed', 'bool', required=True))),
)


def _own(ctx: Context) -> Context:
    return ctx if ctx.module == 'agents' else context('agents', ctx.folder, project=ctx.project,
                                                     session=ctx.session, identity=ctx.identity)


def _fingerprint(one: dict[str, Any]) -> str:
    # Recompute from the actual body rather than trusting a caller's label for another body.
    return hashlib.sha256(str(one.get('text') or '').encode('utf-8')).hexdigest()


def _prompt_names(name: str) -> tuple[str, ...]:
    """Read historical prompt reference spellings in retained delivery evidence."""
    if name == 'orchestration:common' or name.startswith('agents:generated_'):
        name = 'prompt.' + name
    if name.startswith('prompt.skill.'):
        return name, 'skill:' + name.removeprefix('prompt.skill.')
    return (name, name.removeprefix('prompt.')) if name.startswith('prompt.') and ':' in name else (name,)


def _active(receipt: dict[str, Any]) -> str:
    component = cast(dict[str, Any], receipt.get('component') or {})
    return str(component.get('active_fingerprint') or receipt['fingerprint'])


def _receipt(tx: TableTx, key: dict[str, Any]) -> tuple[dict[str, Any] | None, bool]:
    """Read legacy coexistence without assuming one spelling means a more recent accepted delivery."""
    receipts = [one for name in _prompt_names(str(key['name']))
                if (one := tx.get('receipts', {**key, 'name': name})) is not None]
    if not receipts:
        return None, False
    latest = max(datetime.fromisoformat(str(one['at'])) for one in receipts)
    tied = [one for one in receipts if datetime.fromisoformat(str(one['at'])) == latest]
    # Old timestamps have only seconds. Conflicting equal-time receipts cannot establish which body was active;
    # a truthful subsequent acceptance supplies that ordering rather than silently skipping the requested source.
    return tied[0], len({_active(one) for one in tied}) > 1


class ContextService:
    """Public `agent.context` service for preparing and acknowledging instruction delivery."""

    def epoch(self, ctx: Context, session: str | None) -> int:
        ctx = _own(ctx)
        if session is None or ctx.store is None:
            return 0
        with ctx.store.tables(write=False) as tx:
            row = tx.get('contexts', {'session_id': session})
        return int(row['epoch']) if row else 0

    def prepare(self, ctx: Context, session: str | None,
                components: Sequence[dict[str, Any]]) -> dict[str, Any]:
        ctx = _own(ctx)
        previous: dict[str, Any] = {}
        uncertain: set[str] = set()
        known: set[str] = set()
        epoch = 0
        if session is not None and ctx.store is not None:
            with ctx.store.tables(write=False) as tx:
                row = tx.get('contexts', {'session_id': session})
                epoch = int(row['epoch']) if row else 0
                for one in components:
                    receipt, ambiguous = _receipt(tx, {'session_id': session, 'epoch': epoch, 'name': one['name']})
                    if ambiguous:
                        uncertain.add(str(one['name']))
                    if receipt:
                        previous[str(one['name'])] = receipt
                    fingerprint = _fingerprint(one)
                    where = {'session_id': session, 'epoch': epoch, 'fingerprint': fingerprint}
                    # The old receipt table supplies evidence for homes predating the content ledger.
                    if tx.get('delivered_text', where) or tx.rows('receipts', where, limit=1).results:
                        known.add(fingerprint)
        due: list[dict[str, Any]] = []
        seen: set[str] = set()
        for given in components:
            one = {**given, 'rendered_fingerprint': _fingerprint(given)}
            key = str(one['rendered_fingerprint'])
            if key in seen:
                continue
            seen.add(key)
            if key in known:
                before = cast(dict[str, Any] | None, previous.get(str(one['name'])))
                if before is None:
                    continue
                previous_component = cast(dict[str, Any], before.get('component') or {})
                active = str(previous_component.get('active_fingerprint') or before['fingerprint'])
                if active == key and str(one['name']) not in uncertain:
                    continue
                # A -> B -> A changes which retained instruction is active. Send a reference to A, not A's body,
                # and remember that activation only when the reference actually reaches the recipient.
                reference: dict[str, Any] = {'name': one['name'], 'fingerprint': key,
                                            'version': one.get('actual_version_id'), 'after': before['at']}
                text = prompt_files.module('agents', 'restore_context', component_name=str(one['name']),
                    fingerprint=key, version=str(one.get('actual_version_id') or 'unversioned'),
                    after=str(before['at'])) or ''
                one.update(text=text, active_fingerprint=key, reference=reference)
                if 'delivered_value' in one:
                    one['delivered_value'] = reference
                one['rendered_fingerprint'] = _fingerprint(one)
            due.append(one)
        return {'epoch': epoch, 'components': due, 'previous': previous,
                'text': '\n\n'.join(str(one.get('text') or '') for one in due)}

    def changes(self, ctx: Context, session: str | None,
                components: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
        """References to changed instructions already consumed by this context.

        Preparing references acknowledges nothing. Equal rendered text is unchanged even when its source version
        or selection metadata differs. The caller supplies current components. Delivery history cannot establish
        whether the model retained the earlier instruction.
        """
        ctx = _own(ctx)
        if not session or ctx.store is None:
            return []
        epoch = self.epoch(ctx, session)
        notices: list[dict[str, Any]] = []
        with ctx.store.tables(write=False) as tx:
            for one in components:
                name, fingerprint = str(one['name']), _fingerprint(one)
                key = {'session_id': session, 'epoch': epoch, 'name': name}
                before, ambiguous = _receipt(tx, key)
                if before is None:
                    continue
                component = cast(dict[str, Any], before.get('component') or {})
                active = None if ambiguous else component.get('active_fingerprint') or before['fingerprint']
                if active == fingerprint:
                    continue
                delivered = [notice['fingerprint'] for spelling in _prompt_names(name)
                             if (notice := tx.get('change_notices', {**key, 'name': spelling})) is not None]
                if delivered and set(delivered) == {fingerprint}:
                    continue
                notices.append({'name': name, 'epoch': epoch, 'fingerprint': fingerprint,
                                'previous': active, 'actual_version_id': one.get('actual_version_id'),
                                'selected_version_id': one.get('selected_version_id'),
                                'source': one.get('source'),
                                'problems': one.get('problems') or []})
        return notices

    def delivered_changes(self, ctx: Context, session: str | None, notices: Sequence[dict[str, Any]]) -> None:
        """Acknowledge accepted references independently of body receipts. Later revisions remain eligible."""
        ctx = _own(ctx)
        if not session or ctx.store is None or not notices:
            return
        with ctx.store.tables() as tx:
            for one in notices:
                key = {'session_id': session, 'epoch': int(one['epoch']), 'name': _prompt_names(str(one['name']))[0]}
                row = {**key, 'fingerprint': str(one['fingerprint'])}
                if tx.get('change_notices', key) is None:
                    tx.insert('change_notices', row)
                else:
                    tx.update('change_notices', key, row)
                # This table is current reference-dedup state, not body delivery history. An accepted reference
                # replaces stale alias state; it cannot acknowledge the referenced instruction body.
                for alias in _prompt_names(str(one['name']))[1:]:
                    tx.delete('change_notices', {**key, 'name': alias})

    def record(self, ctx: Context, session: str | None, components: Sequence[dict[str, Any]], *,
               epoch: int | None = None, channel: str = 'turn') -> dict[str, Any]:
        ctx = _own(ctx)
        if session is None or ctx.store is None:
            return {'recorded': 0, 'epoch': epoch or 0}
        recorded = 0
        with ctx.store.tables() as tx:
            current = tx.get('contexts', {'session_id': session})
            active = int(current['epoch']) if current else 0
            epoch = active if epoch is None else epoch
            if epoch != active:
                return {'recorded': 0, 'epoch': epoch, 'current_epoch': active, 'stale': True}
            if current is None:
                tx.insert('contexts', {'session_id': session, 'epoch': epoch, 'at': home.now(), 'reason': 'first_delivery'})
            for given in components:
                one = {**given, 'rendered_fingerprint': _fingerprint(given)}
                content_key = {'session_id': session, 'epoch': epoch, 'fingerprint': one['rendered_fingerprint']}
                if tx.get('delivered_text', content_key) is None:
                    tx.insert('delivered_text', {**content_key, 'at': home.now()})
                key = {'session_id': session, 'epoch': epoch, 'name': _prompt_names(str(one['name']))[0]}
                latest, ambiguous = _receipt(tx, key)
                at = datetime.now(UTC)
                if latest:
                    at = max(at, datetime.fromisoformat(str(latest['at'])) + timedelta(microseconds=1))
                row = {**key, 'fingerprint': one['rendered_fingerprint'],
                       'actual_version_id': one.get('actual_version_id'),
                       'selected_version_id': one.get('selected_version_id'), 'component': one,
                       'channel': channel, 'at': at.isoformat(timespec='microseconds').replace('+00:00', 'Z')}
                before = tx.get('receipts', key)
                # Preserve the legacy receipt before replacing it: A -> B -> A must not resend A after upgrade.
                if before is not None:
                    old_key = {**content_key, 'fingerprint': before['fingerprint']}
                    if tx.get('delivered_text', old_key) is None:
                        tx.insert('delivered_text', {**old_key, 'at': before['at']})
                if before is None:
                    tx.insert('receipts', row)
                elif (before['fingerprint'] != row['fingerprint'] or ambiguous or
                      latest is not None and latest['name'] != key['name'] or _active(before) != _active(row)):
                    tx.update('receipts', key, row)
                else:
                    continue
                recorded += 1
        return {'recorded': recorded, 'epoch': epoch}

    def begin_check(self, ctx: Context, session: str | None) -> dict[str, Any]:
        """A startup/resume challenge. Only the runner receives the key; a retained context already has it."""
        ctx = _own(ctx)
        if session is None or ctx.store is None:
            return {}
        with ctx.store.tables() as tx:
            key = {'session_id': session}
            current = tx.get('contexts', key)
            epoch = int(current['epoch']) if current else 0
            prior = tx.get('context_checks', key)
            marker = prior['marker'] if prior and prior['epoch'] == epoch else secrets.token_hex(12)
            row = {**key, 'epoch': epoch, 'checkpoint': secrets.token_hex(8), 'marker': marker,
                   'pending': True, 'confirmed': False}
            if prior:
                tx.update('context_checks', key, row)
            else:
                tx.insert('context_checks', row)
        return row

    def finish_check(self, ctx: Context, session: str | None, checkpoint: str,
                     *, marker: str | None = None) -> dict[str, Any]:
        """Record a marker observation, never an inventory of the model's retained understanding.

        Matching a marker only demonstrates that marker was returned. Omitting it may be ordinary noncompliance.
        Neither observation invalidates delivered receipts or proves semantic retention. Observed compaction and
        explicit recovery are separate operations.
        """
        ctx = _own(ctx)
        if session is None or ctx.store is None:
            return {}
        with ctx.store.tables() as tx:
            key = {'session_id': session}
            check = tx.get('context_checks', key)
            current = tx.get('contexts', key)
            epoch = int(current['epoch']) if current else 0
            if not check or check['checkpoint'] != checkpoint or check['epoch'] != epoch:
                return {'confirmed': False, 'stale': True, 'epoch': epoch}
            if not check['pending']:
                return {'confirmed': bool(check['confirmed']), 'marker_match': bool(check['confirmed']),
                        'semantic_retention': 'unknown', 'epoch': epoch}
            confirmed = marker is not None and hmac.compare_digest(str(check['marker']), marker)
            tx.update('context_checks', key, {'pending': False, 'confirmed': confirmed})
        return {'confirmed': confirmed, 'marker_match': confirmed, 'semantic_retention': 'unknown',
                'epoch': epoch}

    def advance(self, ctx: Context, session: str | None, *, reason: str = 'compaction') -> int:
        ctx = _own(ctx)
        if session is None or ctx.store is None:
            return 0
        with ctx.store.tables() as tx:
            key = {'session_id': session}
            held = tx.get('contexts', key)
            epoch = int(held['epoch']) + 1 if held else 1
            row = {**key, 'epoch': epoch, 'reason': reason, 'at': home.now()}
            if held is None:
                tx.insert('contexts', row)
            else:
                tx.update('contexts', key, row)
        return epoch


SERVICE = ContextService()


def compacted(payload: dict[str, Any], ctx: Context) -> None:
    session = payload.get('session') or payload.get('runner') or payload.get('session_id')
    if session:
        SERVICE.advance(ctx, str(session), reason='compaction')


def inspect_receipts(ctx: Context) -> dict[str, Any]:
    session = str(ctx.nouns['session'])
    with ctx.require_store().tables(write=False) as tx:
        rows = tx.rows('receipts', {'session_id': session}, limit=0).results
    # An inspection must not become another route for dumping delivered bodies or revealing a retention key.
    return {'session': session, 'epoch': SERVICE.epoch(ctx, session),
            'receipts': [{key: value for key, value in row.items() if key != 'component'} for row in rows]}


def confirm_context(ctx: Context) -> dict[str, Any]:
    """Only the actual caller can report its marker; the observation says nothing about retained facts."""
    if not ctx.session:
        raise Stop('A context check belongs to the calling agent session.', 'run this from the assigned agent')
    result = SERVICE.finish_check(ctx, ctx.session, str(ctx.nouns['checkpoint']),
                                   marker=str(ctx.nouns['key']) if ctx.nouns.get('key') else None)
    return result

