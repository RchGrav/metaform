"""Ticket completion saves verified feature commits without publishing shared branches."""
import importlib
import subprocess
import time
from pathlib import Path

import pytest

from metaform.data import Store
from metaform.module import context
from metaform.modules.dispatch.tests.test_dispatch import dispatch as dispatch  # noqa: PLC0414
from metaform.modules.dispatch.tests.test_merge import repo as repo  # noqa: PLC0414

merge = importlib.import_module('metaform.modules.dispatch.merge')
pytestmark = pytest.mark.kind('simulation')


def git(folder, *args):
    return subprocess.run(['git', *args], cwd=folder, check=True, text=True, capture_output=True).stdout.strip()


@pytest.mark.parametrize('remote_configured', [False, True])
@pytest.mark.parametrize('development_branch', ['dev', 'main'])
def test_done_saves_one_ticket_commit_without_publishing_beside_peer_staging(dispatch, repo, remote_configured,
                                                                         development_branch, monkeypatch):
    if development_branch == 'main':
        git(repo, 'branch', '-m', 'main')
        git(repo, 'push', '-qu', 'origin', 'main')
    remote = Path(git(repo, 'remote', 'get-url', 'origin'))
    before = git(repo, 'rev-parse', 'HEAD')
    remote_before = git(remote, 'rev-parse', development_branch)
    if not remote_configured:
        git(repo, 'remote', 'remove', 'origin')
    from metaform.modules.dispatch import activation

    def publish_forbidden(*args, **kwargs):
        pytest.fail('Ticket completion must save without publishing or activation.')

    monkeypatch.setattr(merge, 'push_ticket', publish_forbidden)
    monkeypatch.setattr(activation, 'delivered', publish_forbidden)
    tree = merge.worktree_for(repo, dispatch.id)
    assert tree is not None
    (tree / 'feature.txt').write_text('ticket feature\n')
    git(tree, 'add', 'feature.txt')
    git(tree, 'commit', '-qm', 'ticket step')
    tip = git(tree, 'rev-parse', 'HEAD')
    (repo / 'README.md').write_text('staged peer\n')
    git(repo, 'add', 'README.md')
    (repo / 'README.md').write_text('unstaged peer\n')
    dispatch.store.finish_work(dispatch.id, 'Feature verified')
    result = merge.finished(context('dispatch', repo, project='proj'), dispatch.store,
                            dispatch.store.ticket(dispatch.id).work, tree)
    assert result['state'] == 'committed' and not result['reason'], result
    assert result['head'] == git(tree, 'rev-parse', 'HEAD')
    assert result['evidence']['verification']['passed'] is True
    assert result['evidence']['verification']['command'] == 'true'
    assert result['evidence']['artifacts'] == ['feature.txt']
    assert dispatch.store.complete_delivery(dispatch.id).done
    assert git(remote, 'rev-parse', development_branch) == remote_before
    assert git(repo, 'rev-parse', 'HEAD') == before
    assert git(repo, 'rev-list', '--count', 'HEAD') == '1'
    assert git(tree, 'diff', '--name-only', before, 'HEAD') == 'feature.txt'
    assert git(repo, 'show', ':README.md') == 'staged peer'
    assert (repo / 'README.md').read_text() == 'unstaged peer\n'
    assert not (repo / 'feature.txt').exists()
    assert git(tree, 'merge-base', '--is-ancestor', tip, 'HEAD') == ''
    delivered = git(tree, 'rev-parse', 'HEAD')
    merge.finished(context('dispatch', repo, project='proj'), dispatch.store,
                   dispatch.store.ticket(dispatch.id).work, tree)
    assert git(tree, 'rev-parse', 'HEAD') == delivered, 'Repeated completion creates no second feature commit'
    assert git(repo, 'rev-parse', 'HEAD') == before
    assert not dispatch.store.work(open=True, limit=0).results


def test_explicit_legacy_delivery_excludes_snapshot_and_later_worktree_edits(dispatch, repo):
    tree = merge.worktree_for(repo, dispatch.id)
    assert tree is not None
    (tree / 'snapshot.txt').write_text('peer snapshot\n')
    git(tree, 'add', '.')
    git(tree, 'commit', '-qm', 'legacy snapshot')
    start = git(tree, 'rev-parse', 'HEAD')
    git(repo, 'update-ref', f'{merge.SNAPSHOTS}/{merge.branch_of(dispatch.id)}', start)
    (tree / 'feature.txt').write_text('ticket feature\n')
    git(tree, 'add', 'feature.txt')
    git(tree, 'commit', '-qm', 'ticket step')
    (tree / 'draft.txt').write_text('later peer draft\n')
    dispatch.store.finish_work(dispatch.id, 'Feature verified')
    own = Store(dispatch.store.project_id, module='dispatch')
    with own.tables() as tx:
        tx.insert('merges', {'work_id': dispatch.id, 'branch': merge.branch_of(dispatch.id),
                            'worktree': str(tree), 'state': merge.READY, 'reason': '',
                            'ready': time.time(), 'deadline': time.time(), 'seq': time.time_ns()})
    result = merge.merge_due(context('dispatch', repo, project='proj'), dispatch.store, dispatch.id, publish=True)
    assert result['merged'] and result['pushed'], result
    assert not (repo / 'snapshot.txt').exists()
    assert not (repo / 'draft.txt').exists()
    assert (tree / 'draft.txt').read_text() == 'later peer draft\n'
    assert git(repo, 'show', '--format=', '--name-only', 'HEAD') == 'feature.txt'
    assert git(repo, 'rev-list', '--count', 'HEAD') == '2'


def test_advance_lands_beside_local_edits_and_keeps_staged_peer_work(repo):
    """The person's rule, 2026-10-21: a landing never refuses for a dirty checkout. A locally modified file takes the
    landed hunks and keeps its edit; a peer's staging elsewhere stays staged; paths clean in the checkout are taken as
    landed, added and deleted alike; the index is left showing only the peers' own work."""
    (repo / 'notes.txt').write_text('one\ntwo\nthree\nfour\nfive\nsix\n')
    (repo / 'gone.txt').write_text('gone\n')
    git(repo, 'add', '-A')
    git(repo, 'commit', '-qm', 'more')
    before = git(repo, 'rev-parse', 'HEAD')
    tree = Path(merge.worktree_for(repo, 'advance-test'))
    (tree / 'notes.txt').write_text('ONE\ntwo\nthree\nfour\nfive\nsix\n')  # the landed hunk, at the top
    (tree / 'added.txt').write_text('added\n')
    (tree / 'gone.txt').unlink()
    git(tree, 'add', '-A')
    git(tree, 'commit', '-qm', 'ticket')
    landed = git(tree, 'rev-parse', 'HEAD')
    (repo / 'notes.txt').write_text('one\ntwo\nthree\nfour\nfive\nSIX\n')  # a peer's unstaged edit, at the bottom
    (repo / 'README.md').write_text('staged peer\n')  # a peer's staged work the landing does not touch
    git(repo, 'add', 'README.md')
    passed, report = merge.advance(repo, landed, before)
    assert passed and report == '', report
    assert git(repo, 'rev-parse', 'HEAD') == landed
    assert (repo / 'notes.txt').read_text() == 'ONE\ntwo\nthree\nfour\nfive\nSIX\n'
    assert (repo / 'added.txt').read_text() == 'added\n' and not (repo / 'gone.txt').exists()
    assert git(repo, 'diff', '--name-only') == 'notes.txt', 'only the peer\'s edit is unstaged'
    assert git(repo, 'diff', '--cached', '--name-only') == 'README.md' and git(repo, 'show', ':README.md') == 'staged peer'


def test_advance_keeps_a_file_whose_local_edit_clashes_with_the_landed_hunks_and_names_it(dispatch, repo):
    """A clash never stops the landing or reopens the ticket: main moves, the file keeps its local edit, index entry
    included, and a factual notification names the conflicting file."""
    from metaform.modules.dispatch.orchestration import UPDATES
    before = git(repo, 'rev-parse', 'HEAD')
    tree = Path(merge.worktree_for(repo, 'advance-test'))
    (tree / 'README.md').write_text('ticket\n')
    git(tree, 'commit', '-qam', 'ticket')
    landed = git(tree, 'rev-parse', 'HEAD')
    (repo / 'README.md').write_text('peer\n')
    passed, report = merge.advance(repo, landed, before, ctx=context('dispatch', repo, project='proj'),
                                   work_id=dispatch.id)
    assert passed and 'README.md' in report, report
    assert git(repo, 'rev-parse', 'HEAD') == landed
    assert (repo / 'README.md').read_text() == 'peer\n' and git(repo, 'show', ':README.md') == 'base'
    with Store('proj', module='dispatch').tables(write=False) as tx:
        line = tx.get('session_lines', {'session_id': UPDATES, 'name': f'notification:landing:{dispatch.id}'})
    assert line is not None and 'README.md' in line['text'] and 'kept as they were' in line['text']
