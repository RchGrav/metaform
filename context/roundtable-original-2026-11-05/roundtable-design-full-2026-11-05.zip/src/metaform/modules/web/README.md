# web

Metaform's one web GUI for the user: one server per Metaform home, serving every registered project.

## Writes

On loopback, a write runs when its Origin is the page's own; the server does not judge who sent it. Metaform has no
permission system of its own: the harnesses it orchestrates have theirs, and the page relays a harness's permission
request to the person (2026-10-25).

Activate and Remove beside the base chooser ask first, in the server's own caution (`/api/base-preview`), which names
what the base being left or removed holds; `/api/activate-base` runs only with `confirm` true.

## Purpose

People see the map in a browser. `metaform web` starts the server and prints its address; run again from any folder, it prints the address it already runs at. `metaform web stop` stops it. Before an intake, the intake's own instructions have the agent start it with the `web_start` tool and tell the user the address, so the map can be watched as it is recorded. It ships enabled.

`metaform web serve v000001 v000002` reconstructs saved web variants and serves their static files together, each from its own temporary folder on an OS-assigned port at `127.0.0.1`, PROJ-019. It prints `<variant id>  http://127.0.0.1:<port>/` for each; open those addresses in browser tabs. `metaform web serve all` serves every variant of the latest origin, or add `origin=<id>` to select an earlier origin. The command runs in the terminal until Ctrl+C, then closes its listeners and removes its temporary folders. The Metaform GUI remains its own server on its fixed port.

Clear project in the header clears the selected project as `metaform clear project <project> --confirm` does, PROJ-025 and VIEW-019: it shows the command's caution, what goes and what stays, asks on the page, then clears through the same chassis operation and names any file it could not remove with what to do. Every open page then shows the project with no metaform until the next intake. The conversations with agents stay, a restore keeps what was said since its backup, and the chat dock keeps every thread and reaches the person's own agent with no map: the empty stage offers the intake and never requires it first, VIEW-045 and PROJ-026.

The `colors` picker in the header chooses one of the page's color themes, dark and light, VIEW-023. Each theme is one block of `page/app.css`, `:root[data-theme="<name>"]`, and defines the same colors; the script and the other rules hold none. In every theme each node, link and line holds 3 to 1 against its background, and each 2D label 4.5 to 1 against its box. The choice is kept in the browser's local storage and changes no setting. `page/theme.js` applies it before the page is drawn.

The page shows each node's condition from its work records, MAP-046: a node with an open `missing` record is drawn ghostly, at 70% opacity, and turns solid when its task is done; one with an open `broken` record flashes red until it is resolved; `exclude` keeps its look. The panel lists the selected object's records with their note, task, held and reviewed flags, and the resolution once done. `/api/work` is the store's `work` read.

Board opens the project's Kanban. Prioritize tasks with each card's Top, Up and Down buttons or by dragging it within its column. Higher cards come first; the stored order survives reopening the board and determines distribution and an agent's next waiting ticket, To do before Backlog. Reordering within a column keeps the ticket's assignment, progress and completion.

Add Task and each board card offer Eligible agents, defaulting to Any agent. Choose one or more agent types, or restore Any agent. The card shows the choice, saved through `/api/eligible` as the map module's ticket setting. The Start window enables a ticket only for an eligible agent. Start all selects eligible tickets before choosing one per glyph, leaving skipped cards' assignments and order intact.

Add Task can start the new ticket immediately: check Start an agent now and choose Claude Code, Codex or Google Antigravity. Add Element uses the same ACP dispatch for its validation ticket, with the validation prompt kept verbatim. A launch failure leaves the recorded ticket available on the board for another attempt.

Agents are started explicitly from the page's session controls or the assigned-task API. `GET /api/tasks`
discovers task metadata, `GET /api/task-definition?name=...` reads one canonical definition, and
`POST /api/task-assign` starts the selected task with its supplied context and skills. Default chat opens the
`user_agent` task. The named task definitions and their exact prompts are documented in [tasks](../tasks/README.md).

`GET /api/worker-board` supplies the live paired project agent panel: agent name, average rating, reported context
percentage and checklist completion, followed by Next, Current and Past task phrases and canonical node names.
The board reopens temporary SQLite records across server restarts and page refreshes. Workers keep their native
session while idle; messages and partner-completion events wake them through the native event path.

In the large area, the 2D map opens fitted to the whole diagram and eases to each new fit as nodes arrive or go. Clicking a node switches to a readable fit: the whole diagram while it fits above the minimum text size, otherwise centered on the selected node at that minimum. Keys 1 to 9 set the minimum from 8 to 24 px, 2 px apart; 5, 16 px, is the default. Fit, F and Home return to the whole diagram. Wheel zoom leaves both modes and holds the person's zoom until another click or Fit. In the small area, selection keeps the person's zoom and Fit cycles the views described by VIEW-008. Camera moves and wheel zoom ease in and out; dragging interrupts a move and follows the hand.

Implemented tickets with a verified saved candidate expose `Merge` on their board card and inspector, including
Done tickets. The action pins project, base and candidate to `POST /api/ticket-merge`. Dispatch integrates locally,
cleans a safe ticket worktree, then finishes an open ticket. Requests never push. Dirty
or ambiguous worktrees retain their files and show `Clean worktree` with the outstanding reason. Request state
disables repeat clicks across card redraws and the inspector. Unsaved inspector text remains intact. Scoped
ticket events refresh the board. Ordinary direct closure remains available.

## Template version

Started from template 0.3.0.

## Declaration

`SUPPORTED_OS = ('linux', 'macos', 'windows')`, `DEPENDENCIES = ()`, `SHIPS_DISABLED = False`. `MODULE` declares `start`, its default verb, `stop`, the CLI-only `serve`, and a status hook. It subscribes to nothing. Its panes are the page's two views of the map, `map2d` in the main area and `map3d` above the node's tabs on the right, and the workflow runs, `runs`; the other modules declare the rest, under Toolbar and panes.

## Common base used

`metaform.module` for the declaration, `Context`, `Status`, `Stop` and `Subscription`; `metaform.settings` for its three settings; `metaform.home` for the home's folder and the registered projects.

## Prompts

`resources/prompts.xml` holds `connect`, web's line in the connect message; `instructions`, returned by `metaform_instructions` with module web; the mascots' personas, `persona_<character>`; and `commands`, the `web` slash command.

## Verbs

- `start`, the default, so `metaform web` runs it: when this home's server answers at the address in `run/web.json`, returns `state: running` with its address; when the watchdog in `run/web-watchdog.json` still runs while its server does not answer, returns `state: restarting`; otherwise checks the port and bind address are free, starts the watchdog, `watchdog.py`, as a process detached from the terminal with a pipe as its standard output, which starts `server.py` and passes on its one line saying it listens, waits on the pipe for that line, then asks the server once, and returns `state: started` with its address. With the hold tool on the PATH, or `METAFORM_HOLD` naming it (empty for none), the watchdog is placed as the hold call `metaform-web-<port>` and says it through a named pipe in `run/`; `stop` purges that call once it has ended. The wait is one wait for a message, limited to 15 seconds so the command never hangs on a server that neither answers nor ends, QUAL-015. On a bind address other than loopback the address ends with `?t=<token>`, and `token` is returned too. A port held by another program stops with `Next: metaform set --web-port <port>`; an address it cannot bind stops with `Next: metaform set --web-bind <address>`. Tool `web_start`.
- `stop`: opens the recorded server's events stream, ends the watchdog, which ends its server (on Windows, or with no watchdog, it ends the server itself), reads the stream until the system closes it with the process, removes `run/web.json` and `run/web-watchdog.json`, and returns `state: stopped`, or `state: not running`. Tool `web_stop`.
- `restart`: hands the stop and the start to a process of its own, `restart.py`, so the page comes back even when the caller ends between the two, as an agent's session can. It reads the bind address and port from `run/web.json`, or the watchdog's record, stops the server, waits for the exits of the server and its watchdog as the system's own events, and starts a new watchdog and server on that same address, keeping the developer level in `run/web-debug` and the project the page opens on; a port setting changed meanwhile waits for the next `start`. With none running it is a `start` from the calling folder's settings. The new process loads the Python code on disk now. The answer carries `pages`: an open page reconnects on its own through its live stream, and offers a reload when the code changed. Without the hold tool it is a detached process in a session of its own that forks once and lets its parent end, so a kill of the caller's process tree or group misses it; with hold it is the hold call `metaform-web-restart-<port>`, purged by the next restart. It says how the restart went in one line of JSON, through its pipe or a named pipe under hold; `restart` waits for that at most 60 seconds and returns `state: restarted` with the address, the start's error, or `state: restarting` when the wait ran out and the restart goes on alone. Each step is written to `run/web.log`. Tool `web_restart`.
- `serve <variant id>... | all [origin=<id>]`: reconstructs through the chassis's `Store.extract`, then serves each folder's static files on a separate OS-assigned loopback port. A selector waits for connections without polling. Ctrl+C closes the servers and removes the temporary copies. CLI only; this command runs for the lifetime of the comparison.

## Settings

- `--web-port`, a number, default 7433, for the whole home.
- `--web-bind`, text, default `127.0.0.1`, for the whole home. At a wildcard address, `0.0.0.0` or `::`, the printed address uses the machine's host name.
- `--web-panes`, on or off, default on, for the whole home: lay the page out by the workspace, its toolbar, docked and floating panes and Window menu. The workspace's Default is the page as written, drawn by the page itself with the toolbar's row above it, so turning it on changes nothing until the person arranges something else. Off keeps the page as written with no toolbar and no Window menu.
- `--web-node-shapes`, on or off, default on: each element drawn in the shape of its artifact type, the first segment of its address, in 2D (Mermaid shapes) and 3D (geometry, the same glass): code a box, document a page, media a screen, data a cylinder, collection a stack, upstream and downstream cones.
- `--web-flow-seconds`, a number, default 30, and `--web-idle-flow`, on or off, default off: how long the dots along the joins flow after the map was last touched or changed; after that the 3D map draws no frame until something moves, so an idle page costs nothing. On, the slow flow goes on for as long as the page is open, as before.
- `--web-chat-details`, on or off, default off, for the whole home: show the agent's work in the chat, its tool calls with their details, the calls its permission prompts approved, and its thinking. Off, a thread shows only what the agent says to the person: its messages and the lines it says on the map with `web_say`, each once, with its permission requests, its questions, its notices and the views its Metaform calls show. W on the page shows or hides them for that page until it is reloaded, every open thread at once, and saves nothing.
- `--web-theme`, a choice of `space`, `black`, `midnight`, `graphite`, `plum`, `forest`, `ember`, `paper`, `mist`, `glass` and `tinted-glass`, default `space`, for the whole home: the page's theme, `space` drawing the 3D map in outer space (`page/ultra.js`). The View menu, U and the settings screen choose it, and only the person's choice writes it; until a theme is chosen each browser keeps the one it last showed. It replaced `web_graphics` in the settings cleanup of 2026-10-15, which the page had rewritten from the theme.
- `--web-debug`, a choice of `off`, `info`, `verbose` and `trace`, default off: the page's developer detail. `metaform web start --web-debug <level>` starts the page with it for that run, as written to `run/web-debug`; the page takes the more detailed of that and the setting. Off shows none of it. `info` logs each read and write of the page to the browser console and adds the developer panes, under the workspace: Prompts sent, every prompt Metaform and each enabled module would send, read-only, with the comment above it saying when it is sent, its size and the budget it is held to, from `GET /api/debug/prompts`; and Traces, the page's reads and writes with their status and time. `verbose` adds the events heard; `trace` adds each raw response. `--debug` stays the chassis's switch that asks agents to report, so the web module's is `--web-debug`.

## The person's view

How the person's page looks right now is not configuration: `view.py` keeps it per account behind a Node's gate, and the owner's otherwise, in `<home>/web/view.json`, and it is changed from the View menu, the map bars and the keys (`?` lists them). `GET /api/view` answers `{view: {key: value}}`; `POST /api/view` with `{key, value}` keeps one checked value, `null` returning it to its default. Any account keeps its own, so the route is a read for its class; an account reads the owner's view under its own. The keys are `web_signs` (`outward`, the default, each name a sign standing in the scene, or `facing`; the default was `facing` from 2026-10-15 to 2026-10-17, and the one-time move of kept `outward` to `facing` is gone), `web_lens` (`natural`, `wide`, `fisheye`), `web_flow_mode` (`off`, `hover`, `selected`, `all`, `live`), `web_map_depth` (a number of levels, `all`, or `auto`, the default since 2026-10-17: the whole map up to 200 parts, a larger one collapsed to one level past the least that draws a join; at any depth the branches down to the parts of taken tickets, of agents at work and of the selection open, and close again when the work is done or the selection goes), `web_flow_edges` (on or off), `web_map_direction` (`auto`, `across`, `down`), `web_hover_info` (`name+summary`, `name`, `summary`, `off`), `web_node_zoom` (on or off), `web_agents_window` (`auto`, `open`, `hidden`), `web_physics` (`organic`, `flat`), and the workspace: `web_toolbar`, `web_layout` and `web_workspaces`, JSON text in the shapes under Toolbar and panes, and `web_workspace`, the one in use. They were global settings until the settings cleanup of 2026-10-15 (ticket 0d9e3882); the web module's start carries any stored value over once per home and removes the old rows, so nobody's view changed; a read writes nothing. `set`, `config --show`, the settings screens and the agents' set list no longer show them.

## The server

`server.py` runs the standard library's threading HTTP server. Every request must carry a `Host` header naming the server's own address and port; on a wildcard bind only the port is checked, since the token guards every request there. On a bind address other than loopback, every request needs the home's token, kept in `run/web-token`: as `?t=` on the page URL, which also sets an `HttpOnly`, `SameSite=Strict` cookie, as that cookie, or as the `X-Metaform-Token` header. It serves `page/` at `/`, `vendor/` under `/vendor/`, `/api/server` with its process id and home, `/api/health`, answered before any module refresh or store, with the slowest request running and what it waits on, whether a page read is slow (3 s) or stuck (20 s, answered 503), whether a watchdog keeps the server and the restart that started it, `/api/demo` with the card `metaform demo` writes into its own home, and `demo: null` in any other, `/api/projects` with every registered project, `/api/clear-preview` with what clearing a project removes and keeps, each read of the data access object by its query name under `/api/<read>`, such as `/api/where`, `/api/work` and `/api/intake-recording`, with `/api/node` carrying what the modules add to a node's read as `map node` does, and the stored prompts' reads. The memory module's reads are `/api/memory-graph`, the whole graph with each join saying whether its memory shows at its node in the page's layers, `/api/memory-orphaned`, for the orphaned menu, and `/api/memory-note` for a node's one note; each runs the memory module's command in the server, as a tool call runs it, VIEW-031 and VIEW-034. `/api/events` is one server-sent events stream per open page, held open. The server's loop waits for a connection with no timeout and nothing in it polls. Every GET but the streams (`/api/events`, `/api/voice/*`, `/api/build*`) runs in a worker thread and is answered within 15 s, else 503 with what it waits on, since a browser opens only a few connections to one server and a read that never answers would stop every other. The watchdog, `watchdog.py`, asks `/api/health` every 5 s and starts the server again when its process ends, when a read is stuck, or after 20 s with no healthy answer, writing each restart and its cause to `run/web.log`; runners are not the server's children, so agents go on through a restart. Its seventeen writes, VIEW-011, are POSTs from its own page, with the page's `Origin` and a JSON body: `/api/apply-layers`, `/api/save-prompt`, `/api/clear-project`, which clears only with `confirm` true, `/api/remove-project`, `/api/answer`, `/api/reopen`, which reopens a question answered by mistake, `/api/read`, `/api/task`, `/api/element`, `/api/restore`, `/api/note`, which writes the node's one note with `memory note`, `/api/memory`, which runs memory commands that write in order, `/api/move`, and `/api/dispatch-start`, `/api/dispatch-message` and `/api/dispatch-stop`, which run `metaform dispatch start`, `message` and `stop` in the project's folder, with a message's text after `--`, and `/api/dispatch-prompts`, VIEW-039. `GET /api/dispatch-agents` lists the agents dispatch starts, with whether each one's start command is found on this machine and which is the default, and its POST sets the default; `/api/dispatch-intake`, `/api/dispatch-resume`, `/api/dispatch-permit` and `/api/dispatch-configure` run `metaform dispatch intake`, `resume`, `permit` and `configure`, with an intake's text, a permission's option and a setting's value after `--`, VIEW-039 and VIEW-045. After a write that changed the map the server fires `map.changed` on the module event bus, as the chassis does after a command, VIEW-018, and pushes each change `changes.announce` returns to every open page. It writes what went wrong to `run/web.log`. `/api/report`, classed admin, builds the problem report `metaform report` makes, with the page's browser and its console errors since it opened, and hands it back for Report a problem…, in the View menu, to save as a download; nothing is written in the home or sent, BASE-045.

Behind a Metaform Node's gate the server runs with `--origin https://<domain>` and the per-deploy secret in `METAFORM_GATE_SECRET`, which it reads once and removes from its environment so nothing it starts inherits it; one without the other refuses to start. Then every request must carry the secret in `X-Metaform-Gate`, which only Caddy adds, and name the public origin's host; a write's `Origin` must be the public origin; and each route has a class, `read`, `write`, `dispatch` or `admin` (`route_class`), served only when the gate's `X-Metaform-Classes` for the signed-in account includes it. A write not yet classed is `admin`. Without `--origin` nothing of this applies: the page is the person's own.

What an agent is given is shown as the agent is given it, MCP-037, so the person and the agents see the same thing. `/api/brief?address=` is a node's brief, `metaform.module.node_view`, the same answer the MCP map view's `brief` read gives: the text an agent reads at `metaform://<address>` exactly, from `metaform.module.node_brief`, the read the MCP server serves, with its size against the folder's `node_summary_bytes`, the latest number taken there and the items numbered there, newest first, each with its number, title and why, forty at a time, paged as MCP pages a list: a page with more after it gives `nextCursor`, passed back unchanged as `cursor=`, of the kinds named in `kind=` when given, from `metaform.module.node_items`, the list the MCP server's views read too: one read per module through its `items_at` hook, never one per number. It is read in the folder's own layers and active base, as an agent reads it, whatever the page shows. `/api/item?item=<address>#<n>` is one item as an agent reads it at `metaform://<address>#<n>`, its text and fields, its links among them, `metaform.module.item_view`, the answer the MCP views' `item` read gives too. `/api/agent-view` starts the folder's own MCP server, the one AI tools are registered with, and reads it over MCP as an agent connecting does, as the MCP Inspector reads a server: the server/discover result with its capabilities and the instructions sent at connect, counted in characters against the 2,048 Claude Code keeps; `metaform://glossary`, with the bytes its tool index takes; every tool, resource, resource template and prompt the lists give, each entry as received with its size, the tools largest first; with `address=` that node's brief; and what an agent pays before its first call, counted as Claude Code sends it to the model, each tool named `mcp__metaform__<tool>` with its description and input schema only: with tool search, Claude Code's default (the connect message, the tool names and any tool marked `anthropic/alwaysLoad`), with every tool loaded as the connect message asks, and without tool search (every tool in full). `/api/mermaid` is the map as a Mermaid flowchart from `metaform.outline.mermaid`, the writer `map mermaid` uses, with the page's layers, `direction=`, the roots the page leaves out, `leave_out=`, and `labels=`; a diagram past Mermaid's default limits also carries the notice in `X-Metaform-Notice`, which the page shows. On the page these are the side column's Brief tab, with its items by kind, each opened and its links to other memories followed to their node and back; What an agent sees…, from the Brief tab or the Agents menu, a dialog with what is paid before the first call, kept to the web GUI: in an AI tool's map view the brief draws neither it nor Copy as Mermaid, then the connect message, the glossary, the tools, each opened to its entry and schema, the resources and templates, the prompts and the brief, each with its size; and the Export menu's Mermaid (.mmd) and Copy as Mermaid. An item numbered past the latest this browser was shown at an address is marked unseen, apart from the agent's own New in the brief. The side column's tabs are the panes declared in the node group, map's Object, Brief and Provenance and the chassis's Prompt, in their declared order and with their titles and descriptions from `/api/workspace`.

The roundtable stage, a mode of the 3D map (code.interface.graphical#131, `page/app/roundtable/stage.js`), shows a table of the roundtables module debating the person's question about the selected part: the Roundtable button on the part's Work row, or T, asks the question and takes the default seats or the person's own; the 3D map sinks back, dimmed, scaled back and blurred by CSS and still drawn every frame; the seats stand as figures in an arc on a canvas of their own, the floor's turn in a word bubble from the one bubble layer; the ideas, rankings and answer grow above, and the question, the table's state and the whole transcript sit below. The person only watches: the seats talk among themselves, and preparation follows the creation choice after discussion ends. Leave or Escape puts the map back as it was. `GET /api/roundtable?project=` gives `roundtables_seats`; with `table=` and `after=`, the table's events after that seq, and with `whole=1` its status too. `POST /api/roundtable-open {project, address, topic, seats?, automate_ticket_creation?}` opens a table, answering once its follower has; it is a dispatch-class route. A change whose kinds are all the roundtables module's reads no map: the stage reads its own table's events, once for a burst, when the change names `roundtables:<table>`.

## Toolbar and panes

The page's toolbar, its panes and their places are one system, served by `workspace.py` under `/api/workspace`. Modules and the chassis declare what they offer, `ToolbarItem` and `Pane` of `metaform.module`, in their own `Module(toolbar=, panes=)`, the chassis in `metaform/panes.py`; this module lays the person's arrangement over those defaults and keeps it in the person's view, `view.py`. The design follows what works in Creative Cloud (Photoshop's Edit Toolbar with its Extra Tools, tool groups, Restore Defaults; panels docked, grouped as tabs and floated; named workspaces with Reset and a built-in one that cannot be deleted), VS Code (views contributed with a default container, moved by the person, Reset View Locations) and JetBrains (tool windows anchored left, right or bottom; layouts with a fixed Default). A contribution is a record with an id, a title, a one-line why as its tooltip, an icon and a default place; the person's arrangement is stored apart, keyed by id; what a module adds later lands in its declared place; a disabled module's tools and panes go and come back where they were.

An id is `<owner>.<id>`: `map.brief`, `chassis.search`. Every request below names the page's project as `?project=<id>` or in its body, since the project's folder decides which modules are on.

### Reads

`GET /api/workspace?project=<id>` answers with everything the page draws and edits:

- `items`: each tool, `{id, owner, title, description, icon, icon_url, action, selection, group, placement, order, shortcut}`. `icon` is a built-in name, or null with `icon_url` the module's SVG. `action` is `{kind: "verb", verb, arguments, effect, caution}`, `{kind: "pane", pane}`, `{kind: "page", page}` or `{kind: "link", url}`. `selection` is not null when the tool acts on the selected node, and the tool is then off while nothing is selected. `description` is the tooltip.
- `panes`: each pane, `{id, owner, title, description, icon, icon_url, content, selection, area, group, visible, order, min_width, min_height}`. `content` is `{kind: "page", page}`, a view the page draws; `{kind: "verb", verb, arguments, url}`, a read verb's result; or `{kind: "resource", url, type}`, a file of the module.
- `toolbar`: the arrangement to draw, `{"toolbar": [[id, ...], ...], "extra": [id, ...]}`. Each inner list is one slot: its first tool shows, the others are behind it. `extra` holds the tools behind the toolbar's last slot, `…`.
- `layout`: the panes to draw, `{"areas": {"left"|"main"|"right"|"bottom": {"size": px|null, "groups": [{"id", "tabs": [id, ...], "active": id|null, "size": share|null}]}}, "floating": [{"pane", "x", "y", "w", "h"}], "off": [id, ...]}`. Each group is one pane area of tabs, stacked in its area in order; `size` is an area's width (left, right) or height (bottom) in CSS pixels, null for main, which fills; a group's `size` is its share of its area, null for an equal share. A pane in `off` keeps its place and is not drawn: turning it on puts it back there. A floating pane with null coordinates is placed as `place()` places a window today.
- `defaults`: the same two built from the declarations alone, for Restore Defaults.
- `workspace` and `workspaces`: the active one and every one, `Default` first.
- `icons` and `areas`: the built-in icon names and the five areas, `float` last.

`GET /api/workspace/pane?project=<id>&pane=<id>&selection=<address>` runs a verb pane's verb, as a tool call runs it, with the page's layers when `layers=` is given as the other reads take it; it answers `{pane, result, chars}`, `chars` the length of the result's JSON, what an agent is handed. Read it when the pane shows, when the selection changes and on each `map.changed` event; a pane with `selection` and nothing selected shows that it follows the selection. `GET /api/workspace/file/<owner>/<path>?project=<id>` sends an icon, a pane's file or a linked file a contribution names, and nothing else; HTML comes with the `sandbox` policy, so show it in `<iframe sandbox src=...>`, where it has no reach into the page.

### Writes

Each is a POST from the page with a JSON body, the checks of every write of the server, and answers with the whole read above; every other open page hears `{topic: "workspace"}` on its stream and reads again.

- `/api/workspace/arrangement {project, toolbar?, layout?}` saves what the person left, in the shapes above. Ids of modules turned off now are kept in the view from before, so they come back in place.
- `/api/workspace/reset {project, part?}`, part `toolbar` or `layout` or both: back to the active workspace as it was saved; for Default, the declared defaults.
- `/api/workspace/save {project, name}`: the current toolbar and layout as a workspace of that name, replacing one, and active. Default is never saved over.
- `/api/workspace/select {project, name}`: that workspace active, its toolbar and layout the current ones.
- `/api/workspace/delete {project, name}`: deletes one; Default cannot be deleted. Deleting the active one keeps the current arrangement, under Default.
- `/api/workspace/run {project, item, selection?, confirm?}` runs a `verb` tool's verb with its fixed arguments and the selection, and only a declared tool's. A caution verb answers 409 with its caution and `confirm: true`: ask with `confirmAct` and send again with `confirm: true`. It answers `{item, result}`; show the result in a window of its own, or offer a text result as a file to save.

### What the page builds

The page reads `/api/workspace` once its project is chosen, and draws from it alone; nothing of the toolbar or the panes' places is kept in local storage any more. The text size stays in the browser, as a preference of that screen; the theme is the setting `web_theme` once the person picks one. The arrangement is the person's view, the same in every project. Use the page's existing parts: `splitter()` for the area and group splits, `place()` and `movable` windows for floating panes, writing their place to `layout.floating` instead of `metaform.places`, `confirmAct()` for a caution, and the overlay stack for menus.

- The toolbar: one row of slots under the header, each slot's shown tool as an icon button with its title as the label where there is room, the description as the tooltip and `aria-label`, and the shortcut as `aria-keyshortcuts`. A slot of several tools carries a small corner mark; a long press or the context menu opens its flyout, and choosing a tool there makes it the slot's shown one, saved. The last slot, `…`, opens the extra tools. A pane tool is pressed while its pane is on and shown; clicking it then turns the pane off. A tool whose pane or page command this page does not carry is left out.
- Edit Toolbar…, from the Window menu and the toolbar's context menu: a dialog of two lists, Toolbar and Extra tools, each tool with its icon, title and why. Drag a tool between the lists or within them; drop it on another tool to share that slot, out of a slot to give it its own. Restore Defaults puts `defaults.toolbar` in the dialog, Clear Tools moves every tool to Extra tools, Done saves with `/arrangement`, Cancel leaves it as it was. The same dialog works with the keyboard: Up and Down move the focus, Alt+Up and Alt+Down move the tool, Enter moves it to the other list.
- The Window menu, in the header: every pane with a check, on or off; then Workspaces: each workspace with a check on the active one, New Workspace…, which asks for a name and saves, Reset <active name>, and Delete Workspace…, which lists all but Default; then Edit Toolbar….
- Panes: four docking areas around the main one, left, right and bottom, and floating windows. Each area holds its groups stacked, each group a tab strip over one pane; the tabs follow `tabs`, showing those not in `off`. Drag a tab onto another group's strip to join it, onto an area's edge to start a group there, where blue drop zones show while dragging, or away from every zone to float it; Ctrl while dragging keeps it from docking. A tab's context menu has Move to Left, Main, Right, Bottom and Float, and Close, which turns it off. A pane is never drawn smaller than its `min_width` and `min_height`. An area with no group shown takes no room. Swap, today's button on each map, now exchanges the places of `web.map2d` and `web.map3d` and saves the layout.
- Views the page draws, by `page`: `map2d` (today's small 2D map), `map3d` (the 3D stage), `object`, `provenance` and `prompt` (today's side panel tabs), `settings` (today's settings dialog, as a pane), `dock` (the chat), `board` (the Kanban), `messages` (the questions waiting for the person).
- Commands the page runs, by `page`: `search`, `export-markdown`, `export-xml`, `build`, `shortcuts`, `layers` (the layer list), `add-task` and `add-element` (their windows, at the selected node), `dispatch-node` (Add Task at the selected node with Start an agent now checked), `agents` (the Agents menu), `intake` (Run an intake), `orphaned` (Orphaned memories).
- Views the page draws only as panes, `page/views.js`: `messages`, the questions and messages waiting for the person, oldest first, each opening its node; and, with `--web-debug`, `dev-prompts` and `dev-trace`.
- A verb pane's content, `content.kind` `verb`, is drawn by the workspace from `/api/workspace/pane`: the result as every surface shows it, text as text, a list as a list, an object as its fields, with its length in characters, what an agent is handed, and the JSON as an agent reads it folded below; read again as the pane shows, when the selection changes for a pane that follows it, and on each `map.changed`. A `resource` pane shows its file, an HTML one in a sandboxed frame.
- A verb tool whose verb takes nouns its fixed arguments and the selection leave open carries them as `action.form`, each `{name, help, kind, required, many, choices?}`; the page opens a small form typed by them, and `/run` takes the person's `values`, only those fields, the fixed arguments and the selection staying the tool's. A tool's `shortcut` runs it from the keyboard, by the key's place, and is listed under Tools in the `?` reference.
- The page's own parts: `page/workspace.js` draws the toolbar, the Window menu, the areas and groups, floating panes, Edit Toolbar… and the forms; app.js lends it the views, commands and windows, and a window of the page shown as a pane leaves the overlay stack while docked. Every built-in icon of `module.ICONS` is drawn.
- Settings, from the header's gear in one click or All settings… in the Agents menu (`page/app/settings/screen.js`): the categories down the side and the one chosen on the right, the only part that scrolls. It always opens on Essentials, one screen of what a person sets up and changes day to day: the settings declared `essential`, in their order, with the colour theme, the mascot's voice, the phone's status (its Check runs `GET /api/phone-check`, `metaform twilio status`, only when pressed) and the project folder among them, each linking to its category. Then General, Agents, Budgets, Agent options, Map and display, Voice and speech, Phone, Integrations and Advanced, each setting on the page its `category` names, else its module's `settings_category`, under its `heading`, section or module name; Advanced folds each module, and Modules, the on and off switches, is last, under Advanced. Find a setting searches every category, and Enter goes to the first found. Each row shows its plain label, whether it is the default, set here, inherited from a named folder or glued, Global, and Risky for a risky choice in force; More shows its switch, key, whole help and Glue. A number shows its unit; ElevenLabs' voices are listed from the account only on List voices, `GET /api/speech-voices`. The screen reads again whenever a setting changes elsewhere.
- Broadcast, from Broadcast… in the header's Agents menu (`page/app/agents/broadcast.js`): a small window, not modal, with a text box (Enter sends, Shift+Enter makes a new line), "include my chat agent", off by default, and Send, disabled with no agent running, when it says so. Send posts `/api/dispatch-broadcast {text, system}`, which runs `dispatch broadcast` once and tells every running session at once; the window lists each session told, its glyph, agent and ticket, delivered or failed with why, and the broadcasts kept on the project, `GET /api/dispatch-broadcasts`. Each receiving thread marks the person's bubble Broadcast.
- The header keeps one row while it can (`foldHeader`, `page/app/header/menus.js`): above 1100 px it measures its row and, only while the row does not hold everything, gives back room in steps, the search's icon alone, then tighter spacing, then no labels or padding, then shorter names, and folds its rest behind the menu button last. Text cut short with an ellipsis opens in place at a click or Enter through one helper, `expandCut` (`page/app/core/expand.js`), on Settings, the thread bar's task, agents' lines, tool call titles and Edit Toolbar…; a surface whose text can be cut calls it once on its container.
- On a screen narrower than 820 px the areas stack in the order main, right, left, bottom, and the layout is left as saved.

### The Default workspace

Default is the page as written. The 2D map fills the main area, where its names are read; on the right, the side column holds the 3D map, keeping the whole in view, over the node's tabs, where everything a person reads or types into is, since turning to the left to read is uncomfortable; the board, the settings and What the agent sees open as the page's own windows; the chat rests in its own dock. Arranging nothing else changes nothing a person knew, and every check written for the page holds with the workspace on.

| Area | Group | Tabs, in order (off at first in brackets) |
| --- | --- | --- |
| main | stage | 2D map |
| right, the side column's width | overview | 3D map |
| right | node | Object, Brief, Provenance, (Code), Prompt, (Memories) |
| right | chat | (Messages), (Glossary), (Chat) |
| float | | (Board), (Settings), (What the agent sees) |
| bottom, 280 px | none | |

While the arrangement is that one, one map in the main area and at one side the other map over a group of the node's tabs, `workspace.js` leaves it to the page as written, `classicFrame`: its side column, its splitters, its tabs and its windows work as they always have, the toolbar's row stands under the header and the Window menu in it, and which map takes the large area stays this browser's choice, as Swap made it. The board, the settings and What the agent sees open there as the page's own windows, and their tools and Window checks follow them opening and closing. Turning one of the node's tabs off takes it out of the strip; dragging the side column to the left moves the side's groups to the left area. Any other arrangement, a pane turned on beside them, such as Memories or the chat, or a tab moved with its menu, is drawn in the workspace's areas, with the maps where this browser had them; back to that arrangement, the page as written comes back, every element where it stood.

The default toolbar, in order: Search; Node brief; What the agent sees; Layers; Board; Add task with Add element behind it; Chat; Agent on this node; Memories; Run an intake; Settings. Extra tools: Export Markdown, Export XML, Export Mermaid and Copy as Mermaid, the export group, each a command of the page, Build, Agents, Orphaned memories, Keyboard shortcuts. Each, and why it earns its place:

- Search, chassis: finding a node by its words is the fastest way into a map too large to scan.
- Node brief, map: everything held at a node, in full, for the person, `map where contents=true`.
- What the agent sees, map: the node exactly as an agent is handed it, counted, with its length, so the person sees what a call costs an agent's context, `map where`.
- Layers, map: which knowledge shows changes every read; choosing it is constant.
- Board, map: the tickets in priority order are the work itself.
- Add task and Add element, map: the two ways a person writes onto the map, one slot.
- Chat, dispatch: the person's line to the system agent and every agent at work.
- Agent on this node, dispatch: from a node to an agent working on it in one step; it opens the page's dialog, since starting an agent runs in the person's environment.
- Memories, memory: what agents learned at a node, read beside it; knowledge attaches to the receiving element.
- Run an intake, intake: a map starts with an intake and is checked against the project with another.
- Settings, chassis: every setting and module of the folder without the command line.
- Exports, chassis and map: the map as a document to hand on, Mermaid for drawing it in docs and reviews.

A code map pane is to come from the module that builds it; the tools and the layout take it as they take any contribution.

## Events

Project startup initializes module-owned background services and native runner-death observation.
Map and worker-board events are forwarded to open pages. Opening an event stream or changing settings reads and
updates the selected state; agent work starts through explicit session or assigned-task commands.

Hears `map.changed`, which the chassis fires after any command that changes a project's map, VIEW-018, through the base's listener, BASE-053: the server opens it with `events.listen('web', ...)` once it listens, and each `map.changed` published in another process, a command, the MCP server or a dispatch runner, reaches it and is pushed to every open page, which redraws without a reload. The changes of the page's own writes are pushed from what `events.announce` returns. A change to a project no longer registered is not pushed, since a page has nothing of it to read. With no server running nothing listens, and nothing is sent.

Publishes `web.started` from `web start`, with `project`, `folder` and `state` (`started` or `running`), once the page answers, so a module that serves beside the page starts with it: the twilio module starts its phone bridge then, when the person has turned it on with `twilio_enabled`. A subscriber's failure never fails the start.

## Sync and async

Every verb is a plain function.

## Layers

None. The web GUI reads through the data access object and writes only what VIEW-011 names.

## Lifecycle and cleanup

No `start` or `stop` hooks, and no tasks. The server is its own process, detached from the terminal that started it; `metaform web stop` ends it, and so do logout and restart. Inside other Metaform commands only the `map.changed` subscriber runs, once per command that changed the map.

## Modules relied on

None by import. The web GUI reads through the chassis's data access object and settings. Its dispatch controls run `metaform dispatch` on the command line, so they work while the dispatch module is enabled and say `metaform enable dispatch` while it is not, VIEW-039.

## Systems supported

Linux, macOS and Windows. On POSIX the server runs in a new session; on Windows as a detached process with no console.

## Resources owned

An agent is named on the page by the name dispatch gave its session, first, then its ticket's number: in the agents key, the chat dock's head, tabs and list, and the Agents menu (`agentLabel`, `page/app/agents/dispatch.js`). A figure under the pointer, on either map, is named beside the pointer with the model and the thinking level its session runs, read from its settings as the dock's line shows them (`agentTip`, `page/app/map3d/readout.js`): one element, its words set only when the figure under the pointer changes, moved with the pointer, gone when the pointer leaves the figure; nothing is drawn on the figure.

`page/`, the GUI's HTML, CSS and scripts: `page/app.js` starts the page from its parts under `page/app/<area>/<part>.js`, each one area of the page and under 500 lines, each importing the part before it first so the parts load in one fixed order; and `page/agent-glyphs/`, the flat icon of each agent figure, Metaform's own, VIEW-039; and `vendor/`, the bundled libraries with their licenses, VIEW-003. Under the home: `run/web.json`, the running server's record, with its address, process id and nonce; `run/web-watchdog.json`, its watchdog's process, port and restarts; `run/web-token`, the token for bind addresses other than loopback; `run/web.log`, what went wrong in the server.

## Installed and direct wheel

The same in both; the page and the vendor files travel inside the module.

## Demonstration

```
metaform web
metaform web --json
metaform set --web-port 7500
metaform web stop
```

Roundtable creation offers `Automate Ticket Creation`, off by default. `/api/roundtable-open` accepts the boolean `automate_ticket_creation`. Enabled preparation finishes through a populated inactive board and saved execution outline without decisions. Default-off creation retains person-reviewed transitions. Neither choice automatically activates the prepared board.

The chat command `/mascot` opens the agent glyph picker. It stays closed across new contexts, elapsed time and conversation turns until requested. A glyph chosen for the system agent remains the person’s mascot across conversations.

Explicit `web_embody` also works for the live `conversation-system` session without a board ticket. The agent's own body supports movement and sight without changing the person's persisted mascot selection.
