"""The shared command line parser, CLI-001, CLI-003, CLI-004, CLI-015 and BASE-043.

Required nouns are positional, in order. Optional nouns are `name=value` words
in any order after them. A switch is a setting the verb reads: `--name` and
`--no-name` for a boolean, `--name value` or `--name=value` otherwise, or its
one-letter short form. `--confirm`, `--json` and `--help` are verb controls.
After `--`, every word is a plain noun.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

from . import settings
from .errors import Stop
from .module import Noun, Verb

CONTROLS = ('--confirm', '--json', '--help', '-h')
CONTEXT = ('project', 'layers')  # every module verb takes these for one call, as every tool does, CLI-021 and MCP-025


@dataclass
class Parsed:
    nouns: dict[str, Any] = field(default_factory=dict[str, Any])
    switches: dict[str, Any] = field(default_factory=dict[str, Any])
    confirm: bool = False
    json: bool = False
    help: bool = False
    unknown: list[str] = field(default_factory=list[str])
    fields: dict[str, Any] = field(default_factory=dict[str, Any])
    notices: list[tuple[str, str]] = field(default_factory=list[tuple[str, str]])


def convert(noun: Noun, raw: str, where: str) -> Any:
    """One noun's value from its word, BASE-035."""
    if noun.kind == 'int':
        try:
            return int(raw)
        except ValueError:
            raise Stop(f'{noun.name} is a whole number, not {raw!r}.', f'{where} --help') from None
    if noun.kind == 'bool':
        if raw not in ('true', 'false'):
            raise Stop(f'{noun.name} is true or false, not {raw!r}.', f'{where} --help')
        return raw == 'true'
    if noun.kind == 'json':
        try:
            return json.loads(raw)
        except ValueError:
            raise Stop(f'{noun.name} is JSON, and {raw!r} does not parse.', f'{where} --help') from None
    return raw


def parse(module: str, verb: Verb, words: list[str]) -> Parsed:
    where = f'metaform {module} {verb.name}'
    parsed = Parsed()
    positional: list[str] = []
    optional = {noun.name: noun for noun in verb.nouns if not noun.required}
    # A required noun named as name=value fills that noun, so `map citing key=path value=x` reads as written instead
    # of taking `key=path` as the key; after `--` every word stays positional, BASE-043.
    required = {noun.name: noun for noun in verb.nouns if noun.required}

    def unfilled(name: str) -> bool:
        """Whether a required noun is still to be given: not named already, and not reached by the positional words
        before it, which fill the required nouns not named, in order. A word such as `key=abc` after the positional
        word that fills key is that later noun's value, not a second key."""
        if name in parsed.nouns:
            return False
        waiting = [noun.name for noun in verb.nouns if noun.required and not noun.many and noun.name not in parsed.nouns]
        return name not in waiting or waiting.index(name) >= len(positional)
    ended = False
    index = 0
    while index < len(words):
        word = words[index]
        index += 1
        if ended:
            positional.append(word)
            continue
        if word == '--':
            ended = True
        elif word in ('--help', '-h'):
            parsed.help = True
        elif word == '--json':
            parsed.json = True
        elif word == '--confirm' and verb.caution:
            parsed.confirm = True
        elif word == '--all':
            raise Stop('--all is not a switch. all is an argument.', f'{where} all')
        elif word.startswith('-') and len(word) > 1:
            name, equals, inline = word.partition('=')
            if not name.startswith('--') and (len(name) != 2 or not name[1].isalpha()):
                raise Stop(f'{name} is not a switch; to pass it as a word, put -- before it.', f'{where} --help')
            found = settings.by_switch(name)
            if found is None or found[0].key not in (*verb.switches, *CONTEXT):
                raise Stop(f'{module} {verb.name} has no switch {name}.', f'{where} --help')
            setting, negative = found
            if setting.kind == 'bool':
                if equals:
                    raise Stop(f'{name} takes no value.', f'{where} --help')
                parsed.switches[setting.key] = not negative
                continue
            if not equals:
                if index >= len(words):
                    raise Stop(f'{name} needs a value.', f'{where} --help')
                inline = words[index]
                index += 1
            try:
                parsed.switches[setting.key] = settings.parse(setting, inline)
            except settings.SettingError as error:
                raise Stop(str(error), error.next_step or f'metaform help {setting.switch}') from None
        elif '=' in word and word.split('=', 1)[0] in required and unfilled(word.split('=', 1)[0]):
            name, _, raw = word.partition('=')
            if required[name].many:
                positional.append(raw)  # a noun of several words begins here and takes the words that follow
            else:
                parsed.nouns[name] = convert(required[name], raw, where)
        elif '=' in word and word.split('=', 1)[0] in optional:
            name, _, raw = word.partition('=')
            if not positional_complete(verb, positional, parsed.nouns):
                raise Stop(f'{name}= comes after the required nouns.', f'{where} --help')
            parsed.nouns[name] = convert(optional[name], raw, where)
        elif 'extra' in optional and '=' in word and word.split('=', 1)[0].isidentifier() and \
                positional_complete(verb, positional, parsed.nouns):
            name, _, raw = word.partition('=')
            parsed.fields[name] = raw
        else:
            positional.append(word)
    if parsed.help:
        return parsed
    _place(verb, positional, parsed, where)
    parsed.notices = keep_fields(module, verb, parsed.nouns, parsed.fields)
    return parsed


def keep_fields(module: str, verb: Verb, nouns: dict[str, Any], fields: dict[str, Any]) -> list[tuple[str, str]]:
    """Named fields the verb does not know, kept in the record's `extra`, BASE-043 and BASE-044.

    A verb with no `extra` noun keeps nowhere to put them, so they are ignored. Either way each is named once.
    """
    if not fields:
        return []
    named = ', '.join(noun.name for noun in verb.nouns if not noun.required)
    if not any(noun.name == 'extra' for noun in verb.nouns):
        return [(key, f'{module} {verb.name} has no noun {key}; it was ignored.') for key in fields]
    given = nouns.get('extra')
    if given is None:
        nouns['extra'] = dict(fields)
    elif isinstance(given, dict):
        nouns['extra'] = {**fields, **given}
    else:
        nouns['extra'] = {'value': given, **fields}
    return [(key, (f"{key} is not a noun of {module} {verb.name}; it was kept in the record's extra. Its named "
                   f'nouns are {named}.')) for key in fields]


def positional_complete(verb: Verb, positional: list[str], named: dict[str, Any] | None = None) -> bool:
    required = [noun for noun in verb.nouns if noun.required and not noun.many]
    return len(positional) >= len([noun for noun in required if noun.name not in (named or {})])


def _place(verb: Verb, positional: list[str], parsed: Parsed, where: str) -> None:
    remaining = list(positional)
    for noun in verb.nouns:
        if noun.many:
            values = [convert(noun, word, where) for word in remaining]
            remaining = []
            if values:
                parsed.nouns[noun.name] = values
            elif noun.required:
                raise Stop(f'{verb.name} needs at least one {noun.name}.', f'{where} --help')
            continue
        if noun.name in parsed.nouns:
            continue
        if noun.required and remaining:
            parsed.nouns[noun.name] = convert(noun, remaining.pop(0), where)
        elif noun.required:
            raise Stop(f'{verb.name} needs {noun.usage()}.', f'{where} --help')
    if remaining:
        raise Stop(f'{verb.name} does not take {remaining[0]!r}.', f'{where} --help')


KIND_WORDS = {'str': 'text', 'int': 'a whole number', 'bool': 'true or false'}


def _typed(kind: str, value: Any) -> bool:
    if kind == 'str':
        return isinstance(value, str)
    if kind == 'int':
        return isinstance(value, int) and not isinstance(value, bool)
    if kind == 'bool':
        return isinstance(value, bool)
    return True


def _noun_value(noun: Noun, value: Any, where: str, notices: list[tuple[str, str]]) -> Any:
    """One noun from its JSON value, BASE-035. A noun with a schema, or of kind json, takes any JSON value.

    A `str` noun is never refused for its content, BASE-044: a value that is not a string reaches the verb as its
    JSON text, named once in `notices`. An `int` or `bool` noun sent another kind cannot be read as that kind and
    stops the call as the command line does.
    """
    if noun.schema is not None or noun.kind == 'json':
        return value
    if noun.many:
        if noun.kind == 'str' and isinstance(value, str):  # one string is the list of its one value, as on the command
            value = [value]  # line, so map_cypher takes its query whole as it is written
        members = cast(list[Any], value) if isinstance(value, list) else None
        if members is None or (noun.kind != 'str' and not all(_typed(noun.kind, member) for member in members)):
            raise Stop(f'{noun.name} is a list of {KIND_WORDS[noun.kind]} values.', f'{where} --help')
        if noun.kind == 'str' and not all(isinstance(member, str) for member in members):
            notices.append((noun.name, f'{noun.name} is text; what was sent was kept as its JSON text.'))
            return [member if isinstance(member, str) else json.dumps(member, ensure_ascii=False)
                    for member in members]
        return list(members)
    if noun.kind == 'str' and not isinstance(value, str):
        notices.append((noun.name, f'{noun.name} is text; what was sent was kept as its JSON text.'))
        return json.dumps(value, ensure_ascii=False)
    if not _typed(noun.kind, value):
        raise Stop(f'{noun.name} is {KIND_WORDS[noun.kind]}, not {json.dumps(value)}.', f'{where} --help')
    return value


def switch_value(setting: settings.Setting, value: Any, folder: Path | None = None,
                 notices: list[tuple[str, str]] | None = None) -> Any:
    """A setting's value from its JSON form over MCP, CLI-027, read by its kind as a noun is, BASE-035.

    A text setting, `str` or `select`, is never refused for its kind, BASE-044: a value that is not a string is read
    as its JSON text, named once in `notices`, and then checked as `set` checks that text. A `list` member that is not
    a string is read the same way. An `int` or `bool` setting sent another kind, and a `list` setting sent no list,
    cannot be read as that kind and stop the call as the command line does.
    """
    noted = notices if notices is not None else []
    if setting.kind == 'bool':
        if not isinstance(value, bool):
            raise settings.SettingError(f'{setting.key} is true or false, not {json.dumps(value)}.')
        return value
    if setting.kind == 'list':
        members = cast(list[Any], value) if isinstance(value, list) else None
        if members is None:
            raise settings.SettingError(f'{setting.key} is a list of text values, not {json.dumps(value)}.')
        if not all(isinstance(member, str) for member in members):
            noted.append((setting.key, f'{setting.key} is text; what was sent was kept as its JSON text.'))
        return [text.strip() for text in (member if isinstance(member, str) else json.dumps(member, ensure_ascii=False)
                                          for member in members) if text.strip()]
    if setting.kind == 'int':
        if not isinstance(value, int) or isinstance(value, bool):
            raise settings.SettingError(f'{setting.key} is a whole number, not {json.dumps(value)}.')
        return settings.parse(setting, str(value), folder)
    if not isinstance(value, str):
        noted.append((setting.key, f'{setting.key} is text; what was sent was kept as its JSON text.'))
        value = json.dumps(value, ensure_ascii=False)
    return settings.parse(setting, value, folder)


def from_json(module: str, verb: Verb, arguments: dict[str, Any], *, ignore: tuple[str, ...] = (),
              folder: Path | None = None) -> Parsed:
    """The nouns and switches of one tool call, checked the way the command line checks them, MCP-005 and MCP-006.

    A required noun that is missing, or an `int` or `bool` noun sent a value that is not its kind, stops the call
    with the same next step the command line gives. A `str` noun sent another JSON value reaches the verb as that
    value's JSON text, with a notice in `notices`, BASE-044; a switch is read by its kind the same way, `switch_value`.
    A name that is neither a noun nor a switch of the verb is listed in `unknown`.
    """
    where = f'metaform {module} {verb.name}'
    parsed = Parsed()
    for noun in verb.nouns:
        if noun.name not in arguments:
            if noun.required:
                raise Stop(f'{verb.name} needs {noun.usage()}.', f'{where} --help')
            continue
        parsed.nouns[noun.name] = _noun_value(noun, arguments[noun.name], where, parsed.notices)
    for key in verb.switches:
        setting = settings.SCHEMA.get(key)
        if setting is None or key not in arguments:
            continue
        try:
            parsed.switches[key] = switch_value(setting, arguments[key], folder, parsed.notices)
        except settings.SettingError as error:
            raise Stop(str(error), error.next_step or f'metaform help {setting.switch}') from None
    known = {noun.name for noun in verb.nouns} | set(verb.switches) | set(ignore)
    parsed.unknown = sorted(name for name in arguments if name not in known)
    return parsed
