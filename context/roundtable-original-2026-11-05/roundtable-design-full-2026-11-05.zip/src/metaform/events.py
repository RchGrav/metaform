"""The event bus, BASE-010, BASE-032 and BASE-033: a module publishes a topic and every loaded subscriber receives it.

Each subscriber gets its own Context, built from the publisher's folder and
project, and its outcome comes back to the publisher: completed with its
result, failed with its error, or cancelled. One subscriber's failure never
hides the others. The bus announces and delivers; it runs no workflow. `map.changed` is also handed to every
listener of another process of the home, one more delivery each, BASE-053. A long-running process hears those
with `listen`, and after its own writes fires their changes with `announce`.
"""
from __future__ import annotations

import asyncio
import copy
import inspect
from collections.abc import Callable
from pathlib import Path
from typing import Any

from . import changes, loader, relay
from .module import Context, Surface, call


def publish(topic: str, payload: dict[str, Any], source: Context) -> list[dict[str, Any]]:
    """Deliver a topic from synchronous code. Inside a running loop use `publish_async`, which never blocks it."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        pass
    else:
        raise RuntimeError(f'{source.module} published {topic} from inside a running event loop; an async verb '
                           'publishes with await ctx.publish_async(...), so the loop is never blocked, BASE-009.')
    from . import context
    deliveries: list[dict[str, Any]] = []
    for module in loader.enabled():
        for subscription in module.subscriptions:
            if subscription.topic != topic:
                continue
            try:
                receiver = context.build(module.id, source.folder, project=source.project, resolve=False,
                                         sink=source.sink, surface=source.surface)
                result = call(subscription.handler, copy.deepcopy(payload), receiver)
                deliveries.append({'module': module.id, 'status': 'completed', 'result': result})
            except asyncio.CancelledError:
                deliveries.append({'module': module.id, 'status': 'cancelled'})
            except Exception as error:  # noqa: BLE001  every subscriber failure is reported without hiding other deliveries
                deliveries.append({'module': module.id, 'status': 'failed', 'error': f'{type(error).__name__}: {error}'})
    return deliveries + relay.deliver(topic, payload)


async def publish_async(topic: str, payload: dict[str, Any], source: Context) -> list[dict[str, Any]]:
    """Deliver a topic from inside a running loop: an async subscriber is awaited on it and a sync one runs in a
    worker thread, so no subscriber blocks the loop, BASE-009. Outcomes are those of `publish`."""
    from . import context
    deliveries: list[dict[str, Any]] = []
    for module in loader.enabled():
        for subscription in module.subscriptions:
            if subscription.topic != topic:
                continue
            try:
                receiver = context.build(module.id, source.folder, project=source.project, resolve=False,
                                         sink=source.sink, surface=source.surface)
                if inspect.iscoroutinefunction(subscription.handler):
                    result = await subscription.handler(copy.deepcopy(payload), receiver)
                else:
                    result = await asyncio.to_thread(subscription.handler, copy.deepcopy(payload), receiver)
                deliveries.append({'module': module.id, 'status': 'completed', 'result': result})
            except asyncio.CancelledError:
                current = asyncio.current_task()
                if current is not None and current.cancelling():
                    raise
                deliveries.append({'module': module.id, 'status': 'cancelled'})
            except Exception as error:  # noqa: BLE001  every subscriber failure is reported without hiding other deliveries
                deliveries.append({'module': module.id, 'status': 'failed', 'error': f'{type(error).__name__}: {error}'})
    return deliveries + await asyncio.to_thread(relay.deliver, topic, payload)


def listen(module: str, handler: Callable[[dict[str, Any]], Any]) -> relay.Listener:
    """Hear each `map.changed` published in another process of this home, for a long-running process with no
    `Context`; `ctx.listen` is the same. The handler runs in the listener's own thread. Close the listener when the
    process is done, BASE-053."""
    return relay.listen(module, handler)


def announce(folder: Path, surface: Surface) -> list[dict[str, Any]]:
    """For a long-running process after a call: load or drop the modules enabled or disabled since, BASE-037, then fire
    `map.changed` for each metaform the call changed, VIEW-018. Returns the payloads fired, BASE-053."""
    loader.follow_enabled()
    return changes.announce(folder, surface)


def announced(folder: Path, surface: Surface, function: Callable[..., Any], *args: Any,
              **kwargs: Any) -> tuple[Any, list[dict[str, Any]]]:
    """For a long-running process: one write, `function`, then `map.changed` for what that write alone changed, with
    its tables and what it said it concerns; other writes of the process are left for their own announcement, so a
    write's event never names another's, BASE-053. Returns the function's result and the payloads fired."""
    loader.follow_enabled()
    return changes.announced(folder, surface, function, *args, **kwargs)


def quietly(function: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """For a long-running process: one write whose change the caller announces itself, on its own `map.changed`; what
    it noted is never announced again, by `announce` or at the command's end, BASE-053. Returns the function's result."""
    return changes.quietly(function, *args, **kwargs)

