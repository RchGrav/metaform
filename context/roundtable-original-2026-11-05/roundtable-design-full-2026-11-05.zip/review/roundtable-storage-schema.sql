CREATE TABLE IF NOT EXISTS discussions(
  number INTEGER PRIMARY KEY, subject TEXT NOT NULL, opening TEXT NOT NULL, folder TEXT NOT NULL,
  chair_key TEXT, chair_token TEXT NOT NULL, reporter TEXT NOT NULL,
  state TEXT NOT NULL, reason TEXT,
  round INTEGER NOT NULL DEFAULT 1, position INTEGER NOT NULL DEFAULT 0, round_kept INTEGER NOT NULL DEFAULT 0,
  runner TEXT, budget_runner TEXT, beat REAL NOT NULL DEFAULT 0, unjudged TEXT,
  rounds INTEGER NOT NULL, spend REAL NOT NULL, spent REAL NOT NULL DEFAULT 0,
  report TEXT, export TEXT, report_error TEXT, created TEXT NOT NULL, ended TEXT,
  context_id TEXT, task_id TEXT, imported TEXT, snapshot TEXT,
  topic INTEGER NOT NULL DEFAULT 0, stage TEXT, host TEXT, synthesizer TEXT, advance_asked INTEGER NOT NULL DEFAULT 0,
  unpaid INTEGER NOT NULL DEFAULT 0, mechanical TEXT, seat_mcp TEXT,
  continuation TEXT, handoff TEXT, pass_after INTEGER NOT NULL DEFAULT 0,
  phase_after INTEGER NOT NULL DEFAULT 0, collaboration_runner TEXT, quiet_rounds INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS seats(
  discussion INTEGER NOT NULL, position INTEGER NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL, name TEXT NOT NULL,
  agent TEXT, model TEXT, reported TEXT, session TEXT, gone TEXT,
  seen INTEGER NOT NULL DEFAULT 0, messages TEXT NOT NULL DEFAULT '[]',
  pending TEXT, asked REAL, reply TEXT, tries INTEGER NOT NULL DEFAULT 0, owner TEXT,
  taken INTEGER NOT NULL DEFAULT 0, kept INTEGER NOT NULL DEFAULT 0, extra TEXT,
  availability TEXT NOT NULL DEFAULT 'active', failures INTEGER NOT NULL DEFAULT 0, failing TEXT, reason TEXT,
  since TEXT, retry_at REAL, submitted INTEGER NOT NULL DEFAULT 0, reseated INTEGER NOT NULL DEFAULT 0,
  identity TEXT, profile_key TEXT,
  PRIMARY KEY (discussion, position));
CREATE TABLE IF NOT EXISTS submissions(
  discussion INTEGER NOT NULL, number INTEGER NOT NULL, round INTEGER NOT NULL, position INTEGER,
  seat TEXT NOT NULL, name TEXT, kind TEXT NOT NULL, text TEXT NOT NULL, reason TEXT,
  accepted INTEGER NOT NULL DEFAULT 0, over512 INTEGER NOT NULL DEFAULT 0,
  new REAL, valuable REAL, relevant REAL, keep REAL, original TEXT, truncated INTEGER NOT NULL DEFAULT 0,
  model TEXT, prompt_tokens INTEGER, cached_tokens INTEGER, cache_write_tokens INTEGER, cost REAL, jev_cost REAL,
  created TEXT NOT NULL, topic INTEGER, new_context REAL, on_topic REAL, label TEXT, repeat_of INTEGER, message_id TEXT,
  PRIMARY KEY (discussion, number));
CREATE TABLE IF NOT EXISTS waiting(
  discussion INTEGER NOT NULL, seq INTEGER NOT NULL, text TEXT NOT NULL, PRIMARY KEY (discussion, seq));
CREATE TABLE IF NOT EXISTS offered(
  agent TEXT PRIMARY KEY, models TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS topics(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, name TEXT NOT NULL, title TEXT NOT NULL, text TEXT NOT NULL,
  opened TEXT, discussed TEXT, advanced_by TEXT, why TEXT, closed TEXT,
  PRIMARY KEY (discussion, topic));
CREATE TABLE IF NOT EXISTS stages(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, stage TEXT NOT NULL, position INTEGER NOT NULL,
  seat TEXT NOT NULL, name TEXT, text TEXT NOT NULL, original TEXT, truncated INTEGER NOT NULL DEFAULT 0,
  ideas TEXT, ranking TEXT, repair TEXT, error TEXT,
  model TEXT, prompt_tokens INTEGER, cached_tokens INTEGER, cache_write_tokens INTEGER, cost REAL,
  created TEXT NOT NULL,
  PRIMARY KEY (discussion, topic, stage, position));
CREATE TABLE IF NOT EXISTS judgments(
  id INTEGER PRIMARY KEY, discussion INTEGER NOT NULL, topic INTEGER, round INTEGER, position INTEGER,
  submission INTEGER, kind TEXT NOT NULL, request TEXT, prompts_sha TEXT, response TEXT, model TEXT,
  nouls TEXT, floors TEXT, decision TEXT, usage TEXT, cost REAL, state_tokens INTEGER, latency_ms INTEGER,
  attempts INTEGER, error TEXT, created TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS judgments_of ON judgments(discussion, topic, kind);
CREATE TABLE IF NOT EXISTS events(
  discussion INTEGER NOT NULL, number INTEGER NOT NULL, kind TEXT NOT NULL, text TEXT NOT NULL, seat TEXT,
  created TEXT NOT NULL,
  PRIMARY KEY (discussion, number));
CREATE TABLE IF NOT EXISTS profiles(
  agent TEXT PRIMARY KEY, name TEXT NOT NULL, score REAL, ratings INTEGER NOT NULL DEFAULT 0,
  sessions INTEGER NOT NULL DEFAULT 0, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profile_aliases(
  source TEXT NOT NULL, occurrence INTEGER NOT NULL, identity TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL UNIQUE, profile_key TEXT NOT NULL UNIQUE, PRIMARY KEY(source, occurrence));
CREATE TABLE IF NOT EXISTS scorecards(
  discussion INTEGER NOT NULL, position INTEGER NOT NULL, text TEXT NOT NULL, created TEXT NOT NULL,
  PRIMARY KEY (discussion, position));
CREATE TABLE IF NOT EXISTS session_ratings(
  discussion INTEGER NOT NULL, agent TEXT NOT NULL, PRIMARY KEY (discussion, agent));
CREATE TABLE IF NOT EXISTS topic_proposals(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, position INTEGER NOT NULL,
  state TEXT NOT NULL DEFAULT 'pending', receipt TEXT, text TEXT, usage TEXT, created TEXT,
  attempts INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(discussion, topic, position));
CREATE TABLE IF NOT EXISTS topic_decisions(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, state TEXT NOT NULL DEFAULT 'pending',
  request TEXT, response TEXT, scores TEXT, text TEXT, usage TEXT, error TEXT, created TEXT,
  PRIMARY KEY(discussion, topic));
CREATE TABLE IF NOT EXISTS phase_usage(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, phase TEXT NOT NULL, position INTEGER NOT NULL,
  tokens INTEGER NOT NULL DEFAULT 0, reported INTEGER NOT NULL DEFAULT 0, unreported INTEGER NOT NULL DEFAULT 0,
  notice INTEGER NOT NULL DEFAULT 0, closing INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (discussion, topic, phase, position));
CREATE TABLE IF NOT EXISTS phase_replies(
  discussion INTEGER NOT NULL, reply TEXT NOT NULL, topic INTEGER NOT NULL, phase TEXT NOT NULL,
  position INTEGER NOT NULL, tokens INTEGER NOT NULL, reported INTEGER NOT NULL, recorded INTEGER,
  PRIMARY KEY (discussion, reply));
CREATE TABLE IF NOT EXISTS phase_reply_usage(
  discussion INTEGER NOT NULL, reply TEXT NOT NULL, kind TEXT NOT NULL, usage TEXT NOT NULL,
  PRIMARY KEY (discussion, reply));
CREATE TABLE IF NOT EXISTS phase_notices(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, phase TEXT NOT NULL, percent INTEGER NOT NULL,
  position INTEGER NOT NULL, tokens INTEGER NOT NULL, token_limit INTEGER NOT NULL, text TEXT NOT NULL,
  PRIMARY KEY (discussion, topic, phase, percent));
CREATE TABLE IF NOT EXISTS phase_seed(
  discussion INTEGER NOT NULL, topic INTEGER NOT NULL, phase TEXT NOT NULL,
  PRIMARY KEY (discussion, topic, phase));
