# Design differences retained for review

- Genesis naming: the owner's AgentIdentity rule uses the first harness session ID and accepts display-name collisions. The current roundtable alias allocator seeds the shared generator with a separate UUID and retries collisions. Both the original rule and implementations are included.
- Scoring instructions: the detailed project-worker prompt defines category behavior, weights and the bonus. The shorter roundtable scoring prompt supplies the scorecard structure without that full rubric. Both complete texts are included in docs/reference/roundtable-agent-ratings.md.
- Accolades: the original session instruction promises future-profile scores, accolades and recognition. Current roundtable profile records carry aggregate numeric scores, counts and session totals. A separate accolade ledger, award criteria and delivery mechanism are not defined in those records or prompts. The original promise and current source are included for refinement.
- Task score documentation: the tasks README describes an older initial score of 100 and a 105 overall cap. Current board code and the project-worker instruction use an unscored start with additive rating points. A single rating can reach 105.
- ACP histories: native provider history, the roundtable's settled local mirror, public exports and ordinary dispatch session threads are different records. The included history reference identifies their storage and retention boundaries.
- Artifact completion: shared file access and instructions do not enforce a final document owner or completeness of every requested specification, diagram or sample. The consolidated design records that limitation.

These differences are preserved for review. Building this archive does not change live prompts, naming, scores, histories or running sessions.
