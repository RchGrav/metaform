# Roundtable full design review archive

Start with [the consolidated design specification](specifications/12-roundtables.md).

## Review the requested details

| Subject | Complete reference |
|---|---|
| Agent scoring | [Full original rubric, exact roundtable prompts, weights, bonus, validation and score storage](docs/reference/roundtable-agent-ratings.md) |
| Names and genesis | [Genesis identity, hash derivation and current alias differences](docs/reference/agent-genesis-naming.md) |
| Original identity design | [The owner's unchanged AgentIdentity text](rich/technical/agent_identity.md) |
| Word lists | [256 adjectives](src/metaform/modules/dispatch/resources/names/adjectives.txt), [256 nouns](src/metaform/modules/dispatch/resources/names/nouns.txt), [indexed CSV](review/name-word-indices.csv) |
| ACP conversation histories | [Native history, local mirrors, stored threads, replay, compaction and retention](docs/reference/acp-conversation-history.md) |
| Accolades | [Original recognition promise, current profile behavior and missing mechanism](docs/reference/roundtable-accolades.md) |
| All bundled prompts | [Unabridged readable catalogue](review/all-prompts.md), [machine-readable index](review/prompt-index.json) and exact source files |
| Score and engine tables | [Complete engine SQL schema](review/roundtable-storage-schema.sql), complete store.py and task board.py |
| Current differences | [Design gaps retained for review](review/design-gaps.md) |
| Actual delivered prompts | [Previously captured participant prompts](evidence/roundtable-20-delivered-prompts.txt) |
| Original recognition instruction | [Full historical opening and its source checksum](evidence/roundtable-original-recognition-instruction.md) |

## Included source and requirements

The archive contains the full specifications folder and complete roundtables, dispatch, tasks and agents source modules, including their resources, prompt templates and tests. It also includes shared data/storage code, core package Python files, relevant web controls and history views, general authored prompt files, the original identity documents and project packaging metadata. The original project README is retained as repository-README.md.

Source files retain their repository-relative paths. Prompt definitions are included without shortening, and original word-list order is unchanged. The readable catalogue includes historical and general worker templates alongside current roundtable templates. Source call sites establish which templates each runtime path sends.

This is a local working-tree snapshot including uncommitted corrections. The manifest identifies each source path, byte size and SHA-256 checksum. Source scopes and generated-file exclusions are explicit. No live model call or runtime change is required to produce this archive.
