"""Detached, authenticated loopback owner of one home's knowledge database."""
from __future__ import annotations

import argparse
import hmac
import http.client
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from urllib.parse import parse_qs, urlsplit
import uuid

from filelock import FileLock, Timeout

from .util import dumps, now, python_environment, read_json, write_json


class ServiceError(RuntimeError):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


def _directory(home):
    return Path(home).expanduser().resolve() / "service"


def _unavailable(directory):
    return ServiceError("service_unavailable", f"Knowledge service unavailable; see {directory / 'service.log'}", {"log": str(directory / "service.log")})


def _request(endpoint, token, method, path, body=None, timeout=2):
    connection = http.client.HTTPConnection("127.0.0.1", endpoint["port"], timeout=timeout)
    try:
        headers = {"Authorization": f"Bearer {token}"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        connection.request(method, path, body=body.encode("utf-8") if isinstance(body, str) else body, headers=headers)
        response = connection.getresponse()
        return response.status, json.loads(response.read())
    finally:
        connection.close()


def _probe(directory, timeout=2):
    try:
        endpoint = read_json(directory / "endpoint.json")
        if not isinstance(endpoint, dict) or endpoint.get("host") != "127.0.0.1" or endpoint.get("protocol") != 1:
            return None
        token = (directory / "token").read_text().strip()
        if not token:
            return None
        challenge = secrets.token_urlsafe(24)
        status, reply = _request(endpoint, token, "GET", f"/v1/health?challenge={challenge}", timeout=timeout)
        expected = {"product": "metaform-knowledge", "protocol": 1, "service_id": endpoint["service_id"], "instance_id": endpoint["instance_id"], "ready": True, "challenge": challenge}
        if status == 200 and isinstance(reply, dict) and all(reply.get(key) == value for key, value in expected.items()):
            return endpoint
    except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException):
        pass
    return None


def _owned(directory):
    lock = FileLock(directory / "instance.lock")
    try:
        lock.acquire(timeout=0)
    except Timeout:
        return True
    lock.release()
    return False


def _spawn_service(home, directory):
    with (directory / "service.log").open("ab") as log:
        return subprocess.Popen(
            [sys.executable, "-m", "metaform.service", "--home", str(home)],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            start_new_session=True, close_fds=True, env=python_environment(),
        )


def ensure_service(home, timeout=30):
    """Verify an existing owner or start one, bounded by a single deadline."""
    directory = _directory(home)
    deadline = time.monotonic() + timeout
    remaining = lambda: max(0, deadline - time.monotonic())
    endpoint = _probe(directory, min(2, max(0.001, remaining())))
    if endpoint:
        return endpoint
    directory.mkdir(parents=True, exist_ok=True)
    start_lock = FileLock(directory / "start.lock")
    try:
        start_lock.acquire(timeout=remaining(), poll_interval=0.05)
    except Timeout:
        raise _unavailable(directory) from None
    try:
        spawned = None
        while remaining() > 0:
            endpoint = _probe(directory, min(2, remaining()))
            if endpoint:
                return endpoint
            if spawned is not None and spawned.poll() is not None:
                raise _unavailable(directory)
            if spawned is None and not _owned(directory):
                spawned = _spawn_service(directory.parent, directory)
            time.sleep(min(0.05, remaining()))
        raise _unavailable(directory)
    finally:
        start_lock.release()


def service_status(home, timeout=2):
    directory = _directory(home)
    endpoint = _probe(directory, timeout)
    return {"ready": bool(endpoint), **(endpoint or {}), "log": str(directory / "service.log")}


def stop_service(home, timeout=30):
    """Stop only a freshly verified instance; never signal a recorded PID."""
    directory = _directory(home)
    deadline = time.monotonic() + timeout
    endpoint = _probe(directory, min(2, timeout))
    if not endpoint:
        return {"stopped": False, "ready": False, "log": str(directory / "service.log")}
    token = (directory / "token").read_text().strip()
    try:
        status, reply = _request(endpoint, token, "POST", "/v1/stop", dumps({"instance_id": endpoint["instance_id"]}), timeout=max(0.001, deadline-time.monotonic()))
    except (OSError, ValueError, http.client.HTTPException):
        raise _unavailable(directory) from None
    if status != 200:
        raise _unavailable(directory)
    while time.monotonic() < deadline:
        if not _owned(directory):
            return {"stopped": True, "instance_id": endpoint["instance_id"]}
        time.sleep(0.02)
    raise _unavailable(directory)


class RemoteKnowledge:
    def __init__(self, home, project_id):
        self.home = Path(home).expanduser().resolve()
        self.project_id = project_id
        self.revision = None

    def call(self, operation, arguments, request_id=None):
        envelope = {"protocol": 1, "request_id": request_id or str(uuid.uuid4()), "project_id": self.project_id, "operation": operation, "arguments": arguments}
        body = dumps(envelope)
        directory = _directory(self.home)
        for attempt in range(2):
            endpoint = ensure_service(self.home)
            token = (directory / "token").read_text().strip()
            try:
                status, reply = _request(endpoint, token, "POST", "/v1/operations", body, timeout=30)
            except (OSError, ValueError, http.client.HTTPException):
                if operation == "analysis.query":
                    raise ServiceError("ambiguous_result", "The analysis connection closed before its result arrived; the query may have executed", {"request_id": envelope["request_id"], "project_id": self.project_id}) from None
                if attempt == 0:
                    continue
                raise _unavailable(directory) from None
            if not isinstance(reply, dict) or reply.get("protocol") != 1 or reply.get("request_id") != envelope["request_id"] or reply.get("project_id") != self.project_id:
                raise ServiceError("invalid_response", "Knowledge service returned an invalid operation envelope")
            if status != 200:
                error = reply.get("error", {})
                from .knowledge import KnowledgeError
                raise KnowledgeError(error.get("code", "service_error"), error.get("message", "Knowledge operation failed"), error.get("details"))
            if reply.get("service_id") != endpoint["service_id"] or reply.get("instance_id") != endpoint["instance_id"]:
                raise ServiceError("invalid_response", "Knowledge service identity changed during request")
            self.revision = reply["revision"]
            return reply["result"]


def dispatch_operation(store, envelope):
    """Central operation dispatch, also the extension point for analysis copies."""
    if envelope["operation"] in {"analysis.refresh", "analysis.query", "analysis.status"}:
        try:
            return analysis_operation(store, envelope)
        except ImportError as error:
            from .knowledge import KnowledgeError
            raise KnowledgeError("analysis_unavailable", "Ladybug is not installed", {"backend": "ladybug"}) from error
    return store.call(envelope["project_id"], envelope["operation"], envelope["arguments"], request_id=envelope["request_id"])


def analysis_operation(store, envelope):
    """Operate on an explicit disposable native copy, never the source store."""
    from .backends import LadybugGraph
    from .knowledge import KnowledgeError

    project_id, arguments = envelope["project_id"], envelope["arguments"]
    if project_id is not None:
        store.call(project_id, "project.get", {})
    owner = store._owner(project_id, arguments.get("owner"))
    directory = store.path.parent / "analysis"
    directory.mkdir(exist_ok=True)
    owner_name = owner.removeprefix("project:")
    target = directory / owner_name
    lock = FileLock(directory / (owner_name + ".lock"))
    if envelope["operation"] == "analysis.status":
        with lock:
            return read_json(target / "metadata.json")
    if envelope["operation"] == "analysis.query":
        with lock:
            metadata = read_json(target / "metadata.json")
            if metadata is None:
                raise KnowledgeError("analysis_unavailable", "Refresh the Ladybug analysis copy with graph backend --name ladybug", {"owner": owner})
            result = LadybugGraph(target / "metaform.lbdb").query(arguments["query"], arguments.get("parameters"))
            return {"source_revision": metadata["source_revision"], "refreshed_at": metadata["refreshed_at"], "result": result}
    if arguments.get("backend") != "ladybug":
        raise KnowledgeError("unsupported_backend", "Installed analysis uses the Ladybug backend")
    with store.transaction(False):
        graph = store.call(project_id, "graph.export", {"owner": owner})
        revision = store.revision
    metadata = {"owner": owner, "source_revision": revision, "refreshed_at": now(), "backend": "ladybug"}
    with tempfile.TemporaryDirectory(prefix=owner_name + ".refresh-", dir=directory) as temporary:
        prepared = Path(temporary) / "copy"
        prepared.mkdir()
        LadybugGraph(prepared / "metaform.lbdb").import_raw(graph)
        write_json(prepared / "metadata.json", metadata)
        with lock:
            # Publish the database and its revision together while queries wait.
            previous = Path(temporary) / "previous"
            if target.exists():
                target.rename(previous)
            try:
                prepared.rename(target)
            except BaseException:
                if previous.exists():
                    previous.rename(target)
                raise
    return metadata


class KnowledgeServer(ThreadingHTTPServer):
    # server_close waits for all accepted handlers before storage ownership ends.
    daemon_threads = False
    block_on_close = True

    def __init__(self, store, token, identity):
        self.store = store
        self.token = token
        self.identity = identity
        self.stopping = threading.Event()
        super().__init__(("127.0.0.1", 0), KnowledgeHandler)


class KnowledgeHandler(BaseHTTPRequestHandler):
    # Bound socket inactivity; executing an accepted operation has no time limit.
    timeout = 2

    def _reply(self, status, value):
        body = dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _authenticated(self):
        supplied = self.headers.get("Authorization", "")
        if hmac.compare_digest(supplied, f"Bearer {self.server.token}"):
            return True
        self._reply(401, {"error": {"code": "unauthorized", "message": "Invalid service credential", "details": {}}})
        return False

    def do_GET(self):
        if not self._authenticated():
            return
        parsed = urlsplit(self.path)
        if parsed.path != "/v1/health":
            self._reply(404, {"error": {"code": "not_found"}})
            return
        challenge = parse_qs(parsed.query).get("challenge", [None])[0]
        self._reply(200, {"product": "metaform-knowledge", "protocol": 1, **self.server.identity, "ready": not self.server.stopping.is_set(), "challenge": challenge})

    def do_POST(self):
        if not self._authenticated():
            return
        envelope = {}
        try:
            try:
                body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
            except TimeoutError:
                self.close_connection = True
                return
            envelope = json.loads(body)
            if not isinstance(envelope, dict):
                raise ValueError("Operation envelope must be an object")
            if self.path == "/v1/stop":
                if envelope.get("instance_id") != self.server.identity["instance_id"]:
                    raise ValueError("Service instance does not match")
                self.server.stopping.set()
                self._reply(200, {"stopping": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            if self.path != "/v1/operations":
                self._reply(404, {"error": {"code": "not_found"}})
                return
            if envelope.get("protocol") != 1 or not isinstance(envelope.get("request_id"), str) or not envelope["request_id"] or "project_id" not in envelope or not isinstance(envelope.get("operation"), str) or not isinstance(envelope.get("arguments"), dict):
                raise ValueError("Invalid operation envelope")
            if self.server.stopping.is_set():
                raise ServiceError("service_unavailable", "Knowledge service is stopping")
            result = dispatch_operation(self.server.store, envelope)
            self._reply(200, {"protocol": 1, "request_id": envelope["request_id"], "project_id": envelope["project_id"], **self.server.identity, "revision": self.server.store.revision, "result": result})
        except Exception as error:
            from .knowledge import KnowledgeError
            if isinstance(error, (KnowledgeError, ServiceError)):
                code, message, details = error.code, str(error), error.details or {}
            elif isinstance(error, (ValueError, KeyError, TypeError)):
                code, message, details = "invalid_request", str(error), {}
            else:
                traceback.print_exc()
                code, message, details = "internal_error", "Knowledge operation failed", {}
            self._reply(400 if code != "internal_error" else 500, {"protocol": 1, "request_id": envelope.get("request_id") if isinstance(envelope, dict) else None, "project_id": envelope.get("project_id") if isinstance(envelope, dict) else None, "error": {"code": code, "message": message, "details": details}})


def serve(home):
    from .knowledge import KnowledgeStore
    directory = _directory(home)
    directory.mkdir(parents=True, exist_ok=True)
    lock = FileLock(directory / "instance.lock")
    try:
        lock.acquire(timeout=0)
    except Timeout:
        return
    try:
        token_path = directory / "token"
        token = token_path.read_text().strip() if token_path.exists() else ""
        if not token:
            token = secrets.token_urlsafe(48)
            fd, temporary = tempfile.mkstemp(prefix="token.", dir=directory)
            try:
                with os.fdopen(fd, "w") as stream:
                    stream.write(token)
                os.replace(temporary, token_path)
            finally:
                Path(temporary).unlink(missing_ok=True)
        token_path.chmod(0o600)
        identity_path = directory / "identity.json"
        identity = read_json(identity_path)
        if identity is None:
            identity = {"service_id": str(uuid.uuid4())}
            write_json(identity_path, identity)
        identity = {"service_id": identity["service_id"], "instance_id": str(uuid.uuid4())}
        store = KnowledgeStore(directory / "knowledge.sqlite3")
        server = KnowledgeServer(store, token, identity)
        try:
            write_json(directory / "endpoint.json", {**identity, "protocol": 1, "host": "127.0.0.1", "port": server.server_port, "pid": os.getpid()})
            server.serve_forever(poll_interval=0.05)
        finally:
            server.server_close()
            if hasattr(store, "close"):
                store.close()
    finally:
        lock.release()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--home", required=True)
    args = parser.parse_args()
    serve(args.home)


if __name__ == "__main__":
    main()
