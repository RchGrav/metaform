from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path


def source_hash(project):
    digest = hashlib.sha256()
    paths = [
        project / "pyproject.toml",
        project / "README.md",
        *sorted((project / "packaging").rglob("*")),
        *sorted((project / "src").rglob("*")),
    ]
    for path in paths:
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            digest.update(str(path.relative_to(project)).encode())
            digest.update(path.read_bytes())
    return digest.hexdigest()


def build(app, source=None):
    source = Path(source or app.project).resolve()
    result = subprocess.run(
        [sys.executable, "-m", "build", "--wheel", "--no-isolation", str(source)],
        capture_output=True,
        text=True,
    )
    app.trace(
        "build",
        {"stdout": result.stdout, "stderr": result.stderr, "exit": result.returncode},
    )
    if result.returncode:
        raise ValueError(result.stderr or result.stdout)
    wheels = sorted((source / "dist").glob("*.whl"), key=lambda p: p.stat().st_mtime)
    bundle_runtime(wheels[-1])
    app.set("built_hash", source_hash(source))
    return {"wheel": str(wheels[-1]), "source_hash": app.get("built_hash")}


def bundle_runtime(wheel):
    import base64
    import csv
    import importlib.metadata
    import importlib.resources
    import io
    import os
    import tempfile
    import zipfile
    from .portable import add_tree

    fd, temporary = tempfile.mkstemp(dir=wheel.parent, prefix="runtime-")
    os.close(fd)
    try:
        with (
            zipfile.ZipFile(wheel) as old,
            zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as out,
        ):
            record_name = next(
                n for n in old.namelist() if n.endswith(".dist-info/RECORD")
            )
            for name in old.namelist():
                if name != record_name and not name.startswith("_portable/"):
                    out.writestr(name, old.read(name))
            for package in (
                "filelock",
                "jinja2",
                "markupsafe",
                "flask",
                "werkzeug",
                "click",
                "itsdangerous",
                "blinker",
            ):
                add_tree(
                    out,
                    importlib.resources.files(package),
                    "_portable/" + package + "/",
                )
                dist = importlib.metadata.distribution(package)
                for file in dist.files or []:
                    if "license" in str(file).lower() or str(file).endswith(("METADATA", "RECORD")):
                        item = dist.locate_file(file)
                        if (
                            item.is_file()
                            and "_portable/" + str(file) not in out.namelist()
                        ):
                            out.writestr("_portable/" + str(file), item.read_bytes())
        with zipfile.ZipFile(temporary, "a") as out:
            stream = io.StringIO()
            writer = csv.writer(stream, lineterminator="\n")
            for name in out.namelist():
                data = out.read(name)
                encoded = (
                    base64.urlsafe_b64encode(hashlib.sha256(data).digest())
                    .decode()
                    .rstrip("=")
                )
                writer.writerow([name, "sha256=" + encoded, len(data)])
            writer.writerow([record_name, "", ""])
            out.writestr(record_name, stream.getvalue())
        os.replace(temporary, wheel)
    finally:
        Path(temporary).unlink(missing_ok=True)


def auto_build(app):
    if (
        app.config.get("auto_build", True)
        and (app.project / "pyproject.toml").is_file()
        and (app.project / "src" / "metaform").is_dir()
    ):
        from .locking import lock

        with lock(app, "build"):
            if app.get("built_hash") != source_hash(app.project):
                return build(app)
    return None
