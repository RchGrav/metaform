"""The portable JSON representation and Ladybug's reified graph representation."""

from __future__ import annotations

import copy
import fnmatch
import json
from collections import Counter
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock

from .graph import Graph, join_participants, renamed_elements, scoped_export, scoped_join_references
from .util import digest, dumps, now, read_json, write_json


def normalized(graph, source, layer):
    result = {"elements": {}, "joins": [], "observations": []}
    for identifier, value in graph.get("elements", {}).items():
        record = copy.deepcopy(value)
        record.setdefault("layer", layer)
        result["elements"][identifier] = record
        if source != "imported":
            result["observations"].append(
                {
                    "id": digest([identifier, source, value]),
                    "element_id": identifier,
                    "source": source,
                    "record": record,
                    "created": now(),
                }
            )
    for value in graph.get("joins", []):
        join = copy.deepcopy(value)
        join["join_scope"] = (
            source
            if source in {"native", "archaeology", "merged"}
            else join.get("join_scope", source)
        )
        identifier = join.get("id") or digest(join)
        if join["join_scope"] in {"native", "archaeology"}:
            join.setdefault("source_id", identifier)
            identifier = "join:" + digest([join["join_scope"], join["source_id"]])
        join["id"] = identifier
        result["joins"].append(join)
    result["observations"].extend(copy.deepcopy(graph.get("observations", [])))
    return result


def replaced_scope(original, graph, source, layer="elements", owner=None):
    """Replace one authored perspective while retaining every other source."""
    authored = {"elements": graph.get("elements", {}), "joins": graph.get("joins", [])}
    authored = scoped_join_references(authored, source,
                                     [j for j in original["joins"] if j.get("join_scope") == source], owner)
    incoming = normalized(authored, source, layer)
    data = copy.deepcopy(original)
    affected = {o["element_id"] for o in data["observations"] if o["source"] == source}
    data["observations"] = [o for o in data["observations"] if o["source"] != source]
    latest = {o["element_id"]: o["record"] for o in sorted(data["observations"], key=lambda o: (o["created"], o["id"]))}
    for identifier in affected:
        if identifier in latest:
            data["elements"][identifier] = copy.deepcopy(latest[identifier])
        else:
            data["elements"].pop(identifier, None)
    data["elements"].update(incoming["elements"])
    data["observations"] = sorted(data["observations"] + incoming["observations"], key=lambda o: o["id"])
    joins = {j["id"]: j for j in data["joins"] if j.get("join_scope") != source}
    joins.update({j["id"]: j for j in incoming["joins"]})
    data["joins"] = sorted(joins.values(), key=lambda j: j["id"])
    return data, {"elements": len(incoming["elements"]), "joins": len(incoming["joins"])}


def matches(identifier, record, query):
    data = record["entity_json_obj"]
    names = [identifier, data.get("en", ""), *data.get("aliases", [])]
    return any(fnmatch.fnmatchcase(str(n).lower(), query.lower()) for n in names) or (
        "*" not in query
        and query.lower()
        in (record["entity_desc"] + " " + " ".join(map(str, names))).lower()
    )


class JSONGraph(Graph):
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def export(self, scope=None):
        value = read_json(self.path, {"elements": {}, "joins": [], "observations": []})
        return scoped_export(value, scope)

    def put(self, graph, source="native", layer="elements", *, _raw=False):
        if source in {"native", "archaeology"}:
            graph = scoped_join_references(graph, source, self.joins(scope=source), getattr(self, "owner", None))
        incoming = copy.deepcopy(graph) if _raw else normalized(graph, source, layer)
        with FileLock(str(self.path) + ".lock"):
            data = self.export()
            data["elements"].update(incoming["elements"])
            for key in ("joins", "observations"):
                rows = {r["id"]: r for r in data[key]}
                for row in incoming[key]:
                    if key == "observations":
                        if row["id"] not in rows or row["created"] > rows[row["id"]]["created"]:
                            rows[row["id"]] = row
                    else:
                        rows[row["id"]] = row
                data[key] = sorted(rows.values(), key=lambda r: r["id"])
            write_json(self.path, data)
        return {"elements": len(incoming["elements"]), "joins": len(incoming["joins"])}

    def replace_scope(self, graph, source, layer="elements"):
        with FileLock(str(self.path) + ".lock"):
            data, result = replaced_scope(self.export(), graph, source, layer, getattr(self, "owner", None))
            write_json(self.path, data)
        return result

    def rename_elements(self, mapping):
        with FileLock(str(self.path) + ".lock"):
            data, result = renamed_elements(self.export(), mapping, getattr(self, "owner", None))
            if result["elements"]:
                write_json(self.path, data)
        return result

    def get(self, identifier, scope=None):
        if scope is not None:
            return Graph.get(self, identifier, scope)
        record = self.export()["elements"].get(identifier)
        return (
            {k: record[k] for k in ("entity_desc", "entity_schema", "entity_json_obj")}
            if record
            else None
        )

    def search(self, query="*", layer=None, scope=None):
        data = self.export(scope)
        return [
            dict(
                record,
                id=identifier,
                sources=sorted(
                    {
                        o["source"]
                        for o in data["observations"]
                        if o["element_id"] == identifier
                    }
                ),
            )
            for identifier, record in sorted(data["elements"].items())
            if (layer is None or record.get("layer") == layer)
            and matches(identifier, record, query)
        ]

    def joins(self, identifier=None, scope=None, category=None):
        return [
            j
            for j in self.export(scope)["joins"]
            if (category is None or j["type"] == category)
            and (
                identifier is None
                or identifier
                in {
                    j["id"],
                    j.get("object_id"),
                    j.get("element_id"),
                    *(p.get("ref") for p in j.get("participants", [])),
                }
            )
        ]

    def provenance(self, identifier):
        return [
            {k: o[k] for k in ("source", "record", "created")}
            for o in sorted(
                self.export()["observations"], key=lambda o: (o["created"], o["id"])
            )
            if o["element_id"] == identifier
        ]

    def delete_joins(self, object_id=None, category=None, scope=None):
        with FileLock(str(self.path) + ".lock"):
            data = self.export()
            data["joins"] = [
                j
                for j in data["joins"]
                if not (
                    (object_id is None or j.get("object_id") == object_id)
                    and (category is None or j["type"] == category)
                    and (scope is None or j.get("join_scope") == scope)
                )
            ]
            write_json(self.path, data)

    def stats(self):
        data = self.export()
        return {
            "elements": len(data["elements"]),
            "joins": len(data["joins"]),
            "observations": len(data["observations"]),
            "participants": sum(
                len(join_participants(j)) for j in data["joins"]
            ),
            "layers": dict(
                Counter(r.get("layer", "elements") for r in data["elements"].values())
            ),
            "scopes": dict(Counter(j.get("join_scope") for j in data["joins"])),
        }

    def clean(self):
        return self.merge_perspectives() | {"integrity": "ok"}


class LadybugGraph(JSONGraph):
    """Native nodes for Elements and joins; role-bearing incidence relationships.

    A short-lived database owner under a cross-process lock lets separate CLI,
    MCP and web processes safely share an embedded database.
    """

    @contextmanager
    def connection(self):
        import ladybug

        with FileLock(str(self.path) + ".lock"):
            database = ladybug.Database(
                str(self.path), buffer_pool_size=128 * 1024 * 1024
            )
            connection = ladybug.Connection(database)
            try:
                connection.execute(
                    "CREATE NODE TABLE IF NOT EXISTS Record(id STRING PRIMARY KEY, kind STRING, name STRING, description STRING, layer STRING, scope STRING, object_id STRING, element_id STRING, body STRING)"
                )
                connection.execute(
                    "CREATE REL TABLE IF NOT EXISTS Participant(FROM Record TO Record, role STRING, ordinal INT64)"
                )
                yield connection
            finally:
                connection.close()
                database.close()

    @staticmethod
    def rows(connection, query, params=None):
        result = connection.execute(query, params or {})
        if isinstance(result, list):
            return [
                {"columns": r.get_column_names(), "rows": r.get_all()} for r in result
            ]
        return {"columns": result.get_column_names(), "rows": result.get_all()}

    def query(self, query, params=None):
        with self.connection() as connection:
            return json.loads(
                json.dumps(
                    self.rows(connection, query, params),
                    default=lambda v: (
                        v.isoformat() if hasattr(v, "isoformat") else str(v)
                    ),
                )
            )

    def put(self, graph, source="native", layer="elements", *, _raw=False):
        if source in {"native", "archaeology"}:
            graph = scoped_join_references(graph, source, self.joins(scope=source), getattr(self, "owner", None))
        incoming = copy.deepcopy(graph) if _raw else normalized(graph, source, layer)
        with self.connection() as c:
            c.execute("BEGIN TRANSACTION")
            try:
                for identifier, record in incoming["elements"].items():
                    self._record(
                        c,
                        identifier,
                        "element",
                        record,
                        record["entity_json_obj"].get("en", identifier),
                        record["entity_desc"],
                        record["layer"],
                    )
                for join in incoming["joins"]:
                    self._join(c, join)
                for observation in incoming["observations"]:
                    identifier = "observation:" + observation["id"]
                    existing = c.execute(
                        "MATCH (n:Record {id:$id}) RETURN n.body", {"id": identifier}
                    ).get_all()
                    if not existing or observation["created"] > json.loads(existing[0][0])["created"]:
                        self._record(
                            c,
                            identifier,
                            "observation",
                            observation,
                            "Observation",
                            observation["source"],
                            "observations",
                        )
                c.execute("COMMIT")
            except BaseException:
                c.execute("ROLLBACK")
                raise
        return {"elements": len(incoming["elements"]), "joins": len(incoming["joins"])}

    def rename_elements(self, mapping):
        with self.connection() as c:
            c.execute("BEGIN TRANSACTION")
            try:
                rows = c.execute(
                    "MATCH (n:Record) WHERE n.kind IS NOT NULL RETURN n.id, n.kind, n.body ORDER BY n.id"
                ).get_all()
                original = self._export_rows(rows)
                data, result = renamed_elements(original, mapping, getattr(self, "owner", None))
                for identifier, record in data["elements"].items():
                    if original["elements"].get(identifier) != record:
                        self._record(
                            c, identifier, "element", record,
                            record["entity_json_obj"].get("en", identifier),
                            record["entity_desc"], record["layer"],
                        )
                for before, join in zip(original["joins"], data["joins"]):
                    if before != join:
                        self._join(c, join)
                for before, observation in zip(original["observations"], data["observations"]):
                    if before != observation:
                        self._record(
                            c, "observation:" + observation["id"], "observation",
                            observation, "Observation", observation["source"], "observations",
                        )
                removed = sorted(original["elements"].keys() - data["elements"].keys())
                if removed:
                    c.execute(
                        "MATCH (n:Record) WHERE n.id IN $ids DETACH DELETE n", {"ids": removed}
                    )
                    for join in data["joins"]:
                        if any(p.get("ref") in removed for p in join_participants(join)):
                            self._join(c, join)
                c.execute("COMMIT")
            except BaseException:
                c.execute("ROLLBACK")
                raise
        return result

    def replace_scope(self, graph, source, layer="elements"):
        with self.connection() as c:
            c.execute("BEGIN TRANSACTION")
            try:
                rows = c.execute("MATCH (n:Record) WHERE n.kind IS NOT NULL RETURN n.id, n.kind, n.body ORDER BY n.id").get_all()
                data, result = replaced_scope(self._export_rows(rows), graph, source, layer, getattr(self, "owner", None))
                c.execute("MATCH (n:Record) DETACH DELETE n")
                for identifier, record in data["elements"].items():
                    self._record(c, identifier, "element", record, record["entity_json_obj"].get("en", identifier),
                                 record["entity_desc"], record.get("layer", "elements"))
                for join in data["joins"]:
                    self._join(c, join)
                for observation in data["observations"]:
                    self._record(c, "observation:" + observation["id"], "observation", observation,
                                 "Observation", observation["source"], "observations")
                c.execute("COMMIT")
            except BaseException:
                c.execute("ROLLBACK")
                raise
        return result

    def _join(self, c, join):
        self._record(
            c, join["id"], "join", join, join["type"],
            str(join.get("purpose", "")), "joins", join["join_scope"],
        )
        c.execute(
            "MATCH (a:Record {id:$id})-[p:Participant]->() DELETE p", {"id": join["id"]}
        )
        members = join_participants(join)
        for i, participant in enumerate(members):
            if participant.get("ref") is not None:
                c.execute("MERGE (b:Record {id:$ref})", {"ref": participant["ref"]})
                c.execute(
                    "MATCH (a:Record {id:$id}), (b:Record {id:$ref}) CREATE (a)-[:Participant {role:$role, ordinal:$ordinal}]->(b)",
                    {"id": join["id"], "ref": participant["ref"],
                     "role": participant.get("role", ""), "ordinal": i},
                )

    @staticmethod
    def _record(c, identifier, kind, body, name, description, layer, scope=""):
        c.execute(
            "MERGE (n:Record {id:$id}) SET n.kind=$kind, n.name=$name, n.description=$description, n.layer=$layer, n.scope=$scope, n.object_id=$object_id, n.element_id=$element_id, n.body=$body",
            {
                "id": identifier,
                "kind": kind,
                "name": name,
                "description": description,
                "layer": layer,
                "scope": scope,
                "object_id": body.get("object_id", ""),
                "element_id": body.get("element_id", ""),
                "body": dumps(body),
            },
        )

    def export(self, scope=None):
        rows = self.query(
            "MATCH (n:Record) WHERE n.kind IS NOT NULL RETURN n.id, n.kind, n.body ORDER BY n.id"
        )["rows"]
        return scoped_export(self._export_rows(rows), scope)

    @staticmethod
    def _export_rows(rows, scope=None):
        result = {"elements": {}, "joins": [], "observations": []}
        for identifier, kind, body in rows:
            record = json.loads(body)
            if kind == "element":
                result["elements"][identifier] = record
            elif kind == "join" and (
                scope is None or record.get("join_scope") == scope
            ):
                result["joins"].append(record)
            elif kind == "observation":
                result["observations"].append(record)
        return result

    def get(self, identifier, scope=None):
        if scope is not None:
            return Graph.get(self, identifier, scope)
        rows = self.query(
            "MATCH (n:Record {id:$id}) WHERE n.kind='element' RETURN n.body",
            {"id": identifier},
        )["rows"]
        record = json.loads(rows[0][0]) if rows else None
        return (
            {k: record[k] for k in ("entity_desc", "entity_schema", "entity_json_obj")}
            if record
            else None
        )

    def joins(self, identifier=None, scope=None, category=None):
        if identifier is None:
            rows = self.query(
                "MATCH (n:Record) WHERE n.kind='join' RETURN n.body ORDER BY n.id"
            )["rows"]
        else:
            rows = self.query(
                "MATCH (n:Record) WHERE n.kind='join' AND (n.id=$id OR n.object_id=$id OR n.element_id=$id OR EXISTS { MATCH (n)-[:Participant]->(p:Record {id:$id}) }) RETURN n.body ORDER BY n.id",
                {"id": identifier},
            )["rows"]
        return [
            j
            for row in rows
            if (j := json.loads(row[0]))
            and (scope is None or j.get("join_scope") == scope)
            and (category is None or j["type"] == category)
        ]

    def delete_joins(self, object_id=None, category=None, scope=None):
        selected = [
            j["id"]
            for j in self.joins(scope=scope, category=category)
            if object_id is None or j.get("object_id") == object_id
        ]
        if selected:
            self.query(
                "MATCH (n:Record) WHERE n.id IN $ids DETACH DELETE n", {"ids": selected}
            )


def open_graph(path, backend):
    return {"sqlite": Graph, "json": JSONGraph, "ladybug": LadybugGraph}[backend](path)
