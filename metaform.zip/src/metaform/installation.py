from __future__ import annotations

import importlib.util
import os
import shutil
import sys
import zipfile
from pathlib import Path


def install(app, destination=None):
    bindir = Path(destination or Path.home() / ".local" / "bin").expanduser()
    bindir.mkdir(parents=True, exist_ok=True)
    executable = bindir / "metaform"
    archive = Path(sys.argv[0]).resolve()
    if archive.is_file() and zipfile.is_zipfile(archive):
        package = app.home / "tool" / "metaform"
        package.parent.mkdir(parents=True, exist_ok=True)
        if archive != package:
            shutil.copyfile(archive, package)
        launcher = (
            "import runpy,sys\nsys.argv[0]="
            + repr(str(package))
            + "\nrunpy.run_path(sys.argv[0],run_name='__main__')\n"
        )
    else:
        launcher = "from metaform.cli import main\nraise SystemExit(main())\n"
    executable.write_text("#!" + sys.executable + "\n" + launcher)
    executable.chmod(0o755)
    if os.name == "nt":
        executable.with_suffix(".cmd").write_text(
            '@"' + sys.executable + '" "' + str(executable) + '" %*\n'
        )
    if importlib.util.find_spec("ladybug"):
        from .modules.graph import backend

        backend(app, {"name": "ladybug"}, None)
    return {
        "command": str(executable),
        "backend": app.config.get("graph_backend", "sqlite"),
        "modules": [str(app.home / "modules"), str(app.root / "modules")],
        "message": "Metaform works best when reusable Inference Metaform data can be contributed upstream. Use the workbench to inspect it and sync to publish it. You can target Metaform itself and build custom modules.",
    }
