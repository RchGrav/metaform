from __future__ import annotations

import argparse
import importlib.resources
import threading
import asyncio
import json
import fnmatch
import tempfile
import shutil
from pathlib import Path

from .graph import join_participants, type_ids

from flask import (
    Flask,
    jsonify,
    render_template_string,
    request,
    Response,
    send_from_directory,
)


def create_app(metaform, instance_id=None):
    app = Flask(__name__, static_folder=None)
    previews = {}
    from flask import g
    from werkzeug.local import LocalProxy
    initial = metaform
    projects = {initial.project_id: initial}
    project_lock = threading.RLock()
    metaform = LocalProxy(lambda: getattr(g, "metaform", initial))

    def project_catalog():
        from .service import RemoteKnowledge
        from uuid import NAMESPACE_URL, uuid5

        entries = {key: selected.project_context() for key, selected in projects.items()}
        paths = {entry["path"] for entry in entries.values()}
        homes = {selected.home for selected in projects.values() if selected.knowledge_mode != "portable"}
        for home in sorted(homes):
            if not (home / "service" / "knowledge.sqlite3").is_file():
                continue
            for entry in RemoteKnowledge(home, None).call("project.list", {}):
                if entry["path"] in paths:
                    continue
                key = entry["project_id"]
                if key in entries:
                    key += "-" + uuid5(NAMESPACE_URL, entry["path"]).hex
                entries[key] = entry
                paths.add(entry["path"])
        return {key: entry | {"url": "/projects/" + key + "/"} for key, entry in entries.items()}

    @app.before_request
    def select_request_project():
        identifier = (request.view_args or {}).pop("project_id", None)
        with project_lock:
            if identifier and identifier not in projects:
                from flask import abort
                entry = project_catalog().get(identifier)
                if entry is None:
                    abort(404, "Unknown project")
                if not Path(entry["path"]).is_dir():
                    abort(404, "Project folder does not exist: " + entry["path"])
                projects[identifier] = initial.select_project(entry["path"])
            g.metaform = projects[identifier] if identifier else initial
            g.project_prefix = "/projects/" + (identifier or initial.project_id)

    @app.errorhandler(Exception)
    def error(exc):
        from werkzeug.exceptions import HTTPException

        return jsonify({"error": str(exc)}), exc.code if isinstance(
            exc, HTTPException
        ) else 400

    @app.get("/api/health")
    def health():
        return jsonify({"product": "metaform-viewer", "instance_id": instance_id})

    @app.get("/static/<path:name>")
    def static_file(name):
        root = importlib.resources.files("metaform") / "static"
        if name not in {"workbench.js", "workbench.css", "structure.js", "cytoscape-view.js",
                        "vendor/cytoscape.min.js", "vendor/cytoscape-dagre.js"}:
            return "Not found", 404
        return Response(
            (root / name).read_text(),
            mimetype="text/javascript" if name.endswith(".js") else "text/css",
        )

    @app.get("/")
    def index():
        return render_template_string(
            (
                importlib.resources.files("metaform") / "templates" / "index.html"
            ).read_text(), project_prefix=g.project_prefix
        )

    @app.get("/api/report")
    def report():
        from .modules.viewer import report

        return jsonify(report(metaform, {}, None))

    def perspective_scope(perspective):
        scopes = {"inference": None, "contextual": "native", "latent": "archaeology"}
        if perspective not in scopes:
            raise ValueError("Unknown Metaform perspective: " + perspective)
        return scopes[perspective]

    @app.get("/api/graph")
    def graph():
        query = request.args.get("q", "*")
        graph = (
            metaform.global_graph
            if request.args.get("storage") == "global"
            else metaform.graph
        )
        scope = perspective_scope(request.args.get("perspective", "inference"))
        return jsonify(graph.search(query, scope=scope))

    @app.get("/api/network")
    def network():
        storage = request.args.get("storage", "project")
        graph = metaform.global_graph if storage == "global" else metaform.graph
        perspective = request.args.get("perspective", "inference")
        comparison = graph.similarity()
        similarity = comparison if perspective == "similarity" else None
        memberships = {
            (source, identifier): join["membership"]
            for join in comparison["joins"]
            for source, identifiers in join["sources"].items()
            for identifier in identifiers
        }
        scope = None if similarity is not None else perspective_scope(perspective)
        query = request.args.get("q", "*")
        layer = None if similarity is not None else request.args.get("layer") or None
        records = {} if similarity is not None else {r["id"]: r for r in graph.search(scope=scope)}
        joins = {j["id"]: j for j in (similarity["joins"] if similarity is not None else graph.joins(scope=scope))}

        def references(join):
            return {p["ref"] for p in join_participants(join) if p.get("ref")}

        sources = {scope} if scope else {"native", "archaeology", "merged"}
        record_ids = set(similarity["elements"]) if similarity is not None else {
            identifier for identifier, record in records.items()
            if sources.intersection(record.get("sources", []))
        }
        join_ids = set(joins) if similarity is not None else {
            identifier for identifier, join in joins.items()
            if join.get("join_scope") in sources
        }

        def include_participants(selected):
            # Include referenced joins as joins, preserving joins on joins.
            pending = list(selected)
            seen = set()
            refs = set()
            while pending:
                identifier = pending.pop()
                if identifier in seen:
                    continue
                seen.add(identifier)
                for ref in references(joins[identifier]):
                    refs.add(ref)
                    if ref in joins and ref not in seen:
                        selected.add(ref)
                        pending.append(ref)
            return refs

        record_ids.update(include_participants(join_ids) - set(joins))
        source_records = {}
        if perspective == "inference":
            for source in ("native", "archaeology"):
                for record in graph.search(scope=source):
                    source_records.setdefault(record["id"], {})[source] = record
        layers = sorted({records[i]["layer"] for i in record_ids if i in records})
        if query != "*" or layer:
            matched = {
                identifier for identifier in record_ids
                if fnmatch.fnmatchcase(identifier.lower(), query.lower())
                or ("*" not in query and query.lower() in identifier.lower())
            } if similarity is not None else {r["id"] for r in graph.search(query, layer, scope=scope)}
            if similarity is None:
                for identifier, record in records.items():
                    for variant in [record, *source_records.get(identifier, {}).values()]:
                        if ((not layer or variant["layer"] == layer)
                                and any(fnmatch.fnmatchcase(identifier.lower(), query.lower())
                                        or ("*" not in query and query.lower() in identifier.lower())
                                        for identifier in type_ids(variant))):
                            matched.add(identifier)
            record_ids.intersection_update(matched)
            join_ids = {
                identifier for identifier in join_ids
                if references(joins[identifier]).intersection(record_ids)
            }
            record_ids.update(include_participants(join_ids) - set(joins))

        classification_ids = set()
        if similarity is None:
            for identifier in list(record_ids):
                for variant in [records.get(identifier, {}), *source_records.get(identifier, {}).values()]:
                    for type_id in type_ids(variant):
                        while type_id:
                            classification_ids.add(type_id)
                            type_id = type_id.rpartition(".")[0]
            for identifier in sorted(classification_ids):
                record = (records.get(identifier) or graph.get(identifier, scope="authored")
                          or (metaform.global_graph.get(identifier) if storage == "project" else None))
                if record is not None and not type_ids(record):
                    records[identifier] = record
                    record_ids.add(identifier)

        nodes = {}
        for identifier in sorted(record_ids):
            if similarity is not None:
                nodes[identifier] = dict(similarity["elements"][identifier], id=identifier, name=identifier, kind="structure")
                continue
            record = records.get(identifier)
            nodes[identifier] = (
                dict(record, id=identifier, kind="element", name=record["entity_json_obj"].get("en", identifier))
                if record else
                {"id": identifier, "name": identifier, "kind": "reference", "sources": []}
            )
            if record and identifier in source_records:
                nodes[identifier]["source_records"] = source_records[identifier]
            if identifier in classification_ids:
                nodes[identifier]["classification_context"] = True
        edges = []
        for identifier in sorted(join_ids):
            join = joins[identifier]
            receiver, provider = join.get("object_id"), join.get("element_id")
            participants = join.get("participants", [])
            if not receiver and not provider:
                receivers = [p["ref"] for p in participants if p.get("role") == "receiver" and p.get("ref")]
                providers = [p["ref"] for p in participants if p.get("role") == "ef_owner" and p.get("ref")]
                if len(receivers) == len(providers) == 1:
                    receiver, provider = receivers[0], providers[0]
            # A direct edge represents a known receiving relationship only.
            # Other hyperedges remain intact in the separate joins collection.
            if (
                not receiver or not provider
                or receiver in joins or provider in joins
                or receiver not in nodes or provider not in nodes
                or any(p.get("ref") and p["ref"] not in {receiver, provider} for p in participants)
                or any(
                    p.get("ref") and p.get("role") in {"receiver", "ef_owner"}
                    and p["ref"] != {"receiver": receiver, "ef_owner": provider}[p["role"]]
                    for p in participants
                )
            ):
                continue
            edges.append({
                "id": identifier, "join_id": identifier,
                "source": provider, "target": receiver,
                "label": join["membership"] if similarity is not None else join.get("purpose", ""), "type": join["type"],
                "membership": join.get("membership") if similarity is not None or join.get("join_scope") == "merged"
                else memberships.get((join.get("join_scope"), identifier)),
            })
        return jsonify({
            "nodes": list(nodes.values()), "edges": edges, "layers": layers,
            "joins": [joins[identifier] for identifier in sorted(join_ids)],
            "backend": metaform.config.get("graph_backend", "sqlite"),
            "storage": storage,
            "perspective": perspective,
            "context": (metaform.get("native_context") or {})
            if storage == "project" and perspective in {"inference", "contextual"} else {},
        })

    @app.get("/api/element/<path:identifier>")
    def element(identifier):
        graph = (
            metaform.global_graph
            if request.args.get("storage") == "global"
            else metaform.graph
        )
        scope = perspective_scope(request.args.get("perspective", "inference"))
        record = graph.get(identifier, scope=scope)
        result = {
            "record": record,
            "joins": graph.joins(identifier, scope=scope),
            "provenance": [
                observation for observation in graph.provenance(identifier)
                if scope is None or observation["source"] == scope
            ],
        }
        if (
            graph is metaform.graph
            and record
            and record["entity_schema"] == "metaform:prompt"
        ):
            from . import prompts

            result["prompt"] = prompts.get(metaform, identifier)
        return jsonify(result)

    @app.post("/api/element/<path:identifier>")
    def edit(identifier):
        data = request.get_json()
        graph = (
            metaform.global_graph if data.get("storage") == "global" else metaform.graph
        )
        scope = perspective_scope(data.get("perspective", "inference"))
        if "join" in data:
            targets = {identifier, data["join"].get("id")}
            records = [data["join"], *[join for join in graph.joins() if join["id"] in targets]]
            if any(join.get("join_scope") == "merged" or join.get("schema_id") == "metaform:merged-join" for join in records):
                raise ValueError("Shape-similarity records are read-only; edit the Contextual or Latent source join.")
            result = graph.put({"joins": [data["join"]]}, scope or "edited")
        else:
            result = graph.put(
                {"elements": {identifier: data["record"]}},
                scope or "edited",
                data.get("layer", "elements"),
            )
        return jsonify(result)

    @app.get("/api/workflows")
    def workflows():
        from .workflow import Engine

        return jsonify(
            [
                {
                    "id": r["id"][9:],
                    "source": r["entity_json_obj"],
                    "executable": Engine(metaform).definition(r["id"][9:]),
                }
                for r in metaform.graph.search()
                if r["entity_schema"] == "metaform:workflow"
            ]
        )

    @app.get("/api/run/<identifier>")
    def run(identifier):
        return jsonify(metaform.load_run(identifier))

    @app.post("/api/call/<command>")
    def call(command):
        from .registry import Registry

        return jsonify(
            asyncio.run(
                Registry(g.metaform).call(
                    command, request.get_json() or {}, internal=True
                )
            )
        )

    @app.post("/api/workflow/import")
    def workflow_import():
        from .workflow import import_workflow

        return jsonify(import_workflow(metaform, request.get_json()))

    @app.get("/api/community")
    def community():
        return jsonify(
            {
                "repository": "https://github.com/RchGrav/metaform",
                "export_command": "metaform sync export",
                "merge_command": "metaform sync merge",
                "modules": [
                    str(metaform.home / "modules"),
                    str(metaform.root / "modules"),
                ],
                "self_target": "Run intake from the Metaform source checkout to construct its own Metaform.",
            }
        )

    @app.get("/api/history")
    def versions():
        from .history import initialize

        return jsonify(initialize(metaform))

    @app.post("/api/preview")
    def preview():
        from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
        from functools import partial
        from .history import initialize, reconstruct

        manifest = initialize(metaform)
        versions = (
            request.get_json().get("versions")
            or list(manifest["versions"])
            or ["origin"]
        )
        result = []
        for version in versions:
            key = (metaform.project, version)
            if key not in previews:
                folder = Path(tempfile.mkdtemp(prefix="metaform-preview-"))
                reconstruct(metaform, version, folder)

                class Handler(SimpleHTTPRequestHandler):
                    def log_message(self, *args):
                        pass

                service = ThreadingHTTPServer(
                    ("127.0.0.1", 0), partial(Handler, directory=str(folder))
                )
                threading.Thread(target=service.serve_forever, daemon=True).start()
                previews[key] = (service, folder)
            service, folder = previews[key]
            result.append(
                {"version": version, "url": f"http://127.0.0.1:{service.server_port}/"}
            )
        return jsonify(result)

    @app.post("/api/preview/stop")
    def stop_previews():
        for key, (service, folder) in list(previews.items()):
            if key[0] == metaform.project:
                service.shutdown()
                service.server_close()
                shutil.rmtree(folder)
                del previews[key]
        return jsonify({"stopped": True})

    @app.get("/api/settings")
    def settings():
        return jsonify(
            {
                "project": str(metaform.project),
                "project_id": metaform.project_id,
                "name": metaform.project_name,
                "knowledge_mode": metaform.knowledge_mode,
                "assignment": metaform.binding,
                "backend": metaform.config.get("graph_backend", "sqlite"),
                "harnesses": list(metaform.config.get("harnesses", {})),
                "contribution": "Metaform works best when you can contribute reusable Inference Metaform data upstream. Review and publish through the sync module.",
                "author": "Richard Graver",
                "repository": "https://github.com/RchGrav/metaform",
            }
        )

    @app.get("/api/projects")
    def project_list():
        with project_lock:
            return jsonify(list(project_catalog().values()))

    @app.post("/api/projects/open")
    def project_open():
        from uuid import NAMESPACE_URL, uuid5

        path = (request.get_json() or {}).get("path")
        if not isinstance(path, str) or not path.strip():
            raise ValueError("Enter an existing project folder")
        project = Path(path.strip()).expanduser()
        project = (metaform.project / project).resolve()
        if not project.is_dir():
            raise ValueError("Project folder does not exist: " + str(project))
        if metaform.binding:
            raise ValueError("Project selection cannot change a bound assignment")
        with project_lock:
            for key, selected in projects.items():
                if selected.project == project:
                    return jsonify(selected.project_context() | {"url": "/projects/" + key + "/"})
            selected = metaform.select_project(project)
            key = selected.project_id
            catalog = project_catalog()
            if key in catalog and catalog[key]["path"] != str(project):
                key += "-" + uuid5(NAMESPACE_URL, str(project)).hex
            projects[key] = selected
            return jsonify(selected.project_context() | {"url": "/projects/" + key + "/"})

    @app.get("/api/dump")
    def dump():
        response = jsonify(metaform.graph.export())
        response.headers["Content-Disposition"] = (
            'attachment; filename="metaform-graph.json"'
        )
        return response

    for rule in list(app.url_map.iter_rules()):
        if rule.rule.startswith("/static/"):
            continue
        app.add_url_rule("/projects/<project_id>" + rule.rule,
                         endpoint="project_" + rule.endpoint,
                         view_func=app.view_functions[rule.endpoint], methods=rule.methods)
    return app


def main():
    from werkzeug.serving import make_server
    from .app import App
    from .util import write_json

    parser = argparse.ArgumentParser()
    for name in ("project", "home", "host", "ready", "stop"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()
    selected = App(args.project, args.home)
    instance_id = Path(args.ready).stem
    server = make_server(
        args.host, args.port, create_app(selected, instance_id), threaded=True
    )
    write_json(
        Path(args.ready),
        {"url": f"http://{args.host}:{server.server_port}/projects/{selected.project_id}", "port": server.server_port, "instance_id": instance_id},
    )

    def monitor():
        import time

        while not Path(args.stop).exists():
            time.sleep(0.2)
        server.shutdown()

    thread = threading.Thread(target=monitor, daemon=True)
    thread.start()
    try:
        server.serve_forever()
    finally:
        server.server_close()
        Path(args.ready).unlink(missing_ok=True)
        Path(args.stop).unlink(missing_ok=True)


if __name__ == "__main__":
    main()
