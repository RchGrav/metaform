from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def dumps(value):
    def encode(item):
        if hasattr(item, "model_dump"):
            return item.model_dump(mode="json", by_alias=True)
        if isinstance(item, Path):
            return str(item)
        raise TypeError(f"Cannot encode {type(item).__name__} as JSON")

    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=encode
    )


def digest(value):
    return hashlib.sha256(dumps(value).encode()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def read_json(path, default=None):
    return (
        json.loads(Path(path).read_text(encoding="utf-8"))
        if Path(path).exists()
        else default
    )


def input_value(value):
    if not isinstance(value, str):
        return value
    if value.startswith("@"):
        return json.loads(Path(value[1:]).read_text(encoding="utf-8"))
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def archive_metadata():
    """Expose wheel-vendored metadata that Python cannot discover inside a ZIP subpath."""
    import sys

    archive = Path(__file__).parent.parent
    if not archive.is_file():
        return
    if any(getattr(finder, "metaform_archive", None) == archive for finder in sys.meta_path):
        return
    import importlib.metadata
    import re
    import zipfile

    with zipfile.ZipFile(archive) as package:
        directories = sorted(
            {
                name.rsplit("/", 1)[0] + "/"
                for name in package.namelist()
                if name.startswith("_portable/") and name.endswith(".dist-info/METADATA")
            }
        )
    if not directories:
        return

    class ArchiveMetadataFinder(importlib.metadata.DistributionFinder):
        metaform_archive = archive

        def find_distributions(self, context=importlib.metadata.DistributionFinder.Context()):
            if str(archive) + "/_portable" not in map(str, context.path):
                return
            normalize = lambda name: re.sub(r"[-_.]+", "-", name).lower()
            for directory in directories:
                distribution = importlib.metadata.PathDistribution(
                    zipfile.Path(str(archive), directory)
                )
                if context.name is None or normalize(distribution.metadata["Name"]) == normalize(context.name):
                    yield distribution

    sys.meta_path.insert(0, ArchiveMetadataFinder())


def python_environment():
    """Keep direct wheel execution importable in chassis child processes."""
    import sys

    environment = dict(os.environ)
    import zipfile

    archives = [
        str(Path(entry).resolve())
        for entry in sys.path
        if entry and Path(entry).is_file() and zipfile.is_zipfile(entry)
    ]
    if archives:
        paths = []
        for archive in archives:
            paths.append(archive)
            with zipfile.ZipFile(archive) as package:
                if any(n.startswith("_portable/") for n in package.namelist()):
                    paths.append(archive + "/_portable")
        environment["PYTHONPATH"] = os.pathsep.join(
            paths
            + ([environment["PYTHONPATH"]] if environment.get("PYTHONPATH") else [])
        )
    return environment
