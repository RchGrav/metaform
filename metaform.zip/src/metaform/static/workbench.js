'use strict';
const $=id=>document.getElementById(id), pretty=x=>JSON.stringify(x,null,2), value=id=>$(id).value.trim();
const parse=id=>{const text=value(id);if(!text)return {};try{return JSON.parse(text)}catch{return text}};
const element=(tag,text,cls)=>{const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e};
let selected=null, prepared=null, pending=null, currentVersion='origin', library=[], ruleLibrary=[], ruleDraft={}, promptDraft={}, promptRuleBaseline='[]', inspected=null, fieldBaseline={}, workflows=[], page='graph';
const projectPrefix=document.body.dataset.projectPrefix||'';
async function api(path,body){const r=await fetch(projectPrefix+path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.error||r.statusText);return data}
async function call(command,args={}){return api('/api/call/'+command,args)}
function notice(text,error=false){$('notice').textContent=text;$('notice').className=error?'error':'';$('notice').style.display='block';setTimeout(()=>$('notice').style.display='none',9000)}
function on(id,fn){$(id).onclick=async()=>{try{await fn()}catch(e){notice(e.message,true)}}}
function show(tab){page=tab;window.scrollTo(0,0);$('notice').style.display='none';document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===tab));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));$('title').textContent={graph:'Project Metaform',rules:'Rule editor',prompts:'Prompt editor',workflows:'Saved workflows',versions:'Project versions',activity:'Recorded activity'}[tab];refresh().catch(e=>notice(e.message,true))}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>show(b.dataset.tab));
async function refresh(){if(page==='graph')await graphLoad();if(page==='rules')await rulesLoad();if(page==='prompts')await promptsLoad();if(page==='workflows')await workflowsLoad();if(page==='versions')await versionsLoad();if(page==='activity')await activityLoad();}
on('refresh',async()=>{await Promise.all([refresh(),projectsLoad()])});
let nodes=[],edges=[],joins=[],focusId=null,graphContext={},graphDatasetKey=null,inspectorPerspective='inference',inspectionSequence=0;
const typeIds=MetaformScene.typeIds,isActual=MetaformScene.isActual;
const colors={native:'#a5dec7',archaeology:'#b7acf1',merged:'#e4ad81'};
function membershipLabel(value){return {'01':'1','10':'2','11':'3'}[value]??value}
const structure=new MetaformStructure($('graph-canvas-view'),{
  onBeforeNavigate:async id=>{if(value('search')||value('layer')||(id&&!structure.records.some(n=>n.id===id))){$('search').value='';$('layer').value='';await graphLoad();}},
  onSelect:n=>inspect(n).catch(e=>notice(e.message,true)),
  onNavigate:id=>{focusId=id;selected=structure.scene.nodes.find(n=>n.id===id)||null;$('node-editor').hidden=true;updateFocusControls();renderTypeDetail();if(selected)inspect(selected).catch(e=>notice(e.message,true));}
});
function resize(){if(!structure.initialFit&&structure.svg.clientWidth){structure.fit(false);structure.initialFit=true;}}
function draw(){structure.highlight(selected?.id)}
function updateFocusControls(){
  $('focus-selection').disabled=!selected||selected.kind==='join';
  $('graph-focus').textContent=structure.focus?'Connections to '+structure.focus:'Project overview';
  const defining=structure.records.filter(n=>isActual(n)&&(n.defining||n.entity_json_obj?.defining_element===true));
  $('graph-defining').hidden=!defining.length;
}
function showEdgeDetail(n){
  const card=$('edge-detail'),content=$('edge-detail-content');content.replaceChildren();card.hidden=true;
  if(n.kind!=='join'||$('graph-canvas-view').hidden)return;
  content.append(element('h3','Operative Purpose'),element('p',metaformPurposeText(n.join.purpose)||'No Operative Purpose recorded.'));
  if(n.join.signal!==undefined)content.append(element('h3','Signal'),element('p',fieldText(n.join.signal)));
  card.hidden=false;card.style.left='18px';card.style.top='76px';
}
on('close-edge-detail',()=>{$('edge-detail').hidden=true});
function renderTypeDetail(){
  const panel=$('type-detail');panel.replaceChildren();
  const id=structure.focus,n=structure.scene.nodes.find(n=>n.id===id&&n.kind!=='namespace');
  const header=element('div','','type-detail-heading');header.append(element('span',id?(n&&isActual(n)?'ACTUAL ELEMENT': 'INSIDE THE TYPE'):'PROJECT UNDERSTANDING','eyebrow'),element('h2',id?(n?metaformTypeName(n):id):($('project-name').textContent||'Project')));panel.append(header);
  if(id)panel.append(element('code',id));
  if(n)for(const id of typeIds(n)){const type=element('button','Type: '+id,'classification-link');type.onclick=()=>structure.openType(id);panel.append(type);}
  function fields(container,obj){
    const list=element('dl','','functional-fields');
    for(const [key,val] of Object.entries(obj||{})){
      const term=element('dt',({'ef':'Encounter Function','notes':'Project detail','en':'Element Name','length':'Name length','parametric_elements':'Parametric'}[key]||key.replaceAll('_',' ')));
      const description=element('dd','');
      if(Array.isArray(val)){
        const items=element('ul','');for(const item of val){const li=element('li','');if(item&&typeof item==='object')fields(li,item);else li.textContent=fieldText(item);items.append(li)}description.append(items);
      }else if(val&&typeof val==='object')fields(description,val);else description.textContent=fieldText(val);
      list.append(term,description);
    }container.append(list);
  }
  if(!id){if(Object.keys(graphContext).length)fields(panel,graphContext);else panel.append(element('p','Open a Type to explore its recorded functions and relationships.','muted'));}
  else if(n){
    const variants=n.source_records&&Object.keys(n.source_records).length?n.source_records:{recorded:n};
    for(const [source,record] of Object.entries(variants)){
      const section=element('details','','functional-source');section.open=source==='native'||source==='recorded'||!variants.native;section.append(element('summary',({native:isActual(record)?'Native · actual project detail':'Native · Type definition',archaeology:isActual(record)?'Latent · outside review':'Latent · Type definition',recorded:isActual(record)?'Recorded actual project detail':'Recorded Type definition'}[source]||source)));
      if(record.entity_desc&&!Object.hasOwn(record.entity_json_obj||{},'description'))section.append(element('p',fieldText(record.entity_desc),'type-description'));
      fields(section,Object.fromEntries(Object.entries(record.entity_json_obj||{}).filter(([key])=>key!=='svg')));panel.append(section);
    }
    if(isActual(n))renderTypeMembership(panel,n);
  }else panel.append(element('p','Namespace group organizing the recorded Elements below.','muted'));
  if(id){
    const relevant=structure.scene.joins;
    const details=element('details','','functional-joins');details.open=false;details.append(element('summary',relevant.length+' relationships in this view'));
    for(const join of relevant){const row=element('div','','functional-join');
      const button=element('button',metaformPurposeText(join.purpose)||join.id,'connection-purpose');button.onclick=()=>inspect({id:join.id,kind:'join',join}).catch(e=>notice(e.message,true));
      row.append(element('span',fieldText(join.type)||'Join','join-type'),button);
      row.append(element('small',metaformJoinReferences(join).join(' · ')));
      if(join.signal!==undefined)row.append(element('p','Signal: '+fieldText(join.signal)));details.append(row);
    }panel.append(details);
  }
}
function renderDefiningRelation(n){
  const container=$('node-defining-relation');container.replaceChildren();
  if(!isActual(n))return;
  const relation=MetaformScene.definingRelation(structure.records,structure.joins,n.id);
  container.append(element('h3','Relation to the Defining Element'));
  if(!relation){container.append(element('p','No recorded connection in this view.','muted'));return;}
  if(!relation.steps.length){container.append(element('p','This is the Defining Element.','muted'));return;}
  for(const step of relation.steps){
    const row=element('div','','defining-step');
    row.append(element('small',fieldText(step.join.type),'join-type'));
    const purpose=element('button',metaformPurposeText(step.join.purpose)||step.join.id,'connection-purpose');purpose.onclick=()=>inspect({id:step.join.id,kind:'join',join:step.join}).catch(e=>notice(e.message,true));row.append(purpose);
    const target=structure.records.find(n=>n.id===step.to)||{id:step.to};
    const targetJoin=structure.joins.find(j=>j.id===step.to);
    const button=element('button',targetJoin?metaformPurposeText(targetJoin.purpose)||step.to:metaformTypeName(target),'record-reference');button.onclick=()=>targetJoin?inspect({id:targetJoin.id,kind:'join',join:targetJoin}).catch(e=>notice(e.message,true)):structure.openType(step.to);row.append(button);container.append(row);
  }
}
function renderTypeMembership(container,n){
  for(const id of typeIds(n)){
    const record=structure.records.find(record=>record.id===id),obj=record?.entity_json_obj||{};
    const detail=element('details','','type-membership');detail.append(element('summary','Type · '+id));
    if(record?.entity_desc)detail.append(element('p',record.entity_desc,'type-description'));
    if(obj.ef)detail.append(element('p','Encounter Function: '+fieldText(obj.ef)));
    const open=element('button','Browse '+id,'classification-link');open.onclick=()=>structure.openType(id);detail.append(open);container.append(detail);
  }
}
function updateGraphDisplay(reset=false){
  $('edge-detail').hidden=true;
  const type=value('relationship-type'),similarity=value('perspective')==='similarity';
  const visibleSource=scope=>similarity||!['native','archaeology','merged'].includes(scope)||$('source-'+scope).checked;
  const visibleJoins=joins.filter(n=>visibleSource(n.join.join_scope)&&(!type||JSON.stringify(n.join.type??null)===type));
  const refs=new Set(visibleJoins.flatMap(n=>metaformJoinReferences(n.join))),joinIds=new Set(visibleJoins.map(n=>n.id));
  const definingIds=new Set(visibleJoins.flatMap(n=>(n.join.participants||[]).filter(p=>p.role==='defining_element').map(p=>p.ref)));
  const visibleNodes=nodes.filter(n=>(!n.sources?.length||n.sources.some(visibleSource)||refs.has(n.id))&&(!type||refs.has(n.id))).map(n=>{
    if(!n.source_records)return {...n,defining:n.entity_json_obj?.defining_element===true||definingIds.has(n.id)};
    const source_records=Object.fromEntries(Object.entries(n.source_records).filter(([source])=>visibleSource(source)));
    const record=source_records.native||source_records.archaeology||Object.values(source_records)[0];
    if(record)return {...n,entity_schema:record.entity_schema,entity_json_obj:record.entity_json_obj,entity_desc:record.entity_desc,defining:record.entity_json_obj?.defining_element===true||definingIds.has(n.id),source_records};
    if(!Object.keys(n.source_records).length&&(!n.sources?.length||n.sources.every(visibleSource)))return n;
    return {id:n.id,kind:'reference',entity_json_obj:{},source_records:{},sources:[]};
  });
  structure.setData(visibleNodes,visibleJoins.map(n=>n.join),edges.filter(e=>joinIds.has(e.join_id)),{reset:reset===true,labels:$('node-labels').checked,similarity:$('edge-similarity').checked});
  focusId=structure.focus;
  $('graph-empty').hidden=structure.scene.nodes.length>0;
  updateFocusControls();renderTypeDetail();
}
on('fit',()=>structure.fit());
on('zoom-in',()=>structure.zoom(1.25));on('zoom-out',()=>structure.zoom(.8));
on('graph-back',()=>structure.back());
on('graph-types',()=>structure.resetToTypes());
on('graph-defining',()=>{const relation=MetaformScene.definingRelation(structure.records,structure.joins,structure.focus);const id=relation?.defining||structure.records.find(n=>isActual(n)&&(n.defining||n.entity_json_obj?.defining_element))?.id;if(id)return structure.openType(id)});
on('focus-selection',()=>structure.enter(selected.id));
on('reset-graph',()=>{selected=null;$('relationship-type').value='';$('source-native').checked=true;$('source-archaeology').checked=true;$('source-merged').checked=false;updateGraphDisplay(true)});
$('relationship-type').onchange=()=>updateGraphDisplay();
$('node-labels').onchange=()=>updateGraphDisplay();
$('edge-similarity').onchange=()=>{$('edge-color-key').hidden=!$('edge-similarity').checked;updateGraphDisplay()};
for(const id of ['source-native','source-archaeology','source-merged'])$(id).onchange=()=>{
  updateGraphDisplay();
  if(selected){const visible=structure.scene.nodes.find(n=>n.id===selected.id)||structure.records.find(n=>n.id===selected.id);if(visible)inspect(visible).catch(e=>notice(e.message,true));else{$('node-editor').hidden=true;$('node-connections').hidden=true;}}
};
async function graphLoad(){
  const storage=value('storage'),similarity=value('perspective')==='similarity';
  const data=await api('/api/network?'+new URLSearchParams({q:value('search')||'*',storage,perspective:value('perspective'),layer:value('layer')}));
  graphContext=data.context||{};
  const datasetKey=storage+'|'+value('perspective')+'|'+value('layer'),reset=datasetKey!==graphDatasetKey;graphDatasetKey=datasetKey;
  const definingIds=new Set(data.joins.flatMap(j=>(j.participants||[]).filter(p=>p.role==='defining_element').map(p=>p.ref)));
  nodes=data.nodes.map(n=>({...n,defining:definingIds.has(n.id)||(n.source_records?.native?.entity_json_obj||n.entity_json_obj)?.defining_element===true}));
  const byId=new Map(nodes.map(n=>[n.id,n]));
  joins=data.joins.map(join=>({id:join.id,name:join.id,kind:'join',join}));
  const joinById=new Map(data.joins.map(j=>[j.id,j]));
  edges=data.edges.map(e=>({...e,scope:joinById.get(e.join_id)?.join_scope,membership:e.membership??joinById.get(e.join_id)?.membership,source:byId.get(e.source),target:byId.get(e.target)})).filter(e=>e.source&&e.target);
  const relationship=value('relationship-type');
  $('relationship-type').replaceChildren(element('option','Every relationship type'));
  $('relationship-type').firstChild.value='';
  for(const type of [...new Set(data.joins.map(j=>j.type??null))].sort()){
    const option=element('option',type??'Unspecified type');option.value=JSON.stringify(type);$('relationship-type').append(option);
  }
  $('relationship-type').value=relationship;
  $('backend').textContent=data.backend;
  $('graph-count').textContent=`${nodes.length} Elements · ${joins.length} ${joins.length===1?'join':'joins'}`;
  $('unprojected-joins').hidden=true;
  if(page==='graph')$('title').textContent=storage==='global'?'Global type knowledge':'Project Metaform';
  $('graph-description').textContent=similarity?'Structural correspondence: 1 Native only · 2 Latent only · 3 present in both. Source references retain access to each independent graph.':({inference:'Contextual and latent',contextual:'Contextual',latent:'Latent'}[value('perspective')]+' Elements and joins '+(storage==='global'?'held in shared global storage.':'recorded for the selected project.'));
  $('layer').hidden=similarity;$('graph-sources').hidden=similarity;
  $('graph-edge-legend').textContent=similarity?'→ Provider to receiver · 1 Native · 2 Latent · 3 Both':'Solid: namespace · arrows: OP joins · dashed: property · dotted: supportive';
  $('graph-empty').hidden=nodes.length>0;
  const filtered=value('search')||value('layer')||value('perspective')!=='inference';
  $('graph-empty-title').textContent=filtered?'No matching Elements or joins':storage==='global'?'No global inference recorded yet':'No project intake data yet';
  $('graph-empty-description').textContent=filtered?'Change the search, Metaform view, or layer to inspect other Elements and joins.':'This view fills as intake records Elements and joins. The supplied instructions are available in Prompts.';
  if(!nodes.length&&joins.length){$('graph-empty-title').textContent='Joins available in List';$('graph-empty-description').textContent='These records do not identify an unambiguous provider → receiver connection.';}
  if(selected){selected=byId.get(selected.id)||joins.find(j=>j.id===selected.id)||null;if(!selected){$('node-editor').hidden=true;$('node-title').textContent='Select a record';$('node-hint').textContent='Inspect its text, relationships, and recorded source.';}}
  const selectedLayer=value('layer');
  $('layer').replaceChildren(element('option','Every layer'));$('layer').firstChild.value='';
  for(const l of data.layers){const o=element('option',l);o.value=l;$('layer').append(o)}
  if(selectedLayer&&!data.layers.includes(selectedLayer)){const o=element('option',selectedLayer);o.value=selectedLayer;$('layer').append(o)}
  $('layer').value=selectedLayer;
  renderMetaformList();renderConnections();updateGraphDisplay(reset);resize();
}
let searchTimer;$('search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>graphLoad().catch(e=>notice(e.message,true)),250)};$('storage').onchange=$('perspective').onchange=()=>{selected=null;$('node-editor').hidden=true;$('node-title').textContent='Select a record';$('layer').value='';graphLoad().catch(e=>notice(e.message,true))};$('layer').onchange=()=>graphLoad().catch(e=>notice(e.message,true));
$('backend-choice').onchange=async()=>{try{if(!value('backend-choice'))return;const r=await call('graph.backend',{name:value('backend-choice')});notice(r.knowledge_backend?'Knowledge: '+r.knowledge_backend+' · Analysis: '+(r.analytical_backend||'none'):'Storage: '+r.backend);$('backend').textContent=r.knowledge_backend||r.backend;await graphLoad()}catch(e){notice(e.message,true)}};
const fieldText=x=>x===undefined?'':typeof x==='string'?x:pretty(x);
function setGraphPresentation(view){
  const list=view==='list';
  $('graph-canvas-view').hidden=list;$('metaform-list').hidden=!list;
  $('show-graph').setAttribute('aria-pressed',String(!list));$('show-list').setAttribute('aria-pressed',String(list));
  for(const id of ['fit','zoom-in','zoom-out','zoom-level'])$(id).hidden=list;$('structure-navigation').hidden=list;$('type-detail').hidden=list;
  const url=new URL(window.location.href);if(list)url.searchParams.set('view','list');else url.searchParams.delete('view');
  window.history.replaceState(null,'',url);if(!list){structure.cy.resize();resize()}
}
on('show-graph',()=>setGraphPresentation('graph'));on('show-list',()=>setGraphPresentation('list'));
function renderMetaformList(){
  const similarity=value('perspective')==='similarity';
  const elementHeaders=similarity?['Namespace','Membership','Source references','']:['Namespace','Element Name · EN','Element Description · ED','Encounter Function · EF'];
  $('element-rows').parentElement.querySelectorAll('thead th').forEach((th,i)=>th.textContent=elementHeaders[i]);
  $('join-rows').parentElement.querySelector('thead th:last-child').textContent=similarity?'Membership':'Operative Purpose · OP';
  $('list-count').textContent=`${nodes.length} Elements · ${joins.length} joins`;
  for(const [id,isJoin] of [['element-rows',false],['join-rows',true]]){
    const body=$(id);body.replaceChildren();
    for(const n of isJoin?joins:nodes){
      const row=element('tr','');row.dataset.nodeId=n.id;row.classList.toggle('selected',selected?.id===n.id);
      const reference=element('td',''),button=element('button',n.id,'record-reference');
      button.setAttribute('aria-label','Inspect '+n.id);button.onclick=()=>inspect(n).catch(e=>notice(e.message,true));reference.append(button);row.append(reference);
      const obj=n.entity_json_obj||{},join=n.join||{};
      const connection=edges.find(e=>e.join_id===n.id);
      const participants=connection?connection.source.id+' → '+connection.target.id:join.participants||{object_id:join.object_id,element_id:join.element_id};
      const cells=isJoin?[join.type,participants,similarity?membershipLabel(join.membership):join.purpose]:similarity?[membershipLabel(n.membership),n.sources,'']:[obj.en,n.entity_desc,obj.ef];
      for(const data of cells)row.append(element('td',fieldText(data)));
      body.append(row);
    }
    if(!body.children.length){const row=element('tr',''),cell=element('td',isJoin?'No joins in this view.':'No Elements in this view.','muted');cell.colSpan=4;row.append(cell);body.append(row)}
  }
}
function renderConnections(records=joins.map(n=>n.join)){
  const container=$('node-connections');container.replaceChildren();container.hidden=!selected||selected.kind==='join';
  if(container.hidden)return;
  const relevant=records.filter(join=>metaformJoinReferences(join).includes(selected.id)&&
    (value('perspective')==='similarity'||!['native','archaeology','merged'].includes(join.join_scope)||$('source-'+join.join_scope).checked));
  container.append(element('h3',relevant.length+' joins to this Element'));
  if(!relevant.length)container.append(element('p','No joins recorded in the selected sources.','muted'));
  for(const join of relevant){const row=element('div','','connection');row.dataset.joinId=join.id;
    row.append(element('span',fieldText(join.type)||'Join','join-type'));
    if(join.join_scope)row.append(element('small',({native:'Native',archaeology:'Latent',merged:'Shared'}[join.join_scope]||join.join_scope),'connection-source'));
    const purpose=element('button',metaformPurposeText(join.purpose)||join.id,'connection-purpose');purpose.onclick=()=>inspect({id:join.id,kind:'join',join}).catch(e=>notice(e.message,true));row.append(purpose);
    for(const ref of metaformJoinReferences(join)){
      const other=structure.records.find(n=>n.id===ref)||joins.find(n=>n.id===ref)||{id:ref,kind:'reference'};
      const label=ref===join.object_id?'Receiver':ref===join.element_id?'Provider':'Participant';
      row.append(element('small',label,'connection-label'));
      const button=element('button',metaformTypeName(other),'record-reference');button.dataset.ref=ref;button.title=ref;button.onclick=()=>{const action=other.kind==='join'?inspect(other):structure.openType(ref);Promise.resolve(action).catch(e=>notice(e.message,true))};row.append(button);
    }
    if(join.signal!==undefined)row.append(element('p','Signal: '+fieldText(join.signal),'connection-signal'));
    container.append(row);
  }
}
setGraphPresentation(new URLSearchParams(window.location.search).get('view'));

function populateSemanticFields(record,isJoin){
  const obj=record.entity_json_obj||{};
  const actual=isActual(record);
  const fields=isJoin?{'join-purpose':record.purpose,'join-logic':record.join_logic}:{'node-name':obj.en||obj.name,'node-description':actual&&obj.description!==undefined?obj.description:record.entity_desc,'node-function':obj.ef,'node-notes':obj.notes,'node-aliases':obj.aliases};
  $('node-description').previousElementSibling.textContent=actual?'Actual description':'Type Description';
  $('node-name').previousElementSibling.textContent=actual?'Element name':'Type name';
  for(const [id,key] of [['node-function','ef'],['node-notes','notes'],['node-aliases','aliases']]){
    const hidden=actual&&obj[key]===undefined;$(id).hidden=hidden;$(id).previousElementSibling.hidden=hidden;
  }
  $('node-types').replaceChildren();if(actual)renderTypeMembership($('node-types'),record);
  fieldBaseline={};
  for(const [id,data] of Object.entries(fields)){const text=fieldText(data);$(id).value=text;fieldBaseline[id]={text,data};}
  if(isJoin)sizeJoinPurpose();
}
function sizeJoinPurpose(){const field=$('join-purpose');field.style.height='auto';field.style.height=(field.scrollHeight+field.offsetHeight-field.clientHeight)+'px'}
$('join-purpose').oninput=sizeJoinPurpose;
function applySemanticField(target,key,id,json=false){
  const text=$(id).value, prior=fieldBaseline[id];
  if(text===prior.text)return;
  target[key]=json||(prior.data!==undefined&&typeof prior.data!=='string')?JSON.parse(text):text;
}
async function inspect(n,anchor){
  const request=++inspectionSequence;
  selected=n;updateFocusControls();draw();$('node-title').textContent=n.kind==='join'?'Join':metaformTypeName(n);
  showEdgeDetail(n,anchor);renderConnections();renderDefiningRelation(n);$('node-types').replaceChildren();
  if(n.kind==='reference'){ $('node-editor').hidden=true;$('node-title').textContent=n.id;$('node-hint').textContent='Referenced Element · no detail in the selected sources.';return; }
  if(n.kind==='namespace'){ $('node-editor').hidden=true;$('node-title').textContent=n.id;$('node-hint').textContent='Namespace group · double-click to explore its recorded Elements.';return; }
  document.querySelectorAll('#metaform-list tr[data-node-id]').forEach(row=>row.classList.toggle('selected',row.dataset.nodeId===n.id));
  if(value('perspective')==='similarity'||n.join?.join_scope==='merged'||n.join?.schema_id==='metaform:merged-join'){
    const structure=n.join||{id:n.id,membership:n.membership,sources:n.sources};
    $('node-title').textContent=n.kind==='join'?'Join structure':n.id;$('node-id').textContent=n.id;
    $('node-hint').textContent=structure.membership?'Structural membership: '+membershipLabel(structure.membership)+' · 1 Native · 2 Latent · 3 Both':'Read-only structural comparison record';
    $('node-editor').hidden=false;$('element-fields').hidden=true;$('join-fields').hidden=true;
    $('save-node').hidden=true;$('open-prompt').hidden=true;$('node-json').readOnly=true;
    $('node-json').value=pretty(structure);$('node-json').closest('details').open=true;
    $('node-history').textContent=pretty({membership:structure.membership,sources:structure.sources});
    return;
  }
  const source=n.join?.join_scope||(n.source_records?.native?'native':n.source_records?.archaeology?'archaeology':null);
  const perspective=value('perspective')==='inference'?({native:'contextual',archaeology:'latent'}[source]||'inference'):value('perspective');
  for(const field of $('node-editor').querySelectorAll('input,textarea,button'))field.disabled=true;
  const path='/api/element/'+encodeURIComponent(n.id)+'?';
  const [data,relationships]=await Promise.all([
    api(path+new URLSearchParams({storage:value('storage'),perspective})),
    perspective===value('perspective')?Promise.resolve(null):api(path+new URLSearchParams({storage:value('storage'),perspective:value('perspective')}))
  ]);
  if(selected!==n||request!==inspectionSequence)return;
  renderConnections((relationships||data).joins);
  for(const field of $('node-editor').querySelectorAll('input,textarea,button'))field.disabled=false;
  inspectorPerspective=perspective;
  inspected=n.join||data.record||{entity_desc:'',entity_schema:'metaform:element',entity_json_obj:{en:n.name}};
  $('node-title').textContent=n.kind==='join'?'Join':metaformTypeName(n);$('node-id').textContent=n.id;
  $('node-hint').textContent=n.kind==='join'?'Join participants, purpose, logic, and provenance.':(source?[source]:n.sources||[]).map(s=>({native:'Contextual',archaeology:'Latent',merged:'Both sources',authored:'Authored',test:'Recorded response',workflow:'Workflow output',edited:'Edited',promoted:'Copied to global',packaged:'Packaged'}[s]||s)).join(' · ');
  $('node-editor').hidden=false;$('element-fields').hidden=n.kind==='join';$('join-fields').hidden=n.kind!=='join';
  $('save-node').hidden=false;$('node-json').readOnly=false;
  populateSemanticFields(inspected,n.kind==='join');
  $('join-value-hint').textContent='Structured values are displayed and edited as JSON; text values remain text.';
  $('node-json').value=pretty(inspected);$('node-history').textContent=pretty({joins:data.joins,provenance:data.provenance});$('open-prompt').hidden=data.record?.entity_schema!=='metaform:prompt';
}
on('save-node',async()=>{
  if(!selected)return;
  const record=JSON.parse($('node-json').value), body={storage:value('storage'),perspective:inspectorPerspective};
  if(selected.kind==='join'){
    applySemanticField(record,'purpose','join-purpose');applySemanticField(record,'join_logic','join-logic');body.join=record;
  }else{
    record.entity_json_obj ||= {};
    if(isActual(record)&&record.entity_json_obj.description!==undefined)applySemanticField(record.entity_json_obj,'description','node-description');
    else applySemanticField(record,'entity_desc','node-description');
    for(const [key,id] of [['en','node-name'],['ef','node-function'],['notes','node-notes'],['aliases','node-aliases']])applySemanticField(record.entity_json_obj,key,id,key==='aliases');
    body.record=record;body.layer=selected.layer||'elements';
  }
  await api('/api/element/'+encodeURIComponent(selected.id),body);notice('Revision saved.');await graphLoad();if(selected)await inspect(structure.scene.nodes.find(n=>n.id===selected.id)||selected);
});
on('open-prompt',async()=>{const id=selected.id;show('prompts');await promptsLoad();choosePrompt(id)});
on('query',async()=>{$('query-result').textContent=pretty(await call('graph.cypher',{query:$('cypher').value,global:value('storage')==='global'}))});
async function rulesLoad(){
  ruleLibrary=(await api('/api/graph')).filter(r=>r.entity_schema==='metaform:semantic-rule');
  $('rule-list').replaceChildren();
  for(const r of ruleLibrary){const rule=r.entity_json_obj,b=element('button','', 'list-item');b.append(element('b',rule.rule_code),element('small',rule.purpose));b.onclick=()=>chooseRule(rule.rule_code).catch(e=>notice(e.message,true));$('rule-list').append(b)}
  if(!value('rule-code')&&ruleLibrary.length)await chooseRule(ruleLibrary[0].entity_json_obj.rule_code);
}
function addRuleExample(example={example:'',assessment:'accepted',reason:''}){
  const row=element('fieldset','', 'rule-example');row.exampleSource=example;
  row.append(element('legend','Example'));
  for(const [key,title] of [['example','Example'],['assessment','Assessment'],['reason','Reason']]){
    const label=element('label',title),input=document.createElement(key==='assessment'?'select':'textarea');
    input.dataset.field=key;
    if(key==='assessment')for(const assessment of ['accepted','rejected']){const option=element('option',assessment);option.value=assessment;input.append(option)}
    else input.rows=key==='example'?3:2;
    input.value=example[key]??'';label.append(input);row.append(label);
  }
  const remove=element('button','Remove example');remove.onclick=()=>row.remove();row.append(remove);$('rule-examples').append(row);
}
async function chooseRule(code){
  ruleDraft=await call('rulebook.get',{rule_code:code});
  $('rule-code').value=ruleDraft.rule_code;$('rule-code').readOnly=true;
  $('rule-purpose').value=ruleDraft.purpose;$('rule-concise').value=ruleDraft.concise;$('rule-context').value=ruleDraft.priming?.context??'';
  $('rule-examples').replaceChildren();for(const example of ruleDraft.priming?.examples||[])addRuleExample(example);
  $('rule-prepared').hidden=true;
}
on('new-rule',()=>{ruleDraft={};for(const id of ['rule-code','rule-purpose','rule-concise','rule-context'])$(id).value='';$('rule-code').readOnly=false;$('rule-examples').replaceChildren();$('rule-prepared').hidden=true;$('rule-code').focus()});
on('add-rule-example',()=>addRuleExample());
on('save-rule',async()=>{
  const examples=[...$('rule-examples').children].map(row=>{const data={...row.exampleSource};for(const control of row.querySelectorAll('[data-field]'))data[control.dataset.field]=control.value;return data});
  const rule={...ruleDraft,rule_code:value('rule-code'),purpose:$('rule-purpose').value,concise:$('rule-concise').value,priming:{...ruleDraft.priming,context:$('rule-context').value,examples}};
  const result=await call('rulebook.put',{rule});ruleDraft=rule;$('rule-code').readOnly=true;await rulesLoad();
  $('rule-prepared').hidden=false;$('rule-prepared').textContent=pretty(result);notice('Rule saved.');
});
on('prepare-rule',async()=>{$('rule-prepared').textContent=pretty(await call('rulebook.prepare',{rule_codes:[value('rule-code')]}));$('rule-prepared').hidden=false});
async function promptsLoad(){
  library=(await api('/api/graph')).filter(r=>r.entity_schema==='metaform:prompt');$('prompt-list').replaceChildren();
  library.forEach(r=>{const b=element('button','', 'list-item');b.append(element('b',r.entity_json_obj.name||r.entity_json_obj.en||r.id),element('small',r.id));b.onclick=()=>choosePrompt(r.id).catch(e=>notice(e.message,true));$('prompt-list').append(b)});
  if(!value('prompt-id')&&library.length)await choosePrompt(library[0].id);
}
async function choosePrompt(id){
  const r=library.find(p=>p.id===id);if(!r)return;
  promptDraft=structuredClone(r.entity_json_obj);prepared=null;
  $('prompt-id').value=id;$('prompt-name').value=promptDraft.name||promptDraft.en||id;$('prompt-text').value=promptDraft.text||'';$('prompt-rules').value=pretty(promptDraft.rule_codes||[]);
  $('prompt-rule-prepared').hidden=true;$('prepared').textContent='Prepare input to review the prompt and its rules.';
  const info=await api('/api/element/'+encodeURIComponent(id));
  promptRuleBaseline=pretty(info.prompt?.rule_codes||promptDraft.rule_codes||[]);$('prompt-rules').value=promptRuleBaseline;
  $('prompt-tests').replaceChildren();
  for(const j of info.joins.filter(j=>j.type==='prompt_test')){const item=await api('/api/element/'+encodeURIComponent(j.element_id));const d=item.record?.entity_json_obj;if(!d)continue;const row=element('details','', 'test-row');row.append(element('summary',(d.note||'Recorded response')+' · '+d.created),element('pre',pretty(d)));$('prompt-tests').append(row)}
}
on('new-prompt',()=>{promptDraft={};promptRuleBaseline='[]';$('prompt-id').value='prompt:';$('prompt-name').value='';$('prompt-text').value='';$('prompt-rules').value='[]';$('prompt-tests').replaceChildren();$('prompt-rule-prepared').hidden=true;$('prepared').textContent='Prepare input to review the prompt and its rules.';prepared=null});
async function savePrompt(){
  const prompt={...promptDraft,id:value('prompt-id'),name:$('prompt-name').value,text:$('prompt-text').value};
  if($('prompt-rules').value!==promptRuleBaseline||Object.hasOwn(promptDraft,'rule_codes'))prompt.rule_codes=JSON.parse($('prompt-rules').value);
  const r=await call('prompt.put',{prompt});promptDraft=structuredClone(r.entity_json_obj);await promptsLoad();return r;
}
on('review-prompt-rules',async()=>{$('prompt-rule-prepared').textContent=pretty(await call('rulebook.prepare',{rule_codes:JSON.parse($('prompt-rules').value)}));$('prompt-rule-prepared').hidden=false});
on('save-prompt',async()=>{await savePrompt();notice('Prompt saved.')});
async function preparePrompt(){await savePrompt();prepared=await call('prompt.prepare',{id:value('prompt-id'),inputs:parse('prompt-inputs'),focal:value('prompt-focal')||undefined});$('prepared').textContent=pretty(prepared);return prepared}
on('prepare-prompt',preparePrompt);
on('run-prompt',async()=>{await preparePrompt();let job=await call('prompt.run',{id:value('prompt-id'),inputs:parse('prompt-inputs'),focal:value('prompt-focal')||undefined});pending=job;if(value('prompt-harness')){let result=await call('workflow.drive',{run_id:job.run_id,harness:value('prompt-harness')});$('prompt-answer').value=pretty(result.result?.steps?.test??result);$('prepared').textContent=pretty({prepared,result})}else $('prepared').textContent=pretty({prepared,handoff:job});notice('Prompt execution created.')});
on('record-test',async()=>{if(!prepared)throw Error('Prepare the prompt input for this test first.');await call('prompt.test',{prepared,answer:parse('prompt-answer'),note:value('prompt-note')});notice('Response and prepared input saved.');await choosePrompt(value('prompt-id'))});
async function workflowsLoad(){workflows=await api('/api/workflows');$('workflow-list').replaceChildren();if(!workflows.length)$('workflow-list').append(element('p','No workflows have been saved in this project.','muted'));workflows.forEach(w=>{const b=element('button','', 'list-item');b.append(element('b',w.source.intent||w.id),element('small',w.id+' · '+w.executable.steps.length+' steps'));b.onclick=()=>{$('workflow-source').value=typeof w.source.source_instruction==='string'?w.source.source_instruction:pretty(w.source);$('workflow-json').value=pretty(w.executable)};$('workflow-list').append(b)})}
function jobOutput(job){pending=job;$('run-id').value=job.run_id||value('run-id');$('workflow-output').textContent=pretty(job)}
on('convert-workflow',async()=>{let job=await call('workflow.convert',{source:parse('workflow-source'),focal:value('workflow-focal')||undefined});jobOutput(job);if(value('workflow-harness')){const r=await call('workflow.drive',{run_id:job.run_id,harness:value('workflow-harness')});jobOutput(r);if(r.status==='complete'){$('workflow-json').value=pretty(r.result.steps.convert)}}});
on('save-workflow',async()=>{const r=await api('/api/workflow/import',JSON.parse(value('workflow-json')));notice('Saved '+r.id);await workflowsLoad()});
on('start-workflow',async()=>{const d=JSON.parse(value('workflow-json'));await api('/api/workflow/import',d);jobOutput(await call('workflow.start',{id:d.id,exclusive:false}))});
on('next-step',async()=>jobOutput(await call('workflow.next',{run_id:value('run-id')})));
on('answer-step',async()=>{if(!pending?.request_id)throw Error('Retrieve the pending step first.');await call('workflow.answer',{run_id:value('run-id'),request_id:pending.request_id,answer:parse('workflow-answer')});jobOutput(await call('workflow.next',{run_id:value('run-id')}))});
on('apply-conversion',async()=>{const r=await call('workflow.apply',{run_id:value('run-id')});notice('Imported '+r.id);await workflowsLoad();$('workflow-json').value=pretty(workflows.find(w=>w.id===r.id).executable)});
async function versionsLoad(){const m=await api('/api/history');$('version-list').replaceChildren();for(const v of [{id:'origin',name:'Origin',parent:m.base_commit||m.baseline_kind},...Object.values(m.versions).reverse()]){const b=element('button','', 'list-item');b.append(element('b',v.name),element('small',v.id==='origin'?v.parent:'Parent: '+v.parent));b.onclick=async()=>{currentVersion=v.id;$('version-title').textContent=v.name;$('version-details').textContent=pretty({version:v,...await call('history.diff',{version:v.id})})};$('version-list').append(b)}}
on('checkpoint',async()=>{const r=await call('history.checkpoint',{name:value('version-name'),parent:value('version-parent')||undefined});notice('Saved '+r.name);await versionsLoad()});
async function previews(versions){const data=await api('/api/preview',{versions});$('preview-links').replaceChildren();for(const r of data){const a=element('a','Open '+r.version+' ↗');a.href=r.url;a.target='_blank';a.rel='noopener';$('preview-links').append(a)}notice('Preview links are ready below.')}
on('preview-all',()=>previews());on('preview-version',()=>previews([currentVersion]));on('stop-previews',async()=>{await api('/api/preview/stop',{});$('preview-links').replaceChildren()});
on('extract-version',async()=>{const r=await call('history.extract',{version:currentVersion,destination:value('extract-path')});notice('Extracted to '+r.path)});
on('export',async()=>{$('export-result').textContent=pretty(await call('package.export',{path:value('export-path')||undefined}))});
on('import',async()=>{$('export-result').textContent=pretty(await call('package.import',{path:value('import-path'),destination:value('import-destination')||undefined}))});
async function activityLoad(){const data=await api('/api/report');$('stats').replaceChildren();for(const name of ['elements','joins','observations','participants']){const s=element('div','', 'stat');s.append(element('b',data.stats[name]),element('small',name));$('stats').append(s)}$('run-list').replaceChildren();for(const r of data.runs){const b=element('button','', 'list-item');b.append(element('b',r.workflow+' · '+r.status),element('small',r.id));b.onclick=async()=>{
  try{
    const run=await api('/api/run/'+encodeURIComponent(r.id));
    if(run.kind==='intake'){
      $('activity-run')?.remove();
      const details=element('details','');details.id='activity-run';details.open=true;
      details.append(element('summary','Saved intake run · '+r.id),element('pre',pretty(run)));b.after(details);
    }else{
      show('workflows');$('run-id').value=r.id;jobOutput(await call('workflow.next',{run_id:r.id}));
    }
  }catch(e){notice(e.message,true)}
};$('run-list').append(b)}$('events').textContent=pretty(data.events)}
api('/api/settings').then(s=>{$('project-path').textContent=s.project;$('project-root').textContent=s.project;$('project-name').textContent=s.name||s.project.split(/[\\/]/).filter(Boolean).pop()||s.project;$('backend').textContent=s.backend;$('contribution').textContent=s.contribution;$('knowledge-mode').textContent={service:'Shared service',portable:'Portable',legacy:'Local storage'}[s.knowledge_mode];$('assignment-context').textContent=s.assignment?'Assignment '+s.assignment.request_id:'';const backendChoice=$('backend-choice');if(s.knowledge_mode==='service'){backendChoice.replaceChildren(new Option('Analysis copy…',''),new Option('Refresh Ladybug analysis copy','ladybug'))}else if(s.knowledge_mode==='portable'){backendChoice.replaceChildren(new Option('Portable JSON',''));backendChoice.disabled=true}}).catch(e=>notice(e.message,true));refresh().catch(e=>notice(e.message,true));
// Associate the visible field labels with their controls for keyboard and screen-reader use.
document.querySelectorAll('label').forEach(label=>{const control=label.nextElementSibling;if(control?.id&&control.matches('input,textarea,select'))label.htmlFor=control.id});

async function projectsLoad(){
  const projects=await api('/api/projects'),choice=$('project-choice');
  choice.replaceChildren();
  for(const project of projects){
    const option=element('option',project.name);
    option.title=project.path;
    option.value=project.url;
    option.selected=project.url.replace(/\/$/,'')===projectPrefix;
    choice.append(option);
  }
  choice.title=choice.selectedOptions[0]?.textContent||'Select project';
}
$('project-choice').onchange=()=>{location.href=value('project-choice')};
window.addEventListener('focus',()=>projectsLoad().catch(error=>notice(error.message,true)));
projectsLoad().catch(error=>notice(error.message,true));
