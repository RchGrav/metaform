/* Cytoscape presents saved Metaform relationships; Dagre supplies their layout. */
'use strict';
(function(global){
const model=global?.MetaformScene||(typeof require==='function'?require('./structure.js'):null);
const {structureScene,typeName,shapeKind,zoomAt,purposeText,typeIds,isActual}=model;
const payload=n=>n.source_records?.native?.entity_json_obj||n.entity_json_obj||{};
const text=value=>value==null?'':typeof value==='string'?value:JSON.stringify(value);
const descriptionText=value=>Array.isArray(value)?value.map(descriptionText).join('; '):value&&typeof value==='object'?Object.entries(value).map(([key,item])=>key.replaceAll('_',' ')+': '+descriptionText(item)).join(' · '):text(value);
const shorten=(value,length)=>{const str=text(value).replace(/\s+/g,' ').trim();return str.length>length?str.slice(0,length-1)+'…':str};
const palette={code:'#99dcc5',document:'#c9b4ef',media:'#edbd85',data:'#9aceef',environment:'#b0d68c',person:'#f0afb8',group:'#e3b2e5',system:'#9ac9ee',framework:'#b7b8fb',exterior:'#dfcdb1'};
const shapes={code:'round-rectangle',document:'cut-rectangle',media:'round-rectangle',data:'barrel',environment:'round-hexagon',person:'ellipse',group:'round-octagon',system:'rectangle',framework:'round-diamond',exterior:'diamond'};
function svgImage(artwork,color){
  if(!artwork)return '';
  const displayed=artwork.replace(/<svg\b((?:[^>"']|"[^"]*"|'[^']*')*)>/i,(root,attributes)=>{
    const style=attributes.match(/(?:^|\s)style\s*=\s*(["'])(.*?)\1/i)?.[2]||'';
    let additions='';
    if(/currentcolor/i.test(artwork)&&!/(?:^|\s)color\s*=/i.test(attributes)&&!/(?:^|;)\s*color\s*:/i.test(style))additions+=' color="'+color+'"';
    const viewBox=attributes.match(/(?:^|\s)viewBox\s*=\s*(["'])(.*?)\1/i)?.[2].trim().split(/[\s,]+/).map(Number);
    if(viewBox?.length===4&&viewBox.every(Number.isFinite)&&viewBox[2]>0&&viewBox[3]>0){
      if(!/(?:^|\s)width\s*=/i.test(attributes)&&!/(?:^|;)\s*width\s*:/i.test(style))additions+=' width="'+viewBox[2]+'"';
      if(!/(?:^|\s)height\s*=/i.test(attributes)&&!/(?:^|;)\s*height\s*:/i.test(style))additions+=' height="'+viewBox[3]+'"';
    }
    return additions?root.replace(/<svg\b/i,match=>match+additions):root;
  });
  return 'data:image/svg+xml;utf8,'+encodeURIComponent(displayed.trim().startsWith('<svg')?'<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE svg>'+displayed:displayed);
}
function initialFocus(records){const defining=records.filter(n=>isActual(n)&&payload(n).defining_element===true);return defining.length===1?defining[0].id:null}
function cytoscapeElements(scene,labels=true,similarity=false){
  const dense=scene.edges.length>10||scene.nodes.length>12;
  const hasActual=scene.nodes.some(isActual),connected=new Set(scene.edges.flatMap(e=>[e.source,e.target]));
  // The Type stays in the scene for inspection; its definition is not a provider.
  const nodes=scene.nodes.filter(n=>!(hasActual&&n.id===scene.focus&&n.band==='namespace'&&!connected.has(n.id)&&!scene.nodes.some(child=>child.parent===n.id)));
  const ids=new Set(nodes.map(n=>n.id));
  const result=nodes.map(n=>{
    const obj=payload(n),kind=n.kind==='join'?'join':shapeKind(n),type_ids=typeIds(n),actual=isActual(n);
    const artwork=type_ids.map(id=>(n.type_records||[]).find(record=>record.id===id)).filter(Boolean).map(record=>payload(record).svg).find(svg=>typeof svg==='string'&&svg.trim())||(!actual&&typeof obj.svg==='string'?obj.svg:'');
    const svg_image=svgImage(artwork,palette[kind]||'#bacac7');
    const name=n.kind==='join'?text(n.join.type)||'Join':actual?obj.en||obj.name||n.id:typeName(n);
    const detail=n.kind==='join'?purposeText(n.join.purpose):n.kind==='namespace'?`${n.descendants} actual Elements`:obj.description||obj.ef||n.entity_desc||obj.notes||'Referenced Element';
    const label=[shorten(name,dense?40:65),...(labels?(actual?type_ids:[n.id]):[]),...(dense?[]:[shorten(descriptionText(detail),155)])].filter(Boolean).join('\n');
    return {data:{id:n.id,label,name,type_ids,type_id:type_ids[0]||'',svg_image,kind,record:n,color:palette[kind]||'#bacac7',shape:n.kind==='join'?'diamond':shapes[kind]||'round-rectangle',width:dense?(n.defining?190:170):(n.defining?280:250),height:(dense?100:n.defining?164:148)+Math.max(0,type_ids.length-1)*20+(artwork?84:0)},classes:[actual?'actual':'type',dense?'compact':'',artwork?'artwork':'',n.defining?'defining':'',n.kind==='join'?'junction':'',n.kind==='reference'?'reference':''].filter(Boolean).join(' ')};
  });
  const newId=base=>{let id=base;while(ids.has(id))id+=':';ids.add(id);return id};
  for(const n of nodes)if(n.parent&&ids.has(n.parent))result.push({data:{id:newId('namespace:'+n.id),source:n.parent,target:n.id,label:'',arrow:'none',color:'#65827b'},classes:'namespace'});
  scene.edges.forEach((edge,i)=>{
    if(!ids.has(edge.source)||!ids.has(edge.target))return;
    const property=edge.join?.type==='property',support=['supportive','supporting'].includes(edge.join?.type);
    const color=similarity?({'01':'#99dcc5','10':'#c9b4ef','11':'#edbd85'}[edge.membership]||'#a9c4c0'):property?'#edbd85':support?'#c9b4ef':'#99dcc5';
    result.push({data:{id:newId('purpose:'+i),source:edge.source,target:edge.target,join_id:edge.join_id,edge,join:edge.join,label:dense?'':shorten(purposeText(edge.join?.purpose)||edge.join?.type,90),purpose_label:purposeText(edge.join?.purpose)||text(edge.join?.type),arrow:edge.directed?'triangle':'none',color},classes:'purpose'+(property?' property':support?' supportive':'')});
  });
  return result;
}
function stylesheet(){return [
  {selector:'node',style:{'label':'data(label)','shape':'data(shape)','width':'data(width)','height':'data(height)','background-color':'#233b3c','border-width':2,'border-color':'data(color)','color':'#f0f5f0','font-family':'system-ui, sans-serif','font-size':14,'font-weight':500,'text-wrap':'wrap','text-max-width':218,'text-valign':'center','text-halign':'center','line-height':1.35,'overlay-opacity':0,'text-outline-width':0}},
  {selector:'node.type',style:{'background-color':'#1d3036','border-width':1.5}},
  {selector:'node.defining',style:{'border-width':4,'font-size':15,'background-color':'#294943','text-max-width':246}},
  {selector:'node.compact',style:{'text-max-width':146,'font-size':16}},
  {selector:'node.junction',style:{'width':180,'height':145,'font-size':13,'text-max-width':135}},
  {selector:'node.artwork',style:{'background-image':'data(svg_image)','background-width':72,'background-height':72,'background-fit':'none','background-repeat':'no-repeat','background-position-x':'50%','background-position-y':12,'background-image-containment':'over','text-margin-y':42}},
  {selector:'node.reference',style:{'border-style':'dashed','background-color':'#1b292d'}},
  {selector:'edge',style:{'curve-style':'bezier','width':2,'line-color':'data(color)','target-arrow-color':'data(color)','target-arrow-shape':'data(arrow)','arrow-scale':1.1,'label':'data(label)','color':'#dae8e3','font-size':13,'font-family':'system-ui, sans-serif','text-wrap':'wrap','text-max-width':170,'text-background-color':'#111c20','text-background-opacity':.94,'text-background-padding':4,'text-background-shape':'round-rectangle','text-margin-y':-10,'overlay-opacity':0}},
  {selector:'edge.namespace',style:{'width':1.5,'line-style':'dashed','text-opacity':0}},
  {selector:'edge.property',style:{'line-style':'dashed'}},
  {selector:'edge.supportive',style:{'line-style':'dotted'}},
  {selector:'.muted',style:{'opacity':.22}},
  {selector:'node.highlighted',style:{'border-width':4,'background-color':'#34594f'}},
  {selector:'edge.highlighted',style:{'width':3.5,'font-weight':600,'z-index':10}},
  {selector:'edge.purpose-focus',style:{'label':'data(purpose_label)','text-opacity':1,'font-weight':500,'text-max-width':260,'z-index':20}},
  {selector:':selected',style:{'overlay-opacity':.08,'overlay-color':'#d0f4df'}}
]}
class MetaformStructure{
  constructor(host,{onSelect,onNavigate,onBeforeNavigate}={}){
    this.host=host;this.onSelect=onSelect;this.onNavigate=onNavigate;this.onBeforeNavigate=onBeforeNavigate;this.navigationSequence=0;this.records=[];this.joins=[];this.edges=[];this.scene={nodes:[],edges:[],joins:[],focus:null};this.focus=null;this.selected=null;this.history=[];this.view={x:0,y:0,k:1};this.animation=null;this.initialFit=false;this.loaded=false;
    this.motion=matchMedia('(prefers-reduced-motion: reduce)');
    this.svg=document.createElement('div');this.svg.id='network';this.svg.tabIndex=0;this.svg.setAttribute('role','group');this.svg.setAttribute('aria-label','Project graph. Click an Element to open its connected neighborhood. Arrow keys select Elements; Enter opens one. Escape goes back. Drag nodes to arrange; drag background to pan; scroll or pinch to zoom.');host.prepend(this.svg);
    this.status=document.createElement('span');this.status.className='graph-accessible-status';this.status.setAttribute('aria-live','polite');Object.assign(this.status.style,{position:'absolute',width:'1px',height:'1px',overflow:'hidden',clipPath:'inset(50%)'});host.append(this.status);
    this.cy=global.cytoscape({container:this.svg,elements:[],style:stylesheet(),layout:{name:'preset'},minZoom:.12,maxZoom:4,wheelSensitivity:.22,boxSelectionEnabled:false,selectionType:'single'});
    this.cy.on('pan zoom',()=>this.syncView());
    this.cy.on('tap','node',event=>{const n=event.target.data('record');if(n.kind==='join'||n.id===this.focus)this.select(n);else this.enter(n.id);});
    this.cy.on('tap','edge',event=>{const join=event.target.data('join');if(join)this.select({id:join.id||event.target.data('join_id'),kind:'join',join});});
    this.cy.on('mouseover','edge',event=>{if(event.target.data('join'))event.target.addClass('purpose-focus');});
    this.cy.on('mouseout','edge',event=>{if(event.target.data('join_id')!==this.selected)event.target.removeClass('purpose-focus');});
    this.cy.on('tap',event=>{if(event.target===this.cy)this.highlight(null);});
    this.cy.on('dbltap',event=>{if(event.originalEvent?.shiftKey){this.zoom(.5,event.renderedPosition);return;}if(event.target===this.cy)this.zoom(2,event.renderedPosition);else if(event.target.isNode()){const n=event.target.data('record');if(n.kind==='join')this.select(n);else this.enter(n.id);}});
    this.svg.addEventListener('keydown',event=>this.keyDown(event));
    this.observer=new ResizeObserver(()=>{this.cy.resize();if(!this.initialFit&&this.scene.nodes.length&&this.svg.clientWidth){this.fit(false,true);this.initialFit=true;}});this.observer.observe(this.svg);
  }
  syncView(){const pan=this.cy.pan();this.view={x:pan.x,y:pan.y,k:this.cy.zoom()};this.svg.dataset.zoom=this.view.k.toFixed(4);const output=document.getElementById('zoom-level');if(output)output.textContent=Math.round(this.view.k*100)+'%'}
  setView(view){this.cy.viewport({zoom:view.k,pan:{x:view.x,y:view.y}});this.syncView()}
  cancelAnimation(){this.cy.stop();this.animation=null;this.finishAnimation?.();this.finishAnimation=null}
  animateView(view,duration=260){
    this.cancelAnimation();if(this.motion.matches||!duration){this.setView(view);return Promise.resolve();}
    this.animation=true;return new Promise(resolve=>{this.finishAnimation=resolve;this.cy.animate({zoom:view.k,pan:{x:view.x,y:view.y}},{duration,easing:'ease-out-cubic',complete:()=>{this.animation=null;this.finishAnimation=null;this.syncView();resolve();}});});
  }
  zoom(factor,point={x:this.svg.clientWidth/2,y:this.svg.clientHeight/2}){return this.animateView(zoomAt(this.view,point,factor),170)}
  fit(animate=true,readable=false){
    this.cy.resize();const viewport=this.cy.getFitViewport(this.cy.elements(),55);if(!viewport)return Promise.resolve();
    let target={k:Math.min(1,viewport.zoom),x:viewport.pan.x,y:viewport.pan.y};
    if(target.k!==viewport.zoom){const box=this.cy.elements().boundingBox();target.x=this.cy.width()/2-(box.x1+box.w/2)*target.k;target.y=this.cy.height()/2-(box.y1+box.h/2)*target.k;}

    return animate?this.animateView(target):Promise.resolve(this.setView(target));
  }
  setData(records,joins,edges,{reset=false,labels=true,similarity=false}={}){
    this.cancelAnimation();const first=!this.loaded;this.loaded=true;this.records=records;this.joins=joins;this.edges=edges;this.labels=labels;this.similarity=similarity;
    if(reset||first){this.focus=initialFocus(records);this.selected=this.focus;this.history=[];}
    const previous=this.focus;this.render();
    if(reset||first||previous!==this.focus){this.fit(false,true);this.initialFit=true;this.onNavigate?.(this.focus);}
  }
  snapshot(){return {focus:this.focus,view:{...this.view},selected:this.selected,positions:Object.fromEntries(this.cy.nodes().map(n=>[n.id(),{...n.position()}]))}}
  async navigate(id){
    if(id===this.focus)return;const request=++this.navigationSequence;await this.onBeforeNavigate?.(id);if(request!==this.navigationSequence)return;this.cancelAnimation();const prior=this.history.findIndex(state=>state.focus===id);if(prior>=0)this.history=this.history.slice(0,prior);else this.history.push(this.snapshot());this.focus=id;this.selected=id;this.render();this.onNavigate?.(this.focus);await this.fit(true,true);
  }
  enter(id){const n=this.scene.nodes.find(n=>n.id===id);if(!n||n.kind==='join')return Promise.resolve();return this.navigate(id)}
  openType(id){return this.navigate(id||null)}
  resetToTypes(){return this.navigate(null)}
  async back(index=this.history.length-1){
    const restore=this.history[index];if(!restore)return;this.cancelAnimation();this.history=this.history.slice(0,index);this.focus=restore.focus;this.selected=restore.selected;this.render();
    this.cy.nodes().positions(n=>restore.positions[n.id()]||n.position());this.onNavigate?.(this.focus);await this.animateView(restore.view,300);
  }
  select(n){this.selected=n.id;this.highlight(n.id);this.status.textContent=n.kind==='join'?purposeText(n.join?.purpose):typeName(n)+'. '+text(payload(n).description||payload(n).ef||n.entity_desc);this.onSelect?.(n)}
  highlight(id){
    this.selected=id;this.cy.elements().removeClass('highlighted muted purpose-focus');if(!id)return;
    let focused=this.cy.getElementById(id);if(!focused.length)focused=this.cy.edges().filter(e=>e.data('join_id')===id);
    if(!focused.length)return;if(focused.isEdge())focused.addClass('purpose-focus');const neighborhood=focused.isNode()?focused.closedNeighborhood():focused.union(focused.connectedNodes());this.cy.elements().difference(neighborhood).addClass('muted');neighborhood.addClass('highlighted');
  }
  render(){
    const oldView={...this.view},oldFocus=this.scene.focus,positions=new Map(this.cy.nodes().map(n=>[n.id(),{...n.position()}]));
    this.scene=structureScene(this.records,this.joins,this.edges,this.focus);if(this.focus&&!this.scene.focus){this.history=[];this.selected=null;}this.focus=this.scene.focus;this.svg.dataset.focus=this.focus||'';
    const elements=cytoscapeElements(this.scene,this.labels,this.similarity);
    this.cy.batch(()=>{this.cy.elements().remove();this.cy.add(elements);});
    // Measure Cytoscape's actual wrapped text before laying out its node bodies.
    for(const node of this.cy.nodes()){
      const label=node.boundingBox({includeNodes:false,includeEdges:false,includeLabels:true,includeOverlays:false});
      if(Number.isFinite(label.h))node.data('height',Math.max(node.data('height'),Math.ceil(label.h)+32+(node.hasClass('artwork')?84:0)));
    }
    const topology=JSON.stringify(this.cy.elements().map(e=>[e.id(),e.data('source'),e.data('target'),e.data('width'),e.data('height')]));
    const preserve=oldFocus===this.focus&&topology===this.topology;this.topology=topology;
    if(preserve)this.cy.nodes().positions(n=>positions.get(n.id())||n.position());
    else if(this.scene.actualFocus&&(this.scene.edges.length>10||this.scene.nodes.length>12))this.cy.layout({name:'concentric',concentric:node=>node.id()===this.focus?2:1,levelWidth:()=>1,minNodeSpacing:22,avoidOverlap:true,equidistant:false,startAngle:Math.PI*1.5,fit:false,animate:false,nodeDimensionsIncludeLabels:true}).run();
    else this.cy.layout({name:'dagre',rankDir:'LR',ranker:'network-simplex',nodeSep:this.scene.edges.length>10?14:44,rankSep:this.scene.edges.length>10?90:145,edgeSep:this.scene.edges.length>10?8:24,nodeDimensionsIncludeLabels:true,fit:false,animate:false,useDagreEdgeControlPoints:true}).run();
    this.setView(oldView);this.highlight(this.selected);this.navigation();
    const count=document.getElementById('graph-count');if(count)count.textContent=`${this.scene.nodes.filter(isActual).length} actual Elements · ${this.scene.joins.length} joins`;
  }
  navigation(){
    const back=document.getElementById('graph-back');if(back)back.disabled=!this.history.length;
    const crumbs=document.getElementById('graph-breadcrumbs');if(!crumbs)return;crumbs.replaceChildren();
    const name=id=>id?typeName(this.records.find(n=>n.id===id)||this.scene.nodes.find(n=>n.id===id)||{id}):'Types';
    const current=document.createElement('span');current.textContent=name(this.focus);current.setAttribute('aria-current','location');crumbs.append(current);
  }
  keyDown(event){
    if(event.key==='Enter'&&this.selected){event.preventDefault();this.enter(this.selected);}
    else if(event.key==='Escape'||(event.altKey&&event.key==='ArrowLeft')){event.preventDefault();this.back();}
    else if(['+','=','-','0'].includes(event.key)){event.preventDefault();if(event.key==='0')this.fit();else this.zoom(event.key==='-'?.8:1.25);}
    else if(['ArrowRight','ArrowDown','ArrowLeft','ArrowUp'].includes(event.key)){event.preventDefault();const nodes=this.cy.nodes(),index=nodes.toArray().findIndex(n=>n.id()===this.selected),direction=['ArrowLeft','ArrowUp'].includes(event.key)?-1:1;if(nodes.length){const n=nodes[(index+direction+nodes.length)%nodes.length];this.select(n.data('record'));}}
  }
  destroy(){this.cancelAnimation();this.observer.disconnect();this.cy.destroy();this.svg.remove();this.status.remove()}
}
if(typeof module!=='undefined'&&module.exports)module.exports={cytoscapeElements,initialFocus,stylesheet,MetaformStructure};
if(global)global.MetaformStructure=MetaformStructure;
})(typeof window!=='undefined'?window:null);
