/* Namespace navigation is a view over saved records; it never creates Elements. */
'use strict';
(function(global){
const text=value=>value==null?'':typeof value==='string'?value:JSON.stringify(value,null,2);
const purposeText=value=>typeof value?.op==='string'?value.op:text(value);
const belongs=(id,parent)=>id===parent||id.startsWith(parent+'.');
const refId=ref=>typeof ref==='string'?ref:ref?.id;
const payload=n=>n.source_records?.native?.entity_json_obj||n.entity_json_obj||{};
const typeIds=n=>{const obj=payload(n);return Array.isArray(obj.type_ids)?obj.type_ids:obj.type_id?[obj.type_id]:[]};
const isActual=n=>n.entity_schema==='metaform:actual-element'||typeIds(n).length>0;
const classification=n=>typeIds(n)[0]||n.id;
function typeName(n){
  const obj=payload(n);
  if(isActual(n))return obj.en||obj.name||n.id;
  if(Number.isInteger(obj.length)&&obj.length>0)return n.id.split('.').slice(-obj.length).reverse().join(' ');
  return obj.en||n.id.split('.').slice(-2).reverse().join(' ');
}
function shapeKind(value){const parts=(typeof value==='string'?value:classification(value)).split('.');return ['ext','exterior'].includes(parts[0])?parts[1]||'exterior':parts[0]}
function zoomAt(view,pointer,factor){const k=Math.max(.12,Math.min(4,view.k*factor)),ratio=k/view.k;return {k,x:pointer.x-(pointer.x-view.x)*ratio,y:pointer.y-(pointer.y-view.y)*ratio}}
function references(join){return [...new Set([join.object_id,join.element_id,...(join.participants||[]).map(p=>p.ref)].filter(ref=>typeof ref==='string'&&ref))]}
function structureScene(records,joins,edges,focus){
  const all=new Map(records.map(n=>[n.id,{...n,actual:isActual(n),type_ids:typeIds(n),type_id:typeIds(n)[0],defining:n.defining||payload(n).defining_element===true}]));
  const types=new Map([...all.values()].filter(n=>!n.actual&&n.kind!=='reference').map(n=>[n.id,n]));
  for(const n of records){
    if(n.kind==='reference')continue;
    for(const id of isActual(n)?typeIds(n):[n.id]){
    if(id.includes(':'))continue;
    const parts=id.split('.');
    for(let i=1;i<=parts.length;i++){const key=parts.slice(0,i).join('.');if(!types.has(key)){const group={id:key,kind:'namespace',entity_json_obj:{},sources:[]};types.set(key,group);all.set(key,group);}}
    }
  }
  for(const n of all.values())if(n.actual)n.type_records=n.type_ids.map(id=>types.get(id)).filter(Boolean);
  const parent=id=>id.includes(':')?null:id.includes('.')?id.slice(0,id.lastIndexOf('.')):null;
  const children=id=>[...types.values()].filter(n=>parent(n.id)===id).sort((a,b)=>a.id.localeCompare(b.id));
  if(focus&&!all.has(focus))focus=null;
  const actualFocus=focus&&(all.get(focus).actual||all.get(focus).kind==='reference');
  const visible=new Map(),seeds=new Set();
  const addType=(n,parent=null)=>visible.set(n.id,{...n,parent,band:'namespace'});
  if(actualFocus){visible.set(focus,{...all.get(focus),band:'functional'});seeds.add(focus);}
  else{
    const roots=focus?[types.get(focus)]:children(null);
    for(const root of roots){addType(root);for(const n of children(root.id))addType(n,root.id);}
    if(focus){
      seeds.add(focus);
      for(const n of all.values())if(n.type_ids?.includes(focus)){visible.set(n.id,{...n,band:'functional'});seeds.add(n.id);}
    }
  }
  const selectedJoins=new Map(),joinIds=new Set(joins.map(j=>j.id)),relevant=new Set(seeds);
  // Expand join-to-join references only. Ordinary neighbors are opened by navigation.
  let changed=true;
  while(changed){changed=false;for(const join of joins){if(selectedJoins.has(join.id))continue;if((!focus&&!records.some(isActual))||relevant.has(join.id)||references(join).some(id=>relevant.has(id))){selectedJoins.set(join.id,join);relevant.add(join.id);for(const ref of references(join))if(joinIds.has(ref))relevant.add(ref);changed=true;}}}
  const binary=new Map(edges.map(e=>[e.join_id,e])),reified=new Set([...selectedJoins.values()].flatMap(references).filter(ref=>joinIds.has(ref)));
  const mapped=id=>{
    if(visible.has(id))return id;
    if(joinIds.has(id))return id;
    visible.set(id,{...(all.get(id)||{id,kind:'reference',entity_json_obj:{}}),parent:null,band:'functional',context:!seeds.has(id)});return id;
  };
  const sceneEdges=[];
  for(const join of selectedJoins.values()){
    const edge=binary.get(join.id),source=refId(edge?.source),target=refId(edge?.target);
    if(edge&&!reified.has(join.id)&&!joinIds.has(source)&&!joinIds.has(target)){
      sceneEdges.push({...edge,source:mapped(source),target:mapped(target),kind:'purpose',directed:true,originalSource:source,originalTarget:target,join});
    }else{
      visible.set(join.id,{id:join.id,kind:'join',join,band:'functional',context:true,parent:null});
      for(const ref of references(join))sceneEdges.push({source:join.id,target:mapped(ref),join_id:join.id,join,kind:'participant',directed:false});
    }
  }
  for(const n of visible.values()){
    n.descendants=records.filter(r=>typeIds(r).some(id=>belongs(id,n.id))).length;
    n.children=n.actual?joins.filter(j=>references(j).includes(n.id)).length:children(n.id).length+records.filter(r=>typeIds(r).includes(n.id)).length;
  }
  return {nodes:[...visible.values()],edges:sceneEdges,joins:[...selectedJoins.values()],focus,actualFocus:!!actualFocus};
}
function definingRelation(records,joins,id){
  const defining=new Set(records.filter(n=>isActual(n)&&(n.defining||payload(n).defining_element===true)).map(n=>n.id));
  const adjacent=new Map();
  for(const join of joins){const refs=[join.id,...references(join)].filter(Boolean);for(const from of refs)for(const to of refs)if(from!==to){if(!adjacent.has(from))adjacent.set(from,[]);adjacent.get(from).push({from,to,join});}}
  const queue=[id],visited=new Set(queue),previous=new Map();
  for(let index=0;index<queue.length;index++){
    const current=queue[index];
    if(defining.has(current)){const steps=[];for(let next=current;previous.has(next);){const step=previous.get(next);steps.unshift(step);next=step.from;}return {defining:current,steps};}
    for(const step of adjacent.get(current)||[])if(!visited.has(step.to)){visited.add(step.to);previous.set(step.to,step);queue.push(step.to);}
  }
  return null;
}
const api={structureScene,typeName,shapeKind,zoomAt,purposeText,references,typeIds,isActual,definingRelation};
if(typeof module!=='undefined'&&module.exports)module.exports=api;
if(global){global.MetaformScene=api;global.metaformTypeName=typeName;global.metaformPurposeText=purposeText;global.metaformJoinReferences=references;}
})(typeof window!=='undefined'?window:globalThis);
