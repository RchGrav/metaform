"""A nonce names a stored workflow continuation, independent of its executor."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

from filelock import FileLock

from .util import now, read_json, write_json


def pending_assignment(app, run_id, request_id):
    run = app.load_run(run_id)
    job = (run.get("assignments") or {}).get(request_id)
    if job is None and (run.get("pending") or {}).get("request_id") == request_id:
        job = run["pending"]
    if run["status"] != "running" or not job or job["request_id"] != request_id:
        raise ValueError("The assignment is no longer pending")
    return job


def marker(folder=None):
    start = Path(folder or Path.cwd()).resolve()
    for parent in [start, *start.parents]:
        file = parent / ".agentid" / "nonce"
        if file.is_file():
            return read_json(file) | {"folder": str(parent)}
    return None


def publish(app, job, module="workflow"):
    directory = Path(app.config.get("assignment_home", app.home)) / "assignments"
    directory.mkdir(parents=True, exist_ok=True)
    with FileLock(directory / "index.lock"):
        nonce = job.get("nonce")
        if not nonce:
            nonce = str(secrets.randbelow(900000000) + 100000000)
            while (directory / (nonce + ".json")).exists():
                nonce = str(secrets.randbelow(900000000) + 100000000)
        record = {
            "nonce": nonce,
            "project": str(app.project),
            "home": str(app.home),
            "module": module,
            "run_id": job["run_id"],
            "request_id": job["request_id"],
            "created": now(),
        }
        write_json(directory / (nonce + ".json"), record)
        if directory.parent != app.home:
            write_json(app.home / "assignments" / (nonce + ".json"), record)
    job["nonce"] = nonce
    job["begin"] = "python metaform begin " + nonce
    return job


def begin(nonce, folder=None, home=None, project=None):
    from .app import App, project_path

    root = Path(home or os.environ.get("METAFORM_HOME", Path.home() / ".metaform"))
    selected = project_path(project, home) if project is not None else None
    if selected is not None:
        identity = read_json(selected / ".metaform" / "project.json", {})
        config = read_json(selected / ".metaform" / "config.json", {})
        if (identity.get("knowledge_mode") == "portable" or config.get("knowledge_mode") == "portable"
                or (selected / ".metaform" / "bundle.json").exists()):
            root = selected / ".metaform" / "home"
        else:
            root = Path(home or identity.get("service_home") or root)
    record = read_json(root / "assignments" / (str(nonce) + ".json"))
    if record is None:
        start = Path(folder or Path.cwd()).resolve()
        for parent in [start, *start.parents]:
            file = (
                parent / ".metaform" / "home" / "assignments" / (str(nonce) + ".json")
            )
            if file.is_file():
                record = read_json(file)
                break
    if not record:
        raise ValueError(f"Unknown workflow handoff: {nonce}")
    if selected is not None:
        if selected != Path(record["project"]).resolve():
            raise ValueError("The selected project conflicts with this bound assignment")
    target = Path(folder or Path.cwd()).resolve()
    app = App(record["project"], record["home"], binding=False)
    pending_assignment(app, record["run_id"], record["request_id"])
    write_json(target / ".agentid" / "nonce", record)
    app.event("continuation.begin", record | {"folder": str(target)}, record["run_id"])
    return current(App(target, record["home"], binding=record))


def current(app):
    from .workflow import Engine
    from .intake import Intake

    binding = app.binding
    if binding["module"] == "intake":
        return Intake(app).next(
            binding["run_id"], request_id=binding.get("request_id")
        )
    return Engine(app).next(binding["run_id"], binding.get("request_id"))


def begin_command(app, args, context):
    return begin(args["nonce"], args.get("folder"), app.home)
