"""Native artifact understanding followed by one independent latent examination."""

from __future__ import annotations

import copy
import importlib.resources
from pathlib import Path

from . import schemas, workfolders
from .locking import run_locked
from .util import digest, now


def semantic_text(name):
    return (importlib.resources.files("metaform") / "data" / "semantics" / name).read_text(encoding="utf-8")


class Intake:
    def __init__(self, app):
        self.app = app

    def start(self):
        return self._start("native")

    def examine(self):
        return self._start("archaeology")

    def _start(self, stage):
        run = {
            "id": self.app.identifier(), "workflow": "metaform.intake", "kind": "intake",
            "status": "running", "stage": stage,
            "pending": None, "assignments": {}, "receipts": {}, "created": now(),
        }
        if stage == "archaeology":
            run["native_graph"] = self._native_snapshot()
        self.app.save_run(run)
        self.app.enter("intake", run["id"])
        return self.next(run["id"])

    def _native_snapshot(self):
        graph = self.app.graph.export(scope="native")
        return {**copy.deepcopy(self.app.get("native_context") or {}),
                "elements": graph["elements"], "joins": graph["joins"],
                "references": self._references(graph)}

    def _references(self, native):
        from .knowledge import reference_fields
        from .graph import type_ids

        owner = "project:" + self.app.project_id
        stores = {owner: self.app.graph, "global": self.app.global_graph}
        known = {owner: {"elements": dict(native["elements"]),
                         "joins": {join["id"]: join for join in native["joins"]}}}
        captured = {}
        pending = [(owner, join) for join in native["joins"]]
        pending.extend(
            (owner, {"element_id": type_id})
            for record in native["elements"].values()
            for type_id in type_ids(record)
        )
        checked = set()
        while pending:
            author, join = pending.pop()
            for ref in reference_fields(join):
                owners = [ref["owner"]] if ref.get("owner") else list(dict.fromkeys([author, "global"]))
                for target in owners:
                    if target not in stores:
                        continue
                    kinds = [ref["kind"]] if ref.get("kind") else ["element", "join"]
                    found = False
                    for kind in kinds:
                        if kind not in {"element", "join"}:
                            continue
                        collection = kind + "s"
                        key = (target, kind, ref["ref"])
                        if ref["ref"] in known.get(target, {}).get(collection, {}):
                            found = True
                            break
                        if key in checked:
                            continue
                        checked.add(key)
                        store = stores[target]
                        record = store.get(ref["ref"]) if kind == "element" else next(
                            (item for item in store.joins(ref["ref"]) if item["id"] == ref["ref"]), None)
                        if record is None:
                            continue
                        known.setdefault(target, {"elements": {}, "joins": {}})[collection][ref["ref"]] = record
                        capture = captured.setdefault(target, {"elements": {}, "joins": []})
                        if kind == "element":
                            capture["elements"][ref["ref"]] = record
                            pending.extend((target, {"element_id": type_id})
                                           for type_id in type_ids(record))
                        else:
                            capture["joins"].append(record)
                            pending.append((target, record))
                        found = True
                        break
                    if found:
                        break
        for target, graph in captured.items():
            registered = schemas.registry(self.app, owner=target)
            graph["schemas"] = {identifier: schemas.bundled(self.app, identifier, owner=target)
                                for identifier in {r["entity_schema"] for r in graph["elements"].values()}
                                if identifier in registered}
        return captured

    def _assignment(self, run):
        from .continuation import publish
        from .prompts import snapshot

        native = run["stage"] == "native"
        prepared = snapshot(self.app, "prompt:metaform.intake." + run["stage"])
        aliases = self.app.config.get("semantic_sources", {}).get("aliases")
        alias_text = Path(aliases).read_text(encoding="utf-8") if aliases else semantic_text("aliases.md")
        assignment = {
            **prepared, "run_id": run["id"], "request_id": self.app.identifier(),
            "status": "awaiting_answer", "role": "native_expert" if native else "latent_expert",
            "prompt": prepared["source_prompt"] + "\n\n" + alias_text,
            "schema": schemas.bundled(self.app, "metaform:graph"),
            "context": "project" if native else "fresh", "inputs": {},
            "completion": (
                "Save the graph incrementally with intake.put as you construct it. "
                "The final JSON answer contains only unsaved Elements, joins, or context. "
                'When all work is saved, finish with {"elements": {}, "joins": []}. '
                "Saved records remain part of the completed pass and are included in the Native handoff."
            ),
            "tools": ["intake.search", "intake.get", "intake.put"],
            "source_status": {"aliases": "configured" if aliases else "bundled",
                              "aliases_revision": digest(alias_text)},
            "tool_bindings": {"Namespace search": "intake.search",
                              "Element and receiving-purpose relationships": "intake.get",
                              "author Elements and joins": "intake.put"},
        }
        assignment["inputs"]["schemas"] = {
            identifier: schemas.bundled(self.app, identifier)
            for identifier in ("metaform:element", "metaform:actual-element", "metaform:operative-purpose-join")
        }
        if native:
            assignment["workfolder"] = str(self.app.project)
            assignment["tools"].extend(["intake.files", "intake.read"])
            assignment["inputs"]["native"] = self._native_snapshot()
        else:
            assignment["system_prompt"] = semantic_text("latent-role.md")
            assignment["system_prompt_revision"] = digest(assignment["system_prompt"])
            assignment["inputs"]["native"] = copy.deepcopy(run["native_graph"])
            registered = schemas.registry(self.app)
            assignment["inputs"]["schemas"].update({
                identifier: schemas.bundled(self.app, identifier)
                for identifier in sorted({r["entity_schema"] for r in run["native_graph"]["elements"].values()})
                if identifier in registered
            })
            folder = workfolders.create(self.app, empty=True)
            assignment.update(workfolder=folder["path"], workfolder_id=folder["id"])
        publish(self.app, assignment, "intake")
        run["pending"] = assignment
        self.app.save_run(run)
        self.app.event("assignment", assignment, run["id"])
        self.app.trace("assignment", assignment, run["id"])
        return assignment

    def _next(self, run, request_id=None):
        pending = run.get("pending")
        if request_id is not None:
            if run["status"] == "running" and pending and pending["request_id"] == request_id:
                return pending
            raise ValueError("This request is not pending in the intake run")
        if run["status"] != "running":
            return {"run_id": run["id"], "status": run["status"], "result": run.get("result")}
        if pending:
            return pending
        if run["stage"] == "complete":
            return self._finish(run)
        return self._assignment(run)

    @run_locked
    def next(self, run_id, request_id=None):
        return self._next(self.app.load_run(run_id), request_id)

    @run_locked
    def batch(self, run_id, limit=None):
        run = self.app.load_run(run_id)
        if limit is not None and limit < 1:
            raise ValueError("Assignment limit must be positive")
        return [self._next(run)]

    def _put(self, run, graph):
        source = run["stage"]
        result = self.app.graph.put(graph, source)
        context = {key: copy.deepcopy(value) for key, value in graph.items()
                   if key not in {"elements", "joins", "observations"}}
        if source == "native":
            self.app.set("native_context", {**(self.app.get("native_context") or {}), **context})
        else:
            run.setdefault("latent_context", {}).update(context)
            authored = run.setdefault("latent_graph", {"elements": {}, "joins": []})
            authored["elements"].update(copy.deepcopy(graph.get("elements", {})))
            previous = {join.get("id") or digest(join): join for join in authored["joins"]}
            previous.update({join.get("id") or digest(join): copy.deepcopy(join) for join in graph.get("joins", [])})
            authored["joins"] = list(previous.values())
        return result

    @run_locked
    def put(self, run_id, graph, request_id=None):
        run = self.app.load_run(run_id)
        if run["status"] != "running" or run["stage"] == "complete":
            raise ValueError("This intake pass has completed")
        if request_id is not None:
            self._next(run, request_id)
        result = self._put(run, graph)
        self.app.save_run(run)
        return result

    @run_locked
    def submit(self, run_id, request_id, answer):
        run = self.app.load_run(run_id)
        if request_id in run["receipts"]:
            self._cleanup_completed(run, request_id)
            return run["receipts"][request_id]
        job = self._next(run, request_id)
        if isinstance(answer, dict) and answer.get("status") == "blocked":
            self.app.event("intake.blocked", {"answer": answer, "role": job["role"]}, run_id)
            return {"run_id": run_id, "request_id": request_id, "status": "blocked", "answer": answer}
        notes = schemas.annotations(self.app, job["schema"], answer)
        source = run["stage"]
        self._put(run, answer)
        self.app.event("intake.answer", {"answer": answer, "annotations": notes, "role": job["role"]}, run_id)
        if source == "native":
            run["native_graph"] = self._native_snapshot()
            run["stage"] = "archaeology"
        else:
            run["stage"] = "complete"
        run["pending"] = None
        if job.get("workfolder_id"):
            run.setdefault("cleanup_by_request", {})[request_id] = job["workfolder_id"]
        receipt = {"run_id": run_id, "recorded": True, "source": source,
                   "remaining": 1 if source == "native" else 0,
                   "annotations": notes, "next": "intake.next"}
        run["receipts"][request_id] = receipt
        self.app.save_run(run)
        self._cleanup_completed(run, request_id)
        return receipt

    def _finish(self, run):
        self.app.graph.replace_scope(run["latent_graph"], "archaeology")
        run.update(status="complete", result=self.app.graph.merge_perspectives())
        self.app.save_run(run)
        self.app.leave()
        self.app.event("intake.complete", run["result"], run["id"])
        return {"run_id": run["id"], "status": "complete", "result": run["result"]}

    def _cleanup_completed(self, run, request_id):
        identifier = run.get("cleanup_by_request", {}).get(request_id)
        if identifier is None:
            return
        with self.app.db() as db:
            retained = db.execute("SELECT 1 FROM workfolders WHERE id=?", (identifier,)).fetchone()
        if retained is not None:
            workfolders.cleanup(self.app, identifier)
        del run["cleanup_by_request"][request_id]
        self.app.save_run(run)
