"""Authored semantic rules and the exact material used to prime inference."""

from __future__ import annotations

import importlib.resources
import json

from . import schemas
from .util import digest


def seed(app):
    path = importlib.resources.files("metaform") / "data" / "rulebook.json"
    for rule in json.loads(path.read_text(encoding="utf-8")):
        if app.graph.get("rule:" + rule["rule_code"]) is None:
            put(app, rule)


def put(app, rule):
    record = {
        "entity_desc": rule["purpose"],
        "entity_schema": "metaform:semantic-rule",
        "entity_json_obj": rule,
    }
    app.graph.put(
        {"elements": {"rule:" + rule["rule_code"]: record}}, "authored", "rulebook"
    )
    return {
        "rule": rule,
        "annotations": schemas.annotations(app, "metaform:semantic-rule", rule),
    }


def get(app, rule_code):
    identifier = "rule:" + rule_code
    record = app.graph.get(identifier) or app.global_graph.get(identifier)
    if record is None or record["entity_schema"] != "metaform:semantic-rule":
        raise ValueError(f"Unknown semantic rule: {rule_code}")
    return record["entity_json_obj"]


def prepare(app, rule_codes, concise_only=False):
    snapshots = []
    for code in dict.fromkeys(rule_codes):
        rule = get(app, code)
        snapshots.append(
            {
                "revision": digest(rule),
                "content": {
                    k: v for k, v in rule.items() if not concise_only or k != "priming"
                },
            }
        )
    return snapshots
