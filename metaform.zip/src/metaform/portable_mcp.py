"""Dependency-free stdio MCP for exported work; inference uses the host answer loop.

Implements the tools/resources subset of the 2025-11-25 specification. Installed
use retains the SDK transport, including sampling and newer protocol features.
"""

from __future__ import annotations

import asyncio
import json
import sys

from . import __version__, schemas
from .registry import Registry
from .util import dumps


class Context:
    def __init__(self, app=None, session=None):
        self.app, self.session = app, session

    def select_project(self, selector):
        if self.app is None or self.app.binding or self.session is None:
            raise ValueError("Project selection requires an unbound client session")
        return self.session.select(selector)

    async def sample(self, job, answer_command):
        return job | {
            "transport": "host_answer_loop",
            "answer_command": answer_command,
            "message": "Execute this assignment with the host model, submit its answer, then request the next step.",
        }


def tool_list(registry):
    commands = registry.visible()
    if not registry.app.binding and "project.select" not in registry.app.get("disabled_commands", []):
        commands["project.select"] = registry.discover()["project.select"]
    return {
        "tools": [
            {
                "name": "abort",
                "description": "Leave the active module and return to the router.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "metaform",
                "description": "Discover the current module's commands or execute its command or raw input.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "arguments": {"type": "object"},
                        "raw": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            *[
                {"name": c.key, "description": c.description, "inputSchema": c.schema}
                for c in commands.values()
            ],
        ]
    }


async def dispatch(app, registry, method, params, context=None):
    context = context or Context(app)
    if method == "initialize":
        return {
            "protocolVersion": "2025-11-25",
            "capabilities": {"tools": {"listChanged": True}, "resources": {}},
            "serverInfo": {"name": "metaform", "version": __version__},
            "instructions": "Use the available module commands. Workflow assignments retain exact prompts and response schemas; submit an answer and request the next step. Portable mode uses host execution. abort is the bailout.",
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return tool_list(registry)
    if method == "tools/call":
        try:
            name, arguments = params["name"], params.get("arguments") or {}
            selected_command = arguments.get("command") if name == "metaform" else name
            if selected_command == "project.select" and not app.binding and "project.select" not in app.get("disabled_commands", []):
                selection = arguments.get("arguments", {}) if name == "metaform" else arguments
                result = context.select_project(selection["project"])
            elif name == "metaform":
                if "raw" in arguments:
                    result = await registry.raw(arguments["raw"], context)
                elif arguments.get("command"):
                    result = await registry.call(
                        arguments["command"], arguments.get("arguments"), context
                    )
                else:
                    result = {
                        "mode": app.get("mode"),
                        "commands": tool_list(registry)["tools"][2:],
                        "bailout": "abort",
                    }
            else:
                result = await registry.call(name, arguments, context)
            return {
                "content": [{"type": "text", "text": dumps(result)}],
                "structuredContent": result if isinstance(result, dict) else {"result": result},
                "isError": False,
            }
        except Exception as exc:
            return {"content": [{"type": "text", "text": str(exc)}], "isError": True}
    if method == "resources/list":
        resources = [
            {"name": name, "uri": "metaform://schema/" + name, "mimeType": "application/schema+json"}
            for name in schemas.registry(app)
        ]
        if not app.get("mode"):
            resources.extend(
                {"name": name, "uri": "metaform://" + name, "mimeType": "application/json"}
                for name in ("graph", "stats")
            )
        return {"resources": resources}
    if method == "resources/templates/list":
        return {"resourceTemplates": []}
    if method == "resources/read":
        uri = params["uri"]
        if uri.startswith("metaform://schema/"):
            value = schemas.registry(app)[uri[len("metaform://schema/"):]]
        elif not app.get("mode") and uri == "metaform://graph":
            value = app.graph.export()
        elif not app.get("mode") and uri == "metaform://stats":
            value = app.graph.stats()
        else:
            raise ValueError("Unknown resource")
        return {"contents": [{"uri": uri, "mimeType": "application/json", "text": dumps(value)}]}
    raise LookupError("Method not found: " + method)


async def serve(app):
    from .modules.project import ProjectSession
    session = ProjectSession(app)
    requests = {}

    def write(message):
        sys.stdout.write(dumps({"jsonrpc": "2.0", **message}) + "\n")
        sys.stdout.flush()

    async def respond(message, app):
        registry = Registry(app)
        before = tuple(Registry(session.app).visible())
        app.trace("mcp.request", message)
        try:
            result = await dispatch(app, registry, message["method"], message.get("params") or {}, Context(app, session))
            response = {"id": message["id"], "result": result}
        except Exception as exc:
            response = {
                "id": message["id"],
                "error": {"code": -32601 if isinstance(exc, LookupError) and not isinstance(exc, KeyError) else -32602, "message": str(exc)},
            }
        app.trace("mcp.response", response)
        write(response)
        if before != tuple(Registry(session.app).visible()):
            write({"method": "notifications/tools/list_changed"})

    try:
        while line := await asyncio.to_thread(sys.stdin.readline):
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                write({"id": None, "error": {"code": -32700, "message": "Invalid JSON"}})
                continue
            if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
                write({"id": None, "error": {"code": -32600, "message": "Invalid request"}})
                continue
            if "id" not in message:
                if message["method"] == "notifications/cancelled":
                    task = requests.get((message.get("params") or {}).get("requestId"))
                    if task:
                        task.cancel()
                continue
            identifier = message["id"]
            task = asyncio.create_task(respond(message, session.app))
            requests[identifier] = task
            task.add_done_callback(lambda _, key=identifier: requests.pop(key, None))
    finally:
        pending = list(requests.values())
        for task in pending:
            task.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
