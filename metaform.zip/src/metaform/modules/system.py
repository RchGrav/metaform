import json

from metaform import schemas, workfolders
from metaform.registry import Registry
from metaform.util import write_json


def status(app, args, context):
    return {
        "project": str(app.project),
        "mode": app.get("mode"),
        "graph": app.graph.stats(),
        "commands": list(Registry(app).visible()),
    }


def modules(app, args, context):
    return [
        {"command": c.key, "always_available": c.always_available, "handler": c.handler}
        for c in Registry(app).visible().values()
    ]


def configure(app, args, context):
    path = app.home / "config.json"
    config = app.config | args["settings"]
    write_json(path, config)
    return {"configured": config}


def debug(app, args, context):
    app.set("debug", args.get("enabled", True))
    app.debug = app.get("debug")
    return {"debug": app.get("debug")}


def traces(app, args, context):
    with app.db() as db:
        rows = db.execute(
            "SELECT * FROM events WHERE (? IS NULL OR run_id=?) ORDER BY id",
            (args.get("run_id"), args.get("run_id")),
        ).fetchall()
    return [dict(row) | {"body": json.loads(row["body"])} for row in rows]


def schema_list(app, args, context):
    return schemas.registry(app)


def schema_add(app, args, context):
    return schemas.register(app, args["schema"])


def folder_create(app, args, context):
    return workfolders.create(app, args.get("source"), args.get("empty", False))


def folder_diff(app, args, context):
    return workfolders.diff(app, args["id"])


def folder_apply(app, args, context):
    return workfolders.apply(app, args["id"])


def folder_clean(app, args, context):
    return workfolders.cleanup(app, args["id"])


def forms(app, args, context):
    import importlib.resources

    return json.loads(
        (importlib.resources.files("metaform") / "data" / "forms.json").read_text()
    )
