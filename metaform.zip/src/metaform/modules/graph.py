from metaform.graph import composed_search
from metaform.util import write_json


def search(app, args, context):
    return composed_search(app, args.get("query", "*"), args.get("layer"), scope=args.get("scope"))


def get(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    scope = args.get("scope")
    return {
        "id": args["id"],
        "record": graph.get(args["id"], scope=scope),
        "provenance": [o for o in graph.provenance(args["id"]) if scope is None or o["source"] == scope],
        "joins": graph.joins(args["id"], scope=scope),
    }


def browse(app, args, context):
    if hasattr(app, "knowledge"):
        return app.knowledge.call("knowledge.assemble", {"focal": args["id"], **{key: args[key] for key in ("depth", "scope", "category") if key in args}})
    return app.graph.assemble(
        args["id"], args.get("depth"), args.get("scope"), args.get("category")
    )


def put(app, args, context):
    return app.graph.put(
        args["graph"], args.get("source", "native"), args.get("layer", "elements")
    )


def dump(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    result = graph.export(scope=args.get("scope"))
    if args.get("path"):
        from pathlib import Path

        write_json(Path(args["path"]), result)
    return result


def clean(app, args, context):
    return app.graph.clean()


def similarity(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    return graph.similarity()


def stats(app, args, context):
    return {"project": app.graph.stats(), "global": app.global_graph.stats()}


def backend(app, args, context):
    from metaform.backends import open_graph

    if getattr(app, "knowledge_mode", None) == "service":
        if args.get("name") == "ladybug":
            for owner in ("project:" + app.project_id, "global"):
                app.knowledge.call("analysis.refresh", {"owner": owner, "backend": "ladybug"})
            app.config["analytical_backend"] = "ladybug"
            app.config.pop("analysis_copies", None)
            write_json(app.root / "config.json", app.config)
        elif args.get("name"):
            app.config["analytical_backend"] = None
            app.config.pop("analysis_copies", None)
            write_json(app.root / "config.json", app.config)
        copies = {}
        for owner in ("project:" + app.project_id, "global"):
            metadata = app.knowledge.call("analysis.status", {"owner": owner})
            if metadata is not None:
                copies[owner] = metadata
        return {
            "knowledge_backend": "sqlite",
            "analytical_backend": app.config.get("analytical_backend"),
            "copies": copies,
        }

    if getattr(app, "knowledge_mode", None) == "portable":
        return {"backend": "json", "message": "Portable knowledge uses JSON; installed Ladybug analysis copies remain with the service."}
    if not args.get("name"):
        return {"backend": app.config.get("graph_backend", "sqlite")}
    name = args["name"]
    suffix = {"sqlite": ".kg", "json": ".json", "ladybug": ".lbdb"}[name]
    for old, path in [
        (app.graph, app.root),
        (app.global_graph, app.home / "inference"),
    ]:
        target = open_graph(path / ("metaform" + suffix), name)
        target.put(old.export(), "imported")
    app.config["graph_backend"] = name
    write_json(app.root / "config.json", app.config)
    app.__dict__.pop("graph", None)
    app.__dict__.pop("global_graph", None)
    return {"backend": name, "stats": app.graph.stats()}


def cypher(app, args, context):
    if getattr(app, "knowledge_mode", None) == "service":
        return app.knowledge.call("analysis.query", {
            "owner": "global" if args.get("global") else "project:" + app.project_id,
            "query": args["query"], "parameters": args.get("parameters"),
        })
    graph = app.global_graph if args.get("global") else app.graph
    if not hasattr(graph, "query"):
        return {
            "backend": app.config.get("graph_backend", "sqlite"),
            "message": "Cypher is available with the Ladybug backend.",
        }
    return graph.query(args["query"], args.get("parameters"))
