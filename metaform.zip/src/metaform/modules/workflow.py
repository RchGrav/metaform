import json
from pathlib import Path

from metaform.workflow import Engine, import_workflow
from metaform.util import input_value
from metaform.locking import assignment_lock
from metaform.prompts import semantic_equations, assemble
from metaform.modules.graph import search as search, get as get, put as put


def import_file(app, args, context):
    text = Path(args["path"]).read_text(encoding="utf-8")
    try:
        document = json.loads(text)
    except json.JSONDecodeError:
        document = text
    if isinstance(document, dict):
        document = dict(document, base_dir=str(Path(args["path"]).resolve().parent))
    return import_workflow(app, document)


def start(app, args, context):
    return Engine(app).start(
        args["id"],
        args.get("inputs", {}),
        exclusive=args.get("exclusive", True),
        workfolder=args.get("workfolder", False),
    )


def project_path(app, args):
    from metaform.workfolders import get

    run = app.load_run(run_id(app, args))
    return (
        Path(get(app, run["workfolder_id"])["path"])
        if run.get("workfolder_id")
        else app.project
    )


def files(app, args, context):
    from metaform.modules.intake import project_files

    return project_files(project_path(app, args), app.home)


def read(app, args, context):
    project = project_path(app, args)
    path = (project / args["path"]).resolve()
    if not path.is_relative_to(project):
        raise ValueError("The file is outside the workflow workfolder")
    return {"path": args["path"], "text": path.read_text(encoding="utf-8")}


def run_id(app, args):
    return (app.binding or {}).get("run_id") or args.get("run_id") or (app.get("mode") or {})["run_id"]


def next(app, args, context):
    return Engine(app).next(run_id(app, args), (app.binding or {}).get("request_id"))


def answer(app, args, context):
    identifier = run_id(app, args)
    request = (
        (app.binding or {}).get("request_id") or args.get("request_id")
        or app.load_run(identifier)["pending"]["request_id"]
    )
    return Engine(app).submit(identifier, request, args["answer"])


def recurse(app, args, context):
    return Engine(app).recursive(run_id(app, args), args.get("inputs"))


async def drive(app, args, context):
    from metaform.harness import execute
    from metaform.registry import Registry

    engine = Engine(app)
    identifier = run_id(app, args)
    bound_request = (app.binding or {}).get("request_id")
    count = 0
    while args.get("steps") is None or count < args["steps"]:
        job = engine.next(identifier, bound_request)
        if job["status"] == "awaiting_parallel":
            return job
        if job["status"] in {"complete", "aborted"}:
            return job
        if job["status"] == "running":
            count += 1
            import asyncio

            await asyncio.sleep(0)
            continue
        if job["status"] != "awaiting_tool" and args.get("harness", "mcp") == "mcp":
            return await context.sample(job, "workflow.answer") if context else job
        async with assignment_lock(app, job["request_id"]) as acquired:
            if not acquired:
                return {
                    "run_id": identifier,
                    "request_id": job["request_id"],
                    "status": "executing",
                }
            receipt_key = "execution:" + job["request_id"]
            result = app.get(receipt_key)
            if result is None:
                if job["status"] == "awaiting_tool":
                    result = {
                        "status": "answered",
                        "answer": await Registry(app).call(
                            job["tool"], job["arguments"], context, internal=True
                        ),
                    }
                else:
                    result = await execute(app, job, args["harness"])
                if result["status"] != "answered":
                    return result
                app.set(receipt_key, result)
            receipt = engine.submit(identifier, job["request_id"], result["answer"])
            if bound_request:
                return receipt
        count += 1
    return engine.next(identifier, bound_request)


def lexicalize(app, args, context):
    selected = assemble(app, args["focal"], args.get("depth", 1))
    document = {
        "id": "lexicalize:" + app.identifier(),
        "intent": args["prompt"],
        "source_instruction": args["prompt"],
        "focal": args["focal"],
        "steps": [
            {
                "id": "lexicalize",
                "kind": "prompt",
                "role": "lexicalizer",
                "intent": args["prompt"],
                "prompt_ref": "prompt:metaform.workflow.lexicalize",
                "inputs": {
                    "instruction": {"literal": args["prompt"]},
                    "metaform": {"literal": selected},
                    "semantic_equations": {"literal": semantic_equations()},
                },
                "schema": {"type": "string"},
            }
        ],
    }
    import_workflow(app, document)
    return Engine(app).start(document["id"])


def specialize(app, args, context):
    source = Engine(app).definition(args["id"])
    selected = assemble(app, args["focal"], args.get("depth"))
    document = {
        "id": "specialize:" + app.identifier(),
        "source_workflow": source,
        "focal": args["focal"],
        "intent": source.get("intent", ""),
        "steps": [
            {
                "id": "specialize",
                "role": "lexicalizer",
                "prompt_ref": "prompt:metaform.workflow.specialize",
                "inputs": {
                    "source": {"literal": source},
                    "metaform": {"literal": selected},
                    "semantic_equations": {"literal": semantic_equations()},
                },
                "schema": "metaform:workflow",
            }
        ],
    }
    import_workflow(app, document)
    return Engine(app).start(document["id"])


def convert(app, args, context):
    source = args["source"]
    identifier = "convert:" + app.identifier()
    import_workflow(
        app,
        {
            "id": identifier,
            "source_instruction": source,
            "focal": args.get("focal"),
            "intent": source if isinstance(source, str) else source.get("intent", ""),
            "steps": [
                {
                    "id": "convert",
                    "prompt_ref": "prompt:metaform.workflow.convert",
                    "schema": "metaform:workflow",
                    "inputs": {
                        "source": {"literal": source},
                        "semantic_equations": {"literal": semantic_equations()},
                        "metaform": {
                            "literal": assemble(app, args["focal"])
                            if args.get("focal")
                            else {}
                        },
                        "execution_grammar": {
                            "literal": {
                                "prompt": "prompt or prompt_ref; inputs; schema; focal; output",
                                "branch": "kind: branch; transitions: [{to: step id or null, when: expression}]",
                                "expressions": {
                                    "literal": "constant",
                                    "var": "dotted path in inputs or steps",
                                    "operators": [
                                        "==",
                                        "!=",
                                        ">",
                                        ">=",
                                        "<",
                                        "<=",
                                        "and",
                                        "or",
                                        "!",
                                        "in",
                                    ],
                                },
                                "call": "kind: call; workflow: workflow id; inputs",
                                "foreach": "kind: foreach; items: expression; prompt or prompt_ref; receives item and index",
                                "parallel": "kind: parallel; branches: [{workflow: id, inputs: expressions} or inline {id, steps}]",
                                "tool": "kind: tool; tool: module.command; arguments: expressions",
                                "sequence": "steps execute in order unless transitions select another step; transitions may refer back to earlier steps",
                            }
                        },
                    },
                }
            ],
        },
    )
    return Engine(app).start(identifier, exclusive=False)


def apply(app, args, context):
    import copy

    run = app.load_run(args["run_id"])
    definition = Engine(app).definition(run["workflow"])
    if run["status"] != "complete":
        raise ValueError("Complete the specialization run before applying its result")
    steps = run["result"]["steps"]
    if "convert" in steps:
        document = copy.deepcopy(steps["convert"])
        source = {"id": run["workflow"], "prompt": definition["source_instruction"]}
        document["id"] = args.get("id") or document.get("id", "converted:" + run["id"])
        document["source_instruction"] = definition["source_instruction"]
    elif "specialize" in steps:
        from metaform.prompts import get as get_prompt

        document = copy.deepcopy(steps["specialize"])
        source = definition["source_workflow"]
        document["id"] = args.get("id") or source["id"] + ":specialized:" + run["id"]
        source_steps = {step["id"]: step for step in source["steps"]}
        source_references = {
            step["prompt_ref"] for step in source["steps"] if step.get("prompt_ref")
        } | {prompt["id"] for prompt in source.get("prompts", [])}
        remapped = {}
        for prompt in document.get("prompts", []):
            reference = prompt["id"]
            if reference in source_references:
                remapped[reference] = "prompt:" + document["id"] + ":" + reference
                prompt["id"] = remapped[reference]
        for step in document["steps"]:
            original = source_steps.get(step["id"], {})
            reference = step.get("prompt_ref")
            if reference in remapped:
                step["prompt_ref"] = remapped[reference]
                continue
            if (
                reference
                and reference == original.get("prompt_ref")
                and "prompt" in step
                and step["prompt"] != original.get("prompt")
            ):
                prompt = copy.deepcopy(get_prompt(app, reference))
                step["prompt_ref"] = "prompt:" + document["id"] + ":" + step["id"]
                prompt.update(id=step["prompt_ref"], text=step["prompt"])
                document.setdefault("prompts", []).append(prompt)
    elif "lexicalize" in steps:
        source = {"id": run["workflow"], "prompt": definition["source_instruction"]}
        document = {
            "id": args.get("id") or run["workflow"] + ":applied",
            "intent": definition["intent"],
            "steps": [
                {
                    "id": "act",
                    "prompt": steps["lexicalize"],
                    "focal": definition["focal"],
                }
            ],
        }
    else:
        raise ValueError("This run has no specialization result")
    result = import_workflow(app, document)
    app.graph.put(
        {
            "elements": {
                "prompt:" + run["id"]: {
                    "entity_desc": document.get("intent", document["id"]),
                    "entity_schema": "metaform:provenance",
                    "entity_json_obj": {
                        "source": source,
                        "specialized": document,
                        "references": [definition["focal"]]
                        if definition.get("focal")
                        else [],
                        "run_id": run["id"],
                    },
                }
            },
            "joins": [
                {
                    "object_id": "workflow:" + document["id"],
                    "element_id": "workflow:" + source["id"],
                    "type": "specialization",
                    "participants": [
                        {"role": "source", "ref": "workflow:" + source["id"]},
                        {"role": "specialized", "ref": "workflow:" + document["id"]},
                        *(
                            [{"role": "subject", "ref": definition["focal"]}]
                            if definition.get("focal")
                            else []
                        ),
                    ],
                }
            ],
        },
        "workflow",
        "provenance",
    )
    return result


async def raw(app, argv, context):
    if argv[:1] == ["call"]:
        from metaform.registry import Registry

        return await Registry(app).call(
            "workflow." + argv[1], input_value(" ".join(argv[2:])) or {}, context
        )
    if not argv or argv == ["next"]:
        return next(app, {}, context)
    if argv[0] == "drive":
        return await drive(
            app,
            {
                "harness": argv[1] if len(argv) > 1 else "mcp",
                **({"steps": int(argv[2])} if len(argv) > 2 else {}),
            },
            context,
        )
    if argv[0] in {"get", "search"}:
        return globals()[argv[0]](
            app, {"id" if argv[0] == "get" else "query": " ".join(argv[1:])}, context
        )
    if argv[0] == "put":
        return put(app, {"graph": input_value(" ".join(argv[1:]))}, context)
    if argv[0] == "apply":
        return apply(app, {"run_id": argv[1]}, context)
    if argv[0] == "answer":
        return answer(app, {"answer": input_value(" ".join(argv[1:]))}, context)
    return {
        "assignment": next(app, {}, context),
        "input": argv,
        "commands": [
            "next",
            "answer <JSON or @file>",
            "drive [harness] [steps]",
            "call <operation> <JSON or @file>",
            "abort",
        ],
    }
