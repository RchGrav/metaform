from metaform.packaging import build as build_wheel


def build(app, args, context):
    return build_wheel(app, args.get("source"))


def ci(app, args, context):
    from metaform.ci import setup

    return setup(app, args)


def export(app, args, context):
    from metaform.portable import export

    return export(app, args.get("path") or app.root / "exports" / "metaform")


def import_bundle(app, args, context):
    from metaform.portable import import_bundle
    from metaform.app import App
    from metaform.continuation import publish
    from metaform.util import write_json

    result = import_bundle(args["path"], args.get("destination"))
    from pathlib import Path

    imported = App(result["path"], Path(result["path"]) / ".metaform" / "home")
    imported.config["assignment_home"] = str(app.home)
    write_json(imported.root / "config.json", imported.config)
    handoffs = []
    with imported.db() as db:
        runs = [r[0] for r in db.execute("SELECT id FROM runs WHERE status='running'")]
    for identifier in runs:
        run = imported.load_run(identifier)
        job = run.get("pending")
        if job:
            job.pop("nonce", None)
            publish(
                imported,
                job,
                job.get("module", "intake" if run.get("stage") else "workflow"),
            )
            imported.save_run(run)
            handoffs.append(
                {"run_id": identifier, "nonce": job["nonce"], "begin": job["begin"]}
            )
    return result | {"handoffs": handoffs}
