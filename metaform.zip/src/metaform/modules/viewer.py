def _alive(state, app):
    import json
    import urllib.request

    try:
        route = "/api/health" if state.get("instance_id") else "/api/settings"
        with urllib.request.urlopen(state["url"].rstrip("/") + route, timeout=1) as response:
            reply = json.load(response)
        if state.get("instance_id"):
            return reply == {"product": "metaform-viewer", "instance_id": state["instance_id"]}
        return (isinstance(reply, dict) and reply.get("repository") == "https://github.com/RchGrav/metaform"
                and reply.get("project_id") == app.project_id
                and reply.get("project") == str(app.project))
    except (OSError, ValueError):
        return False


async def serve(app, args, context):
    import asyncio
    import os
    import subprocess
    import sys
    from pathlib import Path
    from metaform.util import read_json, python_environment

    existing = app.get("viewer")
    if existing and await asyncio.to_thread(_alive, existing, app):
        return existing
    identifier = app.identifier()
    ready = app.root / ("viewer-" + identifier + ".ready")
    stop = app.root / ("viewer-" + identifier + ".stop")
    command = [
        sys.executable,
        "-m",
        "metaform.viewer",
        "--project",
        str(app.project),
        "--home",
        str(app.home),
        "--host",
        args.get("host", "127.0.0.1"),
        "--port",
        str(args.get("port", 5077)),
        "--ready",
        str(ready),
        "--stop",
        str(stop),
    ]
    with (app.root / "viewer.log").open("ab") as output:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=output,
            env=python_environment(),
            start_new_session=os.name != "nt",
        )
    for _ in range(100):
        if ready.exists():
            result = read_json(ready) | {
                "id": identifier,
                "ready": str(ready),
                "stop": str(stop),
            }
            app.set("viewer", result)
            return result
        if process.poll() is not None:
            raise ValueError((app.root / "viewer.log").read_text(errors="replace"))
        await asyncio.sleep(0.05)
    process.terminate()
    raise ValueError("Viewer did not finish starting; inspect the viewer log")


async def stop(app, args, context):
    import asyncio
    from pathlib import Path

    state = app.get("viewer")
    if state:
        Path(state["stop"]).touch()
        for _ in range(100):
            if not Path(state["ready"]).exists():
                break
            await asyncio.sleep(0.05)
        else:
            return {"status": "stopping", "id": state["id"]}
        app.set("viewer", None)
    return {"stopped": state["id"] if state else None}


def report(app, args, context):
    import json

    with app.db() as db:
        runs = [
            dict(r)
            for r in db.execute(
                "SELECT id,workflow,status,updated FROM runs ORDER BY updated DESC"
            )
        ]
        events = [
            dict(r) | {"body": json.loads(r["body"])}
            for r in db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 100")
        ]
    return {"stats": app.graph.stats(), "runs": runs, "events": events}
