"""Project registration and client-session selection, separate from assignments."""


class ProjectSession:
    def __init__(self, app):
        self.app = app
        self.sampling_apps = {}

    def select(self, selector):
        self.app = self.app.select_project(selector)
        return self.app.project_context()


def current(app, args, context):
    result = app.project_context()
    if app.knowledge_mode == "service":
        from metaform.service import service_status
        result["service"] = service_status(app.home)
    return result


def list_projects(app, args, context):
    if app.knowledge_mode != "service":
        return [app.project_context()]
    return app.knowledge.call("project.list", {})


def select(app, args, context):
    if app.binding:
        raise ValueError("Project selection cannot change a bound assignment")
    if context is not None and hasattr(context, "select_project"):
        return context.select_project(args["project"])
    return app.select_project(args["project"]).project_context()


def connect(app, args, context):
    from metaform.service import RemoteKnowledge
    result = RemoteKnowledge(app.home, None).call("project.adopt", {
        "path": str(app.project), "home": str(app.home),
        "name": args.get("name"), "new_copy": args.get("new", False),
    })
    if context is not None and hasattr(context, "select_project"):
        context.select_project(str(app.project))
    return result


def relocate(app, args, context):
    return app.knowledge.call("project.relocate", {"path": args["path"]})


def service_status(app, args, context):
    from metaform.service import service_status as status
    return status(app.home)


def service_stop(app, args, context):
    from metaform.service import stop_service
    return stop_service(app.home)


def bootstrap(argv, selector=None):
    """Handle registration repair and service inspection before opening an App."""
    import argparse
    import os
    from pathlib import Path
    from metaform.app import project_path
    from metaform.util import read_json
    from metaform.service import RemoteKnowledge, service_status, stop_service

    selected = selector or os.environ.get("METAFORM_PROJECT") or Path.cwd()
    parser = argparse.ArgumentParser(prog="metaform " + " ".join(argv[:2]))
    if argv[0] == "service":
        import uuid
        try:
            uuid.UUID(str(selected))
        except ValueError:
            pass
        else:
            parser.parse_args(argv[2:])
            home = Path(os.environ.get("METAFORM_HOME") or Path.home() / ".metaform")
            return service_status(home) if argv[1] == "status" else stop_service(home)
    project = project_path(selected)
    identity = read_json(project / ".metaform" / "project.json", {})
    config = read_json(project / ".metaform" / "config.json", {})
    portable = identity.get("knowledge_mode") == "portable" or config.get("knowledge_mode") == "portable"
    home = project / ".metaform" / "home" if portable else Path(
        identity.get("service_home") or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform")
    if argv[:2] == ["project", "connect"]:
        parser.add_argument("--new", action="store_true")
        parser.add_argument("--name")
        args = parser.parse_args(argv[2:])
        return RemoteKnowledge(home, None).call("project.adopt", {
            "path": str(project), "home": str(home), "name": args.name, "new_copy": args.new,
        })
    if argv[:2] == ["project", "relocate"]:
        parser.add_argument("--path", required=True)
        args = parser.parse_args(argv[2:])
        identifier = identity.get("project_id")
        if identifier is None and selector:
            import uuid
            try:
                identifier = str(uuid.UUID(str(selector)))
            except ValueError:
                pass
        if identifier is None:
            raise ValueError("This project is not registered with the shared service")
        return RemoteKnowledge(home, identifier).call("project.relocate", {"path": args.path})
    parser.parse_args(argv[2:])
    return service_status(home) if argv[1] == "status" else stop_service(home)
