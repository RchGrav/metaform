from metaform.graph import composed_search
from metaform.backends import matches
from metaform.intake import Intake
from metaform.util import input_value
from metaform.locking import assignment_lock


def start(app, args, context):
    return Intake(app).start()


def examine(app, args, context):
    return Intake(app).examine()


def run_id(app, args):
    return (app.binding or {}).get("run_id") or args.get("run_id") or (app.get("mode") or {})["run_id"]


def next(app, args, context):
    return Intake(app).next(run_id(app, args), request_id(app, args))


def request_id(app, args):
    return (app.binding or {}).get("request_id") or args.get("request_id")


def batch(app, args, context):
    if (app.binding or {}).get("request_id"):
        return [next(app, args, context)]
    return Intake(app).batch(run_id(app, args), args.get("limit"))


def answer(app, args, context):
    identifier = run_id(app, args)
    request = request_id(app, args)
    if request is None:
        run = app.load_run(identifier)
        jobs = list(run.get("assignments", {}).values())
        if len(jobs) > 1:
            raise ValueError("request_id identifies which intake assignment is answered")
        request = (run.get("pending") or (jobs[0] if jobs else {})).get("request_id")
    return Intake(app).submit(identifier, request, args["answer"])


def search(app, args, context):
    run = app.load_run(run_id(app, args))
    if run["stage"] == "archaeology":
        graph = examination_graph(run)
        results = [dict(record, id=identifier) for identifier, record in sorted(graph["elements"].items())
                   if matches(identifier, record, args.get("query", "*"))]
        for owner, referenced in run["native_graph"].get("references", {}).items():
            results.extend(dict(record, id=identifier, owner=owner)
                           for identifier, record in sorted(referenced["elements"].items())
                           if matches(identifier, record, args.get("query", "*")))
        return results
    return composed_search(app, args.get("query", "*"))


def put(app, args, context):
    """Incrementally author the active perspective; an answer completes the pass."""
    return Intake(app).put(run_id(app, args), args["graph"], request_id(app, args))


def files(app, args, context):
    run = app.load_run(run_id(app, args))
    if run["stage"] != "native":
        raise ValueError(
            "Project files are outside the Latent Expert's context"
        )
    return project_files(app.project, app.home)


def project_files(project, home):
    from pathlib import Path
    import subprocess

    probe = subprocess.run(
        [
            "git",
            "-C",
            str(project),
            "ls-files",
            "-z",
            "--cached",
            "--others",
            "--exclude-standard",
        ],
        capture_output=True,
        text=True,
    )
    if probe.returncode == 0:
        return sorted(set(probe.stdout.split("\0")) - {""})
    import os

    paths = []
    for root, directories, names in os.walk(project):
        directories[:] = [
            name
            for name in directories
            if name not in {".git", ".metaform"}
            and (Path(root) / name).resolve() != home
        ]
        paths.extend(str((Path(root) / name).relative_to(project)) for name in names)
    return sorted(paths)


def read(app, args, context):
    run = app.load_run(run_id(app, args))
    if run["stage"] != "native":
        raise ValueError(
            "Project files are outside the Latent Expert's context"
        )
    path = (app.project / args["path"]).resolve()
    if not path.is_relative_to(app.project):
        raise ValueError("The file is outside the project")
    return {"path": args["path"], "text": path.read_text(encoding="utf-8")}


def get(app, args, context):
    run = app.load_run(run_id(app, args))
    graph = examination_graph(run) if run["stage"] == "archaeology" else app.graph.export(scope="native")
    identifier = args["id"]
    owner = args.get("owner")
    project_owner = "project:" + app.project_id
    references = run.get("native_graph", {}).get("references", {})
    record = graph["elements"].get(identifier) if owner in {None, project_owner} else None
    for target in ([owner] if owner else [project_owner, "global"]):
        if record is None:
            record = references.get(target, {}).get("elements", {}).get(identifier)
        if record is None and run["stage"] == "native":
            store = app.graph if target == project_owner else app.global_graph if target == "global" else None
            if store is not None:
                record = store.get(identifier)
    return {
        "id": identifier,
        "object": record,
        "joins": [join for join in graph["joins"] if identifier in {
            join.get("id"), join.get("object_id"), join.get("element_id"),
            *(p.get("ref") for p in join.get("participants", [])),
        }],
    }


def examination_graph(run):
    native = run["native_graph"]
    latent = run.get("latent_graph", {"elements": {}, "joins": []})
    return {"elements": {**native["elements"], **latent["elements"]},
            "joins": native["joins"] + latent["joins"]}


async def drive(app, args, context):
    import asyncio
    from metaform.harness import execute

    engine = Intake(app)
    identifier = run_id(app, args)
    bound_request = (app.binding or {}).get("request_id")
    concurrency = args.get("concurrency", 4)
    if concurrency < 1:
        raise ValueError("concurrency must be positive")
    completed = 0

    async def run_job(job):
        async with assignment_lock(app, job["request_id"]) as acquired:
            if not acquired:
                return {
                    "run_id": identifier,
                    "request_id": job["request_id"],
                    "status": "executing",
                }
            receipt_key = "execution:" + job["request_id"]
            result = app.get(receipt_key)
            if result is None:
                result = await execute(app, job, args["harness"])
                if result["status"] != "answered":
                    return result
                app.set(receipt_key, result)
            return engine.submit(identifier, job["request_id"], result["answer"])

    while args.get("steps") is None or completed < args["steps"]:
        limit = concurrency
        if args.get("steps") is not None:
            limit = min(limit, args["steps"] - completed)
        jobs = [engine.next(identifier, bound_request)] if bound_request else engine.batch(identifier, limit)
        if not jobs:
            return engine.next(identifier)
        if any(job["status"] != "awaiting_answer" for job in jobs):
            return jobs[0] if len(jobs) == 1 else {
                "run_id": identifier, "status": "unresolved_object", "assignments": jobs
            }
        if args.get("harness", "mcp") == "mcp":
            if context is None:
                return jobs[0] if len(jobs) == 1 else {
                    "run_id": identifier, "status": "awaiting_answers", "assignments": jobs
                }
            if len(jobs) == 1:
                return await context.sample(jobs[0], "intake.answer")
            return await context.sample_batch(jobs, "intake.answer")
        results = await asyncio.gather(*(run_job(job) for job in jobs))
        if app.load_run(identifier)["status"] == "aborted":
            return {"run_id": identifier, "status": "aborted"}
        if bound_request:
            return results[0]
        if not all(result.get("recorded") for result in results):
            return results[0] if len(results) == 1 else {
                "run_id": identifier, "status": "awaiting_answers", "results": results
            }
        completed += len(results)
    return engine.next(identifier)


async def raw(app, argv, context):
    if argv[:1] == ["call"]:
        from metaform.registry import Registry

        return await Registry(app).call(
            "intake." + argv[1], input_value(" ".join(argv[2:])) or {}, context
        )
    if not argv or argv == ["next"]:
        return next(app, {}, context)
    if argv == ["examine"]:
        return examine(app, {}, context)
    if argv[0] == "batch":
        return batch(app, {"limit": int(argv[1])} if len(argv) > 1 else {}, context)
    if argv[0] == "drive":
        return await drive(
            app,
            {
                "harness": argv[1] if len(argv) > 1 else "mcp",
                **({"steps": int(argv[2])} if len(argv) > 2 else {}),
            },
            context,
        )
    if argv[0] == "search":
        return search(app, {"query": " ".join(argv[1:]) or "*"}, context)
    if argv[0] == "get":
        return get(app, {"id": argv[1]}, context)
    if argv[0] == "answer":
        return answer(app, {"answer": input_value(" ".join(argv[1:]))}, context)
    if argv[0] == "put":
        return put(app, {"graph": input_value(" ".join(argv[1:]))}, context)
    return {
        "assignment": next(app, {}, context),
        "input": argv,
        "commands": [
            "next",
            "examine",
            "batch [limit]",
            "answer <JSON or @file>",
            "search <query>",
            "get <id>",
            "drive [harness] [steps]",
            "call <operation> <JSON or @file>",
            "abort",
        ],
    }
