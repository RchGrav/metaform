from __future__ import annotations

import os
import sqlite3
import uuid
from contextlib import contextmanager
from functools import cached_property
from pathlib import Path

from .util import digest, dumps, now, read_json, write_json
from .locking import snapshot_locked


def project_path(selector, home=None):
    """Resolve an explicit directory or registered UUID without opening a project."""
    value = str(selector)
    try:
        uuid.UUID(value)
    except ValueError:
        return Path(selector).expanduser().resolve()
    from .service import RemoteKnowledge
    selected_home = Path(home or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").resolve()
    record = RemoteKnowledge(selected_home, None).call("project.get", {"project_id": value})
    return Path(record["path"]).resolve()


class App:
    """Project-scoped services shared by all transports and modules."""

    def __init__(self, project=None, home=None, debug=False, binding=None):
        from .continuation import marker
        from .util import archive_metadata
        import json

        archive_metadata()
        self.invocation = Path.cwd().resolve()
        inherited = json.loads(os.environ["METAFORM_BINDING"]) if os.environ.get("METAFORM_BINDING") else None
        self.binding = None if binding is False else binding or inherited or marker()
        if self.binding:
            project = self.binding["project"]
            home = self.binding["home"]
        selected = project or os.environ.get("METAFORM_PROJECT") or self.invocation
        self.project = project_path(selected, home)
        self.root = self.project / ".metaform"
        self.project_name = self.project.name
        project_config = read_json(self.root / "config.json", {})
        identity = read_json(self.root / "project.json", {})
        portable = (
            identity.get("knowledge_mode") == "portable"
            or project_config.get("knowledge_mode") == "portable"
            or (self.root / "bundle.json").exists()
            or bool(os.environ.get("METAFORM_PORTABLE"))
        )
        previous = any((self.root / name).exists() for name in (
            "state.sqlite3", "metaform.kg", "metaform.json", "metaform.lbdb", "config.json",
        ))
        self.home = (self.root / "home") if portable else Path(
            home or identity.get("service_home") or os.environ.get("METAFORM_HOME")
            or Path.home() / ".metaform"
        ).resolve()
        self.config = read_json(self.home / "config.json", {}) | project_config
        self.knowledge_mode = "portable" if portable else identity.get(
            "knowledge_mode", project_config.get(
                "knowledge_mode", "legacy" if previous else self.config.get("knowledge_mode", "service")
            )
        )
        self.config["knowledge_mode"] = self.knowledge_mode
        if portable:
            self.config.update(graph_backend="json", auto_build=False)
        self.copy_id = identity.get("copy_id")
        self.project_id = identity.get("project_id") or (identity.get("origin_project_id") if portable else None)
        self.project_id = self.project_id or uuid.uuid5(uuid.NAMESPACE_URL, str(self.project)).hex
        self.root.mkdir(parents=True, exist_ok=True)
        self.home.mkdir(parents=True, exist_ok=True)
        if self.knowledge_mode == "service":
            from .service import RemoteKnowledge, ensure_service

            ensure_service(self.home)
            remote = RemoteKnowledge(self.home, identity.get("project_id"))
            if identity.get("project_id"):
                registration = remote.call("project.get", {"project_id": identity["project_id"]})
                if Path(registration["path"]).resolve() != self.project:
                    raise ValueError("Project location mismatch; use project relocate or project connect --new")
            else:
                registration = remote.call("project.register", {"path": str(self.project), "name": self.project.name})
                write_json(self.root / "project.json", {
                    "format": "metaform-project/1", "project_id": registration["project_id"],
                    "knowledge_mode": "service", "service_home": str(self.home),
                })
            self.project_id = registration["project_id"]
            self.project_name = registration.get("name", self.project.name)
            self.knowledge = RemoteKnowledge(self.home, self.project_id)
        self.debug = debug or self.config.get("debug", False)
        self.db_path = self.root / "state.sqlite3"
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, workflow TEXT NOT NULL,
                    status TEXT NOT NULL, body TEXT NOT NULL, updated TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, run_id TEXT,
                    kind TEXT NOT NULL, body TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS workfolders(id TEXT PRIMARY KEY, path TEXT NOT NULL,
                    body TEXT NOT NULL);
            """)
        self.debug = self.debug or self.get("debug", False)
        self.seed()

    def seed(self):
        import importlib.resources
        import json

        data = importlib.resources.files("metaform") / "data"
        from .prompts import seed

        seed(self)
        from .rulebook import seed as seed_rules

        seed_rules(self)
        if self.knowledge_mode == "portable":
            return
        global_data = data / "global"
        if (global_data / "index.json").is_file():
            index = json.loads((global_data / "index.json").read_text())
            package_hash = digest(index)
            marker = self.home / "inference" / "packaged.json"
            changed = read_json(marker, {}).get("hash") != package_hash
            for identifier in index.get("schemas", []):
                if changed or self.knowledge.call("schema.get", {"owner": "global", "id": identifier}) is None:
                    schema = json.loads((global_data / "schemas" / (digest(identifier) + ".json")).read_text())
                    self.knowledge.call("schema.put", {"owner": "global", "schema": schema})
            if changed:
                elements, observations, joins = {}, [], []
                for identifier in index["elements"]:
                    record = json.loads(
                        (
                            global_data / "elements" / (digest(identifier) + ".json")
                        ).read_text()
                    )
                    elements[identifier] = record["record"]
                    observations.extend(record.get("observations", []))
                for identifier in index["joins"]:
                    joins.append(
                        json.loads(
                            (
                                global_data / "joins" / (digest(identifier) + ".json")
                            ).read_text()
                        )
                    )
                self.global_graph.put(
                    {
                        "elements": elements,
                        "joins": joins,
                        "observations": observations,
                    },
                    "packaged",
                )
                write_json(marker, {"hash": package_hash})

    @contextmanager
    def db(self):
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @cached_property
    def graph(self):
        if self.knowledge_mode == "service":
            from .knowledge import BoundGraph
            return BoundGraph(self.knowledge, "project:" + self.project_id)
        from .backends import open_graph

        backend = self.config.get("graph_backend", "sqlite")
        suffix = {"sqlite": ".kg", "json": ".json", "ladybug": ".lbdb"}[backend]
        graph = open_graph(self.root / ("metaform" + suffix), backend)
        graph.owner = "project:" + self.project_id
        graph.knowledge_snapshot = lambda: self.knowledge.read_snapshot()
        return graph

    @cached_property
    def global_graph(self):
        if self.knowledge_mode == "service":
            from .knowledge import BoundGraph
            return BoundGraph(self.knowledge, "global")
        from .backends import open_graph

        backend = self.config.get("graph_backend", "sqlite")
        suffix = {"sqlite": ".kg", "json": ".json", "ladybug": ".lbdb"}[backend]
        graph = open_graph(self.home / "inference" / ("metaform" + suffix), backend)
        graph.owner = "global"
        graph.knowledge_snapshot = lambda: self.knowledge.read_snapshot()
        return graph

    @property
    def knowledge(self):
        if self.knowledge_mode == "service":
            return self._knowledge
        from .knowledge import LocalKnowledge
        existing = self.__dict__.get("_knowledge")
        if existing is not None and existing.graphs.get("project:" + self.project_id) is self.graph and existing.graphs.get("global") is self.global_graph:
            return existing
        manifest = read_json(self.root / "knowledge-manifest.json", {})
        captured_schemas = None
        if self.knowledge_mode == "portable" and "schemas" in manifest:
            captured_schemas = {}
            for record in manifest["schemas"]:
                captured_schemas.setdefault(record["owner"], {})[record["id"]] = record["body"]
        self._knowledge = LocalKnowledge(self.project_id, self.graph, self.global_graph,
                                         schemas=captured_schemas,
                                         archive_dependencies=read_json(self.root / "archive-dependencies.json", []))
        return self._knowledge

    @knowledge.setter
    def knowledge(self, value):
        self._knowledge = value

    def select_project(self, selector):
        if self.binding:
            raise ValueError("Project selection cannot change a bound assignment")
        home = self.home
        if self.knowledge_mode == "portable":
            home = Path(getattr(self, "_selection_home", None)
                        or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").expanduser().resolve()
            if home == self.home:
                home = Path.home() / ".metaform"
        project = project_path(selector, home)
        identity = read_json(project / ".metaform" / "project.json", {})
        selected = App(project, identity.get("service_home") or home, binding=False)
        selected._selection_home = home
        return selected

    def project_context(self):
        return {
            "project_id": self.project_id, "name": self.project_name,
            "path": str(self.project), "knowledge_mode": self.knowledge_mode,
            "assignment": self.binding, "mode": self.get("mode"),
        }

    def get(self, key, default=None):
        import json

        if key == "mode" and self.binding:
            return {"module": self.binding["module"], "run_id": self.binding["run_id"]}

        with self.db() as db:
            row = db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    @snapshot_locked
    def set(self, key, value):
        with self.db() as db:
            db.execute(
                "INSERT INTO state VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, dumps(value)),
            )

    @snapshot_locked
    def event(self, kind, value, run_id=None):
        with self.db() as db:
            db.execute(
                "INSERT INTO events(run_id,kind,body,created) VALUES(?,?,?,?)",
                (run_id, kind, dumps(value), now()),
            )

    def trace(self, kind, value, run_id=None):
        if self.debug:
            self.event("debug." + kind, value, run_id)

    def enter(self, module, run_id=None):
        if self.binding:
            return
        self.set("mode", {"module": module, "run_id": run_id})

    def leave(self):
        if self.binding:
            return
        self.set("mode", None)

    def abort(self):
        mode = self.get("mode")
        if mode and mode.get("run_id"):
            from .workflow import Engine

            aborted = Engine(self).abort(mode["run_id"])
            # The executing harness observes this persisted status and terminates
            # its own process; abort never signals an unverified operating-system PID.
            from .workfolders import cleanup_aborted

            for run in aborted:
                cleanup_aborted(self, run)
        if self.binding:
            from .continuation import marker

            local = marker()
            if local and local["nonce"] == self.binding["nonce"]:
                (Path(local["folder"]) / ".agentid" / "nonce").unlink()
            self.binding = None
        self.leave()
        self.event("abort", mode)
        return {"aborted": mode, "mode": "router"}

    @snapshot_locked
    def save_run(self, body):
        body.setdefault(
            "origin", {"invocation": str(self.invocation), "target": str(self.project)}
        )
        with self.db() as db:
            db.execute(
                "INSERT INTO runs VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, body=excluded.body, updated=excluded.updated",
                (body["id"], body["workflow"], body["status"], dumps(body), now()),
            )

    def load_run(self, run_id):
        import json

        with self.db() as db:
            row = db.execute("SELECT body FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            raise ValueError(f"Unknown run: {run_id}")
        return json.loads(row[0])

    def identifier(self):
        return uuid.uuid4().hex
