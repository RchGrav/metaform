from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from .util import dumps
from .locking import snapshot_locked


def git(path, *args):
    result = subprocess.run(
        ["git", "-C", str(path), *args], text=True, capture_output=True
    )
    if result.returncode:
        raise ValueError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout


@snapshot_locked
def create(app, source=None, empty=False):
    if app.config.get("graph_backend") == "json" or not shutil.which("git"):
        return create_files(app, source, empty)
    identifier = app.identifier()
    target = app.home / "workfolders" / identifier
    target.mkdir(parents=True)
    source = Path(source or app.project).resolve()
    if not empty:
        probe = subprocess.run(
            ["git", "-C", str(source), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
        )
        if probe.returncode == 0 and Path(probe.stdout.strip()).resolve() == source:
            listing = git(
                source, "ls-files", "-z", "--cached", "--others", "--exclude-standard"
            )
            for name in set(listing.split("\0")) - {""}:
                if set(Path(name).parts) & {".git", ".metaform", ".agentid"}:
                    continue
                origin = source / name
                if origin.is_file() or origin.is_symlink():
                    destination = target / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(origin, destination, follow_symlinks=False)
        else:
            for child in source.iterdir():
                if child.name in {".git", ".metaform"} or child.resolve() == app.home:
                    continue
                if child.is_dir():

                    def ignored(directory, names):
                        return [
                            n
                            for n in names
                            if n in {".git", ".metaform"}
                            or (Path(directory) / n).resolve() in {app.home, target}
                        ]

                    shutil.copytree(
                        child, target / child.name, symlinks=True, ignore=ignored
                    )
                else:
                    shutil.copy2(child, target / child.name, follow_symlinks=False)
    git(target, "init", "-q")
    git(target, "add", "-A")
    git(
        target,
        "-c",
        "user.name=Metaform",
        "-c",
        "user.email=metaform@localhost",
        "commit",
        "--allow-empty",
        "-qm",
        "Workfolder baseline",
    )
    body = {
        "id": identifier,
        "path": str(target),
        "source": None if empty else str(source),
        "baseline": git(target, "rev-parse", "HEAD").strip(),
    }
    with app.db() as db:
        db.execute(
            "INSERT INTO workfolders VALUES(?,?,?)",
            (identifier, str(target), dumps(body)),
        )
    return body


def get(app, identifier):
    with app.db() as db:
        row = db.execute(
            "SELECT body FROM workfolders WHERE id=?", (identifier,)
        ).fetchone()
    if row is None:
        raise ValueError(f"Unknown workfolder {identifier}")
    return json.loads(row[0])


def diff(app, identifier):
    body = get(app, identifier)
    if body.get("backend") == "files":
        return files_diff(app, body)
    path = Path(body["path"])
    git(path, "add", "-N", ".")
    return {
        "workfolder": identifier,
        "diff": git(path, "diff", "--binary", "--no-ext-diff", "HEAD", "--"),
        "status": git(path, "status", "--short"),
    }


@snapshot_locked
def apply(app, identifier):
    body = get(app, identifier)
    if body["source"] is None:
        raise ValueError("An empty workfolder has no source to apply changes to")
    report = diff(app, identifier)
    if body.get("backend") == "files":
        return apply_files(app, body, report)
    if not report["diff"]:
        return {"applied": False, "reason": "No changes"}
    # A surrounding repository must not change how source-relative paths apply.
    environment = dict(
        os.environ,
        GIT_CEILING_DIRECTORIES=str(Path(body["source"]).resolve().parent),
    )
    for options in (["--check"], []):
        result = subprocess.run(
            ["git", "-C", body["source"], "apply", *options, "--binary", "-"],
            input=report["diff"],
            text=True,
            capture_output=True,
            env=environment,
        )
        if result.returncode:
            raise ValueError(result.stderr.strip())
    app.event("workfolder.applied", report)
    return {"applied": True, "workfolder": identifier, "source": body["source"]}


@snapshot_locked
def cleanup_aborted(app, run):
    """Retain shared work until its owning run is aborted and all harnesses stop."""
    with app.db() as db:
        runs = [json.loads(row[0]) for row in db.execute("SELECT body FROM runs")]
    owners = {item["workfolder_id"]: item for item in runs
              if item.get("workfolder_id") and not item.get("workfolder_inherited")}
    active, folders = set(), set()
    for item in runs:
        if item.get("workfolder_id") and any(
            app.get("executing:" + request_id) for request_id in item.get("receipts", {})
        ):
            active.add(item["workfolder_id"])
        jobs = list(item.get("assignments", {}).values())
        if item.get("pending"):
            jobs.append(item["pending"])
        for job in jobs:
            identifier = job.get("workfolder_id") or item.get("workfolder_id")
            if identifier and app.get("executing:" + job["request_id"]):
                active.add(identifier)
            if identifier and item["id"] == run["id"]:
                folders.add(identifier)
    if run.get("workfolder_id"):
        folders.add(run["workfolder_id"])
    for identifier in folders - active:
        if owners.get(identifier, run)["status"] != "aborted":
            continue
        with app.db() as db:
            exists = db.execute("SELECT 1 FROM workfolders WHERE id=?", (identifier,)).fetchone()
        if exists:
            cleanup(app, identifier)


@snapshot_locked
def cleanup(app, identifier):
    body = get(app, identifier)
    path = Path(body["path"])
    managed_root = (app.home / "workfolders").resolve()
    if path.resolve().parent != managed_root:
        raise ValueError("Workfolder is outside the chassis-managed directory")
    report = diff(app, identifier)
    from .history import scan, copy_entry, safe_path

    artifacts = app.root / "outputs" / identifier
    for name, info in scan(path, [".git", ".metaform", ".agentid"]).items():
        copy_entry(path / name, safe_path(artifacts, name), info)
    report["artifacts"] = str(artifacts)
    app.event("workfolder.cleanup", report)
    shutil.rmtree(path)
    with app.db() as db:
        db.execute("DELETE FROM workfolders WHERE id=?", (identifier,))
    return {"removed": identifier, "diff_recorded": True}


@snapshot_locked
def create_files(app, source=None, empty=False):
    from .history import scan, copy_entry, safe_path
    from .util import digest

    identifier = app.identifier()
    target = app.home / "workfolders" / identifier
    target.mkdir(parents=True)
    source = Path(source or app.project).resolve()
    baseline = (
        {}
        if empty
        else scan(
            source,
            [".metaform", ".git", ".agentid", *app.config.get("history_exclude", [])],
        )
    )
    base_path = app.home / "workfolder-baselines" / identifier
    for name, info in baseline.items():
        for folder in (target, base_path):
            out = safe_path(folder, name)
            if "symlink" in info:
                out.parent.mkdir(parents=True, exist_ok=True)
                out.symlink_to(info["symlink"])
            else:
                copy_entry(source / name, out, info)
    body = {
        "id": identifier,
        "path": str(target),
        "source": None if empty else str(source),
        "baseline": digest(baseline),
        "files": baseline,
        "backend": "files",
    }
    with app.db() as db:
        db.execute(
            "INSERT INTO workfolders VALUES(?,?,?)",
            (identifier, str(target), dumps(body)),
        )
    return body


def files_diff(app, body):
    import difflib
    from .history import scan

    path = Path(body["path"])
    before, after = body["files"], scan(path, [".metaform", ".git", ".agentid"])
    changes = {
        name: after.get(name)
        for name in sorted(before.keys() | after.keys())
        if before.get(name) != after.get(name)
    }
    lines = []
    baseline = app.home / "workfolder-baselines" / body["id"]
    for name, info in changes.items():
        try:
            old = (
                (baseline / name).read_text()
                if name in before and "symlink" not in before[name]
                else ""
            )
            new = (path / name).read_text() if info and "symlink" not in info else ""
            if "\0" in old or "\0" in new:
                raise UnicodeError()
            lines.extend(
                difflib.unified_diff(
                    old.splitlines(True), new.splitlines(True), "a/" + name, "b/" + name
                )
            )
        except UnicodeError:
            lines.append("Binary file changed: " + name + "\n")
    return {
        "workfolder": body["id"],
        "diff": "".join(lines),
        "changes": changes,
        "status": "\n".join(
            ("D " if info is None else "M " if name in before else "A ") + name
            for name, info in changes.items()
        ),
    }


@snapshot_locked
def apply_files(app, body, report):
    from .history import scan, safe_path, copy_entry

    source = Path(body["source"])
    existing = scan(source, [".metaform", ".git", ".agentid"])

    def comparable(info):
        if info is None or not body.get("git_permissions"):
            return info
        return dict(info, mode=info["mode"] & 0o111)

    affected = set(report["changes"])
    for name, info in report["changes"].items():
        if info is not None:
            affected.update(key for key in existing if key.startswith(name + "/"))
    conflicts = [
        name
        for name in sorted(affected)
        if comparable(existing.get(name)) != comparable(body["files"].get(name))
    ]
    if conflicts:
        raise ValueError(
            "Source changed since this workfolder began: " + ", ".join(conflicts)
        )
    for name in sorted(report["changes"], key=lambda key: len(Path(key).parts), reverse=True):
        target = safe_path(source, name)
        if target.is_symlink() or target.is_file():
            target.unlink()
    for name, info in report["changes"].items():
        if info is not None:
            target = safe_path(source, name)
            if target.is_dir():
                for parent, directories, files in os.walk(target, topdown=False):
                    Path(parent).rmdir()
            if "symlink" in info:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.symlink_to(info["symlink"])
            else:
                copy_entry(Path(body["path"]) / name, target, info)
    app.event("workfolder.applied", report)
    return {
        "applied": bool(report["changes"]),
        "workfolder": body["id"],
        "source": str(source),
    }
