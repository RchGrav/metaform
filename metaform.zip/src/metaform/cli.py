from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

from .app import App
from .registry import Registry
from .util import input_value


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    project = None
    try:
        if argv[:1] == ["--project"]:
            if len(argv) < 2:
                raise ValueError("--project requires a path or registered project ID")
            project, argv = argv[1], argv[2:]
        elif argv and argv[0].startswith("--project="):
            project, argv = argv[0].split("=", 1)[1], argv[1:]
        from .continuation import marker
        binding = json.loads(os.environ["METAFORM_BINDING"]) if os.environ.get("METAFORM_BINDING") else marker()
        if project and binding:
            from .app import project_path
            if project_path(project, binding["home"]) != project_path(binding["project"]):
                raise ValueError("The selected project conflicts with this bound assignment")
    except ValueError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    if argv[:1] == ["actor"]:
        from .actor import main as actor_main

        return actor_main(argv[1:])
    if os.environ.get("METAFORM_GATEWAY"):
        if argv == ["mcp"]:
            from .mcp_server import serve

            asyncio.run(serve())
            return 0
        from .actor import main as actor_main

        return actor_main(argv)
    if not binding and argv[:2] in (["project", "connect"], ["project", "relocate"], ["service", "status"], ["service", "stop"]):
        from .modules.project import bootstrap
        try:
            print(json.dumps(bootstrap(argv, project), ensure_ascii=False, indent=2))
            return 0
        except Exception as exc:
            print(json.dumps({"error": str(exc)}), file=sys.stderr)
            return 1
    if argv[:1] == ["begin"]:
        from .continuation import begin

        try:
            print(json.dumps(begin(argv[1], home=binding["home"] if binding else None, project=project), ensure_ascii=False, indent=2))
            return 0
        except (IndexError, ValueError) as exc:
            print(
                json.dumps({"error": str(exc), "usage": "metaform begin <nonce>"}),
                file=sys.stderr,
            )
            return 1
    try:
        app = App(project=project)
    except Exception as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    registry = Registry(app)
    if not app.binding and argv[:1] == ["install"]:
        from .installation import install

        print(json.dumps(install(app, argv[1] if len(argv) > 1 else None), indent=2))
        return 0
    if not app.binding and argv == ["browse"]:
        from .modules.viewer import serve

        result = asyncio.run(serve(app, {"port": 0}, None))
        print(json.dumps(result, indent=2))
        return 0
    if argv == ["mcp"]:
        from .mcp_server import serve

        asyncio.run(serve(app))
        return 0
    mode = app.get("mode")
    try:
        if mode and registry.disables_argparse():
            if argv == ["abort"]:
                result = app.abort()
            elif (
                len(argv) >= 2
                and (command := registry.visible().get(".".join(argv[:2])))
                and command.always_available
            ):
                result = run_parser(registry, argv, mode=True)
            else:
                result = asyncio.run(registry.raw(argv))
        else:
            result = run_parser(registry, argv, mode=bool(mode))
        if result is not None:
            print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        return 0
    except Exception as exc:
        import traceback

        app.trace("cli.error", {"error": str(exc), "traceback": traceback.format_exc()})
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


def run_parser(registry, argv, mode=False):
    parser = argparse.ArgumentParser(prog="metaform")
    if not mode:
        parser.add_argument("--debug", action="store_true")
    groups = parser.add_subparsers(dest="module")
    groups.add_parser("abort", help="Leave the active module")
    if not mode:
        groups.add_parser("mcp", help="Serve the same modules over stdio MCP")
        groups.add_parser(
            "begin", help="Bind this folder to a workflow nonce: begin <nonce>"
        )
        groups.add_parser("browse", help="Start the local semantic workbench and print its URL")
        groups.add_parser(
            "install",
            help="Install the user-local command and hydrate Ladybug if available",
        )
    parents = {}
    for command in registry.visible().values():
        if mode and registry.disables_argparse() and not command.always_available:
            continue
        if command.module not in parents:
            parents[command.module] = groups.add_parser(command.module).add_subparsers(
                dest="operation"
            )
        sub = parents[command.module].add_parser(
            command.name, help=command.description, description=command.description
        )
        sub.set_defaults(command_key=command.key)
        for name, shape in command.schema.get("properties", {}).items():
            option = "--" + name.replace("_", "-")
            kwargs = {"dest": name, "help": shape.get("description", "")}
            if "default" in shape:
                kwargs["default"] = shape["default"]
            if name in command.schema.get("required", []):
                kwargs["required"] = True
            if shape.get("type") == "boolean":
                kwargs["action"] = argparse.BooleanOptionalAction
            elif shape.get("type") == "integer":
                kwargs["type"] = int
            elif shape.get("type") == "number":
                kwargs["type"] = float
            else:
                kwargs["type"] = input_value if shape.get("type") != "string" else str
            sub.add_argument(option, **kwargs)
    args = vars(parser.parse_args(argv))
    if args.pop("debug", False):
        registry.app.debug = True
        registry.app.set("debug", True)
    if args.get("module") == "mcp":
        from .mcp_server import serve

        asyncio.run(serve(registry.app))
        return None
    if args.get("module") == "abort":
        return registry.app.abort()
    key = args.pop("command_key", None)
    if not key:
        parser.print_help()
        return None
    args.pop("module", None)
    args.pop("operation", None)
    return asyncio.run(
        registry.call(key, {k: v for k, v in args.items() if v is not None})
    )
