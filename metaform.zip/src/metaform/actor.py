"""A scoped tool bridge for fresh subprocess harnesses.

The child receives a loopback endpoint, never the parent conversation. Its tool
view is bound to one assignment. Latent Expert tools examine its supplied functional context.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import secrets
import sys
import threading
import urllib.error
import urllib.request
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .registry import Registry
from .continuation import pending_assignment
from .util import dumps, input_value


@contextmanager
def gateway(app, assignment):
    token = secrets.token_urlsafe(32)
    commands = set(assignment.get("tools", [])) - {
        "intake.answer",
        "intake.next",
        "workflow.answer",
        "workflow.next",
    }
    commands.update(
        c.key for c in Registry(app).discover().values() if c.always_available
    )
    commands.add("abort")

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_POST(self):
            try:
                if not secrets.compare_digest(
                    self.headers.get("Authorization", ""), "Bearer " + token
                ):
                    self.send_error(403)
                    return
                request = json.loads(
                    self.rfile.read(int(self.headers.get("Content-Length", 0)))
                )
                pending_assignment(app, assignment["run_id"], assignment["request_id"])
                command = request.get("command")
                if command is None:
                    value = {
                        "commands": [
                            {"name": c.key, "inputSchema": c.schema}
                            for c in Registry(app).discover().values()
                            if c.key in commands
                        ]
                        + [{"name": "abort", "inputSchema": {"type": "object"}}]
                    }
                else:
                    if command not in commands:
                        raise ValueError(
                            "Command is outside this assignment's tool view"
                        )
                    arguments = request.get("arguments", {}) | {
                        "run_id": assignment["run_id"],
                        "request_id": assignment["request_id"],
                    }
                    import copy

                    scoped = copy.copy(app)
                    scoped.binding = {
                        "module": assignment.get(
                            "module", (app.get("mode") or {}).get("module", "workflow")
                        ),
                        "run_id": assignment["run_id"],
                        "request_id": assignment["request_id"],
                        "nonce": assignment.get("nonce"),
                    }
                    value = asyncio.run(Registry(scoped).call(command, arguments))
                body = dumps(value).encode()
                self.send_response(200)
            except Exception as exc:
                body = dumps({"error": str(exc)}).encode()
                self.send_response(400)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    service = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    service.daemon_threads = True
    thread = threading.Thread(target=service.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "METAFORM_GATEWAY": f"http://127.0.0.1:{service.server_port}",
            "METAFORM_GATEWAY_TOKEN": token,
            "METAFORM_BINDING": dumps(
                {
                    "project": str(app.project),
                    "home": str(app.home),
                    "module": assignment.get(
                        "module", (app.get("mode") or {}).get("module", "workflow")
                    ),
                    "run_id": assignment["run_id"],
                    "request_id": assignment["request_id"],
                    "nonce": assignment.get("nonce"),
                }
            ),
        }
    finally:
        service.shutdown()
        service.server_close()
        thread.join(timeout=1)


def main(argv=None):
    parser = argparse.ArgumentParser(prog="metaform actor")
    parser.add_argument("command", nargs="?")
    parser.add_argument("--arguments", type=input_value, default={})
    args = parser.parse_args(argv)
    try:
        endpoint = os.environ["METAFORM_GATEWAY"]
        request = urllib.request.Request(
            endpoint,
            data=dumps(vars(args)).encode(),
            headers={
                "Authorization": "Bearer " + os.environ["METAFORM_GATEWAY_TOKEN"],
                "Content-Type": "application/json",
            },
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            print(response.read().decode())
        return 0
    except (KeyError, urllib.error.URLError) as exc:
        print(
            dumps(
                {
                    "error": str(exc),
                    "message": "The actor bridge is available inside an assigned harness process.",
                }
            ),
            file=sys.stderr,
        )
        return 1
