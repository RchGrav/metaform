from __future__ import annotations

import importlib.resources
import json

from .util import read_json, write_json


def builtins():
    return json.loads(
        (importlib.resources.files("metaform") / "data" / "schemas.json").read_text()
    )


def registry(app, owner=None):
    from .util import digest

    base = builtins()
    global_data = importlib.resources.files("metaform") / "data" / "global"
    if getattr(app, "knowledge_mode", None) != "portable" and (global_data / "index.json").is_file():
        index = json.loads((global_data / "index.json").read_text())
        for identifier in index.get("schemas", []):
            base[identifier] = json.loads(
                (global_data / "schemas" / (digest(identifier) + ".json")).read_text()
            )
    if getattr(app, "knowledge", None) is not None:
        if owner is not None:
            selected = app.knowledge.call("schema.list", {"owner": owner})
            return base | selected if owner == "global" else selected
        return (base | app.knowledge.call("schema.list", {"owner": "global"})
                | app.knowledge.call("schema.list", {"owner": "project:" + app.project_id}))
    if owner is None or owner == "global":
        return base | read_json(app.home / "schemas.json", {})
    return read_json(app.root / "schemas.json", {})


def register(app, schema, owner="global"):
    from filelock import FileLock

    try:
        from jsonschema import Draft202012Validator
    except ImportError:
        Draft202012Validator = None
    if Draft202012Validator:
        Draft202012Validator.check_schema(schema)
    if getattr(app, "knowledge", None) is not None:
        return app.knowledge.call("schema.put", {"owner": owner, "schema": schema})
    with FileLock(app.home / "schemas.lock", timeout=30):
        user = read_json(app.home / "schemas.json", {})
        user[schema["$id"]] = schema
        write_json(app.home / "schemas.json", user)
    return schema


def annotations(app, schema, value):
    try:
        from jsonschema import Draft202012Validator
        from referencing import Registry, Resource
    except ImportError:
        return [
            {
                "path": [],
                "message": "Schema validation is unavailable in this portable runtime; the schema and answer are retained.",
            }
        ]
    all_schemas = registry(app)
    if isinstance(schema, str):
        if schema not in all_schemas:
            return [{"path": [], "message": "Schema is not registered: " + schema}]
        schema = all_schemas.get(schema)
    if not schema:
        return []
    references = Registry().with_resources(
        (key, Resource.from_contents(record)) for key, record in all_schemas.items()
    )
    return [
        {"path": list(error.absolute_path), "message": error.message}
        for error in Draft202012Validator(schema, registry=references).iter_errors(
            value
        )
    ]


def bundled(app, schema, owner=None):
    """Carry registered references with a response schema to an external agent."""
    import copy

    all_schemas = registry(app, owner=owner)
    root = copy.deepcopy(
        all_schemas[schema] if isinstance(schema, str) else schema or {}
    )
    definitions = {}

    def expand(value):
        if isinstance(value, list):
            return [expand(item) for item in value]
        if not isinstance(value, dict):
            return value
        result = dict(value)
        if result.get("$ref") in all_schemas:
            key = result["$ref"]
            result["$ref"] = "#/$defs/" + key.replace("~", "~0").replace("/", "~1")
            if key not in definitions:
                definitions[key] = {}
                target = copy.deepcopy(all_schemas[key])
                target.pop("$id", None)
                definitions[key] = expand(target)
        return {k: expand(v) if k != "$ref" else v for k, v in result.items()}

    root = expand(root)
    if definitions:
        root["$defs"] = root.get("$defs", {}) | definitions
    return root
