"""Authored inference instructions and the exact inputs used to exercise them."""

from __future__ import annotations

import importlib.resources
import json

from .util import digest, now

INTAKE_RULE_CODES = ["r1", "r2", "r3", "r4", "r5"]
LEGACY_INTAKE_REVISIONS = {
    "prompt:metaform.intake.native": {
        "058f1f255f2f149d2f7176dfac552862f44cff05b0e7f6df57ca8e14b94f314d",
        "d41f556615d7da4f90b8f9085eb060ceba6d88fe9bf4dea3f1f7849fbc277b7b",
        "80232033604ad5b7d561ff922210906cf2832ce677356f3e2c2323bb7f3b9b2c",
        "552cca93e9fb404dc2304b334897a70328c3c04b313e76d6b98ec05ad6c50304",
        "5d0aa69282d0ab1e3636c7cc826e36bd4aa5ba08559ec67ee1a8a4102ea14d46",
        "24349c2e8dd3fbdf9fdfd76e96cd1f1c97ed8c949df54dcc476e360b3acce463",
        "76f899b40d055935cca7f3d7422548df65487e169d4770af57fc06c7f7c470c8",
        "db6b6641e40cbbafd54cbbe4329a73e432997cf5d891250df2383dbda18b15da",
        "0bb5648b0e23a5e79cd5508b359c5b87a59d0d5c91fab92261fe2674c1a6933e",
        "eb88a6a858cec14dba64fbdf44651781f6de1f18f1eae349c285f7d0e7034059",
        "b2a9f8ba78955a2b6a2468bf1e6dd9374cd05a33277020e27faecc46d59a6924",
        "048eec417a0f1af3a4aa5ce2c91fd6b7b525dca0f15c181bbe7f7b060485c5ac",
        "a330ff6b94e50ee9ddad73e493fef3154c6b38271b5b63b4a6939b2b0761a3b8",
    },
    "prompt:metaform.intake.archaeology": {
        "81c16b6909c20d815b65ca97fc085badfcc0002f23ffc5f3f15f556ae393bf93",
        "8200946ddeccf3835d66be54d5b601ab99f048cd0f8d921df0cccac8b1c84711",
        "3b4485a1f80c829240f6339f6901b7683a7bbcf3577931ec7d589bbdca744daf",
        "58f78cd029ca5e332dba45b9a5bb21b60ab3b13fca52cb8d319c075662c4df35",
        "f3f504fbef9c745ce8783b5c037fe1d52ec4996e929e2898a2abc245017bc0df",
        "a43ca0f7c1698d3e3e3a66d45ffcf33efea101cd176b6386850a47a0bd09a6e6",
        "1a3ec7258b20c6b7f50fbf9ea7047a7d92375036e7023b1359e1592c0dad27da",
        "3bdabc17bd13fc6a967d4cb15e96f5d8df4bbb872ab434576ecebae0fd8c172e",
        "ffe46efb00809804d9158ab7a0ed6c7bf75cad1f91b2e767b7a6158d48407c9e",
        "41ef3fd08c1ee87a223a56d8b88c617ec23635ea936ccc96045dd41d7b8eb041",
    },
    "prompt:metaform.intake.proof": {
        "cb0094fe95e15c69cdc4da6c7317a74a91ba4cb2296dc1d5158bbac2a3b813dd",
        "42dc6ba39705abb5a3ef81ec5801d3b0f5da07b2f3c18870736dcad31559b960",
        "b5782a5849716a574a43135fc32c4d7e184bccc7f587ca009ed4a41574b865d6",
        "da7c9a42d59e954c7984d3a4931a066fc8a6b0e2bc0777b18d3b347f04cba057",
        "793759e5c2ca69b8614da2e9fb21ff16b6f9182eb75a0b828ea3578cc51eace5",
        "ec950109b1d43d85230852ae714a64fa017014be349dbe9759f28529c1d09d24",
        "8b395b740ba07a0f6367db7ab24edba6fd2d0fb2813584e2be722fcc9c0aa35e",
    },
}


def semantic_equations():
    text = (
        importlib.resources.files("metaform")
        / "data" / "semantics" / "semantic-equation-reuse.md"
    ).read_text()
    return {
        "source": "docs/semantics/semantic_equation_reuse_rule.md",
        "text": text,
        "revision": digest(text),
    }


def seed(app):
    data = importlib.resources.files("metaform") / "data"
    documents = (
        json.loads((data / "prompts.json").read_text())
        if (data / "prompts.json").is_file()
        else []
    )
    for role in ("native", "proof", "archaeology"):
        if not (data / "semantics" / (role + ".md")).is_file():
            continue
        documents.append(
            {
                "id": "prompt:metaform.intake." + role,
                "name": {
                    "native": "Native Expert",
                    "proof": "Type proof",
                    "archaeology": "Latent Expert",
                }[role],
                "text": "\n\n".join(
                    (data / "semantics" / name).read_text()
                    for name in (["glossary.md", "proof.md"] if role == "proof"
                                 else [role + ".md", "glossary.md"])
                ),
                "rule_codes": INTAKE_RULE_CODES,
            }
        )
    for prompt in documents:
        stored = app.graph.get(prompt["id"])
        if not stored:
            put(app, prompt)
        elif digest(stored["entity_json_obj"]["text"]) in LEGACY_INTAKE_REVISIONS.get(prompt["id"], set()):
            updated = dict(stored["entity_json_obj"], text=prompt["text"])
            if updated.get("name") in {"Contextual intake", "Latent archaeology", "Type proof"}:
                updated["name"] = prompt["name"]
            put(app, updated)


def put(app, prompt):
    identifier = prompt["id"]
    data = dict(prompt)
    data["en"] = data.get("name", identifier)
    data["revision"] = digest(data["text"])
    record = {
        "entity_desc": data.get("description", data["en"]),
        "entity_schema": "metaform:prompt",
        "entity_json_obj": data,
    }
    app.graph.put({"elements": {identifier: record}}, "authored", "prompts")
    return record


def get(app, identifier):
    record = app.graph.get(identifier) or app.global_graph.get(identifier)
    if record is None:
        raise ValueError(f"Unknown prompt: {identifier}")
    prompt = record["entity_json_obj"]
    if identifier in {
        "prompt:metaform.intake.native", "prompt:metaform.intake.proof",
        "prompt:metaform.intake.archaeology"
    }:
        # Older stored intake prompts receive the established rules without
        # replacing their authored text. Explicit attachments remain editable.
        prompt.setdefault("rule_codes", list(INTAKE_RULE_CODES))
    return prompt


def snapshot(app, identifier):
    from . import rulebook

    prompt = get(app, identifier)
    return {
        "prompt_ref": identifier,
        "prompt_revision": digest(prompt["text"]),
        "source_prompt": prompt["text"],
        "schema": prompt.get("schema"),
        "rules": rulebook.prepare(app, prompt.get("rule_codes", [])),
    }


def assemble(app, focal, depth=None, scope=None, category=None):
    if getattr(app, "knowledge", None) is not None:
        return app.knowledge.call("knowledge.assemble", {
            "focal": focal, "depth": depth, "scope": scope, "category": category,
        })
    return app.graph.assemble(focal, depth, scope, category)


def prepare(app, identifier, inputs=None, focal=None, depth=None):
    from .workflow import render

    prepared = snapshot(app, identifier)
    values = inputs or {}
    return prepared | {
        "prompt": render(prepared["source_prompt"], values),
        "inputs": values,
        "graph": assemble(app, focal, depth) if focal else {},
    }


def record_test(app, prepared, answer, note=""):
    identifier = "test:" + app.identifier()
    record = {
        "entity_desc": "Prompt test",
        "entity_schema": "metaform:prompt-test",
        "entity_json_obj": {
            "en": "Test",
            "prepared": prepared,
            "answer": answer,
            "note": note,
            "created": now(),
        },
    }
    app.graph.put(
        {
            "elements": {identifier: record},
            "joins": [
                {
                    "object_id": prepared["prompt_ref"],
                    "element_id": identifier,
                    "type": "prompt_test",
                    "purpose": "Observe the response to this prompt revision",
                }
            ],
        },
        "test",
        "tests",
    )
    return {"id": identifier, **record["entity_json_obj"]}
