from __future__ import annotations

import importlib
import asyncio
import importlib.resources
import importlib.util
import inspect
import json
import hashlib
import sys
import types
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Command:
    module: str
    name: str
    description: str
    schema: dict
    handler: str
    manifest: dict
    directory: object
    always_available: bool = False
    hidden_when: object = False

    @property
    def key(self):
        return f"{self.module}.{self.name}"


class Registry:
    def __init__(self, app):
        self.app = app

    def discover(self):
        roots = [
            importlib.resources.files("metaform") / "data" / "modules",
            self.app.home / "modules",
            self.app.root / "modules",
        ]
        roots.extend(
            Path(p).expanduser() for p in self.app.config.get("module_paths", [])
        )
        commands = {}
        for root in roots:
            if not root.is_dir():
                continue
            for item in sorted(root.iterdir(), key=lambda p: p.name):
                manifest_path = item / "module.json" if item.is_dir() else item
                if not manifest_path.is_file() or not manifest_path.name.endswith(
                    ".json"
                ):
                    continue
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                for entry in manifest.get("commands", []):
                    command = Command(
                        manifest["id"],
                        entry["name"],
                        entry.get("description", ""),
                        entry.get("inputSchema", {"type": "object", "properties": {}}),
                        entry["handler"],
                        manifest,
                        manifest_path.parent,
                        entry.get("always_available", False),
                        entry.get("hidden_when", False),
                    )
                    if command.key in commands:
                        raise ValueError(
                            f"Duplicate command {command.key}: {manifest_path}"
                        )
                    commands[command.key] = command
        return commands

    def visible(self):
        commands = self.discover()
        mode = self.app.get("mode")
        disabled = set(self.app.get("disabled_commands", []))
        if mode:
            disabled.update(
                key
                for key, c in commands.items()
                if c.module != mode["module"] and not c.always_available
            )
        from .logic import evaluate

        run = self.app.load_run(mode["run_id"]) if mode and mode.get("run_id") else {}
        disabled.update(
            key
            for key, c in commands.items()
            if c.hidden_when and evaluate(c.hidden_when, {"mode": mode, "run": run})
        )
        return {
            key: c
            for key, c in commands.items()
            if key not in disabled or c.always_available
        }

    def portable_manifests(self):
        """Available metadata; closure determines which manifests are dependencies."""
        project_owner = "project:" + self.app.project_id
        result = {"global": {}, project_owner: {}}
        project_modules = (self.app.root / "modules").resolve()
        for command in self.discover().values():
            local = isinstance(command.directory, Path) and command.directory.resolve().is_relative_to(project_modules)
            catalog = result[project_owner if local else "global"]
            catalog["module:" + command.module] = command.manifest
            catalog["command:" + command.key] = {"module": command.module}
        return result

    def portable_dependencies(self, selected=()):
        """Declared resources for selected shared and all project modules."""
        selected = set(selected)
        configured = [Path(p).expanduser().resolve() for p in self.app.config.get("module_paths", [])]
        project_modules = (self.app.root / "modules").resolve()
        builtin = importlib.resources.files("metaform") / "data" / "modules"
        modules, references, unresolved = {}, [], []
        for command in self.discover().values():
            if command.module in modules or str(command.directory) == str(builtin):
                continue
            directory = Path(command.directory).resolve()
            local = directory.is_relative_to(project_modules)
            if not (local or command.module in selected or command.key in selected
                    or any(directory.is_relative_to(p) for p in configured)):
                continue
            declaration = command.manifest.get("portable", {})
            files = []
            for name in declaration.get("files", []):
                path = (directory / name).resolve()
                if path.exists():
                    files.append(str(path))
                else:
                    unresolved.append({"module": command.module, "path": str(path), "reason": "missing_runtime_asset"})
            for ref in declaration.get("knowledge_refs", []):
                reference = {"ref": ref} if isinstance(ref, str) else dict(ref)
                reference.setdefault("kind", "element")
                if not local:
                    reference.setdefault("owner", "global")
                references.append(reference)
            modules[command.module] = {
                "id": command.module, "directory": str(directory),
                "manifest": command.manifest, "files": files,
            }
        return {"modules": list(modules.values()), "knowledge_refs": references, "unresolved": unresolved}

    def load(self, command):
        module_path, function_name = command.handler.split(":", 1)
        if module_path.endswith(".py"):
            directory = Path(command.directory).resolve()
            name = (
                "_metaform_plugin_"
                + hashlib.sha256(str(directory).encode()).hexdigest()
            )
            if name not in sys.modules:
                initializer = directory / "__init__.py"
                if initializer.is_file():
                    spec = importlib.util.spec_from_file_location(
                        name, initializer, submodule_search_locations=[str(directory)]
                    )
                    package = importlib.util.module_from_spec(spec)
                    sys.modules[name] = package
                    try:
                        spec.loader.exec_module(package)
                    except BaseException:
                        sys.modules.pop(name, None)
                        raise
                else:
                    package = types.ModuleType(name)
                    package.__path__ = [str(directory)]
                    package.__package__ = name
                    sys.modules[name] = package
            relative = Path(module_path).with_suffix("")
            parts = list(relative.parts)
            if parts[-1] == "__init__":
                parts.pop()
            module = importlib.import_module(".".join([name, *parts]))
        else:
            module = importlib.import_module(module_path)
        return getattr(module, function_name)

    async def call(self, key, arguments=None, context=None, *, internal=False):
        if key == "abort":
            return self.app.abort()
        commands = (
            self.visible()
            if not internal
            else {
                k: c
                for k, c in self.discover().items()
                if k not in self.app.get("disabled_commands", []) or c.always_available
            }
        )
        if key not in commands:
            raise ValueError(f"Unknown command: {key}")
        command = commands[key]
        arguments = arguments or {}
        self.app.trace("request", {"command": key, "arguments": arguments})
        try:
            result = self.load(command)(self.app, arguments, context)
            if inspect.isawaitable(result):
                result = await result
            await self.after_call()
            self.app.trace("response", {"command": key, "result": result})
            return result
        except Exception as exc:
            import traceback

            self.app.trace(
                "error",
                {
                    "command": key,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                },
            )
            raise

    async def raw(self, argv, context=None):
        mode = self.app.get("mode")
        command = next(
            (c for c in self.discover().values() if c.module == mode["module"]), None
        )
        if not command or not command.manifest.get("raw_handler"):
            raise ValueError("The active module has no raw input handler")
        command.handler = command.manifest["raw_handler"]
        self.app.trace("raw.request", {"module": command.module, "argv": argv})
        result = self.load(command)(self.app, argv, context)
        result = await result if inspect.isawaitable(result) else result
        await self.after_call()
        self.app.trace("raw.response", {"module": command.module, "result": result})
        return result

    def disables_argparse(self):
        mode = self.app.get("mode")
        return bool(
            mode
            and any(
                c.module == mode["module"] and c.manifest.get("disable_argparse")
                for c in self.discover().values()
            )
        )

    async def after_call(self):
        from .packaging import auto_build

        built = await asyncio.to_thread(auto_build, self.app)
        if built:
            self.app.event("package.built", built)
