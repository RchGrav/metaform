# Metaform

**Make the project part of the prompt.**

Metaform prepares reusable understanding of a project so short instructions can
address its actual Elements, relationships, functions, and purposes. It brings
together an editable semantic workbench, a reified knowledge hypergraph, and a
Python CLI/MCP chassis for putting that understanding to work.

This is **Richard Graver's approach to inference amortization**: invest in
understanding up front, retain it in a form agents can use, and give subsequent
reasoning a better place to begin.

The goal is more inference available for design, judgment, problem solving, and
creative work—and less spent repeatedly reconstructing what the project is.

**Private development preview.** We are testing and refining the system and its
semantics before a public release.

The [Metaform specification](docs/SPEC.md) defines the product capabilities,
semantic contract, and acceptance scenarios. Read the
[Inference Metaform primer](docs/primer/README.md) for the full narrative,
a concise introduction, and a technical account of how the approach works.
The [semantic source rules](docs/semantics/README.md) are available alongside it.
The [worked design explanations](docs/semantics/understanding-and-work.md)
preserve Rich's statements about receiving relationships, photograph examination,
and how developed understanding supplies the prompt writer, with the original
photograph examples. [Current work](docs/current-work.md) records implementation status.

[Get started](#get-started) · [Explore the workbench](#a-workbench-for-the-meaning-behind-the-prompt) · [Portable projects](#take-the-work-and-its-understanding-with-you) · [CI and forks](#ci-for-this-repository-and-your-fork)

## A short prompt can carry a lot of intent

An agent working deep inside a problem can lose sight of the surrounding project.
A component's implementation is only part of the picture. Who or what depends
on it? What purpose does its function serve? Which relationships make a local
change consequential somewhere else?

Metaform gives that wider understanding a reusable structure. Names and
descriptions become references into type knowledge. Joins express the
relationships through which Elements serve Operative Purposes. Workflows can
use those references to turn general instructions into work directed at the
project itself.

That opens up a useful kind of prompting:

> Trace the consequences of this refactor through the affected Elements.

> Adapt this workflow so its general terms speak directly to the Elements they concern.

> For each relevant latent Element, generate five purpose imperatives, three
> creative thinking prompts with foresight, and three best practices.

The value comes from what those instructions can resolve against: the project's
structure, independent type knowledge, and their attributed joins. Software
refactoring and porting are natural applications. So are images, documents,
creative exploration, and custom workflows built around other artifacts.

## Two perspectives, with their origins intact

The **Native Expert** examines the actual artifacts, their functions, properties,
and receiving purposes. Types organize that understanding in the Namespace.
An input folder may contain photographs, contracts, a story, resale materials,
software, or several projects. Intake establishes the artifacts and their
relationships, beginning with the exterior receiver's OP and the Defining
Element, then following the artifact's requirements and properties.

The resulting **Native Metaform** is the project's **Inference Metaform**.
Independent latent reasoning can be invoked on its complete functional structure
at any time. The Latent Expert receives the Elements, descriptions, joins, and
OPs while remaining outside the repository's implementation frame.

```mermaid
flowchart TD
    P["Project or artifact"] --> C["Contextual Metaform"]
    C -->|"Complete Native structure, descriptions, and OP relationships"| A["Independent Latent Expert outside the implementation frame"]
    A --> L["Latent Metaform"]
    C -.->|"Structure and provenance references"| S["Shape-similarity layer: 01 / 10 / 11"]
    L -.->|"Structure and provenance references"| S
    C --> W["Prepared prompts and workflows"]
    L --> W
    S --> W
```

The Latent Expert reasons about that actual functional account: it can agree,
disagree, or identify missing relationships. Source provenance remains intact.
The existing similarity layer contains no copied semantic payload: `01` means contextual-only structure,
`10` latent-only structure, and `11` the same nodes and join structure in both.
Different source join contents remain intact and independently observable with
their provenance. Structural agreement does not establish confidence or truth.

Intake performs one Native pass followed by one fresh Latent examination
of the complete Native understanding. `intake.examine` can examine the saved
Native Metaform again. Results remain project-local with their source attribution.
See
[Current work](docs/current-work.md) for implementation and verification limits.

This is type knowledge arranged through semantic relationships. The dotted
namespace is a strict typology: meaningful prefixes express Function or Encounter
Types. The five trunks are `code`, `document`, `media`, `data`, and `exterior`.

The [latest clarification](docs/semantics/artifacts-and-functional-intake.md)
defines **exterior** as not part of the project and **external** as outside the
functionality being examined but still within the repository. Entities can
provide or receive Encounter Functions. The [agreed naming design](docs/semantics/names-receivers-and-variants.md) defines common-name extraction
from the Namespace using `length`. These contracts are documented; the runtime
still uses its existing Name field and intake schemas.

The graph is reified: a join is itself addressable. Relationships can carry
participants, roles, logic, and provenance, and other joins can refer to them.
That makes room for knowledge about how to act as well as what exists.

## A workbench for the meaning behind the prompt

In Metaform, wording is part of the mechanism. An Element's name and description
orient inference. A prompt expresses an operation. Being able to inspect and
refine those words is central to the system.

**Prompts are editable graph nodes.** You can revise the source text, supply
inputs, inspect the prepared instruction, run it through a harness or hand it
to an agent, and keep the actual answer with your review notes. Running
assignments retain the prompt revision they received.

The local Flask workbench brings six views together:

| View | What you can do |
| --- | --- |
| **Graph** | Filter the Contextual, Latent, or Inference Metaform; inspect and edit Element Names, Descriptions, Encounter Functions, notes, aliases, Operative Purposes, and join logic. Source attribution remains visible. |
| **Rules** | Edit the rule's purpose, concise wording, priming context, and accepted/rejected examples with reasons; inspect the saved priming. |
| **Prompts** | Edit stored instructions and their attached rules, inspect prepared input, and keep an agent's response with review notes. |
| **Workflows** | Inspect saved workflow definitions and submit conversions or answers through the current JSON form. |
| **Versions** | Browse checkpoints, inspect changes, extract work, export projects, and open static web variants. |
| **Activity** | See current work, run history, execution events, statistics, and data dumps. |

If a description says little more than its name, you can see it, improve it,
and experiment with the prompt that produces that kind of knowledge. The
workbench gives semantic refinement a concrete place to happen.

A fresh project's intake graph starts empty. Supplied prompts are available in
the prompt editor; example workflows live under `examples/workflows/` and are
imported explicitly. Previously saved records remain available through **All
stored records**. The selected project's name and path appear above every view.

The workflow interface still needs the agreed presentation of a named workflow
and its individual steps. See the [cleanup inventory](docs/workbench-cleanup.md)
for the current scope and the design work awaiting discussion.

## Get started

Requires **Python 3.11+**. From a checkout of this repository:

```sh
uv tool install .
metaform install
```

`metaform install` creates the user-local launcher in `~/.local/bin`. Installed
Ladybug support supplies optional analysis copies of service knowledge; core
operations also work without it. You can install the package with
`python -m pip install .`.

Start the workbench from the project you want to work on:

```sh
cd /path/to/your/project
metaform browse
```

The command prints the viewer URL. Open it in your preferred browser when ready;
Metaform does not launch a browser automatically.

Use **Selected project** in the workbench to switch between open projects and
projects registered with the shared service. **Open project** accepts an existing
folder; relative paths start from the selected project. Refresh the workbench
or return to its browser window to see projects registered by a later intake.
Each project has its own URL, so separate tabs keep their own selection.

New installed projects use one user-local knowledge service per `METAFORM_HOME`.
CLI and MCP startup verify its authenticated health response, reuse the running
instance, or start one. Project execution state stays in `.metaform/state.sqlite3`.
Existing projects keep their legacy graph files until explicitly connected:

```sh
metaform project connect
metaform project list
metaform --project /path/to/project project current
metaform service status
```

`--project` accepts a path or registered project ID; `METAFORM_PROJECT` supplies
the default selector. `project select --project <path-or-id>` changes an MCP
session's selection. Bound assignments retain their project, and workbench tabs
use project-specific URLs. After moving a connected directory, use
`project relocate --path <new-path>`; after copying it, use `project connect --new`
to create a distinct registered owner. `METAFORM_HOME` selects the shared service
and configuration directory. `service stop` stops the verified service instance.

To begin constructing the project's Metaform:

```sh
metaform intake start
metaform drive codex
```

The second command uses a locally installed, authenticated Codex CLI. Custom
harnesses are supported. You can also work through the returned assignments
using `metaform answer @answer.json` and `metaform next`.

The built-in Codex harness uses workspace-write mode with network access for
the local assigned-tool bridge. Metaform's open-ended answer schema is supplied
in the assignment; it is not narrowed to satisfy Codex's strict output-schema
format. An agent reporting blocked intake remains pending for retry.

For an MCP host, configure executable `metaform`, arguments `["mcp"]`, and
`METAFORM_PROJECT` pointing to the project. CLI and MCP use the same command
definitions and handlers. Hosts with suitable sampling support can drive
assignments directly; other hosts receive the assignment and submit its answer.
MCP is optional: it makes Metaform available through an agent's tool interface;
the CLI and web workbench can run without an MCP server.

## Workflows that keep their place

An agent can turn a traditional written process into an executable workflow
using the project's Metaform. The source, prepared prompts, resulting workflow,
and producing run remain connected.

```sh
metaform workflow convert --source "Review the project and revise the Elements that need work."
```

This commissions a builder assignment. The builder performs the inference;
Metaform stores and executes the resulting workflow. The workbench supports
examining and applying the completed conversion. Existing JSON workflows can
also be imported directly; see [the workflow format](docs/workflows.md).

Execution supports prompt steps, conditions, loops, nested calls, parallel
branches, tool steps, and related recursive runs. Workflow control flow is
explicit and persisted. An external orchestrator can dispatch ready branches to
different harnesses.

Delegation passes a stored reference:

```sh
python metaform begin 342765
```

Use the nonce returned by your assignment. The installed equivalent is
`metaform begin 342765`. Metaform writes `.agentid/nonce` in the working folder
and resumes the associated module, assignment, and run. The continuation
retains the exact instructions, inputs, answers, and progress across contexts
and restarts.

The module owns the command surface during its workflow. It can accept raw
input and hide other modules and main switches. `abort` provides the bailout;
commands explicitly marked always available, such as `imagegen`, remain
accessible. Scoped harness commands retain that context across folder changes.

## Take the work and its understanding with you

The agreed [Native variant capability](feature-briefs/native-metaform-variants-specification.md)
builds on retained project understanding and producing prompts. Oversight
examination updates the Native Metaform; a porting variant clones it, changes
a Medium relationship, detaches the affected reasoning, and asks its producing
prompts again in the new context. This is specified development work; executable
project exports described below are already available.

**A Metaform export is an executable project archive.** It carries the work,
its knowledge, and enough state to continue it somewhere else.

```sh
metaform history checkpoint --name "First direction"
metaform package export --path /path/to/exports/metaform
python /path/to/exports/metaform browse
```

The version 2 archive includes the origin, changed files, parent-linked versions,
all selected-project knowledge, and the related global knowledge reached through
that project's and global joins. Workflow attachments and execution dependencies
participate in that selection. Required schemas, prompts, workflows, selected
modules, active workfolders, outputs, and continuation state travel with it.
Another project's private joins do not expand the export.

The archive runs on JSON knowledge and local SQLite execution state without the
service or its database. Contextual and Latent contents, source observations,
and qualified references remain intact. It retains the logical project identity
and gives the working copy a separate `copy_id`. The application code and
portable Python dependencies are bundled; the receiving environment supplies Python.

That makes it possible to move work between your machine, teammates, and
Python-capable AI execution environments, then bring the returned export home.
The portable runtime needs neither a Git executable nor a first-run download.

History can branch from the origin or advance through incremental versions.
Checkpoints record changes without creating commits in your repository. At a
Git repository root, the baseline can be tied to the starting commit; ordinary
folders are supported too. When incoming history includes the local history,
re-import can replace the matching folder. Divergent histories receive a new
suffix so both continuations remain available. Importing an archive creates or
updates a portable working copy; it does not reconcile its edits into the shared
service. That copy can continue work and produce another executable export.

Photos and other changed files are stored as ordinary compressed files, so a
standard ZIP tool can extract them. The workbench can serve static web variants
on separate local URLs for comparison.

| Runtime | Graph and execution capabilities |
| --- | --- |
| **Installed** | Shared SQLite knowledge service, the full MCP SDK, configured harnesses, CLI, and workbench. Optional Ladybug copies support Cypher with explicit refresh and source revision; legacy graph files remain supported. |
| **Portable** | Captured JSON knowledge, local SQLite execution state, CLI, workbench, resumable workflows, and standard-library stdio MCP with a host answer loop. Core operations require no Cypher or service. |

A wheel produced by the release build is also directly executable. You can
rename it `metaform` and run `python metaform browse`. See
[the version guide](docs/next-version.md) for archive identities, import rules,
storage locations, and the capabilities of each runtime.

## A chassis you can make your own

Modules live in `~/.metaform/modules/<module>/` or
`<project>/.metaform/modules/<module>/`. Add a manifest and Python handler, and
its commands become available through both CLI and MCP. Handlers load when
called; modules can include child packages. Start with
[the module example](examples/module/module.json).

Ten starter schema forms cover **Elements, joins, workflows, prompts, rules,
evidence, provenance, learning, reports, and artifacts**. Schemas and layers
are extensible. Prompt text, graph records, and workflow definitions are data
you can inspect, export, and contribute.

The chassis also includes Codex image-generation integration, managed
workfolders, retained outputs, and debug traces of prompts, answers, tool
interactions, and subprocess output visible to the system. Harness configuration
is illustrated in [the example configuration](examples/harness-config.json).

**Metaform can target itself.** Its own code, prompts, workflows, and modules
can become the project under examination. The same tools used to understand
another artifact can help develop the system that prepares that understanding.

## CI for this repository and your fork

The GitHub Actions workflow tests Python **3.11 and 3.13**, builds the wheel and
extensionless `metaform` archive, and checks installed and offline execution.
Both files are available in the completed run's artifacts. Builds run on pushes,
pull requests, and manual requests, including changes to packaged knowledge.

Each fork uses its own checkout and stores its own build artifacts. The workflow
uses a read-only repository token and requires no custom secrets. Repository
visibility governs access to its code and artifacts; our development repository
remains private.

[GitHub disables workflows in new forks by default](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows).
Once your fork contains `.github/workflows/wheel.yml` on its default branch,
you can enable and start its CI from your installed Metaform:

```sh
gh auth login
metaform package ci --repository YOUR_ACCOUNT/metaform
```

The command uses your GitHub CLI authentication to enable Metaform's workflow
and request a build in that repository. It returns the build link. From your
fork's checkout, omit `--repository` to use its `origin` remote. `--ref` selects
another branch or tag; otherwise the fork's default branch is used. The same
operation is available over MCP as `package.ci`.

GitHub must permit Actions for that repository, and the authenticated account
needs permission to enable and dispatch workflows. More details and the manual
activation path are in [the CI guide](docs/ci.md).

To build locally:

```sh
uv sync --frozen
uv run python tools/build_distribution.py
```

Build output is written to `dist/`. While developing Metaform itself, packaged
source/data changes can also trigger automatic wheel rebuilding.

## What we are building toward

The community opportunity is to make useful understanding reusable. A strong
type description, a well-resolved global join, a carefully tuned prompt, or a
workflow that works well can become something other people build on.

As the project develops, contributions can take several forms:

- **Type knowledge and global joins** that bring useful expertise into a project.
- **Prompts and test results** that improve the precision of inference operations.
- **Workflows** for refactoring, porting, analysis, creative work, and other tasks.
- **Modules and schemas** that give Metaform new capabilities.
- **Workbench improvements** that make the knowledge easier to inspect and refine.

The `sync` module exports and pushes reusable global inference data through the
configured Git remote. Global inference keeps its own joins. CI can then
repackage the updated knowledge with the tooling. For now, our focus is private
testing, semantic refinement, and developing examples that demonstrate the
approach clearly.

## Current state

**Version 0.2 is a working development build.** Implementation tests cover
native Ladybug, prompt revisions, parallel handoffs, continuation state, binary
history, and fork CI setup. Additional release checks exercise installed and
offline CLI/MCP, GUI launch, and export/re-import in an empty Python environment.

Live model quality and image generation still need provider testing. Browser
restrictions prevented a full visual acceptance pass during this build.
Inference savings and task-completion improvements are outcomes to measure as
the system is used.

The active semantic sources are preserved in
[`src/metaform/data/semantics`](src/metaform/data/semantics). The maintained
Aliases equations are bundled and supplied to intake. The
[rulebook](docs/rulebook/README.md) supplies editable semantic rule seeds and
priming material to prepared assignments.

For implementation details, see [the version guide](docs/next-version.md),
[architecture and research](docs/architecture.md),
[workflow format](docs/workflows.md), [verification notes](docs/verification.md),
and [source attribution](NOTICE.md).
