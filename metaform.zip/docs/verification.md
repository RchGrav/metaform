# Verification

The [specification's acceptance scenarios](SPEC.md#acceptance-scenarios) define
the semantic demonstrations. Passing implementation tests establish semantic
correctness only where their expectations follow that contract. Tests of
supporting infrastructure and tests encoding superseded assumptions serve
different purposes; the latter need correction alongside the implementation.
The current correction work is tracked in [Current work](current-work.md).

Before the documentation consolidation, the focused command
`.venv/bin/python -m pytest tests/test_core.py tests/test_intake_pipeline.py tests/test_rulebook.py tests/test_execution.py -q`
passed 54 tests. The terminology correction subsequently passed all 9 tests in
`tests/test_rulebook.py`. The existing merged-join test requires copied source
purposes, so its passing result does not demonstrate the specified structural
similarity layer. Fixture answers also do not establish the semantic reasoning
outcomes in A-5 through A-8.

## Native to Latent intake — 2026-09-10

The runtime suite passed **486 tests** after the standalone Native → Latent
engine was established. Coverage includes complete Native graph and schema
handoff, incremental contributions, project-local results, service partition
isolation, saved snapshots, callable examination, provider ownership, and
references between reified joins. Driver, command-harness, and both MCP
protocol modes exercise the two-assignment flow.

Earlier wheel verification with `python -m build --wheel --no-isolation` completed Native and
Latent fixture passes from the wheel itself, then invoked `intake.examine`
through the command registry. The supplied context survived and the artifact
was not promoted into global storage. MCP role delivery uses `systemPrompt`;
installed Codex prompt rendering verified its supported `developer_instructions`
channel precedes task input. Saved prompt snapshots are retained while duplicate
source text is omitted from model input when already present in the intake prompt.

These checks establish runtime behavior and context delivery. No live model
intake was restarted, and they do not establish inference quality or absence of
contextual bias. Existing Name/length migration and other remaining work in
[Current work](current-work.md) are separate from this delivery.

## System review repairs — 2026-09-09

### Workbench project selection follow-up

The final source suite passed **516 tests on Python 3.13.5** (117.54 seconds).
New regressions exercise opening existing folders, tab and graph isolation,
later service registrations, target service homes, existing local storage,
bound assignments, missing folders, and portable copies with shared semantic
owners. Portable preview isolation and selection through multiple archives are
covered. The runtime Name-rule check now targets its preserved earlier source
wording while the agreed replacement remains documented for implementation.

The wheel and standalone archive were rebuilt from the final source. A fresh
wheel installation passed `tools/check_distribution.py`, covering installed and
direct-wheel CLI/MCP, offline GUI/export, and shared-service portable continuation.
Chromium exercised the always-visible selector, invalid paths, relative folder
opening, independent tabs, project switching, registration refresh, and narrow
screen controls without JavaScript errors. The local installation was updated
and its running workbench was checked in Chromium as well.

### Original repair batch

All 21 reproduced [review findings](reviews/2026-09-09-end-to-end-system-review.md)
were repaired and independently rechecked. The complete source suite, run with
each environment's `python -m pytest -q`, passed **501 tests on Python 3.11.6**
and **501 tests on Python 3.13.5** (124.77 and 124.63 seconds respectively).

The regression coverage includes parallel workfolder inheritance and abort
lifecycle, exact assignment binding and delayed MCP answers, repeated foreach
visits, directory replacement, archive symlink boundaries and exclusions,
schema ownership/migration, prepared schema handoffs, reused join identities,
dependency scheduling, qualified similarity, image attribution/readiness, and
viewer crash recovery with live legacy-instance reuse. Abort checks use real
fixture harness processes; viewer checks exercise HTTP endpoints.

Similarity retains exact maximum structural correspondence. The review's
eleven-join divergent fixture now completes in about 0.002 seconds with the same
ten matches, compared with the review's 26–30 seconds. This is a specific
regression result, not a general scaling guarantee. Raw graph, CLI, viewer, and
intake paths use fresh owner-aware knowledge rather than a detached snapshot.

`python tools/build_distribution.py` rebuilt the wheel and standalone archive.
Fresh wheel installations on Python 3.11 and 3.13 both passed
`python tools/check_distribution.py`: installed and direct-wheel CLI/MCP,
offline GUI/export, installed Ladybug/Cypher analysis, and shared-service portable
continuation with the service stopped and original home unavailable.

Provider responses and semantic answers in these regressions are fixtures. The
checks establish the repaired mechanics; no live model or image-provider trial
was performed for this repair batch. The semantic demonstrations identified in
[Current work](current-work.md#build-corrections-remaining) remain outstanding.

## Shared knowledge and portable projects — 2026-09-08

The full source suite passed **396 tests on Python 3.11.6** and **396 tests on
Python 3.13.5**, using each environment's `python -m pytest -q`. Focused
regressions cover owner-qualified references, independent source records,
transactional inference recovery, service startup/reuse and shutdown, project
selection, indexed export closure, captured dependencies and schema refresh.
The closure fixture includes 10,000 unrelated global records and a concurrent
writer. Review findings were repaired and independently rechecked.

`python tools/build_distribution.py` built the wheel and standalone archive.
Fresh installed-wheel environments on Python 3.11 and 3.13 both passed
`python tools/check_distribution.py`: installed and direct-wheel CLI/MCP,
intake completion and reuse, an empty-Python GUI/export round trip, verified
service reuse, and Cypher over a revision-labelled Ladybug copy. The shared
project export excluded unrelated global and other-project relationships, then
continued a nested workflow with `-S`, empty `PATH`/`PYTHONPATH`, the service
stopped and original home unavailable. Re-exporting and reopening retained the
pending request. A regression also proves that two archives with the same file
origin reuse their own working copies without resetting continuation.

A Chromium check opened two service-backed project tabs, changed one tab's
selected project without changing the other, and refreshed a Ladybug analysis
copy. Project/mode display and analysis status were correct, with no JavaScript
errors. This was a desktop check, not a complete accessibility or mobile audit.

Ordinary central graph mutations still reconstruct one owner partition; these
results do not establish large-corpus mutation performance. Live model reasoning
was not part of this feature verification.

## Earlier build checks

The earlier build was checked locally on Linux with Python 3.13.5 and official MCP SDK 2.1.1.
The full suite passed 138 tests with
`uv run --frozen pytest -q --basetemp=.test-tmp/final-verified`.
The rule editor, Metaform filters, and semantic field saves were also exercised
in Chromium, including keyboard operation and the mobile Rules view.

A live Codex intake of the repository's small example module exposed and led
to fixes for strict output-schema rejection, access to the assigned tool bridge,
and blocked answers being treated as completed intake. The native scan and Type proof completed. The first focal latent inference answer
exposed schema-valid optional participant/projection storage failures; after
repair it was replayed successfully. The original answer also contains model
formatting errors, retained for review in [the live trial notes](mvp-review.md).
A second independent focal assignment used the clarified schema, saved four
OP joins with referenced participants and no schema annotations, and displayed
its links in the Latent view. This does not establish semantic quality or
completion of the full latent pass.

## Executed checks

The automated suite exercises the following through real filesystem, SQLite,
subprocess, Git, HTTP, and MCP transports. Agent outputs are labeled fixtures;
they are not presented as model-generated expertise.

- Lazy drop-in module discovery, raw argument preservation, command hiding,
  always-available imagegen, removal, and abort.
- Native intake, individual fresh latent inference assignments, independent global
  joins, matching source-attributed joins, and no native join export.
- Concurrent answer replay, durable pending requests, rule snapshots, conditional
  loops, nested calls, foreach, related recursive runs, and tool steps.
- Graph-backed transition edits changing execution, exact prose imports,
  filesystem prompt binding, graph specialization with retained source, and
  schema annotations that retain the original answer.
- Cycles and n-ary participant traversal, aliases as lookup candidates,
  source-specific join IDs, additional schema forms and arbitrary layers,
  export/import retention, packaged custom schemas, and integrity cleanup.
- A real harness process using the scoped actor bridge to read project evidence;
  its separate Latent Expert process querying global records without local joins.
- Abort terminating an active harness; fresh workfolder cleanup and trace capture.
- Non-Git development copies, text and binary diffs, conflict checks, application
  back to the original ordinary directory, and cleanup.
- Global export and a real Git merge/push against a local bare remote, excluding
  native joins and unrelated source-code commits; later bundle updates loading
  once without resetting global contributions on each new project.
- Flask endpoints plus managed viewer startup/shutdown while the router remains
  responsive; imagegen dry-run integration without generating an image.
- Rules and prompt attachments edited through the GUI retain exact wording and
  existing fields. Graph perspectives retain reified participant closure;
  semantic editors preserve structured EF, OP, and join-logic values.
- Optional pairwise join projections and participant roles preserved through
  SQLite, JSON, Ladybug, intake ownership, completion, reuse, and viewer output.
- Exact semantic equation source and revision supplied to conversion and
  specialization without overwriting authored prompt text.
- Official SDK clients using both the 2025-11-25 and 2026-07-28 paths, sampling
  tool calls that read project evidence, blind global assignments, and debug mode.
- A separately installed wheel: installed CLI, installed stdio MCP, direct-wheel
  CLI, and direct-wheel stdio MCP outside the source checkout.

Reproduce with:

```sh
uv sync --frozen
uv run --frozen pytest -q
uv run --frozen python -m build --wheel --no-isolation
uv venv /tmp/metaform-wheel-check
uv pip install --python /tmp/metaform-wheel-check/bin/python dist/*.whl
/tmp/metaform-wheel-check/bin/python tools/check_distribution.py
```

The GitHub workflow runs the tests and wheel checks on Python 3.11 and 3.13 and
uploads the wheel, including for data-only updates. Its configuration is supplied;
local verification alone does not establish a GitHub Actions result.

## Not established by these checks

- The automated suite does not run live model or image generation. Provider capability probing,
  authored prompt construction, routing, and fixture execution are implemented.
  The bounded live handoff comparison is recorded in [current work](current-work.md);
  it does not establish general model reliability or the remaining semantic outcomes.
- The maintained Aliases section is now bundled and supplied verbatim, with
  configured source overrides retained. Its delivery is tested; model application
  of the equations still requires a live inference trial.
- No claim is made that a host obeys `includeContext: none`, that a subprocess is
  an OS sandbox, or that fixture agents prove independent latent reasoning.
- No empirical claim is made about saved inference, reduced omissions, automatic
  porting quality, or the semantic correctness of a generated metaform.
- Arbitrary external side effects cannot be guaranteed exactly once across a
  crash between the side effect and durable result recording.
- Distributed multi-host workers, production deployment of the viewer, and live
  package-index publication are not implemented or implied by the local chassis.
