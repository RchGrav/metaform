# Executable workflow format

This document describes the current execution API. [SPEC](SPEC.md) defines
intended operation and specialization behavior; [current work](current-work.md)
tracks outstanding alignment and semantic demonstrations.

A workflow has an `id`, optional `intent` and `start`, and ordered `steps`.
Import creates an Element Table record for the procedure and each step, plus
membership and transition joins. The engine reconstructs its definition from
those records. Editing a transition join changes subsequent runs. Each frame
snapshots its steps and referenced rule expressions when it starts.

```json
{
  "id": "example.review",
  "steps": [
    {
      "id": "review",
      "prompt": "Review {{ inputs.element }} against its Operative Purposes.",
      "focal": "{{ inputs.element }}",
      "depth": 2,
      "schema": {
        "type": "object",
        "properties": {"revise": {"type": "boolean"}, "work": {"type": "string"}}
      },
      "transitions": [
        {"when": {"var": "steps.review.revise"}, "to": "revise"},
        {"to": "record"}
      ]
    },
    {"id": "revise", "prompt": "Perform: {{ steps.review.work }}", "next": "review"},
    {"id": "record", "prompt": "Record the completed work.", "next": null}
  ]
}
```

The sample specifies no extra quality rubric or frozen properties. Its condition
is an authored control-flow decision. There is no hidden round, recursion, or
graph-layer limit. `drive --steps` in the structured interface, or raw
`drive HARNESS STEPS`, gives an explicit execution budget. Hosts can also impose
their own protocol limits; the pending assignment remains durable if they stop.

| Step kind | Additional fields | Execution |
| --- | --- | --- |
| `prompt` (default) | `prompt`, optional `schema`, `focal`, `inputs`, `save_as` | Yield an assignment and wait for its answer |
| `branch` | `transitions` | Evaluate conditions and advance one structural step |
| `foreach` | `items`, `prompt` | Snapshot items, assign each one, retain ordered answers |
| `call` | `workflow`, `inputs` | Push a child workflow frame and return its result |
| `tool` | `tool`, `arguments` | Invoke the named chassis command and record its result |

`next: null` finishes a frame. Without transitions or `next`, execution continues
to the next ordered step. Transitions are evaluated in order; their `to` can be
null. A transition can reference `rule: "data.some_rule"`, whose record contains
`{"expression": ...}`. A top-level recursive run, created by `workflow.recurse`,
records its parent and carries the parent's saved values plus explicit inputs.

The expression environment includes `inputs`, `steps`, saved values, and during
foreach, `item` and `index`. `{ "var": "steps.review.revise" }` reads a value;
`{ "literal": value }` passes data without interpreting it as an expression.
Other supported operators: `and`, `or`, `if`, `==`, `===`, `!=`, `<`, `<=`, `>`,
`>=`, `+`, `-`, `*`, `/`, `%`, `!`, `in`, `cat`, and `count`. This is a small
Python-semantics expression language inspired by JsonLogic, not a compatible
implementation of all JsonLogic operators/coercions. Unknown condition operators
raise an execution error. There is no Python `eval` or implicit code execution.

Jinja expressions bind declared values in prompt text. A `file:relative/path`
prompt resolves relative to the imported workflow file. Plain-text imports retain
their source text. An inline prompt without a `prompt_ref` creates a prompt record
for that workflow step. An existing `prompt_ref` selects the referenced prompt
text at execution, including when inline text is also present. Imported prose is
not automatically parsed into a guessed branch structure.

Applying a specialization preserves revised inline wording when a step retains
its source `prompt_ref`: the revised text receives a specialization-local prompt
record. Embedded declarations that reuse source prompt IDs also receive local
IDs, with specialized step references updated together. Source prompts retain
their wording, and authored control flow remains in the specialized definition.

Prompt records and steps can attach semantic rules through `rule_codes`. The
selected rules use `metaform:semantic-rule`, with `rule_code`, `purpose`,
`concise`, and `priming`; they are distinct from the executable `metaform:rule`
conditions above. Prepared assignments carry the exact selected rule content
and revisions, with full priming for each assignment. A running workflow frame
retains its rule snapshots. Explicit concise-only rule preparation is available
for a context that has already received the priming.

The initial rule content and the status of its explanations and examples are
documented in [rule seed sources](rulebook/seed-sources.md). Editing stored
wording does not establish a new semantic agreement.

Optional `output` stores an answer as graph data:

```json
{
  "id": "data.learning.{{ item.id }}",
  "schema": "metaform:learning",
  "layer": "my_learning_layer",
  "subject": "{{ item.id }}"
}
```

An optional `tools` array controls the tools offered to the step's sampled or
subprocess agent. Default workflow tools browse the graph and read the working
copy. Operational information, selected graph data, schema, and prompt remain
separate fields in an assignment. `context: "fresh"` requests a separate empty
workfolder for an external harness; the intake Latent Expert always uses one.
Actor gateways and sampled tool calls bind the exact issued request ID as well
as the run. Tool calls and `continuation.current` retain that assignment even
when sibling assignments are active; caller-supplied IDs cannot select a
sibling's context. A completed binding remains bound to that completed request.
The coordinator retrieves subsequent work outside the binding with the run ID
and begins the newly issued nonce in its agent folder. Sampling requests
`includeContext: none`; this describes the
request to the host, not a guarantee about an external model's prior context.

Intake performs one Native assignment
followed by one fresh Latent examination. Native records actual artifact
understanding through Elements, receiving-purpose joins, and contextual
descriptions. Incremental contributions and the final answer are saved before
the complete Native snapshot is issued as `inputs.native`; `inputs.schemas`
retains the applicable schema definitions and their descriptions.

The latent orientation is snapshotted separately as `system_prompt`, with its
revision, before the specific task and Native material. MCP maps it to
`systemPrompt`; Codex maps it to `developer_instructions`. Each uses a fresh
assignment with no project file-reading tools. `intake.get` returns an Element
and its relationships, and `intake.search` examines the supplied Native snapshot
and the current Latent contributions. Later project edits do not rewrite an
issued assignment's context.

`intake.examine` starts a fresh examination of saved Native understanding.
`intake.batch` returns the single pending assignment;
`intake.drive` executes Native and Latent sequentially. Latent results remain
in the project's `archaeology` perspective. The existing source attribution
and structural similarity representation remain in use.

The knowledge service separately retains direct global inference operations.
`inference.read` returns `id`, `inference_complete`, `status`, and `graph` for a
selected global structure. Incomplete inference returns no graph; a completion
marker without a snapshot reports `unresolved_structure`. Retrieval preserves
exact reference owners and kinds. Non-global and missing references remain
reported while captured joins retain their contents. Global Element lookup uses
current records, then the completion snapshot, then captured archive dependencies.

In service mode, `inference.commit` atomically checks completion, writes eligible
global knowledge and its completion observation, retains the project's Latent
copy, and records a project-scoped request receipt. The first completed graph
is retained and late commits reuse it. Contributions and promotion also preserve
their existing checks inside service transactions. Stable request IDs recover a
committed result after a lost response.

Intake durably records its local transition and cleanup target before removing an
assignment's workfolder. A repeated answer can finish retained cleanup after a
local save failure. Portable JSON retains its separate-file crash boundary.

Run transitions are serialized across processes. Replayed answer IDs return the
same receipt; repeated `next` calls return the same pending assignment. Assignment
execution is locked and completed execution results are cached before submission.
A process crash between an external side effect and its durable result can still
require reconciliation; arbitrary external tools are not promised exactly-once
execution. Debug events and workfolder diffs provide the evidence for recovery.

Project selection belongs to the client context, not the workflow definition.
A CLI `--project` selector, an MCP session selection, and a workbench tab each
identify their App; issued assignments and in-flight requests keep their captured
project. Workflow definitions and step/rule references can resolve through project
and global knowledge. Imported workflow and step attachments become ordinary
`workflow_attachment` joins, so they also participate in selected export.
Prepared prompt assembly keeps owner-labelled source graphs and structural
similarity separate, honoring its requested depth and source.

An executable version 2 archive carries selected workflow definitions, prompts,
schemas, rule revisions, nested workflow dependencies, assignments, and required
assets with JSON knowledge and restored local SQLite state. It preserves the
logical project owner with a separate portable copy identity, and continues
through the same answer/next/export operations without service or Cypher access.
Returning that archive uses portable history import; it does not reconcile
changes into a registered service owner.
