# Architecture and research

Research checked on 2026-09-05. These are implementation choices, not claims of
an empirically best orchestration system.

[SPEC](SPEC.md) defines intended semantic behavior. This document describes the
current chassis; [current work](current-work.md) tracks outstanding alignment.

## Shared chassis

JSON manifests describe commands independently of Python imports. The CLI builds
argparse entries from their input schemas. MCP exposes the same registry.
Takeover and command disabling operate at dispatch; raw input is delivered to
the owning module without main-parser interpretation. An always-available
command survives takeover. `abort` is intrinsic to the chassis.

Runtime state remains in project-local SQLite at `.metaform/state.sqlite3`.
Per-run file locks serialize transitions across CLI and server processes; local
transactions retain answers, run stacks, events, and workfolder identities.
Knowledge operations have a separate interface: `BoundGraph` adapts existing
per-owner methods, while `RemoteKnowledge` and `LocalKnowledge` dispatch the same
graph, schema, assembly, and inference operations.

New installed projects register with one user-local service per resolved
`METAFORM_HOME`. Its central database is `service/knowledge.sqlite3`. Legacy
projects continue using their configured SQLite, JSON, or Ladybug files until
`project connect` explicitly adopts them. Adoption preserves original files,
imports source records without generating replacement observations, reports
competing content, and publishes the service marker after transaction commit and
source verification. Global imports are tracked by source home and digest.
Portable mode selects local JSON before service discovery or ambient seeding.

The service uses authenticated loopback HTTP. Startup requires a fresh challenge
response matching the service, instance, and protocol identities and readiness;
endpoint files, PID values, and open ports alone are insufficient. OS-backed
startup and lifetime locks serialize discovery and ownership. `service status`
probes actual liveness; `service stop` addresses the verified instance. The service
owns knowledge and performs no model work.

A registered project UUID is separate from its canonical path and history ID.
`--project` accepts a path or registered ID; assignment binding takes precedence
over invocation selection. `project select` replaces an MCP session's selected
App for subsequent calls, while in-flight requests keep their captured App.
Workbench URLs identify projects so tabs remain independent. Moves use
`project relocate`; explicit `project connect --new` creates a new owner, copies
the registered source partition, and translates structured self-owner references.
Execution state stays with each project directory.

## MCP workflow orchestration

The implementation uses the official Python SDK 2.1 line. It supports the older
session protocol and the 2026-07-28 protocol, whose requests can return
`InputRequiredResult` and resume with input responses. This avoids trying to
make the server initiate unsupported modern sampling requests.
[Python SDK](https://github.com/modelcontextprotocol/python-sdk),
[sampling specification](https://modelcontextprotocol.io/specification/2026-07-28/client/sampling).

The modern tools specification disallows changing a tool catalog as a side effect
of another request. Consequently the modern server exposes a stable `metaform`
router, `abort`, and always-available tools. Available module commands are data
returned by the router. Older clients receive individual tools and list-change
notifications. This preserves the requested mode semantics across both protocols.
[Modern tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools),
[2025-11-25 tools](https://modelcontextprotocol.io/specification/2025-11-25/server/tools).

Sampling can itself call scoped tools, receive their results, and continue before
answering an assignment. A server-held continuation retains the same request ID
and explicit message history. The local intake agent can read repository files;
the Latent Expert receives the full Native account and search/get/put tools
for that examination, without project file reads.
The host-answer loop remains available when client sampling is unavailable.
Durability is application-owned, rather than tied to experimental task APIs;
tasks changed to an extension in the modern protocol.
[Protocol changes](https://modelcontextprotocol.io/specification/2026-07-28/changelog).

The modern protocol returns independently keyed requests in one
`InputRequiredResult`; completed answers remain retained while unfinished jobs
continue their own tool exchanges. The older protocol uses concurrent sampling
calls. Actor gateways and MCP tool calls bind the exact issued request ID, and
`continuation.current` resolves that assignment rather than a sibling request.

## Reified graph and executable logic

Elements retain the ET fields: `entity_desc`, `entity_schema`, `entity_json_obj`,
keyed in the shared store by `(owner, id)`. Owners are `global` or
`project:<uuid>`; semantic source and physical location are separate axes. Joins
have identities, endpoints, scope, and an arbitrary list of
role-bearing participants. This implements n-ary relations whose purposes,
conditions, and attribution can be addressed directly. Relations can participate
in further relations. It does not reduce every association to an unannotated
pair of nodes. W3C's n-ary pattern is useful here; ordinary RDF statement
reification and an n-ary domain relation are distinct concepts.
[W3C n-ary relations](https://www.w3.org/TR/swbp-n-aryRelations/).

Workflow membership and transitions are graph relations. A condition may refer
to a rule Element and that Element's serialized expression. The executable
snapshot is reconstructed from this graph, so graph logic is operational rather
than a decorative copy of code. The evaluator is deliberately small and explicit;
new operators can be implemented as code while workflow instances remain data.
[JsonLogic](https://jsonlogic.com/),
[SQLite JSON support](https://sqlite.org/json1.html).

References retain their authored strings. Optional `participants[].owner` and
endpoint `reference_owners` make cross-owner references precise. Unqualified
project references resolve locally, then globally; global references resolve in
global knowledge. Equal IDs in different owners remain independently addressable.
Element-address incidence can discover both selected-project and global joins;
references to joins compare qualified join identities. Endpoints remain relevant
even when a join also supplies participants.

Cycle-safe traversal follows endpoints, participants, and reified joins. Runtime
assembly retains owner partitions and honors caller depth, category, and source.
`knowledge.snapshot` follows the complete selected-project closure in one SQLite
read transaction, using owner/reference indexes rather than exporting the entire
global graph first. Other projects' private joins do not expand it; explicit
references outside the selected owners and missing bodies remain reported.
Current source relationships expand closure, while exact historical completion
bodies and their dependencies remain evidence. Similarity does not expand the
source traversal. Indexed selection has dedicated scale and concurrent-writer
checks. Ordinary central graph mutations currently reconstruct and replace one
owner partition inside their transaction; that remains a practical scale limit.

Source observations retain object contributions. Scoped retrieval, search,
assembly, and export use the selected source's latest record. Native and
Latent Expert joins have separate source identities even when their authored IDs
coincide. Structural similarity compares node identities, join types, participant
roles, and references, including references to joins. Its `01`, `10`, and `11`
records contain structure and source references; semantic contents stay in the
Contextual and Latent graphs. `graph.similarity` computes this view and the
completion path persists it under `merged`. The viewer exposes each source and
the read-only similarity view separately. The implementation does not claim
full PROV-O conformance.
[W3C PROV-O](https://www.w3.org/TR/prov-o/).

## Semantics and data movement

The graph does not impose an external taxonomy or normalize namespace semantics.
Element names and roles are authored through inference. Literal source statements
remain available separately from runtime controls. The [SPEC](SPEC.md) defines
the semantic contract, including preservation of established terms.
The active rulebook is seeded as `metaform:semantic-rule` records. Prompt and
step `rule_codes` select exact rule content and revisions for assignments;
workflow frames retain their snapshots. These records are distinct from
executable `metaform:rule` condition expressions. The maintained Aliases section
is bundled verbatim, with an explicit configured source override supported.
See [rule seed provenance](rulebook/seed-sources.md) for the distinction between
established source wording and assistant-authored priming explanations.

Intake performs one Native assignment
followed by one fresh Latent examination. Native records actual artifact
understanding through Elements, receiving-purpose joins, and contextual
descriptions. Incremental contributions and the final answer are saved before
the complete Native snapshot is issued as `inputs.native`; `inputs.schemas`
retains the applicable schema definitions and their descriptions.

The latent orientation is snapshotted separately as `system_prompt`, with its
revision, before the specific task and Native material. MCP maps it to
`systemPrompt`; Codex maps it to `developer_instructions`. Each uses a fresh
assignment with no project file-reading tools. `intake.get` returns an Element
and its relationships, and `intake.search` examines the supplied Native snapshot
and the current Latent contributions. Later project edits do not rewrite an
issued assignment's context.

`intake.examine` starts a fresh examination of saved Native understanding.
`intake.batch` returns the single pending assignment;
`intake.drive` executes Native and Latent sequentially. Latent results remain
in the project's `archaeology` perspective. The existing source attribution
and structural similarity representation remain in use.

### Direct global knowledge operations

The implementation retains the focal authored structure in completion
provenance and records each join's `inference_type` and `authored_id`, with
namespaced stored IDs for concurrent contributions. Reuse follows this ownership
rather than importing every record reachable by undirected traversal. For
example, A depending on B does not make A part of B's dependency graph.
The knowledge service's `inference.read` operation retrieves a selected completed
global structure. These direct store operations are separate from the project
intake flow.

The `inference.read` result contains `id`, `inference_complete`, `status`, and `graph`.
Its completed graph holds focal-authored joins and explicitly named or referenced
Type members resolved from current global records, then captured completion
records, then retained archive dependencies. Incomplete results have no graph;
legacy completion markers without a stored snapshot report
`unresolved_structure`. The snapshot is on the completion observation, preserving
the authored Element record. `inference.commit` performs the completed check,
global contribution and completion observation, project Latent write, and durable
receipt in one central SQLite transaction. `inference.contribute` and promotion
also keep their existing checks and writes within that boundary. Receipts are
keyed by project context and request ID; reusing an ID with different arguments
reports a conflict. Retrying a committed request returns its original result,
allowing the caller to recover a committed result after a lost response.

Concurrent global inference commits retain the first completed graph and reuse
it for later commits. Portable knowledge uses local locking; its separate JSON
files retain their local crash boundary.

Project archives use `metaform-export/2`. They carry the selected closure, source
observations, owner-qualified schemas, historical dependency material, selected
executable assets, and project-bound execution/assignment state. The exported
logical project UUID is preserved; a separate `copy_id` identifies the portable
working copy. JSON graph records and restored local SQLite execution state support
continued prompt/workflow operations and another export without the service,
Cypher, or unrelated packaged global inference. Imports accept versions 1 and 2
and retain inclusive-history replacement and divergent-history sibling behavior.
They create portable copies, not shared-service reconciliation.

Installed Ladybug stores are optional analysis copies. `graph backend --name
ladybug` refreshes the selected project's and global copies; `graph cypher`
queries them and reports their source revision and refresh time. Service writes
do not silently refresh those copies, and Cypher edits do not mutate operational
knowledge. The shared service and portable runtime remain usable without Cypher.

The separate `sync export` operation produces one JSON file per global object
or join, plus observations and an
index containing a content hash. Wheels load an updated indexed bundle once per
shared installation; a later project using the same unchanged bundle does not
reset local global contributions. Changed packaged versions update canonical
records while retaining prior observations. Native joins are never part of this
export path. Sync contributes only data from an isolated worktree based on shared
history; it does not push unrelated development commits. Git merges surface
conflicting edits for resolution.

## Distribution, interface, and remaining evidence

Git diff works on chassis-created repositories even when the original project
is an ordinary directory. Completed development copies remain available for
review and explicit application. Fresh latent inference copies are cleaned after
their assignment. File locks coordinate same-host execution and builds.
[Filelock](https://py-filelock.readthedocs.io/).

Flask provides the local inspection UI in a separate process. A production
deployment can use its WSGI application factory with a suitable WSGI server.
[Flask deployment](https://flask.palletsprojects.com/en/stable/deploying/).

CI tests, builds, and uploads wheels, including graph-data-only commits. It has
no automatic PyPI publishing or PR-merging step.
[GitHub Python workflows](https://docs.github.com/actions/guides/building-and-testing-python),
[PyPA packaging guidance](https://packaging.python.org/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/).

Working control flow is not proof of semantic correctness. Current tests exercise
fixture agents through real processes and MCP clients. Comparative measurements
of token use, inference quality, omission rate, refactoring success, and model
context isolation remain future evaluations. The Aliases source is bundled;
live model/image-provider authentication remains necessary for provider runs.
