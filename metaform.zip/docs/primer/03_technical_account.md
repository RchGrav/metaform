# Inference Metaform
## Technical account: semantic construction, propagation, identity, and inference reuse

### 1. Semantic basis and inferential role

The Inference Metaform represents previously performed semantic inference for use by subsequent operations. The reusable result is not limited to retrieved facts, summaries, or completed task answers. It includes inferred type understanding, dependency meaning, Encounter consequences, receiving relationships, purposes, and their implications across relevant perspectives.

The technical claim is that task execution can begin from this developed understanding. Reducing reconstruction of those prerequisites reserves more effective inferential depth for reasoning about consequences, alternative realizations, and higher-order changes. This is a causal claim about the arrangement and reuse of inference, not a numerical resource equation or a modification of the model's physical architecture.

Elements, type relations, joins, perspectives, and identity relations have literal semantic meanings and mathematical definitions. Graph storage, namespace strings, and natural-language prompts are representations and mechanisms operating through those meanings. Definitions not provided in the supplied material remain unspecified in this account.

### 2. Native construction and independent latent reasoning

The Native Expert examines the actual material or plan to establish the artifacts under analysis. The input can contain software, photographs, contracts, stories, resale assets, or several distinct projects. A folder is contextual evidence, not an assumption of one coherent software artifact.

For each artifact, the Native Expert starts with the exterior receiver's OP and identifies the Defining Element. Its Encounter Function summarizes the combined result the artifact provides. Its identity excludes medium, encoding, genre, and style. The expert recursively names actual properties and hard requirements, joining the Encounter Functions that satisfy each receiving Element's OPs. Exterior means not part of the project. External means external to the functionality being examined but still in the repository. Control or ownership does not define exterior; exterior entities can provide or receive.

The resulting Native, or Contextual, Metaform is the project's Inference Metaform. It represents actual artifacts, functions, receiving purposes, and their relationships. Types classify and organize this understanding in the Namespace; they do not replace project-specific meaning with generic Type descriptions. Global reuse is separate from the primary intake operation.

Latent inference can be called on the complete Native Metaform at any time. The Latent Expert receives everything Native built, including its Elements, descriptions, joins, and OPs. It remains blind to repository implementation details and reasons from outside that implementation frame. Knowing the artifact's functional explanation supplies the context needed to agree with it, question relationships, and infer omissions; independence does not require withholding that explanation.

Native and latent reasoning retain their independent provenance. This handoff correction does not settle whether latent output is a complete graph or a delta. Where contextual and latent graphs are represented, their source contents remain independently observable; the following structural meanings remain applicable without prescribing a new output representation.

### 3. Provenance semantics

A separate shape-similarity layer shows structural agreement and divergence between the two graphs. It contains no copied semantic payload from either source graph; it records only structural correspondence and provenance references. Shape membership is:

| Contextual structural presence | Latent structural presence | Representation |
|---|---|---|
| Present | Absent | `01` |
| Absent | Present | `10` |
| Present | Present | `11` |

When both source graphs contain the same nodes and a join between them, the similarity layer can represent that structural agreement as `11`. If the source join contents differ, both source joins remain intact in their respective graphs and retain their own provenance; the similarity layer does not collapse, copy, or reconcile their contents.

These values do not encode confidence, correctness, precedence, or semantic reconciliation. Matching lexical strings is not the definition of Type identity. This account does not supply a new correspondence algorithm.

### 4. Type structure, lexicalization, and operative characteristics

A Type classifies and organizes the Element under examination. Its Native description records the actual artifact or function and the specific receiving purposes it serves. In the established example, each of the following has type meaning:

```text
code
code.utility
code.utility.disk
```

The path is therefore part of inference, not merely a storage address. Concise names and descriptions are lexical handles for semantic Elements. Natural-language instructions can lexicalize an operation through that structure without becoming the primary definition of its meaning.

Function denotes operative capability. Encounter denotes the form through which something is expressed, experienced, or encountered. A mixed-language project represents language Encounters where they occur rather than replacing the functional type with a language-suffixed path.

The dotted namespace is a strict typology: every prefix must itself express a valid Function or Encounter type. Encoding alone does not qualify as a type; an encoding name may appear where the path is actually expressing a Function, such as an encoder. Thus `document.html` fails when HTML is used only as document encoding, while `code.html` can qualify as a language Encounter and `code.encoder.jpg` can qualify as an encoding Function.

A Type's Parametric array acknowledges its tunables and reserves their names against being minted as Namespace Elements. Adjusting a tunable does not, by itself, constitute acceptance. Notable is retired as a separate rubric: an OP and its relationships already make the Element's relevance explicit.

For photographs, visible subjects and surroundings, related images in the camera's sequence, and folder context contribute to understanding. A couple can be the Defining Element of a photo with the Eiffel Tower serving as a Supportive Element; scenery can also have a salient subject. Descriptions differentiate the actual images. Whether media is a standalone artifact or an asset serving another artifact is determined contextually.

### 5. Encounter propagation and perspectival resolution

With `code.c` joined at `code.utility.disk`, the supplied backward propagation is:

```text
code.utility.disk → code.utility → code
```

This is backward visibility through functional type ancestry: the Encounter is available when reasoning at broader ancestor types. Forward application conditions inference from the attachment point through the functional descendants of that branch. Backward visibility does not cause an Encounter to fan back down unrelated sibling branches.

The operation is not equivalent to annotating the attachment point with language advice. Its consequences can affect realization of functions, data representations, interfaces, dependencies, memory semantics, error behavior, and operating-system interactions. Those consequences can then be examined through other perspectives represented in the graph.

Every part of the Metaform can potentially resolve knowledge from any relevant represented perspective. No fixed traversal order through the principal perspectives is implied by this statement.

The perspectival dimensions and propagation concern semantic operations with intended literal mathematical definitions. The supplied account establishes the roles, their interaction, and the propagation direction. It does not specify numerical coordinates or a vector-space algebra for these inference orientations, so no such formalization is assigned here.

### 6. Tripartite relation and semantic identity

For a Type `T`, the formal identity is the exact set:

`C(T) = {(rᵢ ∧ pᵢ ∧ e)}`

Each conjunction binds a Receiving Entity `rᵢ`, its Operative Purpose `pᵢ`, and the Type's single Encounter Function `e`.

Encounter Function supplies the how, Receiving Entity the who or what, and Operative Purpose the why. The conjunction is relational: the function is interpreted according to its receiver and the purpose of that relationship at the selected resolution.

Receiving entities can themselves participate in further receiving relationships. Each relationship can have its own Operative Purpose. This recursive structure preserves intermediate meanings rather than substituting one ultimate purpose for all local relations.

`C(T)` is exact as a semantic definition. It is not a lower bound, partial signature, similarity measure, confidence score, or candidate identity projection. A Type has one Encounter Function at the represented resolution. A materially different Encounter makes a different Type or variant, represented through a further typological distinction rather than by adding a second EF to the same Type.

The intended mutation/transformation distinction uses semantic identity. Mutation changes the realization while retaining its identity-defining relation. Transformation changes that identity. The invariant therefore need not be preserved artifact content: substantial restructuring or a different implementation Encounter need not require a frozen implementation core.

The identity definition is semantic guidance for reasoning about the Type; it does not itself prescribe an approval gate, lifecycle, or runtime check.

### 7. Knowledge graph of knowledge graphs

The semantic representation is a knowledge graph of knowledge graphs with reified knowledge hypergraph semantics. Relations are available as subjects of inference, not only as links between subjects.

A dependency's meaning can include the dependent function, the required capability, the purpose satisfied, a receiving role, conditions, evidence, procedures, and other meaningful participants. Reducing this to pairwise adjacency can omit precisely the information needed to distinguish alternative realizations.

Contextual and latent forms retain their own relationships within this representation. Other represented perspectives can be brought to bear on either view and on their agreement or divergence. The significance of the structure is its ability to make prior semantic inference available beyond the local working fragment while supporting further inference through that meaning.

Schema-backed layers can represent further inferred understanding. The proposed `refactor_planning` layer is an exploratory example of that possibility, not an established mandatory layer or a supplied schema definition.

### 8. Prompts as operations through represented semantics

A prompt specifies an inference operation through the available semantic structure. The Metaform supplies previously inferred meaning; the prompt directs the current work. Each can be reused independently.

The user-supplied refactoring example compares a plan's shape with the Metaform, examines where the refactoring becomes difficult to follow, and considers representing that planning through `refactor_planning`. The user-supplied porting example links `code.langA` and `code.langB` and examines functions node by node to derive considerations and imperatives. Both remain untested exploratory possibilities.

Their significance is structural engagement. The refactoring prompt examines a proposed realization against represented meaning. The porting prompt engages two Encounters through the ancestry-and-forward-inference mechanism. Neither defines a universal workflow or a closed operator list.

Refactoring can therefore examine alternatives to present organization without equating that organization with type identity. Porting can preserve semantic function and receiving-purpose relationships while deriving a destination realization through another Encounter. The previously performed inference supplies meaning from which to evaluate those alternatives.

### 9. Effective inferential depth and local narrowing

Without reusable preparation, a task may require reconstructing semantic prerequisites and solving the requested problem within the same attempt. With the Metaform, some prerequisites have already been inferred and represented. Subsequent inference can reason from them to further consequences rather than starting again with raw project material.

This advances the starting point of task reasoning. It also changes what comparisons are available: whether a dependency is intrinsic to a function, whether a difficulty belongs to the current realization, or whether an alternative Encounter could realize the same receiving-purpose relationship differently.

The mechanism combines two effects. Contextual and latent construction supplies differently oriented understanding, including divergences that can expose local bias. Amortization reuses the inference that developed this understanding. Graph-wide relationships keep local work examinable through the larger semantic structure. None of these effects is adequately described as merely shortening a prompt.

Related research shows that earlier subproblem solutions can support later reasoning and that reasoning structures can be prepared for subsequent task use.[1][2] Those findings support the general plausibility of prior inferential preparation, not the effectiveness of this particular system.

Later work still performs inference through the represented understanding. Effective depth refers to reduced prerequisite reconstruction and a more developed basis for higher-order work, rather than a specified number of physical neural layers.

### 10. Formal and empirical status

The semantic contract establishes exact conjunction-set Type identity, one Encounter Function per Type, structural presence in the shape-similarity layer, independent provenance for Native and latent reasoning, and branch-scoped Encounter propagation. These semantic definitions do not prescribe runtime identity checking or a correspondence algorithm.

The development conversation provides an early proof of behavior: the agent engaged the prepared perspectives through different instructions and produced specific analysis and imperatives. It does not establish quantified inference savings or elimination of hallucination.

The architectural claim remains precise: **upfront semantic inference is represented for reuse; the retained contextual and latent orientations support reasoning beyond project-local framing; and subsequent operations can devote more of their effective depth to higher-order work because some necessary understanding has already been developed.**

---

## Research references

These references support the limited external comparison in Section 9. The system semantics are supplied definitions, not deductions from these papers.

[1] Denny Zhou et al. *Least-to-Most Prompting Enables Complex Reasoning in Large Language Models*. ICLR, 2023. arXiv:2205.10625.

[2] Pei Zhou et al. *Self-Discover: Large Language Models Self-Compose Reasoning Structures*. arXiv:2402.03620, 2024.
