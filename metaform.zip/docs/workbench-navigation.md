# Navigating the Native Metaform

The workbench uses Cytoscape.js with directed Dagre layouts for functional
paths and concentric layouts for larger local neighborhoods. Both libraries
are bundled locally for standalone operation. The Namespace organizes Types; opening
a Type reveals the actual project Elements classified by it and their
receiving-purpose relationships. Opening an actual Element follows its own
relationships. Separate Elements remain separate even when they share a Type.

| Action | Control |
| --- | --- |
| Open the immediate connections of a Type or actual Element | Click its node, or focus it and press Enter |
| Inspect an Element and all its joins | Click the Element; the inspector includes joins outside the visible neighborhood |
| Inspect a join | Click its arrow or its Operative Purpose in the inspector |
| Open the Type overview | Types button |
| Arrange an Element | Drag the node |
| Return to the previous view | Back, Escape, or Alt + Left |
| Return to the Defining Element | Defining Element button |
| Zoom in / out | Wheel, pinch, + / − buttons, or keyboard + / − |
| Zoom at a location | Double-click the background / Shift + double-click |
| Pan | Drag the background |
| Fit the current diagram | Fit button or keyboard 0 |

Opening a Type or Element animates to its graph neighborhood. A project with
one actual Defining Element opens there initially. Returning restores
the saved zoom and position. Reduced-motion settings skip these animations.
Refresh updates the displayed records while preserving the current view.
Each click replaces the graph with the selected node and its immediate neighbors.
The location display stays on the current node. The inspector shows its recorded
relationship to the Defining Element independently of browsing history.

The detail panel presents the actual saved payload, including structured
functions, notes, purposes, and other project fields. In the combined Inference
view, Native and Latent records are identified separately. The inspector edits
the source selected for that record; viewing Native detail does not edit a
later Latent record that happens to occupy the canonical storage row.

Namespace prefixes without records are labeled **Namespace group**. These are
navigation aids, not invented or persisted Elements. Connections to Elements
outside the open namespace remain available. Joins involving multiple participants or other joins
have inspectable relationship cards.

Actual records use `metaform:actual-element`, carry their own freeform
`entity_json_obj.description`, and reference applicable Types in `type_ids`.
Their IDs identify the actual things. The viewer combines those Type definitions
with the same actual node; classification adds no OP joins or extra visual nodes.
Type records keep their Namespace addresses and reversed `length` naming rule.
A Type’s model-authored `svg` is loaded as an image on the node. Functional
edges follow the saved OP joins. The directed layout keeps cycles and shared
providers visible without treating them as Namespace children.

The viewer reads existing storage through the project's API. It does not
relocate databases or generate missing intake detail.
Updates currently require Refresh; this change does not add a live event stream.

## Verification

- Python viewer tests cover SQLite and portable JSON, project/source isolation,
  exact project fields, and complete joins.
- `node --test tests/test_structure_model.cjs` exercises namespace grouping,
  relationship preservation, naming, and pointer-anchored zoom.
- `node --test tests/test_cytoscape_renderer.cjs` checks actual Cytoscape/Dagre
  rendering data and directed layout.
- `node tests/test_structure_browser.cjs` starts and cleans up an isolated SQLite
  fixture, then checks navigation, source-specific editing, camera restoration,
  gestures, reduced motion, and mobile presentation in Chromium.
