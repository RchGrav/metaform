# Semantic source rules

The [Metaform specification](../SPEC.md) contains the current semantic contract:
exact Type identity `C(T) = {(rᵢ ∧ pᵢ ∧ e)}` with one Encounter Function,
established Element roles, strict typology, Encounter propagation, and independent
Contextual and Latent graphs with a separate shape-similarity layer.
[Current work](../current-work.md) records implementation status.

The 2026-09-10 [Artifacts and functional intake](artifacts-and-functional-intake.md)
clarification describes actual artifacts and their receiving purposes, Type
organization, full Native context for latent reasoning, photographs and their
surrounding context, and the exterior/external distinction. It supersedes the
generic-Type and stripped-handoff framing in older sources.

The 2026-09-09 [Names, receiving purposes, and Native Metaform variants](names-receivers-and-variants.md)
records the accepted Namespace/`length` rule, exterior receiving purposes, the
receiver-owned OP typing clarification, Native oversight updates, and cloned
variants that regenerate affected understanding through their producing prompts.
It links the current specification and implementation handoff. Runtime sources
still require the corresponding implementation updates.

Start with [Developed understanding, receiving relationships, and work](understanding-and-work.md)
for Rich's quoted design statements, glossary definitions, and photograph examples.

These supplied source documents are preserved verbatim.

- [Semantic Equation Preservation and Reuse](semantic_equation_reuse_rule.md)
  — supplied as `Semantic Equation Reuse Rule.md`.
- [Inference Metaform Rules](inference_metaform_rules.md)
  — supplied as `Inference Metaform Rules.md`.
- [Functional typology and encounter](functional_typology.md)
  — settled `code` Name, functional structure, and supplied encounter examples
  from the 2026-09-07 development conversation.

The [Inference Metaform primer](../primer/README.md) provides the narrative
explanation alongside these source rules.

The [Rulebook](../rulebook/README.md) collects individual rules for tasks and
processes, beginning with Name and Description for completing the Element schema.

[Return to the project README](../../README.md)
