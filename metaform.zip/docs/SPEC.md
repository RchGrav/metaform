---
id: SPEC-metaform
sources:
  - README.md
  - docs/primer/01_full_explanation.md
  - docs/primer/02_specification_introduction.md
  - docs/primer/03_technical_account.md
  - docs/semantics/inference_metaform_rules.md
  - docs/semantics/names-receivers-and-variants.md
  - docs/semantics/artifacts-and-functional-intake.md
  - docs/rulebook/element/name.md
  - src/metaform/data/semantics/glossary.md
  - src/metaform/data/semantics/native.md
  - src/metaform/data/semantics/archaeology.md
  - docs/workflows.md
  - docs/workbench-cleanup.md
---

> **Canonical contract.** This document defines the intended semantic product behavior for Metaform. Explicit user-supplied definitions and corrections govern it. Repository implementation and tests are evidence to compare against this contract, not sources of truth by existence.

# Metaform

[Capabilities](#capabilities) · [Semantic contract](#semantic-contract) · [Acceptance scenarios](#acceptance-scenarios) · [Current work](current-work.md)

## Why

Metaform exists to amortize inference about the project being worked on: describe its actual artifacts, functions, properties, and receiving purposes, preserve that understanding as its Native Inference Metaform, and let later work begin from it. Artifact Types organize that understanding in the Namespace. Inputs may include software, photographs, contracts, stories, resale materials, or several distinct projects in one collection. Cost here means inference effort. The desired effect is more reasoning available for higher-order work without repeatedly reconstructing the project's functional understanding.

## Capabilities

- **CAP-1 — Reusable inference preparation**
  - **intent:** The system can prepare reusable semantic understanding so later operations can address project and type meaning without reconstructing the same prerequisite inference from raw artifacts each time.
  - **success:** After preparation, a compact type-level instruction can produce project-specific results that depend on represented semantic relationships without restating those relationships in the instruction.

- **CAP-2 — Contextual Metaform**
  - **intent:** The system can construct a Contextual Metaform from the actual project or implementation plan, preserving project-local Elements and semantic relationships with contextual provenance.
  - **success:** Project-derived Receiving Entities, Operative Purposes, Encounter Functions, Elements, and joins are represented with provenance that distinguishes them from latent inference.

- **CAP-3 — Latent Metaform**
  - **intent:** The system can invoke independent latent reasoning on the complete Native Metaform, including its actual Elements, descriptions, joins, and Operative Purposes, from outside the implementation frame.
  - **success:** The agent receives the Native functional account while remaining blind to the repository implementation. It can agree, disagree, or identify omissions from that outside perspective. Global per-Type reuse is separate from this project-understanding operation.

- **CAP-4 — Shape-similarity layer**
  - **intent:** The system maintains the Contextual and Latent Metaforms as complete, independent graphs and provides a separate structural similarity layer for observing where their shapes agree or differ.
  - **success:** Neither source graph is merged into the other and no semantic payload is copied into the similarity layer. The similarity layer records only structural correspondence and provenance references: contextual-only (`01`), latent-only (`10`), or structurally present in both (`11`). When the same nodes and join exist in both source graphs, the layer can show that structural agreement. If the source join contents differ, both source joins remain intact and independently observable with their provenance.

- **CAP-5 — Project-inferred strict typology**
  - **intent:** The system can infer a project-appropriate strict functional typology and construct recoverable names through the agreed Namespace rule. Exterior denotes an entity that is not part of the project, with its own lightly defined scope.
  - **success:** Functional Namespace prefixes express meaningful Types that organize the actual artifacts and functions being described. Placement follows semantic specificity, reuses the appropriate existing position, and records the common name's extent in `length`. Reversing the final `length` components recovers the name. The exterior exception is described in the semantic contract.

- **CAP-6 — Receiving purposes and participation**
  - **intent:** Intake identifies the actual receiving purposes and how linked Elements serve them. Roles belong to joins owned by the receiving entity's OP. Properties and hard requirements describe what the artifact needs.
  - **success:** Later inference can address those actual relationships. Parametric tunables remain in a Type's array with their names reserved against Namespace Elements; tuning alone does not constitute acceptance. Notable is retired as a separate category because the OP already explains participation.

- **CAP-7 — Encounter propagation**
  - **intent:** The system can propagate an Encounter through the functional type structure so inference at each affected type is conditioned by the relevant realization or encounter.
  - **success:** If `code.bash` is linked to an installer type and `code.cpp` to a game-engine type, broad `code` reasoning can see both; each Encounter conditions the appropriate branch without leaking into an unrelated sibling branch solely through their common ancestor.

- **CAP-8 — Open-ended type-level operations**
  - **intent:** The system can execute general prompts across actual Elements and their relationships without requiring a dedicated hard-coded operation for each reasoning task.
  - **success:** One instruction such as generating best practices or imperatives for every relevant type produces type-specific output conditioned by each type's connected Elements, Encounters, Receiving Entities, and Operative Purposes.

- **CAP-9 — Workflow specialization**
  - **intent:** The system can resolve a general workflow or prompt into the relevant project Elements and semantic relationships while preserving the source operation's intent and control flow.
  - **success:** A specialized workflow addresses concrete project semantics without adding unrelated requirements or changing authored branching/sequence semantics.

- **CAP-10 — Bias/blindness comparison**
  - **intent:** The system can use contextual/latent divergence as an inference surface for examining project-local blind spots and alternative type knowledge.
  - **success:** An operation can examine latent Elements and joins against Native project understanding, determine whether differences are non-issues or oversights, and update the Native Metaform with understanding recovered from identified oversights. The Latent perspective remains independently available.

- **CAP-11 — Refactoring through semantic relations**
  - **intent:** The system can reason about refactoring through represented type meaning rather than treating the current implementation shape as the thing that must be preserved.
  - **success:** Refactoring guidance can consider radically different realizations through the relevant Functions, Encounters, Receiving Entities, Operative Purposes, and relationships needed by the work.

- **CAP-12 — Porting through Encounter change**
  - **intent:** The system can clone Native project understanding into a variant and develop a target realization through a changed Encounter relationship.
  - **success:** Replacing the variant's Property / Medium relationship from `code.cpp` to `code.javascript` detaches reasoning derived from the replaced relationship and reissues its producing prompts against the changed context. Newly produced knowledge belongs to the variant; the base retains its original understanding.

- **CAP-13 — Coarse semantic representation**
  - **intent:** The Metaform represents enough type-level semantic shape to reason effectively without attempting to enumerate every true property, purpose, environment fact, or implementation detail.
  - **success:** The graph remains compact enough for reusable inference while still allowing later operations to deepen selectively through connected Elements and relationships when the task requires it.

- **CAP-14 — Shared knowledge and independent portable projects**
  - **intent:** Projects can use a shared knowledge service and carry their related understanding into a self-contained executable export.
  - **success:** Export follows global and selected-project relationships, including workflow dependencies, while other projects' local relationships remain outside its traversal. Source contents and provenance remain intact. The exported project can read and extend its JSON knowledge, continue work using local SQLite execution state, and export again without the service or Cypher. Installed backends retain Cypher for development and analysis.

- **CAP-15 — Producing context and regenerated understanding**
  - **intent:** Derived knowledge retains its originating prompt and the semantic relationships on which it depends so a meaningful change can cause the relevant questions to be asked again.
  - **success:** A changed relationship in a variant identifies affected reasoning and its producing operations. The system detaches that reasoning from the variant, issues those operations with the new semantic context, and attaches their results with new producing context.

- **CAP-16 — Exterior receiving purpose**
  - **intent:** Intake resolves the receiving entity outside the project that has an OP for the DE's EF, and also represents exterior providers whose EFs serve the artifact's requirements.
  - **success:** A dedicated receiving-purpose record attached to the DE makes the exterior receiver and its OP available to reasoning about internal decisions, preserving the receiver's ownership of the OP.

## Constraints

- `C(T)` defines semantic type identity. It is part of the semantic model, not a required runtime mechanism.
- Contextual and Latent Metaforms must remain complete and independently observable; `01`/`10`/`11` belong to the shape-similarity view and encode structural presence, not confidence, truth, verification, precedence, or merged semantic content.
- Latent reasoning receives the complete Native functional structure, including project joins and OPs, while remaining outside the repository's implementation frame.
- The functional namespace is a strict typology, not a domain/class taxonomy. Its prefixes express valid Function or Encounter types. The `exterior` trunk denotes entities that are not part of the project and is exempt from the reverse-reading requirement. External denotes something outside the functionality being examined but still within the repository.
- Established semantic terms are operative semantic content and must be preserved verbatim. The system must not paraphrase, rewrite, normalize, synonym-substitute, rename, collapse, or replace an established semantic term, including Element-role names.
- Typological placement is inferred from meaning and specificity. The agreed Name rule constructs the local reversed name sequence at that position and records its extent in `length`.
- Each Type has one Encounter Function at its represented resolution. A materially different Encounter implies a different Type/variant, expressed through the typology rather than by adding another EF to the same Type.
- Receiving Entities and Operative Purposes are modeled coarsely enough to provide a useful reasoning frame rather than exhaustively enumerating every possible purpose. Apparent over-specificity is resolved by generalizing the Encounter Function or distinguishing the Receiving Entity where appropriate.
- Encounter-linked project properties remain project-local unless independently established as global type knowledge.
- The operation surface remains open-ended. Refactoring, porting, diagnosis, best-practice generation, foresight, and review are examples, not a closed operator catalog.
- The base Metaform need not encode every true environmental fact. Environmental context belongs only where it materially affects the semantic reasoning required.

## Semantic contract

### 1. Type identity

For a Type `T`, the formal identity is the exact set:

`C(T) = {(rᵢ ∧ pᵢ ∧ e)}`

where each conjunction binds:

- `rᵢ` — Receiving Entity: the **who or what** receiving the effect;
- `pᵢ` — Operative Purpose: the **why** owned by that Receiving Entity;
- `e` — the Type's single Encounter Function: the **how** through which the effect is realized or encountered.

`C(T)` is exact as a semantic definition. It is not a lower bound, partial signature, similarity measure, confidence score, or candidate identity projection.

A Type has one Encounter Function at the represented resolution. A materially different Encounter makes a different Type or variant, represented through a further typological distinction rather than by adding a second EF to the same Type.

Receiving Entities are connected at the most general level that still preserves the useful Operative Purpose. The goal is a coarse reasoning frame, not exhaustive enumeration of every purpose or possible receiver. If an apparent distinction forces the EF or OP into excessive specificity, the model should seek a more general Encounter Function or distinguish the Receiving Entity appropriately.

These definitions describe the semantic relationship that protects type meaning through change. They do not prescribe a runtime identity-checking mechanism.

### 2. Element roles

Element roles are semantic and materially affect inference. They are not taxonomy classes, and the specification must not rename them into class-oriented terminology.

The Defining Element expresses the artifact's identity and its combined EF.
Roles belong to the joins owned by receiving entities' OPs. **Notable** is
retired as a separate category: the OP already explains why the Element
participates. **Supportive Element** describes a contextual contribution to the
subject and purpose, as in the photograph examples; a poor scene with loose
coupling is not supportive merely because it surrounds the subject.

For the supplied examples, `code.game` has an OP for `code.cpp` that is a
**Property of type Medium**, while its OP for `code.game.rules` is a
**Dependency**. These joins express how the receiving Element uses the linked
Element's EF. **Parametric** is a Type's array of tunables. It acknowledges
those items and reserves their names against being minted as Namespace
Elements. Adjusting a tunable does not by itself constitute acceptance.

**Signal** is the way an OP is satisfied. This definition does not prescribe
an acceptance-check mechanism or an additional role taxonomy.

#### Exterior and external relationships

`exterior` means not part of the project. **External** means outside the
functionality being examined but still within the repository. Control or
ownership does not define this distinction. Either relationship can involve
an entity receiving the artifact's EF or providing an EF for an artifact's OP.

Intake resolves the upstream receiver and its OP as part of project
understanding. A dedicated receiving-purpose record attaches this understanding
to the DE and associates the receiver's OP with the DE's EF.

Exterior is lightly defined and exempt from the reverse-reading requirement
of the functional trunks. Environment, person, group, system, and framework
are tentative subgroup examples. Player Group, a family, an organization,
and a dental industry group illustrate receiving contexts.
These examples do not prescribe a closed receiver list. Record multiplicity
and concrete attachment fields remain to be designed.

#### Element descriptions and expert roles

The **Native Expert** describes the actual system freely, using a diagram, account, or structured content in `understanding` when useful, then describes its typological organization. Actual Elements use an open description shape so their detail can speak directly to the system. The input may be a folder of assets, standalone artifacts, or several projects; its contents may be photographs, documents, stories, software, or other material.

The walk first identifies the **Defining Element**, whose EF summarizes the combined result of the artifact under analysis, then its Receiving Entity and that entity's Operative Purpose. The DE's loss would change what the artifact is; its defining function excludes medium, encoding, genre, and style. Intake names its properties and hard requirements, joins each receiving OP to the EF that serves it, and follows those relationships recursively.

For photographs, visible subjects, surrounding folders, related images, and camera filename sequences can supply meaningful context without an explicit user-provided purpose. In a couple-at-the-Eiffel-Tower photograph the couple is defining and the tower supportive; a scenery photograph can also have a salient subject. Descriptions differentiate the actual images. The [artifact and photograph clarification](semantics/artifacts-and-functional-intake.md) records the contextual examples.

#### Semantic term preservation

Defined semantic terms are operative semantic content. The system must preserve established terms verbatim. It must not paraphrase, rewrite, normalize, synonym-substitute, rename, collapse, or otherwise restate an established semantic term as a different term. This applies to Element-role names and to every other defined semantic term in Metaform.

New semantic records may be authored where the process calls for a new record, but an existing established term is not rewritten into alternate wording by intake, latent inference, similarity processing, storage, MCP presentation, workflow specialization, or another system layer.

### 3. Type meaning through change

The semantic relationship defines what the Type means independently of its present implementation. This allows substantial changes in realization without treating current code, structure, or content as a frozen core that must be preserved.

The identity definition is semantic guidance for reasoning about the Type; it does not itself prescribe an approval gate, lifecycle, or runtime check.

### 4. No frozen implementation context

The represented type meaning allows operations to reason about alternative realizations without making the current realization the definition of the thing.

### 5. Strict typology

The dotted functional namespace is a **typology**, not a taxonomy. Its existing
trunks are `code`, `document`, `media`, and `data`. The additional `exterior`
trunk has the project-boundary meaning and naming exception described
above.

For a valid functional Type path `a.b.c`, its prefixes express meaningful Types:

- `a`
- `a.b`
- `a.b.c`

No `domain.class.type` alignment layer exists. A segment belongs because the path speaks to a valid Function or Encounter sprung from its parent, not because a class label makes a hierarchy look regular.

Function expresses operative capability. Encounter expresses how a Function/type is encountered or realized, including variants such as programming language, style, genre, and similar forms. Encoding alone does not qualify as a type; an encoding name may appear where the path is actually expressing a Function, such as an encoder.

Artifact Types classify and organize the Namespace. The actual Elements are described through their functions, properties, and receiving purposes in the artifact being examined.

A Type record keeps the `metaform:element` shape, its Namespace address as its
ID, and its universal Description and single EF. Its namespace and backward
name rule remain unchanged: reverse the final `length` terms to read its name.
It can carry a model-authored `svg` shape for visual presentation.

An actual Element has its own project ID and uses `metaform:actual-element`.
Its `entity_json_obj.description` is freeform text or structured content, with
room for the details that describe the particular thing. Its `type_ids` array
references the applicable Type namespaces. Those Type definitions merge into
the same actual Element's presentation; these memberships create neither OP
joins nor additional visual nodes. Several Types can describe one actual
Element, and separate actual Elements can share a Type without losing their
own descriptions and receiving purposes.

OP joins reference the actual IDs: `object_id` is the Receiving Entity and
`element_id` is the EF provider. The join's `type` carries hard dependency,
property, or supportive, and its `signal` describes how the OP is satisfied.
These are the actual receiving-purpose relationships, distinct from the Type
references organizing the records.

### 6. Typology path and linked properties

The dotted functional path carries meaning through its independently promptable
prefixes. Place the Type at the most general accurate position, then link other
relevant Namespace Elements through OP joins that express their use.

The [agreed Name rule](rulebook/element/name.md#concise-form) defines construction
and extraction. It is reproduced here verbatim:

> The Namespace narrows in specificity as it extends. Use the Type’s most common universal name, expressed as a singular proper noun, and reverse its words into period-separated components.
>
> Locate the position in the existing Namespace that speaks to the Element at its most general specificity. This position may occur within a more specific path. Reuse the components through that position, then append the remaining modifier components that identify the Element in its full specificity.
>
> Record the number of words in the full name as `length`, including reused components. Extract the proper name by reversing the final `length` Namespace components and joining them with spaces.

Given `code.system.driver.video`, Network Driver attaches at
`code.system.driver.network` with `length: 2`. The existing `driver` component
counts toward the name. Semantic placement selects the shared general position;
the final path's name is recoverable from Namespace and `length`.

This replaces the independently authored Element Name field. The runtime still
uses `en`; migrating existing records and reconciling trunk names such as
`code` / Program Code remain implementation decisions.

An Encounter does not have to be appended to the Type's dotted path. It can be linked as a property/relationship to the relevant type. For example an installer Type may be linked to `code.bash`, while a game-engine Type may be linked to `code.cpp`.

Project-local linked properties remain project-local. Their presence does not automatically promote them to global type knowledge.

### 7. Encounter propagation

A property applies through its joins. Its effect is transitive through functional Type structure in two distinct senses:

1. **Backward visibility:** a property linked deeper in a branch flows backward toward the Defining Element or trunk and is available when reasoning at broader ancestor Types.
2. **Forward application:** from its attachment point, the property conditions inference through the named, more-specific Elements of that branch.

Backward visibility does not cause an Encounter to fan back down unrelated sibling branches.

Example:

```text
code
├── installer            ↳ code.bash
└── game
    └── engine           ↳ code.cpp
        ├── renderer
        └── physics
```

Expected reasoning scope:

- `code` can reason with both Bash and C++ as Encounters present in its functional descendants;
- `installer` and its functional descendants reason through Bash;
- `game`, `engine`, `renderer`, and `physics` reason through C++ where that Encounter applies;
- `installer` does not inherit C++ merely because C++ is visible at `code`;
- `renderer` does not inherit Bash merely because Bash is visible at `code`.

### 8. Contextual and Latent Metaforms

The **Native Metaform**, also called the Contextual Metaform, records the actual project's functional understanding. It is the project's Inference Metaform. Latent reasoning can be invoked on it at any time.

The **Latent Metaform** is authored from an outside perspective on the complete Native structure and its descriptions, including its Elements, joins, and OPs. The agent remains blind to the repository's implementation particulars. It reasons about the actual artifact, including what it agrees with, what it questions, and what it finds missing.

The Contextual Metaform and Latent Metaform remain complete, independent graphs. They are not merged, averaged, or rewritten into a third semantic graph. Both remain directly viewable and observable, including through MCP.

A separate **shape-similarity layer** exists for one purpose: to show structural agreement and divergence between those two graphs. It contains no copied semantic payload from either source graph; it records only structural correspondence and provenance references.

Shape membership:

- `01` — structure present in the Contextual Metaform only
- `10` — structure present in the Latent Metaform only
- `11` — the same nodes and join structure are present in both

These values do not encode confidence, correctness, precedence, or semantic reconciliation. When both source graphs contain the same nodes and a join between them, the similarity layer may represent that structural agreement as `11`. If the source join contents differ, both source joins remain intact in their respective graphs and retain their own provenance; the similarity layer does not collapse, copy, or reconcile their contents.

### 9. Inference amortization

The Metaform stores reusable semantic understanding, not a catalog of completed task answers. The prompt/workflow and Metaform remain separable: a prompt describes an operation; the Metaform supplies previously inferred project/type meaning through which that operation is interpreted.

This permits general instructions such as:

- evaluate latent-only Elements for project usefulness or existing coverage;
- generate type-specific best practices or execution imperatives for every relevant Element;
- change an implementation Encounter and derive porting imperatives across affected functional types;
- evaluate a proposed refactor through connected Elements and their reciprocal Operative Purposes.

These are examples of open-ended operations, not a mandatory workflow library.

### 10. Coarse base shape and operation-specific depth

The Metaform's base semantic shape is intentionally coarse. It exists to put forward enough type knowledge and relationship structure to reason on, not to enumerate all possible facts about an artifact or to reproduce the implementation at another abstraction layer.

Later operations may select deeper connected Elements, properties, and relationships when the operation needs them. That additional depth is task-driven and open-ended; it is not required in order to mechanically police Type identity.

### 11. Native refinement and regenerated variants

An examination operation evaluates latent Elements and joins against Native
project understanding to identify non-issues or oversights. Identified
oversights cause the process to update the Native Metaform. This is an authored
update from the examination's reasoning; the Latent perspective and structural
similarity remain independently available.

A variant is a clone of the Native Metaform. The original remains the base
project understanding; the clone develops the target realization. In the
porting example, change the variant's game Property / Medium relationship from
`code.cpp` to `code.javascript`.

The changed relationship detaches its derived reasoning from the variant's
active understanding. The system finds the prompts that produced that knowledge
and asks them again in the variant's changed semantic context. Their results
become new knowledge attached to the variant. Producing-context associations
retain the originating prompt and semantic dependencies needed to carry out
this operation, including dependencies through other derived knowledge.

The concrete variant representation, dependency tracing, and prompt revision
policy remain implementation design choices. The
[feature specification](../feature-briefs/native-metaform-variants-specification.md)
records the agreed behavior, current facilities, and open contracts, with an
[implementation plan](../feature-briefs/native-metaform-variants-implementation-plan.md).

## Non-goals

- Reproduce the implementation as an exhaustive semantic graph.
- Preserve the present implementation shape as a proxy for identity.
- Treat contextual/latent agreement as proof of truth or confidence.
- Replace subsequent inference with stored completed answers.
- Make every current chassis feature—workbench, MCP exposure, packaging, CI, image generation, history/export—a core semantic product requirement merely because it exists in the repository.

## Success signal

A prepared Metaform can take a short, general type-level instruction and produce correctly differentiated reasoning across a heterogeneous project according to each Element's relevant semantic relationships, while enabling substantial changes of realization and open-ended higher-order reasoning.

## Semantic sources

The accepted 2026-09-09 [Name rule](rulebook/element/name.md#concise-form) and
[receiving-purpose and variant clarification](semantics/names-receivers-and-variants.md)
record the latest design decisions. Earlier supplied Name, Description,
typology, and Aliases equations are preserved in
[Inference Metaform Rules](semantics/inference_metaform_rules.md). The
[Aliases section](semantics/inference_metaform_rules.md#aliases) is bundled verbatim
for intake; `semantic_sources.aliases` can select an explicit source override.
The [glossary](../src/metaform/data/semantics/glossary.md) supplies the established
Element-role definitions. [Semantic Equation Preservation and Reuse](semantics/semantic_equation_reuse_rule.md)
defines how authored semantic equations are carried into later inference.

## Open Questions

- When an environmental vector materially affects reasoning, how is it represented without making environmental detail part of the mandatory base shape?
- What are the exterior receiving-purpose record's fields and multiplicity?
- How are existing names such as `code` / Program Code represented under Namespace plus `length`, and how does extraction apply to exterior entries?
- How are variants associated with their bases, semantic dependencies of derived knowledge recorded and traced, and originating prompt/rule revisions selected for reissue?

## Acceptance scenarios

These scenarios define semantic demonstrations for the contract. They are intentionally independent of the current implementation and test suite.

### A-1 — Strict typology rejects class filler

Given proposed types:

- `code.cpp`
- `code.language.cpp`
- `code.game.platformer`
- `code.game.genre.platformer`

The typing operation accepts `code.cpp` and `code.game.platformer` when those paths speak to valid Encounters, and rejects the class-filler forms `code.language.cpp` and `code.game.genre.platformer`.

The reason must be semantic qualification of each path segment, not a hard-coded blacklist of the words `language` or `genre`.

### A-2 — Encoding name is judged by what the path expresses

Given:

- `document.html` where HTML is used only as document encoding;
- `code.html` where HTML is being treated as a language Encounter;
- `code.encoder.jpg` where JPG participates in an encoding Function;

The first fails type qualification, while the latter two can qualify because their paths speak to Encounter or Function rather than expressing an encoding as the Type.

### A-3 — Established semantic terms remain verbatim

Given an established semantic source containing terms such as **Receiving Entity**, **Operative Purpose**, **Encounter Function**, **Defining Element**, **Parametric Element**, or **Stylistic Element**, pass that material through intake, latent inference, storage, MCP retrieval, similarity processing, or workflow specialization.

Expected:

- the established term remains exactly the established term;
- no layer replaces it with a synonym, paraphrase, normalized label, alternate role name, or taxonomy-oriented class name.

### A-4 — Contextual and Latent graphs remain intact behind a similarity view

Given a Native Metaform containing the actual artifact's Elements and project-specific OP relationships, supply that complete functional structure and its descriptions to an independent Latent agent while withholding repository implementation details.

Expected:

- the latent result is independently authored;
- the complete Contextual graph remains intact and observable;
- the complete Latent graph remains intact and observable;
- the shape-similarity layer contains no copied semantic payload from either graph;
- structure present only contextually is shown as `01`;
- structure present only latently is shown as `10`;
- when the same nodes and join structure exist in both graphs, the similarity layer can show `11`;
- if the two source joins have different contents, both source joins remain intact and separately attributable;
- `11` is never interpreted as confidence, truth, or semantic reconciliation.

### A-5 — Encounter propagation respects branch scope

Given:

```text
code
├── installer            ↳ code.bash
└── game
    └── engine           ↳ code.cpp
        ├── renderer
        └── physics
```

Expected:

- reasoning at `code` can account for both Bash and C++;
- `installer` and its functional descendants are conditioned by Bash;
- `game`, `engine`, `renderer`, and `physics` are conditioned by C++ where applicable;
- Bash does not flow into the game/engine branch merely because it is visible at `code`;
- C++ does not flow into the installer branch merely because it is visible at `code`.

### A-6 — One general instruction produces type-specific reasoning

Given the graph in A-5, issue one operation equivalent to: “For every relevant node type and its properties, derive ten best practices.”

Expected output is not one generic list copied to every node. At minimum:

- `code` can distinguish relevant Bash and C++ perspectives;
- `code.installer` yields installer reasoning conditioned by Bash;
- `code.game.engine` and its applicable descendants yield their own functional reasoning conditioned by C++.

The operation must not require dedicated hard-coded “Bash installer best practices” and “C++ game engine best practices” commands.

### A-7 — Workflow specialization preserves authored behavior

Given a general workflow containing authored sequence, branches, and prompts, specialize it against a project Metaform.

Expected:

- general terms resolve to relevant Elements and relationships;
- source intent remains intact;
- existing control flow remains intact unless the source itself calls for a structural inference;
- no additional quality gates, preservation requirements, or hidden rounds appear merely because specialization occurred.

### A-8 — Refactor and porting reason through semantic structure

Given a type whose current realization uses one implementation Encounter, ask Metaform to reason about a substantial refactor or a port to another Encounter.

Expected:

- guidance is derived through the represented Functions, Encounters, Receiving Entities, Operative Purposes, and connected Elements relevant to the work;
- substantially different realizations can be considered through the same prepared semantic understanding;
- porting guidance can change with the target Encounter while remaining specific to each affected Element.

### A-9 — Common names reuse the appropriate Namespace position

Given `code.system.driver.video`, introduce Network Driver. Locate
`code.system.driver` and append `network` there, preserving Video Driver as a
sibling. Store `length: 2` and recover Network Driver from the final two
components. A name with a different word count is extracted using its own
`length`.

### A-10 — Exterior purpose participates in project understanding

Intake identifies the DE's exterior Receiving Entity and its OP for the DE's
EF. Retrieval of the attached receiving-purpose record exposes that relationship
to subsequent reasoning about the artifact. The OP remains the receiver's.

### A-11 — Typed OPs preserve Medium and Dependency distinctions

Record `code.game` receiving `code.cpp` through a Property of type Medium and
receiving `code.game.rules` through a Dependency. Store, retrieve, and prepare
context from these relationships. Their purposes, typing, and EF providers
remain distinguishable.

### A-12 — Oversight examination updates Native understanding

An operation examines latent Elements and joins against Native project
understanding and identifies a non-issue and an oversight. The process updates
Native understanding with the recovered oversight knowledge. Later operations
receive that updated understanding; the Latent source remains independently
observable.

### A-13 — A cloned variant regenerates affected understanding

Clone a Native game Metaform with a C++ Medium relationship and derived
knowledge linked to its producing prompts and semantic dependencies. Replace
the clone's Medium provider with `code.javascript`.

Expected:

- the base retains its C++ relationship and understanding;
- affected derived reasoning detaches from the variant's active understanding;
- unaffected knowledge remains available;
- the producing prompts are reissued against the variant's updated context;
- their results attach to the variant with new producing context;
- subsequent porting work uses reasoning specific to the changed Medium and
  affected functional Types.

Fixture verification of record handling is distinct from a live demonstration
of the regenerated reasoning's semantic suitability.
