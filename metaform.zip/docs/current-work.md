# Current work

The [Metaform specification](SPEC.md) defines the product behavior, semantic
contract, and acceptance scenarios. The documentation is integrated; runtime
corrections are underway. Implementation and tests are evidence to compare
against the specification.

The [discussion handoff](discussion-handoff.md) collects subsequent semantic
clarifications and exploratory goals for coordination with an external agent.

## Actual artifacts and functional intake — 2026-09-10

The [current clarification](semantics/artifacts-and-functional-intake.md)
distinguishes actual artifact understanding from its Type classification.
Native intake describes the artifact's functions and specific OPs, beginning
with the exterior receiver and DE and following requirements and properties.
Photographs, documents, stories, resale materials, and multi-project collections
are within scope. Exterior means not part of the project; external means outside
the functionality under examination but still in the repository.

Native is the project's Inference Metaform. Latent reasoning receives its whole
functional structure while remaining outside the implementation frame. Intake
uses one Native assignment followed by one fresh Latent assignment.
The handoff retains Element descriptions, OP joins, custom schemas, and supplied
artifact context. Incremental Native contributions participate in that handoff;
Latent contributions stay in the project's independently attributed perspective.
`intake.examine` invokes a fresh examination of saved Native understanding.

The latent orientation is a separate instruction snapshot placed before task
input. MCP transports it as `systemPrompt`; Codex uses its supported developer
instruction channel. The role establishes outside reasoning while the task asks
what should differ or is missing from the complete Native account. This does
not claim that prompting eliminates contextual bias.

## Property transitivity — settled clarification, 2026-09-10

A property applies through its joins. Its effect extends forward through named,
more-specific Elements within its branch and flows backward toward the Defining
Element or trunk. Bash on the installer and C++ on the game engine are both
visible at `code`, with their respective relationships intact. The
[propagation contract](SPEC.md#7-encounter-propagation) records this settled rule.

## Workbench project selection — 2026-09-09

The project selector remains visible with one project. Open an existing folder
from the header; relative paths resolve from the selected project. Open local
projects and shared-service registrations appear together, and Refresh or window
focus discovers later registrations. Each tab retains its project URL.

Selection preserves the target's service home and existing local storage.
Portable copies with the same semantic owner have separate viewer URLs and
preview sessions. Missing registered folders are reported without recreating
them, and switching through portable copies retains an external selection home.

## Agreed naming, receiving purposes, and Native variants — 2026-09-09

The [source discussion](semantics/names-receivers-and-variants.md), updated
[canonical contract](SPEC.md), [feature specification](../feature-briefs/native-metaform-variants-specification.md),
and [implementation plan](../feature-briefs/native-metaform-variants-implementation-plan.md)
record the agreed behavior:

- Construct names through semantic Namespace placement and `length`, reusing
  the appropriate general prefix. Extract the proper name by reversing the
  final `length` components. The [accepted rule](rulebook/element/name.md#concise-form)
  includes the sibling Video Driver / Network Driver example.
- Resolve the DE's exterior receiver and its OP during intake, retaining them
  in a dedicated receiving-purpose record attached to the DE. Exterior means
  not part of the project and has its own lightly defined naming scope.
- Record the receiving OP typing. The game/C++ example is Property / Medium;
  game/Game Rules is Dependency. Rich locates Defining, Notable, Parametric,
  and Stylistic in the receiver's OP relationships.
- Examine latent Elements and joins for non-issues or oversights. Identified
  oversights update the Native Metaform's project understanding.
- Clone Native understanding into a variant. Changing its Medium relationship
  detaches the affected derived reasoning and reissues its producing prompts
  against the changed context, attaching new knowledge to the variant.

These are documented requirements, not implemented capabilities. Current
runtime records still use `en`; `length` and the exterior/typed OP contracts
are not yet declared in the bundled schemas. Prompt revisions and assignments
are retained, but the complete producing-dependency, clone, detach, and reissue
operation is not implemented. The feature specification records the remaining
semantic and representation choices without supplying invented resolutions.

## System review repairs — 2026-09-09

All 21 reproduced findings in the [system review](reviews/2026-09-09-end-to-end-system-review.md)
are repaired and covered by regression tests. The full suite passed 501 tests on
both Python 3.11 and 3.13; fresh installed-wheel checks passed on both, including
standalone export and service-free continuation. [Verification](verification.md)
records the scope and limits of that evidence.

The repairs preserve assignment and workfolder ownership, archive boundaries,
schema ownership, reused join identities, and independent Contextual/Latent
sources. Similarity preserves qualified reified references with fresh knowledge
across CLI, viewer, and intake paths.
Viewer crash recovery and image output attribution/readiness are also corrected.
The broader semantic demonstrations and build work listed below remain open.

## Runtime corrections implemented

- Contextual and Latent Elements now retain independently readable source
  contents through scoped retrieval, search, assembly, export, command routing,
  and the viewer. Source edits and export/import preserve that separation across
  SQLite, JSON, and Ladybug.
- Structural similarity covers `01`, `10`, and `11` using node identities,
  join types, participant roles, and references, including cyclic references to
  joins. It contains structure and source references; Element contents, purposes,
  and join logic remain source-local. The viewer exposes a read-only similarity
  view and treats stored similarity joins as read-only in other views.
- Applying specialized workflows preserves revised prompt wording and gives
  source-owned embedded prompt declarations local IDs. Execution retains the
  specialized control flow while source prompt records remain unchanged.

## Shared knowledge and portable projects

The shared knowledge service and portable-project implementation is integrated.
Its initial verification on 2026-09-08 passed 396 tests on both Python 3.11 and
3.13, plus rebuilt distribution checks,
including service-free nested continuation and re-export. Browser project
selection and installed Cypher refresh also passed; see [verification](verification.md).
This storage and runtime work preserves the semantic contract above.

- New installed projects use one authenticated user-local service per resolved
  home. Existing projects retain their configured backend until explicit
  `project connect`. Canonical-path registration, project selection, relocation,
  explicit copied-owner registration, verified liveness, and service stop are
  implemented. Runs, assignments, and workfolders remain project-local.
- Central SQLite retains owner-qualified records, independent Native/Latent
  sources, provenance, and transactional request receipts. Inference completion
  includes the global result and project Latent write in one transaction; retries
  recover committed responses and local workfolder cleanup. Inference lookup
  remains global-only and preserves precise reference owners and kinds.
- Selected export follows eligible project/global references using SQLite indexes
  in one read transaction. Its tests include unrelated global records and a
  concurrent writer. Ordinary graph mutations still reconstruct one owner
  partition; mutation scaling remains a practical limitation.
- Version 2 archives carry selected knowledge and executable dependencies,
  qualified schemas, source observations, historical evidence, assignments, and
  required assets. Portable JSON and local SQLite continue without the service,
  original home, or Cypher. The logical project owner remains stable and a
  separate `copy_id` identifies the working copy. Archive import accepts versions
  1 and 2 and retains history behavior; shared-service reconciliation is not
  implemented.
- Installed Ladybug analysis copies retain Cypher with explicit refresh and source
  revision metadata. Core knowledge, prompt, workflow, and export operations do
  not depend on those copies.

## Build corrections remaining

1. Reconcile intake records, the registered Element schema, and downstream graph
   storage against the contract. `entity_desc` already carries ED; the missing
   `ed` property in `metaform:element` alone does not demonstrate data loss.
   Schema-valid data does not establish semantic completeness. Preserve the
   established Element roles and their authored definitions throughout intake
   and later use.
2. Demonstrate the specified Encounter propagation and differentiated general
   operations using acceptance scenarios A-5 through A-8. Generic graph traversal
   and fixture answers do not establish those semantic outcomes.
3. Implement leaf-alias lookup and reservations at expanded Namespace addresses,
   and carry Parametric names from the intake array into address reservation
   without creating parameter nodes.
4. Complete the remaining rulebook content: Alias and Dependency entries and a
   descendant Description example. Integrate the newly agreed Name rule through
   the runtime migration work above; the current seed still uses its earlier
   formula. [Seed provenance](rulebook/seed-sources.md) distinguishes source
   wording, the accepted revision, and assistant-authored explanations.

## Settled details retained for implementation

- The **Native Expert** describes actual artifacts, functions, and receiving
  purposes, organized by Types. The **Latent Expert** receives that complete
  Native understanding, including OPs and joins, while remaining outside the
  source implementation. Native is the project's Inference Metaform.
- The **Defining Element** carries the EF summarizing the artifact's combined
  result. **Notable** is retired as a separate category; an OP already explains
  participation. **Parametric** is the Type's tunables array. The
  [current clarification](semantics/artifacts-and-functional-intake.md)
  records these settled meanings.
- Alias names reserve only the corresponding expanded address for that Artifact
  Type. `code.cpp.11` may resolve to `code.cpp.cxx11`; `code.c.11` remains
  independently usable. The maintained [Aliases equations](semantics/inference_metaform_rules.md#aliases)
  are already bundled and delivered verbatim, with an explicit source override
  supported. Address resolution and reservation remain unimplemented.
- Parametric Elements use an array when present. Their names reserve the
  corresponding Namespace addresses and block competing Element nodes. A
  Parametric adjustment alone is not an imperative's acceptance signal. Rich's
  exact clarification is in the [worked explanations](semantics/understanding-and-work.md#parametric-intake-data-reservations-and-adjustments).
- Relationship typing belongs in the **intake join dictionary**; the intake
  shape does not itself specify the persistence layout. OP belongs to its
  Receiving Entity. Namespace ancestry alone does not establish an OP relationship.
- Project-level inference selects semantic Namespace placement. Different
  placement can identify different Elements even when both refer to Box2D;
  `code.game` is not a mandatory trunk. The [worked explanations](semantics/understanding-and-work.md)
  preserve the supplied examples and the distinction between intake vocabulary
  and the vocabulary used for working prompts.
- Intake examines the complete Native graph in one fresh Latent context, as
  described in the [workflow format](workflows.md) and [architecture](architecture.md).

## Supporting implementation and verification

The existing build includes the rule and prompt editors, provider → receiver
relationship display with OP labels, Namespace labels, graph/list switching,
source filtering, and direct connection browsing. CLI/MCP routing, workflow
execution, history/export, packaging, CI, image generation, and module loading
are implemented supporting capabilities; their presence does not establish
additional core product requirements. Interface and scope decisions remain in
[workbench cleanup](workbench-cleanup.md).

The failed `mgm-main` intake graphs and their global copies were cleared; authored
prompts and schemas were retained. The runtime suite subsequently passed 486
tests. Historical trial evidence and its limitations remain in
[MVP review](mvp-review.md).

Before the shared-service integration, the full runtime suite passed 248 tests; subsequent prompt migration and rulebook
checks passed 24 tests. The wheel build and browser
checks passed; browser checks covered distinct source records and read-only
similarity inspection. Similarity regressions cover 1,100 independent joins,
a 1,100-link chain, and a 1,100-join cycle. These checks establish implementation
behavior. A subsequent live comparison used four Type cases in two matched
repeats: combined proof/handoff preserved supplied role names that a separate
route lost, while both removed the tested project OPs. Four fresh downstream
Latent inference calls retained that difference; they do not establish a general
Latent-graph quality ranking. The selected built-in proof also produced four
accepted handoffs through the runtime. This does not certify arbitrary historical
global records as decontextualized. Use the
[acceptance scenarios](SPEC.md#acceptance-scenarios) to distinguish contract
behavior from supporting infrastructure tests and superseded expectations.
[Verification](verification.md) records the test commands and evidence limits.
