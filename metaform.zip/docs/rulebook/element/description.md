# Description

For defining the shared meaning of a Type in the Namespace.

The [artifact-intake clarification](../../semantics/artifacts-and-functional-intake.md)
distinguishes this Type definition from the Native description of an actual
artifact. Native descriptions explain that artifact's specific functions,
subjects, context, and receiving purposes. The supplied universal Type wording
below remains available for classification.

## Concise form

The most basic universal statement that both defines uses the ancestral proper nouns of its lineage in reverse namespace order in a semantically proper statement but never name or include the most basic universal definition of the encounter or functions of its children

## Expansion

### Worked example

Supplied `code` trunk:

```yaml
code:
  name: program code
  description: a set of precise instructions that tells a computer how to perform a task or process data
```

[Settled functional typology and encounter context](../../semantics/functional_typology.md)
