# Metaform development handoff

## Next goal

Finish the rulebook for completing the Element schema, and work with Rich on how
its rules will be inspected, edited, and attached to tasks or workflows in the
next version. Begin with the established Name and Description rules.

The first concrete correction is in PR #3: its saved layout places the complete
rule sentences under “Expanded form.” The later agreed design makes those
sentences the concise formulas. Expanded material supplies additional detail and
worked examples alongside the formulas. The wording itself has been preserved.

Continue discussing the remaining rules and interface organization with Rich.
Rules are a concrete interface feature; their navigation placement is open.

## Starting context

Metaform prepares reusable semantic understanding so later instructions can
operate specifically through an artifact's Elements and relationships. The
current construction combines contextual examination of a composite artifact
with independent inference about its participating Types. Source attribution
remains available when the two perspectives are brought together.

The immediate product emphasis is making that work understandable: inspect
project knowledge, open a named workflow to its steps, and inspect the prompts
and applicable rules. Rich is refining the semantics through collaboration.

This archive is intended to be placed at the root of the existing
`RchGrav/metaform` checkout. It contains development continuity material. Its
top-level directory keeps extraction separate from the checkout's existing files.
Repository and PR status is recorded in `CURRENT_WORK.md`.

## Read next

1. The checkout's `AGENTS.md`; an unchanged copy is included here.
2. `RULE_WORDING.md` for the exact settled rule sentences and supplied example.
3. `DECISIONS.md` for the current design decisions, including later refinements.
4. `CURRENT_WORK.md` and `OPEN_QUESTIONS.md` for the implementation state and
   discussions to resume.
5. `COLLABORATION_REVIEW.md` and `CONTINUITY_PROCESS.md` for working practices to
   carry forward and refine in the persistent CLI workspace.

The repository's `docs/semantics/semantic_equation_reuse_rule.md` and
`docs/semantics/inference_metaform_rules.md` contain the maintained semantic
source rules. `docs/primer/02_specification_introduction.md` is a narrative
orientation. Its explanatory role is distinct from the rule sources.

Resume from the next goal above and the actual checkout state. The snapshot
below is dated; branches and pull requests may subsequently advance.
