# Metaform agents 3D

Sixteen procedural, animated agent characters for the Three.js map viewer.
No model files: every agent is built in code by `metaform-agents-3d.js`.

## Use

```js
import { createAgent, drawGlyph, releaseGlyph, placeAgentOnCurve } from './metaform-agents-3d.js';

const agent = createAgent(drawGlyph(sessionId));
scene.add(agent);

// every frame
agent.userData.update(dt, { busy: 0 });   // 0 while travelling, 1 while working at a node
placeAgentOnCurve(agent, edgeCurve, u, { reverse, lift }); // u from 0 to 1; reverse walks end to start

// when the session ends
scene.remove(agent); releaseGlyph(sessionId);
```

- Y up, +Z is the travel direction, about 1.6 units at scale 1 (same as the uploaded GLB set).
- `drawGlyph` gives each session a random glyph and keeps it; no two active sessions share one until all 16 are in use.
- No ring by default. Pass `{ halo: true, harness }` for a ring in the harness colour (`HARNESS_RING`).
- `busy` speeds up each agent's own motion: wings, rotor, tentacles, legs.
- The scene needs lights. An environment map (RoomEnvironment) and ACES tone mapping give the look in the demo.

## Demo

`demo.html` loads Three.js from jsDelivr and imports the module next to it, so serve the folder
(for example `python -m http.server`) and open `http://localhost:8000/demo.html`.
Opening the file directly will not load the module.
