# BMAD completeness review

The first consolidation preserves the ECS baseline and handoff while carrying the owner's direct corrections into the working contract. It contains 16 capabilities with intent/success pairs, 19 traced decisions, acceptance outcomes and detailed adopted source companions. It is ready for interface co-engineering; it is not represented as an implemented or implementation-complete system.

## Coherence pass

The draft preserves the selected LadybugDB backend, namespace/intake distinction, receiver ownership, allowed purposeful messages/events and absence of live logging into harness contexts. Capabilities describe outcomes, technical realization remains in companions, non-goals are explicit and success is demonstrable. There is no inferred event allowlist, compulsory two-agent team or extra approval hierarchy. One concrete projection-scope mismatch is corrected by D-19. Remaining payload/state-machine details are explicitly tracked rather than filled with invented owner decisions.

Verdict: coherent as a working baseline with a recorded engineering correction; further MCP contract completion remains visible.

## Preservation pass

The numbered ECS paper and technical specification, all supplied contracts and verification records are retained byte-for-byte. The handoff is retained and its consequential functional claims are mapped in traceability.md. Direct user corrections are preserved verbatim and incorporated into the derived contract. Existing source review/verification labels remain attached; they are not misrepresented as newly executed runtime evidence. Model-tier/workstation/process wrapper instructions do not become product behavior.

Verdict: supplied load-bearing content preserved through adoption or explicit consolidation. This does not claim recovery of anything absent from the handoff; the owner has chosen to identify omissions as encountered.

## Independent edge-case lens

These are review findings, not automatically accepted requirements. The JSON version retains the lens's proposed guard sketches, which are design proposals except where explicitly resolved below.

### E-01 — Contract completion

**Location:** Handoff Functional namespace and context; ECS 7.2.

**Trigger:** An intake agent needs to publish consolidated semantic refinements.

**Consequence:** Agents lack a specified reasoning-facing path to create or refine the functional map.

**Disposition:** The semantic intake/change operation is already required. Complete its schema with the owner; do not reopen the reasoning or namespace model.

### E-02 — Correction recorded as D-19

**Location:** ECS 5.2 Place-context query.

**Trigger:** A visible_up attachment is located directly at the requested namespace or incident Join.

**Consequence:** Overview-only instructions and tools enter the applying harness catalog.

**Disposition:** Exclude overview-only attachments from applying projections even at the selected node or incident Join. Add AC-04 coverage; original query remains preserved.

### E-03 — Contract completion proposal

**Location:** ECS 7.2 Native tool presentation and invocation.

**Trigger:** A provider changes its tool schema after projection but before invocation.

**Consequence:** Arguments prepared against an earlier schema reach a changed native operation.

**Disposition:** Define version-aware invocation outcomes. The suggested stale_catalog identifier is a reviewer sketch, not an adopted API error name.

### E-04 — Contract completion proposal

**Location:** ECS 10.5 Concurrent contributions.

**Trigger:** A mutation succeeds, its response is lost, and the caller retries its operation ID.

**Consequence:** A retried contribution can create duplicate refinements or apply the same change twice.

**Disposition:** Specify retry/idempotency behavior using the baseline operation ID. Exact outcome-record storage is a proposed mechanism.

### E-05 — Contract completion proposal

**Location:** ECS 10.3 Delivery and retention.

**Trigger:** The harness loads a revised imperative skill while retaining its earlier revision.

**Consequence:** Contradictory skill revisions remain simultaneously authoritative in retained context.

**Disposition:** Specify how changed imperative skill versions supersede earlier retained instructions without pretending old bytes were erased.

### E-06 — Contract completion proposal

**Location:** ECS 9.3-9.4 and 10.3 Event delivery across handoff.

**Trigger:** A context hands off after advancing its journal cursor with events still pending or unknown.

**Consequence:** The successor skips undelivered events or independently repeats submissions with uncertain outcomes.

**Disposition:** Specify cursor, pending and uncertain delivery transfer together during handoff. Do not assume exactly-once model execution.

### E-07 — Contract completion proposal

**Location:** ECS 9.2 Durable event target identity.

**Trigger:** An event waits while its target Address is removed or reused in another snapshot.

**Consequence:** The event reaches an unrelated current element or becomes silently stranded.

**Disposition:** Specify routing of a queued event against its original target version and an unavailable/refined target.

### E-08 — Contract completion proposal

**Location:** Handoff Agent lifecycle and orchestration.

**Trigger:** A selected worker context becomes ineligible, retires, or hands off before assignment delivery.

**Consequence:** Work remains assigned to an unreachable context or executes in both predecessor and successor.

**Disposition:** Specify assignment delivery when the selected context changes eligibility or hands off. This is coordination mechanics, not a new authorization gate.

### E-09 — Contract completion proposal

**Location:** Handoff Context delivery and mailboxes.

**Trigger:** Delivery stops between clearing node pending state and recording the consuming agent's receipt.

**Consequence:** A mailbox notice disappears without a recoverable consuming-agent record.

**Disposition:** Specify recoverable node/agent receipt updates. Exact delivered/read/acknowledged behavior remains the focused inbox contract.

### E-10 — Failure-recovery proposal

**Location:** ECS 9.1-9.3 Local reflex to durable journal.

**Trigger:** Persistence is unavailable during a crossing and the bridge restarts before journaling.

**Consequence:** The reflex runs, but its incident and triggering frame never reach the agent.

**Disposition:** Consider the interval between local action and durable journaling; retain the local-action independence requirement.

### E-11 — Contract completion proposal

**Location:** ECS 8.2-8.4 Observation calibration reference.

**Trigger:** Calibration changes before a retained incident frame is subsequently interpreted.

**Consequence:** Historical depths are reconstructed using different rays, orientation, or mounting transforms.

**Disposition:** Pin calibration used by retained observations. General source-version/provenance requirements already exist.

### E-12 — Device-profile consideration

**Location:** ECS 9.1 Fresh-source evaluation and quality events.

**Trigger:** A source stops advancing sequences without publishing an unavailable observation.

**Consequence:** The controller retains its previous sensing state indefinitely without reporting lost observations.

**Disposition:** Stale sensing behavior belongs in the device profile. A watchdog mechanism is not adopted as a new universal policy or polling loop.

### E-13 — Contract completion proposal

**Location:** ECS 11.4-11.6 Section reuse.

**Trigger:** Recomposition changes the requested audience while source fingerprints, outline, and cross-references remain unchanged.

**Consequence:** Reused sections retain explanations and journeys unsuitable for the newly requested audience.

**Disposition:** Include document audience/kind and producer/prompt version in section-reuse eligibility; exact cache realization remains architecture detail.

## Independent structure lens

The lens used a concise entry contract for task orientation and a detailed reference companion for full technical recovery. It recommended preserving all functional material; estimated content reduction was zero words.

| Recommendation | Disposition in consolidation |
| --- | --- |
| Put governing intent and binding corrections before implementation detail | SPEC.md and decisions.md precede the adopted technical companion |
| Present semantic intake, retrieval and public operations before DDL/Cypher | agent-interface.md provides that reading order; original source sections remain intact |
| Gather navigation to distributed delivery/retention/wake rules | lifecycle-and-delivery.md unifies these contracts and links back through traceability |
| Expose the distinction between source fixture checks and integration evidence | This report and acceptance.md state the boundary before acceptance claims |
| Preserve DDL, queries, schemas, fixtures, event traces, decisions and acceptance criteria | Entire original source tree retained; no source passages deleted |

## Next procedural step

Use the existing material to work through one complete semantic intake → functional readback → refinement interaction. Specify its concrete MCP schemas, outcomes and recovery behavior, then align the other retrieval presentations and host delivery bindings. Carry the resulting decisions into the append-only memlog and re-derive the contract. Architecture and story decomposition follow their actual dependencies; no product-brief restart is needed to reconsider already established intent.
