# Design decisions and source precedence

The ECS packet is the rebuild's starting ground truth. The owner's subsequent corrections apply to the affected passages. The handoff supplements that baseline with the recorded orchestration, communication, lifecycle and interface requirements. Legacy source can explain a mechanism or expose a missing consideration; it does not supply the rebuild's requirements automatically.

The supplied paper, technical specification and contracts are retained verbatim under `sources/ecs/`. Read their implementation prescriptions with the corrections below. The original packet's review labels remain historical source text; they do not reopen the owner's adoption of the baseline or LadybugDB selection.

| Decision | Contract | Source |
| --- | --- | --- |
| D-01 | LadybugDB and Cypher are selected, informed backend choices; complete their contracts rather than reopen the database choice. | user-directions: Design corrections; ECS 1,4 |
| D-02 | The rebuild is specified before implementation; the detailed agent-facing MCP surface is co-engineered with the owner from the ECS baseline. | user-directions: Design corrections |
| D-03 | Reasoned messages and events, including an assignment delivered to an eligible agent, are allowed. Do not implement continual live logging or broadcast every ticket/status change into agent harness contexts. | user-directions: Design corrections |
| D-04 | Namespace hierarchy and intake reasoning are compatible, distinct concerns. Preserve the reasoning procedure while engineering semantic MCP interactions rather than database-tool choreography. | user-directions: Design corrections; handoff 01: Functional namespace and context |
| D-05 | Preserve the exact functional semantics and formula C(T) = { (r_i ∧ p_i ∧ e) }; OP and EF remain in receiver-owned Joins, and specification Objective Purpose remains distinct. | ECS paper 4-7; technical 2 |
| D-06 | Provide local functional, global functional without ancillary layers, and local knowledge-rich retrieval without dumping neighbors' knowledge; full-map startup delivery is not required. | handoff 01: Functional namespace and context |
| D-07 | Deliver unchanged material once per agent context epoch and changes as deltas. Discovery, body delivery, skill loading and retention are distinct states. | handoff 01: Context delivery; ECS technical 5.4,7.3,10 |
| D-08 | Support both agent and namespace-node inboxes; keep consumption traceability at the node and consuming agent, distinct from durable semantic memory. | handoff 01: Context delivery and mailboxes |
| D-09 | Team size and composition are reasoned with user preferences; there is no fixed two-agent minimum. | handoff 01: Agent lifecycle and orchestration |
| D-10 | Useful completed workers remain dormant and reusable. Cache economics depend on measured model/harness behavior, not a universal five-minute expiry or an invented 40% cutoff. | handoff 01: Agent lifecycle; handoff 04:3 |
| D-11 | Preserve deterministic logical identity, conversation and commit history across contexts. Historical agents remain addressable. Preserve intended self-handoff around 50% with graduated warning and later enforcement around approximately 65%; reconcile actual harness measurements. | handoff 01: Agent lifecycle; ECS technical 10 |
| D-12 | Peers see others' aggregate reputation, never their own score or identifiable reviewers/specific reviews. Preserve history in aggregation. The two-cycle lowest-score rule retains its recorded proposed status. | handoff 01: Peer reputation; handoff 04:1-2 |
| D-13 | Use explicit dynamic blacklists where restrictions are configured; add no inferred whitelist, hierarchy or mandatory reviewer/approval pipeline. | handoff 01: Governing intent; ECS triage |
| D-14 | Preserve native skill/tool payloads, explicit source versions, independent participant contexts and transparent harness capability limits. | ECS technical 3,5,7,10 |
| D-15 | ICE Blocks keep indivisibly coupled contracts in the same work unit/worktree while permitting multiple contributors. | ECS paper 4.4; technical 6 |
| D-16 | Keep durable events and incident frames separate from latest sensor state; local reflexes do not wait for MCP or model execution. | ECS technical 8-9 |
| D-17 | Recompose documentation from immutable source cuts with provenance and atomic completed output replacement; routine refresh does not invent requirements or automatically change code. | ECS technical 11 |
| D-18 | MCP events are the forward direction; compatible local messaging remains usable. A2A is not required as a local replacement. | handoff 01: Context delivery and mailboxes |
| D-19 | Applying context projection excludes visible_up-only attachments even when attached directly to the selected namespace or incident Join; overview retrieval retains them. This corrects the query to its stated scope semantics. | ECS technical 5.1-5.2; BMAD edge-case finding 2 |

## Semantic invariants

**C(T) = { (r_i ∧ p_i ∧ e) }**

The exact relational identity account, mutation/transformation distinction, type-level Addresses and receiver-owned purpose records remain as specified in ECS paper sections 3–7 and technical section 2. Namespace ancestry, functional Joins and geometric proximity are distinct relationships. Entity/element perspective changes and RE/PE participation do not create duplicate identities. A provider's EF for a receiving encounter stays in the RE-owned Join; Objective Purpose remains a specification-layer field.

LadybugDB persists the functional graph. Bevy ECS and Resources can realize a virtual execution adapter; neither the functional graph nor a physical adapter thereby becomes an ECS runtime. Knowledge selection controls presentation and application scope, with explicit direct access preserved.

## Superseded interpretations

The earlier assistant classifications of LadybugDB as open, event-driven orchestration as conflicting with communication requirements, and intake versus a consolidated interface as a semantic conflict are retracted. The absent original voice transcript does not block progress from the supplied handoff. An incomplete draft schema indicates engineering work; it does not establish that the owner has left the product behavior undecided.
