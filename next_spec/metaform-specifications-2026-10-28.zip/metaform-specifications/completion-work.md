# Remaining specification work

This is a focused completion queue for the adopted baseline. It does not reset the design or make the whole specification wait on every detail.

## Next co-engineering unit

Complete the semantic intake/change contract together with its readback. Work from the existing domain objects and reasoning procedure. Specify concrete input/output schemas, related-object submission, references, revision behavior, mechanical errors and continuation. Then connect the three required retrieval presentations to the existing navigation/inspection/read draft. The success test is an agent expressing and revising functional understanding without doing database bookkeeping.

| Work | Already established | Detail to complete |
| --- | --- | --- |
| Intake/refinement | Semantic objects, recursive reasoning/revision, consolidated application and selected backend | Public schemas and change result/error semantics; exact operation shape |
| Retrieval | Three presentations, bounded local knowledge and separate move/inspect/read intent | Mode shape, pagination, full functional readback and source-version response fields |
| Catalog/host binding | Named surfaces, native payloads, independent context identity and adapter fallback | Full schemas and each target harness's actual binding/capability behavior |
| Assignments and events | Purposeful events and eligible-agent assignments allowed; no harness live logging | Assignment lifecycle/duplicate handling, durable orchestration event payload and host delivery behavior |
| Inbox receipts | Agent/node inboxes and retained traceability | Delivered/read/acknowledged transitions and recipient coverage |
| Handoff and retention | Once per epoch, deltas, retained skills, logical identity and intended thresholds | Exact compaction boundary/receipt transition in each supported harness |
| Reputation | Anonymous reviews, no self-score visibility and history-respecting aggregates | Formula, assessment cycles/ties and disposition of the recorded proposed retirement rule |
| Storage publication | LadybugDB, schema and derived topology | Engine-executed query fixtures and failure/concurrency demonstrations |
| Legacy knowledge recovery | New specification drives the rebuild | Source-attributed prompt inventory and targeted mechanism/gap sweep, without bulk code migration |

The sensor-shaped event schema supplied in the packet remains intact. Assignment and peer-communication events need their own documented payload semantics; a general orchestration event should not acquire fabricated sensor evidence merely to fit that profile.

## Dependency order

1. Stabilize semantic object/change/read contracts and their acceptance examples against the adopted ECS model.
2. Complete architecture boundaries for graph publication, context projection, native MCP/host integration and delivery records.
3. Complete assignment, inbox, lifecycle and reputation contracts without reopening established behavior.
4. Review the resulting coherent specification and targeted legacy extraction for actual omissions.
5. Use BMAD architecture/epic/story planning once the corresponding contracts can support independently verifiable implementation slices. Keep ICE-coupled interfaces together.

No implementation story is declared ready merely because the baseline is consolidated. No speculative formula, retirement default or unverified harness capability is silently filled in.
