# Agent lifecycle and context delivery

## Purposeful events and diagnostic logging

Messages and events are available mechanisms for agent-directed work and reasoned orchestration. An assignment system message to an eligible worker, a peer discussion, a response to a question, a continuation or a relevant event-driven action is allowed. The system must not continuously mirror every agent's ticket activity, progress and point-by-point status into the user-facing agent's or workers' harness contexts.

The distinction concerns the implemented delivery path and its purpose, not a general ban on informational content or event types. Requested context, a deliberate agent communication and a useful orchestration event remain usable. Do not implement a new content classifier, event allowlist or approval hierarchy to enforce this distinction. Diagnostic observation and persistence remain useful without becoming an automatic model turn.

MCP notification delivery, host processing, context preparation and a host-started ACP turn are distinct actions. Preserve the ECS event/command outcome semantics, including pending work for a busy agent, arrival returned from its navigation call and explicit unknown outcomes after uncertain submission. Assignment eligibility and duplicate-delivery handling need concrete runtime contracts; broad event-driven orchestration is already settled.

## Context epochs and retained skills

Unchanged context is delivered once per agent context epoch, and changed information is supplied as deltas. Discovery does not imply a delivered body, and a delivered body does not imply skill loading or comprehension. Loaded skills remain with the context as the agent moves. Observed compaction and deliberate handoff establish explicit continuation/retention behavior; where a harness cannot reveal retained context, record that limit.

A handoff preserves logical identity and carries the work's goal, progress, decisions, revisions, event cursor and artifact/worktree/skill references. The successor acquires the skill bodies it needs rather than inheriting an assumed copy of every predecessor instruction. Preserve the handoff's intended approximately 50% self-handoff point, graduated warning and later enforcement around approximately 65%, using actual harness capacity where exposed. Do not replace these with unrelated thresholds. Unknown capacity is explicit.

## Reuse, selection and history

Workers finishing an assignment can stay dormant and eligible for later work while their retained context is useful. Selection accounts for measured model/harness cache economics and consumption; it does not impose a universal five-minute lifetime. Runtime retirement preserves historical identity, conversations, commits and reference access. An independently proceeding fork gets its own identity and parent provenance.

Team size/composition respects user preferences and the work. Full Auto can choose one worker, a pair or a differentiated team. Reciprocal review is a useful pattern, not a compulsory two-agent minimum. Exact identity generation and name collision handling follow ECS technical section 10.2.

## Inboxes and durable understanding

Each agent and namespace node has an inbox. Nodes can retain notices for an appropriate subsequent visiting agent; read/consumption records are retained at the node and consuming agent for traceability. A pending notice is distinct from durable semantic memory. Preserve sender/target identity, source attribution, reply and causation references.

The public contract must spell out delivered, read and acknowledged transitions, duplicate/retry behavior and recipient coverage. The existing handoff identifies these details for completion; the presence of inboxes and retained traceability is already settled. An arbitrary context read must not silently be labeled human comprehension or skill loading.

## Peer reputation

Peers assess practical work, quality, critical review and communication. Agent-visible data exposes other agents' aggregates, not the viewing agent's own score, reviewer identities or specific reviews. Aggregation preserves meaningful history so one low result does not arbitrarily erase an established record. The proposed two-consecutive-lowest retirement mechanism retains its proposal status pending the specific details recorded in the handoff; it must not interrupt current work by an invented default.
