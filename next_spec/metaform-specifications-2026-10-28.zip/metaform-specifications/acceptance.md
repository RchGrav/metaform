# Acceptance contracts

These are spec-derived demonstrations for the rebuild. The packet's reported sixteen fixture/reference checks remain attached under `sources/ecs/verification`; they are not runtime acceptance results.

## AC-01 — Functional understanding

Inspect a provider used by two receivers and demonstrate separate receiver-owned OP/EF records, stable Address identity, refinement history and the unchanged exact formula.

## AC-02 — Semantic intake and change

Demonstrate a semantically coherent intake change and subsequent revision through the public MCP interface; inspect the model-visible calls and prove no query or graph-table bookkeeping was required.

## AC-03 — Functional navigation and retrieval

Compare all three retrieval presentations on a node with providers, receivers and large neighbor knowledge; moving and nonmoving reads preserve their advertised presence behavior.

## AC-04 — Knowledge layers

Exercise unspecified/empty selection, hide/restore on a leaf, derived-source hiding and a sibling query. Attach visible_up-only instructions/tools directly at the selected node and its incident Join; verify their overview visibility and absence from applying context/catalog. Preserve stored content.

## AC-05 — Native tools and skills

Compare two participants at the same place/view/revision; test provider-name collisions, exact native schemas, skill manifests/digests and a host without native projection.

## AC-06 — Context continuity

Read a body, navigate away/back, change its source version, compact and hand off; record what was actually delivered/loaded/retained rather than infer retention from discovery.

## AC-07 — Addressed communication

Leave a node notice, visit with appropriate agents, retry delivery and inspect the retained node/agent records; use the completed receipt contract to distinguish delivery/read/acknowledgment.

## AC-08 — Event-driven orchestration

Assign work to an eligible dormant agent, exchange peer messages and process a purposeful event. Generate many unrelated ticket/progress updates and inspect the rendered harness payload/model-call records for absence of automatic live-log traffic.

## AC-09 — Coupled work composition

Compose overlapping ICE Blocks and independent tasks; show coupling is preserved in one work unit/worktree without an automatic branch merge or exclusive agent ownership.

## AC-10 — Persistent agent lifecycle

Complete, reuse, hand off, fork and retire runtime selection; verify identity/history and historical contact continuity, measured cache evidence and the recorded context thresholds.

## AC-11 — Peer reputation

Query reputation from different agents; verify viewing-agent self-score exclusion and reviewer anonymity, and exercise history-respecting aggregation once its exact arithmetic is recorded.

## AC-12 — Consistent persistent state

Publish a refinement while another participant reads; verify snapshot consistency and derived topology. Submit an incompatible stale-revision edit and demonstrate preservation of both contributions.

## AC-13 — Recoverable event delivery

Disconnect between sensor/event changes and reads, reconnect/replay, duplicate notifications and crash after ACP submission; distinguish stable event identity, cursor progress and unknown model/command outcomes.

## AC-14 — Spatial observations and local response

Validate both physical/virtual observation profiles; test an oblique ray against a perpendicular wall, center/corner orientation, invalid/no-return zones and disconnected-model local reflex behavior.

## AC-15 — Revision-bound documentation

Recompose against immutable commits; test semantic changes, file renames, external pinned/live resources, missing source records and a failed section; preserve provenance and prior complete output.

## AC-16 — Observable operation

Report preparation/maintenance/execution cost separately, repeated bytes/model calls and p50/p95/p99 boundary timings from observed runs; identify harness integration and hardware evidence independently.
