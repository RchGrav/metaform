# Agent-facing MCP contracts

The agent interacts with meaningful functional objects, receiving purposes, provider contributions and contextual material. The backend maps those interactions to the ECS graph schema, derived ancestry/incidence, persistent versions and transactions. Those storage responsibilities do not become the agent's workflow.

## Namespace and intake

An Address supplies a functional type and a navigable place. The intake procedure supplies the reasoning used to establish what belongs there, which receiving purpose is served and how the provider contributes. Traversing type ancestry is distinct from tracing a functional relationship; neither traversal substitutes for the other.

Intake supports establishing understanding, following receiving-purpose relationships recursively, revising provisional records, closure, annealing and proof. A compact semantic submission can contain the related objects needed to express a coherent change. It need not translate every reasoning step into a storage command, nor require the entire map to be held until a final submission. The public schema and change outcomes are the next co-engineering contract; no new final tool name or payload is silently adopted here.

The interface preserves meaningful Addresses, canonical names, roles, OP, EF, IFD and references. Backend storage keys, table layout, closure edges, publication sequencing and Cypher construction are handled behind it. Readbacks show the resulting functional understanding and any unresolved correspondence. Mechanical/schema consistency does not become code that grades an agent's semantic judgment.

## Existing ECS operation draft

These are the operation names and responsibilities already supplied in ECS technical section 7.2, not a newly invented catalog.

| Operation | Agent intent | Required result |
| --- | --- | --- |
| `metaform_go` | Go to a functional Address | Place descriptor and arrival context; update this context's presence |
| `metaform_inspect` | Examine an Address without moving | Context projection with source versions and explicit continuation |
| `metaform_read` | Obtain a referenced body or range | Native payload, actual revision/digest and declared continuation |
| `metaform_agents` | Find project participants | Agent identities and contact references, paginated where needed |
| `metaform_message` | Communicate with an addressed target | Stored message reference and its delivery event |

ECS table inputs include project/context references, Address, snapshot/view and cursor as applicable. The host binding and full JSON input/output/error schemas must be completed so agents are not asked to reconstruct runtime or database identity. Native provider tools keep their schemas and execution meanings; collisions retain the stable provider/native-name mapping described in the baseline.

## Three retrieval presentations

| Presentation | Contents | Boundary |
| --- | --- | --- |
| Local functional | Selected element, its receiving/provider relationships and their functional meaning | No automatic expansion into neighbors' attached knowledge |
| Global functional | Compact functional map | Ancillary knowledge layers are omitted; startup need not fetch this view |
| Local knowledge-rich | Selected element's attached knowledge with its direct functional relationships | Keep neighbors' knowledge out of the response |

The exact common tool/mode shape remains co-engineering work. These presentations are already required. Responses distinguish an unknown Address, a known empty result and a partial result. Explicit reads return the requested content or identify the range/continuation; a summary does not silently replace the requested body.

## Context projection and native integration

Layer selection follows the supplied mask/select semantics, including unspecified versus empty selection and branch-local restoration. OP/EF and specification-to-skill/tool bindings are prepared from functional evidence; Cypher retrieves those bindings rather than inferring their meaning on every visit. The context envelope retains attachment reasons and actual source versions.

Named place surfaces and the harness projection adapter preserve stable catalog semantics. A host without native tool projection can use the described stable navigation/read/invocation adapter while reporting that presentation accurately. Availability, resource-body delivery, skill loading and retention are separate records. No fabricated skill-read receipt is a prerequisite to tool invocation.

Applying projections must exclude `visible_up`-only attachments even at the selected node or its incident Join. The original query's `lineage.hops = 0` branch otherwise admits them. Apply an explicit `attachment.scope IN ['local', 'descendants']` condition to both applying-query branches in addition to their ancestry conditions; retain `visible_up` material in the overview path. This is D-19, a correction to implement the baseline's stated scope distinction. The source query remains preserved for traceability.

## Complete interactions

1. An agent surveys a specification or AUE, reasons about its functions and records related semantic objects. It inspects the resulting functional view, refines it and proofs the map without manipulating graph tables.
2. An agent goes to an Address and receives bounded orientation and descriptors. It reads the relevant specification or skill body once; movement changes local discovery while retaining loaded skills in that context.
3. A participant inspects a neighboring receiver's functional relationship without receiving that neighbor's whole knowledge collection. It explicitly reads additional material only as needed for its work.
4. A host projects an assignment's place for an eligible worker, supplies the assignment and appropriate continuation/context, and records the actual delivery. Routine diagnostic records remain available outside automatic model-context streaming.
