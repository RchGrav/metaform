# Specification archive provenance

This export contains the current authored Metaform specification and reviews:
16 capabilities, 19 traced decisions and 16 acceptance contracts. It preserves
the owner's settled corrections in decisions.md. Review suggestions retain
their recorded proposal status except for the explicit D-19 scope correction.

The detailed ECS paper, technical specification and contracts are copied from
the existing repository archive at ecs/Inference-Metaform-ECS-Terminology-Review.zip,
commit 75302f8fa577f5729abe47ba21a19c358ce3d20f. The export verifies those bytes
against the specification workspace's adopted companion files.

Raw conversation sources, the original uploaded handoff ZIP, the private Page
export and BMAD workflow/runtime files are not included. Their consequential
requirements are represented in the authored specification, decisions and
traceability documents. The specification frontmatter's audit-only sources
list points here for this export; its capability and contract text is unchanged.
The full decision log remains in the original BMAD specification workspace.

The completeness review describes the source-preservation checks performed on
that full workspace. This repository archive is the specification-document
subset; it does not claim to bundle the private source history or workflow data.

Read SPEC.md, then decisions.md and the listed companions. Continue with the
semantic intake -> functional readback -> refinement interaction described in
completion-work.md. This is a working baseline for co-engineering, not a claim
of completed implementation or runtime acceptance.
