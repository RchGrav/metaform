# PART 3 — System Architecture & Data Schema Specification

**Inference Metaform · Working specification 1.0 · October 27, 2026**

## 1. Scope and normative meaning

This specification defines a language-independent implementation of functional intake records, contextual layers, place-based context projection, skill delivery and retention, event-driven agent turns, spatial observation adapters, and revision-bound specification/documentation composition. The selected graph database is LadybugDB; Cypher is its query interface. Implementation languages and process packaging remain implementation choices.

“Must” describes an observable contract of the proposed system. “Reference profile” identifies a concrete selected realization. “Design decision” identifies completion of an underspecified point, not a claim that the source already implements it. Source-backed protocol behavior is cited by specification section; unexecuted integration claims are identified in Section 14.

The system supports multiple human and agent participants in a shared project. Participant identity is used for attribution, delivery, and continuity, not context selection. Identical place, view, and revision inputs produce identical available context and tools for every participant. An agent can inspect or navigate to any Address and can address any other agent. Messages at elements and Joins are ordinary addressed records.

The functional core ends at the context, operation, event, and adapter contracts. Existing harnesses retain their own execution behavior. A multiplayer game, screen-sharing application, team-management product, and implementation migration are not defined here.

## 2. Canonical semantics and source normalization

### 2.1 Identity and terminology

An Address identifies an element within a map. The project and map revision disambiguate the same Address in different AUEs or editions. A storage key identifies a stored version; it does not replace the Address's semantic role.

An element can be examined as an entity without duplication. RE and PE are relationship positions. A purpose Join has one RE, an Operative Purpose, an Encounter Function, an information flow direction, and one or more contributing PEs. A combined encounter can include several elements; this does not create several global EFs on one provider.

The specification-layer `objective_purpose` field remains separate from the Join's `purpose` field. The latter is always OP. No field named `objective_purpose` is aliased to OP. Specifications attach to their receiving element or Join; `SPECIFIES` records the Join they elaborate.

A CEL is a contextual knowledge layer, not a new base-map identity system. AT, NS, DE, SE, NE, parametric, ICE, and Block retain the definitions in the supplied Canonical Intake. `SE` means substantial element. The five artifact roots and the two external-reference roots are distinguished rather than repeating the intake's inconsistent numerical phrase “five” before seven names.

### 2.2 Input adapters

The intake adapter flattens repeated XML references by Address while preserving nested contribution relationships. It reads legacy `function` as the source's EF text when that field is the descriptive encounter; it preserves the original field/value in source provenance. It normalizes `send`/`receive` to `sends`/`receives`, with `both` unchanged. Legacy observation, relation, reference, and non-goal fields become source or knowledge items associated with the same receiver-owned Join.

A historical categorical EF marker, such as `Function` or `Encounter`, is retained as source metadata rather than replacing the descriptive EF. Unresolved references are recorded with their source location and shown as unresolved. No additional element is inferred merely to satisfy an importer's missing reference.

New canonical intake and refinement operations record functional meaning directly. Import compatibility does not rewrite the authored intake procedure.

### 2.3 Snapshot and live-state separation

`MapSnapshot` identifies a consistent published set of base records and contextual attachment descriptors. Its `commit_oid` can be null for live work not yet bound to a Git commit. A refinement produces a new snapshot or a storage-equivalent versioned view; earlier referenced snapshots remain readable.

Mutable conversations, current task status, presence, delivery records, and live observations reside in `RuntimeRecord` or the native provider. A graph attachment can point to such a record. Its read response supplies the actual runtime revision. An immutable graph descriptor is not falsely represented as freezing an external live resource.

Every context response records `snapshot_key` and the runtime revisions actually resolved. A commit-bound composition uses only committed exports, unless its request explicitly names an additional runtime cut.

## 3. Functional components and interaction contracts

| Component | Inputs | Outputs and responsibility |
|---|---|---|
| Intake/refinement producer | AUE, specification/source references, current map | Elements, receiver-owned Joins, explicit ICE membership, findings, source references |
| Graph store | Canonical records and layer attachments | Transactionally consistent graph reads and versioned published views |
| Context projector | Project, Address, snapshot/view, explicit layer selection | Orientation, contextual catalog, source/version references, continuation cursors |
| Composer | Specification revision and functional map | Tickets and work units linked to receiving outcomes and target Addresses |
| Facilitator | Work unit, relevant OP/EF, specification Objective Purpose, existing skills | Reused or newly authored skill, native tool references, recorded functional bindings |
| Protocol adapter | Projected descriptors and native providers | MCP tools/resources/skills and change notifications |
| Harness adapter | Context envelope, event journal, delivery ledger | Host tool projection, retained skill segment, ACP turns, handoff records |
| Spatial adapter/controller | Simulation state or native sensor results; motion goals | Normalized observations, local reflex effects, incident events, command status |
| Documentation compositor | Frozen graph export, source commits, prior document | Standalone specifications, declarative documentation, user journeys, source manifest |

Each component reports its own result. A stored tool call is not evidence that a device acted; a fetched descriptor is not evidence that a skill body was loaded; a composition run's existence is not evidence that a document was completed.

## 4. LadybugDB data schema

### 4.1 Tables and keys

The full DDL is supplied in `contracts/graph.cypher`. The following is the complete table definition, not Neo4j constraint syntax. Ladybug's documented `CREATE NODE TABLE` and `CREATE REL TABLE` support these typed endpoints, including multiple endpoint pairs. Relationship identities are application-maintained because relationship tables do not have user-defined primary keys. [Ladybug: Create table — Primary key; Create a relationship table.]

```cypher
CREATE NODE TABLE MapSnapshot(
  key STRING, project_id STRING, repository_id STRING, commit_oid STRING,
  manifest_digest STRING, parent_key STRING, created_at STRING, state STRING,
  PRIMARY KEY(key));
CREATE NODE TABLE Namespace(
  key STRING, snapshot_key STRING, address STRING, depth INT64,
  PRIMARY KEY(key));
CREATE NODE TABLE Element(
  key STRING, snapshot_key STRING, address STRING, name STRING,
  name_length INT64, role STRING, PRIMARY KEY(key));
CREATE NODE TABLE PurposeJoin(
  key STRING, snapshot_key STRING, stable_id STRING, purpose STRING,
  ef STRING, ifd STRING, PRIMARY KEY(key));
CREATE NODE TABLE IceBlock(
  key STRING, snapshot_key STRING, block_number STRING, explanation STRING,
  PRIMARY KEY(key));
CREATE NODE TABLE Layer(
  key STRING, snapshot_key STRING, stable_id STRING, name STRING,
  variable STRING, kind STRING, state STRING, mutable BOOL, hidden BOOL,
  PRIMARY KEY(key));
CREATE NODE TABLE ContextItem(
  key STRING, snapshot_key STRING, stable_id STRING, revision STRING,
  kind STRING, name STRING, summary STRING, content_role STRING,
  payload_mode STRING, payload_json STRING, payload_uri STRING,
  native_schema_uri STRING, content_digest STRING, byte_length INT64,
  objective_purpose STRING, PRIMARY KEY(key));
CREATE NODE TABLE RuntimeRecord(
  key STRING, project_id STRING, kind STRING, revision INT64,
  payload_json STRING, PRIMARY KEY(key));

CREATE REL TABLE IN_SNAPSHOT(
  FROM Namespace TO MapSnapshot, FROM Element TO MapSnapshot,
  FROM PurposeJoin TO MapSnapshot, FROM IceBlock TO MapSnapshot,
  FROM Layer TO MapSnapshot, FROM ContextItem TO MapSnapshot);
CREATE REL TABLE AT_ADDRESS(FROM Element TO Namespace);
CREATE REL TABLE PARENT(FROM Namespace TO Namespace);
CREATE REL TABLE ANCESTOR(FROM Namespace TO Namespace, hops INT64);
CREATE REL TABLE OWNS(FROM Element TO PurposeJoin);
CREATE REL TABLE PROVIDED_BY(FROM PurposeJoin TO Element);
CREATE REL TABLE CONTAINS(FROM Element TO Element);
CREATE REL TABLE MEMBER_OF(FROM Element TO IceBlock);
CREATE REL TABLE INCIDENT(FROM Namespace TO PurposeJoin, side STRING);
CREATE REL TABLE IN_LAYER(FROM ContextItem TO Layer);
CREATE REL TABLE DERIVED_FROM(FROM Layer TO Layer);
CREATE REL TABLE SPECIFIES(FROM ContextItem TO PurposeJoin);
CREATE REL TABLE SUPPORTS(FROM ContextItem TO ContextItem);
CREATE REL TABLE USES_TOOL(FROM ContextItem TO ContextItem);
CREATE REL TABLE DEPENDS_ON(FROM ContextItem TO ContextItem);
CREATE REL TABLE HAS_SKILL(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE OFFERS(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE HAS_TASK(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE HAS_SPEC(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE HAS_DOC(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE HAS_MEMORY(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
CREATE REL TABLE HAS_ITEM(
  FROM Namespace TO ContextItem, FROM PurposeJoin TO ContextItem,
  attachment_key STRING, scope STRING);
```

Storage keys are SHA-256 digests of length-prefixed UTF-8 `(snapshot_key, table_kind, logical_identity)` values. Namespace and element logical identity is the Address; Join, layer, and item logical identities are stable record IDs. Runtime keys include project and record kind. This makes primary-key lookup possible without treating an opaque digest as the element's semantic name.

A `Namespace` prefix can exist for navigation and inherited context without claiming an additional independently significant element in the intake. `Element` contains the actual DE/SE/NE/CQU records. `CONTAINS` records represented composition, not namespace ancestry and not ICE membership.

### 4.2 Record meanings

`Layer.kind` and `ContextItem.kind` identify data kinds, not a closed catalog of future layers. The typed relationships above provide the common projections. `HAS_ITEM` carries additional native layer kinds without changing the base ontology.

`content_role` is `informational` or `imperative`. `payload_mode` is `inline`, `reference`, or `query`. Inline content uses `payload_json`; a reference uses `payload_uri`; a query payload identifies its provider, native operation/query, typed arguments, and returned schema. The adapter preserves the provider's payload rather than translating every format into an invented universal skill or tool body.

For a specification item, the payload contains `objective_purpose`, requirements with stable IDs, inputs, outputs, observable behavior, and supporting references. A task payload contains its goal, target Addresses/Joins, specification revisions, Block IDs, work-unit ID, current state reference, and result references. A documentation payload contains the audience, explanation or journey, and source records. A skill payload uses the official skill representation. A tool payload preserves its native name, input schema, annotations, and provider reference.

Source references identify repository, commit/blob or provider revision, path/URI, and line range or structured pointer. `DEPENDS_ON` records declared item dependencies; `DERIVED_FROM` records layer derivation. They do not assert that all semantic dependencies have been discovered.

### 4.3 Derived topology

`PARENT` links each namespace to its immediate prefix. `ANCESTOR` is a materialized transitive closure containing one self-edge with `hops=0` and one edge to every proper prefix. There is no fixed namespace-depth limit.

`INCIDENT` links each actual endpoint's namespace to a purpose Join with `side='receiver'` or `side='provider'`. It is derived from `OWNS`, `PROVIDED_BY`, and `AT_ADDRESS`. A participant therefore discovers the Join from either endpoint while the Join's purpose record remains receiver-owned.

A refinement updates affected derived relationships in the same publication transaction as the source records. The application maintains one closure edge per `(descendant, ancestor)`, one attachment per `attachment_key`, and consistent snapshot references. These responsibilities preserve a consistent data shape.

Ladybug permits concurrent reads and one write transaction. The reference deployment therefore uses one database service with a write queue and read transactions for multi-query projections. The queue serializes storage changes, not agent reasoning or interactive participation. [Ladybug: Transactions — Important properties; Transaction Statement.]

## 5. Context projection and explicit Cypher

### 5.1 Resolve layers before collecting payloads

Let U be the layer IDs in the selected snapshot. When no starting selection is supplied, begin with its selectable finished nonhidden layers. An explicit empty selection is the empty set. Apply namespace-local rules trunk to leaf:

```text
selection_next = (selection_current − locally_masked) ∪ locally_selected
```

This is the set form of the manuscript's mask/select expression. The mask and selection records are project data. Compute the hidden-source dependency closure from recorded `DERIVED_FROM` relationships. The projection's `excluded_layer_keys` is the complement of the resulting participating selection plus that closure. The rules are stored as `RuntimeRecord` entries of kind `layer_selection`, keyed by project, snapshot, and Address, with `masked_layer_keys` and `selected_layer_keys` arrays. Resolve these entries for the ancestry in the same read transaction before running the projection; absent entries are transparent. Snapshot-qualified rule entries remain unchanged with that snapshot. No list is hardcoded into the query.

Scopes are `local`, `descendants`, and `visible_up`. Local material is delivered at its attachment. Descendant material applies from that attachment toward its descendants. `visible_up` material appears in an explicitly requested broader overview; it does not apply to siblings. A direct named read can retrieve material outside the current projection.

### 5.2 Place-context query

Compute `$leaf_key` from the selected snapshot and target Address, and supply the dynamic `$excluded_layer_keys`. This query returns descriptors, not full payload bodies:

```cypher
MATCH (leaf:Namespace {key: $leaf_key})-[lineage:ANCESTOR]->(at:Namespace)
MATCH (at)-[attachment]->(item:ContextItem)-[:IN_LAYER]->(layer:Layer)
WHERE item.snapshot_key = leaf.snapshot_key
  AND layer.snapshot_key = leaf.snapshot_key
  AND layer.state = 'finished'
  AND NOT (layer.key IN $excluded_layer_keys)
  AND (lineage.hops = 0 OR attachment.scope = 'descendants')
RETURN item.key AS item_key, item.stable_id AS item_id,
       item.revision AS revision, item.kind AS kind,
       item.name AS name, item.summary AS summary,
       item.content_role AS content_role,
       item.payload_mode AS payload_mode, item.payload_uri AS payload_uri,
       item.native_schema_uri AS native_schema_uri,
       item.content_digest AS content_digest, item.byte_length AS byte_length,
       at.address AS via_address, '' AS via_join,
       lineage.hops AS namespace_hops, 0 AS join_hops,
       attachment.attachment_key AS attachment_key, layer.key AS layer_key
UNION ALL
MATCH (leaf:Namespace {key: $leaf_key})-[lineage:ANCESTOR]->(at:Namespace)
MATCH (at)-[incidence:INCIDENT]->(j:PurposeJoin)
MATCH (j)-[attachment]->(item:ContextItem)-[:IN_LAYER]->(layer:Layer)
WHERE item.snapshot_key = leaf.snapshot_key
  AND j.snapshot_key = leaf.snapshot_key
  AND layer.snapshot_key = leaf.snapshot_key
  AND layer.state = 'finished'
  AND NOT (layer.key IN $excluded_layer_keys)
  AND (lineage.hops = 0 OR
       (incidence.side = 'receiver' AND attachment.scope = 'descendants'))
RETURN item.key AS item_key, item.stable_id AS item_id,
       item.revision AS revision, item.kind AS kind,
       item.name AS name, item.summary AS summary,
       item.content_role AS content_role,
       item.payload_mode AS payload_mode, item.payload_uri AS payload_uri,
       item.native_schema_uri AS native_schema_uri,
       item.content_digest AS content_digest, item.byte_length AS byte_length,
       at.address AS via_address, j.stable_id AS via_join,
       lineage.hops AS namespace_hops, 1 AS join_hops,
       attachment.attachment_key AS attachment_key, layer.key AS layer_key;
```

For an attachment, functional proximity is the ordered pair `(namespace_hops, join_hops)`. The host sorts by this pair, then kind, stable item ID, revision, and attachment key. It groups duplicate item/revision references while retaining all attachment reasons. Different revisions or contradictory sources remain distinguishable.

This definition separates ancestry from a Join encounter; it does not pretend that geometric meters and namespace hops are interchangeable. A provider is not assumed to be an ancestor. Provider tools relevant to a receiving task are recorded as `OFFERS` at that receiving Join, retaining their native provider references. Merely reaching a provider does not recursively inject all that provider's other tasks and receivers.

The query avoids independent `OPTIONAL MATCH` branches for skills, tasks, specs, and docs, which would multiply combinations before aggregation. Materialized ancestry also avoids an implicit recursion-depth cutoff: Ladybug documents a default upper bound for recursive patterns without an explicit bound. The optimization is structural—primary-key start, prepared closure, descriptor-only rows—not a measured latency claim. [Ladybug: Match — Recursive relationships.]

A separate namespace lookup distinguishes an unknown Address from a known place with an empty catalog. An overview reads descendant attachments with `scope='visible_up'` and labels them informational visibility; it does not add them to the applying harness.

The next stage resolves selected item bodies by primary key. For the native tool catalog it resolves every offered tool's descriptor, including its input schema and annotations; for ordinary arrival text it resolves only the bodies selected for that delivery. Reference/query payloads are then read through their named native provider.

```cypher
UNWIND $item_keys AS selected_key
MATCH (item:ContextItem {key: selected_key})
RETURN item.key AS item_key, item.stable_id AS item_id,
       item.revision AS revision, item.kind AS kind,
       item.payload_mode AS payload_mode, item.payload_json AS payload_json,
       item.payload_uri AS payload_uri, item.native_schema_uri AS native_schema_uri,
       item.content_digest AS content_digest, item.byte_length AS byte_length;
```

This second stage is how descriptor discovery becomes the concrete tool harness. Large skill, specification, and documentation bodies are not fetched merely to build the tool list.

### 5.3 Functional bindings, not prose matching at every visit

The following inspection query exposes the recorded connection between intake and specification terms:

```cypher
MATCH (receiver:Element {key: $receiver_key})-[:OWNS]->(j:PurposeJoin)
MATCH (j)-[:PROVIDED_BY]->(provider:Element)
MATCH (spec:ContextItem)-[:SPECIFIES]->(j)
MATCH (skill:ContextItem)-[:SUPPORTS]->(spec)
MATCH (skill)-[:USES_TOOL]->(tool:ContextItem)
WHERE j.snapshot_key = receiver.snapshot_key
  AND provider.snapshot_key = receiver.snapshot_key
  AND spec.snapshot_key = receiver.snapshot_key
  AND skill.snapshot_key = receiver.snapshot_key
  AND tool.snapshot_key = receiver.snapshot_key
RETURN receiver.address AS receiver, j.stable_id AS join_id,
       j.purpose AS operative_purpose, j.ef AS encounter_function,
       provider.address AS provider, spec.stable_id AS specification_id,
       spec.objective_purpose AS objective_purpose,
       skill.stable_id AS skill_id, tool.stable_id AS tool_id;
```

The facilitator authors or reuses these bindings from the functional evidence. A skill can have no tool dependency, and a specification can have no prepared skill yet; those records remain visible through the main catalog query. The inspection query is not a completeness condition for work.

### 5.4 Context envelope and cache

A projection returns:

```text
project_id; snapshot_key; address; place_key;
orientation {ancestry, active_join, operative_purpose, encounter_function};
work_refs[]; specification_refs[]; skill_entries[]; tool_descriptors[];
document_refs[]; memory_refs[]; message_refs[];
attachment_reasons[]; resolved_runtime_versions[];
page {complete, next_cursor, returned_count}; findings[]
```

`active_join` is nullable; a place can serve several purposes. Other Joins remain in the catalog. Native objects, such as tool descriptors and skill entries, retain their native fields. The envelope is host data: text already supplied through the native tool catalog is not repeated in the turn text, and a retained skill body is not reinjected on every arrival.

Cache keys include snapshot, target, selection digest, provider/catalog revisions, and requested projection shape. Actual content delivery is deduplicated per context/epoch by source URI and content digest. Cache reuse never means that a different context has received the material.

## 6. Tickets, facilitation, and ICE work composition

A composer receives a specification revision and its receiving relationships. It emits tickets with `ticket_id`, `goal`, `objective_spec_refs`, `target_addresses`, `join_ids`, `block_ids`, `work_unit_id`, `state`, `result_refs`, and source provenance. Dependencies express work ordering where the specification establishes it.

For each target element, expand explicit Block membership. Overlapping established couplings form one composed work unit. The unit records all coupled Addresses, the specification revisions in force, the participating tickets and agents, and one worktree reference for software work. Task decomposition can describe sub-contributions within that unit without splitting its shared contract across worktrees. Work without a filesystem uses the same unit without an invented worktree.

The facilitator consumes that unit's functional context and finds or prepares a skill for its task. Its output is the official skill package or a native server skill reference, the specification bindings, and the tool references. General server instructions can remain at the server. Project-specific procedure belongs at the relevant element or receiving Join. Existing skills are reused when they address the work; no duplicate is created solely because another agent arrived.

When a ticket adds functionality, its result identifies corresponding element/Join refinements and contextual updates. A newly discovered coupling emits `block.changed` with the affected work units and source evidence. Existing contributions remain referenced; the work description records how the coupled changes are brought together. The context system does not silently merge code branches.

## 7. MCP and ACP interface realization

### 7.1 Protocol baseline

The reference binding uses **MCP 2026-07-28**, the stable **`io.modelcontextprotocol/skills`** extension, and **ACP v1**. These are explicit protocol choices, not implementation-language requirements.

MCP requests include required `_meta` protocol version and client capabilities. The examples also include client information. Resource reads return `resultType: 'complete'`, `ttlMs`, `cacheScope`, and `contents`, whose JSON payload is carried as resource text. [MCP: Base Protocol — `_meta`; Schema Reference — RequestMetaObject, ReadResourceResult, TextResourceContents.]

```json
{
  "capabilities": {
    "tools": {"listChanged": true},
    "resources": {"listChanged": true, "subscribe": true},
    "extensions": {
      "io.modelcontextprotocol/skills": {"directoryRead": false}
    }
  }
}
```

The capability fragment belongs in the server's `server/discover` result. A legacy transport binding, when implemented, must have its own version-correct adapter; legacy `resources/subscribe` messages are not mixed into this binding.

### 7.2 Place surfaces and tool presentation

A logical MCP place surface has an endpoint identity determined by project, Address, and shared view. It can be served by the same process as all other places. Its tool/resource catalog depends on the place's published data, not the identity or hidden navigation state of a connection.

This matters because MCP 2026-07-28 Tools and Resources explicitly prohibit catalog variation caused by connection-local state or other requests on that connection. Navigation selects another named place surface; changes to a place's actual tool catalog produce `notifications/tools/list_changed`. [MCP: Tools — Capabilities, List Changed Notification; Resources — Capabilities.]

The harness adapter implements `project_surface(context_id, place_key, catalog_revision)`: it obtains the new place catalog and updates the model-facing tool projection while retaining the context's previously loaded skills. This function is a **Metaform host integration contract**, not an ACP method. ACP alone does not establish live MCP-catalog replacement in every existing harness.

A harness lacking native tool-projection support can use a stable navigation/read/invocation adapter. It receives the native descriptors as context, and the invocation adapter forwards the chosen tool's arguments unchanged to its provider. This preserves reachability and native execution, but is identified as a gateway presentation rather than claiming direct per-tool installation in that harness.

Core operations have typed schemas:

| Tool | Input fields | Result |
|---|---|---|
| `metaform_go` | `project_id`, `context_id`, `address`; optional snapshot/view | Place descriptor and arrival context; updates that context's presence |
| `metaform_inspect` | `project_id`, `address`; optional snapshot/view/cursor | Context projection without moving the participant |
| `metaform_read` | Source URI; optional native range/cursor | Native payload, actual revision/digest, continuation |
| `metaform_agents` | Project; optional cursor | Agent identities and contact references |
| `metaform_message` | Target kind and ID, message body; optional reply ID | Stored message reference and delivery event |

Provider tools retain their typed input schema and annotations. A collision between native tool names is resolved by a stable presentation name recorded with `(provider_id, native_name)`; the reference rule is `mf_` followed by the full SHA-256 hex of the length-prefixed pair. The descriptor title retains the readable native name. Invocation resolves that mapping, not a name guessed from the current place.

Annotations describe effects and risks. The projection adds no read-a-skill receipt prerequisite before invoking a tool. [MCP: Tools — Tool, ToolAnnotations, Calling Tools.]

### 7.3 Official skills transport

The extension identifies a skill by its `SKILL.md` URI. `skills/list` lists entries; `skills/get` returns one entry; `resources/read` returns its files. The entry carries verbatim frontmatter and either a complete resource manifest with digests or the extension's dynamic-resource form. This implementation uses complete manifests for stored project skills. [Skills extension: Skill; Listing Skills; Getting a Skill; Reading Skill Files.]

```text
Skill entry:
  uri = skill's SKILL.md URI
  frontmatter = exact parsed frontmatter object
  resources[] = {uri, digest = sha256:<raw UTF-8/file-byte digest>, size}
```

A stored skill version uses version-addressable resource URIs. The latest catalog points to the selected version; loaded content is retained by digest. Native server skills remain native resources. The existing harness's skill-loading path supplies content-identity checks and reports loading; a generic resource read is recorded separately. The extension's host-side integrity and consent responsibilities remain with that harness. Metaform supplies no parallel mechanism and does not claim end-to-end extension compliance from wire shape alone.

`resource://metaform/skills/catalog` is the ordinary resource describing the place's current skill entries. A catalog update uses `notifications/resources/updated`. A host can then announce that a skill became available. It records a loaded skill only after the harness's skill-loading path delivers its body. There is no invented standard `notifications/skills/learned` method.

### 7.4 Subscriptions

The current base uses `subscriptions/listen`, replacing the former resource-subscription RPC. The acknowledgment is a notification, not an ordinary completion response. [MCP: Subscriptions — Opening a Stream, Acknowledgment, Receiving Notifications.]

```json
{
  "jsonrpc": "2.0",
  "id": "sub-front",
  "method": "subscriptions/listen",
  "params": {
    "_meta": {
      "io.modelcontextprotocol/protocolVersion": "2026-07-28",
      "io.modelcontextprotocol/clientInfo": {
        "name": "metaform-context-host",
        "version": "1.0.0"
      },
      "io.modelcontextprotocol/clientCapabilities": {}
    },
    "notifications": {
      "toolsListChanged": true,
      "resourceSubscriptions": [
        "resource://spatial/tof/matrix_8x8",
        "resource://metaform/events",
        "resource://metaform/skills/catalog"
      ]
    }
  }
}
```

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/subscriptions/acknowledged",
  "params": {
    "_meta": {"io.modelcontextprotocol/subscriptionId": "sub-front"},
    "notifications": {
      "toolsListChanged": true,
      "resourceSubscriptions": [
        "resource://spatial/tof/matrix_8x8",
        "resource://metaform/events",
        "resource://metaform/skills/catalog"
      ]
    }
  }
}
```

```json
{
  "jsonrpc": "2.0",
  "method": "notifications/resources/updated",
  "params": {
    "_meta": {"io.modelcontextprotocol/subscriptionId": "sub-front"},
    "uri": "resource://metaform/events"
  }
}
```

The host processes notifications without automatically inserting their entire stream into model context. It reads the event journal and schedules relevant turns. The experimental MCP Triggers & Events work is explicitly exploratory; this specification does not depend on its proposal methods.

### 7.5 Agent wake-up

After ACP initialization and session setup, the harness initiates the event-originated turn:

```json
{
  "jsonrpc": "2.0",
  "id": "wake-17",
  "method": "session/prompt",
  "params": {
    "sessionId": "session-17",
    "prompt": [
      {
        "type": "text",
        "text": "Event source: front-tof. Event: boundary entered; the local reflex stopped motion. Functional target: code.controller.motion. Event record: resource://metaform/events/event-42. The attached place context identifies the receiving purpose, specification, tools, and observations."
      }
    ]
  }
}
```

This example presumes that the named session exists and its host has projected the selected place. ACP does not define the application's target namespace. The harness supplies it through the context envelope. Loading/resuming a prior session depends on the adapter's declared support; retaining a transcript does not guarantee resumability. [ACP v1: Prompt Turn; Session Setup — Creating a Session, Loading Sessions, Resuming Sessions.]

## 8. Uniform spatial observation interface

### 8.1 Resource identity

The canonical resource is:

```text
resource://spatial/tof/matrix_8x8
```

At each place endpoint it denotes that place's declared primary ToF source. This binding is shared and stable, not “the sensor most recently selected by a caller.” Additional sensors have explicit source-specific URIs. An incident's referenced frame uses an immutable URI containing source epoch and sequence.

Both virtual and physical adapters return the same payload schema. The `source.kind` field preserves which realization produced it. The resource describes observation, not a guarantee of clearance or object identity.

### 8.2 Exact payload schema

`contracts/spatial-tof.schema.json` contains the following JSON Schema 2020-12. Unknown extension fields are preserved; the defined fields keep their meanings.

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:metaform:schema:spatial-tof:1",
  "type": "object",
  "required": [
    "schema_version", "source", "sequence", "clock", "frame_id",
    "calibration_uri", "shape", "layout", "distance_semantics", "units",
    "distances_mm", "zone_status", "native_status"
  ],
  "properties": {
    "schema_version": {"const": "metaform.spatial.tof/1"},
    "source": {
      "type": "object",
      "required": ["id", "kind", "epoch"],
      "properties": {
        "id": {"type": "string", "minLength": 1},
        "kind": {"enum": ["physical", "virtual"]},
        "epoch": {"type": "string", "minLength": 1}
      }
    },
    "sequence": {"$ref": "#/$defs/counter"},
    "clock": {
      "type": "object",
      "required": [
        "id", "kind", "capture_ns", "received_ns", "nominal_period_ns"
      ],
      "properties": {
        "id": {"type": "string", "minLength": 1},
        "kind": {"enum": ["monotonic", "simulation"]},
        "capture_ns": {"$ref": "#/$defs/nullableCounter"},
        "received_ns": {"$ref": "#/$defs/counter"},
        "nominal_period_ns": {"$ref": "#/$defs/nullableCounter"}
      }
    },
    "frame_id": {"type": "string", "minLength": 1},
    "calibration_uri": {"type": "string", "format": "uri"},
    "shape": {"const": [8, 8]},
    "layout": {"const": "row-major-top-left"},
    "distance_semantics": {"const": "axial-z"},
    "units": {"const": "mm"},
    "distances_mm": {
      "type": "array", "minItems": 64, "maxItems": 64,
      "items": {"type": ["number", "null"], "minimum": 0}
    },
    "zone_status": {
      "type": "array", "minItems": 64, "maxItems": 64,
      "items": {"enum": ["valid", "no_return", "invalid", "unavailable"]}
    },
    "native_status": {
      "type": "array", "minItems": 64, "maxItems": 64,
      "items": {"type": ["integer", "null"]}
    }
  },
  "$defs": {
    "counter": {"type": "string", "pattern": "^(0|[1-9][0-9]*)$"},
    "nullableCounter": {
      "anyOf": [{"$ref": "#/$defs/counter"}, {"type": "null"}]
    }
  }
}
```

For index `i=8r+c`, `r=0` is the top row and `c=0` the left column, looking outward from the sensor. The optical frame is right-handed: x right, y down, z forward. Sequence counters and nanoseconds use decimal strings to avoid cross-language integer rounding.

`capture_ns` is null when the actual capture time is unavailable. `received_ns` then records local acquisition/read completion; it is not relabeled as capture time. A source restart creates a new epoch. Clock values from different IDs are not subtracted without a recorded clock mapping.

For every zone, `valid` requires a finite nonnegative depth. The other states require null depth. `no_return` means no measured return, not demonstrated empty space. `invalid` preserves a native measurement-quality failure. `unavailable` means no observation for that zone. Raw native codes remain in `native_status`. These cross-field meanings are checked separately from array shape; no zero or maximum-integer placeholder is treated as a measured distance.

### 8.3 JSON-RPC binding

```json
{
  "jsonrpc": "2.0",
  "id": "r-42",
  "method": "resources/read",
  "params": {
    "_meta": {
      "io.modelcontextprotocol/protocolVersion": "2026-07-28",
      "io.modelcontextprotocol/clientInfo": {
        "name": "metaform-context-host", "version": "1.0.0"
      },
      "io.modelcontextprotocol/clientCapabilities": {}
    },
    "uri": "resource://spatial/tof/matrix_8x8"
  }
}
```

The latest-frame result uses zero freshness time. This complete response contains all 64 zones; `text` is JSON serialization of the observation object:

```json
{
  "jsonrpc": "2.0",
  "id": "r-42",
  "result": {
    "resultType": "complete",
    "ttlMs": 0,
    "cacheScope": "private",
    "contents": [
      {
        "uri": "resource://spatial/tof/matrix_8x8",
        "mimeType": "application/json",
        "text": "{\"schema_version\":\"metaform.spatial.tof/1\",\"source\":{\"id\":\"front-tof\",\"kind\":\"virtual\",\"epoch\":\"run-17\"},\"sequence\":\"42\",\"clock\":{\"id\":\"sim-17\",\"kind\":\"simulation\",\"capture_ns\":\"2800000000\",\"received_ns\":\"2800000000\",\"nominal_period_ns\":\"66666667\"},\"frame_id\":\"front_tof_optical\",\"calibration_uri\":\"resource://spatial/tof/front-tof/calibration\",\"shape\":[8,8],\"layout\":\"row-major-top-left\",\"distance_semantics\":\"axial-z\",\"units\":\"mm\",\"distances_mm\":[1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,120.0,120.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,120.0,120.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0,1200.0],\"zone_status\":[\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\",\"valid\"],\"native_status\":[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]}"
      }
    ]
  }
}
```

This is a string-valued resource body, not a new MCP `content` object. The delivery includes a complete serialized request/response fixture with all 64 zones and a round-trip check. Protocol errors use the base JSON-RPC/MCP error form; temporary sensor unavailability can still be represented by the resource's explicit zone states. [MCP: Resources — Reading Resources, Resource Contents; Schema Reference — ReadResourceResult, TextResourceContents.]

### 8.4 Calibration and adapter algorithms

The calibration resource contains source and frame IDs, 64 normalized optical direction vectors, a permutation from native zone order to canonical order, the sensor-to-body rigid transform, native distance convention, sample-model description, and the native quality mapping reference. The permutation contains each integer 0–63 once. Rays have positive z and unit length; the rigid transform uses meters and a normalized quaternion in x/y/z/w order.

For virtual ray direction d_i and hit distance t_i in meters:

```text
axial_depth_mm[i] = 1000 × t_i × d_i.z
point_m[i] = (axial_depth_mm[i] / 1000 / d_i.z) × d_i
```

Thus a perpendicular wall one meter away yields 1000 mm in every valid zone, including oblique rays. Raw slant distances would not satisfy this contract. The reference virtual profile uses the nearest hit along each calibrated center ray. A richer finite-footprint simulator can use another declared sample model without changing the resource schema.

The physical VL53L5CX adapter uses the vendor ULD's decoded measurements, target counts, and status fields over the device's I2C interface. It reorders zones, applies the documented depth convention, and preserves quality. Where multiple targets are reported, the reference reduction selects the nearest measurement classified valid by the native quality interpretation, while exposing full native results through a separate resource when needed. The selected status mapping and driver revision are part of the calibration/profile record, not guessed from an integer buffer. [ST: UM2887 §§1–3; ST employee explanation of perpendicular distance.]

The supplied material does not establish the actual mounting transform, native-to-canonical permutation, or calibrated rays for Rich's hardware. These are deployment data. The profile supplies them from vendor calibration or a measured calibration; their status remains visible until established. A center-and-corner target fixture checks orientation, and a perpendicular-wall fixture checks depth convention.

The reference acquisition profile is 8×8 at 15 Hz. ST's published material distinguishes this from 4×4 at 60 Hz. A faster controller loop may reuse the latest sample but does not claim a new observation on each tick. No fixed model-response frequency is required.

## 9. Edge reflex and wake-up state machine

### 9.1 Separate local reaction from contextual response

The reference incident is a forward-facing zone crossing a configured near boundary. A `BoundaryProfile` contains `profile_id`, sensor source/frame, zone indices, enter depth, exit depth, local reflex operation, target Address, optional Join ID, and source revision. Enter and exit values belong to the device/application profile. An illustrative 200/250 mm pair demonstrates hysteresis; it is not a universal stopping distance.

The controller evaluates fresh source sequences. In state CLEAR, any valid monitored zone at or below the enter depth produces OBSTRUCTED. It runs the local reflex immediately and records the effect. In OBSTRUCTED, further near samples update the current observation without creating another entry event. All monitored zones valid at or above the exit depth produce CLEAR and a clearing event. An unavailable/invalid sample is not interpreted as clear; it produces a quality event when quality state changes. The existing device's behavior for unavailable sensing is recorded in its device profile rather than inferred by Metaform.

The local action does not depend on database persistence, MCP connectivity, or a model turn. Software-derived threshold events retain the exact triggering matrix. A hardware threshold interrupt whose observation time cannot be aligned with a later read records that distinction.

### 9.2 Durable event record

`contracts/event.schema.json` specifies:

```text
event_id; source_id; source_epoch; source_sequence;
journal_id; journal_sequence; kind;
project_id; target_address; join_id;
clock_id; observed_ns; persisted_clock_id; persisted_ns;
cause_id; observation_uri; observation_sequence;
summary; details
```

The event ID is stable across transport retries. The journal sequence orders persistence in the receiving journal; source sequence orders events from one source. Neither asserts synchronized physical time across unrelated sources.

The reference journal uses a head record and sequence-keyed records in `RuntimeRecord`. Appending the next sequence and advancing the head share one transaction. A page after sequence n reads the head and calculates the keys for n+1 through the requested page end; it does not scan JSON payloads to find events. The read transaction fixes that page's head. Messages use the same pattern for each addressed conversation stream.

`details` records affected zones, boundary profile revision, triggering values, reflex requested/applied state, and relevant command ID. The incident frame is retained with the event. Ordinary nonincident frames can replace the latest matrix without entering long-lived project memory.

### 9.3 End-to-end trace

| Step | State transition | Observable action |
|---|---|---|
| 1 | Sensor sequence advances | Driver publishes a new observation with time, quality, source epoch, and calibration reference |
| 2 | CLEAR → OBSTRUCTED | Controller runs its local stop reflex; records actual effect independently of transport |
| 3 | Event created → journaled | Bridge stores event and incident frame, then advances the journal cursor |
| 4 | Resource changed | Bridge emits `notifications/resources/updated` for the event journal |
| 5 | Harness IDLE → WAKE_PENDING | Host reads journal entries after its last cursor, deduplicates event IDs, resolves target Address |
| 6 | Projection prepared | Cypher returns the place's context; host reuses already delivered bodies and offers newly relevant material |
| 7 | WAKE_PENDING → RUNNING | Harness submits the event-originated ACP `session/prompt` |
| 8 | Agent reasoning | Agent reads observation/skill/specification as needed and chooses its response |
| 9 | Native operation queued/applied | Adapter reports motion or other tool status from the actual provider |
| 10 | RUNNING → IDLE | Completed turn and delivered event IDs are recorded; later independent events remain pending |

A busy agent's events join its pending queue and can accompany the next natural turn. Arrival caused by the agent's own navigation is returned in that operation's result rather than forcing an extra model invocation. A state event can wake an idle agent without polling sensor matrices through the model.

### 9.4 Disconnection, duplication, and ordering

`resource://metaform/events` identifies the journal; a resource template with `after` and `limit` identifies subsequent pages. Cursors contain journal identity and sequence. On reconnect, the host reads from the retained cursor. Crossing and clearing events remain distinct even if one resource notification covers both. Matrix update hints can coalesce; event records do not disappear through coalescing.

The host persists delivery states `pending`, `submitted`, `completed`, and `delivery_unknown`, with context and ACP request IDs. A crash after submission but before a result leaves an explicit unknown outcome. Recovery examines available session history and preserves the uncertainty; it does not claim exactly-once model execution. Repeated events carry the same identity.

Native commands likewise distinguish `queued`, `applied`, `completed`, `interrupted`, `failed`, and `unknown`. A lost acknowledgment is not reported as completed motion. Provider-native retry and command-status behavior is described by the tool.

### 9.5 Timing contract

Measure separately:

```text
local reaction = fresh-sample wait + driver read + reflex computation + actuator response
agent response = bridge/journal + notification + context projection + ACP scheduling + model turn
```

The first expression does not contain the second. At 15 Hz, a periodic sample interval is approximately 66.7 ms before readout and actuator effects. A 100 Hz controller cannot remove that sensing interval. Record actual timestamps and p50/p95/p99 for each boundary; no unmeasured end-to-end deadline is asserted.

## 10. Agent contexts, retention, and shared participation

### 10.1 Runtime records

The following payloads use `RuntimeRecord`, each with a project-local revision:

| Kind | Required logical fields |
|---|---|
| Participant | `participant_id`, kind human/agent, display name, genesis reference where applicable |
| Agent context | `context_id`, `agent_id`, harness ID, native session ID, epoch, state, predecessor context |
| Presence | Participant/context ID, project, current Address, optional spatial instance/frame, view reference |
| Layer selection | Snapshot key, Address, `masked_layer_keys`, `selected_layer_keys` |
| Delivery | Context/epoch, source URI, actual digest/revision, delivery channel, time, content reference |
| Message | Message ID, sender and attribution source, target kind/ID, body reference, reply/causation IDs, sequence |
| Work unit | Unit ID, target Addresses/Joins, Block membership revision, ticket IDs, participant IDs, worktree/artifact references |
| Wake delivery | Context/event IDs, ACP request ID, pending/submitted/completed/unknown state |
| Handoff | Predecessor/successor context IDs, same logical agent ID, target, goal, progress, decisions, references, event cursor |

The body used for spatial action is an instance reference with time-bounded participant association. It is not an agent ID. The transport's session is provenance, not an inferred participant identity. Multiple users do not share a process-global “current user,” and multiple contexts do not share a global “current place.”

### 10.2 Identity continuity

The reference choice retains logical agent identity across an explicit handoff and creates a new identity for an independently proceeding fork. Both retain predecessor/parent references. A stopped historical context remains readable from retained records, whether or not its native harness can resume it.

Display names follow the supplied genesis rule: FNV-1a over the first session ID's UTF-8 bytes, XOR-fold to sixteen bits, high/low bytes indexing the fixed adjective/noun tables. The tables' version is retained. Names can collide; stable IDs disambiguate them and no rehash changes an established name. The word tables are referenced from the existing project's naming implementation, not recreated here.

### 10.3 Delivery and retention

The host distinguishes `discovered`, `resource_body_delivered`, `skill_loaded`, and `changed_since_delivery`. The latter is a source-version comparison, not a judgment of understanding. `learned_skills` is the set of versions delivered by the harness's skill-loading path into the current context; it grows through that context and is not reduced when the agent leaves a place.

On observable compaction, the reference host restores the retained skill segment and records the new epoch's delivery. A harness with no retention observability reports that limit; delivery records are not represented as proof of surviving comprehension. The adapter's ability to preserve the segment is an implementation requirement of this retention profile, not an undocumented ACP feature.

A handoff carries the goal, completed/remaining work, decisions, current source revisions, event cursor, work-unit/worktree references, and skill references. It does not copy every prior skill body by default. The successor starts with an empty loaded-skill set and acquires its place's material. `contracts/handoff.schema.json` defines the record.

### 10.4 Budget and page behavior

Use the harness's actual context capacity and tokenizer where exposed. Available input is capacity minus retained context and the requested output reserve. When a configured usage fraction is reached, or the next planned delivery would exceed that capacity, emit a handoff-needed signal and prepare continuation at the next appropriate turn boundary. A goal boundary or explicit handoff can use the same mechanism. Unknown capacity is reported as unknown rather than replaced by an invented universal limit.

Descriptor lists use deterministic ordering and revision-bound cursors. Explicit body reads supply the requested bytes or a declared range with continuation. No summary is substituted for a requested full body without identifying the substitution. Changed versions are announced by references first, then read when relevant. These mechanisms reduce repeated delivery while leaving direct access available.

### 10.5 Concurrent contributions

Shared mutations carry record ID, observed revision, and operation ID. The store transaction retains the contributor's proposed value and publishes the resulting revision. If the observed revision has changed incompatibly, the result includes both versions and a `concurrent_change` finding rather than silently discarding one contribution. This is an observable data interaction, not a participant hierarchy.

Messages and events retain origin and causation. An addressed message is readable by any participant; subscription determines automatic delivery. A user interface can show multiple participant views or shared attention, but Metaform does not prescribe screen-sharing or multiplayer transport.

## 11. Intent-driven documentation recomposition

### 11.1 Frozen inputs

A request names `repository_id`, `target_commit`, optional `base_commit`, document kind, audience, source selection, and prior output reference. Resolve movable branch names once to immutable commit IDs before collecting data.

The versioned repository export contains a manifest and canonical base/layer records. The manifest lists record files and byte digests; it does not contain the hash of the commit that contains itself. After Git creates that commit, the composition run binds `(repository_id, commit_oid, manifest_digest)` to a graph snapshot. This avoids a self-referential commit hash.

A live database state is not silently joined to a past source commit. Missing committed records, changed external native resources, and additional requested runtime cuts remain explicit findings and provenance. A commit-only run resolves external material from committed captures or pinned provider versions; a live fallback is labeled as such.

### 11.2 Programmatic sweep

The composition request's explicit publication selection determines this sweep; it does not inherit whichever leaf a participant last visited. Traverse all selected namespace records, including specification and documentation attachments at Joins. `contracts/document-sweep.cypher` contains the complete two-branch query. Both branches select the requested `snapshot_key`, participating finished layers, and item kinds `specification` and `documentation`; the second obtains the receiver Address through `OWNS`.

```cypher
MATCH (place:Namespace)-[attachment]->(item:ContextItem)-[:IN_LAYER]->(layer:Layer)
WHERE place.snapshot_key = $snapshot_key
  AND item.snapshot_key = $snapshot_key
  AND layer.snapshot_key = $snapshot_key
  AND item.kind IN ['specification', 'documentation']
  AND layer.state = 'finished'
  AND NOT (layer.key IN $excluded_layer_keys)
RETURN place.address AS address, '' AS join_id,
       attachment.attachment_key AS attachment_key,
       item.stable_id AS item_id, item.revision AS revision,
       item.kind AS kind, item.content_digest AS content_digest,
       item.payload_mode AS payload_mode, item.payload_json AS payload_json,
       item.payload_uri AS payload_uri, item.native_schema_uri AS native_schema_uri
UNION ALL
MATCH (receiver:Element)-[:OWNS]->(j:PurposeJoin)
MATCH (j)-[attachment]->(item:ContextItem)-[:IN_LAYER]->(layer:Layer)
WHERE receiver.snapshot_key = $snapshot_key
  AND j.snapshot_key = $snapshot_key
  AND item.snapshot_key = $snapshot_key
  AND layer.snapshot_key = $snapshot_key
  AND item.kind IN ['specification', 'documentation']
  AND layer.state = 'finished'
  AND NOT (layer.key IN $excluded_layer_keys)
RETURN receiver.address AS address, j.stable_id AS join_id,
       attachment.attachment_key AS attachment_key,
       item.stable_id AS item_id, item.revision AS revision,
       item.kind AS kind, item.content_digest AS content_digest,
       item.payload_mode AS payload_mode, item.payload_json AS payload_json,
       item.payload_uri AS payload_uri, item.native_schema_uri AS native_schema_uri;
```

Resolve each body once by `(item ID, revision, digest)`. Sort the structural spine by namespace segment sequence with parents before descendants, then receiver, Join ID, kind, and item ID. Preserve cross-branch Joins as explicit references rather than duplicating the same section. Include the relevant OP, EF, CQU trace, source references, and Block context beside the specification/documentation records.

A native query-backed payload is evaluated against its pinned snapshot when the provider supports that operation. Otherwise the producer records the actual provider revision and its correspondence limit. It does not label an unpinned response as commit-bound.

### 11.3 Detect changed source, then interpret meaning

The programmatic stage executes equivalent argument-array calls to:

```sh
git diff --name-status -z --find-renames "$BASE" "$TARGET" --
git diff --no-ext-diff --unified=0 "$BASE" "$TARGET" --
```

`BASE` and `TARGET` are resolved object IDs, not interpolated user text. The first result supplies zero-delimited path/status records, including rename pairs; the second supplies textual changes. Binary changes retain old/new blob references rather than fabricated text. Git documents these operations as diff formats and options, not as a semantic analysis engine. [Git: git-diff — name-status, -z, find-renames.]

Parse canonical exports by stable record ID. Compare OP, EF, Objective Purpose, attachment scope, native tool schemas, skill digests, documentation, source references, and ICE membership independently. A file rename without a changed functional record is not automatically a functional transformation. A changed implementation reference identifies material to inspect, not proof that the documented behavior changed.

For code-only changes, follow recorded source references to candidate elements and Joins. Unmapped changes are listed explicitly. The composition agent examines their evidence and states the inferred functional consequence with its support or uncertainty. Git detects the change; the agent supplies the interpretation.

### 11.4 Impact and context assembly

Compute affected records from direct changes, declared source/derivation dependencies, changed Join endpoints, and relevant Block membership. Then find document sections whose recorded source dependencies intersect those records. Include the parent outline and cross-references needed to keep the result standalone.

The structural sweep is complete for the selected source set, but the model does not receive the entire repository in every section job. It receives the relevant spine fragment, exact source bodies, changed records, previous section, and references to other fragments. A section is reused only when its source fingerprints, relevant outline context, and cross-references remain unchanged.

### 11.5 Composition-agent contract

Input:

```text
run identity and source cut;
document kind/audience;
section identity and complete outline;
current functional records and native payloads;
changed records and supporting source excerpts;
previous section, if any;
recorded working decisions and unresolved findings.
```

Output:

```text
section text;
claims[] {claim_id, source_refs, status specified|observed|inferred|unknown};
journeys[] {participant, goal, starting_context, interactions, observable_result};
cross_references[];
source_dependencies[];
findings[].
```

The agent rewrites explanations to match the selected sources. User journeys describe actual specified interactions and distinguish intended behavior from implementation evidence. A new requirement is introduced only by an explicit design assignment, as in this working specification; routine documentation refresh explains the selected sources and records unresolved correspondence.

The programmatic stage checks structural completeness, resolvable references, source identifiers, and output formatting. It reports unsupported statements or unresolved correspondence in the generated artifact and run findings. No automatic critic cascade is required.

### 11.6 Publication, failure, and provenance

Write each generated or reused section into a run-specific output directory. Assemble the standalone document with its glossary, interfaces, journeys, and references. Write a manifest containing source cut, selection, producer identity, prompt/version digest, section dependencies, output digests, and findings. `contracts/composition-manifest.schema.json` specifies that manifest.

A completed generation atomically replaces the output pointer. A failed section leaves the previous complete output in place and records which section failed; partial text is retained as partial work, not presented as the completed document. Generated artifacts do not automatically commit, push, or modify source code.

Re-running the same source cut can reuse completed sections with matching dependencies. Re-running a model can produce different prose; retained outputs and manifests provide inspectability rather than a claim of deterministic natural-language generation.

## 12. Compatible ecosystem profiles

### 12.1 Bevy ECS with Resources: optional execution adapter

Bevy uses **Entity-Component-System (ECS)**. Runtime entities identify simulated objects, components hold their per-entity data, and systems process components and shared **Resources**. A Bevy adapter maps stable Metaform functional references to appropriate runtime objects without treating engine-local entity handles as durable Metaform identities. LadybugDB remains the functional graph store; neither its graph nodes nor its CEL attachments become Bevy ECS components by definition.

In a Bevy implementation, Resources may hold the latest normalized observation, motion-command state, and references to context services. Simulation systems can produce ray observations; an adapter for physical observations can populate the same application-level data contract. Command-application systems run at the local execution rate, independently of MCP client timing. A physical bridge outside Bevy implements the same observation contract without needing an ECS runtime. Browser-WASM examples establish one deployment option, not a universal module ABI. [Bevy: Getting Started — ECS; Getting Started — Resources; Examples in WebGL2.]

### 12.2 ROS-compatible data

Use ROS optical-frame conventions for the observation frame and SI units when producing ROS messages. An 8×8 `sensor_msgs/Image` with `32FC1` encoding carries axial depth in meters; valid millimeters divide by 1000. Unknown/invalid values become NaN. The resource's native status can accompany it on a separate diagnostic topic. A no-return observation becomes +Inf only when the source explicitly establishes beyond-range meaning; otherwise it is unknown.

The calibration supports organized `PointCloud2` conversion through the direction-vector formula. A body-frame motion profile can adapt `TwistStamped` values after applying the recorded sensor/body frame relationship. Message types and frame semantics are reused rather than named as newly invented Metaform formats. [ROS: REP 103; REP 118; sensor_msgs/Image; PointCloud2; geometry_msgs/TwistStamped.]

### 12.3 Drone and WebAssembly interfaces

MAVLink is an informative adapter target, not a selected flight controller. Its `OBSTACLE_DISTANCE` message has 72 directional bins in centimeters, not an 8×8 image. An adapter must document the angular projection and lost vertical information; it cannot relabel the 64-zone payload as that message. [MAVLink common.xml: OBSTACLE_DISTANCE.]

A WASM-backed tool is a normal provider with a content digest, declared ABI/version, input/output schema, execution entry point, and outcome resource. A skill can explain its use; a skill manifest is not itself the executable module. Browser presentation, native Bevy execution, and other hosts can share the functional contract while identifying their actual native bindings. This specification does not invent a universal WASM bus or prescribe a permission model.

## 13. Working decisions and source correspondence

| Decision | Underspecified point | Selected completion and reason |
|---|---|---|
| D01 | Cross-paradigm terminology | Metaform uses functional graph records and contextual projection over MCP, not an ECR standard. Bevy uses ordinary ECS with shared Resources when selected as a runtime; neither LadybugDB nor the physical adapter must implement ECS |
| D02 | Graph ancestry cost/depth | Materialized prefix closure including self; avoids repeated traversal and implicit depth limits |
| D03 | EF/Objective Purpose intersection | Facilitator records spec/skill/tool bindings at receiver-owned Joins; runtime resolves them deterministically |
| D04 | Context source versions | Snapshot-qualified graph descriptors plus actual live-provider revisions; commit-bound exports for composition |
| D05 | Dynamic MCP catalogs | Named place surfaces and host projection; satisfies current catalog semantics without connection-local mutation |
| D06 | Skill availability notice | Ordinary resource-catalog update; loading recorded when the native harness reports skill-body loading |
| D07 | Agent continuity | Same logical identity on deliberate handoff; a new identity on independently proceeding fork |
| D08 | Compaction and retention | Host-managed retained skill segment with explicit observability; no claim that receipts prove comprehension |
| D09 | Uniform depth meaning | Axial-z millimeters with explicit calibration and quality; normalize simulated slant ray distances |
| D10 | Event loss between reads | Persist incident events and referenced frames separately from latest observation; cursor-based replay |
| D11 | Concurrent edits | Record revisions and expose incompatible concurrent contributions rather than silently overwriting |
| D12 | Recomposition source cut | Immutable Git IDs plus export manifest; semantic interpretation follows raw diff and structural comparison |
| D13 | Documentation generation size | Complete programmatic sweep, dependency-scoped section jobs, reuse unchanged supported sections |
| D14 | Multi-user breadth | Shared identities, messages, records, and independent contexts; interactive presentation remains open |
| D15 | Hardware-specific values | Native profile supplies quality mapping, zone permutation, calibration, and reflex parameters; values not invented from notes |
| D16 | Official skills host behavior | Use the existing harness's skill-loading path; distinguish resource delivery, skill loading, and Metaform context selection |

## 14. Verification, acceptance, and remaining uncertainty

Sixteen local checks were executed against the delivery's application schemas and reference semantics. They cover five well-formed JSON Schemas, a complete 64-zone observation, resource-text round-tripping and required cache fields, incorrect array length, negative depth, status/depth agreement, unknown values, axial conversion of 64 rays, branch-local layer restoration, ancestry beyond thirty hops, skill retention across movement, event replay deduplication, actual skill-file digest, and the supplied Hermes correction's five Blocks/fifteen members. Results are in `verification/results.json`.

These checks do not execute the proposed system. LadybugDB was not installed in the runtime; an installation attempt failed because the package server could not be resolved. The DDL and Cypher are therefore **source-reviewed, engine execution unverified**. MCP/ACP end-to-end interoperability, Bevy integration, physical sensor calibration, and motor behavior were not exercised. No latency, capacity, or inference-amortization benchmark is claimed.

Implementation acceptance is observable:

| Contract | Required demonstration |
|---|---|
| Functional representation | One element serves several receivers without a global EF; nested references preserve Address identity |
| Context projection | Same place/view/revision yields the same catalog for two participants; ancestor context applies correctly; sibling-local context does not |
| Query execution | DDL and supplied queries run on the selected Ladybug release; empty known place differs from unknown Address; deep ancestry is complete |
| Progressive disclosure | Arrival gives descriptors and relevant orientation; explicit reads return bodies; repeated unchanged bodies are not automatically reinjected |
| Retention and handoff | A loaded skill remains after movement; compaction retention is established by the harness profile; successor loading begins from its new context |
| ICE work composition | Coupled elements share the work unit/worktree while multiple participants can contribute |
| MCP | Current request metadata, native tool schemas/annotations, official skill entries, subscription acknowledgment, and update notifications interoperate |
| Spatial compatibility | Physical and simulated adapters validate against one schema; orientation, units, axial convention, and unknown values remain correct |
| Edge independence | Reflex completes with MCP disconnected and the model idle; event and incident frame are delivered after reconnect |
| Event recovery | Enter/clear between reads are both preserved; duplicate transport events keep one identity; unknown ACP outcomes remain explicit |
| Recomposition | A change to an Objective Purpose updates affected explanations/journeys; a mere file rename does not invent a functional change; source cut and citations remain reproducible |
| Shared participation | Two humans and two agents maintain independent positions, contexts, and delivery histories while reading and contributing to the same functional records |

The unverified items are integration work and deployment evidence, not unspecified semantic mechanisms. The specification identifies the data, behavior, and observable result needed to build and test each boundary.
