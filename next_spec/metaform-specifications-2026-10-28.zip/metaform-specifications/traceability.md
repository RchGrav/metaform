# Requirement and source index

| Capability | Acceptance | Source | Additional contract |
| --- | --- | --- | --- |
| CAP-1 Functional understanding | AC-01 | ECS paper 2-7; technical 2,4 | Adopted ECS technical specification |
| CAP-2 Semantic intake and change | AC-02 | User D-04; handoff 01; ECS technical 2-3 | agent-interface.md |
| CAP-3 Functional navigation and retrieval | AC-03 | Handoff 01; ECS technical 5,7.2 | agent-interface.md |
| CAP-4 Knowledge layers | AC-04 | ECS paper 7; technical 4-5 | agent-interface.md |
| CAP-5 Native tools and skills | AC-05 | ECS technical 3,5,7 | agent-interface.md |
| CAP-6 Context continuity | AC-06 | Handoff 01; ECS technical 5.4,7.3,10 | lifecycle-and-delivery.md |
| CAP-7 Addressed communication | AC-07 | Handoff 01; ECS technical 7.2,9.2,10 | lifecycle-and-delivery.md |
| CAP-8 Event-driven orchestration | AC-08 | User D-03; handoff 01; ECS technical 3,6,7.5,9 | lifecycle-and-delivery.md |
| CAP-9 Coupled work composition | AC-09 | ECS paper 4.4; technical 6 | Adopted ECS technical specification |
| CAP-10 Persistent agent lifecycle | AC-10 | Handoff 01; ECS technical 10 | lifecycle-and-delivery.md |
| CAP-11 Peer reputation | AC-11 | Handoff 01: Peer reputation | lifecycle-and-delivery.md |
| CAP-12 Consistent persistent state | AC-12 | ECS technical 2.3,4,5.4,10.5 | Adopted ECS technical specification |
| CAP-13 Recoverable event delivery | AC-13 | ECS technical 7,9 | Adopted ECS technical specification |
| CAP-14 Spatial observations and local response | AC-14 | ECS technical 8-9,12 | Adopted ECS technical specification |
| CAP-15 Revision-bound documentation | AC-15 | ECS technical 11 | Adopted ECS technical specification |
| CAP-16 Observable operation | AC-16 | Handoff 01: Operation and quality; ECS paper 8.5; technical 9.5,14 | Adopted ECS technical specification |

## Preservation sweep

| Source range | Preserved content and destination |
| --- | --- |
| ECS paper 1–3 | Thesis, independent-origin attribution, advance inference and meaningful Address orientation; adopted paper, CAP-1 |
| ECS paper 4–7 | Entity/element perspective, RE/PE, CQU, OP/EF, DE/SE/NE, ICE, exact C(T), CELs and selection; adopted paper, decisions, CAP-1/4/9 |
| ECS paper 8–12 | Progressive delivery, retained skills, reflex/model timing, provenance, critics, optional lexicalization and recomposition; adopted paper, CAP-5/6/13–16 |
| ECS paper 13–15 and references | Historical example scope, reported counts, evaluation boundaries and research relationships; adopted paper; not converted to new runtime facts |
| ECS technical 1–3 | Scope, participant equality, normalization, snapshot/live distinction and component responsibilities; adopted technical, decisions, CAP-1/5/12 |
| ECS technical 4 | Complete LadybugDB schema, key rules, namespace closure/incidence and publication responsibilities; adopted technical and graph.cypher, CAP-12 |
| ECS technical 5 | Selection, projection queries, functional binding, envelope and version-qualified cache; adopted technical/queries, CAP-3–6/12 |
| ECS technical 6 | Specification-to-work composition, facilitator bindings, ICE and changed coupling; adopted technical, CAP-8/9 |
| ECS technical 7 | Native tools, named place surfaces, host gateway, skill transport, subscriptions and ACP turns; adopted technical/fixtures, agent interface, CAP-5/6/8/13 |
| ECS technical 8–9 | Sensor schema/calibration, axial conversion, status semantics, local reflex, durable event journal, replay and timings; adopted technical/contracts, CAP-13/14/16 |
| ECS technical 10 | Identity, runtime records, delivery/retention, budget and concurrent contributions; adopted technical, lifecycle companion, CAP-6/10/12 |
| ECS technical 11 | Immutable source cuts, complete sweep, scoped interpretation, output/provenance/failure behavior; adopted technical/contracts, CAP-15 |
| ECS technical 12 | Bevy, ROS, drone and WASM adapter profiles and their limits; adopted technical, CAP-14 |
| ECS technical 13–14 | Recorded design decisions, acceptance demonstrations and verification limits; adopted technical, acceptance companion |
| Handoff 01 | Functional intake/retrieval, context/inboxes, lifecycle/team composition, reputation, operation; incorporated through D-01–18 and CAP-1–16 |
| Handoff 04 | Localized recorded details and source statuses; completion-work.md with direct LadybugDB/communication/intake corrections applied |
| Direct user corrections | Selected backend, adopted ECS baseline, no live logging, purposeful events, semantic MCP interface and review-first approach; decisions, agent interface and lifecycle |
| Latest user direction | Proceed from handoff using BMAD, owner supplies omissions; decisions, memlog and completion work |

## Wrapper-only source material

Handoff model-tier assignments, workstation recommendations and process instructions remain in the source snapshot. They do not become runtime product requirements or authorization to rebuild code. Its requested future prompt inventory and implementation extraction remain future specification work, not falsely reported completed activities.
