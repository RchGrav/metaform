Checks run here, Linux under WSL: pytest 482 passed in 254 s; pyright strict 0 errors; ruff check src tests conftest.py 117 findings.

1. Lint fails on every CI job. Ruff 0.16.9 is pinned and pyproject leaves the rule set at Ruff's defaults, which in this version report I001 unsorted imports 32, PLW1510 subprocess.run without check 17, UP017 datetime.UTC 11, ISC004 11, FURB167 11, BLE001 8, RUF059 8 and a few more. 65 are fixable with --fix. Q47 is still open, so the checks workflow shows red whatever else passes.

2. map knowledge has no ef noun. op=add-join, add-subtype and correct cannot set Function or Encounter, so a knowledge layer's joins and every correction made through the tool carry no ef, against MAP-020. An ef= given on the command line goes to extra with a notice. BUILD-LOG step 27 records this as not changed.

3. Not built from the current spec: PROJ-019, web variants served side by side; PROJ-020 and PROJ-021, export and import of an origin unit as a wheel, waiting on section 08 questions 8, 5 and 13; MCP-022, a check per tool that it loads the skill from the folder the installer writes, which is recommended and so built as written.

4. The history boundary is git ls-files --cached --others --exclude-standard, and .gitignore ignores only .venv, __pycache__, *.egg-info and dist. This working tree has 25,010 untracked files git does not ignore, about 1.9 GB: artifacts, .test-tmp, .tmp, archives, node_modules, the earlier runtime's .metaform folder, metaform.zip, the 35 MB metaform_2.zip, and backups such as CLAUDE.md~, README.md~ and AGENTS.bak. metaform add origin on this repository would copy all of it into the home as variant v000001. Ignore or remove them before establishing an origin here.

5. The .metaform folder inside the project folder is state from the earlier runtime. The current design never writes into a project folder, STORE-001, and nothing reads it.

6. Stale documents. specifications/spec/HANDOFF.md describes the build before steps 12 to 27: it names the viewer as the next step, lists four Canonical Intake questions the current text has answered, and mentions an uncommitted fix step. The web module README says the server serves only /api/server and /api/projects; server.py also serves every named read under /api/<read>, the prompt reads and three POST writes. specifications/README.md says Canonical_Intake_test.xml holds changes under test, while 00-index.md says it no longer matches since ef was added.

7. prompts.shipped has no caller since step 26, so in a live home the prompt store is empty and the web GUI's Prompt tab has nothing to edit until a module ships a prompt. That follows the decision; the tab is simply empty meanwhile.

8. The MCP server composes its instructions once, when mcp serve starts. The tool list is rebuilt per request, but a status notice such as the one to delegate the intake stays in a connected host's instructions until the host reconnects.