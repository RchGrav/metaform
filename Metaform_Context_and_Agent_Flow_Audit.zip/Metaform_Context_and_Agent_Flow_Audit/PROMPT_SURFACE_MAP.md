# Prompt and context surface map

A source string, a delivered ACP/MCP payload, a harness-loaded instruction, and the final model request are different evidence. This map follows those distinctions.

## Layers

| Surface | Entry/trigger | Cost and behavior to examine | Reviewed source |
|---|---|---|---|
| Repository AGENTS.md | Native harness instruction discovery; CLAUDE.md also asks to read it | Broad narrated procedure and engineering requirements affect ordinary work | [S01](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/AGENTS.md) [S02](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/CLAUDE.md) |
| Repository CLAUDE.md | Claude/native project loading where applicable | Original-intent rewriting; duplicated glossary; project policy | [S02](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/CLAUDE.md) |
| User/global native files | Existing personal configuration plus Metaform provisioned pointer | Outside-repo instructions are unknown here; provisioned pointer may trigger guide read | [S05](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/agent_setup.py) [S03](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/resources/prompts.xml) |
| Passive Claude hook | Matching native delegation/question tools | Once per known host session; if session ID missing, every match can emit reminder | [S05](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/agent_setup.py) |
| Native role definition | Explicit/automatic selection of a `.claude/agents` role | Role wrapper, reference body, model/tools metadata; not universal startup text | [S26](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/mcp-context-expert.md) [S27](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/critic.md) |
| MCP connect/server guidance | MCP connection/discovery path | Compact modules vs full instructions; live status notices; host placement unknown | [S04](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/instructions.py) [S16](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py) |
| Tool directory and schemas | Catalog listing/open/direct call | Schemas supplied according to module discovery; dynamic blacklist separate | [S16](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py) [S17](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/catalog.py) |
| Module and tool guides | First relevant tool use or explicit guide request | Shared-line deduplication; auto guide receipts deliberately survive compaction | [S16](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py) [S19](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/shown.py) |
| Dispatched role body/common text | Assignment and epoch-based preparation | Rendered receipts; selected role snapshot; literal final-model priority not controlled by role name | [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml) |
| ACP task/opening/continuation | New or resumed work turn | Per-ticket context boundary, supplied assignment, memory instructions, checkpoint | [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S10](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/runner.py) [S11](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/orchestration.py) |
| Retention checkpoint | Piggybacked actual turn/checkpoint | Diagnostic response requirement; does not inventory semantics | [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S10](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/runner.py) |
| Functional map orientation | Relevant node/work/handoff reads | Purpose and source selection; count trees and bounded summaries | [S20](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/around.py) [S21](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/resources/prompts.xml) |
| Glossary/peer register | Resource/guide read selected for project | Canonical meanings useful; prohibition on independent concepts overreaches | [S21](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/resources/prompts.xml) |
| Memory instructions/results | Startup/guide plus task-relevant reads | Read-time housekeeping duty; receipt/revision updates; own-write behavior | [S22](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/delivery.py) [S23](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/resources/prompts.xml) |
| Ordinary peer message | Normal turn/inbox | Short summary with access to original; model-authored summary is not source evidence | [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S11](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/orchestration.py) |
| Relayed user direction | User message route | Existing original-message route worth preserving; source attribution matters | [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py) |
| Spec adaptation/change order | Recorded adaptive-mode publication | Current revision and affected work; notification, not automatic approval | [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py) |
| Tool results | MCP response shaping | Field selection, false/missing, text/structured rendering; host may select either | [S16](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py) [S18](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/shaping.py) |
| Workflow skill/library | Selected skill/subroutine | Library markers, bound variables, exact lexicalization; same-agent call already available | [S24](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/workflow/resources/prompts.xml) |
| Roundtable opening/results | Selected discussion/proposal/adoption | Scope-specific question; complete transcript available; proposal-only is a selected assignment | [S25](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/roundtables/resources/prompts.xml) |
| Intake preparation | Explicit initial/greenfield intake | Functional inference is preparation, not a procedure every worker should reread | [S03](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/resources/prompts.xml); P01 §4.3 |
| Hosted project wheel | Explicit remote build/onboarding | Additional instructions specific to that deployment; not an ACP-worker default | [S03](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/resources/prompts.xml) |
| Prompt editor/store | Selected edits, shipped changes, trial text | Source file may differ from operative version; snapshots/migrations matter | [S06](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/prompt_files.py) [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) |
| Host compaction/auto memory/system text | Harness-controlled lifecycle | Can change unseen context; native trace required to establish final composition | Official sources; outside live-audit scope |

## Effective instruction manifest, proposed observation

Reuse existing `Sent` records rather than creating a second mandatory prompt authority. A debugging view can contain:

```text
episode/session/turn
adapter and observed version
cwd and known instruction search scope
role name, selected role snapshot
shipped prompt identity and selected edit/version
rendered content digest and byte length
delivery surface (ACP user content, MCP result, native config, guide, resource)
context epoch and observed reason for change
source reference for each supplied requirement/plan/imperative
compaction/usage observations actually supplied by the adapter
native/global/injected sources: observed, configured, or unknown
```

These are diagnostics, not admission checks. A hash proves which bytes Metaform sent, not that a model understood or retained them. A host can transform, truncate or supplement a response.

## Important non-findings

The full handoff text exists in source but is not thereby sent on every ordinary turn. Debug stop/report instructions are setting-dependent. The workflow system already supports same-agent calls; it is not inherently one-agent-per-subroutine. A review count setting is not proof of its production value. Text plus structured MCP content is not proof that a host presents both to the model. Source comments about a previous runaway launch incident describe a repaired case and are not evidence that the loop still exists.

## Coverage boundaries

The audit directly inspected the listed root/native/chassis/agent/dispatch/orchestration/MCP/map/memory/workflow/roundtable surfaces and relevant execution functions. It did not load the user's home prompt/role database, every generated specialist, every nested project instruction, or all third-party skill/plugin text. The live Canonical Intake resource path used by the older preprint was not present at that same path in this revision; no replacement procedure is inferred. The supplied preprint's canonical semantics were retained, not rewritten from an unseen current intake file.
