# Implementation sequence

These are proposed changes, not tickets created in the live project. Paths and symbols are grounded in the reviewed revision. Node addresses should be resolved from the actual project's map during implementation rather than invented from filenames.

## 1. Correct result selection and preserve evidence

**Files:** `modules/mcp/shaping.py`; focused existing/new tests around it.

Separate selection from formatting. Validate explicit requests on raw typed values; apply filters; recursively project; then render triage/full/count. Keep text and structured results semantically consistent. Retain meaningful or explicitly selected false/zero/empty values. Ensure all deep-path selection branches use the same path semantics.

Use the three shaping fixtures in `diagnostics/` as observed failures, then extend to nested lists and empty-result cases. Do not use broad `view=full` as the permanent workaround for a broken selector—it is exactly the kind of workaround that can inflate context.

**Dependency:** none on orchestration restructuring.

## 2. Remove contradictory prompt directions at the actual served source

**Files:** root AGENTS/CLAUDE; dispatch/orchestration/memory prompt XML; prompt-store selection machinery only where needed to apply the intended source revision.

Apply targeted edits from `prompts/`, preserving unrelated authored material and MetaformFoundation. Align FQC to runtime's single correction-return route; replace the contradictory hold paragraph; remove Facilitator-as-universal-return wording; replace mandatory per-read memory cleanup with relevant evidence-led maintenance. Remove universal narrative/style reconstruction routines.

Use existing `Sent` records to compare selected and rendered text before/after. A selected override is a separate source to reconcile, not something to overwrite blindly. Existing role snapshots and native files may need their intended update path. This is verification of an edit, not a new permission process.

**Dependency:** none on episode support. Full replacement fragments that change integration assumptions are labelled in PROMPT_REVISIONS.md.

## 3. Retain intent provenance as data, not repeated prose

**Files:** map/work storage and edit paths, orchestration assignment/plan creation, liaison handoff and runtime Planner path.

Record the original request and later user revisions as addressable source records. Associate a work item with source reference(s), optional exact spans, interpretation and plan/spec revision. Keep the operation and its source identity separable from the current execution description. Use existing message/history facilities where their lifecycle genuinely fits; do not treat a completed-ticket snapshot as every intermediate request revision.

Add author/source provenance to direction messages. In particular, inspect all callers of `ticket_edited` before altering its “the user edited” wording: distinguish a user edit, an agent plan refinement and an adaptive change order. The source message currently uses the user attribution, but caller provenance was not traced completely enough to claim all agent edits are misattributed.

A transitional implementation can retain source text once in a linked work/message record and attach a plan note. Do not leave the old `needs_plan` task-fingerprint cycle unchanged while moving the plan out of task text; step 4 adjusts its routing semantics.

**Dependency:** prompt wording can be drafted now; use of a new source field requires this data-path implementation.

## 4. Make runtime selection fit the task rather than block it unnecessarily

**Files:** `orchestration/runtime.py`, `routing.py`, `state.py::runtime/prepare_runtime`, transport catalog/choice persistence and setting adapters.

Keep explicit person selections. Make advertised optional effort optional end-to-end. Treat capability/model preferences as selection evidence instead of hardcoded agent-family exclusions. Reuse a selected choice for a continuation unless the needed capability or the person's choice changes.

Rework `needs_plan` as a planning contribution decision, not a universal implementation-admission category. A real Planner result should update plan state and be consumed once; a worker can otherwise resolve a local approach within its assignment. Update `runtime_task`, `runtime_choice` and `runtime_plan` together with this code. Their proposed text is not a schema-compatible substitute for old category semantics by itself.

Retain useful cached JEV decisions. Where a responsible agent already provides the organization/runtime decision, avoid paying for the same decision again in separate classification. The correct choice can still be model-driven; this is not an instruction to replace semantic selection with brittle keyword rules.

**Verification:** the two routing fixtures in diagnostics; a local ambiguous implementation succeeds without an artificial Planner loop; real cross-workstream planning still occurs; explicit overrides survive.

## 5. Introduce execution episodes while keeping the board and assignments

**Files:** orchestration assignment/session binding; dispatch runner and transport launch/resume; tool-call attribution context.

Add an episode identity representing a coherent stretch of work. Associate one or more work records with it. Keep work IDs and results independent of session lifetime. Replace the permanent one-session/one-assignment assumption with historical bindings plus one current work binding for a turn. This is more than deleting the existing `bind` check: tool attribution, child returns, current `METAFORM_WORK` assumptions, branch/worktree state and concurrent edits must continue to resolve correctly.

A continued session gets the new assignment/delta and source references, not the entire previous handoff again. Resume a dormant session through supported ACP methods. Start a fresh context when useful and reconstruct the same episode from retained decisions, current evidence and functional understanding. Keep specialist/assessment roles separate; do not make every worker do every responsibility to avoid startup cost.

For helpers, provide a retained helper/episode path for related follow-up. Keep current one-shot helpers for genuinely standalone work. The helper prompt cannot create persistence on its own.

**Verification:** three related cards, one worker session; concurrent unrelated card, another appropriate context; independent review; old caller receives a child result after active card changes; recovery after process replacement; explicit user instruction can reach the chosen agent.

**Dependencies:** result/provenance paths should be stable first. No new authorization matrix is required.

## 6. Make review and change reconciliation semantic and traceable

**Files:** `state.py::returned/_decided/_finding/_correction`; affected assessment prompts and views.

Retain findings against the reviewed candidate/requirements revision. Replace all-findings suppression by name matching with explicit revision-change evidence and per-finding disposition by the responsible reasoning role. Keep the existing reopen/correction continuation as the normal recorded path. Use stable finding identity/references and evidence to recognize recurrences; normalized title can remain a lookup hint, not proof of issue equivalence.

A user change can supersede a requirement. It need not supersede every defect in the same component. Reconciliation happens as useful work, not as another universal review gate.

**Verification:** unrelated same-component user change; actual supersession; paraphrased recurring finding; two different defects with the same generic title; no duplicate model-created correction cards.

## 7. Align context observations, changes and reconstruction

**Files:** `agents/roles.py`, `shown.py`, `memory/delivery.py`, map around notices, dispatch compaction/checkpoint handling.

Document and preserve the distinct meanings of receipts. Capture actual compaction events if the adapter supports them. Keep uncertain retention separate from known delivery and host configuration. A marker response is diagnostic only. Prepare a fresh context from relevant source and current state when needed, without claiming surgical deletion of the old transcript.

For long-lived episodes, index consumed revisions and coalesce relevant external updates into existing turns. Preserve exact correction/tombstone identities; do not add global memory broadcasts or model calls for unchanged state. This is a deliberate revision of the current no-push policy and should be evaluated separately from wording-only cleanup.

**Verification:** explicit compaction; opaque resume; failed retention-marker response; changed memory from another worker; own write; deletions; explicit reread; selected prompt revision while a session remains active.

## 8. Integrate references and measure complete outcomes

Use the existing workflow/skills/resources paths for the selected cookbook-derived references. Publish a small directory containing purpose and access path. Load the matching guide only when it contributes. Record whether a guide is informational or is an explicitly selected procedure; the cookbook's default gates are not project policy.

Collect model calls (including JEV and fallback agents), known input/output/cache/usage data, delivered payload bytes, startup/resume counts, tool-result sizes, corrections and achieved outcomes. Native/internal context can remain unknown. Measure prompt changes and episode changes separately so a regression is attributable.

Run matched cases with the prepared functional model held constant: related small fixes; parallel independent work; a blocker requiring adaptive specification reasoning; changed user intent; recovery; greenfield and brownfield tasks. Compare usefulness and fidelity as well as cost. No universal context percentage, ticket size or number of agents is introduced.

## Suggested order

Result fidelity and prompt contradictions can be repaired first without waiting for the episode redesign. Intent provenance and runtime selection then make episode continuity dependable. Review reconciliation and context-update handling follow the same source identities. References/telemetry can proceed alongside these changes.

Keep unrelated UI, code-style and other subsystem work out of this revision unless it is a direct dependency. The audit reports nearby design smells, but does not authorize broad cleanup.
