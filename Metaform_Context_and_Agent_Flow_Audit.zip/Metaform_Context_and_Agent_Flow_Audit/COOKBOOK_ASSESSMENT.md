# Vibe Coding Cookbook: selective use for Metaform

## What was inspected

The attached archive contains `COOKBOOK.md`, the agentic workflow setup kit, its references, and six native-role templates. The inspected sources include:

- `COOKBOOK.md`, §3.3 Skills, §4.3 FULL/LIGHT/TRIVIAL, §4.4 Issues, and the role/workflow discussion.
- `agentic-workflow-kit/setting-up-agentic-workflow/references/prompts.md`.
- `.../references/principles.md`.
- `.../templates/project/dot-claude/agents/planner.md`, `developer.md`, `tester.md`, `reviewer.md`, `debugger.md`, `doc-keeper.md`.

The archive mentions a fuller `prompt-writing` skill with delegation templates, but those referenced materials are not included. The role revisions in this package use the materials actually present, not a claimed reading of missing guides.

## Useful ideas to adapt

| Source idea | Metaform adaptation |
|---|---|
| Role starts with a concrete job and useful result | Keep GC, Planner, Worker, Verifier and FQC responsibilities explicit; avoid turning role identity into an elaborate procedural ritual. |
| Preserve source names/numbers and mark inference | Retain the source request separately; distinguish interpretation, research and adaptation. |
| Search existing implementation before building | Use functional relationships and references to find existing fulfillment, rather than rediscovering only through filenames. |
| Check a hypothesis with focused evidence | Investigator returns cause/evidence/uncertainty; not necessarily a new report file for every tool call. |
| Compare failing test identities, not only counts | Useful verifier reference: a replaced failure can hide behind an unchanged failure count. |
| Findings tied to concrete scenarios | FQC/reviewer describes actual behavior and consequence, while retaining uncertain concerns as uncertain rather than deleting them. |
| One canonical document/topic, references instead of copies | Store one result/evidence record; board, liaison and peers refer to it. |
| Lazy skills/reference loading | Use current Metaform module/skill discovery; relevant procedure/reference on demand. |
| Search issue history before creating duplicates | Reuse stable finding/work identity and attach new evidence; title similarity is only a search hint. |

These are adaptations, not claims that the cookbook proves a performance improvement.

## Material not imported as system policy

The kit is designed around a different authority and execution model. Its own principles require approval at each step, protected tests, path-restricted roles, new-dependency approvals, clean RED baselines, numerical size budgets, a fresh context per task and reset after a fixed number of failures. Its templates also require missing-input BLOCKED responses and additional report files at each stage.

Those details would add precisely the gates, fragmentation and repeated setup this revision is examining. They remain part of the source cookbook, but they are not copied into Metaform's prompts. Likewise, a separate tester's useful perspective does not imply immutable tests or that every test/specification conflict requires a user approval round.

## Proposed MCP reference entries

These are suggested resource identities, not existing tool/URI claims. Implement them through the current skill/resource mechanism rather than inventing another service.

| Suggested reference | Content | Useful moment |
|---|---|---|
| `reference.prompting.assignment` | Exact source vs interpretation; goal, receiving purpose, available evidence, expected contribution, return reference | Preparing a nontrivial delegation or debugging drift |
| `reference.work.reuse` | Find existing fulfillment through map and artifact; compare simplest adequate alternatives | Planning or implementation where a new mechanism is being considered |
| `reference.debugging.evidence` | Focused hypothesis/check/result; source location; what remains unknown | Investigator or worker diagnosing a real failure |
| `reference.verification.outcome` | Outcome-to-observation mapping; candidate identity; failing-test identities; limits of evidence | Verification requiring more than a success assertion |
| `reference.review.findings` | Finding identity, concrete consequence, evidence, superseded requirement vs unrelated defect | Independent assessment and correction reconciliation |
| `reference.documentation.current_state` | One authoritative description, links to detail, distinction from historical rationale | Documentation changes, not all coding sessions |

The directory needs only a purpose and retrieval path. Full guides are supplied when used. Keep source attribution and note which statements were adapted; do not make the entire cookbook an imperative knowledge layer on every project node.

A short reference can contain one example relevant to its operation. It should not silently introduce fixed task sizes, mandatory approval states, role capability restrictions, numerical retry limits or new completion prerequisites.
