# Metaform: agent flow and context audit

Reviewed repository: `RchGrav/metaform`, `main` snapshot `4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351` (commit timestamp 2026-10-21T23:29:16Z).

**Verdict:** retain the functional model, event-driven continuations and existing selective context delivery. Address intent rewriting, assignment/startup granularity, contradictory instructions and lossy result shaping before adding another management layer.

## Contents

- [Audit](AUDIT.md): findings, evidence, consequences, refinements and verification cases.
- [Prompt/context surface map](PROMPT_SURFACE_MAP.md): where instructions enter and what is known about their delivery.
- [Implementation sequence](IMPLEMENTATION_PLAN.md): changes grounded in existing modules and dependencies.
- [Prompt revisions](PROMPT_REVISIONS.md): proposed wording, preserved behavior and integration dependencies.
- [Cookbook assessment](COOKBOOK_ASSESSMENT.md): useful material, incompatible assumptions and proposed reference delivery.
- [Source index](SOURCE_INDEX.md): pinned repository sources and official protocol sources.
- `prompts/`: proposed replacement elements and surgical edits; not an installed prompt pack.
- `diagnostics/`: five isolated source-function reproductions and their actual output.

No repository, project settings, prompt store or user configuration was changed. This package is analysis and proposed text. The reproduction script operates on local JSON fixtures, not the live system.

## Limits that matter

The audit covers the connected source and the supplied preprint/cookbook, not your active home database, prompt-store selections, installed harness configuration, session transcripts or billing. Source findings are established; their share of production token cost is not measured. References to delivered context mean Metaform-authored material unless a native harness trace says more. The surface map distinguishes directly read surfaces from downstream/configuration-dependent material.
