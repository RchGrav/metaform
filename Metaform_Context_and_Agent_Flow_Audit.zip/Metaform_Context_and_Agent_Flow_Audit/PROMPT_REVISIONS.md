# Proposed prompt revisions and application notes

## Intent of the edits

The revisions keep role identity, functional grounding, C(T), adaptive/strict behavior, useful independent assessment, explicit source evidence and existing result/continuation mechanisms. They remove contradictory instructions and recurring secondary tasks that are not the assigned outcome.

The user asked for refined prompts; these are proposed texts for that review, not repository mutations. XML files contain selected replacement elements only. Do not replace an entire module file with them or load them as a global trial file without preserving component identity: different modules can share element names such as `instructions`.

## Files and behavior changes

| File | Scope | Application dependency |
|---|---|---|
| `prompts/orchestration.selected-elements.proposed.xml` | common, GC, FQC, Planner, implementer, investigator, requirements, verifier, reviewer | Reconcile the selected store version and existing authored changes. FQC return aligns to the current reopen route. Source references need the provenance path where not already available. |
| `prompts/memory.selected-elements.proposed.xml` | instructions, refine, orient, counts | Wording change; existing canonical CRUD and read interfaces retained. `unread` and `read_unread` placeholders preserved. |
| `prompts/dispatch.targeted-edits.md` | Liaison voice/intake/hold handling; helper wording | Preserve full system wrapper/persona. Hold wake behavior and persistent helper/session behavior require code changes. |
| `prompts/root-and-native.targeted-edits.md` | Root narration/rewrite policy; glossary reasoning; native expert wrappers | Native instruction loading, not universal ACP system-prompt injection. Preserve MetaformFoundation and unrelated requirements. |
| `prompts/runtime.code-dependent.md` | Runtime classification/choice/plan and specialist-authoring guidance | Change optional effort, choice filtering and plan-state semantics in code first or together. |

## Deliberate preservation

The common prompt retains user revisions in either adaptation mode, recorded return destinations, direct coordination, useful specialty creation, durable evidence and the separation of ticket resolution from Git publication. It does not turn every role into a GC. The FQC remains independent and can adapt a limiting specification in adaptive mode. The Planner preserves an explicitly requested proposal-only operation rather than silently starting implementation from it.

The short implementer/investigator/verifier/reviewer prompts intentionally resemble the strongest parts already in the repository. Most of their problems come from inherited wrappers and repeated common instructions, not a failure to define those roles at all. The revisions are not an argument that every original sentence must be replaced.

The workflow lexicalizer is already faithful to the preprint's intended operation and is not rewritten here. Canonical intake and MetaformFoundation are not replaced with generic engineering language. The user-facing identity/persona remains in its existing source.

## Deployment validation, not a new approval mechanism

For each selected change, inspect the exact rendered role/turn payload and its `Sent` identity/version. Exercise an active assignment and a resumed session as well as a fresh one. Native AGENTS/CLAUDE/global instructions and selected prompt-store edits can still supply conflicting older text. Use an ordinary request that previously triggered the unwanted behavior and examine its actual outcome.

The XML parses locally. Placeholder identity is preserved in the memory `counts` fragment and the helper/runtime-plan examples. The fragments have not been executed through the live Metaform prompt store or a production agent. They are not claimed to be behaviorally benchmarked or byte-for-byte compatible with every selected local override.
