# Metaform agent-flow and context audit

## Executive finding

**The source contains concrete causes of avoidable orchestration work and opportunities for intent drift. The principal remedy is not a more restrictive prompt, a universal context cap, or an additional supervisor.**

Retain the functional namespace, receiver-owned relationships, persistent work records, event-driven continuations, compact inbox and revision-aware delivery. Make related execution reusable across work records; stop substituting rewritten briefs for authoritative intent; resolve contradictions at their source; correct information-losing result shaping.

This distinction matters: the preprint is about reusing completed reasoning, not making every input as small as possible. A useful prepared functional account may save more reasoning than it costs to transmit. The present design sometimes economizes on a tool payload while introducing another agent, another classification, another maintenance duty, or another rewrite. P01 §§1–2, 8.

### What is established, and what is not

**Source-observed** means a rule or code path is present in the pinned revision. **Reproduced** means the isolated functions were executed on stated fixtures. **Inferred** means the probable effect on agent behavior or spending follows from the mechanism but was not measured in production. **Unknown** includes selected runtime prompt overrides, host-loaded personal instructions, actual retry frequency, billing and output quality.

This is a broad cross-system audit of relevant entry points and their execution paths, not a claim to have executed every module or read every generated specialist prompt in your home store. No production savings percentage is asserted.

## 1. The current flow is more sophisticated than a naïve supervisor loop

The actual source already has substantial machinery worth retaining:

1. Specialist selection uses lightweight purposes rather than loading every role body; decisions are fingerprinted/cached. Assignment runtime selection is retained against the task fingerprint. This is not an unconditional classifier on every turn. [S13](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/runtime.py) [S14](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/routing.py) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)
2. Assignments, child returns, role commissions, change orders and pending deliveries are durable. Transport is separated from orchestration records. Work-change handling uses relevant work IDs and event kinds instead of indiscriminately revisiting every task. [S11](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/orchestration.py) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py) [S29](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/storage.py)
3. Role text uses rendered-content receipts and context epochs. Memory delivery has identity/revision handling. The system is not simply resending every unchanged role and memory on every MCP call. [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S22](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/delivery.py)
4. MCP tool discovery is lazy and module-based, with a direct-call path; result filtering and count views can keep irrelevant records out of a response. Compact instructions are already a default mechanism. [S04](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/instructions.py) [S16](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py) [S17](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/catalog.py) [S18](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/shaping.py)
5. Routine updates wait in a compact liaison inbox; full messages/evidence remain available. A relayed user decision bypasses the ordinary summarized peer-note presentation. The existing exact-message path should be extended, not replaced. [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml)
6. Adaptive mode already distinguishes notifying the user from requesting approval. Completion is deliberately separate from Git publication and independent review. Those are important existing design choices. [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml)

The useful revision is therefore **less repeated reasoning around this machinery**, not replacement of the machinery with another agent bureaucracy.

## 2. Findings, in priority order

### F01 — Ticket identity is also a context-lifetime boundary

**Priority: high. Evidence: source-observed; spending effect inferred.**

`dispatch/runner.py` describes one ACP session per ticket. `Orchestration.bind` rejects a session already bound to another assignment. Transport can resume a previous session for the same work item when configured and supported. The helper prompt/lifecycle ends the helper when its single turn ends. [S10](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/runner.py) [S11](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/orchestration.py) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py) [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml)

This preserves ownership, but a series of small related tickets cannot naturally use one accumulating local understanding. The functional map is reused as data; the worker's newly acquired implementation understanding is repeatedly reconstructed. Resuming the same ticket does not solve reuse across related tickets. Conversely, retaining one transcript indefinitely would introduce a different context problem.

**Refinement:** separate work records from a coherent execution episode. A session can handle successive related contributions under an explicit current binding; historical bindings remain intact. An episode retains relevant decisions and functional locations. Session replacement is possible without changing the episode's identity. Keep distinct roles distinct: reuse a worker for related worker work, not a liaison as a tester or a reviewer as the implementer.

**Verification:** three related work records execute through one suitable worker session; each result and tool write remains attributed to the active record. An independent assessment still uses its own role/session. Returning to an earlier work record does not overwrite its earlier result history.

### F02 — The repository explicitly teaches agents to rewrite the user's intent

**Priority: high. Evidence: source-observed; downstream drift inferred.**

`CLAUDE.md` says briefs/tickets/prompts should be written from understanding rather than copied, and instructs agents to encode intent without quoting the person. In contrast, the workflow lexicalizer preserves instruction words/order while replacing project referents. The runtime Planner prompt edits the task into a more precise task. [S02](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/CLAUDE.md) [S24](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/workflow/resources/prompts.xml) [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml)

Interpretation is necessary; using interpretation as the replacement authority is not. These instructions create a plausible path from user request → liaison account → planning rewrite → specialist brief in which an operative exception, open-ended request, or distinction disappears. The source also contains exact user relay and history facilities, so this is not a claim that all original messages are lost. Completed-ticket Git history alone does not establish immutable provenance for every intermediate request/edit. [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S28](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/ticket_history.py)

**Refinement:** retain an addressable, verbatim source request and subsequent user revisions. Store interpretation, lexical mappings, plan and selected imperatives separately. Deliver relevant exact spans when they carry the operation, exceptions or constraints; reference the remainder. A shorter child assignment need not quote an entire conversation, but it should not become the only evidence of what was requested.

**Verification:** an instruction containing an exception, an open-ended goal and a prohibition reaches worker/reviewer with its exact source available. A plan revision changes the plan, not the user-source record. A research conclusion is not reclassified as a user decision.

### F03 — Model selection and plan preparation can become a significant entry cost

**Priority: high. Evidence: source-observed; cost distribution unknown.**

A fresh automatically routed ticket can use one JEV specialist choice, followed by runtime task classification and runtime selection. Failed/unavailable/uncertain decisions can commission a full Facilitator. `prepare_runtime` turns `needs_plan` into a Planner child and delays the original implementation launch. These decisions are cached; the issue is their granularity, not an every-turn loop. [S13](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/runtime.py) [S14](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/routing.py) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)

`runtime_task` asserts that missing concrete behavior/acceptance evidence requires a separate plan because a stronger implementer cannot replace it. That is a design judgment encoded as a launch dependency. It can make a capable worker pay for a separate planning episode before resolving an ordinary local engineering question. Planning can also be genuinely useful; removing it indiscriminately would lose value.

**Refinement:** reuse established expertise/runtime within a coherent episode. Ask a model for organization when a real decomposition or coordination decision exists. Let workers develop local implementation approaches as part of execution. Preserve a separate Planner for work that benefits from it. If JEV remains, use decisions already supplied by the current responsible agent rather than repeating them in another call; consolidate related selection decisions when their inputs are already shared.

**Verification:** related continuation performs no new expertise/runtime classification merely because a new card exists. A novel multi-workstream objective still receives planning. Missing local implementation detail does not automatically produce another agent.

### F04 — Runtime preferences are implemented as candidate exclusion, and optional effort becomes mandatory

**Priority: high. Evidence: source-observed and reproduced.**

`runtime._candidates` excludes non-Codex agents for `coding` and non-Claude agents for `frontend` unless an explicit agent override exists. `_efforts` returns no values when effort is absent or unrecognized; every candidate requires an effort value. [S13](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/runtime.py)

Local fixtures show zero candidates for an otherwise available model without an effort selector, and zero coding candidates for a Claude-only catalog until an explicit override is supplied. These are routing/admission restrictions, not evidence that every role is permission-gated.

**Refinement:** distinguish explicit user choice from preference. Use the person's model-strength descriptions and advertised capabilities to select; keep an available alternative usable. Represent an unsupported effort control as absent, allowing the harness default, rather than inventing a setting or declaring the model unavailable. Carry optionality through validation, persistence and transport, not just this function.

**Verification:** catalogs with no effort control, unfamiliar effort labels and a single alternate capable agent remain representable. Explicit user choices still select the requested runtime. Invalid advertised IDs still produce accurate transport/configuration errors.

### F05 — Memory reading is turned into mandatory cleanup work

**Priority: high. Evidence: source-observed; behavioral cost inferred.**

`memory:refine` and the final part of `memory:instructions` require cleanup whenever an agent reads memory, including removing non-durable/non-useful entities, checking facts, correcting and merging. The same system also encourages search, open and ongoing memory maintenance. [S23](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/resources/prompts.xml)

Useful maintenance becomes a recurring second assignment. A worker reading one relevant fact can be pulled into auditing nearby knowledge before doing its real job. “Useful” can also be interpreted from that worker's narrow task even though the knowledge serves another receiver or future activity. The preprint explicitly gives memory meaningful functional locations; relevance to today's task is not equivalent to long-term value. P01 §7.

**Refinement:** keep unrestricted canonical CRUD and explicit responsibility for memory quality. Tie corrections to evidence established in the work, and consolidation to actual duplication encountered. Maintenance should contribute to the assignment or preserve a reusable finding, not require a fresh audit on every read. The revised text preserves atomic observations, directed relations, durable rationale and work-record incident evidence.

**Verification:** retrieving an unchanged relevant memory does not require another investigation/cleanup episode. A disproven observation is corrected with its reason/evidence. An unrelated valid fact remains even when irrelevant to this particular task.

### F06 — The FQC has two contradictory correction routes

**Priority: high. Evidence: source-observed.**

The `functionality` prompt first tells the FQC to create one corrective ticket per finding and route each to the Facilitator. Later it says findings reopen the reviewed ticket. The current runtime's `_finding` attempts to match existing work, and `_correction` reopens the original delivery assignment/ticket. [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)

An obedient model can create independent corrective tickets and then return the same findings into a runtime that also reopens original work. This is a concrete prompt/code mismatch, not an argument against independent evaluation.

**Refinement:** make the assessment return the single source of findings and let the existing correction mechanism record/reroute them. Distinct new work can be proposed as such when the finding genuinely calls for it; it is not the automatic format of every review. Preserve FQC independence, substantive evidence and adaptive specification reasoning.

**Verification:** one assessment with three findings yields one coherent correction continuation on the reviewed work, with three traceable findings—not three new specialist starts plus an original-ticket restart. Independent new outcomes remain separately representable.

### F07 — A new user message can suppress all findings by lexical overlap

**Priority: high. Evidence: source-observed; no production occurrence measured.**

`returned` calls `_decided` for an assessment. `_decided` checks whether a newer user direction names the reviewed functional location or short name. When true, the complete findings list is not filed. [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)

A message naming the parser might change one requirement while leaving a separate data-loss defect relevant. Name overlap and a later timestamp do not establish that every finding is superseded.

**Refinement:** retain the assessment and the requirement/candidate revision it examined. Attach newer direction as evidence for the responsible agent to reconcile. Identify affected findings individually, using the actual meaning of the change. Code can detect a revision difference; it cannot prove semantic supersession from a substring match.

**Verification:** a later cosmetic instruction mentioning the same component does not erase an unrelated functional defect. A genuinely superseded requirement is clearly identified without duplicating correction work for it.

### F08 — Result compaction can remove requested evidence or erase false values

**Priority: high. Evidence: reproduced on copied source functions.**

The `mcp/shaping.py` reproduction results are:

| Fixture | Actual outcome |
|---|---|
| Request `candidate.artifact.hash` | Validation accepts it; `_trim` returns `{}`. |
| `view=full`, `fields=[id]`, `status_equals=open` | Full early return ignores projection and filter. |
| Read record with `passed=false`, explicitly request `passed` | `lean` removes it before field checking; requested field is reported absent. |

These fixtures prove local semantics, not that those exact objects are routinely emitted by every production tool. [S18](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/shaping.py) D01.

**Refinement:** operate on typed data in a clear sequence: validate requested fields against the unmodified structure; filter records; recursively project selected paths; render the selected result. Full versus triage should determine representation/default detail, not silently cancel explicit selection. Preserve false/zero/empty when meaningful or explicitly requested. Select default omissions by the actual tool contract rather than assuming every false field has the same meaning.

**Verification:** nested selections retain their exact value and structure; explicit filters have the same selection semantics across views; `false`, missing and unknown remain distinguishable. Exercise lists of nested objects as well as nested dictionaries.

### F09 — High-priority native instructions conflict with concise role behavior

**Priority: high. Evidence: source-observed; final loaded context adapter-dependent.**

`AGENTS.md` requires a narrated analysis/benefits/originality/action sequence. The implementer says to keep routine reasoning internal and communicate decisions briefly. The liaison has a detailed banned-word/style checklist and requires reconstruction of every outgoing reply/plan/ticket. `CLAUDE.md` adds its own global and glossary directions and explicitly points agents to AGENTS.md. [S01](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/AGENTS.md) [S02](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/CLAUDE.md) [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml) [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml)

These are not merely many words. They prescribe extra output operations and conflicting priorities. The inspected AGENTS and CLAUDE source bodies total 28,954 bytes; that is a source-size observation, not a token estimate or proof that every adapter loads both. Root project guidance also affects agents developing Metaform itself; it is not automatically the same instruction stack for every project Metaform manages.

**Refinement:** retain functional semantics and substantive engineering requirements. Remove the universal narration ritual and the per-message rewrite ritual; use direct outcome/evidence language. Put long task-specific performance/protocol material behind relevant references. Resolve conflicting instructions rather than adding another “override” paragraph to compete with them.

**Verification:** a straightforward repair is executed and reported without an obligatory essay or repeated stylistic reconstruction; architectural reasoning is still available where it matters. Compare effective native instruction sources for each tested harness, not only XML source size.

### F10 — The liaison is instructed both to force a hold decision and to preserve justified holds

**Priority: high. Evidence: source-observed.**

`dispatch:system` tells the liaison it must cancel or unhold a ticket or it will be woken every 15 minutes. The next instructions say preserve real prerequisites, never cancel valid work to stop reminders, and leave a justified hold in place. [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml)

This creates a behavioral contradiction and an incentive to act to end reminders. Source wording establishes the contradiction; the timer implementation and actual reminder frequency were not reproduced here.

**Refinement:** keep justified waiting as a normal state with a reason and relevant release event. Review on changed prerequisites, a meaningful deadline or user direction. Unhold when the reason resolves; cancel when the outcome is no longer wanted or valid. Remove the coercive cancel-or-unhold sentence rather than adding another exception to it. Preserve explicit user stops and actual dependency readiness.

**Verification:** an unchanged justified hold does not cause repeated identical decision work. Satisfying its dependency resumes it. The user can still start, stop or discuss work through the existing interfaces.

### F11 — Some role-return wording names the Facilitator instead of the actual caller

**Priority: medium-high. Evidence: source-observed.**

The common prompt correctly tells agents to use the recorded return destination, then describes every specialist as assigned by/returning to the Facilitator. In the runtime, a specialist may return to its immediate parent, a GC, or another recorded route; the Facilitator may only have published expertise/runtime. [S12](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml) [S15](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)

This can encourage an unnecessary relay or an additional narrated handoff even though the runtime already routes results.

**Refinement:** use the recorded caller/return route once. Treat role creation as preparing expertise, not owning every subsequent result. Store one substantive result; inboxes and views carry references and the decision-relevant summary.

**Verification:** a worker-called specialist returns to that worker and is not separately re-reported to a Facilitator merely because the role was created there.

### F12 — A retention key is not an inventory of retained understanding

**Priority: medium-high. Evidence: source-observed; ACP boundary verified.**

The role service has a retention challenge keyed to the context epoch. A matching reply confirms the key; an absent/incorrect reply can advance the epoch as retention unconfirmed. The runner attaches checks to actual turns rather than necessarily starting a dedicated check-only model turn. [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S10](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/runner.py)

Remembering a key does not prove the role body, original instruction, evidence or functional relationship survived compaction. Missing a key can mean ordinary noncompliance rather than context loss. A new epoch makes material eligible again; it does not establish that every old item disappeared. The current compaction proposal supplies lifecycle updates and optional summaries, not a complete model-context manifest.

**Refinement:** distinguish delivery history, compaction observation and uncertain retention. Use actual adapter compaction events when available. Treat the nonce as limited diagnostic evidence, not semantic retention proof or a reason to reconstruct everything. Rehydrate relevant material for continuing work and permit exact explicit rereads. This is an observation model, not a new execution gate.

**Verification:** key survives while one useful fact does not; key omitted despite retained facts; compaction reported without a summary; unsupported compaction reporting. None is falsely recorded as complete knowledge of the hidden context.

### F13 — Several independent “shown” lifecycles can disagree

**Priority: medium. Evidence: source-observed; resulting user-visible incidence unmeasured.**

Role receipts, generic shown records, memory delivery revisions and workflow library markers represent different things. Generic `shown` records expire after seven days on a subsequent write; process-local sessions disappear with the process. Compaction deliberately preserves `catalog:` and `guide:` records, while other prompt wording can imply broad guide restoration. Explicit guide reads remain available. [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S19](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/shown.py) [S22](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/delivery.py) [S24](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/workflow/resources/prompts.xml) [S09](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml)

These are not all bugs: host catalog state can survive while model text does not, and not re-sending every guide is sensible. The issue is treating the records as a single claim that an agent currently possesses something.

**Refinement:** give each receipt a clear meaning and scope: delivered content revision, retained host configuration, or discovery history. Tie content deduplication to the episode/session epoch and preserve explicit rereads. Align restoration wording with actual behavior. Let storage cleanup follow session lifecycle where reliable, without assuming age proves compaction.

**Verification:** resume after process replacement and after receipt expiry; compact and explicitly request a previously shown guide; alternate shared text A→B→A. Compare actual returned payloads, not just receipt counts.

### F14 — Memory freshness now depends mainly on the reader revisiting the node

**Priority: medium-high for long-lived work. Evidence: source-observed; deliberate policy difference.**

Memory prompt comments explicitly say nothing is pushed when memories change. Around-node reads report counts/revisions and access paths. This avoids unsolicited context floods, but an already-working consumer can continue with an earlier assumption until it rereads the relevant location. [S20](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/around.py) [S22](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/delivery.py) [S23](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/resources/prompts.xml)

This differs from the earlier proposed working model's propagation to existing consumers. It is an intentional current policy, not an undiscovered missing implementation.

**Refinement proposed for long-lived episodes:** retain who consumed a relevant item/revision and coalesce a small changed-reference notice into that consumer's next natural turn. Fetch the exact correction and its superseded reference when needed. Do not broadcast every memory or wake a model for routine unrelated writes. Distinguish the consumer's own writes from new external information.

**Verification:** one relevant external correction reaches an already-engaged consumer; unrelated memories and the consumer's own writes do not cause unnecessary notifications; multiple changes coalesce while retaining latest revision and deletion semantics.

### F15 — Context selection sometimes follows storage shape rather than the task's reason

**Priority: medium. Evidence: source-observed; task impact inferred.**

The node brief's omission prompts describe dropping source paths, then received joins, then reducing the tree and eventually provider joins after the first. Around-node presentation is one-hop and bounded by side count. Optional Jev ranking asks about usefulness at a node. These are useful presentation choices, but none alone establishes which receiving purpose matters to a particular assignment. [S20](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/around.py) [S21](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/resources/prompts.xml) [S03](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/resources/prompts.xml)

A short representation can omit the distant receiver or precise source reference that makes the task intelligible, causing later rediscovery. This does not justify loading the entire graph every time.

**Refinement:** let the assignment's outcome and receiving purpose select the essential functional context. Keep global orientation compact, local evidence addressable, and the entire map available. Preserve identities and purposes before decorative/count detail. Treat display byte limits as display constraints, not a definition of sufficient understanding.

**Verification:** a task governed by a receiver that is not first in storage order receives that relationship; an irrelevant adjacent branch does not load merely because it is adjacent. Compare follow-up discovery and correctness, not only packet bytes.

### F16 — Glossary language can constrain reasoning rather than preserve meaning

**Priority: medium. Evidence: source-observed; behavioral effect inferred.**

The peer register prohibits terminology drift, which protects Metaform's semantics. It also says never to reason through independently constructed concepts. Read literally, this can discourage a worker or critic from proposing a better arrangement not yet named in the glossary. [S21](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/resources/prompts.xml)

Preserving the meanings of RE, OP, EF, joins and C(T) is different from limiting the concepts an agent can explore. Likewise, “attach knowledge to the RE” should be read through the actual receiver-owned relationship; an element can be a receiver in one relationship and provider in another. The preprint supports that perspectival distinction. P01 §§4, 6–8.

**Refinement:** preserve canonical terms and definitions verbatim where those concepts are used. Clearly distinguish a proposed concept/arrangement from an established one, and retain its functional rationale. Remove the ban on independent concepts rather than converting it into a vocabulary-approval procedure.

**Verification:** a critic can propose a new implementation arrangement while correctly preserving or explicitly discussing the relevant functional identity. It does not silently rename established concepts.

### F17 — Native expert-role wrappers introduce their own architecture and audit bias

**Priority: medium. Evidence: source-observed; activation conditional.**

The native MCP expert has useful source→host→model distinctions, but says counting tokens is not its job and presents a mandatory sequential category-opening procedure. The implementation uses module-owned discovery and direct-call support, and the task here explicitly requires cost diagnosis. Its lengthy embedded protocol account is also tied to a specific revision rather than the installed adapter's negotiated behavior. [S26](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/mcp-context-expert.md) [S17](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/catalog.py)

The native critic has strong evidence discipline, but also requires three-to-six tickets, treats later dropped requirements as regressions by definition, and omits a finding unless it can prescribe full remediation. Its broad performance paragraphs are unrelated to many non-UI audits. [S27](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/critic.md)

**Refinement:** keep the MetaformFoundation and canonical semantics intact. Revise the wrappers to investigate the assignment's actual question, report established defects even when a remedy remains uncertain, and measure total work where cost is the target. Determine whether a later change was authorized before calling it a regression. Load specialized reference detail when needed. These files are conditional native-role surfaces, not proof that every dispatched worker receives them.

**Verification:** a context-cost audit reports actual startup/reasoning/repair costs and unknowns; an authorized design change is not labelled a regression merely for differing from an earlier document; no arbitrary ticket count is generated.

### F18 — Prompt edits can miss the text actually being served

**Priority: high for remediation reliability. Evidence: source-observed; deployment selections unknown.**

`prompt_files` serves selected prompt-store edits, supports trial files, and merges specified exact-anchor updates. Broken XML can fall back to a last shipped stored version while recording/reporting a problem. Existing role assignments can retain snapshots. Global native pointers/hooks update when provisioning runs, not merely when XML changes. [S06](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/prompt_files.py) [S07](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py) [S05](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/agent_setup.py)

Consequently, changing a source prompt and reading the file back does not prove a running agent received the change. Nor is a role named `system` a native model system message: the installed ACP/harness path determines its actual role and priority.

**Refinement:** extend the existing rendered `Sent`/role receipts into an observational effective-instruction manifest. Show shipped identity, selected edit/version, rendered digest, delivery path and known native instruction sources. Preserve user edits; make unresolved source/selection differences visible. Validate the delivered payload after a change. The manifest does not become a prerequisite for agents to work.

**Verification:** exercise shipped text, selected edit, trial text, malformed-source fallback, existing assignment snapshot and resumed session. The report identifies exactly what Metaform sent in each case and clearly marks native/internal material it cannot see.

## 3. Capabilities, workflow controls and actual dependencies

The inspected `catalog.py` applies `roles_without_authority` dynamically. It does not justify replacing the user's model with a default-deny role matrix. Lazy discovery is not the same thing as a permission boundary. Preserve direct-call semantics and the configured blacklist's actual behavior. [S17](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/catalog.py)

Distinguish these cases:

| Mechanism | Treatment |
|---|---|
| User stop, configured Full Auto setting, finite process capacity | Preserve existing user/lifecycle control. |
| A task truly needs another task's output | Retain the dependency; it is not a speculative approval step. |
| An explicitly requested proposal-only assignment | Preserve proposal-only behavior; approval belongs to that selected operation. |
| Schema/identifier validation needed to execute a tool correctly | Preserve accurate protocol/data behavior. |
| A model must satisfy `needs_plan` before any implementation | Reconsider as an organizational judgment, not universal readiness law. |
| A role may think/act only through a capability whitelist | Not proposed. |
| Spec adaptation in adaptive mode | Retain functional reasoning, recorded revision and user notification. |

## 4. Working shape grounded in this implementation

Keep the board. Introduce an execution episode that can cover one or several related work records. Keep liaison, planning, execution and independent assessment as different responsibilities, invoked according to the work rather than as a mandatory sequence.

```text
User's request and revisions — retained as source
                 |
              Liaison — intent, continuity, user interaction
                 |
       Existing work / plan / functional graph
                 |
        Runtime selects a useful execution episode
                 |
   Continued, resumed, or freshly grounded worker session
                 |
   Result + evidence + functional findings stored once
                 |
    Existing continuations, dependencies and board views
                 |
     Independent assessment where requested/configured
```

This is not a new top-level manager. It removes coupling between “a new record exists” and “another context must be started.” It also does not promise that a warm context is always cheaper: a highly unrelated accumulated transcript may be worse than reconstruction from prepared understanding.

The runtime handles readiness, attribution, message coalescing and durable delivery. Agents decide what constitutes useful work, relevant evidence, a meaningful organization and a better realization of the function. The functional graph remains a prepared reasoning substrate, not an execution DAG or an access-control list.

## 5. ACP boundary and measurement

ACP session setup and agent-advertised configuration are the implementation boundary. Client-provided system prompts remain a Draft feature; do not depend on a universally available system slot. A mode can select harness-defined behavior, not install arbitrary client text with guaranteed priority. Optional compaction updates do not expose all retained context. These distinctions are documented in SOURCE_INDEX.md.

Record what is observable: adapter/version, session creation/resume, model/effort choices actually advertised, Metaform-rendered prompt bytes/versions, tool result bytes, available usage/cost reports and compaction events. Record unavailable billing or hidden prompt composition as unknown, not zero. `session/load` history replay to the client is not proof that the same transcript is newly billed to the model.

Compare total cost per achieved objective, including organizational calls, native onboarding, worker execution, evaluation, repair and user correction. Separately measure initial bytes, subsequent repeated bytes, model turns, tool calls and elapsed time. Test the same useful outcome with prepared functional understanding held constant. Do not reward a smaller prompt that loses intent or increases rediscovery.

## 6. What this audit would change first

First fix the result-shaping failures and contradictory correction/hold/return instructions. Preserve user-source provenance and verify the effective prompt stack. Then introduce episode/session reuse and remove unnecessary planning/selection re-entry. Finally refine memory freshness and context reconstruction using actual adapter signals.

The source already contains the foundations for this. The strongest next revision is **fewer unnecessary transitions between models, faithful source intent, and selective continuity of understanding**—not shorter text at any cost.
