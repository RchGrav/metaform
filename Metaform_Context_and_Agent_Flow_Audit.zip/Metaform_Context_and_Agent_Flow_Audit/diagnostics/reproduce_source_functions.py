"""Read-only, isolated reproductions of functions inspected through the GitHub connector.

Source: RchGrav/metaform @ 4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351.
The functions below are copied from the inspected source (not a checked-out repository).
Only JSON-like values are used. `plain` is identity for these already-plain fixtures.
This is NOT the repository test suite or a production ACP run.
"""
from __future__ import annotations
import dataclasses
import json
from typing import Any, cast
from collections.abc import Mapping, Sequence

DEAD = frozenset({'node_kind', 'node_id', 'layer_id', 'is_work', 'age_seconds', 'existing', 'differs', 'orphaned', 'position'})
STATUS = ('status', 'state', 'column', 'condition')
LIST_MOST = 25

class Unheld(ValueError):
    pass

@dataclasses.dataclass(frozen=True)
class Shape:
    view: str = 'triage'
    fields: tuple[str, ...] = ()
    must_contain: str = ''
    status_equals: str = ''
    given: list[bool] = dataclasses.field(default_factory=list[bool], compare=False)
    @property
    def filtered(self) -> bool:
        return bool(self.must_contain or self.status_equals)

def lean(value: Any, *, row: bool = False, nested: bool = False) -> Any:
    if isinstance(value, dict):
        given = cast(dict[str, Any], value)
        kept: dict[str, Any] = {}
        for key, one in given.items():
            if key in DEAD or given.get(f'{key}_address') or (nested and key == 'id' and given.get('address')):
                continue
            made = lean(one, row=row, nested=True)
            if made is None or made == '' or made == [] or made == {} or (row and made is False):
                continue
            kept[key] = made
        return kept
    if isinstance(value, (list, tuple)):
        return [lean(one, row=True) for one in cast(list[Any], value)]
    return value

def _flat(row: dict[str, Any], prefix: str = '') -> dict[str, Any]:
    found: dict[str, Any] = {}
    for key, value in row.items():
        if isinstance(value, dict):
            found.update(_flat(cast(dict[str, Any], value), f'{prefix}{key}.'))
        else:
            found[f'{prefix}{key}'] = value
    return found

def _held_fields(rows: list[dict[str, Any]]) -> list[str]:
    found: list[str] = []
    for row in rows:
        found += [key for key in _flat(row) if key not in found]
    return found

def _named(key: str, fields: tuple[str, ...]) -> bool:
    return key in fields or key.split('.', 1)[0] in fields or key.rsplit('.', 1)[-1] in fields

def _check(rows: list[dict[str, Any]], shape: Shape) -> None:
    held = _held_fields(rows)
    if not rows:
        return
    unheld = [one for one in shape.fields if not any(_named(key, (one,)) for key in held)]
    if unheld:
        raise Unheld(f'No record here holds {", ".join(unheld)}; they hold {", ".join(held)}.')
    if shape.status_equals and not any(key in STATUS for key in held):
        raise Unheld(f'status_equals compares {", ".join(STATUS)}, which no record here holds; they hold '
                     f'{", ".join(held)}. must_contain finds a value in any field.')

def _trim(value: Any, fields: tuple[str, ...]) -> Any:
    if isinstance(value, list):
        return [_trim(one, fields) for one in cast(list[Any], value)]
    if not isinstance(value, dict):
        return value
    kept: dict[str, Any] = {}
    for key, one in cast(dict[str, Any], value).items():
        if key in fields:
            kept[key] = one
        elif isinstance(one, dict):
            inner = {name: held for name, held in cast(dict[str, Any], one).items()
                     if _named(f'{key}.{name}', fields)}
            if inner:
                kept[key] = inner
    return kept

def compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), default=str)

def full_branch(result: Any, shape: Shape) -> tuple[str, dict[str, Any] | None] | None:
    # Exact early-return branch of shaped(), after plain(result).
    data = result
    if shape.view == 'full':
        return compact(data), cast(dict[str, Any], data) if isinstance(data, dict) else None
    return None

LEVELS = {'off': 0, 'disabled': 0, 'none': 0, 'minimal': 1, 'light': 1, 'low': 2,
          'medium': 3, 'high': 4, 'xhigh': 5, 'max': 6, 'pro': 6, 'ultra': 7}

def _efforts(offered: Sequence[str], task_type: str) -> list[str]:
    ranked = {one: LEVELS[one.lower()] for one in offered if one.lower() in LEVELS}
    if not ranked:
        return []
    if task_type == 'routing':
        target = min(ranked.values())
    elif task_type == 'lookup':
        target = min(ranked.values(), key=lambda value: (abs(value - LEVELS['low']), value))
    elif task_type in ('planning', 'needs_plan'):
        target = max(ranked.values())
        if target < LEVELS['high']:
            return []
    else:
        floor = LEVELS['high'] if task_type == 'analysis' else LEVELS['medium']
        return [one for one, level in ranked.items() if level >= floor]
    return [one for one, level in ranked.items() if level == target]

def _candidates(catalog: Mapping[str, Any], task_type: str,
                overrides: Mapping[str, Any] | None = None) -> dict[str, dict[str, str]]:
    choices: dict[str, dict[str, str]] = {}
    fixed = overrides or {}
    for agent, offered in catalog.items():
        if fixed.get('agent') and agent != fixed['agent']:
            continue
        if not fixed.get('agent') and ((task_type == 'frontend' and agent != 'claude')
                                       or (task_type == 'coding' and agent != 'codex')):
            continue
        for model in offered.get('models', {}):
            if fixed.get('model') and model != fixed['model']:
                continue
            efforts = ([fixed['effort']] if fixed.get('effort') in offered.get('efforts', [])
                       else [] if fixed.get('effort') else _efforts(offered.get('efforts', []), task_type))
            for effort in efforts:
                key = json.dumps([agent, model, effort], separators=(',', ':'))
                choices[key] = {'agent': agent, 'model': model, 'effort': effort}
    return choices

def main() -> None:
    results: list[dict[str, Any]] = []
    nested = {'candidate': {'artifact': {'hash': 'abc123', 'path': 'result.txt'}}}
    shape = Shape(fields=('candidate.artifact.hash',))
    _check([nested], shape)
    projected = _trim(nested, shape.fields)
    assert projected == {}
    results.append({'case': 'nested_projection', 'validation': 'accepted',
                    'requested': list(shape.fields), 'actual': projected})
    raw = {'results': [{'id': 'A', 'state': 'open', 'evidence': 'KEEP'},
                       {'id': 'B', 'state': 'done', 'evidence': 'OMIT'}]}
    output = full_branch(raw, Shape(view='full', fields=('id',), status_equals='open'))
    assert output is not None and output[1] == raw
    results.append({'case': 'full_bypasses_filter_and_projection', 'actual': output[1]})
    compressed = lean({'id': 'check-1', 'passed': False}, row=True)
    error = None
    try:
        _check([compressed], Shape(fields=('passed',)))
    except Unheld as caught:
        error = str(caught)
    assert compressed == {'id': 'check-1'} and error is not None
    results.append({'case': 'explicit_false_removed_before_field_check', 'actual': compressed, 'error': error})
    optional_effort = _candidates({'codex': {'models': {'m': 'Available model'}, 'efforts': []}}, 'coding')
    assert optional_effort == {}
    results.append({'case': 'adapter_without_effort_selector', 'candidate_count': len(optional_effort)})
    alternative = {'claude': {'models': {'m': 'Available model'}, 'efforts': ['high']}}
    without = _candidates(alternative, 'coding')
    with_override = _candidates(alternative, 'coding', {'agent': 'claude'})
    assert without == {} and len(with_override) == 1
    results.append({'case': 'coding_brand_filter', 'without_override': len(without),
                    'with_explicit_agent_override': len(with_override)})
    print(json.dumps({'snapshot': '4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351',
                      'scope': 'isolated source-function reproductions, not repository tests',
                      'results': results}, indent=2))

if __name__ == '__main__':
    main()
