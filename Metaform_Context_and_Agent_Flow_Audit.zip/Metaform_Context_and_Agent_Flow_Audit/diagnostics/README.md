# Isolated source-function reproduction

Run with Python 3.11 or newer:

```bash
python diagnostics/reproduce_source_functions.py
```

No external packages, repository access, agent calls or network are used. The script prints JSON and checks the five observed current behaviors. Its assertions confirm the observed failures/exclusions; it is not a proposed fixed implementation.

The functions are copied from the reviewed source, with comments/docstrings reduced. `full_branch` is the exact early-return branch of `shaped`; inputs are already plain JSON-like values, so the repository's `plain` conversion is identity for these fixtures. The complete repository test suite was not run.

`results.json` is the actual output from the local execution. The findings establish these functions' semantics, not which of the fixtures occurs in production or what fraction of the user's spending it causes.
