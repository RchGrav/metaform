# Sources and evidence scope

## Repository

All links below are pinned to `4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351`. Function and XML-element names in the audit identify the relevant code; GitHub connector responses often serialized a complete file into one content field, so this report does not invent source line numbers.

**S01. [AGENTS.md](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/AGENTS.md)**

Repository-wide development instructions; mandatory explanation sequence.

**S02. [CLAUDE.md](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/CLAUDE.md)**

Imports AGENTS.md; paraphrasing policy; persistent glossary and development guidance.

**S03. [src/metaform/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/resources/prompts.xml)**

Global pointers, hook reminder, optional debug text, Jev questions, remote and intake openings.

**S04. [src/metaform/instructions.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/instructions.py)**

Compact/full instruction composition and module-status additions.

**S05. [src/metaform/agent_setup.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/agent_setup.py)**

Global native-harness instruction files and passive Claude hook installation.

**S06. [src/metaform/prompt_files.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/prompt_files.py)**

Authored XML, selected store edits, trial prompts, migrations, Sent records and fallbacks.

**S07. [src/metaform/modules/agents/roles.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/roles.py)**

Role resolution, rendered-text delivery receipts, context epochs and retention checkpoints.

**S08. [src/metaform/modules/agents/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/agents/resources/prompts.xml)**

Agent role lookup and context restoration wording.

**S09. [src/metaform/modules/dispatch/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/resources/prompts.xml)**

Work, helper, liaison, checkpoint, communication and inbox prompts.

**S10. [src/metaform/modules/dispatch/runner.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/runner.py)**

Ticket/session lifecycle, ACP interaction and context-check integration.

**S11. [src/metaform/modules/dispatch/orchestration.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/dispatch/orchestration.py)**

Durable transition transport, launch, same-ticket resume, waiting and messaging.

**S12. [src/metaform/modules/orchestration/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/resources/prompts.xml)**

Shared instructions, responsibility prompts, specialist/runtime classification and plan refinement.

**S13. [src/metaform/modules/orchestration/runtime.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/runtime.py)**

Runtime choice, candidate exclusions and effort policy.

**S14. [src/metaform/modules/orchestration/routing.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/routing.py)**

Specialist selection, cached decisions, creator fallback and routing continuation.

**S15. [src/metaform/modules/orchestration/state.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/orchestration/state.py)**

Assignments, sessions, continuation, result routing, review suppression and correction reopening.

**S16. [src/metaform/modules/mcp/server.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/server.py)**

Tool discovery/schema/result assembly, guides and delivery integration.

**S17. [src/metaform/modules/mcp/catalog.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/catalog.py)**

Module-based discovery; configured roles_without_authority handling.

**S18. [src/metaform/modules/mcp/shaping.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/mcp/shaping.py)**

Triage/full results, filters, projections, empty/false suppression.

**S19. [src/metaform/shown.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/shown.py)**

Session shown-records, expiry and compaction treatment of catalog/guide records.

**S20. [src/metaform/modules/map/around.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/around.py)**

Node and neighbor counts, pointers, revisions and on-read updates.

**S21. [src/metaform/modules/map/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/resources/prompts.xml)**

Orientation, glossary, brief omissions, adaptive-mode and blindspot instructions.

**S22. [src/metaform/modules/memory/delivery.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/delivery.py)**

Memory identity/revision delivery and receipts.

**S23. [src/metaform/modules/memory/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/memory/resources/prompts.xml)**

Search/open, CRUD, mandatory read-time cleanup and memory notices.

**S24. [src/metaform/modules/workflow/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/workflow/resources/prompts.xml)**

Exact lexicalization, same-agent calls, handoffs, selected libraries and execution wording.

**S25. [src/metaform/modules/roundtables/resources/prompts.xml](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/roundtables/resources/prompts.xml)**

Question scope, discussion, recorded outcomes, proposal and adoption.

**S26. [.claude/agents/mcp-context-expert.md](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/mcp-context-expert.md)**

Native expert role, embedded protocol reference and context-selection doctrine.

**S27. [.claude/agents/critic.md](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/.claude/agents/critic.md)**

Native critic role and preserved MetaformFoundation.

**S28. [src/metaform/modules/map/ticket_history.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/ticket_history.py)**

Completed-ticket snapshots in Git; not evidence of universal request/edit provenance.

**S29. [src/metaform/modules/map/storage.py](https://github.com/RchGrav/metaform/blob/4ccf5d2e2b70bbb6be0eb3e6ab23a9aae0573351/src/metaform/modules/map/storage.py)**

Work persistence and differentiated work-change events; inspected relevant portions.

## Supplied documents

**P01.** `inference-metaform(1).md`, supplied in this conversation. Relevant sections: §1 (amortization vs token volume); §2 (not a mandatory whole pipeline); §4 (receiver-owned purposes); §6 (exact C(T), not an approval gate); §7 (memory and informational/imperative layers); §8 (lexicalization preserves the operation); §9 (substantive blindspot response); §12 (intent-driven formation). Its implementation snapshot is older than the reviewed repository. The audit compares design concepts without treating old implementation boundaries as current defects.

**C01.** `Vibe-Coding-Cookbook-main.zip`, supplied in this conversation and inspected locally. Exact internal paths appear in COOKBOOK_ASSESSMENT.md. No separate prompt-writing guide was present among the mounted user attachments; the cookbook's role templates and prompt references are the guide used here. The book mentions a larger `prompt-writing` skill, but those referenced guides/templates are not contained in this supplied archive and were not treated as read.

**D01.** `diagnostics/reproduce_source_functions.py` and `diagnostics/results.json`. Functions copied from S13/S18 for isolated JSON fixtures. This is not a checkout, repository test suite or end-to-end ACP run.

## Official protocol and harness references checked for this audit

- [ACP session setup](https://agentclientprotocol.com/protocol/v1/session-setup): sessions have separate conversation state; load/resume behavior depends on support.
- [ACP client-provided system prompt RFD](https://agentclientprotocol.com/rfds/client-system-prompt): Draft at review; not a universal deployed system-role interface.
- [ACP session compaction](https://agentclientprotocol.com/rfds/session-compaction): Completed proposal; compaction lifecycle and optional displayable summary, not a full retained-context inventory.
- [ACP session context size and cost](https://agentclientprotocol.com/rfds/session-usage): Completed proposal; context utilization and optional cumulative cost. End-turn token accounting is a separate Draft.
- [ACP session modes](https://agentclientprotocol.com/protocol/v1/session-modes): agent-defined modes, not arbitrary client instructions with universal system priority.
- [Claude Code memory/instructions](https://code.claude.com/docs/en/memory): native instruction and memory loading is a harness concern.
- [Codex AGENTS.md instructions](https://developers.openai.com/codex/guides/agents-md): native instruction discovery/assembly must be considered alongside ACP.
- [MCP July 2026 changelog](https://modelcontextprotocol.io/specification/2026-07-28/changelog): relevant to the native expert's pinned protocol account, not proof that every installed adapter/server negotiated that revision.

Public protocol status does not establish that an installed adapter implements an optional feature. Installed versions and actual configuration remain deployment evidence to collect, not assumptions.
