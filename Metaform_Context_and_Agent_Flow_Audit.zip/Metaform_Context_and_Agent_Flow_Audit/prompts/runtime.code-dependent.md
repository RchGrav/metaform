# Runtime-selection prompt revisions requiring matching code changes

These are **not drop-in replacements** for the current classification/schema flow. Implement step 4 of IMPLEMENTATION_PLAN.md with these intentions so the prompt does not promise behavior the runtime cannot execute.

## runtime_task

> Identify what contribution this assignment needs from the available expertise. Use the requested outcome, functional relationships, current approach, existing decisions and available evidence. Distinguish local implementation reasoning from work that benefits from a separate planning contribution. Return the decision needed for this assignment's execution; retain established choices when the work is a continuation of the same contribution.

The present enum may be retained for reporting, but `needs_plan` should no longer automatically mean every vague implementation must wait for another model. A real planning dependency remains possible where planning is the useful contribution.

## runtime_choice

> Select an available runtime suited to the contribution, using the person's explicit choices, advertised capabilities, recorded strengths and measured outcomes. Prefer enough capability for the work without paying for unused capability. Treat an unsupported configuration control as absent and use the harness's supported configuration. Explain the material reason for a new choice when it differs from the established runtime.

Code must represent absent effort and distinguish explicit overrides from preferences. The prompt cannot overcome candidate filtering that already removed usable choices.

## runtime_plan, retaining `<work/>`

> Develop the implementation approach for ticket <work/> from its source request, functional context and current evidence. Record the proposed approach, relevant implementation locations, actual dependencies and evidence that will establish the result. Keep the source request distinguishable from the plan. Return the planning contribution through the recorded continuation so execution can proceed with it. Carry consequential unresolved product decisions with their implications to the recorded user-facing route.

Code must persist plan state separately and consume that contribution once. Merely changing this prompt to stop rewriting `task` while retaining the current task-fingerprint classification can leave the ticket repeatedly classified as needing a plan.

## Reusable specialist authoring: targeted guidance

Retain the existing commissioning/publication mechanism. Where the Facilitator is instructed to author a reusable specialist, use:

> Define the expertise, the contribution it supplies, the evidence it should examine and the useful result it returns. Use the project's canonical meanings where relevant. Keep assignment-specific facts in the assignment; keep reusable methods and reference pointers in the role. Reuse an existing role whose expertise fits before creating another one.

This is a method paragraph, not a replacement of the unreviewed remainder of the Facilitator publication contract. Publication tools and required role metadata remain their actual implemented forms.
