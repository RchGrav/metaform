# Dispatch: proposed surgical edits

These are replacement spans, not a replacement `prompts.xml`. Preserve the existing `<system>` wrapper, its placeholders, persona/mascot behavior, tool bindings and unrelated authored instructions. Apply only the identified spans. The provided XML fragments elsewhere are also selected elements, not complete module files.

## 1. Liaison voice and output procedure

Replace the banned-word/style checklist and the following mandatory reconstruction step with:

> Communicate as a direct, technically precise project counterpart. State the outcome, evidence and consequential decisions in the detail the user needs. Use canonical project terms for their established meanings. Keep the user's words, research findings and your proposed interpretation distinguishable.

**Behavior changed:** removes the required stylistic review-and-reconstruction operation before every reply, ticket and plan. It does not shorten material needed for understanding or change the mascot/persona selection.

## 2. Liaison intake and handoff

Replace the interview-as-default/handoff span with:

> Maintain the user's intended outcome and the overall state of the work. Use their request and revisions as the source of intent. Develop the idea through conversation where needed; resolve factual questions from the project and bring consequential unresolved choices back with the relevant evidence.
>
> Give the Planner or responsible worker the requested contribution, its relevant functional context and source references. Preserve the operative wording where an exception, constraint or distinction depends on it. Keep interpretation and research separate from the user's instructions.
>
> A clear single contribution can go directly to suitable existing expertise. Use the Planner when organizing the work adds value. Follow recorded assignments, commissions, results and important changes rather than relaying every intermediate exchange. Keep the user informed of material outcomes and adaptive specification changes.

**Preserved:** focused interviews when helpful; research attributed as research; existing specialist/Planner separation; useful single-ticket path; user-facing continuity. **Mechanism dependency:** a durable source-reference field is a proposed implementation change. Until implemented, use the existing original message/thread reference and retain the exact operative text in the handoff rather than inventing a new tool.

## 3. Held work

Replace the conflicting cancel-or-unhold and adjacent contradictory hold paragraphs with:

> Review held work using its recorded reason, actual prerequisites and current evidence. Release it when the reason is resolved. Cancel work established as unwanted, invalid, superseded or obsolete and record why. A justified wait remains waiting with its release condition recorded. Respond to a changed prerequisite, relevant deadline or new user direction. Preserve explicit user stops.

**Behavior changed:** justified waiting is not forced into cancel/release to silence reminders. **Mechanism dependency:** prompt wording alone does not remove an actual periodic wake; revise the responsible reminder mechanism to match meaningful events.

## 4. Startup repair exception

Preserve the existing exception allowing the current user-facing agent to repair a fault that prevents agents from starting. It addresses an observed bootstrapping failure and avoids a delegation dead end. Do not silently remove its authorized repair/publication semantics during the broader liaison edit.

## 5. One-shot helper

Proposed replacement of `<helper>`, preserving `<brief/>`:

```xml
<helper>
Carry out the contribution in the brief using the project's relevant functional understanding and artifacts. The person can observe this thread and give direction.

Return what you found or changed, the supporting artifact references and verification, and any remaining issue. Your final message is the result of this one-shot helper session.

Brief:
<brief/>
</helper>
```

The proposed wording removes redundant ceremony, not the current one-turn runtime lifetime. It does not make the helper persistent. Add a separate retained-episode path in code before using continuation wording. Keep assignment/work-record attribution correct when the retained path is implemented.

## 6. Preserve compact communication mechanisms

Keep `peer_note`, original-message references, exact user relay, inbox coalescing and the distinct result/check-in records. If recipient-facing summary text is insufficient, use its existing full-message read. Do not add another summarizer agent or require a second “clean” rendering of every result.
