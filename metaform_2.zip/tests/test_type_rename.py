import copy

import pytest

from metaform.backends import JSONGraph
from metaform.graph import Graph


@pytest.fixture(params=[Graph, JSONGraph])
def graph(request, tmp_path):
    return request.param(tmp_path / "graph")


def record(name):
    return {
        "entity_desc": name,
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name, "notes": "code.language.cpp remains authored text"},
    }


def test_type_rename_preserves_authored_meaning_join_identity_and_history(graph):
    old, new = "code.language.cpp", "code.cpp"
    graph.put(
        {
            "elements": {old: record("C++ program code"), "document": record("Document")},
            "joins": [
                {
                    "id": "purpose",
                    "object_id": old,
                    "element_id": "document",
                    "type": "dependency",
                    "purpose": "The exact purpose mentions code.language.cpp.",
                    "join_logic": {"var": "code.language.cpp"},
                    "participants": [
                        {"role": "receiver", "ref": old},
                        {"role": "ef_owner", "ref": "document"},
                        {"role": "literal", "value": old},
                    ],
                },
                {"id": "default-members", "object_id": "document", "element_id": old, "type": "dependency"},
                {"id": "join-reference", "object_id": "purpose", "element_id": old, "type": "evidence"},
            ],
        },
        "native",
    )
    graph.put({"elements": {old: record("Earlier independent C++ description")}}, "archaeology")
    before = graph.export()
    result = graph.rename_elements({old: new})
    after = graph.export()
    assert result == {"elements": 1, "joins": 3, "observations": 2}
    assert graph.get(old) is None
    assert after["elements"][new] == before["elements"][old]
    assert set(after["elements"]) == {new, "document"}
    expected_joins = copy.deepcopy(before["joins"])
    for join in expected_joins:
        if join["object_id"] == old:
            join["object_id"] = new
        if join["element_id"] == old:
            join["element_id"] = new
        for participant in join.get("participants", []):
            if participant.get("ref") == old:
                participant["ref"] = new
    assert after["joins"] == expected_joins
    expected_observations = copy.deepcopy(before["observations"])
    for observation in expected_observations:
        if observation["element_id"] == old:
            observation["element_id"] = new
    assert after["observations"] == expected_observations
    assert len(graph.provenance(new)) == 2
    assert not graph.provenance(old)
    assert len(graph.joins(new)) == 3
    assert not graph.joins(old)
    assert not graph.assemble(new)["unresolved"]
    if not isinstance(graph, JSONGraph):
        with graph.db() as db:
            assert not db.execute("PRAGMA foreign_key_check").fetchall()
            assert not db.execute("SELECT * FROM participants WHERE ref=?", (old,)).fetchall()


def test_type_rename_into_canonical_keeps_canonical_record_and_both_histories(graph):
    graph.put({"elements": {"code": record("Program code"), "code.language": record("Uncorrected language")}})
    before = graph.export()
    graph.rename_elements({"code.language": "code"})
    after = graph.export()
    assert after["elements"] == {"code": before["elements"]["code"]}
    assert len(graph.provenance("code")) == 2
    assert {row["id"] for row in after["observations"]} == {
        row["id"] for row in before["observations"]
    }
    assert {row["element_id"] for row in after["observations"]} == {"code"}


@pytest.mark.parametrize(
    "mapping,expected",
    [
        ({"a": "b", "b": "c"}, {"b": "A", "c": "B"}),
        ({"a": "b", "b": "a"}, {"b": "A", "a": "B"}),
    ],
)
def test_type_rename_is_simultaneous(graph, mapping, expected):
    graph.put(
        {"elements": {"a": record("A"), "b": record("B")},
         "joins": [{"id": "j", "object_id": "a", "element_id": "b", "type": "dependency"}]},
        "authored",
    )
    graph.rename_elements(mapping)
    assert {row["id"]: row["entity_json_obj"]["en"] for row in graph.search()} == expected
    assert graph.joins()[0]["object_id"] == mapping["a"]
    assert graph.joins()[0]["element_id"] == mapping["b"]
    for identifier, name in expected.items():
        assert graph.provenance(identifier)[0]["record"]["entity_json_obj"]["en"] == name


@pytest.mark.parametrize("mapping", [{"a": "c", "b": "c"}, {"missing": "c"}, {"a": "j"}])
def test_type_rename_rejects_ambiguous_or_missing_identifiers_without_writes(graph, mapping):
    graph.put(
        {"elements": {"a": record("A"), "b": record("B")},
         "joins": [{"id": "j", "object_id": "a", "element_id": "b", "type": "dependency"}]},
        "authored",
    )
    before = graph.export()
    with pytest.raises(ValueError):
        graph.rename_elements(mapping)
    assert graph.export() == before


def test_type_rename_can_unify_identical_records_without_losing_observations(graph):
    graph.put({"elements": {"a": record("Same"), "b": record("Same")}})
    graph.rename_elements({"a": "c", "b": "c"})
    assert [row["id"] for row in graph.search()] == ["c"]
    assert len(graph.provenance("c")) == 2


def test_type_rename_cannot_merge_into_a_different_kind_of_record(graph):
    graph.put(
        {"elements": {
            "code.language.cpp": record("C++ program code"),
            "code.cpp": {
                "entity_desc": "An authored prompt",
                "entity_schema": "metaform:prompt",
                "entity_json_obj": {"text": "Preserved prompt"},
            },
        }}
    )
    before = graph.export()
    with pytest.raises(ValueError, match="different schema"):
        graph.rename_elements({"code.language.cpp": "code.cpp"})
    assert graph.export() == before
