"""Project boundary, capture coherence and executable portable continuation."""

import json
import os
import subprocess
import sys
import zipfile

import pytest
from pathlib import Path

from metaform.app import App
from metaform import history, portable
from metaform.util import write_json
from metaform.workflow import Engine, import_workflow


def record(name):
    return {"entity_desc": name, "entity_schema": "metaform:element", "entity_json_obj": {"en": name}}


def test_same_origin_archives_reuse_their_own_continuation(app, tmp_path):
    first_archive = tmp_path / "first.pyz"
    app.graph.put({"elements": {"first-only": record("first archive")}})
    portable.export(app, first_archive)
    second_project, second_home = tmp_path / "second-project", tmp_path / "second-home"
    write_json(second_project / ".metaform" / "config.json", {"knowledge_mode": "legacy", "graph_backend": "json"})
    second = App(second_project, second_home, binding=False)
    import_workflow(second, {"id": "child", "steps": [{"id": "inspect", "prompt": "Inspect X"}]})
    import_workflow(second, {"id": "parent", "steps": [{"id": "child", "kind": "call", "workflow": "child"}, {"id": "finish", "prompt": "Finish inspection"}]})
    engine = Engine(second)
    job = engine.start("parent", exclusive=False)
    while job["status"] == "running":
        job = engine.next(job["run_id"])
    second_archive = tmp_path / "second.pyz"
    portable.export(second, second_archive)
    assert portable.read_bundle(first_archive)["manifest"]["mform_sha_id"] == portable.read_bundle(second_archive)["manifest"]["mform_sha_id"]
    environment = {key: value for key, value in os.environ.items() if not key.startswith("METAFORM_")}
    environment.update(PATH="", PYTHONPATH="")

    def invoke(archive, *arguments):
        result = subprocess.run([sys.executable, "-S", str(archive), *arguments], cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=30)
        assert result.returncode == 0, result.stderr or result.stdout
        return json.loads(result.stdout)

    assert invoke(first_archive, "graph", "get", "--id", "first-only")["record"]["entity_desc"] == "first archive"
    assert invoke(second_archive, "workflow", "next", "--run-id", job["run_id"])["request_id"] == job["request_id"]
    invoke(second_archive, "workflow", "answer", "--run-id", job["run_id"], "--request-id", job["request_id"], "--answer", '"inspected"')
    following = invoke(second_archive, "workflow", "next", "--run-id", job["run_id"])
    while following["status"] == "running":
        following = invoke(second_archive, "workflow", "next", "--run-id", job["run_id"])
    assert following["prompt"] == "Finish inspection"
    assert invoke(first_archive, "graph", "get", "--id", "first-only")["record"]["entity_desc"] == "first archive"
    returned = tmp_path / "returned.pyz"
    invoke(second_archive, "package", "export", "--path", str(returned))
    assert invoke(returned, "workflow", "next", "--run-id", job["run_id"])["request_id"] == following["request_id"]


def test_export_excludes_unrelated_global_and_shared_home_artifacts(app, tmp_path):
    app.graph.put({"elements": {"X": record("project X")}})
    app.global_graph.put({"elements": {"X": record("shared X"), "Y": record("related Y"), "U": record("UNRELATED_GLOBAL")}, "joins": [{"id": "xy", "object_id": "X", "element_id": "Y", "type": "dependency"}]}, "archaeology")
    write_json(app.home / "assignments" / "other.json", {"project": str(tmp_path / "B"), "run_id": "B", "request_id": "B", "nonce": "other"})
    (app.home / "workfolder-baselines" / "B").mkdir(parents=True)
    (app.home / "workfolder-baselines" / "B" / "private.txt").write_text("OTHER_PROJECT_BASELINE")
    write_json(app.home / "modules" / "unused" / "module.json", {"id": "unused", "commands": []})
    archive_path = tmp_path / "export.pyz"
    portable.export(app, archive_path)
    with zipfile.ZipFile(archive_path) as archive:
        graph = json.loads(archive.read("knowledge/global.json"))
        assert set(graph["elements"]) == {"X", "Y"}
        assert not any(name.startswith(("continuation/assignments/other", "workfolder-baselines/B/", "modules/global/unused/", "metaform/data/global/")) for name in archive.namelist())
        bundle = json.loads(archive.read("metaform_bundle.json"))
        assert bundle["format"] == "metaform-export/2"
        checkpoint = bundle["manifest"]["versions"][bundle["manifest"]["head"]]
        assert checkpoint["knowledge_digest_version"] == 2
        assert json.loads(archive.read("versions/" + checkpoint["id"] + "/global.json")) == graph


def test_digest_ignores_unrelated_global_but_retains_source_observations(app):
    app.graph.put({"elements": {"X": record("X")}})
    app.global_graph.put({"elements": {"X": record("X")}}, "archaeology")
    initial = history.knowledge_digest(app)
    app.global_graph.put({"elements": {"U": record("unrelated")}}, "archaeology")
    assert history.knowledge_digest(app) == initial
    app.global_graph.put({"observations": [{"id": "proof", "element_id": "X", "source": "archaeology-complete", "record": dict(record("X"), inference={"elements": {"X": record("X")}, "joins": []}), "created": "2026-09-08T00:00:00Z"}]}, "imported")
    assert history.knowledge_digest(app) != initial


def test_snapshot_lock_nests_across_apps_and_excludes_another_process(app, tmp_path):
    import select
    from metaform import locking
    assert hasattr(locking, "snapshot_lock")
    import_workflow(app, {"id": "locked", "steps": [{"id": "act", "prompt": "Act."}]})
    job = Engine(app).start("locked", exclusive=False)
    other_app = App(app.project, app.home)
    script = """
import sys
from pathlib import Path
from types import SimpleNamespace
from metaform.app import App
from metaform.locking import snapshot_lock
from metaform.portable import export
print('ready', flush=True)
with snapshot_lock(SimpleNamespace(root=Path(sys.argv[1]) / '.metaform')):
    print('acquired', flush=True)
    export(App(sys.argv[1], sys.argv[2]), sys.argv[3])
"""
    result = tmp_path / "captured.pyz"
    process = None
    try:
        with locking.snapshot_lock(app):
            with locking.snapshot_lock(other_app):
                process = subprocess.Popen([sys.executable, "-c", script, str(app.project), str(app.home), str(result)], stdout=subprocess.PIPE, text=True, env={**os.environ, "PYTHONPATH": str(Path(__file__).resolve().parents[1] / "src")})
                assert process.stdout.readline().strip() == "ready"
                assert select.select([process.stdout], [], [], 0.1)[0] == []
                # These nest run_locked -> App.save_run inside the same project lock.
                engine = Engine(other_app)
                engine.submit(job["run_id"], job["request_id"], {"done": True})
                assert engine.next(job["run_id"])["status"] == "complete"
                app.set("phase", "after")
        assert process.wait(timeout=15) == 0
        with zipfile.ZipFile(result) as archive:
            captured = json.loads(archive.read("continuation/state.json"))
        run = next(json.loads(row["body"]) for row in captured["runs"] if row["id"] == job["run_id"])
        assert run["status"] == "complete"
        assert next(json.loads(row["value"]) for row in captured["state"] if row["key"] == "phase") == "after"
    finally:
        if process is not None and process.poll() is None:
            process.kill()
            process.wait()


def test_import_relocates_all_assignments_and_drops_ephemeral_execution(app, tmp_path):
    (app.project / "work.txt").write_text("work")
    import_workflow(app, {"id": "portable", "steps": [{"id": "work", "prompt": "Do the work."}]})
    job = Engine(app).start("portable", workfolder=True, exclusive=False)
    run = app.load_run(job["run_id"])
    run["assignments"] = {job["request_id"]: dict(job)}
    app.save_run(run)
    app.set("executing:" + job["request_id"], True)
    archive = tmp_path / "continue.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    restored = imported.load_run(job["run_id"])
    assert restored["assignments"][job["request_id"]]["workfolder"].startswith(str(target))
    assert not imported.get("executing:" + job["request_id"], False)
    assert json.loads((target / ".metaform" / "config.json").read_text())["knowledge_mode"] == "portable"


def test_future_file_prompt_survives_source_loss_and_reexport(app, tmp_path):
    external = tmp_path / "external-prompts"
    external.mkdir()
    source = external / "future.txt"
    source.write_text("Future instruction for {{ item }}.")
    import_workflow(app, {"id": "future", "steps": [
        {"id": "first", "prompt": "First.", "next": "second"},
        {"id": "second", "prompt": "Placeholder."},
    ]})
    job = Engine(app).start("future", {"item": "selected work"}, exclusive=False)
    run = app.load_run(job["run_id"])
    run["stack"][0]["definition"]["base_dir"] = str(external)
    run["stack"][0]["definition"]["steps"][1]["prompt"] = "file:future.txt"
    app.save_run(run)
    archive = tmp_path / "future.pyz"
    portable.export(app, archive)
    source.unlink()
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    # Re-export before issuing the future step exercises the captured-file map.
    continued = tmp_path / "future-continued.pyz"
    portable.export(imported, continued)
    other = Path(portable.import_bundle(continued, tmp_path / "other")["path"])
    restored = App(other, other / ".metaform" / "home")
    engine = Engine(restored)
    engine.submit(job["run_id"], job["request_id"], {"done": True})
    assert engine.next(job["run_id"])["prompt"] == "Future instruction for selected work."


def test_selected_flat_shared_module_does_not_ship_other_module(app, tmp_path):
    modules = app.home / "modules"
    write_json(modules / "selected.json", {"id": "selected", "commands": [{"name": "run", "handler": "selected.py:run"}], "portable": {"knowledge_refs": ["D"]}})
    write_json(modules / "other.json", {"id": "other", "commands": [{"name": "run", "handler": "other.py:run"}]})
    (modules / "selected.py").write_text("def run(app, args, context):\n    return 'selected'\n")
    (modules / "other.py").write_text("OTHER_PRIVATE_MODULE")
    import_workflow(app, {"id": "module-user", "steps": [{"id": "use", "kind": "tool", "tool": "selected.run"}]})
    app.global_graph.put({"elements": {"D": record("declared module dependency")}}, "archaeology")
    archive = tmp_path / "modules.pyz"
    portable.export(app, archive)
    with zipfile.ZipFile(archive) as bundle:
        names = bundle.namelist()
        assert "modules/global/selected/module.json" in names
        assert not any("other.py" in name or name.endswith("other.json") for name in names)
        assert "D" in json.loads(bundle.read("knowledge/global.json"))["elements"]
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    from metaform.registry import Registry
    registry = Registry(imported)
    command = registry.discover()["selected.run"]
    assert registry.load(command)(imported, {}, None) == "selected"


def test_unstarted_workflow_prompt_reference_captures_file_text(app, tmp_path):
    from metaform import prompts
    external = tmp_path / "external-text"
    external.mkdir()
    source = external / "instruction.txt"
    source.write_text("Read {{ item }} exactly.")
    prompts.put(app, {"id": "prompt:file-ref", "text": "file:" + str(source)})
    import_workflow(app, {"id": "unstarted", "steps": [{"id": "read", "prompt_ref": "prompt:file-ref"}]})
    archive = tmp_path / "unstarted.pyz"
    portable.export(app, archive)
    source.unlink()
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    assert Engine(imported).start("unstarted", {"item": "captured text"}, exclusive=False)["prompt"] == "Read captured text exactly."


def test_empty_workfolder_can_be_exported_and_continued(app, tmp_path):
    from metaform import workfolders
    folder = workfolders.create(app, empty=True)
    archive = tmp_path / "empty.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    assert workfolders.diff(imported, folder["id"])["diff"] == ""


def test_schema_owner_variants_survive_import_and_next_startup(app, tmp_path):
    identifier = "custom:owner-schema"
    global_schema = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": identifier, "type": "string"}
    local_schema = dict(global_schema, type="object")
    app.knowledge.call("schema.put", {"owner": "global", "schema": global_schema})
    app.knowledge.call("schema.put", {"owner": "project:" + app.project_id, "schema": local_schema})
    app.graph.put({"elements": {"X": dict(record("local"), entity_schema=identifier)}})
    app.global_graph.put({"elements": {"X": dict(record("global"), entity_schema=identifier)}}, "archaeology")
    archive = tmp_path / "schemas.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    for _ in range(2):
        imported = App(target, target / ".metaform" / "home")
        assert imported.knowledge.call("schema.get", {"owner": "global", "id": identifier}) == global_schema
        assert imported.knowledge.call("schema.get", {"owner": "project:" + imported.project_id, "id": identifier}) == local_schema


def test_zip_runtime_resumes_and_reexports_without_source_home(app, tmp_path):
    (app.project / "work.txt").write_text("portable work")
    import_workflow(app, {"id": "offline", "steps": [
        {"id": "first", "prompt": "First offline instruction.", "next": "second"},
        {"id": "second", "prompt": "Second offline instruction."},
    ]})
    job = Engine(app).start("offline", workfolder=True, exclusive=False)
    archive = tmp_path / "offline.pyz"
    portable.export(app, archive)
    app.home.rename(tmp_path / "unavailable-home")
    agent = tmp_path / "offline-agent"
    agent.mkdir()

    def command(path, *args, cwd=agent):
        result = subprocess.run([sys.executable, "-S", str(path), *args], cwd=cwd,
                                env={**os.environ, "PYTHONPATH": "", "PATH": ""},
                                capture_output=True, text=True, timeout=20)
        assert result.returncode == 0, result.stderr + result.stdout
        return json.loads(result.stdout)

    assert command(archive, "begin", str(job["nonce"]))["prompt"] == "First offline instruction."
    command(archive, "workflow", "answer", "--answer", '{"done": true}')
    second = command(archive, "workflow", "next", "--run-id", job["run_id"], cwd=tmp_path)
    assert second["prompt"] == "Second offline instruction."
    continued = tmp_path / "continued.pyz"
    command(archive, "package", "export", "--path", str(continued), cwd=tmp_path)
    resumed_agent = tmp_path / "resumed-agent"
    resumed_agent.mkdir()
    assert command(continued, "begin", str(second["nonce"]), cwd=resumed_agent)["prompt"] == second["prompt"]


def test_packaged_global_seed_stays_excluded_on_import_and_second_start(app, tmp_path, monkeypatch):
    import importlib.resources
    import shutil
    from metaform.util import digest
    original_files = importlib.resources.files
    package = tmp_path / "package" / "metaform"
    shutil.copytree(original_files("metaform"), package, ignore=shutil.ignore_patterns("__pycache__"))
    write_json(package / "data" / "global" / "index.json", {"elements": ["UNRELATED_SEED"], "joins": [], "schemas": []})
    write_json(package / "data" / "global" / "elements" / (digest("UNRELATED_SEED") + ".json"), {"record": record("unrelated packaged sentinel")})
    monkeypatch.setattr(importlib.resources, "files", lambda name: package if name == "metaform" else original_files(name))
    archive = tmp_path / "seed.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    for _ in range(2):
        imported = App(target, target / ".metaform" / "home")
        assert imported.global_graph.get("UNRELATED_SEED") is None
    again = tmp_path / "seed-again.pyz"
    portable.export(imported, again)
    with zipfile.ZipFile(again) as bundle:
        assert not any(name.startswith("metaform/data/global/") for name in bundle.namelist())
        assert "UNRELATED_SEED" not in json.loads(bundle.read("knowledge/global.json"))["elements"]


def test_completion_only_dependency_and_source_records_survive_portable_copy(app, tmp_path):
    app.graph.put({"elements": {"X": record("Contextual X")}}, "native")
    app.graph.put({"elements": {"X": record("Latent X")}}, "archaeology")
    snapshot = {"elements": {"X": record("Latent X"), "D": record("dependency D")}, "joins": []}
    app.global_graph.put({"elements": {"X": record("Latent X"), "D": record("dependency D"), "E": record("transitive E"), "U": record("unrelated")}, "joins": [{"id": "de", "object_id": "D", "element_id": "E", "type": "dependency"}], "observations": [{"id": "completed-x", "element_id": "X", "source": "archaeology-complete", "record": dict(record("Latent X"), inference=snapshot), "created": "2026-09-08T00:00:00Z"}]}, "archaeology")
    expected_project = app.graph.export()
    archive = tmp_path / "completion.pyz"
    portable.export(app, archive)
    with zipfile.ZipFile(archive) as bundle:
        expected_global = json.loads(bundle.read("knowledge/global.json"))
        assert set(expected_global["elements"]) == {"X", "D", "E"}
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    actual_project = imported.graph.export()
    actual_project["observations"].sort(key=lambda observation: observation["id"])
    expected_project["observations"].sort(key=lambda observation: observation["id"])
    assert actual_project == expected_project
    assert imported.global_graph.export() == expected_global
    assert imported.graph.get("X", scope="native") == record("Contextual X")
    assert imported.graph.get("X", scope="archaeology") == record("Latent X")
    assert imported.knowledge.call("inference.read", {"id": "X"}) == app.knowledge.call("inference.read", {"id": "X"})


def test_changed_source_during_capture_does_not_publish_mixed_archive(app, tmp_path, monkeypatch):
    import pytest
    source = app.project / "changing.txt"
    source.write_text("before")
    destination = tmp_path / "existing.pyz"
    destination.write_bytes(b"previous export remains")
    original_checkpoint = history.checkpoint

    def changing_checkpoint(*args, **kwargs):
        result = original_checkpoint(*args, **kwargs)
        source.write_text("after")
        return result

    monkeypatch.setattr(history, "checkpoint", changing_checkpoint)
    with pytest.raises(ValueError, match="Files changed during export: changing.txt"):
        portable.export(app, destination)
    assert destination.read_bytes() == b"previous export remains"


def test_v1_import_preserves_broad_graph_and_inclusive_reimport(app, tmp_path):
    from metaform.util import digest
    source = tmp_path / "source.pyz"
    portable.export(app, source)
    with zipfile.ZipFile(source) as archive:
        members = {item.filename: archive.read(item) for item in archive.infolist()}
    graph = json.loads(members["knowledge/global.json"])
    graph["elements"]["OLD_UNRELATED"] = dict(record("v1 broad global record"), layer="elements")
    members["knowledge/global.json"] = json.dumps(graph).encode()
    project = json.loads(members["knowledge/project.json"])
    bundle = json.loads(members["metaform_bundle.json"])
    bundle["format"] = "metaform-export/1"
    bundle.pop("origin_project_id", None)
    entry = bundle["manifest"]["versions"][bundle["manifest"]["head"]]
    entry.pop("knowledge_digest_version", None)
    entry["knowledge_digest"] = digest({"project": {key: project[key] for key in ("elements", "joins")}, "global": {key: graph[key] for key in ("elements", "joins")}, "runs": []})
    members["metaform_bundle.json"] = json.dumps(bundle).encode()
    members["history/manifest.json"] = json.dumps(bundle["manifest"]).encode()
    for path in ("knowledge/manifest.json", "knowledge/resources.json", "knowledge/archive-dependencies.json"):
        members.pop(path, None)
    legacy = tmp_path / "legacy.pyz"
    with zipfile.ZipFile(legacy, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in members.items():
            archive.writestr(name, data)
    first = portable.import_bundle(legacy, tmp_path / "copies")
    second = portable.import_bundle(legacy, tmp_path / "copies")
    assert first["path"] == second["path"]
    imported = App(first["path"], Path(first["path"]) / ".metaform" / "home")
    assert imported.global_graph.get("OLD_UNRELATED") == record("v1 broad global record")
    narrowed = tmp_path / "narrowed.pyz"
    portable.export(imported, narrowed)
    with zipfile.ZipFile(narrowed) as archive:
        assert "OLD_UNRELATED" not in json.loads(archive.read("knowledge/global.json"))["elements"]


def test_project_module_declared_resource_outside_module_tree_is_portable(app, tmp_path):
    module = app.root / "modules" / "local"
    write_json(module / "module.json", {"id": "local", "commands": [{"name": "read", "handler": "handler.py:read"}], "portable": {"files": ["../../shared.txt"]}})
    (module / "handler.py").write_text("from pathlib import Path\ndef read(app, args, context):\n    return (Path(__file__).parent / '../../shared.txt').read_text()\n")
    (app.root / "shared.txt").write_text("declared resource")
    archive = tmp_path / "local-resource.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    from metaform.registry import Registry
    registry = Registry(imported)
    assert registry.load(registry.discover()["local.read"])(imported, {}, None) == "declared resource"


def test_config_only_module_survives_reexport(app, tmp_path):
    configured = tmp_path / "configured-modules"
    module = configured / "configured"
    write_json(module / "module.json", {"id": "configured", "commands": [{"name": "run", "handler": "handler.py:run"}]})
    (module / "handler.py").write_text("def run(app, args, context):\n    return 'configured'\n")
    app.config["module_paths"] = [str(configured)]
    archive = tmp_path / "configured.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    continued = tmp_path / "configured-again.pyz"
    portable.export(imported, continued)
    with zipfile.ZipFile(continued) as bundle:
        assert "modules/global/configured/module.json" in bundle.namelist()


def test_flat_module_change_after_capture_does_not_publish_archive(app, tmp_path, monkeypatch):
    import pytest
    modules = app.home / "modules"
    write_json(modules / "selected.json", {"id": "selected", "commands": [{"name": "run", "handler": "selected.py:run"}]})
    handler = modules / "selected.py"
    handler.write_text("def run(app, args, context):\n    return 'before'\n")
    import_workflow(app, {"id": "flat", "steps": [{"id": "use", "kind": "tool", "tool": "selected.run"}]})
    original = portable.captured_file

    def concurrent_change(archive, path, member, checks):
        original(archive, path, member, checks)
        if path == handler:
            handler.write_text("def run(app, args, context):\n    return 'after'\n")

    monkeypatch.setattr(portable, "captured_file", concurrent_change)
    archive = tmp_path / "changing-module.pyz"
    with pytest.raises(ValueError, match="Files changed during export:.*selected.py"):
        portable.export(app, archive)
    assert not archive.exists()


def test_imported_subdirectory_workfolder_applies_to_imported_source_only(app, tmp_path):
    from metaform import workfolders
    source = app.project / "src"
    source.mkdir()
    (source / "value.txt").write_text("original")
    folder = workfolders.create(app, source=source)
    (Path(folder["path"]) / "value.txt").write_text("continued")
    archive = tmp_path / "subdirectory.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    workfolders.apply(imported, folder["id"])
    assert (source / "value.txt").read_text() == "original"
    assert (target / "src" / "value.txt").read_text() == "continued"


def test_imported_subdirectory_workfolder_applies_when_original_source_is_absent(app, tmp_path):
    from metaform import workfolders
    source = app.project / "src"
    source.mkdir()
    (source / "value.txt").write_text("original")
    folder = workfolders.create(app, source=source)
    (Path(folder["path"]) / "value.txt").write_text("continued")
    archive = tmp_path / "subdirectory-offline.pyz"
    portable.export(app, archive)
    source.rename(app.project / "unavailable")
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    workfolders.apply(imported, folder["id"])
    assert (target / "src" / "value.txt").read_text() == "continued"


def test_long_lived_local_apps_refresh_and_preserve_registered_schemas(tmp_path):
    from metaform import schemas
    project, home = tmp_path / "local-project", tmp_path / "local-home"
    write_json(project / ".metaform" / "config.json", {"knowledge_mode": "legacy", "graph_backend": "json"})
    first, second = App(project, home), App(project, home)
    cached = first.knowledge
    a = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "schema:one", "type": "object"}
    b = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "schema:two", "type": "string"}
    c = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "schema:three", "type": "integer"}
    schemas.register(second, a)
    second.graph.put({"elements": {"Y": dict(record("Y"), entity_schema=a["$id"])}})
    assert schemas.registry(first)[a["$id"]] == a
    schemas.register(first, b)
    schemas.register(second, c)
    assert first.knowledge is cached
    assert first.knowledge.call("schema.list", {"owner": "global"}) == {s["$id"]: s for s in (a, b, c)}
    latest = dict(a, **{"$id": "schema:after-last-read"})
    schemas.register(second, latest)
    second.graph.put({"elements": {"Z": dict(record("Z"), entity_schema=latest["$id"])}})
    archive = tmp_path / "fresh-schemas.pyz"
    portable.export(first, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    assert imported.knowledge.call("schema.get", {"owner": "global", "id": a["$id"]}) == a
    assert imported.knowledge.call("schema.get", {"owner": "global", "id": latest["$id"]}) == latest


@pytest.mark.parametrize("mode", ["legacy", "service"])
def test_packaged_custom_schema_is_seeded_and_available_offline(tmp_path, monkeypatch, mode):
    import importlib.resources
    import shutil
    from metaform import schemas
    from metaform.util import digest
    original_files = importlib.resources.files
    package = tmp_path / "package"
    shutil.copytree(original_files("metaform") / "data", package / "data")
    global_data = package / "data" / "global"
    schema = {"$schema": "https://json-schema.org/draft/2020-12/schema", "$id": "schema:packaged-only", "type": "object", "properties": {"en": {"type": "string"}}}
    write_json(global_data / "index.json", {"elements": ["packaged:X"], "joins": [], "schemas": [schema["$id"]]})
    write_json(global_data / "elements" / (digest("packaged:X") + ".json"), {"record": dict(record("Packaged X"), entity_schema=schema["$id"]), "observations": []})
    write_json(global_data / "schemas" / (digest(schema["$id"]) + ".json"), schema)
    monkeypatch.setattr(importlib.resources, "files", lambda name: package if name == "metaform" else original_files(name))
    project, home = tmp_path / "P", tmp_path / "home"
    write_json(project / ".metaform" / "config.json", {"knowledge_mode": mode, "graph_backend": "json"})
    if mode == "service":
        from metaform.knowledge import KnowledgeStore
        from metaform import service
        store = KnowledgeStore(home / "service" / "knowledge.sqlite3")
        monkeypatch.setattr(service, "ensure_service", lambda home: None)
        monkeypatch.setattr(service, "RemoteKnowledge", lambda home, project_id: store.bind(project_id))
    app = App(project, home)
    # An older installation can have the packaged marker without stored schemas.
    if mode == "service":
        with store.transaction() as db:
            db.execute("DELETE FROM schemas WHERE owner='global' AND id=?", (schema["$id"],))
    else:
        write_json(home / "schemas.json", {})
    assert (home / "inference" / "packaged.json").exists()
    app.seed()
    assert app.knowledge.call("schema.get", {"owner": "global", "id": schema["$id"]}) == schema
    app.graph.put({"elements": {"local": record("local")}, "joins": [{"id": "related", "object_id": "local", "element_id": "packaged:X", "type": "relation"}]})
    assert schemas.registry(app)[schema["$id"]] == schema
    closure = app.knowledge.call("knowledge.snapshot", {})
    assert any(item["id"] == schema["$id"] and item["body"] == schema for item in closure["schemas"])
    archive = tmp_path / "packaged-schema.pyz"
    portable.export(app, archive)
    monkeypatch.setattr(importlib.resources, "files", original_files)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    assert schemas.registry(imported)[schema["$id"]] == schema
    assert imported.global_graph.get("packaged:X")["entity_schema"] == schema["$id"]


def test_flat_symlink_module_handler_exports_and_runs(app, tmp_path):
    from metaform.registry import Registry
    modules = app.home / "modules"
    write_json(modules / "linked.json", {"id": "linked", "commands": [{"name": "run", "handler": "linked.py:run"}]})
    target_handler = modules / "implementation.py"
    target_handler.write_text("def run(app, args, context):\n    return 'linked implementation'\n")
    (modules / "linked.py").symlink_to(target_handler.name)
    import_workflow(app, {"id": "linked-user", "steps": [{"id": "run", "kind": "tool", "tool": "linked.run"}]})
    archive = tmp_path / "linked.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home")
    registry = Registry(imported)
    assert registry.load(registry.discover()["linked.run"])(imported, {}, None) == "linked implementation"


def test_flat_symlink_handler_changed_target_is_detected(app, tmp_path, monkeypatch):
    modules = app.home / "modules"
    write_json(modules / "linked.json", {"id": "linked", "commands": [{"name": "run", "handler": "linked.py:run"}]})
    target = modules / "implementation.py"
    target.write_text("def run(app, args, context):\n    return 'before'\n")
    handler = modules / "linked.py"
    handler.symlink_to(target.name)
    import_workflow(app, {"id": "linked-user", "steps": [{"id": "run", "kind": "tool", "tool": "linked.run"}]})
    original = portable.captured_file
    def changing_target(archive, path, member, checks):
        original(archive, path, member, checks)
        if path == handler:
            target.write_text("def run(app, args, context):\n    return 'after'\n")
    monkeypatch.setattr(portable, "captured_file", changing_target)
    archive = tmp_path / "changed-link.pyz"
    with pytest.raises(ValueError, match="Files changed during export:.*linked.py"):
        portable.export(app, archive)
    assert not archive.exists()
