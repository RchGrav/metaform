"""The delivered sample path needs no source checkout and preserves existing projects."""
import asyncio
import json
from pathlib import Path

import pytest

from metaform.app import App
from metaform.registry import Registry


def test_sample_loads_preserved_historical_records_without_initializing_cwd(tmp_path, monkeypatch, capsys):
    from metaform.cli import main

    cwd = tmp_path / 'unopened'
    cwd.mkdir()
    monkeypatch.chdir(cwd)
    monkeypatch.setenv('METAFORM_HOME', str(tmp_path / 'unused-home'))
    destination = tmp_path / 'sample'
    assert main(['--json', 'package', 'sample', '--destination', str(destination)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result['project'] == str(destination)
    assert result['view'] == 'History / Compare'
    assert not (cwd / '.metaform').exists()
    assert not (tmp_path / 'unused-home').exists()
    sample = App(destination, destination / '.metaform/home', binding=False)
    native = sample.graph.export('native')
    assert 'mgm:project' in native['elements']
    assert sample.get('native_context')['understanding']
    assert sample.knowledge_mode == 'portable'
    with pytest.raises(ValueError, match='already contains'):
        asyncio.run(Registry(sample).call('package.sample', {'destination': str(destination)}))
    assert sample.graph.export('native') == native
