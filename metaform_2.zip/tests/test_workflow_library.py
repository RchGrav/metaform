"""Authored source behavior exercised through the distributed workflow library."""

from pathlib import Path

import pytest

from metaform.app import App
from metaform.util import write_json
from metaform.workflow import Engine


@pytest.fixture
def library_app(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "legacy", "graph_backend": "json", "auto_build": False})
    return App(tmp_path / "project", home, binding=False)


def advance(engine, run_id):
    for _ in range(30):
        result = engine.next(run_id)
        if result["status"] != "running":
            return result
    raise AssertionError("The authored procedure did not reach its next assignment")


def answer(engine, job, value):
    engine.submit(job["run_id"], job["request_id"], value)
    return advance(engine, job["run_id"])


def test_dual_agent_actual_source_keeps_user_review_repair_and_numeric_completion(library_app):
    engine = Engine(library_app)
    job = engine.start("metaform.library.dual_agent", {"spec": "Return x squared."}, exclusive=False)
    assert job["role"] == "Dev"
    job = answer(engine, job, {"retained_spec": "Return x squared.", "tools": [], "request_install": "REQUEST_INSTALL []"})
    assert job["status"] == "awaiting_user"
    job = answer(engine, job, {"USER_APPROVE": "no"})
    assert job["status"] == "awaiting_user"
    job = answer(engine, job, {"USER_APPROVE": True})
    job = answer(engine, job, {"available_tools": [], "setup_results": []})
    submission = {"plan": "Multiply x by itself.", "artifact_files": []}
    job = answer(engine, job, submission)
    assert job["role"] == "Eval" and job["context"] == "fresh"
    first_evaluator = job["request_id"]
    job = answer(engine, job, {"approved": False, "fixes": [{"variance": "Missing test", "fix": "Add a negative input test"}]})
    assert job["step"] == "fix_plan"
    job = answer(engine, job, submission)
    assert job["request_id"] != first_evaluator
    job = answer(engine, job, {"approved": True, "fixes": []})
    implementation = {"slice": "square", "artifact_files": [{"path": "square.py", "content": "def square(x): return x*x\n"}],
                      "test_files": [], "verification_evidence": []}
    job = answer(engine, job, implementation)
    assert job["role"] == "Eval" and job["inputs"]["submission"] == implementation
    review = {"approved": True, "fixes": [], "spec_fully_satisfied": True, "remaining_requirements": [],
              "coverage_percent": 10, "coverage_at_least_95": True, "zero_issues": True, "checks": []}
    job = answer(engine, job, review)
    assert job["step"] == "next_slice", "The source requires measured coverage >=95, regardless of a contradictory summary flag"
    job = answer(engine, job, implementation)
    job = answer(engine, job, review | {"coverage_percent": None})
    assert job["step"] == "next_slice"
    job = answer(engine, job, implementation)
    job = answer(engine, job, review | {"coverage_percent": 95})
    assert job["step"] == "complete"
    assert answer(engine, job, "COMPLETE ✅")["result"]["values"]["result"] == "COMPLETE ✅"


@pytest.mark.parametrize('experts', [False, True])
def test_metaprompt_clarifies_then_delegates_only_when_needed(library_app, experts):
    engine = Engine(library_app)
    job = engine.start('metaform.library.metaprompt', {}, exclusive=False)
    assert job['status'] == 'awaiting_user'
    assert job['prompt'].startswith('What is the topic or role of the prompt you want to create?')
    job = answer(engine, job, 'Create a prompt for an explanation.')
    brief = {'needs_clarification': True, 'clarification_message': 'Which subject?', 'requirements': []}
    job = answer(engine, job, brief)
    assert job['status'] == 'awaiting_user' and job['prompt'] == 'Which subject?'
    job = answer(engine, job, 'Explain prime numbers.')
    assert job['inputs']['answer'] == 'Explain prime numbers.'
    job = answer(engine, job, brief | {'needs_clarification': False})
    task = {'id': 'math', 'persona': 'Expert Mathematician', 'is_python': False,
            'instructions': 'Check the mathematical definition.', 'depends_on': []}
    plan = {'tasks': [task] if experts else [], 'completed': [], 'has_next': experts,
            'next_task': task if experts else None}
    job = answer(engine, job, plan)
    if experts:
        creator = job['request_id']
        assert job['step'] == 'create_specialist' and job['context'] == 'fresh'
        candidate = {'result': 'Definition', 'code': '', 'evidence': [], 'uncertainties': []}
        job = answer(engine, job, candidate)
        assert job['step'] == 'review_specialist' and job['request_id'] != creator
        assert job['inputs']['candidate'] == candidate
        review = {'needs_revision': True, 'feedback': 'Include the greater-than-one condition.', 'confirmed': [], 'uncertainties': []}
        job = answer(engine, job, review)
        assert job['step'] == 'revise_specialist'
        job = answer(engine, job, candidate | {'result': 'Corrected definition'})
        job = answer(engine, job, review | {'needs_revision': False})
        assert job['step'] == 'advance_expert_plan'
        completed = [{'task_id': task['id'], 'candidate': candidate, 'review': review | {'needs_revision': False}}]
        job = answer(engine, job, plan | {'has_next': False, 'next_task': None, 'completed': completed})
    assert job['step'] == 'draft_prompt'
    final_prompt = '<System>Explain prime numbers.</System>'
    job = answer(engine, job, final_prompt)
    if experts:
        assert job['step'] == 'verify_prompt' and job['context'] == 'fresh'
        job = answer(engine, job, {'needs_revision': False, 'feedback': '', 'confirmed': [], 'uncertainties': []})
    assert job['step'] == 'deliver_prompt'
    assert job['inputs']['prompt'] == final_prompt
    result = answer(engine, job, final_prompt)
    assert result['status'] == 'complete' and result['result']['values']['final_prompt'] == final_prompt


def test_multi_agent_source_requires_user_approval_and_repairs_actual_findings(library_app):
    engine = Engine(library_app)
    def plan_job():
        job = engine.start('metaform.library.multi_agent_orchestrator', {'request': 'Write a greeting function.'}, exclusive=False)
        assert 'semantic_equations' not in job['inputs']
        job = answer(engine, job, {'needs_clarification': False, 'requirements': [], 'assumptions': []})
        return answer(engine, job, {'approval_message': 'Approve this greeting plan?', 'steps': [{'id': 'greeting', 'instruction': 'Return hello.'}]})
    rejected = plan_job()
    assert rejected['status'] == 'awaiting_user'
    assert answer(engine, rejected, {'approved': 'no'})['status'] == 'complete'
    job = answer(engine, plan_job(), {'approved': True})
    work = {'needs_clarification': False, 'needs_setup_permission': True,
            'question': 'Install the test runner?',
            'requested_setup_actions': ['Install the test runner.']}
    job = answer(engine, job, work)
    assert job['step'] == 'setup_permission' and job['status'] == 'awaiting_user'
    job = answer(engine, job, {'approved': True})
    assert job['step'] == 'resume_development'
    job = answer(engine, job, work | {'needs_setup_permission': False})
    assert job['step'] == 'evaluate'
    review = {'passed': True, 'all_complete': True, 'findings': [{'issue': 'Greeting differs from spec.'}], 'checks': []}
    job = answer(engine, job, review)
    assert job['step'] == 'repair', 'A summary passed flag cannot erase an actual remaining issue.'
    assert job['inputs']['review'] == review
    job = answer(engine, job, work | {'needs_setup_permission': False})
    job = answer(engine, job, review | {'findings': []})
    assert job['step'] == 'final_output'
    assert answer(engine, job, 'Hello.')['status'] == 'complete'


def test_orchestrator_defers_init_and_routes_exact_pass_repair_and_user_completion(library_app):
    engine = Engine(library_app)
    start = engine.start('metaform.library.orchestrator', {'invoked_during_repo_init': True}, exclusive=False)
    job = advance(engine, start['run_id']) if start['status'] == 'running' else start
    assert job['step'] == 'wait_for_repo_init'
    job = answer(engine, job, {'state': 'not completed'})
    assert job['step'] == 'wait_for_repo_init'
    job = answer(engine, job, {'state': 'completed'})
    assert job['step'] == 'deferred_notice'
    assert answer(engine, job, 'Start with /build.')['status'] == 'complete'
    start = engine.start('metaform.library.orchestrator', {}, exclusive=False)
    job = advance(engine, start['run_id']) if start['status'] == 'running' else start
    assert job['step'] == 'bootstrap'
    module = {'id': 'greeting', 'language': 'Python', 'artifact_directory': 'src', 'contract': 'Return hello.', 'dependencies': []}
    inventory = {'command_name': 'build', 'task_directory': 'task/build_1', 'documents': []}
    journey = [
        ('bootstrap', inventory),
        ('observe_and_mirror', 'continue'),
        ('planning', {'goal': 'Build a greeting function.'}),
        ('resolve_plan', {'goal': 'Build a greeting function.'}),
        ('architect', {'blueprint_path': 'docs/Blueprint.md', 'specification': 'Return hello.', 'modules': [module], 'dependency_list': []}),
        ('doc_shard', {'index_path': 'docs/index.md', 'shards': []}),
        ('initialize_queue', {'pending_modules': [module], 'completed_modules': []}),
        ('observe_and_mirror', 'continue'),
        ('select_module', {'module': module, 'remaining_modules': []}),
        ('implement', {'paths': ['src/greeting.py']}),
        ('review', ['Use the exact requested greeting.']),
        ('observe_and_mirror', 'continue'),
        ('repair', {'paths': ['src/greeting.py']}),
        ('review', 'PASS'),
        ('log_completion', {'pending_modules': [], 'completed_modules': [{'id': 'greeting', 'artifacts': ['src/greeting.py'], 'review': 'PASS'}]}),
        ('observe_and_mirror', 'continue'),
        ('integration', {'checks': ['tests pass'], 'readme_path': 'README.md'}),
        ('stage_artifacts', {'paths': ['src/greeting.py', 'README.md']}),
        ('observe_and_mirror', 'continue'),
        ('satisfaction', {'action': 'satisfied'}),
        ('complete', 'The greeting function and documentation are complete.'),
    ]
    for step, value in journey:
        assert job['step'] == step
        job = answer(engine, job, value)
    assert job['status'] == 'complete'


def test_extractor_preserves_isolated_review_and_approved_action_resume(library_app):
    engine = Engine(library_app)
    job = engine.start('metaform.library.extractor', {'request': {'source': 'def square(x): return x*x'}}, exclusive=False)
    specification = {'request': {}, 'target_language': 'English pseudocode', 'focus_components': ['square'],
                     'FINAL_SPEC': ['Describe multiplication by itself.'], 'feedback': None,
                     'needs_clarification': True, 'question': 'Which target language?', 'message': ''}
    task = {'id': 'square', 'TASK': 'Document square', 'spec_refs': [], 'dependencies': []}
    packet = {'TASK': task, 'FINAL_SPEC': specification['FINAL_SPEC'], 'target_language': 'English pseudocode',
              'requested_changes': [], 'original_artifacts': [{'source': 'square.py', 'content': 'def square(x): return x*x'}],
              'dependency_artifacts': [], 'previous_documentation': None}
    state = {'requirements': specification, 'TASKS': [], 'completed': [], 'feedback': None}
    journey = [
        ('initialize', state), ('analyze', specification), ('clarify', 'English pseudocode'),
        ('analyze', specification | {'needs_clarification': False}),
        ('decide_plan', {'needs_planning': True}), ('plan', {'TASKS': [task]}),
        ('select_work', {'queue': [task], 'completed': [], 'feedback': None, 'message': ''}),
        ('select_next', {'has_task': True, 'TASK': task, 'remaining_queue': [], 'completed': [], 'dependency_artifacts': [], 'previous_documentation': None}),
        ('prepare_artifacts', packet),
    ]
    for step, value in journey:
        assert job['step'] == step
        job = answer(engine, job, value)
    assert job['step'] == 'draft' and job['context'] == 'fresh'
    implementation = {'documentation': 'Multiply x by itself.', 'tool_needed': True, 'tool': 'parser',
                      'permission_request': 'REQUEST-INSTALL-PERMISSION: parser', 'message': ''}
    job = answer(engine, job, implementation)
    assert job['status'] == 'awaiting_user'
    job = answer(engine, job, 'no')
    assert job['status'] == 'awaiting_user'
    job = answer(engine, job, 'PERMISSION GRANTED')
    assert job['step'] == 'execute_authorized_action'
    action_result = {'operation': 'parse source', 'result': 'Parsed square function.', 'artifacts': []}
    job = answer(engine, job, action_result)
    assert job['step'] == 'draft' and job['inputs']['external_action_result'] == action_result
    implementation['tool_needed'] = False
    job = answer(engine, job, implementation)
    assert job['step'] == 'critic' and job['context'] == 'fresh'
    job = answer(engine, job, {'PATCH_HINTS': ['Name the argument.'], 'message': ''})
    assert job['step'] == 'apply_hints'
    job = answer(engine, job, implementation)
    assert job['step'] == 'evaluate' and job['context'] == 'fresh'
    assert 'PATCH_HINTS' not in job['inputs']
    job = answer(engine, job, {'DEVIATIONS': [], 'sample_checks': [], 'message': ''})
    job = answer(engine, job, {'PATCH_HINTS': ['Name the argument.'], 'DEVIATIONS': [], 'message': ''})
    assert job['step'] == 'draft', 'The authored loop requires both original review lists empty.'
    for step, value in [('draft', implementation), ('critic', {'PATCH_HINTS': [], 'message': ''}),
                        ('evaluate', {'DEVIATIONS': [], 'sample_checks': [], 'message': ''}),
                        ('integrate_reviews', {'PATCH_HINTS': [], 'DEVIATIONS': [], 'message': ''})]:
        assert job['step'] == step
        job = answer(engine, job, value)
    task_result = {'task_id': 'square', 'documentation': implementation['documentation'], 'PATCH_HINTS': [], 'DEVIATIONS': []}
    journey = [('complete_task', {'status': 'completed', 'TASK_RESULT': task_result, 'unresolved': None}),
               ('collect', {'queue': [], 'completed': [task_result], 'feedback': None, 'message': ''}),
               ('select_next', {'has_task': False, 'completed': [task_result], 'TASK': None}),
               ('return_results', {'status': 'completed', 'TASK_RESULTS': [task_result], 'unresolved': None}),
               ('assemble', {'COMPLETE_DELIVERABLE': 'Multiply x by itself.'})]
    for step, value in journey:
        assert job['step'] == step
        job = answer(engine, job, value)
    assert 'Multiply x by itself.' in job['prompt'] and job['status'] == 'awaiting_user'
    job = answer(engine, job, {'approved': 'no', 'feedback': 'Clarify negative inputs.'})
    assert job['step'] == 'record_feedback'


@pytest.mark.parametrize('docs_requested', [False, True])
def test_taskengineplus_preserves_style_requeue_isolation_docs_and_permission(library_app, docs_requested):
    engine = Engine(library_app)
    job = engine.start('metaform.library.taskeengineplus', {'user_input': 'Implement a greeting.'}, exclusive=False)
    task = {'TASK_ID': 'greet', 'NAME': 'Greet', 'DEPENDENCIES': [], 'GOAL': 'Return hello'}
    current = {'TASK': task, 'RETRY_COUNT': 0, 'LAST_ATTEMPT': None, 'PREVIOUS_RESULT': None}
    schedule = {'CURRENT': current, 'QUEUE': [], 'COMPLETED': [], 'RETRY_LOGS': [], 'INSTALL_PERMISSIONS': [], 'ALL_PASSED': True}
    for step, value in [('pre_analyst', {'CLARIFIED_PROBLEM': 'Return hello.'}),
                        ('analyst', {'FINAL_SPEC': ['Return hello.'], 'REQUESTS_DOCS': docs_requested}),
                        ('tech_advisor', {'TECH_STACK': ['Python']}), ('planner', {'TASKS': [task]}),
                        ('initialize_queue', schedule)]:
        assert job['step'] == step
        job = answer(engine, job, value)
    assert job['step'] == 'implementer', 'ALL_PASSED cannot finish a still-current planned task.'
    implementation = {'CODE': 'def greet(): return "hello"', 'TEST': 'assert greet() == "hello"',
                      'NEEDS_INSTALL': True, 'INSTALL_REQUEST': 'Implementer: REQUEST-INSTALL-PERMISSION: pytest',
                      'REQUESTED_TOOLS': ['pytest'], 'INSTALL_PERMISSIONS': []}
    job = answer(engine, job, implementation)
    assert job['status'] == 'awaiting_user' and 'pytest' in job['prompt']
    job = answer(engine, job, {'approved': False})
    assert job['inputs']['PERMISSION_DECISION'] == {'approved': False}
    job = answer(engine, job, implementation | {'NEEDS_INSTALL': False})
    job = answer(engine, job, {'RESULT': {'PATCH_HINTS': ['Use requested naming.']}, 'MESSAGE': 'Critic: Fix naming.'})
    job = answer(engine, job, {'STYLE_PASS': True, 'PATCH_HINTS': ['Use requested naming.']})
    assert job['step'] == 'reconcile_attempt', 'Remaining hints must return to Orchestrator for requeue.'
    retry = current | {'RETRY_COUNT': 1, 'LAST_ATTEMPT': 'Naming needs repair.'}
    job = answer(engine, job, schedule | {'CURRENT': retry})
    assert job['step'] == 'implementer' and job['inputs']['RETRY_COUNT'] == 1
    job = answer(engine, job, implementation | {'NEEDS_INSTALL': False})
    job = answer(engine, job, {'RESULT': 'STYLE_PASS', 'MESSAGE': 'Critic: clean'})
    job = answer(engine, job, {'STYLE_PASS': True, 'PATCH_HINTS': []})
    assert job['step'] == 'evaluator' and job['context'] == 'fresh'
    assert job['inputs']['CODE'] == implementation['CODE']
    evaluation = {'NEEDS_INSTALL': True, 'INSTALL_REQUEST': 'Evaluator: REQUEST-INSTALL-PERMISSION: pytest',
                  'DEVIATIONS': [], 'EXECUTION_EVIDENCE': []}
    job = answer(engine, job, evaluation)
    assert job['status'] == 'awaiting_user' and 'pytest' in job['prompt']
    job = answer(engine, job, {'approved': True})
    assert job['inputs']['PERMISSION_DECISION'] == {'approved': True}
    job = answer(engine, job, evaluation | {'NEEDS_INSTALL': False})
    if docs_requested:
        assert job['step'] == 'doc_writer'
        job = answer(engine, job, {'DOCS': '# Greet\nReturns hello.'})
    assert job['step'] == 'reconcile_attempt'
    complete = {'TASK_ID': 'greet', 'CODE': implementation['CODE'], 'TEST': implementation['TEST'],
                'DOCS': None, 'RETRY_COUNT': 1, 'STYLE_PASS': True, 'DEVIATIONS': []}
    job = answer(engine, job, schedule | {'CURRENT': None, 'COMPLETED': [complete]})
    assert job['step'] == 'complete_deliverable'
    assert answer(engine, job, {'COMPLETE_DELIVERABLE': {'CODE': [complete], 'RETRY_LOGS': []}})['status'] == 'complete'


def test_taskengineplus_duplicate_completed_ids_cannot_replace_a_missing_planned_task(library_app):
    engine = Engine(library_app)
    job = engine.start('metaform.library.taskeengineplus', {'user_input': 'Implement A and B.'}, exclusive=False)
    tasks = [{'TASK_ID': name, 'NAME': name, 'DEPENDENCIES': [], 'GOAL': name} for name in ['A', 'B']]
    for value in [{'CLARIFIED_PROBLEM': 'A and B'}, {'FINAL_SPEC': ['A', 'B'], 'REQUESTS_DOCS': False},
                  {'TECH_STACK': []}, {'TASKS': tasks}]:
        job = answer(engine, job, value)
    completed = {'TASK_ID': 'A', 'STYLE_PASS': True, 'DEVIATIONS': []}
    job = answer(engine, job, {'ALL_PASSED': True, 'CURRENT': None, 'QUEUE': [], 'COMPLETED': [completed, completed]})
    assert job['step'] != 'complete_deliverable'


def test_python_to_c_preserves_phase_dependencies_parallel_roles_and_validation_reporting(library_app):
    engine = Engine(library_app)
    root = engine.start('metaform.library.python_to_c', {'input_directory': '/artifact/source', 'output_dir': '/artifact/docs'}, exclusive=False)
    result = root
    seen = []
    for phase in range(3):
        if result['status'] == 'running':
            result = advance(engine, root['run_id'])
        assert result['status'] == 'awaiting_parallel'
        jobs = result['parallel']
        assert len(jobs) == 5 and len({job['request_id'] for job in jobs}) == 5
        for job in jobs:
            seen.append(job['role'])
            assert '{input_directory}' not in job['prompt'] and '{output_dir}' not in job['prompt']
            assert job['inputs']['input_directory'] == '/artifact/source'
            assert 'agent_context:' in job['inputs']['shared_context_format_example']
            if phase:
                assert len(job['inputs']['phase1']) == 5
            answer(engine, job, {'observed_phase': phase + 1, 'agent': job['role']})
        result = advance(engine, root['run_id'])
    assert len(set(seen)) == 15
    assert result['step'] == 'architecture_synthesizer'
    assert len(result['inputs']['phase3']) == 5
    result = answer(engine, result, {'architecture': 'Observed architecture.'})
    assert result['step'] == 'implementation_guide'
    result = answer(engine, result, {'guide': 'Implement the observed behavior.'})
    assert result['step'] == 'documentation_complete'
    result = answer(engine, result, {'validation_passed': False, 'issues': ['Document the missing dependency.']})
    assert result['status'] == 'complete', 'Source validation_failure is report_and_continue.'
    phase4 = result['result']['steps']['phase4_complete']
    assert phase4['values']['validation']['validation_passed'] is False


def test_mirroring_controller_writes_current_compact_tree_and_follows_exact_results(library_app, tmp_path):
    import asyncio
    import json
    import sys
    from metaform.harness import execute
    from metaform.modules.workflow import progress

    app = library_app
    engine = Engine(app)
    initial = engine.start('metaform.library.orchestrator', {}, exclusive=False)
    job = advance(engine, initial['run_id'])
    script = tmp_path / 'mirror.py'
    script.write_text('''import json, pathlib, subprocess, sys
result = subprocess.run([sys.executable, '-m', 'metaform', 'actor', 'workflow.progress'], capture_output=True, text=True, check=True)
path = pathlib.Path('task/demo/tree.json')
path.parent.mkdir(parents=True, exist_ok=True)
path.write_text(result.stdout)
print(json.dumps({'task_directory': 'task/demo'}))
''')
    app.config['harnesses'] = {'mirror': {'command': [sys.executable, str(script)]}}
    observed = asyncio.run(execute(app, job, 'mirror'))
    assert observed['status'] == 'answered'
    before = json.loads((app.project / 'task/demo/tree.json').read_text())
    assert before['runs'][0]['pending']['step'] == 'bootstrap'
    request_id = job['request_id']
    job = answer(engine, job, observed['answer'] | {'retained_payload': 'ARTIFACT_EVIDENCE_' * 10000})
    assert job['step'] == 'observe_and_mirror'
    asyncio.run(execute(app, job, 'mirror'))
    after = json.loads((app.project / 'task/demo/tree.json').read_text())
    assert after['runs'][0]['pending']['step'] == 'observe_and_mirror'
    assert 'bootstrap' in after['runs'][0]['frames'][0]['completed_steps']
    assert 'ARTIFACT_EVIDENCE_' not in json.dumps(after)
    reference = next(item for item in after['runs'][0]['answers'] if item['request_id'] == request_id)['reference']
    exact = progress(app, reference['arguments'], None)
    assert exact['answer']['retained_payload'] == 'ARTIFACT_EVIDENCE_' * 10000
    child = engine.start('metaform.library.orchestrator', {}, parent=job['run_id'], exclusive=False)
    subtree = progress(app, {'run_id': child['run_id']}, None)
    assert {run['run_id'] for run in subtree['runs']} == {child['run_id']}
    with pytest.raises(ValueError, match='selected subtree'):
        progress(app, {'run_id': child['run_id'], 'result_request_id': request_id}, None)
