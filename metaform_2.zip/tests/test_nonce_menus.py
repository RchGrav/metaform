"""The menu an agent sees is the menu of its context (SPEC sections 9 and 14).

A bound folder shows its assignment: status first, then only that context's
commands. The project's main folder shows the orchestrator's menu. Any other
folder shows no menu at all.
"""
from pathlib import Path

from metaform import cli
from metaform.continuation import begin, marker
from metaform.workflow import Engine, import_workflow


def bound_worker(app, tmp_path):
    import_workflow(app, {'id': 'menu-work', 'steps': [{'id': 'work', 'prompt': 'Do the step.'}]})
    job = Engine(app).start('menu-work', exclusive=False)
    worker = tmp_path / 'worker'
    begin(job['nonce'], worker, app.home)
    return job, worker


def test_a_bound_folder_shows_status_then_only_its_assignment(app, tmp_path, capsys, monkeypatch):
    job, worker = bound_worker(app, tmp_path)
    monkeypatch.chdir(worker)
    for argv in ([], ['--help']):
        cli.main(argv)
        out = capsys.readouterr().out
        assert out.startswith('Status\n'), argv
        assert 'Job id: ' + job['nonce'] in out and 'Workflow: menu-work' in out and 'Step: work' in out
        assert 'Folder: ' + str(worker) in out and 'Worktree: no' in out
        assert 'Installed modules' not in out and 'Choose another project' not in out
        assert 'metaform workflow answer' in out and 'metaform workflow next' in out and 'metaform done' in out
        assert 'intake start' not in out and 'provision' not in out.lower()


def test_the_main_folder_shows_the_agent_base_menu_and_the_orchestrator_menu_behind_help_orchestrate(app, capsys, monkeypatch):
    monkeypatch.chdir(app.project)
    for argv in ([], ['help'], ['--help']):
        cli.main(argv)
        out, err = capsys.readouterr()
        assert out.startswith('Status\n'), (argv, err)
        assert 'Project: ' + app.project.name in out and 'Stage:' in out and 'Job id' not in out, (argv, err)
        assert 'metaform begin <nonce>' in out
        assert 'Orchestrator menu: metaform help orchestrate' in out and 'Admin menu: metaform help admin' in out
        assert 'Provision a harness' not in out and 'Installed modules' not in out
    cli.main(['help', 'orchestrate'])
    out = capsys.readouterr().out
    assert out.startswith('Status\n') and 'Orchestrating from here' in out
    assert 'Provision a harness: metaform install --help' in out
    assert 'List workflows: metaform workflow list' in out
    assert 'Intake: metaform intake start' in out
    assert 'Installed modules' in out
    cli.main(['help', 'admin'])
    out = capsys.readouterr().out
    assert out.startswith('Status\n') and 'Admin menu' in out and 'metaform complete' in out and 'Installed modules' in out


def test_any_other_folder_shows_no_menu(app, tmp_path, capsys, monkeypatch):
    elsewhere = tmp_path / 'elsewhere'
    elsewhere.mkdir()
    monkeypatch.chdir(elsewhere)
    cli.main(['--project', str(app.project)])
    out = capsys.readouterr().out
    assert 'Installed modules' not in out and 'Provision' not in out
    assert 'main folder' in out and str(app.project) in out and 'metaform begin <nonce>' in out


def test_done_ends_the_assignment_and_cleans_its_nonce(app, tmp_path, capsys, monkeypatch):
    job, worker = bound_worker(app, tmp_path)
    assert marker(worker)['nonce'] == job['nonce'] and not (worker / '.agentid').exists()
    monkeypatch.chdir(worker)
    cli.main(['done'])
    out = capsys.readouterr().out
    assert '"status": "done"' in out and job['nonce'] in out
    assert marker(worker) is None and not (worker / '.agentid').exists()
    assert not (app.home / 'assignments' / (job['nonce'] + '.json')).exists()
    monkeypatch.chdir(app.project)
    cli.main([])
    assert capsys.readouterr().out.startswith('Status\n')


def test_done_outside_an_assignment_says_so(app, capsys, monkeypatch):
    monkeypatch.chdir(app.project)
    assert cli.main(['done']) != 0
    assert 'bound assignment' in capsys.readouterr().out


def test_registration_issues_a_workflow_nonce_and_editing_renews_it(app):
    from metaform.continuation import workflow_nonce
    import_workflow(app, {'id': 'reg', 'steps': [{'id': 'a', 'prompt': 'A'}]})
    first = workflow_nonce(app, 'reg')
    assert isinstance(first, str) and len(first) == 16
    assert 'nonce' not in Engine(app).definition('reg')
    import_workflow(app, {'id': 'reg', 'steps': [{'id': 'a', 'prompt': 'A changed'}]})
    assert workflow_nonce(app, 'reg') != first


def test_an_agent_nonce_is_derived_from_the_workflow_nonce_and_records_the_assignment(app):
    import hashlib
    import json
    from metaform.continuation import workflow_nonce
    import_workflow(app, {'id': 'reg', 'steps': [{'id': 'a', 'prompt': 'A'}]})
    job = Engine(app).start('reg', exclusive=False)
    nonce = job['nonce']
    assert len(nonce) == 8 and nonce.isalnum()
    record = json.loads((app.home / 'assignments' / (nonce + '.json')).read_text())
    assert record['workflow'] == 'reg' and record['workflow_nonce'] == workflow_nonce(app, 'reg')
    assert hashlib.sha256((record['workflow_nonce'] + record['salt']).encode()).hexdigest()[:8] == nonce
    assert Engine(app).start('reg', exclusive=False)['nonce'] != nonce


def test_multi_step_assignments_are_isolated_and_single_prompt_operations_are_not(app):
    from metaform.intake import Intake
    import_workflow(app, {'id': 'two', 'steps': [{'id': 'a', 'prompt': 'A'}, {'id': 'b', 'prompt': 'B'}]})
    import_workflow(app, {'id': 'one', 'steps': [{'id': 'a', 'prompt': 'A'}]})
    import_workflow(app, {'id': 'delegate', 'steps': [{'id': 'go', 'kind': 'call', 'workflow': 'two'}]})
    started = Engine(app).start('delegate', exclusive=False)
    delegated = started
    for _ in range(3):
        if delegated.get('nonce'):
            break
        delegated = Engine(app).next(started['run_id'])
    assert delegated.get('nonce'), delegated
    assert delegated.get('workfolder') and Path(delegated['workfolder']).resolve() != app.project.resolve()
    assert not Engine(app).start('two', exclusive=False).get('workfolder'), "the orchestrator's own run stays in the main folder"
    assert not Engine(app).start('one', exclusive=False).get('workfolder')
    assert Path(Intake(app).start()['workfolder']).resolve() == app.project.resolve()


def test_a_subfolder_and_the_temp_folder_get_no_orchestration_menu(app, capsys, monkeypatch):
    import tempfile
    sub = app.project / 'src'
    sub.mkdir(exist_ok=True)
    monkeypatch.chdir(sub)
    cli.main([])
    out = capsys.readouterr().out
    assert 'Orchestrating from here' not in out and 'main folder' in out
    monkeypatch.chdir(tempfile.gettempdir())
    cli.main(['--project', str(app.project)])
    out = capsys.readouterr().out
    assert 'Orchestrating from here' not in out and 'main folder' in out


def test_in_the_middle_of_a_workflow_nothing_activates_until_it_is_aborted(app, capsys, monkeypatch):
    import_workflow(app, {'id': 'busy', 'steps': [{'id': 'a', 'prompt': 'A'}, {'id': 'b', 'prompt': 'B'}]})
    from metaform.registry import Registry
    Engine(app).start('busy', exclusive=True)
    monkeypatch.chdir(app.project)
    for menu in ('base', 'orchestrate'):
        cli.starting_page(Registry(app), initialized=True, menu=menu)
        out = capsys.readouterr().out
        assert out.startswith('Status\n') and 'Workflow: busy' in out, menu
        assert 'Orchestrating from here' not in out and 'Installed modules' not in out
        assert 'This workflow' in out and 'metaform workflow answer' in out and 'metaform abort' in out


def test_the_walk_stops_before_the_home_folder(tmp_path, capsys, monkeypatch):
    """Walking stops before ~, one level deeper: ~/.metaform is the Metaform home, never a project."""
    home = tmp_path / 'user-home'
    (home / '.metaform').mkdir(parents=True)
    (home / '.metaform' / 'state.sqlite3').write_bytes(b'')
    work = home / 'projects' / 'thing'
    work.mkdir(parents=True)
    monkeypatch.setenv('HOME', str(home))
    monkeypatch.chdir(work)
    for argv in ([], ['--help']):
        cli.main(argv)
        out = capsys.readouterr().out
        assert 'Project: ' + home.name + ' (' + str(home) + ')' not in out, argv
        assert 'run metaform from ' + str(home) + '\n' not in out, argv
