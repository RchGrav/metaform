"""The standalone packet runs on the sandbox floor (SPEC section 14).

The packet carries nothing beyond what the floor has: an intake and a workflow run inside a
fresh venv on the floor's Python that holds only the floor packages, and the answers are
checked there by the runtime's own checker, with no jsonschema anywhere.
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from metaform import portable
from metaform.workflow import import_workflow

# The compatibility floor recorded in SPEC section 14, plus Jinja2 as the bundle's own carry.
FLOOR_PACKAGES = [
    "numpy", "pandas", "scipy", "scikit-learn", "statsmodels", "matplotlib", "seaborn", "openpyxl",
    "xlsxwriter", "Pillow", "python-docx", "python-pptx", "pdfplumber", "pdf2image", "pdfkit", "reportlab",
    "sympy", "mpmath", "joblib", "python-dateutil", "pytz", "tqdm", "Jinja2",
]


def floor_python():
    """The floor's Python 3.11 when uv has one, otherwise the running interpreter."""
    uv = shutil.which("uv")
    if uv:
        found = subprocess.run([uv, "python", "find", "3.11"], capture_output=True, text=True)
        if found.returncode == 0 and found.stdout.strip():
            return found.stdout.strip()
    return sys.executable


def fresh_floor_venv(root):
    """A fresh venv on the floor's Python holding only the floor packages."""
    subprocess.run([floor_python(), "-m", "venv", str(root)], check=True, capture_output=True)
    python = root / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    uv = shutil.which("uv")
    assert uv, "uv installs the floor packages into the fresh venv"
    install = subprocess.run([uv, "pip", "install", "--python", str(python), "-q", *FLOOR_PACKAGES],
                             capture_output=True, text=True, timeout=900)
    assert install.returncode == 0, "The floor packages could not be installed: " + install.stderr[-800:]
    return python


def test_an_intake_and_a_workflow_run_inside_the_packet_on_the_floor(app, tmp_path):
    import_workflow(app, {"id": "review", "steps": [{"id": "look", "prompt": "Look at X"}, {"id": "finish", "prompt": "Finish"}]})
    archive = tmp_path / "packet.pyz"
    portable.export(app, archive)
    python = fresh_floor_venv(tmp_path / "floor")
    probe = subprocess.run([str(python), "-c", "import jsonschema"], capture_output=True)
    assert probe.returncode != 0, "The floor venv must not carry jsonschema itself"
    environment = {key: value for key, value in os.environ.items() if not key.startswith("METAFORM_")}
    environment.update(PATH="", PYTHONPATH="")

    def invoke(*arguments):
        result = subprocess.run([str(python), str(archive), *arguments], cwd=tmp_path, env=environment,
                                capture_output=True, text=True, timeout=180)
        assert result.returncode == 0, result.stderr or result.stdout
        return json.loads(result.stdout)

    run_id = invoke("intake", "start")["run_id"]
    invoke("intake", "put", "--run-id", run_id, "--graph", json.dumps({"elements": 5}))
    invoke("intake", "answer", "--run-id", run_id, "--answer",
           json.dumps({"elements": {"code.loop.clock": {"ef": "Shows the time."}}, "joins": [], "subtypes": []}))
    applied = invoke("intake", "apply", "--run-id", run_id)
    assert applied["status"] == "complete"
    # The runtime's own checker judged the first contribution, with no jsonschema on the floor.
    notes = json.dumps(applied.get("annotations"))
    assert "unavailable" not in notes, notes
    assert "is not of type 'object'" in notes, notes
    copies = [entry for entry in tmp_path.iterdir() if entry.is_dir() and entry.name.endswith("_0000")]
    assert len(copies) == 1, copies
    assert not (copies[0] / ".metaform" / "home" / "floor").exists()

    job = invoke("workflow", "start", "--id", "review", "--no-exclusive")
    step = invoke("workflow", "next", "--run-id", job["run_id"])
    assert step["prompt"] == "Look at X"
    invoke("workflow", "answer", "--run-id", job["run_id"], "--request-id", step["request_id"], "--answer", '"looked"')
    following = invoke("workflow", "next", "--run-id", job["run_id"])
    while following["status"] == "running":
        following = invoke("workflow", "next", "--run-id", job["run_id"])
    assert following["prompt"] == "Finish"
