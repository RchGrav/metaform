"""Public build controls and portable dependency/continuation regressions."""

import asyncio
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest

from metaform import packaging, portable
from metaform.app import App
from metaform.modules import package
from metaform.registry import Registry
from metaform.util import read_json, write_json
from metaform.workflow import Engine, import_workflow


def build_source(path):
    """A local PEP 517 backend builds a real wheel without network dependencies."""
    (path / "src" / "metaform").mkdir(parents=True)
    (path / "src" / "metaform" / "__init__.py").write_text("VALUE = 1\n")
    (path / "pyproject.toml").write_text(
        '[build-system]\nrequires = []\nbuild-backend = "fixture_backend"\nbackend-path = ["."]\n'
    )
    (path / "README.md").write_text("Packaging fixture\n")
    (path / "fixture_backend.py").write_text('''
from pathlib import Path
from zipfile import ZipFile
def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    counter = Path("build-count")
    counter.write_text(str(int(counter.read_text()) + 1 if counter.exists() else 1))
    name = "packaging_fixture-1.0-py3-none-any.whl"
    with ZipFile(Path(wheel_directory) / name, "w") as archive:
        archive.writestr("packaging_fixture.py", Path("src/metaform/__init__.py").read_text())
        archive.writestr("packaging_fixture-1.0.dist-info/METADATA", "Metadata-Version: 2.1\\nName: packaging-fixture\\nVersion: 1.0\\n")
        archive.writestr("packaging_fixture-1.0.dist-info/WHEEL", "Wheel-Version: 1.0\\nGenerator: fixture\\nRoot-Is-Purelib: true\\nTag: py3-none-any\\n")
        archive.writestr("packaging_fixture-1.0.dist-info/RECORD", "")
    return name
''')
    return path


def test_build_missing_source_explains_explicit_source_route(app):
    with pytest.raises(ValueError, match=r"package build --source") as failure:
        package.build(app, {}, None)
    assert str(app.project) in str(failure.value)
    assert "pyproject.toml" in str(failure.value)


def test_explicit_build_works_from_an_ordinary_selected_project(app, tmp_path):
    source = build_source(tmp_path / "source")
    app.config["auto_build"] = False
    result = asyncio.run(Registry(app).call("package.build", {"source": str(source)}))
    assert Path(result["wheel"]).parent == source / "dist"
    with zipfile.ZipFile(result["wheel"]) as wheel:
        assert wheel.read("packaging_fixture.py") == b"VALUE = 1\n"
        assert "_portable/jinja2/__init__.py" in wheel.namelist()
        assert not any(name.startswith("_portable/floor/") for name in wheel.namelist()), "The wheel form carries no floor"
    assert not (app.project / "dist").exists()


def test_auto_build_obeys_explicit_configuration_and_source_changes(tmp_path):
    source = build_source(tmp_path / "source")
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "legacy", "auto_build": False})
    app = App(source, home, binding=False)
    registry = Registry(app)
    asyncio.run(registry.after_call())
    assert not (source / "dist").exists()
    app.config["auto_build"] = True
    asyncio.run(registry.after_call())
    asyncio.run(registry.after_call())
    assert (source / "build-count").read_text() == "1"
    (source / "src" / "metaform" / "__init__.py").write_text("VALUE = 2\n")
    asyncio.run(registry.after_call())
    assert (source / "build-count").read_text() == "2"
    with zipfile.ZipFile(next((source / "dist").glob("*.whl"))) as wheel:
        assert wheel.read("packaging_fixture.py") == b"VALUE = 2\n"


def test_export_reports_unbundled_imports_and_retains_diagnostics(app, tmp_path):
    folder = app.root / "modules" / "external"
    write_json(folder / "module.json", {"id": "external", "commands": [
        {"name": "run", "handler": "handler.py:run"}]})
    (folder / "handler.py").write_text(
        "import json\nimport definitely_unbundled_dependency\n"
        "from .helper import value\ndef run(app, args, context): return value\n"
    )
    (folder / "helper.py").write_text("value = 7\n")
    archive = tmp_path / "external.pyz"
    result = portable.export(app, archive)
    assert result["unresolved"] == [{
        "module": "external", "import": "definitely_unbundled_dependency",
        "path": "modules/project/external/handler.py", "line": 2,
        "reason": "unbundled_python_import",
    }]
    with zipfile.ZipFile(archive) as bundle:
        assert "modules/project/external/helper.py" in bundle.namelist()
        assert json.loads(bundle.read("metaform_bundle.json"))["unresolved"] == result["unresolved"]
    imported = portable.import_bundle(archive, tmp_path / "copies")
    assert imported["unresolved"] == result["unresolved"]


def test_public_import_republishes_active_handoff_to_imported_project(app, tmp_path):
    import_workflow(app, {"id": "portable-handoff", "steps": [
        {"id": "work", "prompt": "Inspect the supplied artifact."}]})
    original = Engine(app).start("portable-handoff", exclusive=False)
    archive = tmp_path / "handoff.pyz"
    portable.export(app, archive)
    result = package.import_bundle(app, {"path": str(archive), "destination": str(tmp_path / "copies")}, None)
    handoff, = result["handoffs"]
    record = read_json(app.home / "assignments" / (handoff["nonce"] + ".json"))
    assert record["project"] == result["path"]
    assert record["run_id"] == original["run_id"]
    assert record["request_id"] == original["request_id"]
    target = Path(result["path"])
    imported = App(target, target / ".metaform" / "home", binding=False)
    next_job = Engine(imported).next(original["run_id"])
    assert next_job["request_id"] == original["request_id"]
    assert next_job["prompt"] == original["prompt"]
    assert next_job["nonce"] == handoff["nonce"]


def test_flat_module_diagnostics_do_not_attribute_another_modules_imports(app, tmp_path):
    folder = app.root / "modules"
    write_json(folder / "alpha.json", {"id": "alpha", "commands": [
        {"name": "run", "handler": "alpha.py:run"}]})
    (folder / "alpha.py").write_text("def run(app, args, context): return 1\n")
    write_json(folder / "beta" / "module.json", {"id": "beta", "commands": [
        {"name": "run", "handler": "handler.py:run"}]})
    (folder / "beta" / "handler.py").write_text(
        "import definitely_unbundled_dependency\ndef run(app, args, context): return 2\n"
    )
    result = portable.export(app, tmp_path / "modules.pyz")
    assert [item["module"] for item in result["unresolved"]] == ["beta"]


def test_first_archive_help_keeps_custom_reference_without_materializing_project(app, tmp_path):
    write_json(app.root / "modules" / "reference" / "module.json", {
        "id": "reference", "description": "An exported custom capability.",
        "commands": [{"name": "inspect", "description": "Inspect this exported capability.",
                      "handler": "handler.py:inspect"}],
    })
    (app.root / "modules" / "reference" / "handler.py").write_text(
        "def inspect(api, args, context): return 'exported'\n")
    archive = tmp_path / "help.pyz"
    exported = portable.export(app, archive)
    environment = {key: value for key, value in os.environ.items() if not key.startswith("METAFORM_")}
    environment.update(PYTHONPATH="", PATH="")
    result = subprocess.run([sys.executable, "-S", str(archive), "reference", "--help"],
                            cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=20)
    assert result.returncode == 0, result.stderr
    assert "Inspect this exported capability." in result.stdout
    assert not (archive.parent / exported["mform_sha_id"]).exists()
    running = subprocess.run([sys.executable, "-S", str(archive), "reference", "inspect"],
                             cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=20)
    assert running.returncode == 0, running.stderr
    existing = subprocess.run([sys.executable, "-S", str(archive), "reference", "--help"],
                              cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=20)
    assert existing.returncode == 0, existing.stderr
    assert "Inspect this exported capability." in existing.stdout


@pytest.mark.parametrize("arguments", [
    ["system", "reference"], ["system", "settings"], ["skill"], ["guide", "chassis"]])
def test_archive_reference_operations_do_not_materialize_project(app, tmp_path, arguments):
    import_workflow(app, {"id": "archived-custom", "intent": "Review an archived custom subject.",
                          "steps": [{"id": "review", "prompt": "Review the archived artifact."}]})
    archive = tmp_path / "reference.pyz"
    exported = portable.export(app, archive)
    environment = {key: value for key, value in os.environ.items() if not key.startswith("METAFORM_")}
    environment.update(PYTHONPATH="", PATH="")
    result = subprocess.run([sys.executable, "-S", str(archive), *arguments],
                            cwd=tmp_path, env=environment, capture_output=True, text=True, timeout=20)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip()
    assert not (archive.parent / exported["mform_sha_id"]).exists()
    if arguments == ["guide", "chassis"]:
        workflows = json.loads(result.stdout)["workflows"]["workflows"]
        assert any(workflow["id"] == "archived-custom" for workflow in workflows)


def test_chassis_reference_does_not_trigger_a_source_build(tmp_path):
    source = build_source(tmp_path / "source")
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "legacy", "auto_build": True})
    app = App(source, home, binding=False)
    result = asyncio.run(Registry(app).call("guide.chassis"))
    assert result["foundation"]["artifact"]["id"] == "chassis:operations"
    assert not (source / "build-count").exists()
    assert not (source / "dist").exists()
