import base64
import copy
import json

from metaform.models import capture_model, import_v1
from test_foundation_models import foundation, model_app


def legacy_fixture(app):
    current = foundation(app)
    types = {identifier: {'entity_schema': 'metaform:element', 'entity_desc': record['description'], 'entity_json_obj': {k: record[k] for k in ('ef', 'length', 'aliases')}} for identifier, record in current['types'].items()}
    actuals = {identifier: {'entity_schema': 'metaform:actual-element', 'entity_desc': record['description'], 'entity_json_obj': {'en': record['name'], 'type_ids': ['code.evaluator'] if identifier == 'demo:engine' else ['code'], 'defining_element': identifier == 'demo:project'}} for identifier, record in current['elements'].items()}
    joins = [{'id': j['id'], 'object_id': j['receiver']['id'], 'element_id': j['provider']['id'], 'purpose': j['purpose'], 'type': 'hard dependency', 'join_logic': {'preserve': 'code.evaluator'}, 'join_scope': 'native'} for j in current['joins']]
    return {'native': {'elements': types | actuals, 'joins': joins, 'understanding': current['understanding']}, 'archaeology': {'elements': {'demo:proposal': {'entity_schema': 'metaform:actual-element', 'entity_desc': 'A proposed missing contract.', 'entity_json_obj': {'type_ids': ['code']}}}, 'joins': []}}


def test_migration_preserves_bytes_direction_and_outside_history(model_app):
    source = legacy_fixture(model_app)
    raw = json.dumps(source, indent=3).encode()
    report = import_v1(model_app, raw, {'source': 'archived fixture'})
    result = capture_model(model_app, report['model'])
    assert set(result['elements']) == set(source['native']['elements']) - set(result['types'])
    assert 'demo:proposal' not in result['elements']
    assert result['historical_outside_results'][0]['snapshot'] == source['archaeology']
    assert base64.b64decode(result['source_snapshots'][0]['snapshot']['bytes']) == raw
    assert result['understanding'] == source['native']['understanding']
    for original, migrated in zip(source['native']['joins'], result['joins']):
        assert migrated['receiver']['id'] == original['object_id']
        assert migrated['provider']['id'] == original['element_id']
        assert migrated['purpose'] == original['purpose']
        assert migrated['role'] == original['type']
        assert migrated['join_logic'] == original['join_logic']
        assert migrated['provider_type']['id'] == 'code.evaluator'
    assert all('type_ids' not in record for record in result['elements'].values())
    assert all('category' not in row for row in result['narrowings'])
    assert any(d['code'] == 'unresolved_narrowing' for d in report['diagnostics'])


def test_multiple_facets_remain_unresolved_and_original_is_untouched(model_app):
    source = legacy_fixture(model_app)
    source['native']['elements']['demo:engine']['entity_json_obj']['type_ids'].append('code')
    original = copy.deepcopy(source)
    report = import_v1(model_app, source, {'source': 'multiple-facet fixture'})
    result = capture_model(model_app, report['model'])
    assert source == original
    assert len([b for b in result['bindings'] if b['element']['id'] == 'demo:engine']) == 2
    assert all('provider_type' not in join for join in result['joins'])
    assert len([d for d in report['diagnostics'] if d['code'] == 'unresolved_provider_type']) == 2
    assert result['source_snapshots'][0]['snapshot'] == original


def test_actual_structured_description_and_authored_summary_survive(model_app):
    source = legacy_fixture(model_app)
    record = source['native']['elements']['demo:engine']
    detail = {'account': 'Evaluates observed paths.', 'notes': ['Retains source-specific evidence.'], 'provenance': {'source': 'inspection', 'locator': 'engine'}}
    record['entity_json_obj']['description'] = detail
    record['entity_json_obj']['summary'] = 'Authored concise engine account.'
    original = copy.deepcopy(source)
    result = capture_model(model_app, import_v1(model_app, source, {'source': 'structured-account fixture'})['model'])
    assert result['elements']['demo:engine']['description'] == detail
    assert result['elements']['demo:engine']['summary'] == 'Authored concise engine account.'
    assert result['source_snapshots'][0]['snapshot'] == original
    assert source == original


def test_join_roles_and_softness_survive_import_without_rewriting_source(model_app):
    source = legacy_fixture(model_app)
    prototype = source['native']['joins'][0]
    cases = [
        {'id': 'property-local', 'type': 'property', 'classification': 'occasion', 'is_soft': True,
         'property_type': 'Historical submitted field'},
        {'id': 'property-transitive', 'type': 'property', 'classification': 'language', 'is_soft': False},
        {'id': 'requirement-optional', 'type': 'hard dependency', 'classification': 'environment', 'is_soft': True},
        {'id': 'requirement-custom', 'type': 'hard dependency', 'classification': 'Owner-supplied category', 'is_soft': False},
        {'id': 'legacy-hard', 'type': 'hard dependency'},
        {'id': 'legacy-explicit-soft', 'type': 'hard dependency', 'is_soft': True},
        {'id': 'legacy-supportive', 'type': 'supportive'},
    ]
    source['native']['joins'] = [prototype | case for case in cases]
    original = copy.deepcopy(source)
    result = capture_model(model_app, import_v1(model_app, source, {'source': 'join-semantics fixture'})['model'])
    joins = {join['id']: join for join in result['joins']}
    assert set(joins) == {case['id'] for case in cases}
    for case in cases:
        join = joins[case['id']]
        assert join['role'] == case['type']
        for field in ('classification', 'is_soft', 'property_type'):
            if field in case:
                assert join[field] == case[field]
        assert join['purpose'] == prototype['purpose']
        assert join['join_logic'] == prototype['join_logic']
    assert 'is_soft' not in joins['legacy-hard']
    assert 'classification' not in joins['legacy-hard']
    assert 'is_soft' not in joins['legacy-supportive']
    assert source == original == result['source_snapshots'][0]['snapshot']
    assert all(note['path'] != ['joins', 2, 'role'] for note in result['diagnostics'])
