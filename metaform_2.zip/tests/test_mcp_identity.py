"""Each agent is its own `metaform mcp` process with its own stdin; the system tells them apart by that process
(Rich, 2026-09-14). So a server must be able to say which one it is: the folder it was started in, its pid, its
project and its binding. Two servers in two folders of one project answer differently; a server in a bound worker
folder answers with its nonce. And a server started in a folder that belongs to nothing never makes that folder a
project (SPEC section 13)."""
import asyncio
import json
import os
import sys

import pytest
from mcp import Client
from mcp.client.stdio import StdioServerParameters

from metaform.continuation import begin
from metaform.workflow import Engine, import_workflow


def environment(app):
    return {"METAFORM_RUNTIME_DIR": os.environ["METAFORM_RUNTIME_DIR"], "PYTHONPATH": os.environ.get("PYTHONPATH", ""),
            "METAFORM_HOME": str(app.home)}


async def whoami(app, folder):
    params = StdioServerParameters(command="metaform", args=["mcp"], cwd=str(folder), env=environment(app))
    async with Client(params) as client:
        names = {tool.name for tool in (await client.list_tools()).tools}
        assert "system.whoami" in names
        result = await client.call_tool("system.whoami", {})
        return json.loads("".join(part.text for part in result.content if getattr(part, "text", None)))


def test_two_servers_in_two_folders_of_one_project_say_which_is_which(app, tmp_path):
    deep = app.project / "src" / "inner"
    deep.mkdir(parents=True)
    main, inner = asyncio.run(whoami(app, app.project)), asyncio.run(whoami(app, deep))
    assert main["folder"] == str(app.project) and inner["folder"] == str(deep)
    assert main["project"] == inner["project"] == str(app.project)
    assert main["pid"] != inner["pid"] and main["pid"] != os.getpid()
    assert main["binding"] is None and inner["binding"] is None


def test_a_server_started_elsewhere_by_the_same_harness_still_knows_the_nonce(app, tmp_path):
    """A harness spawns its server from its own folder, never the assignment's, so the folder cannot carry the
    identity. The nonce is entered once by `begin`; the live db links it to the harness process, and the server
    that harness spawns reads it back wherever it was started (Rich, 2026-09-14)."""
    import subprocess

    import_workflow(app, {"id": "who-work", "steps": [{"id": "work", "prompt": "Do the step."}]})
    job = Engine(app).start("who-work", exclusive=False)
    worker = tmp_path / "worker"
    worker.mkdir()
    entered = subprocess.run(["metaform", "begin", job["nonce"]], cwd=str(worker), capture_output=True, text=True,
                             env=dict(os.environ) | environment(app))
    assert entered.returncode == 0, entered.stderr
    import sqlite3

    from metaform import bindings

    assert bindings.linked(os.getpid(), app.home) == job["nonce"], "begin linked the nonce to the harness"

    # The server is started from a folder that knows nothing of the assignment, as a harness starts it.
    answer = asyncio.run(whoami(app, app.project))
    assert answer["folder"] == str(app.project) and answer["ppid"] == os.getpid()
    assert answer["nonce"] == job["nonce"], "the server reads the nonce back through its parent"
    with sqlite3.connect(bindings.database(app.home)) as db:
        row = db.execute("SELECT ppid, nonce FROM agents WHERE pid=?", (answer["pid"],)).fetchone()
    assert row == (os.getpid(), job["nonce"])


@pytest.mark.xfail(strict=True, reason="SPEC section 13: the working folder is never taken as a project of its own; "
                                       "lands with the checkout unit, docs/plan.md step 4")
def test_a_server_started_in_a_folder_that_belongs_to_nothing_makes_no_project_there(app, tmp_path):
    nowhere = tmp_path / "nowhere"
    nowhere.mkdir()
    answer = asyncio.run(whoami(app, nowhere))
    assert answer["folder"] == str(nowhere) and answer["project"] is None
    assert sorted(entry.name for entry in nowhere.iterdir()) == []


def test_the_server_records_its_own_process_and_its_parent_in_the_live_db(app, tmp_path):
    """Each agent is its own process, so the process is the identity: the server finds its pid and the ppid of the
    harness that spawned it and passes both into the live db, with the folder it was started in (Rich, 2026-09-14)."""
    import sqlite3

    from metaform import bindings

    deep = app.project / "src" / "inner"
    deep.mkdir(parents=True)
    main, inner = asyncio.run(whoami(app, app.project)), asyncio.run(whoami(app, deep))
    assert main["ppid"] == inner["ppid"] == os.getpid(), "the parent is the harness that spawned the server"
    assert main["pid"] != inner["pid"]
    with sqlite3.connect(bindings.database(app.home)) as db:
        rows = {row[0]: row[1:] for row in db.execute("SELECT pid, ppid, folder, project FROM agents")}
    assert rows[main["pid"]] == (os.getpid(), str(app.project), str(app.project))
    assert rows[inner["pid"]] == (os.getpid(), str(deep), str(app.project))
