import pytest
from metaform.app import App


@pytest.fixture(autouse=True)
def isolate_default_home(tmp_path, monkeypatch):
    monkeypatch.setenv("METAFORM_HOME", str(tmp_path / "test-default-home"))
    monkeypatch.setenv("METAFORM_RUNTIME_DIR", str(tmp_path / "test-runtime"))


@pytest.fixture(autouse=True)
def stop_test_services(request, isolate_default_home):
    """Release service homes created inside this test's temporary directory."""
    from metaform.service import stop_service

    if "tmp_path" not in request.fixturenames:
        yield
        return
    root = request.getfixturevalue("tmp_path")
    yield
    from metaform.util import read_json
    for endpoint in root.rglob("endpoint.json"):
        record = read_json(endpoint) or {}
        if record.get("runtime_dir") != str(endpoint.parent):
            continue
        with pytest.MonkeyPatch.context() as patch:
            patch.setenv("METAFORM_RUNTIME_DIR", str(endpoint.parent))
            stop_service(timeout=5)


@pytest.fixture
def app(tmp_path):
    from metaform.util import write_json
    write_json(tmp_path / "home" / "config.json", {"knowledge_mode": "legacy", "auto_build": False})
    return App(tmp_path / "project", tmp_path / "home")
