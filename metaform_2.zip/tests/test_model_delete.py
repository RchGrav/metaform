"""Selected semantic deletion preserves sibling records and immutable history."""
import asyncio
import copy
import json

import pytest

from metaform.app import App
from metaform.models import capture_model, foundation_diagnostics, list_models, publish_foundation
from metaform.registry import Registry
from metaform.transform import patch_snapshot
from metaform.util import write_json


@pytest.fixture(params=['json', 'sqlite', 'service'])
def deletion_app(tmp_path, request):
    write_json(tmp_path / 'home' / 'config.json', {
        'knowledge_mode': 'service' if request.param == 'service' else 'legacy',
        'graph_backend': 'sqlite' if request.param == 'service' else request.param, 'auto_build': False})
    return App(tmp_path / 'project', tmp_path / 'home', binding=False)


def fixture(app):
    owner = 'project:' + app.project_id
    ref = lambda kind, name: {'owner': owner, 'kind': kind, 'id': name}
    artifact = ref('element', 'artifact')
    snapshot = {
        'schema_version': '2', 'model': {'project': app.project_id, 'model': 'source'},
        'artifact': artifact, 'understanding': 'The artifact has two independent components.',
        'types': {name: {'id': name, 'owner': owner, 'description': name, 'ef': 'Provide ' + name,
                         'length': 1, 'aliases': []} for name in ('code', 'code.unit', 'code.unit.special')},
        'elements': {name: {'id': name, 'owner': owner, 'name': name, 'description': name,
                            'artifact': artifact} for name in ('artifact', 'bad', 'good')},
        'bindings': [{'id': 'binding:' + name, 'owner': owner, 'element': ref('element', name),
                      'type': ref('type', 'code.unit')} for name in ('bad', 'good')],
        'narrowings': [{'id': 'placement', 'owner': owner, 'parent': ref('type', 'code.unit'),
                       'child': ref('type', 'code.unit.special'), 'category': 'encounter', 'reason': 'More specific function.'}],
        'refinements': [{'id': 'refine:' + name, 'owner': owner, 'parent': artifact,
                        'child': ref('element', name), 'reason': 'Recorded component.'} for name in ('bad', 'good')],
        'joins': [{'id': 'join:' + name, 'owner': owner, 'receiver': artifact,
                   'provider': ref('element', name), 'provider_type': ref('type', 'code.unit'),
                   'purpose': 'Use ' + name, 'role': 'hard dependency', 'classification': 'function',
                   'is_soft': False} for name in ('bad', 'good')],
    }
    snapshot['joins'].extend([
        snapshot['joins'][1] | {'id': 'join:dependent', 'participants': [{'role': 'premise', 'ref': ref('join', 'join:bad')}]},
        snapshot['joins'][1] | {'id': 'join:recursive', 'scope': {'target': ref('join', 'join:dependent')}},
    ])
    snapshot['elements']['foreign-good'] = snapshot['elements']['bad'] | {'owner': 'other-owner'}
    return snapshot, ref


def delete(app, model, target, **arguments):
    return asyncio.run(Registry(app).call('model.delete', {'model': model, 'target': target, **arguments}))


def test_element_delete_previews_closure_then_preserves_siblings_and_source(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    source = publish_foundation(app, document)
    original = capture_model(app, source)
    target = ref('element', 'bad')
    ordinary_remove = patch_snapshot(original, [{'op': 'remove', 'target': target}])
    assert any(note.get('ref') == target for note in foundation_diagnostics(ordinary_remove)), 'Ordinary transform.remove intentionally remains exact-record-only.'

    preview = delete(app, source, target)
    expected = {('element', 'bad'), ('binding', 'binding:bad'), ('refinement', 'refine:bad'),
                ('join', 'join:bad'), ('join', 'join:dependent'), ('join', 'join:recursive')}
    assert {(item['kind'], item['id']) for item in preview['affected']} == expected
    assert preview['preview'] is True
    assert list_models(app) == [source]
    assert capture_model(app, source) == original

    result = delete(app, source, target, preview=False)
    current = capture_model(app, result['model'])
    assert {(item['kind'], item['id']) for item in result['affected']} == expected
    assert current['model']['model'] == source['model'] and current['model'] != source
    assert current['types'] == original['types']
    assert {name: value for name, value in original['elements'].items() if name != 'bad'} == current['elements']
    assert [record['id'] for record in current['joins']] == ['join:good']
    assert [record['id'] for record in current['bindings']] == ['binding:good']
    assert current['narrowings'] == original['narrowings']
    assert not any(note.get('ref') == target for note in current['diagnostics'])
    assert capture_model(app, source) == original
    assert delete(app, source, target, preview=False)['model'] == result['model'], 'Exact retries reuse the recorded deletion.'


@pytest.mark.parametrize('kind,name', [('join', 'join:bad'), ('type', 'code.unit')])
def test_join_or_type_delete_never_removes_other_elements_or_types(deletion_app, kind, name):
    app = deletion_app
    document, ref = fixture(app)
    source = publish_foundation(app, document)
    original = capture_model(app, source)
    result = delete(app, source, ref(kind, name), preview=False)
    current = capture_model(app, result['model'])
    assert current['elements'] == original['elements']
    assert current['types'] == {key: value for key, value in original['types'].items() if not (kind == 'type' and key == name)}
    if kind == 'join':
        assert [join['id'] for join in current['joins']] == ['join:good']
        assert current['bindings'] == original['bindings']
        assert current['refinements'] == original['refinements']
    else:
        assert not current['joins'] and not current['bindings'] and not current['narrowings']
        assert 'code.unit.special' in current['types'], 'Namespace descendants are separate Types, not a deletion cascade.'
    assert capture_model(app, source) == original


def test_delete_rejects_stale_preview_before_new_incident_relation_can_be_missed(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    source = publish_foundation(app, document)
    delete(app, source, ref('element', 'bad'))
    updated = copy.deepcopy(document)
    updated['joins'].append(updated['joins'][0] | {'id': 'join:added-after-preview'})
    new_head = publish_foundation(app, updated, base=source)
    with pytest.raises(ValueError, match='changed.*preview|preview.*changed'):
        delete(app, source, ref('element', 'bad'), preview=False)
    assert list_models(app) == [new_head]
    assert 'bad' in capture_model(app, new_head)['elements']


def test_delete_preview_reports_knowledge_invalidation_without_starting_work(deletion_app):
    from test_model_transformations import generate_advice
    from metaform.layers import active_attachments

    app = deletion_app
    document, ref = fixture(app)
    source = publish_foundation(app, document)
    bad_layer = generate_advice(app, source, ref('element', 'bad'), 'Explain this component.')
    before = active_attachments(app, source)
    with app.db() as db:
        runs_before = db.execute('SELECT count(*) FROM runs').fetchone()[0]
    preview = delete(app, source, ref('element', 'bad'))
    assert any(item['layer'] == bad_layer and item['action'] == 'invalidate' for item in preview['impact']['decisions'])
    assert active_attachments(app, source) == before
    with app.db() as db:
        assert db.execute('SELECT count(*) FROM runs').fetchone()[0] == runs_before
    result = delete(app, source, ref('element', 'bad'), preview=False)
    assert not active_attachments(app, result['model'])
    assert active_attachments(app, source) == before


def test_deleted_reusable_type_is_not_reinserted_from_the_shared_store(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    for record in document['types'].values():
        record['owner'] = 'global'
        app.global_graph.put({'elements': {record['id']: {
            'entity_schema': 'urn:metaform:schema:foundation:2#/$defs/Type',
            'entity_desc': record['description'], 'entity_json_obj': record}}})
    for binding in document['bindings']:
        binding['type']['owner'] = 'global'
    for narrowing in document['narrowings']:
        narrowing['parent']['owner'] = narrowing['child']['owner'] = 'global'
    for join in document['joins']:
        join['provider_type']['owner'] = 'global'
    document['elements']['good']['provenance'] = {
        'derived_from': [{'owner': 'global', 'kind': 'type', 'id': 'code.unit'}]}
    document['types']['code']['presentation'] = {
        'selected_type': {'owner': 'global', 'kind': 'type', 'id': 'code.unit'}}
    source = publish_foundation(app, document)
    shared_before = app.global_graph.export()
    target = {'owner': 'global', 'kind': 'type', 'id': 'code.unit'}
    result = delete(app, source, target, preview=False)
    current = capture_model(app, result['model'])
    assert not any(record['id'] == 'code.unit' and record['owner'] == 'global' for record in current['types'].values())
    assert any(record['id'] == 'code.unit.special' for record in current['types'].values())
    assert app.global_graph.export() == shared_before
    assert current['elements']['good']['provenance'] == document['elements']['good']['provenance']
    assert current['types']['code']['presentation'] == document['types']['code']['presentation']
    from metaform.transform import apply_transformation
    later = apply_transformation(app, {'id': 'refine-surviving-element', 'source': result['model'],
        'destination_model': source['model'], 'purpose': 'Refine a surviving Element.', 'mapping': [],
        'operations': [{'op': 'update', 'target': ref('element', 'good'),
                        'record': current['elements']['good'] | {'description': 'More precise account.'},
                        'reason': 'Only this Element changes.'}]})
    assert not any(record['id'] == 'code.unit' and record['owner'] == 'global'
                   for record in capture_model(app, later['model'])['types'].values()), 'An unrelated edit must not undo the selected deletion.'


def test_delete_handles_an_annotated_invalid_scope_on_the_selected_join(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    document['joins'][0]['scope'] = None
    source = publish_foundation(app, document)
    assert any(note['code'] == 'schema' for note in capture_model(app, source)['diagnostics'])
    result = delete(app, source, ref('join', 'join:bad'), preview=False)
    assert [record['id'] for record in capture_model(app, result['model'])['joins']] == ['join:good']


def test_deleting_artifact_element_preserves_other_elements_files_and_project(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    artifact_file = app.project / 'source.txt'
    artifact_file.write_text('Keep the project source.\n')
    config = (app.root / 'config.json').read_bytes()
    identity = app.project_id
    source = publish_foundation(app, document)
    result = delete(app, source, ref('element', 'artifact'), preview=False)
    current = capture_model(app, result['model'])
    assert current['elements'] == {key: value for key, value in document['elements'].items() if key != 'artifact'}
    assert any(note.get('ref') == document['artifact'] for note in result['diagnostics'])
    assert artifact_file.read_text() == 'Keep the project source.\n'
    assert (app.root / 'config.json').read_bytes() == config
    assert app.project_id == identity
    assert 'artifact' in capture_model(app, source)['elements']


def test_delete_replay_returns_its_original_revision_after_later_edits(deletion_app):
    from metaform.transform import apply_transformation
    from test_model_transformations import generate_advice
    app = deletion_app
    document, ref = fixture(app)
    source = publish_foundation(app, document)
    generate_advice(app, source, ref('element', 'good'), 'Explain the component in its recorded context.')
    deletion = delete(app, source, ref('element', 'bad'), preview=False)
    current = capture_model(app, deletion['model'])
    later = apply_transformation(app, {'id': 'edit-after-deletion', 'source': deletion['model'],
        'destination_model': source['model'], 'purpose': 'Refine surviving work.', 'mapping': [],
        'operations': [{'op': 'update', 'target': ref('element', 'good'),
                        'record': current['elements']['good'] | {'description': 'A later refinement.'},
                        'reason': 'Record the later refinement.'}]})
    with app.db() as db:
        runs_before = db.execute('SELECT count(*) FROM runs').fetchone()[0]
    replay = delete(app, source, ref('element', 'bad'), preview=False)
    assert replay['model'] == deletion['model']
    assert replay['impact'] == deletion['impact']
    assert [job['run_id'] for job in replay['reinference']] == [job['run_id'] for job in deletion['reinference']]
    with app.db() as db:
        assert db.execute('SELECT count(*) FROM runs').fetchone()[0] == runs_before
    assert list_models(app) == [later['model']]


def test_delete_ignores_malformed_incident_refs_without_changing_their_record(deletion_app):
    app = deletion_app
    document, ref = fixture(app)
    document['joins'][-1]['scope'] = {'target': ref('join', [])}
    source = publish_foundation(app, document)
    result = delete(app, source, ref('element', 'bad'), preview=False)
    current = capture_model(app, result['model'])
    assert current['joins'] == [document['joins'][1], document['joins'][-1]]


def test_deletion_preserves_generic_knowledge_and_rerenders_only_the_affected_composite(deletion_app):
    from test_enumerator import composite_fixture
    from metaform.knowledge_tool import start
    from metaform.layers import active_attachments
    from metaform.workflow import Engine

    app = deletion_app
    document = json.loads(json.dumps(composite_fixture()).replace('project:properties', 'project:' + app.project_id))
    document['model'] = {'project': app.project_id, 'model': 'mixed-language-code'}
    source = publish_foundation(app, document)
    request = 'the top 6 creative thinking with foresight imperatives'
    job = start(app, request, 'Creative foresight', source)
    answers = {field: ['Recorded advice for: ' + question] for field, question in job['inputs']['questions'].items()}
    Engine(app).submit(job['run_id'], job['request_id'], answers)
    assert Engine(app).next(job['run_id'])['status'] == 'complete'
    original = active_attachments(app, source)
    base = next(item for item in original if item['question'] == request + ' for program code')
    composite = next(item for item in original if item['subject'] == document['artifact'])
    assert 'bash installer' in composite['question'] and 'cxx23 game engine' in composite['question']
    target = {'owner': 'project:' + app.project_id, 'kind': 'element', 'id': 'installer'}

    preview = delete(app, source, target)
    actions = {item['target']['id']: item['action'] for item in preview['impact']['decisions']}
    assert actions[base['id']] == 'preserve'
    assert actions[composite['id']] == 'regenerate'
    assert active_attachments(app, source) == original
    applied = delete(app, source, target, preview=False)
    active = active_attachments(app, applied['model'])
    assert next(item for item in active if item['id'] == base['id']) == base
    assert all(item['id'] != composite['id'] for item in active)
    regenerated = next(job for job in applied['reinference'] if any(
        context['subject'] == document['artifact'] for context in job['inputs']['contexts'].values()))
    assert regenerated['inputs']['request'] == request
    assert list(regenerated['inputs']['questions'].values()) == [
        request + ' for repository program code that is part cxx23 game engine']
    revised = {field: ['Revised advice for the remaining game engine.'] for field in regenerated['inputs']['questions']}
    Engine(app).submit(regenerated['run_id'], regenerated['request_id'], revised)
    assert Engine(app).next(regenerated['run_id'])['status'] == 'complete'
    current = active_attachments(app, applied['model'])
    assert next(item for item in current if item['id'] == base['id']) == base
    replacement = next(item for item in current if item['slot'] == composite['slot'])
    assert replacement['payload'] == ['Revised advice for the remaining game engine.']
    assert replacement['id'] != composite['id']
    assert active_attachments(app, source) == original
