import json
from pathlib import Path

import pytest

from metaform import prompts
from metaform.util import digest


OLD_BUILTINS = {
    "native": "eb88a6a858cec14dba64fbdf44651781f6de1f18f1eae349c285f7d0e7034059",
    "proof": "da7c9a42d59e954c7984d3a4931a066fc8a6b0e2bc0777b18d3b347f04cba057",
    "archaeology": "1a3ec7258b20c6b7f50fbf9ea7047a7d92375036e7023b1359e1592c0dad27da",
}


def test_current_builtin_prompt_revisions_migrate_and_new_text_uses_spec(app):
    for role, old_digest in OLD_BUILTINS.items():
        identifier = "prompt:metaform.intake." + role
        assert old_digest in prompts.LEGACY_INTAKE_REVISIONS[identifier]
        if role == "proof":
            assert app.graph.get(identifier) is None
            continue
        text = prompts.get(app, identifier)["text"]
        assert "When complete the two graphs are merged" not in text
        prepared = prompts.compose_role(app, "intake" if role == "native" else "blindspots", {})
        assert prepared["contract_version"] == "2"
        assert prepared["components"] == [] if role == "native" else prepared["components"]
        assert ("minimal, coarse project memory graph shape" if role == "native" else "knowledge-layer generation") in text



@pytest.mark.parametrize("role", ["native", "proof", "archaeology"])
def test_obsolete_builtin_migration_preserves_custom_text_and_issued_assignment(app, role):
    from metaform.app import App
    from metaform.workflow import Engine, import_workflow
    before = json.loads((Path(__file__).parent / "fixtures/intake-before-independent-graphs.json").read_text())
    old_text = before["glossary"] + "\n\n" + before[role]
    assert digest(old_text) == OLD_BUILTINS[role]
    identifier = "prompt:metaform.intake." + role
    prompts.put(app, {"id": identifier, "text": old_text})
    import_workflow(app, {"id": "issued-intake", "steps": [{"id": "act", "prompt_ref": identifier}]})
    issued = Engine(app).start("issued-intake")
    reopened = App(app.project, app.home)
    if role == "proof":
        assert prompts.get(reopened, identifier)["text"] == old_text
    else:
        assert "When complete the two graphs are merged" not in prompts.get(reopened, identifier)["text"]
    assert Engine(reopened).next(issued["run_id"]) == issued
    custom = old_text + "\nAuthored addition."
    prompts.put(reopened, dict(prompts.get(reopened, identifier), text=custom))
    assert prompts.get(App(app.project, app.home), identifier)["text"] == custom
