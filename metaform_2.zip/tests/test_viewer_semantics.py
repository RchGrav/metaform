import copy

import pytest

from metaform.backends import JSONGraph
from metaform.intake import Intake
from metaform.prompts import INTAKE_RULE_CODES
from metaform.util import digest
from metaform.viewer import create_app


@pytest.fixture(params=["sqlite", "json"])
def client(app, request):
    if request.param == "json":
        app.graph = JSONGraph(app.root / "semantics.json")
        app.global_graph = JSONGraph(app.home / "semantics.json")
        app.seed()
    return create_app(app).test_client()


def test_network_preserves_joins_without_pairwise_projections(app, client):
    app.graph.put({"joins": [
        {"id": "partial", "element_id": "code", "type": "OP"},
        {"id": "participant", "type": "OP", "participants": [{"ref": "code"}]},
    ]}, "native")
    response = client.get("/api/network")
    assert response.status_code == 200
    joins = {join["source_id"]: join for join in response.json["joins"]}
    assert "object_id" not in joins["partial"]
    assert "element_id" not in joins["participant"]
    assert joins["participant"]["participants"] == [{"ref": "code"}]
    assert response.json["edges"] == []
    assert response.json["nodes"] == [
        {"id": "code", "name": "code", "kind": "reference", "sources": []},
    ]


def test_network_projects_receiving_relationships_without_namespace_edges(app, client):
    purpose = {"native": "  visual representation of objects\n", "archaeology": ["Authored purpose"]}
    app.graph.put({
        "elements": {identifier: {
            "entity_desc": "Example", "entity_schema": "metaform:element",
            "entity_json_obj": {"en": "Display name"},
        } for identifier in ("code", "code.game.platformer.2d", "media.image.sheet.sprite")},
        "joins": [{
            "id": "visuals", "object_id": "code.game.platformer.2d",
            "element_id": "media.image.sheet.sprite", "type": "dependency", "purpose": purpose,
        }, {
            "id": "receives", "type": "dependency", "purpose": "Other OP",
            "participants": [{"role": "ef_owner", "ref": "code.game.platformer.2d"},
                             {"role": "receiver", "ref": "external.receiver"}],
        }],
    }, "native")
    before = app.graph.export()
    data = client.get("/api/network").json
    assert {node["id"] for node in data["nodes"]} == {
        "code", "code.game.platformer.2d", "media.image.sheet.sprite", "external.receiver",
    }
    assert not any(node["kind"] == "join" for node in data["nodes"])
    joins = {join["source_id"]: join for join in data["joins"]}
    assert len(data["edges"]) == 2
    assert {edge["join_id"]: edge for edge in data["edges"]} == {
        joins["visuals"]["id"]: {
            "id": joins["visuals"]["id"], "join_id": joins["visuals"]["id"],
            "source": "media.image.sheet.sprite", "target": "code.game.platformer.2d",
            "label": purpose, "type": "dependency", "membership": "01",
        },
        joins["receives"]["id"]: {
            "id": joins["receives"]["id"], "join_id": joins["receives"]["id"],
            "source": "code.game.platformer.2d", "target": "external.receiver",
            "label": "Other OP", "type": "dependency", "membership": "01",
        },
    }
    assert app.graph.export() == before


def test_network_keeps_unresolved_relationships_without_inventing_directions(app, client):
    app.graph.put({"joins": [
        {"id": "unknown-roles", "type": "dependency", "participants": [
            {"role": "first", "ref": "a"}, {"role": "second", "ref": "b"},
        ]},
        {"id": "multi", "object_id": "a", "element_id": "b", "type": "dependency",
         "participants": [{"role": "receiver", "ref": "a"}, {"role": "ef_owner", "ref": "b"},
                          {"role": "support", "ref": "c"}]},
        {"id": "contradiction", "object_id": "a", "element_id": "b", "type": "dependency",
         "participants": [{"role": "receiver", "ref": "b"}, {"role": "ef_owner", "ref": "a"}]},
        {"id": "ambiguous", "type": "dependency", "participants": [
            {"role": "receiver", "ref": "a"}, {"role": "receiver", "ref": "b"},
            {"role": "ef_owner", "ref": "c"},
        ]},
        {"id": "join-on-join", "object_id": "a", "element_id": "multi", "type": "evidence"},
    ]}, "native")
    before = app.graph.joins()
    data = client.get("/api/network").json
    assert data["edges"] == []
    assert {node["id"] for node in data["nodes"]} == {"a", "b", "c"}
    assert {join["id"]: join for join in data["joins"]} == {join["id"]: join for join in before}


def test_rule_editor_save_preserves_authored_fields_and_primes_next_assignment(app, client):
    original = client.post("/api/call/rulebook.get", json={"rule_code": "r1"}).json
    rule = copy.deepcopy(original)
    rule["concise"] = "  The rule stated exactly; {{ terms }} remain literal.\n"
    rule["priming"]["context"] = "First paragraph.\n\nSecond paragraph; not a changelog.\n"
    rule["priming"]["examples"][0]["reason"] = "  The exact reason.\n"
    rule["additional_context"] = {"authored": ["unchanged", {"detail": "  Exact  "}]}
    response = client.post("/api/call/rulebook.put", json={"rule": rule})
    assert response.status_code == 200
    assert response.json["rule"] == rule
    assert client.post("/api/call/rulebook.get", json={"rule_code": "r1"}).json == rule
    app.seed()
    from metaform import prompts
    identifier = "prompt:metaform.intake.native"
    prompts.put(app, dict(prompts.get(app, identifier), rule_codes=["r1"]))
    assignment = Intake(app).start()
    supplied = next(item for item in assignment["rules"] if item["content"]["rule_code"] == "r1")
    assert supplied == {"content": rule, "revision": digest(rule)}


@pytest.mark.parametrize("explicit_rules", [False, True])
def test_prompt_details_show_effective_rules_without_rewriting_saved_prompt(app, client, explicit_rules):
    identifier = "prompt:metaform.intake.native"
    record = app.graph.get(identifier)
    prompt = record["entity_json_obj"]
    prompt.pop("rule_codes")
    if explicit_rules:
        prompt["rule_codes"] = []
    app.graph.put({"elements": {identifier: record}}, "authored", "prompts")
    before = app.graph.export()
    response = client.get("/api/element/" + identifier)
    assert response.status_code == 200
    assert response.json["record"] == record
    assert response.json["prompt"] == prompt | {"rule_codes": [] if explicit_rules else INTAKE_RULE_CODES}
    assert app.graph.export() == before

    global_record = copy.deepcopy(record)
    global_record["entity_json_obj"]["text"] = "Independent global prompt.\n"
    app.global_graph.put({"elements": {identifier: global_record}}, "authored", "prompts")
    global_response = client.get("/api/element/" + identifier + "?storage=global").json
    assert global_response["record"] == global_record
    assert "prompt" not in global_response


def test_prompt_editor_save_roundtrips_full_object_and_literal_source(app, client):
    identifier = "prompt:metaform.intake.native"
    record = client.get("/api/element/" + identifier).json["record"]
    prompt = record["entity_json_obj"]
    prompt["text"] = "  Literal {{ 1 + 1 }}.\n{% if condition %}Authored example.{% endif %}\n"
    prompt["description"] = "Authored purpose.\n"
    prompt["schema"] = {"type": "object", "properties": {"answer": {"type": "string"}}}
    prompt["rule_codes"] = ["r3", "r1"]
    prompt["additional_context"] = {"terms": ["cpp", "cxx23"]}
    response = client.post("/api/call/prompt.put", json={"prompt": prompt})
    assert response.status_code == 200
    expected = prompt | {"revision": digest(prompt["text"])}
    assert response.json["entity_json_obj"] == expected
    assert client.get("/api/element/" + identifier).json["record"]["entity_json_obj"] == expected
    prepared = client.post("/api/call/prompt.prepare", json={"id": identifier}).json
    assert prepared["schema"] == prompt["schema"]
    assert prepared["prompt"] == prompt["text"]
    assert prepared["annotations"][0]["kind"] == "missing_template_input"
    assert prepared["source_prompt"] == prompt["text"]
    assignment = Intake(app).start()
    assert assignment["source_prompt"] == prompt["text"]
    assert [r["content"]["rule_code"] for r in assignment["rules"]] == ["r3", "r1"]


@pytest.mark.parametrize("storage", ["project", "global"])
def test_element_and_join_editor_preserve_structured_semantics(app, client, storage):
    graph = app.graph if storage == "project" else app.global_graph
    other = app.global_graph if storage == "project" else app.graph
    record = {
        "entity_desc": "Exact description.\n",
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": "Program code", "ef": "Original function", "notes": "Original context"},
    }
    graph.put({"elements": {"code": record}}, "native")
    untouched = other.get("code")
    edited = copy.deepcopy(record)
    edited["entity_json_obj"].update({
        "ef": {"native": "  Contextual function.\n", "archaeology": ["Independent function", {"detail": "Exact"}]},
        "notes": "  Context shaping inference.\n\nLiteral {{ term }}.\n",
        "additional_context": {"retained": True},
    })
    response = client.post("/api/element/code", json={"storage": storage, "record": edited})
    assert response.status_code == 200
    assert client.get("/api/element/code?storage=" + storage).json["record"] == edited
    assert other.get("code") == untouched

    graph.put({"joins": [{
        "id": "code-dependency", "object_id": "code", "element_id": "code.cpp",
        "type": "receiving_entity", "purpose": "Initial OP", "join_logic": "Initial logic",
        "participants": [{"role": "receiver", "ref": "code"}, {"role": "ef_owner", "ref": "code.cpp"},
                         {"role": "condition", "value": {"term": "authored"}}],
    }]}, "archaeology")
    join = graph.joins()[0]
    join["purpose"] = {"native": "  Authored OP.\n", "archaeology": "Independent OP"}
    join["join_logic"] = {"all": [{"literal": " {{ condition }} "}, {"ordered": ["first", "second"]}]}
    join["additional_context"] = ["Exact", {"detail": "  Retained\n"}]
    response = client.post("/api/element/" + join["id"], json={"storage": storage, "join": join})
    assert response.status_code == 200
    assert graph.joins() == [join]
    fetched = client.get("/api/element/code?storage=" + storage).json
    assert fetched["joins"] == [join]
    assert other.joins() == []


@pytest.mark.parametrize("mode,expected", [("service", "sqlite"), ("portable", "json"), ("legacy", "sqlite")])
def test_backend_endpoints_report_open_store_without_rewriting_configuration(tmp_path, mode, expected):
    from metaform.app import App
    from metaform.knowledge import KnowledgeStore
    from metaform.util import write_json

    project, home = tmp_path / "project", tmp_path / "home"
    config_path = project / ".metaform" / "config.json"
    saved = {"knowledge_mode": mode, "graph_backend": "sqlite" if mode == "legacy" else "ladybug", "auto_build": False}
    write_json(config_path, saved)
    store = KnowledgeStore(home / "service" / "knowledge.sqlite3") if mode == "service" else None
    local = App(project, home, binding=False,
                knowledge_client=(lambda _home, project_id: store.bind(project_id)) if store else None)
    if mode == "legacy":
        saved["graph_backend"] = "json"
        write_json(config_path, saved)
        local.refresh_config()
    before = config_path.read_bytes()
    client = create_app(local).test_client()
    responses = {path: client.get(path) for path in ("/api/settings", "/api/network")}
    assert all(response.status_code == 200 for response in responses.values())
    assert {path: response.json["backend"] for path, response in responses.items()} == {
        "/api/settings": expected, "/api/network": expected,
    }
    assert config_path.read_bytes() == before
