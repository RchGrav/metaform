from concurrent.futures import ThreadPoolExecutor

import pytest

from metaform.knowledge import BoundGraph, KnowledgeStore, LocalKnowledge
from metaform.backends import JSONGraph
from test_knowledge_contract import element


def setup_store(tmp_path):
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    ids = [store.call(None, "project.register", {"path": str(tmp_path / name)})["project_id"] for name in ("A", "B")]
    return store, ids


def test_completion_concurrent_projects_and_project_scoped_retry(tmp_path):
    store, ids = setup_store(tmp_path)
    def complete(project_id):
        return store.call(project_id, "inference.commit", {"focal": "X", "snapshot": {"elements": {"X": element(project_id)}, "joins": []}}, "same")
    with ThreadPoolExecutor(2) as executor:
        results = list(executor.map(complete, ids))
    assert sorted(result["reused"] for result in results) == [False, True]
    observations = store.call(ids[0], "graph.provenance", {"owner": "global", "id": "X"})
    assert len([o for o in observations if o["source"] == "archaeology-complete"]) == 1
    for project_id, result in zip(ids, results):
        assert complete(project_id) == result
        assert store.call(project_id, "graph.get", {"id": "X", "scope": "archaeology"}) is not None


def test_completion_rolls_back_before_commit_and_type_presence_is_not_completion(tmp_path):
    store, (a, _) = setup_store(tmp_path)
    store.call(a, "inference.promote", {"graph": {"elements": {"X": element("promoted")}}})
    assert store.call(a, "inference.read", {"id": "X"})["inference_complete"] is False
    with pytest.raises(RuntimeError):
        with store.transaction():
            store.call(a, "inference.commit", {"focal": "X", "snapshot": {"elements": {"X": element("inferred")}, "joins": []}}, "retry")
            raise RuntimeError("before commit")
    assert store.call(a, "inference.read", {"id": "X"})["inference_complete"] is False
    assert store.call(a, "graph.get", {"id": "X"}) is None


def test_completion_read_uses_current_then_snapshot_then_archive(tmp_path):
    local = LocalKnowledge("A", JSONGraph(tmp_path / "P" / "metaform.json"), JSONGraph(tmp_path / "home" / "inference" / "metaform.json"), archive_dependencies=[{"owner": "global", "kind": "element", "id": "Z", "body": element("archive")}])
    graph = BoundGraph(local, "global")
    graph.put({"elements": {"X": element("current")}, "observations": [{"id": "completion", "element_id": "X", "source": "archaeology-complete", "created": "2026-01-01", "record": {"inference": {"elements": {"X": element("old"), "Y": element("snapshot")}, "joins": [{"id": "j", "object_id": "X", "element_id": "Y", "type": "relation", "participants": [{"ref": "Z"}]}]}}}]})
    result = local.call("inference.read", {"id": "X"})
    assert result["graph"]["elements"] == {"X": element("current"), "Y": element("snapshot"), "Z": element("archive")}


def test_contribute_preserves_completed_dependency_and_promote_preserves_definition(tmp_path):
    store, (a, _) = setup_store(tmp_path)
    store.call(a, "inference.commit", {"focal": "Y", "snapshot": {"elements": {"Y": element("established")}, "joins": []}}, "Y")
    store.call(a, "inference.contribute", {"focal": "X", "graph": {"elements": {"X": element("new"), "Y": element("replacement")}}}, "X")
    store.call(a, "inference.promote", {"graph": {"elements": {"Y": element("promoted")}}})
    assert store.call(a, "graph.get", {"owner": "global", "id": "Y"}) == element("established")




@pytest.mark.parametrize("requested_project", ["selected", "other"])
def test_completed_snapshot_foreign_reference_does_not_use_global_same_id(tmp_path, requested_project):
    store, (a, b) = setup_store(tmp_path)
    foreign = "project:" + (a if requested_project == "selected" else b)
    store.call(a, "graph.put", {"owner": "global", "graph": {"elements": {"X": element("unrelated global")}}})
    snapshot = {"elements": {"F": element("focal")}, "joins": [{"id": "j", "type": "relation", "object_id": "F", "element_id": "X", "reference_owners": {"element_id": foreign}, "participants": [{"ref": "X", "owner": foreign}]}]}
    store.call(a, "inference.commit", {"focal": "F", "snapshot": snapshot})
    graph = store.call(a, "inference.read", {"id": "F"})["graph"]
    assert "X" not in graph["elements"]
    assert graph["joins"] == snapshot["joins"]
    assert any(issue["requested_owner"] == foreign and issue["reason"] == "outside_project" for issue in graph["unresolved_references"])


def test_completed_snapshot_join_reference_does_not_resolve_same_named_element(tmp_path):
    store, (a, _) = setup_store(tmp_path)
    store.call(a, "graph.put", {"owner": "global", "graph": {"elements": {"X": element("element X")}}})
    snapshot = {"elements": {"F": element("focal")}, "joins": [{"id": "j", "type": "relation", "participants": [{"ref": "X", "kind": "join"}]}]}
    store.call(a, "inference.commit", {"focal": "F", "snapshot": snapshot})
    graph = store.call(a, "inference.read", {"id": "F"})["graph"]
    assert "X" not in graph["elements"]
    assert graph["unresolved"] == ["X"]
    assert graph["unresolved_references"][0]["kind"] == "join"
