import json
from types import SimpleNamespace

import pytest
from mcp import types

from metaform.intake import Intake
from metaform.mcp_server import Context


@pytest.mark.parametrize("instructions", [None, 'Outside perspective.\nExamine "why".'])
def test_sampling_keeps_instructions_separate_from_assignment(app, instructions):
    job = Intake(app).start()
    if instructions is not None:
        job["system_prompt"] = instructions
    request = SimpleNamespace(session=SimpleNamespace(
        client_capabilities=types.ClientCapabilities(sampling=types.SamplingCapability()),
    ))

    pending = Context(app, request).prepare(job, "intake.answer")

    params = pending["params"]
    assert params.get("systemPrompt") == instructions
    payload = json.loads(params["messages"][0]["content"]["text"])
    assert "system_prompt" not in payload
    assert payload["prompt"] == job["prompt"]
    assert "source_prompt" not in payload
    assert job["source_prompt"] in payload["prompt"]
    assert params["includeContext"] == "none"


def test_host_answer_loop_retains_assignment_instructions(app):
    job = Intake(app).start()
    job["system_prompt"] = "Outside perspective."
    request = SimpleNamespace(session=SimpleNamespace(client_capabilities=None))

    pending = Context(app, request).prepare(job, "intake.answer")

    assert pending["transport"] == "host_answer_loop"
    assert pending["system_prompt"] == job["system_prompt"]
