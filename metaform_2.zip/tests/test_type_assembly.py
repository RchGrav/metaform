"""A Type focal retrieves distinct actual functions without manufacturing OPs."""
import pytest

from metaform.backends import open_graph
from metaform.knowledge import BoundGraph, KnowledgeStore, LocalKnowledge


def element(name, type_id=None):
    data = {"en": name, "ef": name + " encounter", "provenance": [name + ".py"]}
    if type_id:
        data["type_id"] = type_id
    return {"entity_desc": name, "entity_schema": "metaform:element", "entity_json_obj": data}


def actual_record(name, classifications):
    return {"entity_desc": name, "entity_schema": "metaform:actual-element", "entity_json_obj": {
        "type_ids": classifications,
        "description": {"purpose": name, "observed": ["A project-specific freeform fact"]},
        "project_detail": {"source": "actual.py", "behavior": ["one", "two"]},
    }}


def native_graph():
    return {"elements": {
        "code.interface": element("Interface"),
        "code.interface.control": element("Control interface"),
        "code.store": element("Store"),
        "gateway/control": element("Gateway controls", "code.interface"),
        "monitor/control": element("Monitor controls", "code.interface.control"),
        "gateway/state": element("Route state", "code.store"),
        "monitor/state": element("Probe state", "code.store"),
        "unrelated/interface": element("Interface-shaped unrelated thing", "code.interfaceish"),
    }, "joins": [
        {"id": "routes", "object_id": "gateway/control", "element_id": "gateway/state", "type": "hard dependency", "purpose": "Inspect selected routes"},
        {"id": "probes", "object_id": "monitor/control", "element_id": "monitor/state", "type": "hard dependency", "purpose": "Inspect probe failures"},
        {"id": "flavor", "object_id": "gateway/control", "element_id": "monitor/state", "type": "property", "purpose": "Show probe freshness"},
    ]}


@pytest.fixture(params=["sqlite", "json", "service"])
def graph(request, tmp_path):
    if request.param == "service":
        store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
        project_id = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
        return BoundGraph(store.bind(project_id), "project:" + project_id)
    return open_graph(tmp_path / ("graph." + request.param), request.param)


def assert_type_selection(result):
    assert {"gateway/control", "monitor/control", "gateway/state", "monitor/state"} <= result["elements"].keys()
    assert "unrelated/interface" not in result["elements"]
    assert {j["purpose"] for j in result["joins"]} == {"Inspect selected routes", "Inspect probe failures"}
    assert result["elements"]["monitor/control"]["entity_json_obj"]["provenance"] == ["Monitor controls.py"]
    assert "code.interface.control" in result["elements"]


def test_type_focal_preserves_actual_identity_and_direct_purposes(graph):
    graph.put(native_graph(), "native")
    result = graph.assemble("code.interface", depth=1, scope="native", category="hard dependency")
    assert_type_selection(result)
    assert not result["unresolved"]
    assert len(graph.joins(scope="native")) == 3


def test_actual_focal_does_not_expand_to_classification_siblings(graph):
    graph.put(native_graph(), "native")
    result = graph.assemble("gateway/control", depth=1, scope="native", category="hard dependency")
    assert "gateway/state" in result["elements"]
    assert "monitor/control" not in result["elements"]
    assert "monitor/state" not in result["elements"]
    assert "code.interface" in result["elements"]


def test_multiple_classifications_keep_one_actual_and_its_own_joins(graph):
    record = actual_record("Combined control and storage", ["code.interface", "code.store", "code.interface"])
    graph.put({"elements": {
        "code.interface": element("Interface"), "code.store": element("Store"),
        "actual/combined": record, "actual/sibling": actual_record("Other store", ["code.store"]),
        "actual/provider": actual_record("Provider", []),
    }, "joins": [{"id": "own-purpose", "object_id": "actual/combined", "element_id": "actual/provider",
                  "type": "hard dependency", "purpose": "Own purpose"}]}, "native")
    for focal in ("code.interface", "code.store", "code", "actual/combined"):
        result = graph.assemble(focal, depth=1, scope="native")
        assert result["elements"]["actual/combined"] == record
        assert {"code.interface", "code.store", "actual/provider"} <= result["elements"].keys()
        assert len(result["joins"]) == 1
        assert result["joins"][0]["purpose"] == "Own purpose"
        if focal in {"code.interface", "actual/combined"}:
            assert "actual/sibling" not in result["elements"]
    assert len(graph.joins()) == 1


def test_type_membership_is_source_scoped(graph):
    graph.put(native_graph(), "native")
    graph.put({"elements": {
        "code.interface": element("Interface"),
        "gateway/control": element("Latent reclassification", "code.store"),
        "future/control": element("Proposed controls", "code.interface"),
    }}, "archaeology")
    native = graph.assemble("code.interface", depth=0, scope="native")
    latent = graph.assemble("code.interface", depth=0, scope="archaeology")
    assert "gateway/control" in native["elements"]
    assert "future/control" not in native["elements"]
    assert "gateway/control" not in latent["elements"]
    assert "future/control" in latent["elements"]
    assert not latent["joins"]


def test_scoped_assembly_retains_authored_type_without_authored_actuals(graph):
    graph.put({"elements": {
        "code.authored": element("Authored Type"),
        "authored/actual": element("Authored actual", "code.authored"),
        "code.collision": element("Actual using a Type-shaped ID", "code.other"),
    }}, "authored")
    graph.put({"elements": {
        "actual/author": element("Native actual", "code.authored"),
        "actual/collision": element("Native collision reference", "code.collision"),
    }}, "native")
    actual = graph.assemble("actual/author", depth=0, scope="native")
    assert actual["elements"]["code.authored"] == element("Authored Type")
    focal = graph.assemble("code.authored", depth=0, scope="native")
    assert set(focal["elements"]) == {"code.authored", "actual/author"}
    assert not focal["unresolved"]
    collision = graph.assemble("actual/collision", depth=0, scope="native")
    assert "code.collision" not in collision["elements"]


@pytest.mark.parametrize("backend", ["json", "service"])
def test_knowledge_assembly_resolves_global_type_and_local_actuals(tmp_path, backend):
    project_id = "example"
    if backend == "service":
        store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
        project_id = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
        knowledge = store.bind(project_id)
    else:
        knowledge = LocalKnowledge(project_id, open_graph(tmp_path / "local.json", "json"), open_graph(tmp_path / "global.json", "json"))
    local, shared = BoundGraph(knowledge, "project:" + project_id), BoundGraph(knowledge, "global")
    data = native_graph()
    shared.put({"elements": {"code.interface": data["elements"].pop("code.interface")}}, "native")
    local.put(data, "native")
    result = knowledge.call("knowledge.assemble", {"focal": "code.interface", "depth": 1, "scope": "native", "category": "hard dependency"})
    assert_type_selection(result["project"])
    assert "code.interface" in result["global"]["elements"]
    assert {o["source"] for o in result["project"]["observations"]} == {"native"}
    actual = knowledge.call("knowledge.assemble", {"focal": "gateway/control", "depth": 1, "scope": "native", "category": "hard dependency"})
    assert "monitor/control" not in actual["project"]["elements"]
    local.put({"elements": {
        "gateway/control": element("Reclassified proposal", "code.store"),
        "future/control": element("Proposed control", "code.interface"),
    }}, "archaeology")
    scoped = knowledge.call("knowledge.assemble", {"focal": "code.interface", "depth": 0, "scope": "archaeology"})
    assert set(scoped["project"]["elements"]) == {"future/control"}
    assert set(scoped["global"]["elements"]) == {"code.interface"}
    assert not scoped["unresolved"]
    local.put({"elements": {"code.authored": element("Authored Type")}}, "authored")
    local.put({"elements": {"actual/author": element("Actual author", "code.authored")}}, "native")
    for focal in ("actual/author", "code.authored"):
        authored = knowledge.call("knowledge.assemble", {"focal": focal, "depth": 0, "scope": "native"})
        assert set(authored["project"]["elements"]) == {"code.authored", "actual/author"}
        assert not authored["unresolved"]
        assert {o["source"] for o in authored["project"]["observations"]} == {"native", "authored"}
    shared.put({"elements": {"code.collision": element("Opposite-source actual", "code.other")}}, "archaeology")
    local.put({"elements": {"actual/collision": element("Actual collision", "code.collision")}}, "native")
    collision = knowledge.call("knowledge.assemble", {"focal": "actual/collision", "depth": 0, "scope": "native"})
    assert not collision["global"]["elements"]
    combined = actual_record("Combined function", ["code.interface", "code.authored", "code.interface"])
    local.put({"elements": {"actual/combined": combined}}, "native")
    assembled = knowledge.call("knowledge.assemble", {"focal": "actual/combined", "depth": 0, "scope": "native"})
    assert assembled["project"]["elements"]["actual/combined"]["entity_json_obj"] == combined["entity_json_obj"]
    assert set(assembled["project"]["elements"]) == {"actual/combined", "code.authored"}
    assert set(assembled["global"]["elements"]) == {"code.interface"}
    assert not assembled["project"]["joins"]
    assert len(assembled["global"]["observations"]) == 1
    from metaform.graph import type_ids
    assert type_ids(combined) == ["code.interface", "code.authored"]
    assert type_ids(element("Existing scalar", "code.store")) == ["code.store"]
