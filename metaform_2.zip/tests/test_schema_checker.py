"""The runtime checks answers against its schemas with a checker of its own; jsonschema is a dev-only reference.

Rich, 2026-09-13: intake is live per object, so no model-authored JSON reaches a validator, and the jsonschema
library, rpds-py and the sandbox floor go with it. Windows can then run the packet. The shipped schemas use a
fixed subset: type with null unions, properties, required, items, additionalProperties, $ref to local pointers
and registry ids, $defs, enum, const, minimum, maximum, minItems, maxItems, minLength, pattern, oneOf, anyOf,
allOf, if/then.
"""
import copy
import json
import subprocess
import sys
import tomllib
from pathlib import Path

from metaform import schemas


def samples(app):
    """Values to judge against the shipped schemas: one that fits and one that does not, per schema."""
    from metaform.registry import Registry

    pairs = [("urn:metaform:schema:coarse-intake:2#/$defs/IntakeContribution",
              {"elements": {"code.loop.clock": {"ef": "Shows the time.", "name_length": 1}},
               "joins": [{"receiver": "code.loop.clock", "provider": "code.loop", "purpose": "Keep time.",
                          "combined": {"tick": {"relation": "advances", "observation": "One second passes."}}}],
               "subtypes": ["code.loop.clock.digital"]}),
             ("urn:metaform:schema:coarse-intake:2#/$defs/IntakeContribution",
              {"elements": 5, "joins": [{"receiver": 1, "combined": {"tick": {"relation": 2}}}], "subtypes": "x", "extra": True}),
             ("metaform:semantic-rule", {"rule_code": "r1", "purpose": "p", "concise": "c", "priming": "x"}),
             ("metaform:semantic-rule", {"rule_code": 7, "priming": None}),
             ("urn:metaform:schema:transformation:2", {"operations": [{"kind": "add", "target": {"owner": "o", "kind": "type", "id": "code.x"}, "record": {}, "reason": "r"}]}),
             ("urn:metaform:schema:transformation:2", {"operations": [{"kind": "explode", "target": "nope"}], "mappings": 3}),
             ("urn:metaform:schema:blindspot-report:2", {"findings": "not a list"}),
             ("urn:metaform:schema:foundation:2", {"artifact": {}, "types": {"code": {"id": "code", "owner": "o", "description": "d", "ef": ""}}, "elements": {}, "bindings": [], "narrowings": [], "refinements": [], "joins": [], "understanding": {}, "schema_version": "2", "model": {"project": "p", "model": "m", "revision": "r"}}),
             ("urn:metaform:schema:foundation:2", {"artifact": 1, "types": [], "joins": [{"receiver": 5}], "schema_version": 2})]
    for command in Registry(app).discover().values():
        entry = next((item for item in command.manifest["commands"] if item["name"] == command.name), {})
        for example in entry.get("examples", []):
            arguments = example.get("arguments", {})
            pairs.append((command.schema, arguments))
            broken = {key: (None if isinstance(value, (str, int, float, bool)) else 5) for key, value in arguments.items()}
            broken["unexpected_field_for_the_checker"] = [1]
            pairs.append((command.schema, broken))
    return pairs


def test_the_checker_reports_the_same_errors_as_jsonschema_on_the_shipped_schemas(app):
    from jsonschema import Draft202012Validator
    from referencing import Registry as References, Resource
    from referencing.jsonschema import DRAFT202012

    registry = schemas.registry(app)
    references = References().with_resources(
        (key, Resource.from_contents(record, default_specification=DRAFT202012)) for key, record in registry.items())
    compared = 0
    for schema, value in samples(app):
        resolved = {"$ref": schema} if isinstance(schema, str) else schema
        reference = {(tuple(error.absolute_path), error.validator)
                     for error in Draft202012Validator(resolved, registry=references).iter_errors(value)}
        ours = {(tuple(note["path"]), note["code"]) for note in schemas.annotations(app, schema, value)}
        assert ours == reference, (schema, value)
        compared += 1
    assert compared > 40


def test_the_checker_words_the_common_findings_the_way_the_answers_have_always_read(app):
    notes = schemas.annotations(app, "urn:metaform:schema:coarse-intake:2#/$defs/IntakeContribution",
                                {"elements": 5, "subtypes": [1]})
    messages = {tuple(note["path"]): note["message"] for note in notes}
    assert messages[("elements",)] == "5 is not of type 'object'"
    assert messages[("subtypes", 0)] == "1 is not of type 'string'"
    required = schemas.annotations(app, {"type": "object", "required": ["ef"], "properties": {"ef": {"enum": ["a", "b"]}}}, {"ef": "c"})
    assert {note["message"] for note in required} == {"'c' is not one of ['a', 'b']"}
    assert schemas.annotations(app, {"type": "object", "required": ["ef"]}, {})[0]["message"] == "'ef' is a required property"


def test_the_runtime_checks_answers_with_no_jsonschema_importable(app, tmp_path):
    code = """
import sys
sys.modules['jsonschema'] = None
sys.modules['referencing'] = None
from metaform.app import App
from metaform import schemas
app = App(sys.argv[1], sys.argv[2])
notes = schemas.annotations(app, 'urn:metaform:schema:coarse-intake:2#/$defs/IntakeContribution', {'elements': 5})
print(notes[0]['message'])
schemas.register(app, {'$id': 'urn:test:plain', 'type': 'object', 'properties': {'n': {'type': 'integer', 'minimum': 1}}})
print(schemas.annotations(app, 'urn:test:plain', {'n': 0})[0]['message'])
"""
    result = subprocess.run([sys.executable, "-c", code, str(app.project), str(app.home)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == ["5 is not of type 'object'", "0 is less than the minimum of 1"]


def test_jsonschema_is_a_dev_dependency_only():
    project = tomllib.loads(Path("pyproject.toml").read_text())
    assert not any(dependency.startswith("jsonschema") for dependency in project["project"]["dependencies"])
    assert any(dependency.startswith("jsonschema") for dependency in project["dependency-groups"]["dev"])


def test_the_packet_and_the_wheel_carry_no_floor(app, tmp_path):
    import zipfile
    from metaform import portable

    assert not (Path("src/metaform/data") / "sandbox").exists()
    archive = tmp_path / "packet.pyz"
    portable.export(app, archive)
    with zipfile.ZipFile(archive) as packet:
        names = packet.namelist()
    assert not any(name.startswith("floor/") for name in names)
    assert not any("jsonschema" in name or "rpds" in name for name in names)
