"""Regression witnesses for the runtime findings in the September system review."""

import asyncio
import copy
import sys
from pathlib import Path

import pytest

from metaform import workfolders
from metaform.app import App
from metaform.continuation import begin, current
from metaform.intake import Intake
from metaform.modules.workflow import drive, project_path
from metaform.registry import Registry
from metaform.util import write_json
from metaform.workflow import Engine, import_workflow


@pytest.fixture
def runtime_app(tmp_path, request):
    home = tmp_path / "home"
    write_json(home / "config.json", {
        "knowledge_mode": "legacy", "graph_backend": getattr(request, "param", "json"),
        "auto_build": False,
    })
    return App(tmp_path / "project", home, binding=False)


def bound_app(app, job):
    bound = copy.copy(app)
    bound.binding = {
        "project": str(app.project), "home": str(app.home), "module": "workflow",
        **{key: job[key] for key in ("run_id", "request_id", "nonce")},
    }
    return bound


def two_runs(app):
    import_workflow(app, {"id": "two", "steps": [
        {"id": "one", "prompt": "FIRST {{who}}"},
        {"id": "two", "prompt": "SECOND {{who}}"},
    ]})
    engine = Engine(app)
    return engine, engine.start("two", {"who": "A"}, exclusive=False), engine.start(
        "two", {"who": "B"}, exclusive=False,
    )


def test_bound_workflow_routes_keep_issued_run_and_request(runtime_app):
    app = runtime_app
    engine, first, sibling = two_runs(app)
    bound = bound_app(app, first)
    arguments = {key: sibling[key] for key in ("run_id", "request_id")}
    for command in ("workflow.next", "workflow.answer"):
        with pytest.raises(ValueError, match="conflicts with the bound assignment"):
            asyncio.run(Registry(bound).call(command, arguments | {"answer": "wrong identity"}))
    assert engine.next(first["run_id"]) == first
    assert engine.next(sibling["run_id"]) == sibling
    assert asyncio.run(Registry(bound).call("workflow.next", {})) == first
    matched = {key: first[key] for key in ("run_id", "request_id")}
    receipt = asyncio.run(Registry(bound).call("workflow.answer", matched | {"answer": "A result"}))
    assert receipt["run_id"] == first["run_id"]
    assert engine.next(sibling["run_id"]) == sibling
    second = engine.next(first["run_id"])
    assert second["prompt"] == "SECOND A"
    assert asyncio.run(Registry(bound).call("workflow.answer", {"answer": "duplicate"})) == receipt
    assert asyncio.run(Registry(bound).call("workflow.answer", matched | {"answer": "duplicate"})) == receipt
    assert engine.next(first["run_id"]) == second


@pytest.mark.parametrize("route", ["current", "nonce", "next", "drive"])
def test_completed_binding_does_not_receive_later_assignment(runtime_app, tmp_path, route):
    app = runtime_app
    engine, first, sibling = two_runs(app)
    bound = bound_app(app, first)
    engine.submit(first["run_id"], first["request_id"], "done")
    second = engine.next(first["run_id"])
    error = {"drive": "Unknown command", "nonce": "Unknown workflow handoff"}.get(route, "pending")
    with pytest.raises(ValueError, match=error):
        if route == "current":
            current(bound)
        elif route == "nonce":
            begin(first["nonce"], tmp_path / "handoff", app.home)
        else:
            asyncio.run(Registry(bound).call("workflow." + route, {}))
    assert engine.next(first["run_id"]) == second
    assert engine.next(sibling["run_id"]) == sibling


def test_foreach_back_transition_issues_a_new_pass(runtime_app):
    app = runtime_app
    import_workflow(app, {"id": "loop", "steps": [
        {"id": "each", "kind": "foreach", "items": {"var": "inputs.items"}, "prompt": "Visit {{item}}"},
        {"id": "decide", "prompt": "Repeat?", "transitions": [
            {"when": {"var": "steps.decide"}, "to": "each"}, {"to": None},
        ]},
    ]})
    engine = Engine(app)
    first = engine.start("loop", {"items": ["A"]}, exclusive=False)
    run_id = first["run_id"]
    engine.submit(run_id, first["request_id"], "first pass")
    assert engine.next(run_id)["status"] == "running"
    decision = engine.next(run_id)
    engine.submit(run_id, decision["request_id"], True)
    repeated = engine.next(run_id)
    assert repeated["status"] == "awaiting_answer"
    assert repeated["prompt"] == "Visit A"
    assert repeated["request_id"] != first["request_id"]
    assert engine.next(run_id) == repeated
    engine.submit(run_id, repeated["request_id"], "second pass")
    engine.next(run_id)
    decision = engine.next(run_id)
    engine.submit(run_id, decision["request_id"], False)
    assert engine.next(run_id)["result"]["steps"]["each"] == ["second pass"]


@pytest.mark.parametrize("runtime_app", ["json", "sqlite"], indirect=True)
def test_parallel_harness_edits_parent_workfolder_and_retains_diff(runtime_app):
    app = runtime_app
    (app.project / "target.txt").write_text("original\n")
    import_workflow(app, {"id": "child", "steps": [{"id": "act", "prompt": "Edit target.txt"}]})
    import_workflow(app, {"id": "parent", "steps": [
        {"id": "fork", "kind": "parallel", "branches": ["child"]},
    ]})
    engine = Engine(app)
    parent = engine.start("parent", exclusive=False, workfolder=True)
    child = parent["parallel"][0]
    folder = workfolders.get(app, app.load_run(parent["run_id"])["workfolder_id"])
    assert project_path(app, {"run_id": child["run_id"]}) == Path(folder["path"])
    app.config["harnesses"] = {"fixture": {"command": [
        sys.executable, "-c", "from pathlib import Path; Path('target.txt').write_text('modified by child\\n'); print('done')",
    ]}}
    assert asyncio.run(drive(app, {"run_id": child["run_id"], "harness": "fixture"}, None))["status"] == "complete"
    engine.next(parent["run_id"])
    final = engine.next(parent["run_id"])
    assert (app.project / "target.txt").read_text() == "original\n"
    assert (Path(folder["path"]) / "target.txt").read_text() == "modified by child\n"
    assert "+modified by child" in final["result"]["changes"]["diff"]


def test_mcp_answer_survives_module_takeover_and_keeps_receipt(runtime_app):
    from mcp import types
    from metaform.mcp_server import accept_sample

    app = runtime_app
    engine, first, _ = two_runs(app)
    intake = Intake(app).start()
    result = types.CreateMessageResult(
        role="assistant", content=types.TextContent(type="text", text='"workflow result"'),
        model="fixture", stop_reason="endTurn",
    )
    pending = {key: first[key] for key in ("run_id", "request_id")} | {"command": "workflow.answer"}
    receipt = asyncio.run(accept_sample(app, pending, result))
    assert receipt["recorded"]
    assert asyncio.run(accept_sample(app, pending, result)) == receipt
    assert engine.next(first["run_id"])["prompt"] == "SECOND A"
    assert app.get("mode")["run_id"] == intake["run_id"]
    assert app.load_run(intake["run_id"])["pending"] == intake


@pytest.mark.parametrize("direction", ["directory-to-file", "file-to-directory"])
def test_portable_workfolder_applies_file_directory_replacement(runtime_app, direction):
    app = runtime_app
    entry = app.project / "entry"
    if direction == "directory-to-file":
        (entry / "deeper").mkdir(parents=True)
        (entry / "deeper" / "nested").write_text("old")
    else:
        entry.write_text("old")
    folder = workfolders.create(app)
    changed = Path(folder["path"]) / "entry"
    if direction == "directory-to-file":
        (changed / "deeper" / "nested").unlink()
        (changed / "deeper").rmdir()
        changed.rmdir()
        changed.write_text("new")
    else:
        changed.unlink()
        changed.mkdir()
        (changed / "nested").write_text("new")
    assert workfolders.apply(app, folder["id"])["applied"]
    assert (entry if direction == "directory-to-file" else entry / "nested").read_text() == "new"


def test_directory_replacement_preserves_unreviewed_source_additions(runtime_app):
    app = runtime_app
    entry = app.project / "entry"
    entry.mkdir()
    (entry / "nested").write_text("old")
    (app.project / "a.txt").write_text("before")
    folder = workfolders.create(app)
    changed = Path(folder["path"]) / "entry"
    (changed / "nested").unlink()
    changed.rmdir()
    changed.write_text("new")
    (Path(folder["path"]) / "a.txt").write_text("after")
    (entry / "unreviewed").write_text("keep")
    with pytest.raises(ValueError, match="Source changed"):
        workfolders.apply(app, folder["id"])
    assert (entry / "nested").read_text() == "old"
    assert (entry / "unreviewed").read_text() == "keep"
    assert (app.project / "a.txt").read_text() == "before"


def test_aborted_parallel_child_keeps_parent_workfolder(runtime_app):
    from metaform.harness import execute

    app = runtime_app
    (app.project / "target.txt").write_text("original")
    import_workflow(app, {"id": "child", "steps": [{"id": "act", "prompt": "Work"}]})
    import_workflow(app, {"id": "parent", "steps": [
        {"id": "fork", "kind": "parallel", "branches": ["child"]},
    ]})
    engine = Engine(app)
    parent = engine.start("parent", exclusive=False, workfolder=True)
    child = parent["parallel"][0]
    folder_id = app.load_run(parent["run_id"])["workfolder_id"]
    folder = Path(child["workfolder"])
    app.config["harnesses"] = {"fixture": {"command": [
        sys.executable, "-c", "from pathlib import Path; import time; Path('started').touch(); time.sleep(30)",
    ]}}

    async def scenario():
        execution = asyncio.create_task(execute(app, child, "fixture"))
        try:
            async with asyncio.timeout(10):
                while not (folder / "started").exists():
                    if execution.done():
                        await execution
                        pytest.fail("Fixture stopped before starting its work")
                    await asyncio.sleep(0.02)
                engine.abort(child["run_id"])
                assert (await execution)["status"] == "aborted"
        finally:
            if not execution.done():
                execution.cancel()
                await asyncio.gather(execution, return_exceptions=True)

    asyncio.run(scenario())
    assert (folder / "target.txt").read_text() == "original"
    assert workfolders.get(app, folder_id)["path"] == str(folder)
    assert app.load_run(parent["run_id"])["status"] == "running"


def test_bound_drive_executes_only_its_issued_assignment(runtime_app):
    app = runtime_app
    engine, first, sibling = two_runs(app)
    bound = bound_app(app, first)
    app.config["harnesses"] = {"fixture": {"command": [sys.executable, "-c", "print('done')"]}}
    with pytest.raises(ValueError, match="conflicts with the bound assignment"):
        asyncio.run(drive(bound, {"run_id": sibling["run_id"], "harness": "fixture"}, None))
    assert engine.next(first["run_id"]) == first
    assert engine.next(sibling["run_id"]) == sibling
    receipt = asyncio.run(drive(bound, {"harness": "fixture"}, None))
    assert receipt["recorded"] and receipt["run_id"] == first["run_id"]
    assert engine.next(first["run_id"])["prompt"] == "SECOND A"
    assert engine.next(sibling["run_id"]) == sibling


def test_idle_parallel_child_abort_keeps_parent_workfolder(runtime_app):
    app = runtime_app
    (app.project / "target.txt").write_text("original")
    import_workflow(app, {"id": "child", "steps": [{"id": "act", "prompt": "Work"}]})
    import_workflow(app, {"id": "parent", "steps": [
        {"id": "fork", "kind": "parallel", "branches": ["child"]},
    ]})
    parent = Engine(app).start("parent", exclusive=False, workfolder=True)
    child = parent["parallel"][0]
    folder = Path(child["workfolder"])
    asyncio.run(Registry(bound_app(app, child)).call("abort"))
    assert (folder / "target.txt").read_text() == "original"
    assert app.load_run(child["run_id"])["status"] == "aborted"
    assert app.load_run(parent["run_id"])["status"] == "running"


def test_child_with_its_own_workfolder_still_cleans_up_on_abort(runtime_app):
    app = runtime_app
    import_workflow(app, {"id": "child", "steps": [{"id": "act", "prompt": "Work"}]})
    engine = Engine(app)
    parent = engine.start("child", exclusive=False, workfolder=True)
    child = engine.start("child", parent=parent["run_id"], exclusive=False, workfolder=True)
    asyncio.run(Registry(bound_app(app, child)).call("abort"))
    assert not Path(child["workfolder"]).exists()
    assert Path(parent["workfolder"]).exists()


def test_parent_abort_stops_descendants_before_shared_folder_cleanup(runtime_app):
    from metaform.harness import execute

    app = runtime_app
    (app.project / "target.txt").write_text("original")
    import_workflow(app, {"id": "leaf", "steps": [{"id": "act", "prompt": "{{name}}"}]})
    import_workflow(app, {"id": "middle", "steps": [{"id": "fork", "kind": "parallel", "branches": [
        {"workflow": "leaf", "inputs": {"name": {"literal": "slow"}}},
    ]}]})
    import_workflow(app, {"id": "parent", "steps": [{"id": "fork", "kind": "parallel", "branches": [
        {"workflow": "leaf", "inputs": {"name": {"literal": "fast"}}}, "middle",
    ]}]})
    engine = Engine(app)
    unrelated = engine.start("leaf", {"name": "unrelated"}, exclusive=False)
    parent = engine.start("parent", workfolder=True)
    fast, middle = parent["parallel"]
    slow = middle["parallel"][0]
    folder = Path(fast["workfolder"])
    folder_id = app.load_run(parent["run_id"])["workfolder_id"]
    script = app.home / "waiting_child.py"
    script.write_text(
        "import json, signal, sys, time\n"
        "from pathlib import Path\n"
        "name = json.loads(Path(sys.argv[1]).read_text())['prompt']\n"
        "def stop(*args):\n"
        "    while name == 'slow' and not Path('release-slow').exists(): time.sleep(0.01)\n"
        "    Path(name + '-stopped').write_text('retained child output')\n"
        "    raise SystemExit(0)\n"
        "signal.signal(signal.SIGTERM, stop)\n"
        "Path(name + '-started').touch()\n"
        "while True: time.sleep(1)\n"
    )
    app.config["harnesses"] = {"fixture": {"command": [
        sys.executable, str(script), "{request_file}",
    ]}}

    async def scenario():
        executions = [asyncio.create_task(execute(app, job, "fixture")) for job in (fast, slow)]
        try:
            async with asyncio.timeout(10):
                while not all((folder / (name + "-started")).exists() for name in ("fast", "slow")):
                    for task in executions:
                        if task.done():
                            await task
                            pytest.fail("Fixture stopped before starting")
                    await asyncio.sleep(0.02)
                app.abort()
                assert folder.exists()
                assert engine.next(unrelated["run_id"]) == unrelated
                assert all(app.load_run(job["run_id"])["status"] == "aborted" for job in (parent, fast, middle, slow))
                assert (await executions[0])["status"] == "aborted"
                assert folder.exists()
                (folder / "release-slow").touch()
                assert (await executions[1])["status"] == "aborted"
        finally:
            if folder.exists():
                (folder / "release-slow").touch()
            for task in executions:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*executions, return_exceptions=True)

    asyncio.run(scenario())
    assert not folder.exists()
    assert (app.root / "outputs" / folder_id / "slow-stopped").read_text() == "retained child output"
    assert (app.project / "target.txt").read_text() == "original"
    assert engine.next(unrelated["run_id"]) == unrelated


def test_parent_abort_retains_folder_during_child_process_start(runtime_app, monkeypatch):
    from metaform.harness import execute

    app = runtime_app
    import_workflow(app, {"id": "leaf", "steps": [{"id": "act", "prompt": "Work"}]})
    import_workflow(app, {"id": "parent", "steps": [{"id": "fork", "kind": "parallel", "branches": ["leaf"]}]})
    parent = Engine(app).start("parent", workfolder=True)
    child = parent["parallel"][0]
    folder = Path(child["workfolder"])
    app.config["harnesses"] = {"fixture": {"command": [sys.executable, "-c", "import time; time.sleep(30)"]}}
    create_process = asyncio.create_subprocess_exec

    async def scenario():
        entered, release = asyncio.Event(), asyncio.Event()

        async def delayed_start(*args, **kwargs):
            entered.set()
            await release.wait()
            return await create_process(*args, **kwargs)

        monkeypatch.setattr(asyncio, "create_subprocess_exec", delayed_start)
        execution = asyncio.create_task(execute(app, child, "fixture"))
        try:
            async with asyncio.timeout(10):
                await entered.wait()
                app.abort()
                assert folder.exists()
                release.set()
                assert (await execution)["status"] == "aborted"
        finally:
            release.set()
            if not execution.done():
                execution.cancel()
            await asyncio.gather(execution, return_exceptions=True)

    asyncio.run(scenario())
    assert not folder.exists()


@pytest.mark.parametrize("completed", [False, True])
def test_answered_child_keeps_execution_claim_until_harness_stops(runtime_app, completed):
    from metaform.harness import execute

    app = runtime_app
    import_workflow(app, {"id": "leaf", "steps": [{"id": "act", "prompt": "Work"}]})
    import_workflow(app, {"id": "parent", "steps": [{"id": "fork", "kind": "parallel", "branches": ["leaf"]}]})
    engine = Engine(app)
    parent = engine.start("parent", workfolder=True)
    child = parent["parallel"][0]
    folder = Path(child["workfolder"])
    folder_id = app.load_run(parent["run_id"])["workfolder_id"]
    script = app.home / "answered_child.py"
    script.write_text(
        "import signal, time\n"
        "from pathlib import Path\n"
        "def stop(*args):\n"
        "    Path('stopped').write_text('last child output')\n"
        "    raise SystemExit(0)\n"
        "signal.signal(signal.SIGTERM, stop)\n"
        "Path('started').touch()\n"
        "while True: time.sleep(1)\n"
    )
    app.config["harnesses"] = {"fixture": {"command": [sys.executable, str(script)]}}

    async def scenario():
        execution = asyncio.create_task(execute(app, child, "fixture"))
        try:
            async with asyncio.timeout(10):
                while not (folder / "started").exists():
                    if execution.done():
                        await execution
                        pytest.fail("Fixture stopped before starting")
                    await asyncio.sleep(0.02)
                receipt = engine.submit(child["run_id"], child["request_id"], "independent answer")
                assert receipt["recorded"]
                assert app.load_run(child["run_id"])["pending"] is None
                if completed:
                    completion = engine.next(child["run_id"])
                    assert completion["status"] == "complete"
                app.abort()
                assert folder.exists()
                assert (await asyncio.wait_for(execution, 2))["status"] == "aborted"
                assert engine.submit(child["run_id"], child["request_id"], "duplicate") == receipt
                if completed:
                    retained = engine.next(child["run_id"])
                    assert retained["status"] == "complete"
                    assert retained["result"] == completion["result"]
        finally:
            if not execution.done():
                execution.cancel()
            await asyncio.gather(execution, return_exceptions=True)

    asyncio.run(scenario())
    assert not folder.exists()
    assert (app.root / "outputs" / folder_id / "stopped").read_text() == "last child output"
