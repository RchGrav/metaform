import copy

from metaform import prompts
from metaform.app import App
from metaform.models import capture_model, publish_foundation
from metaform.modules import workflow
from metaform.workflow import Engine, import_workflow


def foundation(app):
    owner = 'project:' + app.project_id
    ref = lambda kind, identifier: {'owner': owner, 'kind': kind, 'id': identifier}
    artifact = ref('element', 'demo:engine')
    snapshot = {'schema_version': '2', 'model': {'project': app.project_id, 'model': 'demo'}, 'artifact': artifact,
        'understanding': 'The engine evaluates connectivity for an operator.',
        'types': {'code.evaluator': {'id': 'code.evaluator', 'owner': owner, 'description': 'An evaluator interprets observations.',
                  'ef': 'Determine viable connectivity', 'length': 1, 'aliases': []}},
        'elements': {'demo:engine': {'id': 'demo:engine', 'owner': owner, 'name': 'Connectivity engine', 'artifact': artifact,
                    'description': 'The connectivity evaluator implemented in engine.cpp.'},
                    'demo:operator': {'id': 'demo:operator', 'owner': owner, 'name': 'Network operator', 'artifact': artifact,
                    'description': 'The operator selects a usable network.'}},
        'bindings': [{'id': 'engine-evaluator', 'owner': owner, 'element': artifact, 'type': ref('type', 'code.evaluator')}],
        'joins': [{'id': 'choose-network', 'owner': owner, 'receiver': ref('element', 'demo:operator'), 'provider': artifact,
                   'provider_type': ref('type', 'code.evaluator'), 'purpose': 'Choose a viable network', 'role': 'hard dependency'}],
        'narrowings': [], 'refinements': []}
    return publish_foundation(app, snapshot)


def test_grounded_instruction_receives_canonical_context_and_applies_literal_answer(app):
    model = foundation(app)
    source = 'Refactor its evaluator; retain {{ network }} in examples.'
    job = workflow.lexicalize(app, {'model': model, 'target': 'demo:engine', 'prompt': source}, None)
    assert job['contract_version'] == '2'
    assert job['inputs']['source_instruction'] == source
    assert job['model'] == model
    assert job['targets'][0]['id'] == 'demo:engine'
    records = {item['ref']['id']: item['value'] for item in job['inputs']['region']['records']}
    assert records['choose-network']['purpose'] == 'Choose a viable network'
    assert records['code.evaluator']['ef'] == 'Determine viable connectivity'
    assert job['context_dependencies']
    assert app.get(job['context_ref']) == job['inputs']['region']
    assert job['source_prompt'] == prompts.get(app, 'prompt:metaform.role.ground-and-specialize')['text']
    answer = {'instruction': 'Refactor demo:engine in engine.cpp while preserving choose-network and {{ network }} examples.',
              'model': model, 'targets': job['targets']}
    engine = Engine(app)
    receipt = engine.submit(job['run_id'], job['request_id'], answer)
    assert receipt['annotations'] == []
    engine.next(job['run_id'])
    applied = workflow.apply(app, {'run_id': job['run_id'], 'id': 'refactor-engine'}, None)
    executable = engine.start(applied['id'], exclusive=False)
    assert executable['source_prompt'] == answer['instruction']
    assert executable['prompt'] == answer['instruction']
    assert executable['inputs']['metaform'] == job['inputs']['region']
    assert executable['model'] == model
    assert engine.definition(applied['id'])['source_instruction'] == source


def test_specialization_preserves_source_control_flow_and_frozen_read_context(app):
    model = foundation(app)
    source = {'id': 'source', 'intent': 'Refactor then repeat review when a revision is needed.', 'steps': [
        {'id': 'edit', 'prompt': 'Refactor the evaluator.', 'next': 'review'},
        {'id': 'review', 'prompt': 'Review the evaluator.', 'transitions': [
            {'to': 'edit', 'when': {'var': 'steps.review.revise'}}, {'to': None}]}]}
    import_workflow(app, source)
    original = copy.deepcopy(Engine(app).definition('source'))
    job = workflow.specialize(app, {'id': 'source', 'model': model, 'target': 'demo:engine'}, None)
    assert job['inputs']['source_instruction'] == original
    assert job['schema_ref'] == 'metaform:workflow'
    snapshot = capture_model(app, model)
    snapshot['elements']['demo:engine']['description'] = 'Changed after the specialist assignment.'
    publish_foundation(app, snapshot, base=model)
    assert Engine(App(app.project, app.home)).next(job['run_id']) == job
    answer = copy.deepcopy(original)
    answer['steps'][0]['prompt'] = 'Refactor demo:engine while retaining its evaluator EF.'
    answer['steps'][1]['prompt'] = 'Review the choose-network receiving purpose.'
    engine = Engine(app)
    engine.submit(job['run_id'], job['request_id'], answer)
    engine.next(job['run_id'])
    applied = workflow.apply(app, {'run_id': job['run_id'], 'id': 'grounded-review'}, None)
    result = engine.definition(applied['id'])
    assert result['steps'][1]['transitions'] == original['steps'][1]['transitions']
    assert result['model'] == model
    assert engine.definition('source') == original


def test_conversion_keeps_exact_source_and_execution_grammar_with_common_model(app):
    model = foundation(app)
    source = 'Inspect the engine; if the result requires changes, revise and repeat inspection.'
    job = workflow.convert(app, {'source': source, 'model': model, 'target': 'demo:engine'}, None)
    assert job['inputs']['source_instruction'] == source
    assert 'parallel' in job['inputs']['execution_grammar']
    assert job['inputs']['semantic_equations'] == prompts.semantic_equations()
    assert job['inputs']['region']['model'] == model
    assert job['source_prompt'] == prompts.get(app, 'prompt:metaform.workflow.convert')['text']


def test_nonexclusive_job_records_explicit_handle_reads_with_canonical_arguments(app):
    import asyncio
    from metaform.read_model import read_model
    from metaform.registry import Registry

    model = foundation(app)
    job = workflow.convert(app, {'source': 'Inspect the evaluator.', 'model': model, 'target': 'demo:engine'}, None)
    assert not app.binding and not app.get('mode')
    registry = Registry(app)
    found = asyncio.run(registry.call('workflow.search', {'run_id': job['run_id'], 'query': '*'}))
    inspected = asyncio.run(registry.call('workflow.get', {'run_id': job['run_id'], 'id': 'code.evaluator'}))
    expected_search = read_model(app, 'model.search', {'model': model, 'query': ''})
    inspect_args = {'model': model, 'target': 'code.evaluator'}
    assert found == expected_search
    assert inspected == read_model(app, 'type.inspect', inspect_args)
    captured = app.load_run(job['run_id'])
    expected_reads = [expected_search, read_model(app, 'model.inspect', inspect_args), inspected]
    assert captured['semantic_reads'] == [
        {'request_id': job['request_id'], 'result': result} for result in expected_reads
    ]
    assert all(dependency in captured['context_dependencies']
               for result in expected_reads for dependency in result['dependencies'])


def test_repeated_grounding_reuses_context_and_custom_lexicalizer_text(app):
    model = foundation(app)
    source = 'Inspect the engine.'
    args = {'model': model, 'target': 'demo:engine', 'prompt': source}
    first = workflow.lexicalize(app, args, None)
    app.leave()
    identifier = 'prompt:metaform.workflow.lexicalize'
    custom = dict(prompts.get(app, identifier), text='Literal {{ schema }} authored specialization.\n')
    prompts.put(app, custom)
    second = workflow.lexicalize(app, args, None)
    assert first['context_ref'] == second['context_ref']
    assert second['source_prompt'] == custom['text']
    assert second['prompt'].startswith(custom['text'] + '\n\n')


def test_layer_guidance_reaches_specialist_with_origin_and_does_not_change_authored_work(app):
    from metaform.layers import create_layer
    model = foundation(app)
    subject = capture_model(app, model)['artifact']
    engine = Engine(app)
    def finish(job, answer):
        engine.submit(job['run_id'], job['request_id'], answer)
        return engine.next(job['run_id'])
    job = create_layer(app, 'Explain useful evaluator implementation practices.', model=model, target=subject)
    schema = {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:practice', 'type': 'string'}
    plan = {'name': 'Evaluator practices', 'description': 'Useful evaluator practices', 'schema_ref': schema['$id'], 'schema': schema,
            'selector': {'kind': 'subjects', 'targets': [subject]}, 'groups': [{'subjects': [subject], 'purpose': 'Explain applicable practices'}]}
    job = finish(job, plan)
    result = finish(job, {'attachments': [{'subject': subject, 'schema_ref': schema['$id'],
        'payload': 'Consider a review before broad architectural changes.',
        'applicability': {'scope': {'kind': 'direct', 'target': subject}, 'reason': 'Advice for the connectivity evaluator.'}}]})
    source = 'Refactor the connectivity evaluator while preserving its result for the network operator.'
    specialist = workflow.lexicalize(app, {'prompt': source, 'target': subject, 'model': model}, None)
    knowledge = [item for item in specialist['inputs']['region']['records'] if item['ref']['kind'] == 'knowledge']
    assert len(knowledge) == 1
    assert knowledge[0]['explanation']['origin_layer']['id'] == result['layer']['id']
    assert specialist['inputs']['applicable_knowledge'] == [knowledge[0]['ref']]
    finish(specialist, {'instruction': source, 'model': model, 'targets': [subject]})
    applied = workflow.apply(app, {'run_id': specialist['run_id'], 'id': 'requested-refactor'}, None)
    document = engine.definition(applied['id'])
    assert document['steps'][0]['prompt'] == source
    assert len(document['steps']) == 1
    assert document['steps'][0]['transitions'] == []


def test_grounded_sampling_offers_callable_semantic_tools_and_honors_disabled_commands(app):
    import asyncio
    import pytest
    from types import SimpleNamespace
    from mcp import types
    from metaform.mcp_server import Context
    from metaform.registry import Registry
    from metaform.read_model import read_model

    model = foundation(app)
    job = workflow.lexicalize(app, {'model': model, 'target': 'demo:engine', 'prompt': 'Refactor its evaluator.'}, None)
    request = SimpleNamespace(session=SimpleNamespace(client_capabilities=types.ClientCapabilities(sampling=types.SamplingCapability(tools={}))))
    context = Context(app, request)
    advertised = context.prepare(job, 'workflow.answer')['params']['tools']
    assert {tool['name'] for tool in advertised} == set(job['tools'])
    assert 'workflow.ground' in {tool['name'] for tool in advertised}
    registry = Registry(app)
    actual = asyncio.run(registry.call('workflow.ground', {'target': 'demo:engine'}))
    expected = read_model(app, 'model.ground', {'model': model, 'target': 'demo:engine'})
    assert actual == expected
    found = asyncio.run(registry.call('workflow.search', {'query': 'evaluator'}))
    assert any(item['ref']['id'] == 'code.evaluator' for item in found['records'])
    inspected = asyncio.run(registry.call('workflow.get', {'id': 'code.evaluator'}))
    assert inspected['resolved_target']['kind'] == 'type'
    captured = app.load_run(job['run_id'])
    assert captured['semantic_reads'][0]['result'] == expected
    assert captured['context_dependencies']
    engine = Engine(app)
    engine.submit(job['run_id'], job['request_id'], {'instruction': 'Refactor demo:engine.', 'model': model, 'targets': job['targets']})
    engine.next(job['run_id'])
    applied = workflow.apply(app, {'run_id': job['run_id'], 'id': 'with-read-context'}, None)
    task = engine.start(applied['id'])
    assert task['context_reads'][0] == expected
    assert all(item in task['context_dependencies'] for item in captured['context_dependencies'])
    app.set('disabled_commands', ['workflow.ground'])
    assert 'workflow.ground' not in {tool['name'] for tool in context.prepare(job, 'workflow.answer')['params']['tools']}
    with pytest.raises(ValueError, match='Unknown command'):
        asyncio.run(Registry(app).call('workflow.ground', {'target': 'demo:engine'}))
