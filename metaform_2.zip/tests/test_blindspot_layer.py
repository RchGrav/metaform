from test_knowledge_layers import foundation, finish


def test_outside_report_does_not_publish_proposed_actuals(app, foundation):
    from metaform.layers import blindspots, inspect_layer, active_attachments
    from metaform.models import capture_model
    before = capture_model(app, foundation)
    job = blindspots(app, request='What has this account overlooked?', model=foundation)
    assert job['context'] == 'fresh'
    assert job['contract_version'] == '2'
    assert job['inputs']['coarse_account'] == before
    assert 'workflow.read' not in job['tools']
    target = {'owner': 'project:' + app.project_id, 'kind': 'join', 'id': 'join:project-evaluation'}
    report = {'summary': 'The supplied account is coherent.', 'findings': [
        {'id': 'finding:acceptance', 'target': target, 'account': 'No acceptance contract is recorded.',
         'basis': 'The supplied join account.', 'question': 'Does the implementation enforce an acceptance contract?',
         'structural_change': {'proposed_element': 'demo:acceptance'}}]}
    result = finish(app, job, report)
    assert result['status'] == 'complete'
    bundle = inspect_layer(app, result['layer'], foundation)
    assert bundle['attachments'][0]['payload'] == report
    assert len(bundle['attachments']) == 1
    assert bundle['attachments'][0]['target_index'][0]['target'] == target
    assert len(active_attachments(app, foundation)) == 1
    assert capture_model(app, foundation) == before
    assert 'demo:acceptance' not in before['elements']


def test_malformed_report_is_retained_with_annotations(app, foundation):
    from metaform.layers import blindspots, inspect_layer
    from metaform.models import capture_model
    before = capture_model(app, foundation)
    job = blindspots(app, model=foundation)
    result = finish(app, job, {'summary': 42, 'findings': None})
    saved = inspect_layer(app, result['layer'], foundation)
    assert saved['attachments'][0]['payload'] == {'summary': 42, 'findings': None}
    assert saved['attachments'][0]['annotations']
    assert saved['generation']['outputs'][job['request_id']]['annotations']
    assert capture_model(app, foundation) == before


def test_report_generation_through_shared_store(app, tmp_path):
    from metaform.knowledge import BoundGraph, KnowledgeStore
    from metaform.layers import blindspots, list_layers, inspect_layer
    from metaform.models import publish_foundation
    from test_foundation_models import foundation as sample
    store = KnowledgeStore(tmp_path / 'knowledge.sqlite3')
    project_id = store.call(None, 'project.register', {'path': str(app.project)})['project_id']
    seeded = app.global_graph.export()
    app.project_id = project_id
    app.knowledge_mode = 'service'
    app.knowledge = store.bind(project_id)
    app.graph = BoundGraph(app.knowledge, 'project:' + project_id)
    app.global_graph = BoundGraph(app.knowledge, 'global')
    app.global_graph.import_raw(seeded)
    from metaform.prompts import seed
    seed(app)
    model = publish_foundation(app, sample(app))
    result = finish(app, blindspots(app, model=model), {'summary': 'A coherent account.', 'findings': []})
    assert list_layers(app, model)[0]['id'] == result['layer']['id']
    assert inspect_layer(app, result['layer'], model)['attachments'][0]['payload']['summary'] == 'A coherent account.'
