import pytest

from metaform.knowledge import BoundGraph, KnowledgeError, KnowledgeStore, LocalKnowledge
from metaform.backends import JSONGraph
from test_knowledge_contract import element


@pytest.fixture
def store(tmp_path):
    return KnowledgeStore(tmp_path / "knowledge.sqlite3")


def register(store, path):
    return store.call(None, "project.register", {"path": str(path)})["project_id"]


def test_registration_is_idempotent_by_canonical_path(store, tmp_path):
    a = register(store, tmp_path / "A")
    assert register(store, tmp_path / "A" / ".." / "A") == a
    assert store.call(None, "project.list", {})[0]["project_id"] == a
    assert store.call(a, "project.get", {})["path"] == str(tmp_path / "A")


def test_sources_owners_and_receipts_are_independent(store, tmp_path):
    a, b = (register(store, tmp_path / n) for n in ("A", "B"))
    for project, name in ((a, "A"), (b, "B")):
        args = {"owner": "project:" + project, "graph": {"elements": {"X": element(name)}}}
        first = store.call(project, "graph.put", args, "equal-request")
        revision = store.revision
        assert store.call(project, "graph.put", args, "equal-request") == first
        assert store.revision == revision
        with pytest.raises(KnowledgeError, match="request") as error:
            store.call(project, "graph.put", args | {"source": "archaeology"}, "equal-request")
        assert error.value.code == "request_id_conflict"
    store.call(a, "graph.put", {"owner": "global", "graph": {"elements": {"X": element("global")}}})
    rows = store.call(a, "graph.search", {"owners": ["project:" + a, "global"], "scope": "native"})
    assert {(r["owner"], r["entity_desc"]) for r in rows} == {("project:" + a, "A"), ("global", "global")}
    assert store.call(b, "graph.get", {"id": "X"}) == element("B")


def test_unknown_and_cross_project_owners_are_rejected(store, tmp_path):
    a, b = (register(store, tmp_path / n) for n in ("A", "B"))
    with pytest.raises(KnowledgeError) as error:
        store.call("unknown", "graph.get", {"id": "X"})
    assert error.value.code == "unknown_project"
    with pytest.raises(KnowledgeError) as error:
        store.call(a, "graph.put", {"owner": "project:" + b, "graph": {"elements": {"X": element("bad")}}})
    assert error.value.code == "invalid_owner"
    assert store.call(b, "graph.get", {"id": "X"}) is None


def test_transaction_failure_rolls_back_graph_revision_and_receipt(store, tmp_path):
    a = register(store, tmp_path / "A")
    revision = store.revision
    with pytest.raises(RuntimeError):
        with store.transaction():
            store.call(a, "graph.put", {"graph": {"elements": {"X": element("X")}}}, "aborted")
            raise RuntimeError("interrupted")
    assert store.revision == revision
    assert store.call(a, "graph.get", {"id": "X"}) is None
    store.call(a, "graph.put", {"graph": {"elements": {"X": element("different")}}}, "aborted")


def test_memory_graph_inputs_and_read_results_remain_detached():
    import copy
    from metaform.knowledge import _MemoryGraph

    original = {'elements': {'X': element('original')}, 'joins': [], 'observations': []}
    expected = copy.deepcopy(original)
    graph = _MemoryGraph(original)
    original['elements']['X']['entity_json_obj']['changed'] = 'caller mutation'
    assert graph.get('X') == expected['elements']['X']
    result = graph.get('X')
    result['entity_json_obj']['changed'] = 'read mutation'
    exported = graph.export()
    exported['elements']['X']['entity_json_obj']['changed'] = 'export mutation'
    assert graph.export() == expected


def test_bound_graph_and_local_dispatch_preserve_source_edits(store, tmp_path):
    a = register(store, tmp_path / "A")
    local = LocalKnowledge(a, JSONGraph(tmp_path / "project.json"), JSONGraph(tmp_path / "global.json"))
    for knowledge in (local, store.bind(a)):
        graph = BoundGraph(knowledge, "project:" + a)
        for source in ("native", "archaeology"):
            graph.put({"elements": {"X": element(source)}, "joins": [{"id": "same", "type": "relation", "object_id": "X", "element_id": "Y", "purpose": source}]}, source)
        assert graph.get("X", "native") == element("native")
        assert graph.get("X", "archaeology") == element("archaeology")
        assert len(graph.joins()) == 2
        assert len(graph.provenance("X")) == 2
        graph.rename_elements({"X": "Z"})
        assert graph.get("X") is None
        assert graph.get("Z", "native") == element("native")
        assert graph.stats()["elements"] == 1
        assert len(graph.assemble("Z")["joins"]) == 2
        graph.merge_perspectives()
        assert graph.similarity()["joins"]
        graph.clean()
        graph.delete_joins(scope="native")
        assert graph.joins(scope="native") == []


def test_snapshot_and_schema_are_owner_partitioned(store, tmp_path):
    a = register(store, tmp_path / "A")
    store.call(a, "graph.put", {"graph": {"elements": {"X": element("before")}}})
    schema = {"$id": "example", "type": "string"}
    store.call(a, "schema.put", {"owner": "global", "schema": schema})
    snap = store.read_snapshot(a)
    store.call(a, "graph.put", {"graph": {"elements": {"X": element("after")}}})
    assert snap["partitions"]["project:" + a]["elements"]["X"]["entity_desc"] == "before"
    assert snap["schemas"]["global"]["example"] == schema
    assert snap["revision"] < store.revision


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_adoption_preserves_sources_and_originals(store, tmp_path, backend):
    from metaform.backends import open_graph
    from metaform.util import write_json
    project, home = tmp_path / "project", tmp_path / "home"
    suffix = {"sqlite": ".kg", "json": ".json"}[backend]
    write_json(project / ".metaform" / "config.json", {"graph_backend": backend})
    graph = open_graph(project / ".metaform" / ("metaform" + suffix), backend)
    for source in ("native", "archaeology"):
        graph.put({"elements": {"X": element(source)}}, source)
    original = graph.export()
    entry = store.adopt(project, home)
    copied = store.call(entry["project_id"], "graph.export", {})
    assert copied == original
    assert graph.export() == original
    assert (project / ".metaform" / "project.json").exists()


def test_adoption_conflict_rolls_back_without_marker(store, tmp_path):
    project, home = tmp_path / "project", tmp_path / "home"
    from metaform.util import write_json
    write_json(project / ".metaform" / "config.json", {"graph_backend": "json"})
    global_graph = JSONGraph(home / "inference" / "metaform.json")
    global_graph.put({"elements": {"X": element("legacy")}})
    store.call(None, "graph.put", {"owner": "global", "graph": {"elements": {"X": element("existing")}}})
    with pytest.raises(KnowledgeError) as error:
        store.adopt(project, home)
    assert error.value.code == "migration_conflict"
    assert not (project / ".metaform" / "project.json").exists()
    assert store.call(None, "project.list", {}) == []
    assert global_graph.get("X") == element("legacy")


def test_schema_list_and_remote_adoption(store, tmp_path):
    entry = store.call(None, "project.adopt", {"path": str(tmp_path / "P"), "home": str(tmp_path / "home")}, "adopt")
    schema = {"$id": "test:schema", "type": "string"}
    store.call(entry["project_id"], "schema.put", {"owner": "global", "schema": schema})
    assert store.call(entry["project_id"], "schema.list", {"owner": "global"})["test:schema"] == schema
    assert store.call(None, "project.adopt", {"path": str(tmp_path / "P"), "home": str(tmp_path / "home")}, "adopt") == entry


def test_composed_search_retains_owner_variants(store, tmp_path):
    from types import SimpleNamespace
    from metaform.graph import composed_search
    project_id = register(store, tmp_path / "P")
    knowledge = store.bind(project_id)
    for owner in ("project:" + project_id, "global"):
        knowledge.call("graph.put", {"owner": owner, "graph": {"elements": {"X": element(owner)}}})
    app = SimpleNamespace(knowledge=knowledge, project_id=project_id)
    assert len(composed_search(app, "X")) == 2


def test_explicit_foreign_join_refs_survive_source_scoping_and_rename(store, tmp_path):
    a = register(store, tmp_path / "A")
    graph = BoundGraph(store.bind(a), "project:" + a)
    graph.put({"elements": {"X": element("X")}, "joins": [
        {"id": "j", "object_id": "X", "element_id": "Y", "type": "relation"},
        {"id": "higher", "object_id": "j", "element_id": "X", "reference_owners": {"object_id": "global", "element_id": "global"}, "type": "relation", "participants": [{"ref": "j", "owner": "global"}]}
    ]})
    higher = next(j for j in graph.joins() if j["source_id"] == "higher")
    assert higher["object_id"] == "j"
    assert higher["participants"][0]["ref"] == "j"
    graph.rename_elements({"X": "Z"})
    higher = next(j for j in graph.joins() if j["source_id"] == "higher")
    assert higher["element_id"] == "X"


def test_runtime_assembly_crosses_owners_with_scope_and_depth(store, tmp_path):
    a = register(store, tmp_path / "A")
    store.call(a, "graph.put", {"graph": {"elements": {"X": element("local X")}, "joins": [{"id": "local", "object_id": "W", "element_id": "X", "type": "relation"}]}})
    store.call(a, "graph.put", {"owner": "global", "source": "archaeology", "graph": {"elements": {"X": element("global X"), "Y": element("global Y")}, "joins": [{"id": "global", "object_id": "X", "element_id": "Y", "type": "relation"}]}})
    result = store.call(a, "knowledge.assemble", {"focal": "W"})
    assert result["project"]["elements"]["X"]["entity_desc"] == "local X"
    assert result["global"]["elements"]["Y"]["entity_desc"] == "global Y"
    short = store.call(a, "knowledge.assemble", {"focal": "W", "depth": 1})
    assert short["global"]["elements"] == {}
    scoped = store.call(a, "knowledge.assemble", {"focal": "X", "scope": "archaeology"})
    assert scoped["project"]["elements"] == {}
    assert scoped["global"]["elements"]["Y"]["entity_desc"] == "global Y"


def test_local_schema_registration_survives_new_dispatcher(tmp_path):
    local_path, global_path = tmp_path / "P" / ".metaform" / "metaform.json", tmp_path / "home" / "inference" / "metaform.json"
    local = LocalKnowledge("A", JSONGraph(local_path), JSONGraph(global_path))
    for owner in ("project:A", "global"):
        local.call("schema.put", {"owner": owner, "schema": {"$id": owner, "type": "string"}})
    restored = LocalKnowledge("A", JSONGraph(local_path), JSONGraph(global_path))
    assert restored.call("schema.list", {"owner": "global"})["global"] == {"$id": "global", "type": "string"}
    assert restored.call("schema.get", {"owner": "project:A", "id": "project:A"}) == {"$id": "project:A", "type": "string"}


def test_builtin_schemas_available_to_both_snapshot_dispatchers(store, tmp_path):
    a = register(store, tmp_path / "P")
    local = LocalKnowledge(a, JSONGraph(tmp_path / "P" / "metaform.json"), JSONGraph(tmp_path / "home" / "inference" / "metaform.json"))
    local.graphs["project:" + a].put({"elements": {"X": element("X")}})
    store.call(a, "graph.put", {"graph": {"elements": {"X": element("X")}}})
    assert local.read_snapshot()["schemas"]["global"]["metaform:element"]
    assert any(s["id"] == "metaform:element" for s in store.call(a, "knowledge.snapshot", {})["schemas"])


def test_explicit_new_copy_clones_service_partition_and_translates_self_owner(store, tmp_path):
    from metaform.util import read_json, write_json
    original = store.adopt(tmp_path / "original", tmp_path / "home")
    old_owner = "project:" + original["project_id"]
    store.call(original["project_id"], "graph.put", {"graph": {"elements": {"X": element("original")}, "joins": [{"id": "self", "object_id": "X", "element_id": "X", "reference_owners": {"object_id": old_owner}, "participants": [{"ref": "X", "owner": old_owner}], "type": "relation"}]}})
    before = store.call(original["project_id"], "graph.export", {})
    copied = tmp_path / "copy"
    write_json(copied / ".metaform" / "project.json", read_json(tmp_path / "original" / ".metaform" / "project.json"))
    result = store.adopt(copied, tmp_path / "home", new_copy=True)
    new_owner = "project:" + result["project_id"]
    graph = store.call(result["project_id"], "graph.export", {})
    assert graph["elements"] == before["elements"]
    assert graph["observations"] == before["observations"]
    assert graph["joins"][0]["id"] == before["joins"][0]["id"]
    assert graph["joins"][0]["participants"][0]["owner"] == new_owner
    assert graph["joins"][0]["reference_owners"]["object_id"] == new_owner
    assert store.call(original["project_id"], "graph.export", {}) == before
    assert read_json(copied / ".metaform" / "project.json")["origin_project_id"] == original["project_id"]


def test_portable_snapshot_holds_both_json_stores_until_capture(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event
    project_graph, global_graph = JSONGraph(tmp_path / "P" / "metaform.json"), JSONGraph(tmp_path / "home" / "inference" / "metaform.json")
    local = LocalKnowledge("A", project_graph, global_graph)
    global_graph.put({"elements": {"X": element("before")}})
    started, writer_done = Event(), Event()
    original_export = project_graph.export
    def export(scope=None):
        started.set()
        assert not writer_done.wait(.05)
        return original_export(scope)
    project_graph.export = export
    def write():
        started.wait()
        global_graph.put({"elements": {"X": element("after")}})
        writer_done.set()
    with ThreadPoolExecutor(2) as executor:
        writer = executor.submit(write)
        capture = local.read_snapshot()
        writer.result()
    assert capture["partitions"]["global"]["elements"]["X"]["entity_desc"] == "before"
    assert global_graph.get("X") == element("after")


@pytest.mark.parametrize("operation", ["open", "adopt"])
def test_retired_backend_does_not_modify_or_replace_existing_storage(store, tmp_path, operation):
    from metaform.app import App
    from metaform.util import write_json

    project, home = tmp_path / "project", tmp_path / "home"
    config = project / ".metaform" / "config.json"
    write_json(config, {"knowledge_mode": "legacy", "graph_backend": "ladybug", "auto_build": False})
    project_store = config.parent / "metaform.lbdb"
    project_store.write_bytes(b"Retained retired project storage\x00\xff")
    global_store = home / "inference" / "metaform.lbdb"
    global_store.parent.mkdir(parents=True)
    global_store.write_bytes(b"Retained retired global storage\x00\xfe")
    original = {path: path.read_bytes() for path in (config, project_store, global_store)}

    with pytest.raises(ValueError, match="Unknown graph backend"):
        if operation == "open":
            App(project, home, binding=False)
        else:
            store.adopt(project, home)

    assert {path: path.read_bytes() for path in original} == original
    assert not (config.parent / "project.json").exists()
    for directory in (config.parent, global_store.parent):
        assert not (directory / "metaform.kg").exists()
        assert not (directory / "metaform.json").exists()
