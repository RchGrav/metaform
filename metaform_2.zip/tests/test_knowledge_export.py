import copy

from metaform.knowledge_export import (
    DictionarySnapshot,
    execution_dependencies,
    project_closure,
    selected_digest,
)


def element(name):
    return {"entity_desc": name, "entity_schema": "metaform:element", "entity_json_obj": {"en": name}}


def graph(elements=(), joins=(), observations=()):
    return {"elements": {name: element(name) for name in elements}, "joins": list(joins), "observations": list(observations)}


def join(identifier, left, right, **extra):
    return {"id": identifier, "object_id": left, "element_id": right, "type": "relationship", "join_scope": "authored", **extra}


def fixture():
    return {"revision": 12, "partitions": {
        "project:A": graph(["W", "L"], [join("a0", "W", "X"), join("a1", "Z", "L", join_scope="archaeology")]),
        "global": graph(["X", "Y", "Z", "rule", "unused"], [join("g1", "X", "Y"), join("g2", "Y", "Z", join_scope="archaeology")]),
        "project:B": graph(["Q"], [join("b1", "X", "Q")]),
    }}


def test_owner_aware_closure_preserves_whole_reified_joins_and_missing_references():
    capture = fixture()
    capture["partitions"]["global"]["joins"] += [
        join("g3", "g1", "g4", participants=[{"role": "condition", "ref": "rule"}, {"role": "unknown", "ref": "missing"}, {"role": "literal", "value": "unused"}], logic={"and": [True, False]}),
        join("g4", "g3", "Z"),
        join("private", "Y", "Q", reference_owners={"element_id": "project:B"}),
    ]
    result = project_closure(DictionarySnapshot(capture), "A", [])
    assert set(result["global"]["elements"]) == {"X", "Y", "Z", "rule"}
    assert set(result["project"]["elements"]) == {"W", "L"}
    assert {j["id"] for j in result["global"]["joins"]} == {"g1", "g2", "g3", "g4", "private"}
    assert next(j for j in result["global"]["joins"] if j["id"] == "g3") == capture["partitions"]["global"]["joins"][2]
    assert any(u["ref"] == "missing" and u["field"] == "participants[1].ref" and u["reason"] == "missing" for u in result["unresolved"])
    assert any(u["ref"] == "Q" and u["requested_owner"] == "project:B" and u["reason"] == "outside_project" for u in result["unresolved"])


def test_absent_element_body_still_discovers_incident_joins():
    capture = fixture()
    del capture["partitions"]["global"]["elements"]["X"]
    capture["partitions"]["project:A"]["joins"] = [join("a0", "W", "X")]
    capture["partitions"]["project:A"]["elements"].pop("L")
    result = project_closure(capture, "A", [])
    assert set(result["global"]["elements"]) == {"Y", "Z"}
    assert any(u["ref"] == "X" and u["reason"] == "missing" for u in result["unresolved"])


def test_equal_join_ids_do_not_alias_and_explicit_private_refs_do_not_bridge():
    capture = {"revision": 1, "partitions": {
        "project:A": graph(["W"], [join("same", "W", "X")]),
        "global": graph(["X", "secret", "foreign"], [join("same", "secret", "secret"), join("reified", "same", "secret"), join("private-address", "W", "foreign", reference_owners={"object_id": "project:B"})]),
    }}
    result = project_closure(capture, "A", [])
    assert set(result["global"]["elements"]) == {"X"}
    assert result["global"]["joins"] == []
    capture["partitions"]["project:A"]["joins"].append(join("explicit", "W", "same", reference_owners={"element_id": "global"}))
    result = project_closure(capture, "A", [])
    assert {j["id"] for j in result["global"]["joins"]} == {"same", "reified"}


def test_similarity_is_excluded_before_reified_incidence():
    capture = {"revision": 1, "partitions": {
        "project:A": graph(["W"], [join("a", "W", "X")]),
        "global": graph(["X", "unrelated"], [join("similarity:old", "X", "X", join_scope="merged", schema_id="metaform:merged-join"), join("leak", "similarity:old", "unrelated")]),
    }}
    result = project_closure(capture, "A", [])
    assert set(result["global"]["elements"]) == {"X"}
    assert result["global"]["joins"] == []


def completion(identifier, created, members, joins):
    return {"id": identifier, "element_id": "X", "source": "archaeology-complete", "created": created, "record": {**element("X snapshot"), "inference": {"elements": {name: element(name + " captured") for name in members}, "joins": joins}}}


def test_latest_snapshot_members_seed_current_closure_older_evidence_is_separate():
    old = completion("old", "1", ["X", "O"], [join("old-only", "X", "O")])
    latest = completion("latest", "2", ["X", "Y", "captured-only"], [join("snapshot-only", "X", "Y", participants=[{"role": "rule", "ref": "historical-rule"}])])
    capture = {"revision": 3, "partitions": {
        "project:A": graph(["W"], [join("a", "W", "X")]),
        "global": graph(["X", "Y", "Z", "O", "not-current", "historical-rule"], [join("current", "Y", "Z"), join("historical-neighbor", "O", "not-current")], [old, latest]),
    }}
    result = project_closure(capture, "A", [])
    assert set(result["global"]["elements"]) == {"X", "Y", "Z", "historical-rule"}
    assert [j["id"] for j in result["global"]["joins"]] == ["current"]
    assert result["global"]["observations"] == [old, latest]
    dependencies = result["archive_dependencies"]
    assert any(d["id"] == "O" and d["owner"] == "global" for d in dependencies)
    assert any(d["id"] == "captured-only" and d["body"]["entity_desc"] == "captured-only captured" for d in dependencies)
    assert not any(d["id"] == "not-current" for d in dependencies)
    assert result["global"]["elements"]["Y"]["entity_desc"] == "Y"


def test_long_reified_cycle_terminates_without_depth_limit():
    joins = [join(f"j{i}", "X" if i == 0 else f"j{i - 1}", f"j{(i + 1) % 1100}") for i in range(1100)]
    result = project_closure({"revision": 1, "partitions": {"project:A": graph(["X"]), "global": graph([], joins)}}, "A", [])
    assert len(result["global"]["joins"]) == 1100
    assert len({j["id"] for j in result["global"]["joins"]}) == 1100


def test_snapshot_is_coherent_and_digest_excludes_unrelated_revisions_but_keeps_provenance():
    capture = fixture()
    captured = DictionarySnapshot(capture)
    capture["revision"] = 13
    capture["partitions"]["global"]["joins"].append(join("later", "X", "unused"))
    before = project_closure(captured, "A", [])
    after = project_closure(capture, "A", [])
    assert before["revision"] == 12
    assert "unused" not in before["global"]["elements"]
    assert "unused" in after["global"]["elements"]
    unrelated = fixture()
    unrelated["revision"] = 99
    unrelated["partitions"]["global"]["elements"]["disconnected"] = element("disconnected")
    assert selected_digest(before) == selected_digest(project_closure(unrelated, "A", []))
    unrelated["partitions"]["global"]["observations"].append({"id": "provenance", "element_id": "Y", "source": "native", "created": "today", "record": element("another source")})
    assert selected_digest(before) != selected_digest(project_closure(unrelated, "A", []))


def test_typed_execution_dependencies_follow_workflow_forms_without_scanning_prose():
    run = {"workflow": "outer", "stack": [{"workflow": "outer", "definition": {"steps": [
        {"id": "call", "kind": "call", "workflow": "child"},
        {"id": "parallel", "kind": "parallel", "branches": ["one", {"workflow": "two"}, {"steps": [{"id": "embedded", "kind": "call", "workflow": "three"}]}]},
        {"id": "prompt", "prompt_ref": "prompt:chosen", "rule_codes": ["ABC"], "schema": "schema:answer", "focal": "X", "prompt": "prose mentions workflow:unrelated", "transitions": [{"to": "end", "rule": "condition"}]},
    ]}}], "pending": {"prompt_ref": "prompt:prepared", "schema": {"$ref": "schema:recursive"}}, "assignments": {"a": {"focal": "assigned"}}}
    refs = {(d["kind"], d["ref"]) for d in execution_dependencies(run)}
    assert {("element", "workflow:outer"), ("element", "workflow:child"), ("element", "workflow:one"), ("element", "workflow:two"), ("element", "workflow:three"), ("element", "prompt:chosen"), ("element", "rule:ABC"), ("element", "X"), ("element", "condition"), ("element", "prompt:prepared"), ("element", "assigned"), ("schema", "schema:answer"), ("schema", "schema:recursive")} <= refs
    assert all(ref != "workflow:unrelated" for _, ref in refs)


def test_recursive_schema_selection_and_digest_relocation_across_assignments_and_frames():
    capture = fixture()
    capture["schemas"] = {"global": {"metaform:element": {"$ref": "schema:common"}, "schema:common": {"type": "object"}, "unused": {"type": "integer"}}}
    result = project_closure(capture, "A", [])
    assert {d["id"] for d in result["schemas"]} == {"metaform:element", "schema:common"}
    runs = [{"id": "run", "pending": {"nonce": "one", "begin": "metaform begin one", "workfolder": "/original/home/work"}, "assignments": {"a": {"nonce": "two", "workfolder": "/original/project/work"}}, "stack": [{"definition": {"base_dir": "/original/project/procedure"}}]}]
    moved = copy.deepcopy(runs)
    moved[0]["pending"].update(nonce="new", begin="metaform begin new", workfolder="/new/home/work")
    moved[0]["assignments"]["a"].update(nonce="newer", workfolder="/new/project/work")
    moved[0]["stack"][0]["definition"]["base_dir"] = "/new/project/procedure"
    assert selected_digest(result, runs, home="/original/home", project="/original/project") == selected_digest(result, moved, home="/new/home", project="/new/project")


def test_actual_intake_assignment_and_prepared_graph_seed_executable_members():
    refs = execution_dependencies({"pending": {"role": "latent_expert", "inputs": {"id": "focal", "object": element("focal")}, "rules": [{"revision": "saved", "content": {"rule_code": "SNAPSHOT"}}]}, "assignments": {"work": {"graph": {"elements": {"prepared": element("prepared")}, "joins": [join("captured", "prepared", "related")]}}}})
    pairs = {(r["kind"], r["ref"]) for r in refs}
    assert {("element", "focal"), ("element", "prepared"), ("element", "related"), ("element", "rule:SNAPSHOT"), ("schema", "metaform:element")} <= pairs


def test_registered_schema_without_id_follows_nested_refs():
    capture = fixture()
    capture["schemas"] = {"global": {"metaform:element": {"type": "object", "properties": {"name": {"$ref": "schema:leaf#/$defs/name"}}}, "schema:leaf": {"$defs": {"name": {"type": "string"}}}}}
    assert {d["id"] for d in project_closure(capture, "A")["schemas"]} == {"metaform:element", "schema:leaf"}


def test_latest_reified_snapshot_reference_discovers_current_incident_join():
    latest = completion("latest", "2", ["X"], [join("retired", "X", "X"), join("snapshot-link", "retired", "X")])
    capture = {"revision": 1, "partitions": {"project:A": graph(["X"]), "global": graph(["X", "Y"], [join("current-reference", "retired", "Y", participants=[{"role": "retired", "ref": "retired", "kind": "join"}])], [latest])}}
    result = project_closure(capture, "A")
    assert "Y" in result["global"]["elements"]
    assert [j["id"] for j in result["global"]["joins"]] == ["current-reference"]


def test_schema_provenance_retains_each_selecting_record():
    capture = fixture()
    capture["schemas"] = {"global": {"metaform:element": {"type": "object"}}}
    schema = project_closure(capture, "A")["schemas"][0]
    assert {p["id"] for p in schema["provenance"]} >= {"W", "L", "X", "Y", "Z"}


def test_digest_preserves_opaque_answer_nonce_and_pre_normalized_runs():
    snapshot = project_closure(fixture(), "A")
    original = [{"id": "run", "pending": {"nonce": "job"}, "answer": {"nonce": "authored", "begin": "authored beginning"}}]
    changed = copy.deepcopy(original)
    changed[0]["answer"]["nonce"] = "different meaning"
    assert selected_digest(snapshot, original, home="/home/a") != selected_digest(snapshot, changed, home="/home/a")
    changed = copy.deepcopy(original)
    changed[0]["pending"]["nonce"] = "different stored input"
    assert selected_digest(snapshot, original) != selected_digest(snapshot, changed)


def test_reified_snapshot_archive_resolves_captured_join_kind_without_false_missing():
    latest = completion("latest", "2", ["X"], [join("retired", "X", "X"), join("snapshot-link", "retired", "X")])
    capture = {"revision": 1, "partitions": {"project:A": graph(["X"], [], [latest])}}
    result = project_closure(capture, "A")
    assert not any(u["from"]["kind"] == "observation" and u["ref"] == "retired" for u in result["unresolved"])


def test_sqlite_and_portable_json_produce_identical_selected_source_and_dependencies(tmp_path):
    from metaform.backends import JSONGraph
    from metaform.knowledge import BoundGraph, KnowledgeStore, LocalKnowledge

    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    owner = "project:" + identifier
    capture = fixture()
    capture["partitions"][owner] = capture["partitions"].pop("project:A")
    capture["partitions"]["global"]["observations"] = [completion("saved", "now", ["X", "Y"], [join("snapshot-only", "X", "Y")])]
    for partition in capture["partitions"].values():
        for body in partition["elements"].values():
            body["layer"] = "elements"
    portable = LocalKnowledge(identifier, JSONGraph(tmp_path / "project.json"), JSONGraph(tmp_path / "global.json"))
    for knowledge in (store.bind(identifier), portable):
        for selected_owner in (owner, "global"):
            BoundGraph(knowledge, selected_owner).import_raw(capture["partitions"][selected_owner])
        knowledge.call("schema.put", {"owner": "global", "schema": {"$id": "metaform:element", "type": "object"}})
    connected = store.call(identifier, "knowledge.snapshot", {"execution_roots": []})
    standalone = portable.call("knowledge.snapshot", {"execution_roots": []})
    assert {k: v for k, v in connected.items() if k != "revision"} == {k: v for k, v in standalone.items() if k != "revision"}
    assert selected_digest(connected) == selected_digest(standalone)


def test_writer_committing_after_capture_cannot_change_in_progress_closure(tmp_path):
    from metaform.knowledge import KnowledgeStore

    path = tmp_path / "knowledge.sqlite3"
    store, writer = KnowledgeStore(path), KnowledgeStore(path)
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    store.call(identifier, "graph.import", {"graph": graph(["X"])})
    store.call(identifier, "graph.import", {"owner": "global", "graph": graph(["X", "Y"], [join("before", "X", "Y")])})
    capture = store.read_snapshot(identifier)

    class InterleavedSnapshot(DictionarySnapshot):
        def record(self, key):
            value = super().record(key)
            if getattr(self, "write_on_read", False):
                self.write_on_read = False
                writer.call(identifier, "graph.put", {"owner": "global", "source": "authored", "graph": {"elements": {"N": element("N")}, "joins": [join("after", "X", "N")]}})
            return value

    snapshot = InterleavedSnapshot(capture)
    snapshot.write_on_read = True
    before = project_closure(snapshot, identifier)
    after = store.call(identifier, "knowledge.snapshot", {})
    assert before["revision"] == capture["revision"] < after["revision"]
    assert set(before["global"]["elements"]) == {"X", "Y"}
    assert set(after["global"]["elements"]) == {"X", "Y", "N"}


def test_sql_reader_matches_dictionary_closure_and_avoids_unrelated_global_scan(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.knowledge_export import SqlKnowledgeSnapshot

    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    store.call(identifier, "graph.import", {"graph": graph(["X"])})
    global_graph = graph(["X", "Y"] + [f"unrelated-{i}" for i in range(10000)], [join("included", "X", "Y")])
    store.call(identifier, "graph.import", {"owner": "global", "graph": global_graph})
    expected = project_closure(store.read_snapshot(identifier), identifier)
    with store.transaction(False) as db:
        revision = store.revision
        reader = SqlKnowledgeSnapshot(db, identifier, revision)
        # A 10,000-row global scan cannot fit this VM-operation allowance; the
        # selected two-node component can. This exercises actual SQLite work.
        callbacks = 0
        def budget():
            nonlocal callbacks
            callbacks += 1
            return callbacks > 100
        db.set_progress_handler(budget, 100)
        actual = project_closure(reader, identifier)
        db.set_progress_handler(None, 0)
    assert actual == expected
    assert set(actual["global"]["elements"]) == {"X", "Y"}


def test_sql_reader_keeps_revision_while_another_writer_commits(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.knowledge_export import SqlKnowledgeSnapshot

    path = tmp_path / "knowledge.sqlite3"
    store, writer = KnowledgeStore(path), KnowledgeStore(path)
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    store.call(identifier, "graph.import", {"graph": graph(["X"])})
    store.call(identifier, "graph.import", {"owner": "global", "graph": graph(["X", "Y"], [join("before", "X", "Y")])})
    with store.transaction(False) as db:
        reader = SqlKnowledgeSnapshot(db, identifier, store.revision)
        writer.call(identifier, "graph.put", {"owner": "global", "source": "authored", "graph": {"elements": {"N": element("N")}, "joins": [join("after", "X", "N")]}})
        before = project_closure(reader, identifier)
    after = store.call(identifier, "knowledge.snapshot", {})
    assert before["revision"] < after["revision"]
    assert set(before["global"]["elements"]) == {"X", "Y"}
    assert set(after["global"]["elements"]) == {"X", "Y", "N"}


def test_sql_and_dictionary_match_missing_owner_variants_and_reified_cycles(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.knowledge_export import SqlKnowledgeSnapshot

    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    local = graph(["W"], [join("same", "W", "missing-X")])
    shared = graph(["Y", "rule", "outside"], [
        join("ordinary", "missing-X", "Y"),
        join("same", "outside", "outside"),
        join("g3", "ordinary", "g4", participants=[{"role": "rule", "ref": "rule"}, {"role": "missing", "ref": "not-found"}]),
        join("g4", "g3", "Y"),
        join("foreign", "Y", "W", reference_owners={"element_id": "project:B"}),
        join("similarity:ignored", "Y", "Y", join_scope="merged"),
        join("would-leak", "similarity:ignored", "outside"),
    ])
    for owner, data in (("project:" + identifier, local), ("global", shared)):
        store.call(identifier, "graph.import", {"owner": owner, "graph": data})
    expected = project_closure(store.read_snapshot(identifier), identifier)
    with store.transaction(False) as db:
        result = project_closure(SqlKnowledgeSnapshot(db, identifier, store.revision), identifier)
    assert result == expected
    assert set(result["global"]["elements"]) == {"Y", "rule"}
    assert {j["id"] for j in result["global"]["joins"]} == {"ordinary", "g3", "g4", "foreign"}
    assert any(u["ref"] == "missing-X" and u["reason"] == "missing" for u in result["unresolved"])


def test_sql_module_manifest_metadata_expands_only_referenced_modules(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.knowledge_export import SqlKnowledgeSnapshot

    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    store.call(identifier, "graph.import", {"graph": graph(["W"], [join("attachment", "W", "workflow:shared")])})
    shared = graph(["workflow:shared", "chosen", "unused"])
    shared["elements"]["workflow:shared"] = {"entity_desc": "Shared", "entity_schema": "metaform:workflow", "entity_json_obj": {"steps": [{"id": "work", "module": "selected"}]}}
    store.call(identifier, "graph.import", {"owner": "global", "graph": shared})
    manifests = {"global": {"module:selected": {"id": "selected", "portable": {"knowledge_refs": ["chosen"]}}, "module:unrelated": {"id": "unrelated", "portable": {"knowledge_refs": ["unused"]}}}}
    capture = store.read_snapshot(identifier)
    capture["runtime_assets"] = manifests
    expected = project_closure(capture, identifier)
    with store.transaction(False) as db:
        result = project_closure(SqlKnowledgeSnapshot(db, identifier, store.revision, runtime_assets=manifests), identifier)
    assert result == expected
    assert set(result["global"]["elements"]) == {"workflow:shared", "chosen"}
    assert {asset["id"] for asset in result["runtime_assets"]} == {"module:selected"}


def test_sql_schema_fallback_is_selected_recursively_and_registered_body_wins(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.knowledge_export import SqlKnowledgeSnapshot

    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    identifier = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    store.call(identifier, "graph.import", {"graph": graph(["X"])})
    registered = {"$id": "metaform:element", "$ref": "schema:leaf"}
    store.call(identifier, "schema.put", {"owner": "global", "schema": registered})
    fallback = {"global": {"metaform:element": {"type": "wrong"}, "schema:leaf": {"type": "object"}, "unrelated": {"type": "string"}}}
    with store.transaction(False) as db:
        result = project_closure(SqlKnowledgeSnapshot(db, identifier, store.revision, schemas=fallback), identifier)
    bodies = {item["id"]: item["body"] for item in result["schemas"]}
    assert bodies == {"metaform:element": registered, "schema:leaf": {"type": "object"}}


def test_digest_does_not_relocate_paths_or_job_shaped_data_inside_answers():
    snapshot = project_closure(fixture(), "A")
    original = [{"id": "run", "answer": {"path": "/old/home/artifact", "pending": {"nonce": "first"}}}]
    different = copy.deepcopy(original)
    different[0]["answer"]["pending"]["nonce"] = "second"
    assert selected_digest(snapshot, original, home="/old/home") != selected_digest(snapshot, different, home="/old/home")
    different = copy.deepcopy(original)
    different[0]["answer"]["path"] = "/new/home/artifact"
    assert selected_digest(snapshot, original, home="/old/home") != selected_digest(snapshot, different, home="/new/home")


def test_snapshot_join_collision_preserves_explicit_reference_owner_and_kind():
    cases = [
        ({"owner": "global"}, "global"),
        ({"kind": "element"}, "global"),
        ({"owner": "global", "kind": "element"}, "global"),
        ({"owner": "project:A", "kind": "element"}, "project:A"),
    ]
    for qualification, target_owner in cases:
        latest = completion("latest", "2", ["X"], [
            join("j", "X", "X"),
            join("snapshot-link", "X", "X", participants=[{"role": "subject", "ref": "j", **qualification}]),
        ])
        capture = {"revision": 1, "partitions": {
            "project:A": graph(["X"], [], [latest]),
            "global": graph(),
        }}
        capture["partitions"][target_owner]["elements"].update({"j": element("j"), "Z": element("Z")})
        capture["partitions"][target_owner]["joins"].append(join("current", "j", "Z"))
        result = project_closure(capture, "A")
        selected = result["global"] if target_owner == "global" else result["project"]
        assert {"j", "Z"} <= set(selected["elements"]), qualification
        assert any(body["id"] == "current" for body in selected["joins"]), qualification
        assert not any(u["ref"] == "j" for u in result["unresolved"]), qualification


def test_tool_command_metadata_selects_exact_dotted_module_and_knowledge():
    capture = {"revision": 1, "partitions": {"project:A": graph(["W"]), "global": graph(["chosen", "unrelated"])} ,
               "runtime_assets": {"global": {
                   "command:custom.module.run": {"module": "custom.module"},
                   "module:custom.module": {"id": "custom.module", "portable": {"knowledge_refs": ["chosen"]}},
                   "module:custom": {"id": "custom", "portable": {"knowledge_refs": ["unrelated"]}},
               }}}
    roots = execution_dependencies({"stack": [{"definition": {"steps": [{"id": "call", "kind": "tool", "tool": "custom.module.run"}]}}]})
    result = project_closure(capture, "A", roots)
    assert set(result["global"]["elements"]) == {"chosen"}
    assert {asset["id"] for asset in result["runtime_assets"]} == {"command:custom.module.run", "module:custom.module"}
    assert not result["unresolved"] or all(issue["ref"] == "metaform:element" for issue in result["unresolved"])


def test_retained_job_tool_capabilities_select_handlers_without_scanning_answers():
    capture = {"revision": 1, "partitions": {"project:A": graph(["W"]), "global": graph(["chosen", "unused"])} ,
               "runtime_assets": {"global": {
                   "command:custom.module.inspect": {"module": "custom.module"},
                   "module:custom.module": {"id": "custom.module", "portable": {"knowledge_refs": ["chosen"]}},
                   "command:unused.run": {"module": "unused"},
                   "module:unused": {"id": "unused", "portable": {"knowledge_refs": ["unused"]}},
               }}}
    run = {"id": "run", "pending": {"run_id": "run", "request_id": "job", "tools": ["custom.module.inspect"]},
           "answer": {"tools": ["unused.run"]}, "result": {"tools": ["unused.run"]}}
    result = project_closure(capture, "A", execution_dependencies(run))
    assert set(result["global"]["elements"]) == {"chosen"}
    assert {asset["id"] for asset in result["runtime_assets"]} == {"command:custom.module.inspect", "module:custom.module"}
