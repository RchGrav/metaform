"""Historical v1 assignment contracts remain resumable after the v2 transition."""
import asyncio
import sys
from pathlib import Path

from metaform import harness
from metaform.intake import Intake
from metaform.modules import intake


def elements():
    return {
        identifier: {
            "entity_desc": name,
            "entity_schema": "metaform:element",
            "entity_json_obj": {"en": name},
        }
        for identifier, name in [("code", "Program code"), ("code.cpp", "C++ program code")]
    }


def test_default_drive_examines_whole_native_graph_once(app, monkeypatch):
    graph = {"elements": elements(), "joins": [{
        "object_id": "code", "element_id": "code.cpp", "type": "receiving_entity",
        "purpose": "Compile this project's engine with its required language medium",
    }], "description": "A concrete engine project"}
    roles = []
    folders = []

    async def execute(scoped_app, job, name):
        roles.append(job["role"])
        if job["role"] == "native_expert":
            return {"status": "answered", "answer": graph}
        assert job["role"] == "latent_expert"
        for identifier, record in graph["elements"].items():
            assert job["inputs"]["native"]["elements"][identifier].items() >= record.items()
        assert job["inputs"]["native"]["joins"][0]["purpose"] == graph["joins"][0]["purpose"]
        assert job["inputs"]["native"]["description"] == graph["description"]
        assert job["system_prompt"]
        assert job["context"] == "fresh"
        assert "intake.read" not in job["tools"]
        folders.append(Path(job["workfolder"]))
        assert folders[-1].is_dir()
        return {"status": "answered", "answer": {"elements": {
            "code.additional": {"entity_desc": "A missing capability", "entity_schema": "metaform:element", "entity_json_obj": {}},
        }, "joins": []}}

    monkeypatch.setattr(harness, "execute", execute)
    native = Intake(app)._start("native")
    result = asyncio.run(intake.drive(app, {
        "run_id": native["run_id"], "harness": "fixture", "concurrency": 4,
    }, None))
    assert result["status"] == "complete"
    assert roles == ["native_expert", "latent_expert"]
    assert all(not folder.exists() for folder in folders)
    assert app.graph.get("code.additional", scope="archaeology") is not None


def test_abort_cleans_idle_latent_folder(app):
    job = Intake(app)._start("archaeology")
    assert Path(job["workfolder"]).is_dir()
    app.abort()
    assert app.load_run(job["run_id"])["status"] == "aborted"
    assert app.get("mode") is None
    assert not Path(job["workfolder"]).exists()
    with app.db() as db:
        assert db.execute("SELECT count(*) FROM workfolders").fetchone()[0] == 0


def test_abort_terminates_latent_harness_and_cleans_its_folder(app, tmp_path):
    async def scenario():
        job = Intake(app)._start("archaeology")
        script = tmp_path / "wait_for_abort.py"
        script.write_text("import time\ntime.sleep(30)\n")
        app.config["harnesses"] = {"fixture": {"command": [sys.executable, str(script)]}}
        task = asyncio.create_task(intake.drive(app, {
            "run_id": job["run_id"], "harness": "fixture",
        }, None))
        try:
            async with asyncio.timeout(5):
                while not app.get("executing:" + job["request_id"]):
                    await asyncio.sleep(0.02)
            app.abort()
            result = await asyncio.wait_for(task, 5)
            assert result["status"] == "aborted"
            assert app.load_run(job["run_id"])["status"] == "aborted"
            assert app.get("mode") is None
            assert not app.get("executing:" + job["request_id"])
            assert not Path(job["workfolder"]).exists()
            with app.db() as db:
                assert db.execute("SELECT count(*) FROM workfolders").fetchone()[0] == 0
        finally:
            if not task.done():
                app.abort()
                await asyncio.wait_for(task, 5)

    asyncio.run(scenario())
