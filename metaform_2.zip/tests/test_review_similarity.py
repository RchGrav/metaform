"""Regressions for owner-qualified structure and duplicate correspondence cost."""
import json
from itertools import combinations, permutations
import os
from pathlib import Path
import random
import subprocess
import sys

import pytest

from metaform.backends import JSONGraph
from metaform.app import App
from metaform.knowledge import KnowledgeStore, LocalKnowledge
from metaform.modules import graph as graph_module
from metaform.similarity import compare
from metaform.util import write_json


@pytest.fixture(params=[("portable", "json"), ("legacy", "json"), ("legacy", "sqlite")])
def local_app(tmp_path, request):
    mode, backend = request.param
    project = tmp_path / "project"
    write_json(project / ".metaform/config.json", {"knowledge_mode": mode, "graph_backend": backend})
    return App(project, tmp_path / "home", binding=False)


@pytest.mark.parametrize("operation", ["similarity", "merge_perspectives", "clean"])
def test_raw_app_graph_resolves_qualified_joins_before_knowledge_access(local_app, operation):
    owner = "project:" + local_app.project_id
    for graph in [local_app.graph, local_app.global_graph]:
        graph.put({"joins": [{"id": "j", "type": "authored-relation"}]}, "authored")
    for source, target in [("native", "global"), ("archaeology", owner)]:
        local_app.graph.put({"joins": [{"id": source, "type": "evidence", "participants": [
            {"role": "relationship", "ref": "j", "owner": target},
        ]}]}, source)
    before = {source: local_app.graph.export(source) for source in ["native", "archaeology"]}
    if operation == "similarity":
        view = graph_module.similarity(local_app, {}, None)
    else:
        if operation == "clean":
            graph_module.clean(local_app, {}, None)
        else:
            local_app.graph.merge_perspectives()
        view = {"joins": local_app.graph.joins(scope="merged")}
    assert sorted(j["membership"] for j in view["joins"]) == ["01", "10"]
    assert {p["owner"] for j in view["joins"] for p in j["participants"]} == {"global", owner}
    assert all(p["kind"] == "join" for j in view["joins"] for p in j["participants"])
    assert local_app.graph.similarity()["elements"] == {}
    assert {source: local_app.graph.export(source) for source in before} == before


@pytest.mark.parametrize("operation", ["similarity", "merge_perspectives", "clean"])
def test_raw_app_similarity_resolves_writes_after_previous_knowledge_call(local_app, operation):
    assert local_app.knowledge.call("graph.similarity", {})["joins"] == []
    local_app.global_graph.put({"joins": [{"id": "later", "type": "authored-relation"}]}, "authored")
    for source in ["native", "archaeology"]:
        local_app.graph.put({"joins": [{"id": source, "type": "evidence", "participants": [
            {"role": "relationship", "ref": "later", "owner": "global"},
        ]}]}, source)
    if operation == "similarity":
        view = graph_module.similarity(local_app, {}, None)
    else:
        getattr(local_app.graph, operation)()
        view = {"joins": local_app.graph.joins(scope="merged")}
    assert [j["membership"] for j in view["joins"]] == ["11"]
    assert view["joins"][0]["participants"] == [
        {"role": "relationship", "ref": "later", "owner": "global", "kind": "join"},
    ]
    assert local_app.graph.similarity()["elements"] == {}


@pytest.mark.parametrize("kind", ["join", None])
@pytest.mark.parametrize("same_owner", [False, True])
@pytest.mark.parametrize("mode", ["service", "portable"])
def test_similarity_resolves_external_join_owner_without_fabricating_elements(tmp_path, kind, same_owner, mode):
    if mode == "service":
        store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
        project = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
        knowledge = store.bind(project)
    else:
        project = "p"
        knowledge = LocalKnowledge(project, JSONGraph(tmp_path / "project/graph.json"),
                                   JSONGraph(tmp_path / "home/inference/graph.json"))
    owner = "project:" + project
    for target, relation in [("global", "global-relation"), (owner, "local-relation")]:
        knowledge.call("graph.put", {"owner": target, "source": "authored", "graph": {
            "joins": [{"id": "j", "type": relation}],
        }})
    for source, target in [("native", "global"), ("archaeology", "global" if same_owner else owner)]:
        participant = {"role": "relationship", "ref": "j", "owner": target}
        if kind:
            participant["kind"] = kind
        knowledge.call("graph.put", {"source": source, "graph": {"joins": [
            {"id": source + "-higher", "type": "evidence", "participants": [participant]},
        ]}})
    before = knowledge.call("graph.export", {})
    view = knowledge.call("graph.similarity", {})
    assert sorted(j["membership"] for j in view["joins"]) == (["11"] if same_owner else ["01", "10"])
    assert view["elements"] == {}
    assert {p["owner"] for j in view["joins"] for p in j["participants"]} == ({"global"} if same_owner else {"global", owner})
    assert all(p["kind"] == "join" and p["ref"] == "j" for j in view["joins"] for p in j["participants"])
    assert knowledge.call("graph.export", {}) == before


@pytest.mark.parametrize("operation", ["knowledge.snapshot", "knowledge.assemble", "graph.merge_perspectives"])
def test_similarity_qualification_reaches_assembly_snapshot_and_merge(tmp_path, operation):
    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    project = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
    owner = "project:" + project
    for target in ["global", owner]:
        store.call(project, "graph.put", {"owner": target, "source": "authored", "graph": {
            "joins": [{"id": "j", "type": "authored-relation"}],
        }})
    for source, target in [("native", "global"), ("archaeology", owner)]:
        store.call(project, "graph.put", {"source": source, "graph": {"joins": [
            {"id": source, "type": "evidence", "object_id": "j", "element_id": "X",
             "reference_owners": {"object_id": target}},
        ]}})
    before = {source: store.call(project, "graph.export", {"scope": source})
              for source in ["native", "archaeology"]}
    result = store.call(project, operation, {"focal": "X"} if operation == "knowledge.assemble" else {})
    if operation == "graph.merge_perspectives":
        view = {"joins": store.call(project, "graph.joins", {"scope": "merged"})}
    elif operation == "knowledge.assemble":
        view = result["similarity"][owner]
    else:
        view = result["similarity"]
    assert sorted(j["membership"] for j in view["joins"]) == ["01", "10"]
    assert {j["reference_owners"]["object_id"] for j in view["joins"]} == {"global", owner}
    assert {source: store.call(project, "graph.export", {"scope": source}) for source in before} == before


def test_similarity_keeps_element_typeaddress_correspondence_across_owners():
    graphs = [{"elements": {}, "joins": [{"id": source, "type": "OP", "participants": [
        {"role": "receiver", "ref": "X", "owner": owner, "kind": "element"},
    ]}]} for source, owner in [("n", "global"), ("a", "project:p")]]
    view = compare(*graphs)
    assert [j["membership"] for j in view["joins"]] == ["11"]
    assert view["elements"]["X"]["membership"] == "11"


def test_similarity_divergent_duplicate_joins_finishes_with_exact_maximum():
    script = """
import json
from metaform.similarity import compare
graphs = []
for prefix in ['n', 'a']:
    joins = [{'id': f'{prefix}:{i}', 'type': 'OP', 'object_id': 'X', 'element_id': 'Y'} for i in range(9)]
    joins += [{'id': f'{prefix}:z{i}', 'type': 'evidence',
               'object_id': prefix + ':' + str(0 if prefix == 'n' else i), 'element_id': 'E'} for i in range(2)]
    graphs.append({'elements': {}, 'joins': joins})
view = compare(*graphs)
print(json.dumps(sorted(j['membership'] for j in view['joins'])))
"""
    environment = dict(os.environ, PYTHONPATH=str(Path(__file__).resolve().parents[1] / "src"))
    result = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True,
                            env=environment, timeout=5, check=True)
    # Nine leaf joins plus one evidence join can correspond; the second evidence cannot.
    assert json.loads(result.stdout) == ["01", "10"] + ["11"] * 10


def test_similarity_pruning_preserves_exact_small_cyclic_and_duplicate_correspondence():
    randomizer = random.Random(8)
    for _ in range(40):
        graphs = []
        for prefix in ["n", "a"]:
            identifiers = [prefix + str(i) for i in range(4)]
            graphs.append({"elements": {}, "joins": [
                {"id": identifier, "type": "OP", "object_id": randomizer.choice(["X", *identifiers]),
                 "element_id": randomizer.choice(["E", "E", "F"])} for identifier in identifiers
            ]})
        native, latent = [{j["id"]: j for j in graph["joins"]} for graph in graphs]
        maximum = 0
        for size in range(1, 5):
            for left in combinations(native, size):
                for right in permutations(latent, size):
                    mapping = dict(zip(left, right))
                    if all(native[a]["element_id"] == latent[b]["element_id"] and
                           (mapping.get(native[a]["object_id"]) == latent[b]["object_id"]
                            if native[a]["object_id"] in native else
                            native[a]["object_id"] == latent[b]["object_id"])
                           for a, b in mapping.items()):
                        maximum = size
        view = compare(*graphs)
        assert sum(j["membership"] == "11" for j in view["joins"]) == maximum
