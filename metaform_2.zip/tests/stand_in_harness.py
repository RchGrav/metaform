"""A stand-in agent for the job viewer test: reads the assignment and answers with a small contribution."""
import json, sys, time
request_file, response_file = sys.argv[1], sys.argv[2]
assignment = json.load(open(request_file))
time.sleep(1)
answer = {
  "elements": {
    "code.loop.clock": {"ef": "Shows the current time as a pong rally."},
    "code.loop.clock.display": {"ef": "Draws the digits."}},
  "joins": [
    {"receiver": "code.loop.clock", "provider": "code.loop.clock.display", "purpose": "Show the time as digits."}],
  "subtypes": ["code.loop.clock.display.digits"]}
json.dump(answer, open(response_file, "w"))
