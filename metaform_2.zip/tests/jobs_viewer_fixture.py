"""Serve an empty project with a stand-in harness so the job viewer can run an intake end to end."""
import os, signal, sys, tempfile
from pathlib import Path
from metaform.app import App
from metaform.util import write_json
from metaform.viewer import create_app
from werkzeug.serving import make_server
here = Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix="jobs-viewer-") as folder:
    root = Path(folder).resolve()
    os.environ["METAFORM_RUNTIME_DIR"] = str(root / "runtime")
    project = root / "pong clock"
    project.mkdir()
    (project / "pong_clock.py").write_text("print('tick')\n")
    write_json(root / "home/config.json", {"knowledge_mode": "legacy", "harnesses": {
        "stand-in": {"command": [sys.executable, str(here / "stand_in_harness.py"), "{request_file}", "{response_file}"]}}})
    app = App(project, root / "home")
    server = make_server("127.0.0.1", 0, create_app(app), threaded=True)
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt))
    print(f"http://127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
