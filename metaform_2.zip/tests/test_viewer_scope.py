import json
from pathlib import Path

import pytest

from metaform.app import App
from metaform.backends import JSONGraph
from metaform.prompts import prepare, record_test
from metaform.viewer import create_app
from metaform.workflow import import_workflow


def element(name, layer="elements"):
    return {
        "entity_desc": name,
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name},
        "layer": layer,
    }


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_project_view_does_not_present_authored_procedures_as_intake(app, backend):
    if backend == "json":
        app.graph = JSONGraph(app.root / "test.json")
        app.seed()
    client = create_app(app).test_client()
    assert client.get("/api/workflows").json == []
    for query in ("", "?dataset=records", "?dataset=unknown"):
        network = client.get("/api/network" + query).json
        assert network["nodes"] == []
        assert network["edges"] == []
        assert network["joins"] == []
        assert network["layers"] == []
        assert "dataset" not in network
    assert client.get("/api/graph").json

    # Reproduce records left by the previous automatically seeded examples and trials.
    example = Path(__file__).resolve().parents[1] / "examples/workflows/conditional_review.json"
    import_workflow(app, json.loads(example.read_text()))
    trial = prepare(app, "prompt:metaform.workflow.convert")
    record_test(app, trial, {"answer": "A recorded response"})
    before = app.graph.export()
    for perspective in ("inference", "contextual", "latent"):
        for dataset in ("inference", "records", "unknown"):
            network = client.get(
                f"/api/network?perspective={perspective}&dataset={dataset}"
            ).json
            assert network["nodes"] == []
            assert network["edges"] == []
            assert network["layers"] == []
    library = client.get("/api/graph").json
    assert any(n["sources"] == ["authored"] for n in library)
    assert any(n["sources"] == ["test"] for n in library)
    assert any(n["entity_schema"] == "metaform:prompt" for n in library)
    assert any(n["entity_schema"] == "metaform:semantic-rule" for n in library)
    assert client.get("/api/workflows").json
    assert app.graph.export() == before


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_imported_metaform_is_visible_without_intake_or_schema_restrictions(app, tmp_path, backend):
    from metaform.util import write_json
    write_json(tmp_path / "origin-home" / "config.json", {"knowledge_mode": "legacy"})
    origin = App(tmp_path / "origin", tmp_path / "origin-home")
    custom = dict(element("Imported element"), entity_schema="custom:artifact")
    origin.graph.put({
        "elements": {"custom": custom, "other": element("Other")},
        "joins": [{
            "id": "custom-join", "object_id": "custom", "element_id": "other",
            "type": "custom-relation", "purpose": "Imported relationship",
        }],
    }, "native")
    if backend == "json":
        app.graph = JSONGraph(app.root / "imported.json")
        app.seed()
    app.graph.put(origin.graph.export(), "imported")
    with app.db() as db:
        assert db.execute("SELECT count(*) FROM runs").fetchone()[0] == 0
    client = create_app(app).test_client()
    network = client.get("/api/network").json
    elements = {n["id"]: n for n in network["nodes"] if n["kind"] == "element"}
    assert set(elements) == {"custom", "other"}
    assert elements["custom"]["entity_schema"] == "custom:artifact"
    assert [join["type"] for join in network["joins"]] == ["custom-relation"]
    assert len(network["edges"]) == 1
    assert network["edges"][0]["source"] == "other"
    assert network["edges"][0]["target"] == "custom"
    assert client.get("/api/network?dataset=records").json == network
    assert client.get("/api/network?perspective=latent").json["nodes"] == []


def test_filtered_intake_graph_preserves_hyperedge_participants(app):
    app.graph.put({"elements": {"evidence": element("Evidence")}}, "authored")
    app.graph.put({
        "elements": {
            "a": element("A", "selected"), "b": element("B"),
            "c": element("C"), "d": element("D"),
        },
        "joins": [
            {"id": "ab", "object_id": "a", "element_id": "b", "type": "dependency"},
            {"id": "cd", "object_id": "c", "element_id": "d", "type": "dependency"},
            {"id": "context", "object_id": "a", "element_id": "ab", "type": "evidence",
             "participants": [{"role": "subject", "ref": "a"}, {"role": "relationship", "ref": "ab"}, {"role": "support", "ref": "evidence"}]},
        ],
    }, "native")
    client = create_app(app).test_client()
    data = client.get("/api/network?layer=selected").json
    assert {n["id"] for n in data["nodes"] if n["kind"] != "join"} == {"a", "b", "evidence"}
    assert len(data["joins"]) == 2
    assert not any(n["kind"] == "join" for n in data["nodes"])
    assert [(e["source"], e["target"]) for e in data["edges"]] == [("b", "a")]
    identifiers = {n["id"] for n in data["nodes"]}
    assert all(e["source"] in identifiers and e["target"] in identifiers for e in data["edges"])
    assert client.get("/api/network?q=missing").json["nodes"] == []


def test_project_selection_does_not_mix_project_data(app, tmp_path):
    other = App(tmp_path / "other-project", app.home)
    app.graph.put({"elements": {"media.photo": element("Photo")}}, "native")
    app.global_graph.put({"elements": {"document.email": element("Email")}}, "archaeology")
    a, b = create_app(app).test_client(), create_app(other).test_client()
    assert a.get("/api/settings").json["project"] == str(app.project)
    assert b.get("/api/settings").json["project"] == str(other.project)
    assert {n["id"] for n in a.get("/api/network").json["nodes"]} == {"media.photo"}
    assert b.get("/api/network").json["nodes"] == []
    assert a.get("/api/network?storage=global").json == b.get("/api/network?storage=global").json


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_metaform_perspectives_keep_sources_and_reference_closure(app, backend):
    if backend == "json":
        app.graph = JSONGraph(app.root / "perspectives.json")
        app.global_graph = JSONGraph(app.home / "perspectives.json")
    app.graph.put({
        "elements": {"code": element("Program code"), "project": element("Project")},
        "joins": [{"id": "project-use", "object_id": "project", "element_id": "code",
                   "type": "receiving_entity", "purpose": "Project purpose"}],
    }, "native")
    app.graph.put({
        "elements": {"code": element("Program code"), "dependency": element("Dependency")},
        "joins": [
            {"id": "dependency-join", "object_id": "code", "element_id": "dependency",
             "type": "receiving_entity", "purpose": "Independent purpose"},
            {"id": "evidence", "object_id": "code", "element_id": "dependency",
             "type": "evidence", "participants": [
                 {"role": "subject", "ref": "code"},
                 {"role": "relationship", "ref": "dependency-join"},
                 {"role": "support", "ref": "external-reference"},
             ]},
        ],
    }, "archaeology")
    app.global_graph.put({"elements": {"global-only": element("Global only")}}, "archaeology")
    client = create_app(app).test_client()

    contextual = client.get("/api/network?perspective=contextual").json
    assert contextual["perspective"] == "contextual"
    assert {n["id"] for n in contextual["nodes"] if n["kind"] == "element"} == {"project", "code"}
    assert {join["purpose"] for join in contextual["joins"]} == {"Project purpose"}

    latent = client.get("/api/network?perspective=latent&q=code").json
    assert latent["perspective"] == "latent"
    assert {join["join_scope"] for join in latent["joins"]} == {"archaeology"}
    identifiers = {n["id"] for n in latent["nodes"]}
    assert "project" not in identifiers and "global-only" not in identifiers
    assert "external-reference" in identifiers
    assert len(latent["joins"]) == 2
    assert [(e["source"], e["target"]) for e in latent["edges"]] == [("dependency", "code")]
    assert all(e["source"] in identifiers and e["target"] in identifiers for e in latent["edges"])
    global_data = client.get("/api/network?storage=global&perspective=latent").json
    assert {n["id"] for n in global_data["nodes"]} == {"global-only"}
    assert client.get("/api/network?storage=global&perspective=contextual").json["nodes"] == []
    combined = client.get("/api/network").json
    assert combined["perspective"] == "inference"
    assert {join["join_scope"] for join in combined["joins"]} == {"native", "archaeology"}
    assert client.get("/api/network?perspective=unknown").status_code == 400
