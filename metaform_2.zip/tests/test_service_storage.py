"""Shared SQLite knowledge remains readable and exportable across restarts."""
from metaform.service import RemoteKnowledge, stop_service
from test_service_lifecycle import home
from test_knowledge_contract import element


def test_service_core_export_and_snapshot_survive_restart(home, tmp_path):
    admin = RemoteKnowledge(home, None)
    identifier = admin.call("project.register", {"path": str(tmp_path / "project")})["project_id"]
    remote = RemoteKnowledge(home, identifier)
    for source in ("native", "archaeology"):
        remote.call("graph.put", {"graph": {"elements": {"X": element(source)}}, "source": source})
    exported = remote.call("graph.export", {})
    assert {row["source"] for row in exported["observations"]} == {"native", "archaeology"}
    assert remote.call("knowledge.snapshot", {"execution_roots": []})["project"] == exported
    stop_service(home)
    assert remote.call("graph.export", {}) == exported
    assert remote.call("graph.get", {"id": "X", "scope": "native"}) == element("native")
