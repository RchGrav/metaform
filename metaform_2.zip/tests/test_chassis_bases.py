"""The four bases, code, document, media and data, are reusable positions known to every intake (plan unit 3,
SPEC section 5): seeded once into the global registry with their universal EF, referenced by every run, and reused
by the expansion, never re-authored per project with an empty EF.
"""
from metaform.app import App
from metaform.intake import Intake
from metaform.models import capture_model

BASES = ("code", "document", "media", "data")


def test_the_bases_are_global_positions_with_an_ef_from_the_first_start(app):
    for base in BASES:
        record = app.global_graph.get(base)
        assert record and record["entity_json_obj"]["ef"], base
    assert app.global_graph.get("code")["entity_json_obj"]["ef"] == "Tell a computer how to perform a task or process data."
    assert app.global_graph.get("code")["entity_desc"] == "a set of precise instructions that tells a computer how to perform a task or process data"


def test_seeding_keeps_an_edited_base(app):
    app.global_graph.put({"elements": {"data": {"entity_desc": "edited", "entity_schema": "metaform:element",
                                                 "entity_json_obj": {"ef": "Edited.", "length": 1, "aliases": []}}}}, "authored")
    again = App(app.project, app.home)
    assert again.global_graph.get("data")["entity_json_obj"]["ef"] == "Edited."


def test_an_intake_reuses_the_bases_instead_of_authoring_them_with_an_empty_ef(app):
    (app.project / "main.py").write_text("print('hi')\n")
    engine = Intake(app)
    job = engine.start({})
    assert {"global|" + base for base in BASES} <= set(app.load_run(job["run_id"])["referenced_types"])
    assert {record["id"] for record in job["inputs"]["reusable_types"].values()} >= set(BASES)
    engine.put(job["run_id"], {"elements": {"code.loop.clock": {"ef": "Keeps the time."},
                                            "data.configuration": {"ef": "Holds the settings."}},
                               "joins": [{"receiver": "code.loop.clock", "provider": "data.configuration", "purpose": "Read the settings."}],
                               "subtypes": []}, job["request_id"])
    engine.submit(job["run_id"], job["request_id"], {})
    model = capture_model(app, engine.next(job["run_id"])["model"])
    assert model["types"]["code"]["owner"] == "global"
    assert model["types"]["code"]["ef"] == "Tell a computer how to perform a task or process data."
    assert model["types"]["data"]["owner"] == "global" and model["types"]["data"]["ef"]
    assert model["types"]["code.loop"]["owner"] == "project:" + app.project_id
