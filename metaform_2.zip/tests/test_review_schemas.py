from pathlib import Path

import pytest

from metaform.backends import JSONGraph
from metaform.knowledge import KnowledgeError, KnowledgeStore, LocalKnowledge
from metaform.modules import sync
from metaform.util import digest, read_json, write_json


def test_global_sync_excludes_private_schema_and_project_override(app, tmp_path):
    shared = {"$id": "custom:shared", "type": "string"}
    app.knowledge.call("schema.put", {"owner": "global", "schema": shared})
    for schema in [
        {"$id": "custom:shared", "type": "integer", "description": "LOCAL_SENTINEL"},
        {"$id": "custom:private", "type": "object", "description": "PRIVATE_SENTINEL"},
    ]:
        app.knowledge.call("schema.put", {"owner": "project:" + app.project_id, "schema": schema})
    result = sync.export(app, {"repository": str(tmp_path / "export")}, None)
    output = Path(result["directory"])
    assert read_json(output / "schemas" / (digest("custom:shared") + ".json")) == shared
    assert "custom:private" not in read_json(output / "index.json")["schemas"]
    assert not (output / "schemas" / (digest("custom:private") + ".json")).exists()


@pytest.mark.parametrize("graph_changed", [False, True])
def test_adoption_unchanged_schema_source_preserves_central_edit(tmp_path, graph_changed):
    home = tmp_path / "home"
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    write_json(home / "schemas.json", {"example": {"$id": "example", "type": "string"}})
    project_id = store.adopt(tmp_path / "a", home)["project_id"]
    edited = {"$id": "example", "type": "number"}
    store.call(project_id, "schema.put", {"owner": "global", "schema": edited})
    if graph_changed:
        write_json(home / "config.json", {"graph_backend": "json"})
        JSONGraph(home / "inference" / "metaform.json").put({"elements": {"New": {"entity_desc": "New", "entity_schema": "example", "entity_json_obj": {}}}})
    store.adopt(tmp_path / "b", home)
    assert store.call(project_id, "schema.get", {"owner": "global", "id": "example"}) == edited


@pytest.mark.parametrize("source", ["changed", "other_home", "legacy_import"])
def test_adoption_schema_conflict_rolls_back_before_marker(tmp_path, source):
    home = tmp_path / "home"
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    original = {"$id": "example", "type": "string"}
    write_json(home / "schemas.json", {"example": original})
    project_id = store.adopt(tmp_path / "a", home)["project_id"]
    edited = {"$id": "example", "type": "number"}
    store.call(project_id, "schema.put", {"owner": "global", "schema": edited})
    if source == "changed":
        incoming = {"$id": "example", "type": "boolean"}
        write_json(home / "schemas.json", {"example": incoming})
    elif source == "other_home":
        home = tmp_path / "other_home"
        incoming = original
        write_json(home / "schemas.json", {"example": incoming})
    else:
        incoming = original
        # A pre-fix installation only retained the graph digest.
        with store.transaction() as db:
            db.execute("DELETE FROM imports")
            db.execute("INSERT INTO imports VALUES(?,?)", (str(home), digest({"elements": {}, "joins": [], "observations": []})))
    project = tmp_path / "b"
    revision = store.revision
    before = (home / "schemas.json").read_bytes()
    with pytest.raises(KnowledgeError) as error:
        store.call(None, "project.adopt", {"path": str(project), "home": str(home)}, "schema-conflict")
    assert error.value.code == "migration_conflict"
    assert error.value.details == [{"owner": "global", "kind": "schemas", "id": "example", "existing": edited, "incoming": incoming}]
    assert store.revision == revision
    assert len(store.call(None, "project.list", {})) == 1
    assert store.call(project_id, "schema.get", {"owner": "global", "id": "example"}) == edited
    assert not (project / ".metaform" / "project.json").exists()
    assert (home / "schemas.json").read_bytes() == before


def test_adoption_imports_project_schema_exactly_under_new_owner(tmp_path):
    project, home = tmp_path / "project", tmp_path / "home"
    write_json(project / ".metaform" / "config.json", {"graph_backend": "json"})
    local = LocalKnowledge("old", JSONGraph(project / ".metaform" / "metaform.json"), JSONGraph(home / "inference" / "metaform.json"))
    schema = {"$id": "local:schema", "type": "string", "description": "Project definition"}
    local.call("schema.put", {"owner": "project:old", "schema": schema})
    before = (project / ".metaform" / "schemas.json").read_bytes()
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    entry = store.adopt(project, home)
    assert store.call(entry["project_id"], "schema.get", {"id": "local:schema"}) == schema
    assert store.call(entry["project_id"], "schema.get", {"owner": "global", "id": "local:schema"}) is None
    assert read_json(project / ".metaform" / "project.json")["knowledge_mode"] == "service"
    assert (project / ".metaform" / "schemas.json").read_bytes() == before


def test_adoption_project_schema_conflict_keeps_existing_registration_and_no_marker(tmp_path):
    project, home = tmp_path / "project", tmp_path / "home"
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    project_id = store.call(None, "project.register", {"path": str(project)})["project_id"]
    existing = {"$id": "local:schema", "type": "number"}
    incoming = {"$id": "local:schema", "type": "string"}
    store.call(project_id, "schema.put", {"schema": existing})
    write_json(project / ".metaform" / "schemas.json", {"local:schema": incoming})
    with pytest.raises(KnowledgeError) as error:
        store.adopt(project, home)
    assert error.value.code == "migration_conflict"
    assert error.value.details == [{"owner": "project:" + project_id, "kind": "schemas", "id": "local:schema", "existing": existing, "incoming": incoming}]
    assert store.call(project_id, "schema.get", {"id": "local:schema"}) == existing
    assert not (project / ".metaform" / "project.json").exists()


def test_schema_migration_keeps_prior_graph_import_identity(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"graph_backend": "json"})
    graph = JSONGraph(home / "inference" / "metaform.json")
    graph.put({"elements": {"X": {"entity_desc": "legacy", "entity_schema": "example", "entity_json_obj": {}}}})
    schema = {"$id": "example", "type": "string"}
    write_json(home / "schemas.json", {"example": schema})
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    store.call(None, "graph.put", {"owner": "global", "graph": {"elements": {"X": {"entity_desc": "central edit", "entity_schema": "example", "entity_json_obj": {}}}}})
    store.call(None, "schema.put", {"owner": "global", "schema": schema})
    with store.transaction() as db:
        db.execute("INSERT INTO imports VALUES(?,?)", (str(home), digest(graph.export())))
    project_id = store.adopt(tmp_path / "project", home)["project_id"]
    assert store.call(project_id, "graph.get", {"owner": "global", "id": "X"})["entity_desc"] == "central edit"
    assert store.call(project_id, "schema.get", {"owner": "global", "id": "example"}) == schema


def test_failed_schema_verification_rolls_back_graph_and_registration(tmp_path):
    project, home = tmp_path / "project", tmp_path / "home"
    write_json(project / ".metaform" / "config.json", {"graph_backend": "json"})
    graph = JSONGraph(project / ".metaform" / "metaform.json")
    graph.put({"elements": {"X": {"entity_desc": "legacy", "entity_schema": "example", "entity_json_obj": {}}}})
    write_json(project / ".metaform" / "schemas.json", {"registered-id": {"$id": "different-id", "type": "string"}})
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    with pytest.raises(KnowledgeError) as error:
        store.adopt(project, home)
    assert error.value.code == "migration_verification_failed"
    assert store.revision == 0
    assert store.call(None, "project.list", {}) == []
    assert not (project / ".metaform" / "project.json").exists()
    with store.transaction(False) as db:
        assert db.execute("SELECT COUNT(*) FROM elements").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM schemas").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM imports").fetchone()[0] == 0


def test_new_copy_uses_current_central_schema_and_translates_self_owner(tmp_path):
    home = tmp_path / "home"
    store = KnowledgeStore(tmp_path / "store.sqlite3")
    original = tmp_path / "original"
    old_id = store.adopt(original, home)["project_id"]
    schema = {"$id": "local:schema", "type": "number", "participants": [{"ref": "X", "owner": "project:" + old_id}]}
    store.call(old_id, "schema.put", {"schema": schema})
    copied = tmp_path / "copy"
    write_json(copied / ".metaform" / "project.json", read_json(original / ".metaform" / "project.json"))
    write_json(copied / ".metaform" / "schemas.json", {"local:schema": {"$id": "local:schema", "type": "string"}})
    new_id = store.adopt(copied, home, new_copy=True)["project_id"]
    assert store.call(new_id, "schema.get", {"id": "local:schema"}) == schema | {"participants": [{"ref": "X", "owner": "project:" + new_id}]}
    assert store.call(old_id, "schema.get", {"id": "local:schema"}) == schema
