"""The structure viewer receives actual project records, not only Type labels."""

import pytest

from metaform.backends import JSONGraph
from metaform.viewer import create_app


def element(name, **detail):
    return {
        "entity_desc": "Universal description of " + name,
        "entity_schema": "project:function",
        "entity_json_obj": {"en": name, **detail},
    }


@pytest.fixture(params=["sqlite", "json"])
def structure(app, request):
    if request.param == "json":
        app.graph = JSONGraph(app.root / "structure.json")
    return app, create_app(app).test_client()


def test_structure_exposes_native_context_only_in_its_project_perspectives(structure):
    app, client = structure
    context = {
        "artifact": {"kind": "photographs", "boundary": "Items in this folder"},
        "description": "Photographs of used items being offered for sale",
    }
    app.set("native_context", context)
    for perspective in ("inference", "contextual"):
        assert client.get("/api/network", query_string={"perspective": perspective}).json["context"] == context
    for query in ({"perspective": "latent"}, {"perspective": "similarity"}, {"storage": "global"}):
        assert client.get("/api/network", query_string=query).json["context"] == {}


def test_structure_preserves_actual_detail_and_source_records(structure):
    app, client = structure
    native = element("Installer", notes="Installs the editor and configures startup", functions=[
        {"name": "Prepare runtime", "purpose": "Allow the editor to start", "path": "install.sh"},
    ])
    latent = element("Installer", notes="Review runtime compatibility")
    app.graph.put({"elements": {"code.installer": native}}, "native")
    app.graph.put({"elements": {"code.installer": latent}}, "archaeology")
    node = client.get("/api/network").json["nodes"][0]
    assert node["source_records"]["native"]["entity_json_obj"] == native["entity_json_obj"]
    assert node["source_records"]["archaeology"]["entity_json_obj"] == latent["entity_json_obj"]
    for perspective, record in (("contextual", native), ("latent", latent)):
        selected = client.get("/api/network", query_string={"perspective": perspective}).json["nodes"][0]
        assert selected["entity_json_obj"] == record["entity_json_obj"]
        assert "source_records" not in selected
    assert "source_records" not in client.get("/api/network?perspective=similarity").get_data(as_text=True)


def test_structure_retains_all_bases_full_joins_and_no_synthetic_elements(structure):
    app, client = structure
    identifiers = ["code.installer", "document.contract", "media.photo.product.used",
                   "data.catalog", "exterior.person.buyer", "ext.environment.market"]
    app.graph.put({
        "elements": {identifier: element(identifier, notes="Actual detail for " + identifier) for identifier in identifiers},
        "joins": [
            {"id": "sale", "type": "supportive", "purpose": "Help the buyer assess the item",
             "participants": [{"role": "receiver", "ref": "exterior.person.buyer"},
                              {"role": "ef_owner", "ref": "media.photo.product.used"},
                              {"role": "support", "ref": "data.catalog"}],
             "signal": {"description": "Visible condition and matching item information"}},
            {"id": "terms", "type": "hard dependency", "purpose": "State the sale terms",
             "participants": [{"role": "receiver", "ref": "sale"},
                              {"role": "ef_owner", "ref": "document.contract"}]},
        ],
    }, "native")
    before = app.graph.export()
    network = client.get("/api/network?perspective=contextual").json
    assert {node["id"] for node in network["nodes"]} == set(identifiers)
    assert network["joins"] == sorted(app.graph.joins(scope="native"), key=lambda join: join["id"])
    assert len(network["joins"]) == 2
    assert network["edges"] == []  # Both relationships need their full participant structure.
    assert app.graph.export() == before


def test_type_search_retains_distinct_actual_elements_and_their_type_record(structure):
    app, client = structure
    classification = element("Interface", length=1)
    app.graph.put({"elements": {"code.interface": classification}}, "authored")
    app.graph.put({
        "elements": {
            "gateway:commands": element("Gateway commands", type_id="code.interface", ef="Control gateway routes"),
            "monitor:commands": element("Monitor commands", type_id="code.interface", ef="Inspect probes"),
            "gateway:routes": element("Route selection", type_id="code.selector"),
            "monitor:probes": element("Probe observations", type_id="data.observation"),
        },
        "joins": [
            {"id": "route-purpose", "object_id": "gateway:commands", "element_id": "gateway:routes",
             "type": "hard dependency", "purpose": "Choose the requested gateway route", "signal": "Selected route"},
            {"id": "probe-purpose", "object_id": "monitor:commands", "element_id": "monitor:probes",
             "type": "hard dependency", "purpose": "Report the latest probe outcome", "signal": "Observed probe result"},
        ],
    }, "native")
    before = app.graph.export()
    for perspective in ("contextual", "inference"):
        network = client.get("/api/network", query_string={"perspective": perspective, "q": "code.interface"}).json
        nodes = {node["id"]: node for node in network["nodes"]}
        assert set(nodes) == {"code", "data", "code.interface", "gateway:commands", "monitor:commands", "gateway:routes", "monitor:probes"}
        assert nodes["code.interface"]["entity_desc"] == classification["entity_desc"]
        actual = [node for node in nodes.values() if node.get("entity_json_obj", {}).get("type_id") == "code.interface"]
        assert {node["id"] for node in actual} == {"gateway:commands", "monitor:commands"}
        assert {(edge["source"], edge["target"]) for edge in network["edges"]} == {
            ("gateway:routes", "gateway:commands"), ("monitor:probes", "monitor:commands"),
        }
        assert {join["signal"] for join in network["joins"]} == {"Selected route", "Observed probe result"}
    assert app.graph.export() == before


def test_combined_type_search_keeps_native_classification_after_latent_reclassification(structure):
    app, client = structure
    app.graph.put({'elements': {
        'code.interface': element('Interface'), 'code.store': element('Store'),
    }}, 'authored')
    app.graph.put({'elements': {'actual:controls': element('Controls', type_id='code.interface')}}, 'native')
    app.graph.put({'elements': {'actual:controls': element('Control store', type_id='code.store')}}, 'archaeology')
    network = client.get('/api/network?q=code.interface&perspective=inference').json
    nodes = {node['id']: node for node in network['nodes']}
    assert set(nodes) == {'actual:controls', 'code', 'code.interface', 'code.store'}
    assert nodes['actual:controls']['source_records']['native']['entity_json_obj']['type_id'] == 'code.interface'
    assert nodes['actual:controls']['source_records']['archaeology']['entity_json_obj']['type_id'] == 'code.store'
    latent = client.get('/api/network?q=code.interface&perspective=latent').json
    assert latent['nodes'] == []


def test_freeform_actual_record_is_found_by_each_type_without_membership_joins(structure):
    app, client = structure
    types = {identifier: element(identifier, length=1) for identifier in ('media.photo', 'document.report')}
    actual = {
        'entity_schema': 'metaform:actual-element', 'entity_desc': 'Field survey',
        'entity_json_obj': {'en': 'Field survey', 'type_ids': list(types),
                            'description': {'subject': 'River crossing', 'observations': ['High water', 'Intact footbridge']}},
    }
    app.graph.put({'elements': types}, 'authored')
    app.graph.put({'elements': {'survey': actual}}, 'native')
    for type_id in types:
        network = client.get('/api/network', query_string={'q': type_id}).json
        nodes = {node['id']: node for node in network['nodes']}
        assert set(nodes) == {'survey', 'media', 'document', *types}
        assert nodes['survey']['entity_json_obj'] == actual['entity_json_obj']
        assert network['joins'] == []
        assert network['edges'] == []
