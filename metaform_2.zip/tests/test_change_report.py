from copy import deepcopy
import subprocess

from metaform.intake import Intake
from metaform.models import capture_model, publish_foundation
from test_foundation_intake import contribution, storage


def finish(app, job):
    intake = Intake(app)
    intake.submit(job['run_id'], job['request_id'], contribution(app))
    return intake.next(job['run_id'])['model']


def test_change_percentage_uses_union_and_preserves_each_intake_baseline(app):
    from metaform.change_report import report

    for name in ('keep.txt', 'modify.txt', 'delete.txt'):
        (app.project / name).write_text('original')
    subprocess.run(['git', 'init', '-q', str(app.project)], check=True)
    subprocess.run(['git', '-C', str(app.project), 'add', '--', 'keep.txt', 'modify.txt', 'delete.txt'], check=True)
    job = Intake(app).start()
    (app.project / 'modify.txt').write_text('changed during intake')
    first = finish(app, job)
    original_model = deepcopy(capture_model(app, first))
    (app.project / 'delete.txt').unlink()
    (app.project / 'added.txt').write_text('new')
    result = report(app, first)
    assert result['status'] == 'available'
    assert (result['added'], result['modified'], result['deleted']) == (1, 1, 1)
    assert result['total_compared_paths'] == 4
    assert result['percentage'] == 75
    assert result['baseline_file_count'] == result['current_file_count'] == 3
    assert result['net_growth_files'] == result['net_growth_percentage'] == 0
    assert result['baseline']['id'] == job['run_id']
    assert result['baseline']['captured_at']
    with app.db() as db:
        assert db.execute('SELECT count(*) FROM runs').fetchone()[0] == 1
    assert capture_model(app, first) == original_model

    second = finish(app, Intake(app).start())
    current = report(app, second)
    assert current['percentage'] == 0
    assert current['total_compared_paths'] == 3
    assert current['baseline']['id'] != result['baseline']['id']
    assert report(app, first) == result
    assert capture_model(app, first) == original_model


def test_growth_and_change_report_empty_baseline_additions_and_deletions(app):
    from metaform.change_report import report

    empty = finish(app, Intake(app).start())
    assert report(app, empty)['percentage'] == 0
    for name in ('one', 'two'):
        (app.project / name).write_text(name)
    added = report(app, empty)
    assert added['baseline_file_count'] == 0 and added['current_file_count'] == 2
    assert added['net_growth_files'] == 2 and added['net_growth_percentage'] is None
    assert added['percentage'] == 100
    baseline = finish(app, Intake(app).start())
    (app.project / 'one').unlink()
    deleted = report(app, baseline)
    assert deleted['net_growth_files'] == -1 and deleted['net_growth_percentage'] == -50
    assert deleted['percentage'] == 50
    for name in ('three', 'four', 'five'):
        (app.project / name).write_text(name)
    grown = report(app, baseline)
    assert grown['baseline_file_count'] == 2 and grown['current_file_count'] == 4
    assert grown['net_growth_files'] == 2 and grown['net_growth_percentage'] == 100
    assert grown['total_compared_paths'] == 5 and grown['percentage'] == 80

def test_symlink_change_compares_link_target_without_following_it(app, tmp_path):
    from metaform.change_report import report

    outside = tmp_path / 'outside.txt'
    outside.write_text('outside source')
    link = app.project / 'source-link'
    link.symlink_to(outside)
    model = finish(app, Intake(app).start())
    outside.write_text('changed outside this project')
    assert report(app, model)['percentage'] == 0
    link.unlink()
    link.symlink_to(tmp_path / 'missing-target')
    result = report(app, model)
    assert result['modified'] == 1
    assert result['percentage'] == 100


def test_planned_and_older_models_do_not_invent_source_baselines(app, monkeypatch):
    from metaform.change_report import report
    from metaform.modules import intake

    older = publish_foundation(app, {'schema_version': '2',
        'model': {'project': app.project_id, 'model': 'older'}, **storage(app)})
    def no_scan(*args):
        raise AssertionError('Source scan was not requested for this model')
    monkeypatch.setattr(intake, 'project_files', no_scan)
    result = report(app, older)
    assert result['status'] == 'unavailable' and result['percentage'] is None
    inputs = {'artifact_context': {'plan': 'A maintenance guide'}, 'source_manifest': {'files': []}}
    plan = finish(app, Intake(app).start(inputs))
    planned = report(app, plan)
    assert planned['status'] == 'planned' and planned['percentage'] is None
    assert inputs == {'artifact_context': {'plan': 'A maintenance guide'}, 'source_manifest': {'files': []}}
