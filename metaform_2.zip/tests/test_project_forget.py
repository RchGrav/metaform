"""Forgetting a project: the projects page marks folders that no longer exist and can forget them, and the CLI can
forget by path or every missing one. Forgetting drops the registration and the catalog entry; the folder and its
knowledge are untouched. Rich, 2026-09-13: dead entries with no way to clear them are a glaring hole.
"""
import asyncio
import shutil

from metaform.app import App
from metaform.registry import Registry
from metaform.service import stop_service
from metaform.util import write_json
from metaform.viewer import create_app
from test_viewer_projects import local_project


def test_the_projects_page_marks_missing_folders_and_forgets_them(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home)
    second = local_project(tmp_path / "second", home)
    third = local_project(tmp_path / "third", home)
    client = create_app(first).test_client()
    try:
        for project in (second, third):
            assert client.post("/api/projects/open", json={"path": str(project.project)}).status_code == 200
        shutil.rmtree(second.project)
        listed = {item["path"]: item for item in client.get("/api/projects").json}
        assert listed[str(second.project)]["missing"] is True
        assert listed[str(third.project)]["missing"] is False
        page = client.get("/projects").get_data(as_text=True)
        assert "folder is gone" in page and "Forget" in page
        assert client.post("/api/projects/forget", json={"missing": True}).json["forgotten"] == [str(second.project)]
        assert client.post("/api/projects/forget", json={"path": str(third.project)}).json["forgotten"] == [str(third.project)]
        assert {item["path"] for item in client.get("/api/projects").json} == {str(first.project)}
        assert third.project.is_dir()
    finally:
        stop_service(home)


def test_project_forget_command_drops_the_registration_and_keeps_the_folder(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "service", "auto_build": False})
    app = App(tmp_path / "project", home)
    other = App(tmp_path / "other", home)
    gone = App(tmp_path / "gone", home)
    try:
        listed = {row["path"] for row in asyncio.run(Registry(app).call("project.list"))}
        assert {str(other.project), str(gone.project)} <= listed
        shutil.rmtree(gone.project)
        assert asyncio.run(Registry(app).call("project.forget", {"missing": True}))["forgotten"] == [str(gone.project)]
        assert asyncio.run(Registry(app).call("project.forget", {"path": str(other.project)}))["forgotten"] == [str(other.project)]
        assert {row["path"] for row in asyncio.run(Registry(app).call("project.list"))} == {str(app.project)}
        assert other.project.is_dir()
    finally:
        stop_service(home, timeout=5)
