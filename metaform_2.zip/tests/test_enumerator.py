from copy import deepcopy

import pytest

from test_property_applicability import foundation, ref
from test_knowledge_layers import foundation as published_foundation


def composite_fixture():
    snapshot = foundation()
    snapshot['types'] = {}
    definitions = [('code', 'program code', 'Directs execution.'),
                   ('code.installer', None, 'Installs the program.'),
                   ('code.engine', None, 'Provides an engine.'),
                   ('code.engine.game', None, 'Runs the game.'),
                   ('code.bash', None, 'Expresses shell operations.'),
                   ('code.cxx23', None, 'Expresses C++23 operations.')]
    for identifier, display, ef in definitions:
        value = dict(ref('type', identifier), description=identifier, ef=ef,
                     length=2 if identifier == 'code.engine.game' else 1, aliases=[])
        if display:
            value['display_name'] = display
        snapshot['types'][identifier] = value
    snapshot['elements'] = {identifier: dict(ref('element', identifier), name=name,
        description=name, artifact=ref('element', 'project')) for identifier, name in
        [('project', 'repository program code'), ('installer', 'installer'), ('engine', 'game engine')]}
    snapshot['bindings'] = [dict(ref('binding', f'b:{element}:{typ}'), element=ref('element', element), type=ref('type', typ))
        for element, typ in [('project', 'code'), ('installer', 'code.installer'), ('installer', 'code.bash'),
                             ('engine', 'code.engine.game'), ('engine', 'code.cxx23')]]
    snapshot['narrowings'] = [dict(ref('narrowing', 'n:' + identifier), parent=ref('type', identifier.rsplit('.', 1)[0]),
        child=ref('type', identifier), category='function' if identifier in ('code.installer', 'code.engine') else 'encounter',
        reason='Recorded narrowing.') for identifier in snapshot['types'] if '.' in identifier]
    snapshot['refinements'] = []
    snapshot['joins'] = []
    for component, language, facet in [('installer', 'code.bash', 'code.installer'), ('engine', 'code.cxx23', 'code.engine.game')]:
        snapshot['joins'].append(dict(ref('join', component + '-language'), receiver=ref('element', component),
            provider=ref('type', language), provider_type=ref('type', language), role='property',
            classification='language', purpose='Realize this implementation.', is_soft=False))
        snapshot['joins'].append(dict(ref('join', component + '-function'), receiver=snapshot['artifact'],
            provider=ref('element', component), provider_type=ref('type', facet), role='hard dependency',
            classification='functionality', purpose='Receive ' + component + ' functionality.'))
    return snapshot


def test_renderer_keeps_base_and_whole_composite_with_component_origins():
    from metaform.knowledge_tool import render

    snapshot = composite_fixture()
    before = deepcopy(snapshot)
    request = 'the top 3 best practices'
    result = render(snapshot, request, snapshot['artifact'])
    assert list(result['questions'].values()) == [
        request + ' for program code',
        request + ' for repository program code that is part bash installer, and part cxx23 game engine']
    composite = result['entries'][1]
    assert composite['subject'] == snapshot['artifact']
    assert {p['id'] for p in composite['properties']} == {'installer-language', 'engine-language'}
    assert composite['components'] == [
        {'component': ref('element', 'installer'), 'properties': [ref('join', 'installer-language')]},
        {'component': ref('element', 'engine'), 'properties': [ref('join', 'engine-language')]}]
    all_entries = render(snapshot, request)['entries']
    assert {entry['context'] for entry in all_entries} == {'node', 'composite'}
    assert all(entry['subject']['kind'] != 'join' for entry in all_entries)
    assert len(all_entries) == 9
    assert [entry['question'] for entry in all_entries].count(result['questions']['q2_array']) == 1
    assert render(snapshot, request, ref('type', 'code'))['questions'] == result['questions']
    creative = 'the top 6 creative thinking with foresight imperatives'
    other = render(snapshot, creative, snapshot['artifact'])
    assert [q.removeprefix(creative) for q in other['questions'].values()] == [q.removeprefix(request) for q in result['questions'].values()]
    assert [entry['slot'] for entry in other['entries']] == [entry['slot'] for entry in result['entries']]
    assert snapshot == before
    snapshot['joins'].reverse()
    snapshot['types'] = dict(reversed(list(snapshot['types'].items())))
    assert render(snapshot, request, snapshot['artifact']) == result
    snapshot['joins'] = [join for join in snapshot['joins'] if join['id'] != 'engine-language']
    snapshot['elements']['project']['name'] = 'program code'
    assert list(render(snapshot, request)['questions'].values()).count(
        request + ' for program code that is part bash installer') == 1


def test_receiving_relationship_stays_in_component_context_without_an_extra_question():
    from metaform.knowledge_tool import render

    snapshot = foundation()
    snapshot['types']['code.engine.game'] = dict(ref('type', 'code.engine.game'), length=2, description='Game engine', ef='Runs the game')
    snapshot['elements']['player'] = dict(ref('element', 'player'), name='player')
    snapshot['joins'].append(dict(ref('join', 'player-result'), receiver=ref('element', 'player'),
        provider=snapshot['artifact'], provider_type=ref('type', 'code.engine.game'),
        purpose='the enjoyment of the game', role='hard dependency'))
    questions = render(snapshot, 'Use creative thinking with foresight to make the top 6 imperatives')['entries']
    component = next(q for q in questions if q['subject'] == snapshot['artifact'] and q['context'] == 'composite')
    assert ref('join', 'player-result') in component['records']
    assert ref('element', 'player') in component['records']
    assert ref('type', 'code.engine.game') in component['records']
    assert all(q['subject'] != ref('join', 'player-result') for q in questions)


def test_exterior_receivers_do_not_pool_sibling_component_properties():
    from metaform.knowledge_tool import render

    snapshot = composite_fixture()
    snapshot['elements']['operators'] = dict(ref('element', 'operators'), name='operators', boundary='exterior')
    snapshot['elements']['guide'] = dict(ref('element', 'guide'), name='operating guide')
    for provider, facet in [('project', 'code'), ('guide', 'code')]:
        snapshot['joins'].append(dict(ref('join', provider + '-operators'), receiver=ref('element', 'operators'),
            provider=ref('element', provider), provider_type=ref('type', facet), role='hard dependency',
            purpose='Operate the program.'))
    for target in ('operators', 'guide'):
        selected = render(snapshot, 'Explain', ref('element', target))['entries']
        assert len(selected) == 1
        assert selected[0]['context'] == 'node'
        assert selected[0]['properties'] == []
    assert 'bash installer, and part cxx23 game engine' in render(snapshot, 'Explain', snapshot['artifact'])['questions']['q2_array']


def test_property_provider_element_name_is_retained_and_name_changes_reinfer_its_composite(app):
    import json
    from metaform.knowledge_tool import render, start
    from metaform.layers import active_attachments
    from metaform.models import publish_foundation
    from metaform.transform import apply_transformation
    from metaform.workflow import Engine

    snapshot = composite_fixture()
    provider = ref('element', 'installer-shell')
    snapshot['elements'][provider['id']] = provider | {
        'name': 'Bash 5.2', 'description': 'The installer shell realization.', 'artifact': snapshot['artifact']}
    snapshot['bindings'].append(ref('binding', 'installer-shell-type') | {'element': provider, 'type': ref('type', 'code.bash')})
    prop = next(join for join in snapshot['joins'] if join['id'] == 'installer-language')
    prop['provider'] = provider
    request = 'Explain this context'
    rendered = render(snapshot, request, snapshot['artifact'])
    assert rendered['questions']['q2_array'] == request + ' for repository program code that is part Bash 5.2 installer, and part cxx23 game engine'
    assert any(dep.get('target') == provider and dep['fields'] == ['*'] for dep in rendered['entries'][1]['dependencies'])
    self_provider = deepcopy(snapshot)
    next(join for join in self_provider['joins'] if join['id'] == 'installer-language')['provider'] = ref('element', 'installer')
    assert render(self_provider, request, self_provider['artifact'])['questions']['q2_array'] == (
        request + ' for repository program code that is part bash installer, and part cxx23 game engine')

    snapshot = json.loads(json.dumps(snapshot).replace('project:properties', 'project:' + app.project_id))
    snapshot['model'] = {'project': app.project_id, 'model': 'named-property-provider'}
    source = publish_foundation(app, snapshot)
    job = start(app, request, 'Named provider advice', source)
    Engine(app).submit(job['run_id'], job['request_id'], {field: ['Fixture answer'] for field in job['inputs']['questions']})
    Engine(app).next(job['run_id'])
    before = active_attachments(app, source)
    base = next(item for item in before if item['question'] == request + ' for program code')
    old = next(item for item in before if item['subject'] == snapshot['artifact'])
    updated = snapshot['elements'][provider['id']] | {'name': 'Bash 5.3'}
    changed = apply_transformation(app, {'id': 'record-shell-version', 'source': source,
        'destination_model': 'renamed-property-provider', 'purpose': 'Record the changed shell realization.',
        'operations': [{'op': 'update', 'target': {field: updated[field] for field in ('owner', 'kind', 'id')},
                        'record': updated, 'reason': 'The recorded shell version changed.'}]})
    current = active_attachments(app, changed['model'])
    assert next(item for item in current if item['id'] == base['id']) == base
    assert all(item['id'] != old['id'] for item in current)
    regenerated = next(item for item in changed['reinference'] if any(
        context['subject'] == snapshot['artifact'] for context in item['inputs']['contexts'].values()))
    assert list(regenerated['inputs']['questions'].values()) == [
        request + ' for repository program code that is part Bash 5.3 installer, and part cxx23 game engine']


def test_identical_property_names_display_once_but_keep_both_signals_and_dependencies(app):
    import json
    from metaform.knowledge_tool import render, start
    from metaform.layers import active_attachments
    from metaform.models import publish_foundation
    from metaform.transform import apply_transformation
    from metaform.workflow import Engine

    snapshot = composite_fixture()
    snapshot['types']['document'] = ref('type', 'document') | {
        'description': 'An organized expression of information.', 'ef': 'Presents information.', 'length': 1}
    text_type = ref('type', 'document.text')
    snapshot['types']['document.text'] = text_type | {'description': 'A text document presents readable characters.',
        'ef': 'Presents content as readable characters.', 'length': 2}
    snapshot['narrowings'].append(ref('narrowing', 'document-text') | {'parent': ref('type', 'document'),
        'child': text_type, 'category': 'encounter', 'reason': 'The textual document encounter.'})
    installer = ref('element', 'installer')
    snapshot['bindings'].append(ref('binding', 'installer-text') | {'element': installer, 'type': text_type})
    for classification, signal, local in [('encoding', 'ASCII-only source, valid UTF-8.', False),
                                          ('style', 'Expanded source with LF line endings.', True)]:
        snapshot['joins'].append(ref('join', 'installer-' + classification) | {
            'receiver': installer, 'provider': installer, 'provider_type': text_type,
            'role': 'property', 'classification': classification, 'is_soft': local,
            'purpose': 'Keep the source available in its recorded textual realization.', 'signal': signal})
    request = 'Explain this context'
    entry = next(entry for entry in render(snapshot, request)['entries']
                 if entry['subject'] == installer and entry['context'] == 'composite')
    assert entry['question'].count('text document') == 1
    assert {ref('join', name)['id'] for name in ('installer-encoding', 'installer-style')} <= {
        origin['id'] for origin in entry['properties']}
    snapshot = json.loads(json.dumps(snapshot).replace('project:properties', 'project:' + app.project_id))
    snapshot['model'] = {'project': app.project_id, 'model': 'distinct-text-properties'}
    source = publish_foundation(app, snapshot)
    job = start(app, request, 'Text properties', source)
    field = next(field for field, context in job['inputs']['contexts'].items()
                 if context['subject']['id'] == 'installer' and context['context'] == 'composite')
    assert {origin['id'] for origin in job['inputs']['contexts'][field]['properties']} >= {'installer-encoding', 'installer-style'}
    signals = {join['id']: join['signal'] for join in job['inputs']['functional_account']['joins'] if 'signal' in join}
    assert signals['installer-encoding'] == 'ASCII-only source, valid UTF-8.'
    assert signals['installer-style'] == 'Expanded source with LF line endings.'
    Engine(app).submit(job['run_id'], job['request_id'], {key: ['Fixture answer'] for key in job['inputs']['questions']})
    Engine(app).next(job['run_id'])
    before = active_attachments(app, source)
    original = next(item for item in before if item['subject']['id'] == 'installer')
    for name in ('installer-encoding', 'installer-style'):
        assert any(dep.get('target', {}).get('id') == name for dep in original['dependencies'])
    updated = next(join for join in snapshot['joins'] if join['id'] == 'installer-style') | {
        'signal': 'Expanded source with CRLF line endings.'}
    changed = apply_transformation(app, {'id': 'change-source-layout', 'source': source,
        'destination_model': 'changed-text-properties', 'purpose': 'Record the changed textual realization.',
        'operations': [{'op': 'update', 'target': {key: updated[key] for key in ('owner', 'kind', 'id')},
                        'record': updated, 'reason': 'The source layout changed.'}]})
    assert all(item['id'] != original['id'] for item in active_attachments(app, changed['model']))
    regenerated = next(item for item in changed['reinference'] if any(
        context['subject']['id'] == 'installer' for context in item['inputs']['contexts'].values()))
    assert next(iter(regenerated['inputs']['questions'].values())) == original['question']
    assert next(join for join in regenerated['inputs']['functional_account']['joins'] if join['id'] == 'installer-style')['signal'] == updated['signal']


def test_replacing_components_preserves_generic_answer_and_reuses_the_saved_instruction(app, evidence_path=None):
    import asyncio
    import json
    from metaform.layers import active_attachments, inspect_layer
    from metaform.models import capture_model, publish_foundation
    from metaform.registry import Registry
    from metaform.workflow import Engine

    document = json.loads(json.dumps(composite_fixture()).replace('project:properties', 'project:' + app.project_id))
    document['model'] = {'project': app.project_id, 'model': 'mixed-language-code'}
    source = publish_foundation(app, document)
    source_snapshot = capture_model(app, source)
    request = 'the top 3 best practices'
    call = lambda name, arguments: asyncio.run(Registry(app).call(name, arguments))
    job = call('knowledge.start', {'request': request, 'name': 'Best Practices', 'model': source})
    generic_answer = [
        'Write clear, readable code with descriptive names and focused functions.',
        'Test important behavior and edge cases, and verify changes before merging.',
        'Keep code simple, reuse existing solutions, and avoid unnecessary complexity.']
    javascript_answer = [
        'Keep rendering, physics, input, audio, and asset loading in focused modules, with game-specific logic separate from reusable engine code.',
        'Use requestAnimationFrame for rendering and a fixed timestep for simulation; cap catch-up work to handle pauses without freezing.',
        'Test core engine behavior and profile representative scenes; minimize allocations in hot loops and explicitly release unused resources.']
    answers = {field: generic_answer if question == request + ' for program code' else ['Fixture answer: ' + question]
               for field, question in job['inputs']['questions'].items()}
    Engine(app).submit(job['run_id'], job['request_id'], answers)
    completed = Engine(app).next(job['run_id'])
    original = active_attachments(app, source)
    base = next(item for item in original if item['question'] == request + ' for program code')
    composite = next(item for item in original if item['subject'] == document['artifact'])
    assert set(tuple(sorted(item.items())) for item in completed['attachments']) == {
        tuple(sorted({'owner': item['owner'], 'kind': 'knowledge', 'id': item['id']}.items())) for item in original}
    assert all(dep['kind'] == 'record' and dep['target']['kind'] == 'type' for dep in base['dependencies'])
    assert any(dep.get('selector', {}).get('kind') == 'knowledge_tool.context' for dep in composite['dependencies'])
    assert composite['question_context']['components'] == job['inputs']['contexts'][next(
        field for field, context in job['inputs']['contexts'].items() if context['subject'] == document['artifact'])]['components']
    owner = document['artifact']['owner']
    reference = lambda kind, identifier: {'owner': owner, 'kind': kind, 'id': identifier}
    removed = [reference('element', name) for name in ('installer', 'engine')]
    removed += [reference('binding', item['id']) for item in document['bindings'] if item['element']['id'] in ('installer', 'engine')]
    removed += [reference('join', item['id']) for item in document['joins']]
    additions = [
        ('type', reference('type', 'code.JavaScript') | {'description': 'JavaScript program code.', 'ef': 'Expresses JavaScript operations.', 'length': 1, 'aliases': []}),
        ('narrowing', reference('narrowing', 'javascript-narrowing') | {'parent': reference('type', 'code'), 'child': reference('type', 'code.JavaScript'), 'category': 'encounter', 'reason': 'The recorded language.'}),
        ('element', reference('element', 'javascript-engine') | {'name': 'game engine', 'description': 'The replacement game engine.', 'artifact': document['artifact']}),
        ('binding', reference('binding', 'javascript-engine-function') | {'element': reference('element', 'javascript-engine'), 'type': reference('type', 'code.engine.game')}),
        ('binding', reference('binding', 'javascript-engine-language') | {'element': reference('element', 'javascript-engine'), 'type': reference('type', 'code.JavaScript')}),
        ('join', reference('join', 'javascript-language') | {'receiver': reference('element', 'javascript-engine'), 'provider': reference('type', 'code.JavaScript'), 'provider_type': reference('type', 'code.JavaScript'), 'role': 'property', 'classification': 'language', 'purpose': 'Realize this implementation.', 'is_soft': False}),
        ('join', reference('join', 'javascript-function') | {'receiver': document['artifact'], 'provider': reference('element', 'javascript-engine'), 'provider_type': reference('type', 'code.engine.game'), 'role': 'hard dependency', 'classification': 'functionality', 'purpose': 'Receive game-engine functionality.'})]
    patch = {'id': 'replace-bash-cxx-with-javascript', 'source': source, 'destination_model': 'javascript-code',
        'purpose': 'Replace the recorded implementation while retaining the generic program-code definition.',
        'operations': [{'op': 'remove', 'target': target, 'reason': 'The old component is no longer present.'} for target in removed] + [
            {'op': 'add', 'target': reference(kind, record['id']), 'record': record, 'reason': 'Record the replacement component.'} for kind, record in additions]}
    changed = call('model.transform', {'patch': patch})
    active = active_attachments(app, changed['model'])
    assert next(item for item in active if item['id'] == base['id']) == base
    assert all(item['id'] != composite['id'] for item in active)
    regenerated = next(item for item in changed['reinference'] if any(
        context['subject'] == document['artifact'] for context in item['inputs']['contexts'].values()))
    assert regenerated['inputs']['request'] == request
    assert list(regenerated['inputs']['questions'].values()) == [request + ' for repository program code that is part JavaScript game engine']
    assert all(request + ' for program code' not in item['inputs']['questions'].values() for item in changed['reinference'])
    revised = {field: javascript_answer for field in regenerated['inputs']['questions']}
    Engine(app).submit(regenerated['run_id'], regenerated['request_id'], revised)
    assert Engine(app).next(regenerated['run_id'])['status'] == 'complete'
    current = active_attachments(app, changed['model'])
    replacement = next(item for item in current if item['slot'] == composite['slot'])
    assert replacement['payload'] == javascript_answer
    assert replacement['id'] != composite['id']
    assert next(item for item in current if item['id'] == base['id']) == base
    assert inspect_layer(app, completed['layer'], changed['model'])['recipe']['request'] == request
    assert active_attachments(app, source) == original
    assert capture_model(app, source) == source_snapshot
    if evidence_path is not None:
        from pathlib import Path
        Path(evidence_path).write_text(json.dumps({
            'evidence': 'Public knowledge.start and model.transform over an isolated hand-authored fixture. Generic and JavaScript answer arrays were supplied by Rich; Bash/C++ and other answers are explicitly marked fixture data. No model inference or MGM dataset mutation.',
            'request': request, 'source': source, 'destination': changed['model'],
            'patch': patch, 'generic_answer_before_and_after': base,
            'original_composite': composite, 'replacement_composite': replacement,
            'rerendered_questions': regenerated['inputs']['questions'],
            'rerendered_contexts': regenerated['inputs']['contexts'],
            'impact': changed['impact'], 'produced_knowledge': completed['attachments'],
            'verified': {'generic_answer_unchanged': True, 'old_composite_inactive': True,
                         'new_composite_same_slot': True, 'source_foundation_and_answers_unchanged': True,
                         'saved_request_unchanged': True}}, indent=2) + '\n')


@pytest.mark.parametrize('change', ['add_property', 'first_property', 'remove_all_properties'])
def test_property_membership_changes_invalidate_only_composites_and_absent_composites_need_no_inference(app, change):
    import json
    from metaform.knowledge_tool import start
    from metaform.layers import active_attachments
    from metaform.models import publish_foundation
    from metaform.transform import apply_transformation
    from metaform.workflow import Engine

    document = json.loads(json.dumps(composite_fixture()).replace('project:properties', 'project:' + app.project_id))
    document['model'] = {'project': app.project_id, 'model': 'mixed-language-code'}
    properties = [item for item in document['joins'] if item['role'] == 'property']
    if change == 'first_property':
        document['joins'] = [item for item in document['joins'] if item['role'] != 'property']
    source = publish_foundation(app, document)
    request = 'Describe {{ literal context }} creatively'
    job = start(app, request, 'Literal context', source)
    Engine(app).submit(job['run_id'], job['request_id'], {field: ['Fixture answer'] for field in job['inputs']['questions']})
    Engine(app).next(job['run_id'])
    original = active_attachments(app, source)
    base = next(item for item in original if item['question'] == request + ' for program code')
    composite = next((item for item in original if item['subject'] == document['artifact']), None)
    if change in ('add_property', 'first_property'):
        record = deepcopy(properties[0])
        record['id'] = 'additional-engine-language'
        record['receiver'] = document['artifact'] | {'id': 'engine'}
        operations = [{'op': 'add', 'target': {field: record[field] for field in ('owner', 'kind', 'id')},
                       'record': record, 'reason': 'Add a newly recorded component property.'}]
    else:
        operations = [{'op': 'remove', 'target': {field: record[field] for field in ('owner', 'kind', 'id')},
                       'reason': 'The property is no longer present.'} for record in properties]
    changed = apply_transformation(app, {'id': change, 'source': source, 'destination_model': change,
                                        'purpose': 'Record changed property membership.', 'operations': operations})
    current = active_attachments(app, changed['model'])
    assert next(item for item in current if item['id'] == base['id']) == base
    assert composite is None or all(item['id'] != composite['id'] for item in current)
    if change in ('add_property', 'first_property'):
        regenerated = next(item for item in changed['reinference'] if any(
            context['subject'] == document['artifact'] for context in item['inputs']['contexts'].values()))
        expected_context = ('bash and cxx23 game engine, and part bash installer' if change == 'add_property' else 'bash game engine')
        assert list(regenerated['inputs']['questions'].values()) == [
            request + ' for repository program code that is part ' + expected_context]
        if composite:
            assert any(reason.get('selector', {}).get('kind') == 'knowledge_tool.context'
                       for decision in changed['impact']['decisions'] if decision['target']['id'] == composite['id']
                       for reason in decision['reasons'])
        assert all(request + ' for program code' not in item['inputs']['questions'].values() for item in changed['reinference'])
    else:
        assert changed['reinference'] == []
        assert all(item['question_context']['context'] == 'node' for item in current)


def test_nonce_delivers_exact_enumeration_and_answers_attach_without_model_chosen_mapping(app, published_foundation):
    from pathlib import Path
    from metaform.app import App
    from metaform.continuation import marker, begin
    from metaform.knowledge_tool import preview, start
    from metaform.layers import inspect_layer
    from metaform.registry import Registry
    from metaform.workflow import Engine

    request = 'Write 3 best practices. Preserve {{ literal words }}'
    rendered = preview(app, request, published_foundation)
    job = start(app, request, 'Best Practices', published_foundation)
    assert job['role'] == 'knowledge-tool'
    assert job['inputs']['questions'] == rendered['questions']
    assert job['schema'] == rendered['schema']
    assert job['inputs']['functional_account']['model'] == rendered['model']
    assert job['inputs']['functional_account']['understanding']
    assert set(job['inputs']['contexts']) == set(rendered['questions'])
    assert all(job['inputs']['contexts'][entry['field']]['records'] == entry['records'] for entry in rendered['entries'])
    assert job['prompt'] == job['source_prompt']
    folder = Path(job['workfolder'])
    assert marker(folder) is None
    retrieved = begin(job['nonce'], folder=folder, home=app.home)
    assert retrieved['prompt'] == job['prompt']
    assert retrieved['schema'] == rendered['schema']
    assert marker(folder)['nonce'] == job['nonce'] and not (folder / '.agentid').exists()
    bound = App(folder, app.home)
    commands = Registry(bound).visible()
    assert 'workflow.answer' in commands
    assert 'knowledge.start' not in commands
    assert 'workflow.start' not in commands
    answers = {field: [question, field, 'Contract test response'] for field, question in rendered['questions'].items()}
    import asyncio
    receipt = asyncio.run(Registry(bound).call('workflow.answer', {'answer': answers}))
    assert receipt['recorded']
    assert not folder.exists()
    result = Engine(app).next(job['run_id'])
    assert result['status'] == 'complete'
    assert result['coverage'] == {'completed': len(answers), 'pending': 0, 'missing': []}
    saved = inspect_layer(app, result['layer'], published_foundation)
    assert saved['layer']['name'] == 'Best Practices'
    attachments = {a['slot']: a for a in saved['attachments']}
    for entry in rendered['entries']:
        attached = attachments[entry['slot']]
        assert attached['payload'] == answers[entry['field']]
        assert attached['subject'] == entry['subject']
        assert attached['question'] == entry['question']

    from metaform.layers import regenerate_layer, active_attachments
    subject = rendered['entries'][0]['subject']
    regenerated = regenerate_layer(app, result['layer'], published_foundation, target=subject)
    assert regenerated['role'] == 'knowledge-tool'
    from metaform.knowledge_tool import render
    from metaform.models import capture_model
    selected = render(capture_model(app, published_foundation), request, subject)['entries']
    assert list(regenerated['inputs']['questions'].values()) == [entry['question'] for entry in selected]
    revised = {field: ['Revised contract response'] for field in regenerated['inputs']['questions']}
    Engine(app).submit(regenerated['run_id'], regenerated['request_id'], revised)
    assert Engine(app).next(regenerated['run_id'])['status'] == 'complete'
    assert len(active_attachments(app, published_foundation)) == len(answers)
