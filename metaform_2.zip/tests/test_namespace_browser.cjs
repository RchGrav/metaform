const assert=require('node:assert/strict');
const {test,before,after}=require('node:test');
const {resolve}=require('node:path');
const {chromium}=require('playwright');

let browser;
before(async()=>{browser=await chromium.launch({headless:true});});
after(async()=>{await browser?.close();});

const envelope=(ids,cursor=null)=>({records:ids.map(id=>({ref:{owner:'fixture',kind:'type',id},value:{display_name:id},counts:{direct:1,descendant:0}})),coverage:{next_cursor:cursor},diagnostics:[]});
async function fixture(t,category='',cursor=null){
  const page=await browser.newPage();page.setDefaultTimeout(1500);t.after(()=>page.close());
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  await page.setContent('<main id="namespace"></main>');
  await page.addScriptTag({path:resolve(__dirname,'../src/metaform/static/namespace-browser.js')});
  await page.evaluate(category=>{
    window.calls=[];window.waiting=[];window.selected=[];
    window.namespace=new MetaformNamespaceBrowser(document.querySelector('main'),{
      state:{expanded:[],category},select:ref=>selected.push(ref),
      read:(operation,args)=>{calls.push({operation,args});return new Promise((resolve,reject)=>waiting.push({resolve,reject}));}
    });
    namespace.load().catch(error=>{window.loadError=error.message;});
  },category);
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['code'],cursor));
  await page.locator('[role=treeitem]').waitFor();
  return {page,errors,row:page.locator('[role=treeitem]').first(),toggle:page.locator('.namespace-expand').first()};
}

test('a failed namespace expansion retries and clears its loading/error state',async t=>{
  const {page,errors,row,toggle}=await fixture(t);
  await toggle.click();
  await page.evaluate(()=>waiting.shift().reject(new Error('Fixture read failed')));
  await page.getByText('Fixture read failed',{exact:true}).waitFor();
  await toggle.click();
  await page.waitForFunction(()=>calls.length===3);
  assert.equal(await row.getAttribute('aria-busy'),'true');
  assert(await row.getByText('Loading Types…',{exact:true}).isVisible());
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['code.clock']));
  await page.getByText('code.clock',{exact:true}).waitFor();
  assert.equal(await row.getAttribute('aria-expanded'),'true');
  assert.equal(await row.getAttribute('aria-busy'),null);
  assert.equal(await page.locator('.semantic-error').count(),0);
  assert.deepEqual(errors,[]);
});

test('rapid expand and collapse keeps one load and retains the resulting children',async t=>{
  const {page,errors,row,toggle}=await fixture(t);
  await toggle.click();await toggle.click();
  assert.equal(await row.getAttribute('aria-expanded'),'false');
  assert.equal(await page.evaluate(()=>calls.length),2);
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['code.clock']));
  await page.waitForFunction(()=>document.querySelectorAll('[role=treeitem]').length===2);
  assert(await row.locator('[role=group]').isHidden());
  await toggle.click();
  assert(await page.getByText('code.clock',{exact:true}).isVisible());
  assert.equal(await page.evaluate(()=>calls.length),2);
  assert.equal(await page.locator('[role=treeitem]').count(),2);
  const child=page.locator('[role=treeitem]').nth(1),childToggle=child.locator('.namespace-expand');
  await childToggle.click();await childToggle.click();await childToggle.click();
  assert.equal(await page.evaluate(()=>calls.length),3);
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['code.clock.display']));
  await page.getByText('code.clock.display',{exact:true}).waitFor();
  assert.equal(await child.getAttribute('aria-expanded'),'true');
  assert.equal(await page.evaluate(()=>calls.length),3);
  await page.getByText('code.clock',{exact:true}).click();
  assert.equal(await page.evaluate(()=>selected[0].id),'code.clock');
  assert.deepEqual(errors,[]);
});

test('root pagination retains its original unfiltered selection and can retry',async t=>{
  const {page,errors}=await fixture(t,'function','root-page-2');
  assert.equal(await page.evaluate(()=>calls[0].args.category),undefined);
  await page.getByRole('button',{name:'More Types',exact:true}).click();
  const first=await page.evaluate(()=>calls[1].args);
  assert.equal(first.category,undefined,'Root cursor must use the original root query');
  assert.equal(first.cursor,'root-page-2');
  await page.evaluate(()=>waiting.shift().reject(new Error('Page read failed')));
  await page.getByText('Page read failed',{exact:true}).waitFor();
  await page.getByRole('button',{name:'More Types',exact:true}).click();
  assert.deepEqual(await page.evaluate(()=>calls[2].args),first);
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['document']));
  await page.getByText('document',{exact:true}).waitFor();
  assert.equal(await page.locator('[role=treeitem]').count(),2);
  assert.equal(await page.locator('.semantic-error').count(),0);
  assert.deepEqual(errors,[]);
});

test('a failed detached expansion cannot erase the replacement tree state',async t=>{
  const {page,errors,toggle}=await fixture(t);
  await toggle.click();
  await page.evaluate(()=>{namespace.load().catch(error=>{window.loadError=error.message;});});
  await page.evaluate(result=>waiting.pop().resolve(result),envelope(['code']));
  await page.waitForFunction(()=>calls.length===4);
  await page.evaluate(()=>waiting.shift().reject(new Error('Obsolete expansion failed')));
  await page.evaluate(result=>waiting.shift().resolve(result),envelope(['code.clock']));
  await page.getByText('code.clock',{exact:true}).waitFor();
  const row=page.locator('[role=treeitem]').first();
  assert.equal(await row.getAttribute('aria-expanded'),'true');
  assert(await page.evaluate(()=>namespace.state.expanded.includes(document.querySelector('[role=treeitem]').dataset.key)));
  assert.equal(await page.locator('.semantic-error').count(),0);
  assert.deepEqual(errors,[]);
});
