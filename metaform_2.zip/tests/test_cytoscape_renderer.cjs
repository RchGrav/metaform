const {test}=require('node:test');
const assert=require('node:assert/strict');
const {cytoscapeElements,initialFocus}=require('../src/metaform/static/cytoscape-view.js');
const node=(id,type_id,en=id)=>({id,type_id,kind:'element',band:'functional',entity_json_obj:{type_id,en,ef:'Actual behavior of '+en}});
test('Cytoscape keeps actual identity and classification while retaining full inspection detail',()=>{
  const nodes=[node('first','code.interface','Gateway controls'),node('second','code.interface','Monitor observations')];
  const result=cytoscapeElements({nodes,edges:[]},true,false);
  assert.deepEqual(result.map(n=>n.data.id),['first','second']);
  for(const n of result){assert(n.data.label.includes('code.interface'));assert(n.data.accessible_label.includes('Actual behavior'));assert(!n.data.label.includes('Actual behavior'));}
});
test('Cytoscape preserves provider direction, role, OP and reified join identities',()=>{
  const nodes=[node('a','code.interface'),node('b','code.manager'),{id:'meeting',kind:'join',join:{type:'supportive',purpose:'Combine support'}}];
  const join={id:'requirement',type:'hard dependency',purpose:'Control gateway routes'};
  const scene={nodes,edges:[{source:'a',target:'b',join_id:'requirement',kind:'purpose',directed:true,join},{source:'meeting',target:'a',join_id:'meeting',kind:'participant',directed:false,join:{type:'supportive'}}]};
  const elements=cytoscapeElements(scene,true,false),edge=elements.find(e=>e.data.join_id==='requirement');
  assert.equal(edge.data.source,'a');assert.equal(edge.data.target,'b');assert.equal(edge.data.label,'Join');assert.equal(edge.data.join.type,'hard dependency');assert.equal(edge.data.purpose_label,'Control gateway routes');assert.equal(edge.data.arrow,'triangle');
  assert(elements.some(n=>n.data.id==='meeting'));
  assert.equal(elements.find(e=>e.data.join_id==='meeting').data.arrow,'none');
});
test('a reified join uses its declared classification color and label',()=>{
  const {setJoinClassifications}=require('../src/metaform/static/structure.js'),taxonomy=require('../src/metaform/static/join-classifications.json');
  setJoinClassifications(taxonomy);
  const join={id:'meeting',role:'property',classification:'language',is_soft:true,purpose:'Represent the recorded implementation.'};
  const [result]=cytoscapeElements({nodes:[{id:'meeting',kind:'join',join}],edges:[]},true,false);
  assert.equal(result.data.color,taxonomy.property.language.color);assert(result.data.label.includes(taxonomy.property.language.emoji));
  assert.equal(result.data.record.join,join);setJoinClassifications({});
});
test('unique actual Defining Element opens first; several remain unselected',()=>{
  const first=node('gateway','code.manager');first.entity_json_obj.defining_element=true;
  assert.equal(initialFocus([first,node('interface','code.interface')]),'gateway');
  const second=node('monitor','code.monitor');second.entity_json_obj.defining_element=true;
  assert.equal(initialFocus([first,second]),null);
});
test('vendored Cytoscape and Dagre position real relationships and cycles without losing nodes',()=>{
  const cytoscape=require('../src/metaform/static/vendor/cytoscape.min.js');
  cytoscape.use(require('../src/metaform/static/vendor/cytoscape-dagre.js'));
  const {stylesheet}=require('../src/metaform/static/cytoscape-view.js');
  const nodes=['a','b','c'].map(id=>node(id,'code.interface'));
  const edges=[['a','b'],['b','c'],['c','b']].map(([source,target],i)=>({source,target,join_id:'j'+i,join:{id:'j'+i,type:'hard dependency'},directed:true}));
  const cy=cytoscape({headless:true,styleEnabled:true,elements:cytoscapeElements({nodes,edges}),style:stylesheet()});
  try{
    cy.layout({name:'dagre',rankDir:'LR',nodeDimensionsIncludeLabels:true,useDagreEdgeControlPoints:true}).run();
    assert.equal(cy.nodes().length,3);assert.equal(cy.edges().length,3);
    assert(cy.getElementById('a').position('x')<cy.getElementById('b').position('x'));
    assert(cy.edges().some(e=>e.source().id()==='c'&&e.target().id()==='b'));
    assert(cy.nodes().every(n=>Number.isFinite(n.position('x'))&&Number.isFinite(n.position('y'))));
  }finally{cy.destroy();}
});
test('multiple Type memberships and authored SVG merge into one actual node with its own description',()=>{
  const svg='<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><path d="M10 10H70V70H10Z" fill="#a5dec7"/></svg>';
  const record={id:'control',kind:'element',band:'functional',type_ids:['code.interface','code.monitor'],entity_json_obj:{en:'Control surface',type_ids:['code.interface','code.monitor'],description:'Shows current connectivity and accepts route commands.',ef:'Generic interface behavior'},type_records:[{id:'code.interface',entity_json_obj:{svg}},{id:'code.monitor',entity_json_obj:{svg:'<svg xmlns="http://www.w3.org/2000/svg"/>'}}]};
  const elements=cytoscapeElements({nodes:[record],edges:[]},true);
  assert.equal(elements.length,1);assert.equal(elements[0].data.id,'control');
  assert.deepEqual(elements[0].data.type_ids,['code.interface','code.monitor']);
  assert(elements[0].data.accessible_label.includes('Shows current connectivity and accepts route commands.'));
  assert(!elements[0].data.label.includes('Generic interface behavior'));
  assert(elements[0].data.label.includes('code.interface'));assert(elements[0].data.label.includes('code.monitor'));
  assert(elements[0].data.svg_image.startsWith('data:image/svg+xml;utf8,'));
  assert(decodeURIComponent(elements[0].data.svg_image.split(',')[1]).endsWith(svg));
  assert(elements[0].classes.includes('artwork'));
  assert.equal(initialFocus([{...record,entity_json_obj:{...record.entity_json_obj,defining_element:true}}]),'control');
});
test('structured actual descriptions survive in accessible inspection detail',()=>{
  const record={id:'photo',type_ids:['media.photo'],entity_json_obj:{en:'Donkey on the trail',type_ids:['media.photo'],description:{subject:'Donkey and its handler',setting:'Canyon trail'}}};
  const [element]=cytoscapeElements({nodes:[record],edges:[]});
  assert(element.data.accessible_label.includes('subject: Donkey and its handler'));assert(element.data.accessible_label.includes('setting: Canyon trail'));assert(!element.data.label.includes('{'));assert(!element.data.label.includes('\"'));
});
test('freeform actual record renders before classification without inventing a Type',()=>{
  const actual={id:'trail-photo',entity_schema:'metaform:actual-element',entity_json_obj:{en:'Donkey on the trail',description:'A donkey and handler descend a canyon trail.',defining_element:true}};
  const [element]=cytoscapeElements({nodes:[actual],edges:[]});
  assert(element.classes.includes('actual'));assert.deepEqual(element.data.type_ids,[]);
  assert.equal(element.data.label,'Donkey on the trail');assert(element.data.accessible_label.includes('A donkey and handler'));
  assert.equal(initialFocus([actual]),'trail-photo');
});
test('dense neighborhoods retain every node and join but defer OP and description text to inspection',()=>{
  const nodes=Array.from({length:13},(_,i)=>node('n'+i,'code.interface','Interface '+i));
  const edges=nodes.slice(1).map((n,i)=>({source:n.id,target:'n0',join_id:'j'+i,join:{id:'j'+i,type:'hard dependency',purpose:'Provide the behavior required by receiver '+i},directed:true}));
  const elements=cytoscapeElements({nodes,edges}),cards=elements.filter(e=>!e.data.source),links=elements.filter(e=>e.data.source);
  assert.equal(cards.length,13);assert.equal(links.length,12);
  assert(cards.every(n=>!n.data.label.includes('Actual behavior')));
  assert(links.every(e=>e.data.label===''));
  assert(links.every(e=>e.data.purpose_label.startsWith('Provide the behavior')));
});
test('SVG currentColor receives a display palette without changing authored SVG or overriding its color',()=>{
  const base='<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><path d="M10 10H70V70H10Z" fill="none" stroke="currentColor"/></svg>';
  function rendered(svg){const actual=node('control','code.interface');actual.type_records=[{id:'code.interface',entity_json_obj:{svg}}];const [element]=cytoscapeElements({nodes:[actual],edges:[]});assert.equal(actual.type_records[0].entity_json_obj.svg,svg);return decodeURIComponent(element.data.svg_image.split(',')[1]);}
  assert(rendered(base).includes('color="#99dcc5"'));
  for(const attribute of ['color="#ff8844"','style="color: #ff8844; stroke-width: 3"']){
    const colored=base.replace('<svg ','<svg '+attribute+' '),display=rendered(colored);
    assert(display.includes(attribute));assert(!display.includes('#99dcc5'));
  }
  assert(rendered(base.replace('<svg ','<svg style="background-color: #111;" ')).includes('color="#99dcc5"'));
});
test('viewBox-only SVGs gain display dimensions while authored dimensions remain unchanged',()=>{
  const base='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 48"><rect x="4" y="4" width="56" height="40"/></svg>';
  function rendered(svg){const actual=node('control','code.interface');actual.type_records=[{id:'code.interface',entity_json_obj:{svg}}];const [element]=cytoscapeElements({nodes:[actual],edges:[]});assert.equal(actual.type_records[0].entity_json_obj.svg,svg);return decodeURIComponent(element.data.svg_image.split(',')[1]);}
  const display=rendered(base),root=display.match(/<svg\b[^>]*>/)[0];
  assert(root.includes('width="64"'));assert(root.includes('height="48"'));
  const explicit=base.replace('<svg ','<svg width="128" height="96" ');assert(rendered(explicit).endsWith(explicit));
  const styled=base.replace('<svg ','<svg style="width:128px;height:96px" ');assert(rendered(styled).endsWith(styled));
});
