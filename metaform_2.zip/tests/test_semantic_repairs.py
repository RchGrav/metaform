import asyncio
import base64
import copy
import hashlib
import pytest

from metaform.intake import Intake
from metaform.models import capture_model, publish_foundation
from metaform.registry import Registry
from metaform.workflow import Engine
from test_foundation_intake import contribution
from test_model_transformations import foundation, generate_advice


def call(app, command, **arguments):
    return asyncio.run(Registry(app).call(command, arguments))


def test_retained_intake_handoff_refreshes_launcher_without_reissuing(app, monkeypatch):
    from metaform import continuation

    job = Intake(app).start()
    run = app.load_run(job['run_id'])
    run['pending']['begin'] = 'retired-probe.py begin ' + job['nonce']
    app.save_run(run)
    saved = copy.deepcopy(run)
    monkeypatch.setattr(continuation, 'launcher', lambda: 'current-metaform')
    for request in (None, job['request_id']):
        resumed = Intake(app).next(job['run_id'], request)
        assert resumed == saved['pending'] | {'begin': 'current-metaform begin ' + job['nonce']}
        assert app.load_run(job['run_id']) == saved


def test_intake_bound_completion_publishes_and_retains_accumulated_annotations(app):
    from metaform.app import App
    from metaform.continuation import begin

    job = Intake(app).start()
    begin(job['nonce'], folder=app.project, home=app.home)
    worker = App(app.project, app.home)
    graph = contribution(app)
    graph['elements']['document.guide']['ef'] = 1
    recorded = call(worker, 'intake.put', graph=graph)
    assert 'annotations' not in recorded
    observed = app.load_run(job['run_id'])['submissions'][0]['annotations']
    assert observed
    receipt = call(worker, 'intake.answer', answer={})
    assert 'annotations' not in receipt
    result = call(worker, receipt['next'], run_id=job['run_id'])
    assert result['status'] == 'complete'
    assert result['annotations'] == observed
    saved = capture_model(app, result['model'])
    assert saved['types']['document.guide']['ef'] == '', 'the answer is made to fit the shape'
    assert any(note.get('code') == 'missing_field' and note.get('field') == 'ef' for note in observed)
    assert result['diagnostics'] == saved['diagnostics']
    assert call(worker, receipt['next'], run_id=job['run_id']) == result


def test_intake_binary_read_returns_lossless_artifact_and_retained_description(app):
    png = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+X0XcAAAAASUVORK5CYII=')
    (app.project / 'photo.png').write_bytes(png)
    job = Intake(app).start()
    result = call(app, 'intake.read', path='photo.png', description='A one-pixel photographic fixture.')
    assert result['mime_type'] == 'image/png'
    assert result['size'] == len(png)
    assert result['sha256'] == hashlib.sha256(png).hexdigest()
    assert base64.b64decode(result['data']) == png
    assert result['dimensions'] == {'width': 1, 'height': 1}
    Intake(app).submit(job['run_id'], job['request_id'], contribution(app))
    published = capture_model(app, Intake(app).next(job['run_id'])['model'])
    evidence = published['activities'][0]['source_evidence'][0]
    assert evidence['description'] == result['description']
    assert evidence['revision'] == result['sha256']
    assert base64.b64decode(evidence['data']) == png


def test_design_reads_causally_reach_generated_attachment_impact(app):
    from metaform.layers import active_attachments, create_layer
    from metaform.transform import apply_transformation

    original = foundation(app)
    source = publish_foundation(app, original)
    subject = original['artifact']
    remote = {'owner': subject['owner'], 'kind': 'element', 'id': 'demo:installer'}
    job = create_layer(app, 'Explain the engine in its delivery context.', subject, source)
    read = call(app, 'workflow.get', run_id=job['run_id'], target=remote)
    schema = {'$id': 'urn:test:causal-advice', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string'}
    Engine(app).submit(job['run_id'], job['request_id'], {'name': 'Engine guidance', 'schema_ref': schema['$id'],
        'schema': schema, 'selector': {'kind': 'target', 'target': subject},
        'groups': [{'subjects': [subject], 'purpose': 'Account for the installer delivery context.'}]})
    generated = Engine(app).next(job['run_id'])
    Engine(app).submit(generated['run_id'], generated['request_id'], {'attachments': [{
        'subject': subject, 'schema_ref': schema['$id'], 'payload': 'Advice depends on delivery.',
        'slot': 'advice', 'applicability': {'scope': {'kind': 'direct', 'target': subject}, 'reason': 'Delivery dependency.'}}]})
    Engine(app).next(job['run_id'])
    attachment = active_attachments(app, source)[0]
    assert all(item in attachment['dependencies'] for item in read['dependencies'])
    changed = apply_transformation(app, {'id': 'change-installer', 'source': source,
        'destination_model': 'new-delivery', 'purpose': 'Record a changed delivery operation.', 'mapping': [],
        'operations': [{'op': 'update', 'target': remote,
            'record': original['elements']['demo:installer'] | {'description': 'A different delivery process.'},
            'reason': 'Delivery process changed.'}]})
    assert changed['impact']['decisions'][0]['action'] == 'regenerate'


def test_compare_uses_recorded_mapping_for_attachment_impact(app):
    from metaform.transform import apply_transformation

    original = foundation(app)
    source = publish_foundation(app, original)
    old = original['bindings'][0]['type']
    new = old | {'id': 'code.cxx'}
    generate_advice(app, source, original['artifact'], 'Describe engine operations.')
    moved = apply_transformation(app, {'id': 'rename-implementation', 'source': source,
        'destination_model': 'renamed', 'purpose': 'Relocate without changing meaning.',
        'operations': [{'op': 'relocate', 'target': old, 'replacement': new, 'reason': 'Same meaning.'}],
        'mapping': [{'from': old, 'to': new, 'meaning_preserved': True, 'reason': 'Same meaning.'}]})
    result = call(app, 'model.compare', source=source, destination=moved['model'])
    assert result['layer_impact']['decisions'] == moved['impact']['decisions']
    assert result['layer_impact']['effective_mapping'] == moved['effective_mapping']


def test_clone_replay_keeps_original_activity_when_purpose_changes(app):
    source = publish_foundation(app, foundation(app))
    first = call(app, 'model.clone', source=source, destination_model='copy', purpose='Original purpose.')
    repeated = call(app, 'model.clone', source=source, destination_model='copy', purpose='Later wording.')
    assert repeated['model'] == first['model']
    saved = capture_model(app, repeated['model'])
    assert saved['activities'][-1]['transformation']['purpose'] == 'Original purpose.'


def test_removed_layer_retains_public_inspection(app):
    from metaform.layers import regenerate_layer, remove_layer

    source = publish_foundation(app, foundation(app))
    layer = generate_advice(app, source, capture_model(app, source)['artifact'], 'Retain this recipe.')
    before = call(app, 'layer.inspect', model=source, target=layer)
    variant = call(app, 'model.clone', source=source, destination_model='variant')['model']
    remove_layer(app, layer, source)
    regenerate_layer(app, layer, variant)
    after = call(app, 'layer.inspect', model=source, target=layer)
    assert after['layer_context']['removed'] is True
    assert after['layer_context']['recipe'] == before['layer_context']['recipe']
    assert after['layer_context']['attachments'] == before['layer_context']['attachments']


def test_enumerator_uses_recorded_root_name_without_code_substitution():
    from metaform.knowledge_tool import render
    from test_property_applicability import foundation as sample

    snapshot = sample()
    snapshot['types']['code']['display_name'] = 'Executable instructions'
    snapshot['types']['code.engine']['length'] = 2
    result = render(snapshot, 'Preserve {{this}} instruction')
    assert any(item['question'] == 'Preserve {{this}} instruction for engine Executable instructions' for item in result['entries'])
    del snapshot['types']['code']['display_name']
    result = render(snapshot, 'Preserve {{this}} instruction')
    assert any(item['question'] == 'Preserve {{this}} instruction for code' for item in result['entries'])
    assert all('program code' not in item['question'] for item in result['entries'])


def test_enumerator_regeneration_resumes_missing_fields_only(app):
    from metaform.knowledge_tool import start
    from metaform.layers import active_attachments

    source = publish_foundation(app, foundation(app))
    job = start(app, 'Explain this operation.', 'Guidance', source)
    fields = list(job['inputs']['questions'])
    Engine(app).submit(job['run_id'], job['request_id'], {fields[0]: ['Already completed.']})
    completed = Engine(app).next(job['run_id'])
    saved = copy.deepcopy(active_attachments(app, source))
    resumed = call(app, 'layer.regenerate', layer=completed['layer'], model=source)
    assert list(resumed['inputs']['questions']) == fields[1:]
    Engine(app).submit(resumed['run_id'], resumed['request_id'], {field: ['Recovered.'] for field in fields[1:]})
    assert Engine(app).next(resumed['run_id'])['coverage']['pending'] == 0
    assert saved[0] in active_attachments(app, source)
    assert len(active_attachments(app, source)) == len(fields)


def test_registered_schema_without_dialect_does_not_break_answer_annotations(app):
    from metaform import schemas

    authored = {'$id': 'urn:test:implicit-dialect', 'type': 'integer'}
    schemas.register(app, authored)
    assert schemas.registry(app)[authored['$id']] == authored
    notes = schemas.annotations(app, {'$ref': authored['$id']}, 'retained answer')
    assert notes and notes[0]['path'] == []
    assert schemas.annotations(app, {'$ref': authored['$id']}, 3) == []
    assert schemas.registry(app)[authored['$id']] == authored


def test_property_purpose_survives_intake_correction_and_prepared_context(app):
    from metaform.layers import create_layer
    from metaform.transform import apply_transformation

    job = Intake(app).start()
    receipt = Intake(app).submit(job['run_id'], job['request_id'], contribution(app))
    assert 'annotations' not in receipt
    published = Intake(app).next(job['run_id'])['model']
    shallow = capture_model(app, published)['joins'][0]
    target = {'owner': shallow['owner'], 'kind': 'join', 'id': shallow['id']}
    as_property = shallow | {'role': 'property', 'purpose': 'Realize this implementation medium.'}
    source = apply_transformation(app, {'id': 'deepen-property', 'source': published,
        'destination_model': 'deepened', 'purpose': 'Deep intake records the property.', 'mapping': [],
        'operations': [{'op': 'update', 'target': target, 'record': as_property,
            'reason': 'Deep intake names the medium as a property of this element.'}]})['model']
    before = capture_model(app, source)
    original = before['joins'][0]
    assert original == as_property
    replacement = original | {'purpose': 'Present the result.', 'evidence': [{'source': 'The owner clarified its use.'}]}
    result = apply_transformation(app, {'id': 'clarify-property', 'source': source,
        'destination_model': 'clarified', 'purpose': 'Correct the recorded property meaning.', 'mapping': [],
        'operations': [{'op': 'update', 'target': target, 'record': replacement,
            'reason': 'The source relationship described presentation rather than realization medium.'}]})
    after = capture_model(app, result['model'])
    assert capture_model(app, source)['joins'][0]['purpose'] == 'Realize this implementation medium.'
    assert after['joins'][0] == replacement
    assert after['activities'][-1]['transformation']['operations'][0]['reason'].startswith('The source relationship')
    prepared = create_layer(app, 'Explain this relationship.', target, result['model'])
    assert next(item['value'] for item in prepared['inputs']['region']['records'] if item['ref'] == target) == replacement


def test_intake_search_and_publication_preserve_recorded_namespace_ancestors(app):
    root = {'entity_schema': 'metaform:element', 'entity_desc': 'The recorded universal document definition.',
            'entity_json_obj': {'ef': 'Recorded document encounter.', 'length': 1, 'aliases': []}}
    app.global_graph.put({'elements': {'document': root}}, 'authored')
    job = Intake(app).start()
    context = call(app, 'intake.get', id='document', owner='global')
    assert any(item['ref']['id'] == 'document' for item in context['records'])
    Intake(app).put(job['run_id'], contribution(app))
    Intake(app).submit(job['run_id'], job['request_id'], {})
    model = Intake(app).next(job['run_id'])['model']
    published = capture_model(app, model)
    assert published['types']['document']['description'] == root['entity_desc']
    assert not any(item['code'] == 'unresolved_namespace_position' and item['id'] == 'document'
                   for item in call(app, 'namespace.browse', model=model)['diagnostics'])


def test_enumerator_includes_recorded_participant_relationship_context():
    from metaform.knowledge_tool import render
    from metaform.read_model import read_snapshot
    from test_property_applicability import foundation as sample, ref

    snapshot = sample()
    observer = ref('element', 'other')
    join = next(item for item in snapshot['joins'] if item['id'] == 'j:project:engine')
    join['participants'] = [{'ref': observer, 'role': 'observer'}]
    neighbors = read_snapshot(snapshot, 'graph.neighbors', {'target': observer})
    assert any(item['ref']['id'] == join['id'] for item in neighbors['records'])
    enumeration = render(snapshot, 'Explain this context')
    matching = [entry for entry in enumeration['entries'] if entry['context'] == 'composite'
                and ref('join', join['id']) in entry['relationships'] and observer in entry['records']]
    assert matching
    assert all(entry['context'] != 'participant' for entry in enumeration['entries'])


def test_enumerator_reports_exact_work_size_without_truncating_questions(app):
    import json
    from metaform.knowledge_tool import preview, start

    model = publish_foundation(app, foundation(app))
    rendered = preview(app, 'Explain every context.', model)
    assert rendered['statistics']['questions'] == len(rendered['questions'])
    assert rendered['statistics']['question_bytes'] == len(json.dumps(rendered['questions'], ensure_ascii=False).encode('utf-8'))
    assert rendered['statistics']['schema_bytes'] == len(json.dumps(rendered['schema'], ensure_ascii=False).encode('utf-8'))
    summary = call(app, 'knowledge.preview', request='Explain every context.', model=model, summary=True)
    assert summary['statistics']['questions'] == len(rendered['questions'])
    assert 'questions' not in summary
    job = start(app, 'Explain every context.', 'Guidance', model)
    assert job['knowledge_statistics'] == rendered['statistics']
    assert job['inputs']['questions'] == rendered['questions']


def test_intake_completed_guidance_uses_installed_guide_without_absent_features(app, monkeypatch):
    discovered = Registry.discover
    removed = {'knowledge-tool', 'analysis'}
    monkeypatch.setattr(Registry, 'discover', lambda registry: {
        key: command for key, command in discovered(registry).items() if command.module not in removed})
    job = Intake(app).start()
    Intake(app).submit(job['run_id'], job['request_id'], contribution(app))
    result = Intake(app).next(job['run_id'])
    assert 'best_practices' not in result and 'offers' not in result
    assert result['next'] == {'command': 'guide.start', 'arguments': {'model': result['model']}}
    removed.add('guide')
    result = Intake(app).next(job['run_id'])
    assert result['status'] == 'complete'
    assert 'next' not in result


@pytest.mark.parametrize('identity', ['run_id', 'request_id'])
def test_bound_intake_rejects_contradictory_explicit_identity_before_recording(app, identity):
    first = Intake(app).start()
    second = Intake(app).start()
    worker = copy.copy(app)
    worker.binding = {'module': 'intake', 'run_id': first['run_id'], 'request_id': first['request_id']}
    with pytest.raises(ValueError, match='conflict'):
        call(worker, 'intake.answer', answer=contribution(app), **{identity: second[identity]})
    assert app.load_run(first['run_id'])['receipts'] == {}
    assert app.load_run(second['run_id'])['receipts'] == {}


def test_unbound_intake_answer_requires_run_identity_even_with_active_mode(app):
    first = Intake(app).start()
    second = Intake(app).start()
    with pytest.raises(ValueError, match='explicit run_id.*nonce'):
        call(app, 'intake.answer', answer=contribution(app))
    assert app.load_run(first['run_id'])['receipts'] == {}
    assert app.load_run(second['run_id'])['receipts'] == {}
    receipt = call(app, 'intake.answer', run_id=first['run_id'], request_id=first['request_id'], answer=contribution(app))
    assert receipt['recorded']
    assert app.load_run(second['run_id'])['receipts'] == {}


def test_public_knowledge_explain_retains_origin_and_explains_nonapplicability(app):
    source = publish_foundation(app, foundation(app))
    subject = {'owner': 'project:' + app.project_id, 'kind': 'element', 'id': 'demo:engine'}
    layer = generate_advice(app, source, subject, 'Engine-specific advice')
    found = call(app, 'knowledge.get', model=source, target=subject, layers=[layer['id']])
    knowledge = next(record for record in found['records'] if record['ref']['kind'] == 'knowledge')
    for target, applies in [('demo:engine', True), ('demo:installer', False)]:
        explained = call(app, 'knowledge.explain', model=source, target=target, knowledge=knowledge['ref'])
        record = next(record for record in explained['records'] if record['ref'] == knowledge['ref'])
        assert record['explanation']['applies'] is applies
        assert record['explanation']['origin_layer']['id'] == layer['id']
        assert record['value']['payload'] == 'Engine-specific advice'
        assert explained['dependencies']
        if not applies:
            assert any(note['code'] == 'no_applicability_path' for note in explained['diagnostics'])


def test_outside_account_preserves_native_meaning_without_replaying_intake_audit(app):
    from metaform.layers import blindspots

    raw = 'Captured implementation transcript.\n' * 1000
    (app.project / 'artifact.txt').write_text(raw)
    job = Intake(app).start()
    call(app, 'intake.read', path='artifact.txt', description='Artifact behavior evidence')
    Intake(app).submit(job['run_id'], job['request_id'], contribution(app))
    model = Intake(app).next(job['run_id'])['model']
    before = capture_model(app, model)
    outside = blindspots(app, model=model)['inputs']
    account = outside['coarse_account']
    for key, value in before.items():
        if key != 'activities':
            assert account[key] == value
    activity = account['activities'][0]
    assert activity['id'] == before['activities'][0]['id']
    assert 'inputs' not in activity
    assert activity['source_evidence'][0]['description'] == 'Artifact behavior evidence'
    assert activity['source_evidence'][0]['revision'] == before['activities'][0]['source_evidence'][0]['revision']
    assert raw not in str(outside)
    assert outside['region'] == {'model': model, 'target': before['artifact']}
    contract = outside['coarse_account_contract']
    assert contract['format'] == 'native-functional-projection'
    assert contract['source_model'] == model
    assert contract['retained_activities'] == [
        {'owner': activity['owner'], 'id': activity['id']}]
    assert contract['omitted_intake_audit_fields'] == [
        'inputs', 'source_evidence[].text', 'source_evidence[].data',
        'components[].text', 'prompt.text']
    assert 'retained full foundation' in contract['diagnostics_scope']
    assert 'owner and id' in contract['resolution']
    assert capture_model(app, model) == before
