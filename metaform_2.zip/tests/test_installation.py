import asyncio
import io
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest
from mcp import Client
from mcp.client.stdio import StdioServerParameters

from metaform import cli, installation


def isolated_harnesses(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr(installation.shutil, "which", lambda name: None)


def test_installer_configures_only_selected_harness_and_preserves_cursor_settings(monkeypatch, tmp_path):
    isolated_harnesses(monkeypatch, tmp_path)
    config = tmp_path / ".cursor" / "mcp.json"
    config.parent.mkdir()
    original = '{"mcpServers":{"other":{"command":"other-server"}},"setting":true}\n'
    config.write_text(original)
    monkeypatch.setattr(installation.shutil, "which", lambda name: "/bin/codex" if name == "codex" else None)
    monkeypatch.setattr(installation.sys, "stdin", io.StringIO())
    launcher = str(tmp_path / "bin with spaces" / "metaform")

    pending = installation.setup_harnesses(launcher)
    assert [item["id"] for item in pending["detected"]] == ["codex", "cursor"]
    assert pending["configured"] == []
    assert config.read_text() == original

    result = installation.setup_harnesses(launcher, ["cursor"])
    assert result["configured"] == ["cursor"]
    saved = json.loads(config.read_text())
    assert saved == {"mcpServers": {"other": {"command": "other-server"},
                                  "metaform": {"command": launcher, "args": ["mcp"]}}, "setting": True}
    assert Path(result["backups"][0]).read_text() == original
    assert not (tmp_path / ".codex").exists()


def test_interactive_selection_reprompts_for_invalid_choice_and_allows_skip(monkeypatch, tmp_path, capsys):
    isolated_harnesses(monkeypatch, tmp_path)
    (tmp_path / ".cursor").mkdir()
    monkeypatch.setattr(installation.sys, "stdin", SimpleNamespace(isatty=lambda: True))
    responses = iter(["99", "1"])
    monkeypatch.setattr("builtins.input", lambda: next(responses))
    result = installation.setup_harnesses("/absolute/metaform")
    assert result["configured"] == ["cursor"]
    assert "Cursor" in capsys.readouterr().err
    monkeypatch.setattr("builtins.input", lambda: "")
    assert installation.setup_harnesses("/absolute/metaform")["configured"] == []

    def interrupt():
        raise KeyboardInterrupt
    monkeypatch.setattr("builtins.input", interrupt)
    interrupted = installation.setup_harnesses("/absolute/metaform")
    assert interrupted["configured"] == []
    assert interrupted["errors"] == []


@pytest.mark.parametrize("harness,executable,expected", [
    ("codex", "codex", ["mcp", "add", "metaform", "--", "/bin with spaces/metaform", "mcp"]),
    ("claude", "claude", ["mcp", "add", "--transport", "stdio", "--scope", "user", "metaform", "--", "/bin with spaces/metaform", "mcp"]),
    ("gemini", "gemini", ["mcp", "add", "--scope", "user", "metaform", "/bin with spaces/metaform", "mcp"]),
    ("vscode", "code", ["--add-mcp", '{"name": "metaform", "command": "/bin with spaces/metaform", "args": ["mcp"]}']),
])
def test_harness_registration_uses_documented_cli_and_reports_failure(monkeypatch, tmp_path, harness, executable, expected):
    isolated_harnesses(monkeypatch, tmp_path)
    monkeypatch.setattr(installation.shutil, "which", lambda name: "/tools/" + name if name == executable else None)
    calls = []
    def run(argv, **kwargs):
        calls.append(argv)
        return SimpleNamespace(returncode=0, stdout="Added", stderr="")
    monkeypatch.setattr(installation.subprocess, "run", run)
    result = installation.setup_harnesses("/bin with spaces/metaform", [harness])
    assert result["configured"] == [harness]
    assert calls == [["/tools/" + executable, *expected]]
    monkeypatch.setattr(installation.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=1, stdout="", stderr="Registration failed"))
    result = installation.setup_harnesses("/bin with spaces/metaform", [harness])
    assert result["configured"] == []
    assert result["errors"] == [{"id": harness, "error": "Registration failed"}]


def test_invalid_cursor_config_is_preserved(monkeypatch, tmp_path):
    isolated_harnesses(monkeypatch, tmp_path)
    config = tmp_path / ".cursor" / "mcp.json"
    config.parent.mkdir()
    config.write_text("unfinished {")
    result = installation.setup_harnesses("/absolute/metaform", ["cursor"])
    assert result["configured"] == []
    assert result["errors"][0]["id"] == "cursor"
    assert config.read_text() == "unfinished {"


def test_windows_registration_launches_the_script_through_python(monkeypatch, tmp_path):
    isolated_harnesses(monkeypatch, tmp_path)
    (tmp_path / ".cursor").mkdir()
    monkeypatch.setattr(installation, "os", SimpleNamespace(name="nt", environ={}))
    installation.setup_harnesses("C:/User Tools/metaform", ["cursor"])
    server = json.loads((tmp_path / ".cursor" / "mcp.json").read_text())["mcpServers"]["metaform"]
    assert server == {"command": installation.sys.executable, "args": ["C:/User Tools/metaform", "mcp"]}


def test_claude_custom_config_is_backed_up_before_registration(monkeypatch, tmp_path):
    isolated_harnesses(monkeypatch, tmp_path)
    directory = tmp_path / "claude profile"
    directory.mkdir()
    config = directory / ".claude.json"
    original = '{"mcpServers":{"other":{"command":"keep"}}}'
    config.write_text(original)
    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(directory))
    monkeypatch.setattr(installation.shutil, "which", lambda name: "/bin/claude" if name == "claude" else None)
    def register(*args, **kwargs):
        config.write_text('{}')
        return SimpleNamespace(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(installation.subprocess, "run", register)
    result = installation.setup_harnesses("/absolute/metaform", ["claude"])
    assert result["configured"] == ["claude"]
    assert len(result["backups"]) == 1
    assert Path(result["backups"][0]).read_text() == original


def test_install_cli_registers_a_launcher_that_serves_onboarding(monkeypatch, tmp_path, app, capsys):
    isolated_harnesses(monkeypatch, tmp_path)
    (tmp_path / ".cursor").mkdir()
    monkeypatch.setenv("METAFORM_HOME", str(app.home))
    monkeypatch.setenv("METAFORM_PROJECT", str(app.project))
    destination = tmp_path / "launcher with spaces"
    assert cli.main(["install", str(destination), "--harness", "cursor"]) == 0
    result = json.loads(capsys.readouterr().out)
    server = json.loads((tmp_path / ".cursor" / "mcp.json").read_text())["mcpServers"]["metaform"]
    assert result["mcp"]["configured"] == ["cursor"]
    assert Path(result["command"]).is_file()

    async def scenario():
        params = StdioServerParameters(**server, env={"METAFORM_HOME": str(app.home), "METAFORM_PROJECT": str(app.project), "PYTHONPATH": os.environ.get("PYTHONPATH", ""), "METAFORM_RUNTIME_DIR": os.environ["METAFORM_RUNTIME_DIR"]})
        async with Client(params) as client:
            state = json.loads(client.instructions.rsplit("\n\n", 1)[1])
            assert state["project"]["path"] == str(app.project)
            assert state["status"] == "needs_project_input"
            assert any(module["id"] == "knowledge" for module in state["modules"])

    asyncio.run(scenario())


def test_install_writes_the_skill_where_configured_harnesses_discover_it(monkeypatch, tmp_path):
    isolated_harnesses(monkeypatch, tmp_path)
    monkeypatch.setenv("CODEX_HOME", str(tmp_path / "codex home"))
    monkeypatch.delenv("CLAUDE_CONFIG_DIR", raising=False)
    home = tmp_path / "metaform-home"
    detected = [{"id": "codex", "name": "Codex", "executable": "/tools/codex", "config": None},
                {"id": "gemini", "name": "Gemini CLI", "executable": "/tools/gemini", "config": None}]
    calls = []
    monkeypatch.setattr(installation.subprocess, "run",
                        lambda argv, **kwargs: calls.append(argv) or SimpleNamespace(returncode=0, stdout="", stderr=""))

    result = installation.install_skills(home, ["codex", "claude", "gemini"], detected)

    text = (home / "skills" / "metaform" / "SKILL.md").read_text()
    assert text.startswith("---\nname: metaform\n")
    assert "## Registered abilities" not in text
    assert "metaform <module> --help" in text
    assert result["file"] == str(home / "skills" / "metaform" / "SKILL.md")
    assert Path(result["registered"]["agents"]) == tmp_path / ".agents" / "skills" / "metaform" / "SKILL.md"
    assert Path(result["registered"]["codex"]) == tmp_path / "codex home" / "skills" / "metaform" / "SKILL.md"
    assert Path(result["registered"]["claude"]) == tmp_path / ".claude" / "skills" / "metaform" / "SKILL.md"
    for path in result["registered"].values():
        if path != "gemini skills install":
            assert Path(path).read_text() == text
    assert calls == [["/tools/gemini", "skills", "install", str(home / "skills" / "metaform"), "--scope", "user", "--consent"]]
    assert result["errors"] == []

    unselected = installation.install_skills(home, [], detected)
    assert set(unselected["registered"]) == {"metaform", "agents"}


def test_install_preserves_existing_launcher_and_does_not_initialize_project(monkeypatch, tmp_path, capsys):
    isolated_harnesses(monkeypatch, tmp_path)
    project = tmp_path / 'selected'
    project.mkdir()
    home = tmp_path / 'runtime-home'
    monkeypatch.setenv('METAFORM_HOME', str(home))
    destination = tmp_path / 'bin'
    destination.mkdir()
    managed = destination / 'metaform'
    original = '#!/bin/sh\nexec /uv/tools/metaform "$@"\n'
    managed.write_text(original)
    managed.chmod(0o755)
    assert cli.main(['--project', str(project), 'install', str(destination)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert managed.read_text() == original
    assert result['launcher']['preserved'] is True
    assert not list(project.iterdir())
