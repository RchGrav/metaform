import json
from types import SimpleNamespace

import pytest

from metaform import ci
from metaform.registry import Registry


@pytest.mark.parametrize("remote", [
    "https://github.com/fork-owner/metaform.git",
    "git@github.com:fork-owner/metaform.git",
    "ssh://git@github.com/fork-owner/metaform.git",
])
def test_ci_targets_origin_in_the_fork(app, monkeypatch, remote):
    monkeypatch.setattr(ci, "git", lambda *args: remote)
    assert ci.repository_name(app) == "fork-owner/metaform"
    assert "package.ci" in Registry(app).visible()


@pytest.mark.parametrize("state, ref", [("disabled_fork", None), ("active", "work/semantics")])
def test_ci_enables_and_dispatches_only_the_selected_repository(app, monkeypatch, state, ref):
    monkeypatch.setattr(ci.shutil, "which", lambda name: "/bin/gh")
    calls = []
    root = "repos/fork-owner/metaform"

    def run(command, **kwargs):
        method = command[command.index("--method") + 1]
        endpoint = command[command.index("X-GitHub-Api-Version: 2026-03-10") + 1]
        payload = json.loads(kwargs["input"]) if kwargs.get("input") else None
        calls.append((method, endpoint, payload))
        if endpoint == root:
            value = {"full_name": "fork-owner/metaform", "private": True, "default_branch": "trunk"}
        elif endpoint.endswith("/wheel.yml"):
            value = {"state": state}
        elif endpoint.endswith("/enable"):
            value = None
        else:
            value = {"workflow_run_id": 123, "html_url": "https://github.com/fork-owner/metaform/actions/runs/123"}
        return SimpleNamespace(returncode=0, stdout=json.dumps(value) if value else "", stderr="")

    monkeypatch.setattr(ci.subprocess, "run", run)
    result = ci.setup(app, {"repository": "fork-owner/metaform", "ref": ref})
    assert result["private"] and result["run_id"] == 123
    expected = [
        ("GET", root, None),
        ("GET", root + "/actions/workflows/wheel.yml", None),
    ]
    if state != "active":
        expected.append(("PUT", root + "/actions/workflows/wheel.yml/enable", None))
    expected.append(("POST", root + "/actions/workflows/wheel.yml/dispatches", {"ref": ref or "trunk"}))
    assert calls == expected


def test_ci_reports_github_failure_without_claiming_a_build(app, monkeypatch):
    monkeypatch.setattr(ci.shutil, "which", lambda name: "/bin/gh")
    monkeypatch.setattr(ci.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(
        returncode=1, stdout="", stderr="gh: Resource not accessible (HTTP 403)"
    ))
    with pytest.raises(ValueError, match="HTTP 403"):
        ci.setup(app, {"repository": "fork-owner/metaform"})
    with app.db() as db:
        assert not db.execute("SELECT 1 FROM events WHERE kind='ci.dispatch'").fetchone()
