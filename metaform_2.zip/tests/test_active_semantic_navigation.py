"""An active workflow must not hide the user's semantic view or widen worker tools."""

import json
from pathlib import Path

from metaform.models import publish_foundation
from metaform.registry import Registry
from metaform.viewer import create_app
from metaform.workflow import Engine, import_workflow


def test_active_workflow_keeps_semantic_navigation_with_exact_worker_scope(app, monkeypatch):
    source = (Path(__file__).parent / 'fixtures' / 'foundation_v2.json').read_text()
    foundation = json.loads(source.replace('project:illustrative', 'project:' + app.project_id))
    foundation['model']['project'] = app.project_id
    model = publish_foundation(app, foundation)
    import_workflow(app, {'id': 'active-view', 'steps': [
        {'id': 'work', 'prompt': 'Read the requested neighborhood.', 'tools': ['graph.neighbors']}]})
    job = Engine(app).start('active-view')

    async def unexpected_build(self):
        raise AssertionError('Semantic navigation must not trigger a package build')

    monkeypatch.setattr(Registry, 'after_call', unexpected_build)
    client = create_app(app).test_client()
    for command in ('graph.neighbors', 'graph.traverse'):
        response = client.post('/api/semantic/' + command, json={'model': model, 'target': 'demo:engine'})
        assert response.status_code == 200, response.json
        assert any(record['ref']['kind'] == 'join' for record in response.json['records'])

    app.binding = {'module': 'workflow', 'run_id': job['run_id'], 'request_id': job['request_id']}
    visible = Registry(app).visible()
    assert 'graph.neighbors' in visible
    assert 'graph.traverse' not in visible
