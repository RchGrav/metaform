"""Clearing a project: every published model, run, layer, assignment and binding of the project goes, so intake
starts from nothing; the folder, its files and its registration stay. Rich has asked for this project operation
every time; the workbench brief names it: clearing the data and re-intaking is a project operation.
"""
import asyncio

import pytest

from metaform import bindings
from metaform.app import App
from metaform.intake import Intake
from metaform.models import list_models
from metaform.registry import Registry
from metaform.service import stop_service
from metaform.util import write_json
from metaform.viewer import create_app


def published(app):
    """One coarse intake published in-process: start, one put, an empty final answer, apply."""
    intake = Intake(app)
    job = intake.start({})
    intake.put(job["run_id"], {"elements": {"code.loop.clock": {"ef": "Shows the time."}}, "joins": [], "subtypes": []}, job["request_id"])
    intake.submit(job["run_id"], job["request_id"], {})
    intake.apply(job["run_id"])
    return job


def runs(app):
    with app.db() as db:
        return [row[0] for row in db.execute("SELECT id FROM runs")]


def test_clear_removes_the_models_runs_assignments_and_bindings_and_keeps_the_folder(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "service", "auto_build": False})
    app = App(tmp_path / "project", home)
    (app.project / "main.py").write_text("print('hi')\n")
    try:
        published(app)
        assert list_models(app) and runs(app)
        pending = Intake(app).start({})
        assert app.get("mode")["module"] == "intake"
        record = {"nonce": pending["nonce"], "project": str(app.project), "home": str(app.home), "module": "intake",
                  "run_id": pending["run_id"], "request_id": pending["request_id"]}
        bindings.record(tmp_path / "worker", record, home=app.home)
        assert (app.home / "assignments" / (pending["nonce"] + ".json")).is_file()
        bound = App(tmp_path / "project", home, binding=record | {"folder": str(tmp_path / "worker")})
        with pytest.raises(ValueError, match="Unknown command|delegated"):
            asyncio.run(Registry(bound).call("project.clear"))

        result = asyncio.run(Registry(app).call("project.clear"))

        assert result["cleared"]["models"] >= 1 and result["cleared"]["runs"] >= 2
        assert list_models(app) == [] and runs(app) == []
        assert app.get("mode") is None
        assert not (app.home / "assignments" / (pending["nonce"] + ".json")).exists()
        assert bindings.lookup(tmp_path / "worker", home=app.home) is None
        assert (app.project / "main.py").read_text() == "print('hi')\n"
        assert str(app.project) in {row["path"] for row in asyncio.run(Registry(app).call("project.list"))}
        again = Intake(app).start({})
        assert again["status"] == "awaiting_answer"
    finally:
        stop_service(home, timeout=5)


def test_the_page_offers_clear_and_the_project_returns_to_needs_intake(app):
    (app.project / "main.py").write_text("print('hi')\n")
    published(app)
    client = create_app(app).test_client()
    assert client.get("/api/jobs").json["runs"]
    assert "Clear project" in client.get("/").get_data(as_text=True)
    cleared = client.post("/api/semantic/project.clear", json={}).json
    assert cleared["cleared"]["models"] >= 1
    assert client.get("/api/jobs").json["runs"] == []
    assert client.post("/api/semantic/model.discover", json={}).json["models"] == []
    assert client.post("/api/semantic/guide.start", json={}).json["status"] == "needs_intake"
