"""Layer origin and Type inheritance are independent explanation axes (V11)."""
from copy import deepcopy

from metaform.properties import explain_applicability
from test_property_applicability import foundation, ref


def advice(id='cpp-practice', value='Prefer scoped ownership.'):
    return dict(ref('knowledge', id), subject=ref('type', 'code.cpp'), layer=ref('layer', 'practices'), generation=ref('generation', 'g1'), payload={'recommendation': value}, applicability={'scope': {'kind': 'type', 'target': ref('type', 'code.cpp'), 'descendants': True}, 'reason': 'Reusable C++ ownership advice.'}, dependencies=[], evidence=[{'source': 'assignment:g1'}], freshness='current')


def test_type_layer_reuse_preserves_origin_generation_and_local_scope():
    snapshot = foundation()
    item = advice()
    for actual, expected_steps in [('engine', ['Type binding']), ('other', ['Type narrowing', 'Type binding'])]:
        result = explain_applicability(snapshot, ref('element', actual), ref('knowledge', item['id']), [item])
        assert result['applies']
        assert result['origin'] == ref('knowledge', item['id'])
        assert result['origin_layer'] == item['layer']
        assert result['generation'] == item['generation']
        assert result['freshness'] == 'current'
        assert result['source_refs'] == item['evidence']
        assert [s['step'] for s in result['path']] == expected_steps
    local = dict(item, id='local-setting', subject=ref('element', 'engine'), applicability={'scope': {'kind': 'record', 'target': ref('element', 'engine')}, 'reason': 'Local engine setting.'})
    assert explain_applicability(snapshot, ref('element', 'engine'), local, [])['applies']
    assert not explain_applicability(snapshot, ref('element', 'other'), local, [])['applies']
    assert not explain_applicability(snapshot, ref('element', 'installer'), item, [])['applies']


def test_competing_qualified_advice_and_revision_changes_are_not_latest_wins():
    snapshot = foundation()
    one = advice()
    two = dict(advice('cpp-practice', 'Use a shared owner for this boundary.'), owner='global', layer=ref('layer', 'boundary-practices', 'global'), qualifications=['Only at a shared-lifetime boundary.'])
    records = [one, two]
    results = [explain_applicability(snapshot, ref('element', 'engine'), ref('knowledge', i['id'], i['owner']), records) for i in records]
    assert all(r['applies'] for r in results)
    assert len({r['origin']['owner'] for r in results}) == 2
    assert results[0]['claim'] != results[1]['claim']
    assert results[1]['qualifications'] == two['qualifications']
    destination = deepcopy(snapshot)
    destination['model']['revision'] = 'r2'
    destination['bindings'] = [b for b in destination['bindings'] if b['id'] != 'b:engine:code.cpp']
    assert not explain_applicability(destination, ref('element', 'engine'), one, records)['applies']
    assert explain_applicability(snapshot, ref('element', 'engine'), one, records)['applies']
    stale = dict(one, freshness='stale')
    stale_result = explain_applicability(snapshot, ref('element', 'engine'), stale, [stale])
    assert stale_result['freshness'] == 'stale'
    assert not stale_result['applies'] and stale_result['visible_here']


def test_report_target_index_exposes_locator_without_copying_report():
    snapshot = foundation()
    item = dict(advice(), subject=ref('element', 'project'), target_index=[{'target': ref('element', 'installer'), 'locator': '/findings/0'}], applicability={'scope': {'kind': 'record', 'target': ref('element', 'project')}, 'reason': 'Findings address their own named targets.'}, payload={'findings': [{'account': 'Installer question.'}]})
    result = explain_applicability(snapshot, ref('element', 'installer'), item, [item])
    assert result['applies']
    assert result['payload_locators'] == ['/findings/0']
    assert result['origin'] == ref('knowledge', item['id'])
    assert not explain_applicability(snapshot, ref('element', 'other'), item, [item])['applies']


def test_explicit_actual_scope_qualifies_reusable_type_advice():
    snapshot = foundation()
    item = advice()
    item['applicability']['scope'] = {'kind': 'records', 'targets': [ref('element', 'engine')]}
    assert explain_applicability(snapshot, ref('element', 'engine'), item, [])['applies']
    assert not explain_applicability(snapshot, ref('element', 'other'), item, [])['applies']


def test_record_revisions_are_preserved_and_pinned_mismatches_remain_unresolved():
    snapshot = foundation()
    item = dict(advice(), revision='knowledge-r1')
    result = explain_applicability(snapshot, ref('element', 'engine'), ref('knowledge', item['id']), [item])
    assert result['origin']['revision'] == 'knowledge-r1'
    wrong_revision = dict(ref('knowledge', item['id']), revision='knowledge-r0')
    unresolved = explain_applicability(snapshot, ref('element', 'engine'), wrong_revision, [item])
    assert not unresolved['applies']
    assert any(d['code'] == 'unresolved_origin' for d in unresolved['diagnostics'])


def test_shared_knowledge_read_preserves_competing_layer_origins_and_native_property():
    from metaform.read_model import read_snapshot

    snapshot = foundation()
    first = advice()
    second = dict(advice('cpp-practice', 'Use a shared owner at this boundary.'), owner='global', layer=ref('layer', 'boundary', 'global'))
    snapshot['knowledge'] = [first, second]
    engine = read_snapshot(snapshot, 'knowledge.get', {'target': ref('element', 'engine')})
    explanations = [r['explanation'] for r in engine['records'] if 'explanation' in r]
    assert {r['origin']['owner'] for r in explanations if r['origin']['kind'] == 'knowledge'} == {first['owner'], second['owner']}
    assert any(r['origin']['id'] == 'j:engine:medium' and r['origin_layer'] is None for r in explanations)
    assert not any(r['claim'].get('value') == 'code.shell' and r['applies'] for r in explanations)
    trunk = read_snapshot(snapshot, 'knowledge.get', {'target': ref('type', 'code')})
    properties = [r['explanation'] for r in trunk['records'] if r.get('explanation', {}).get('origin', {}).get('kind') == 'join']
    assert {r['claim']['value'] for r in properties} == {'code.shell', 'code.cpp'}
    assert all(r['visible_here'] and not r['applies'] for r in properties)
