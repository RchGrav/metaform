"""Global HTTP routing uses explicit project Apps and the owner's real store."""
import urllib.request

from metaform.app import App
from metaform.knowledge import KnowledgeStore
from metaform.util import write_json
from metaform.viewer import create_app


class DirectOwner:
    def __init__(self, home):
        self.home = home
        self.directory = home.parent / "runtime"
        self.store = KnowledgeStore(home / "service" / "knowledge.sqlite3")

    def knowledge_client(self, home, project_id):
        assert home == self.home
        return self.store.bind(project_id)

    def project_records(self):
        return [entry | {"home": str(self.home)}
                for entry in self.store.call(None, "project.list", {})]


def test_owner_apps_register_and_select_without_recursive_remote_start(tmp_path, monkeypatch):
    import metaform.service as service

    home = tmp_path / "home"
    write_json(home / "config.json", {"auto_build": False})
    owner = DirectOwner(home)

    def unexpected(*args, **kwargs):
        raise AssertionError("An in-process App must not start or call a remote server")

    monkeypatch.setattr(service, "ensure_service", unexpected)
    monkeypatch.setattr(service, "RemoteKnowledge", unexpected)
    first = App(tmp_path / "first", home, binding=False,
                knowledge_client=owner.knowledge_client)
    record = {"entity_desc": "Recorded project item", "entity_schema": "metaform:element", "entity_json_obj": {}}
    first.graph.put({"elements": {"first": record}})
    second = first.select_project(tmp_path / "second")
    second.graph.put({"elements": {"second": record}})
    assert first.project_id != second.project_id
    assert first.graph.get("first") is not None
    assert first.graph.get("second") is None
    assert second.graph.get("first") is None
    assert second.graph.get("second") is not None
    assert first.select_project(second.project_id).project == second.project


def test_global_viewer_requires_project_context_and_preserves_each_url(tmp_path, monkeypatch):
    import metaform.service as service

    home = tmp_path / "home"
    write_json(home / "config.json", {"auto_build": False})
    owner = DirectOwner(home)
    monkeypatch.setattr(service, "ensure_service", lambda *args, **kwargs: (_ for _ in ()).throw(
        AssertionError("Global routing must not spawn another server")))
    web = create_app(None, "global-instance", owner=owner)
    client = web.test_client()
    assert client.get("/api/health").json["instance_id"] == "global-instance"
    assert client.get("/api/projects").json == []
    assert client.get("/api/settings").status_code == 400
    assert client.get("/static/explorer.js").status_code == 200
    entries = []
    for name in ("first", "second"):
        path = tmp_path / name
        path.mkdir()
        entries.append(web.extensions["metaform_open_project"](path, home))
    assert len(client.get("/api/projects").json) == 2
    for entry in reversed(entries):
        assert client.get(entry["url"].rstrip("/"), follow_redirects=True).status_code == 200
        response = client.get(entry["url"] + "api/settings")
        assert response.status_code == 200, response.json
        assert response.json["project"] == entry["path"]
    assert client.get("/api/settings").status_code == 400
    landing = client.get("/")
    assert landing.status_code == 302 and landing.headers["Location"].endswith(entries[-1]["url"])
    assert client.get("/projects").status_code == 200


def test_global_catalog_retains_local_projects_without_converting_them(tmp_path):
    home = tmp_path / "home"
    owner = DirectOwner(home)
    path = tmp_path / "local"
    write_json(path / '.metaform' / 'config.json', {'knowledge_mode': 'legacy', 'graph_backend': 'json', 'auto_build': False})
    original = App(path, home, binding=False)
    original.graph.put({'elements': {'retained': {'en': 'Retained local record'}}})
    graph_before = original.graph.export()
    web = create_app(None, 'first-instance', owner=owner)
    opened = web.extensions['metaform_open_project'](path, home)
    after_restart = create_app(None, 'replacement-instance', owner=owner).test_client()
    catalog = after_restart.get('/api/projects').json
    assert [entry['path'] for entry in catalog] == [str(path)]
    response = after_restart.get(opened['url'] + 'api/settings')
    assert response.status_code == 200, response.json
    assert response.json['knowledge_mode'] == 'legacy'
    assert original.graph.export() == graph_before
    assert not (original.root / 'project.json').exists()


def test_global_shutdown_closes_owned_preview_resources(app):
    (app.project / "example.txt").write_text("Preview data")
    web = create_app(app)
    client = web.test_client()
    response = client.post("/api/preview", json={}, base_url="http://localhost:9876")
    assert response.status_code == 200, response.json
    url = response.json[0]["url"]
    try:
        assert url.startswith("http://localhost:9876/projects/")
        assert client.get(url + "example.txt").data == b"Preview data"
        assert client.get(url + "example.txt").headers.get('Access-Control-Allow-Origin') == '*'
    finally:
        web.extensions["metaform_close"]()
    assert client.get(url).status_code == 404


def test_sandboxed_preview_cannot_mutate_workbench_state(app):
    (app.project / "index.html").write_text("<h1>Preview</h1>")
    web = create_app(app)
    client = web.test_client()
    url = client.post('/api/preview', json={}).json[0]['url']
    try:
        for origin in ('null', 'https://another.example'):
            rejected = client.post('/api/preview/stop', headers={'Origin': origin})
            assert rejected.status_code == 403
            assert client.get(url).status_code == 200
        accepted = client.post('/api/preview/stop', headers={'Origin': 'http://localhost'})
        assert accepted.status_code == 200
        assert client.get(url).status_code == 404
    finally:
        web.extensions['metaform_close']()


def test_explicitly_unbound_owner_app_ignores_ambient_assignment(tmp_path, monkeypatch):
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    monkeypatch.setenv('METAFORM_BINDING', '{unfinished caller binding')
    selected = App(tmp_path / 'project', home, binding=False)
    assert selected.binding is None


def test_slow_project_open_keeps_global_and_existing_project_http_responsive(tmp_path, monkeypatch):
    import json
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from werkzeug.serving import make_server

    home = tmp_path / "home"
    write_json(home / "config.json", {"auto_build": False})
    owner = DirectOwner(home)
    web = create_app(None, "isolated-owner", owner=owner)
    first, slow = tmp_path / "first", tmp_path / "slow"
    first.mkdir()
    slow.mkdir()
    opened = web.extensions["metaform_open_project"](first, home)
    entered, release = threading.Event(), threading.Event()
    initializer = App.__init__
    initialized = []

    def delayed(self, project, *args, **kwargs):
        if project == slow:
            initialized.append(project)
            entered.set()
            assert release.wait(5), "Test did not release the slow initializer"
        initializer(self, project, *args, **kwargs)

    monkeypatch.setattr(App, "__init__", delayed)
    server = make_server("127.0.0.1", 0, web, threaded=True)
    serving = threading.Thread(target=server.serve_forever)
    serving.start()
    base = f"http://127.0.0.1:{server.server_port}"

    def read(path, timeout=.75):
        with urllib.request.urlopen(base + path, timeout=timeout) as response:
            return response.status, response.read()

    def open_slow():
        request = urllib.request.Request(base + "/api/projects/open",
            data=json.dumps({"path": str(slow), "home": str(home)}).encode(),
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(request, timeout=5) as response:
            return json.load(response)

    try:
        with ThreadPoolExecutor(max_workers=6) as pool:
            pending = pool.submit(open_slow)
            assert entered.wait(2)
            repeated = pool.submit(open_slow)
            try:
                paths = ["/api/health", "/api/projects", "/static/explorer.js",
                         opened["url"] + "api/settings"]
                results = [pool.submit(read, path) for path in paths]
                assert all(result.result(timeout=2)[0] == 200 for result in results)
                assert not pending.done()
            finally:
                release.set()
            assert pending.result(timeout=3) == repeated.result(timeout=3)
            assert initialized == [slow]
    finally:
        release.set()
        server.shutdown()
        server.server_close()
        serving.join(timeout=3)
        web.extensions["metaform_close"]()


def test_slow_catalog_read_does_not_block_health_or_open_project_http(app, monkeypatch):
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from werkzeug.serving import make_server

    web = create_app(app)
    entered, release = threading.Event(), threading.Event()
    project_context = app.project_context

    def delayed_context():
        entered.set()
        assert release.wait(5), "Test did not release the catalog read"
        return project_context()

    monkeypatch.setattr(app, "project_context", delayed_context)
    server = make_server("127.0.0.1", 0, web, threaded=True)
    serving = threading.Thread(target=server.serve_forever)
    serving.start()
    base = f"http://127.0.0.1:{server.server_port}"

    def read(path, timeout=.75):
        with urllib.request.urlopen(base + path, timeout=timeout) as response:
            return response.status, response.read()

    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            pending = pool.submit(read, '/api/projects', 5)
            assert entered.wait(2)
            try:
                results = [pool.submit(read, path) for path in (
                    '/api/health', '/static/explorer.js', '/projects/' + app.project_id + '/api/settings')]
                assert all(result.result(timeout=2)[0] == 200 for result in results)
                assert not pending.done()
            finally:
                release.set()
            assert pending.result(timeout=3)[0] == 200
    finally:
        release.set()
        server.shutdown()
        server.server_close()
        serving.join(timeout=3)
