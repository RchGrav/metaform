import copy
import json
from pathlib import Path

import pytest

from metaform.workflow import Engine


@pytest.fixture
def foundation(app):
    from metaform.models import publish_foundation
    data = json.loads((Path(__file__).parent / 'fixtures/foundation_v2.json').read_text())
    def owned(value):
        if isinstance(value, dict):
            return {key: ('project:' + app.project_id if key == 'owner' and item == 'project:illustrative' else owned(item)) for key, item in value.items()}
        if isinstance(value, list):
            return [owned(item) for item in value]
        return value
    data = owned(data)
    data['model']['project'] = app.project_id
    return publish_foundation(app, data)


def finish(app, job, answer):
    receipt = Engine(app).submit(job['run_id'], job['request_id'], answer)
    assert Engine(app).submit(job['run_id'], job['request_id'], answer) == receipt
    return Engine(app).next(job['run_id'])


def contribution(subject, payload, schema='urn:test:advice'):
    return {'attachments': [{'subject': subject, 'schema_ref': schema, 'payload': payload,
                            'slot': 'guidance', 'applicability': {'scope': {'kind': 'direct', 'target': subject}, 'reason': 'Knowledge for this subject.'}}]}


def test_model_layer_selection_persists_and_controls_default_public_reads(app, foundation):
    import asyncio
    from metaform.app import App
    from metaform.layers import create_layer, remove_layer
    from metaform.models import capture_model, publish_foundation
    from metaform.registry import Registry

    subject = capture_model(app, foundation)['artifact']
    layers = []
    for name in ('Best Practices', 'Review notes'):
        job = create_layer(app, name, model=foundation)
        job = finish(app, job, {'name': name, 'schema_ref': 'urn:test:advice',
            'schema': {'$id': 'urn:test:advice', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string'},
            'groups': [{'subjects': [subject]}]})
        layers.append(finish(app, job, contribution(subject, name))['layer'])

    def call(command, **args):
        return asyncio.run(Registry(App(app.project, app.home)).call(command, args))

    assert call('layer.select', model=foundation, layer=layers[0])['selected_layer'] == layers[0]
    assert call('layer.list', model=foundation)['selected_layer'] == layers[0]

    def payloads(**args):
        return {r['value']['payload'] for r in call('knowledge.get', model=foundation, target=subject, **args)['records']
                if r['ref']['kind'] == 'knowledge'}

    assert payloads() == {'Best Practices'}
    assert payloads(layers=[layers[1]]) == {'Review notes'}
    assert payloads(layers=None) == {'Best Practices', 'Review notes'}
    assert payloads(layers=[]) == set()
    assert call('layer.list', model=foundation)['selected_layer'] == layers[0]
    other = capture_model(app, foundation)
    other['model']['model'] = 'other'
    other = publish_foundation(app, other)
    assert call('layer.list', model=other)['selected_layer'] is None
    assert call('layer.select', model=foundation, layer=None)['selected_layer'] is None
    assert payloads() == {'Best Practices', 'Review notes'}
    call('layer.select', model=foundation, layer=layers[0])
    remove_layer(app, layers[0], foundation)
    assert call('layer.list', model=foundation)['selected_layer'] is None
    assert payloads() == {'Review notes'}


def test_layer_resume_and_selected_regeneration(app, foundation):
    from metaform.layers import create_layer, inspect_layer, list_layers, regenerate_layer, active_attachments, remove_layer
    from metaform.models import capture_model
    before = capture_model(app, foundation)
    owner = 'project:' + app.project_id
    subjects = [{'owner': owner, 'kind': 'type', 'id': 'code.cpp'}, {'owner': owner, 'kind': 'element', 'id': 'demo:engine'}]
    request = 'Explain presentation choices. Preserve {{ original wording }} exactly.\nSecond line.'
    job = create_layer(app, request, model=foundation)
    plan = {'name': 'Presentation choices', 'description': request, 'schema_ref': 'urn:test:advice',
            'schema': {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:advice', 'type': 'string'},
            'selector': {'kind': 'subjects', 'targets': subjects},
            'groups': [{'subjects': [subject], 'purpose': 'Explain its choices.'} for subject in subjects]}
    job = finish(app, job, plan)
    job = finish(app, job, contribution(subjects[0], 'Shared Type advice'))
    saved = inspect_layer(app, job['layer'], foundation)
    assert saved['generation']['state'] == 'partial'
    assert len(saved['attachments']) == 1
    assert Engine(app).next(job['run_id'])['request_id'] == job['request_id']
    result = finish(app, job, contribution(subjects[1], 'Local advice'))
    assert result['status'] == 'complete'
    layer = result['layer']
    saved = inspect_layer(app, layer, foundation)
    assert saved['recipe']['request'] == request
    assert saved['recipe']['rendered_assignments']
    assert saved['recipe']['schema_snapshots']['urn:test:advice']
    assert any(d['kind'] == 'selector' for d in saved['recipe']['dependencies'])
    repeat = regenerate_layer(app, layer, foundation, target=subjects[1])
    result = finish(app, repeat, contribution(subjects[1], 'Revised local advice'))
    assert result['status'] == 'complete'
    assert {a['payload'] for a in active_attachments(app, foundation)} == {'Shared Type advice', 'Revised local advice'}
    assert capture_model(app, foundation) == before
    assert len(list_layers(app, foundation)) == 1
    remove_layer(app, layer, foundation)
    assert list_layers(app, foundation) == []
    assert active_attachments(app, foundation) == []
    assert inspect_layer(app, layer, foundation)['recipe']['request'] == request
    assert capture_model(app, foundation) == before


def test_non_code_schema_layer_removal_and_authored_revision_survive(app, foundation):
    from metaform.layers import create_layer, regenerate_layer, inspect_layer, active_attachments, list_layers, remove_layer
    from metaform.models import publish_foundation, capture_model
    owner = 'project:' + app.project_id
    data = json.loads((Path(__file__).parent / 'fixtures/non_code_foundation_v2.json').read_text().replace('project:illustrative', owner))
    data['model']['project'] = app.project_id
    model = publish_foundation(app, data)
    before = capture_model(app, model)
    subject = before['artifact']
    schema = {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:reader-support',
              'type': 'object', 'properties': {'reader_question': {'type': 'string'}, 'section': {'type': 'string'}}}
    def generate(request):
        job = create_layer(app, request, model=model)
        plan = {'name': 'Reader support', 'description': request, 'schema_ref': schema['$id'], 'schema': schema,
                'selector': {'kind': 'subjects', 'targets': [subject]},
                'groups': [{'subjects': [subject], 'purpose': request}]}
        job = finish(app, job, plan)
        return finish(app, job, contribution(subject, {'reader_question': request, 'section': 'Introduction'}, schema['$id']))['layer']
    first = generate('Explain what the guide reader needs to know.')
    second = generate('Describe useful navigation choices.')
    assert first['id'] != second['id']
    saved = inspect_layer(app, second, model)
    authored = copy.deepcopy(saved['attachments'][0])
    authored.update(id='authored:reader-note', authored=True, provenance={'source': 'authored'}, payload={'reader_question': 'My own question'})
    state_record = app.graph.get('layer-state:' + second['id'])
    state = state_record['entity_json_obj']
    state['generations'][saved['generation']['id']]['attachments'].append(authored)
    association = next(iter(state['associations'].values()))
    association['attachments'].append({'owner': owner, 'kind': 'knowledge', 'id': authored['id']})
    app.graph.put({'elements': {'layer-state:' + second['id']: state_record}, 'joins': []}, source='authored', layer='knowledge-layers')
    job = regenerate_layer(app, second, model, subject)
    finish(app, job, contribution(subject, {'reader_question': 'Fresh inferred question'}, schema['$id']))
    active = active_attachments(app, model, [second])
    assert any(item['id'] == 'authored:reader-note' for item in active)
    assert any(item['payload'] == {'reader_question': 'Fresh inferred question'} for item in active)
    remove_layer(app, first, model)
    assert [layer['id'] for layer in list_layers(app, model)] == [second['id']]
    assert capture_model(app, model) == before


def test_partial_publish_replays_without_duplicate_attachment(app, foundation):
    from metaform.layers import create_layer, publish_generation, active_attachments, inspect_layer
    owner = 'project:' + app.project_id
    subject = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    job = create_layer(app, 'Explain practices', model=foundation)
    plan = {'name': 'Practices', 'description': 'Practices', 'schema_ref': 'urn:test:text',
            'schema': {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:text', 'type': 'string'},
            'selector': {'kind': 'subjects', 'targets': [subject]}, 'groups': [{'subjects': [subject], 'purpose': 'Reusable Type advice.'}]}
    job = finish(app, job, plan)
    answer = contribution(subject, 'One shared account', 'urn:test:text')
    first = publish_generation(app, job['run_id'], answer)
    assert publish_generation(app, job['run_id'], answer) == first
    assert len(active_attachments(app, foundation)) == 1
    finish(app, job, {'attachments': []})
    saved = inspect_layer(app, job['layer'], foundation)
    assert saved['attachments'][0]['payload'] == 'One shared account'


def test_destination_keeps_source_history_and_excludes_changed_advice(app, foundation):
    from metaform.layers import blindspots, associate_destination, active_attachments, inspect_layer
    from metaform.models import capture_model, publish_foundation
    owner = 'project:' + app.project_id
    target = {'owner': owner, 'kind': 'element', 'id': 'demo:engine'}
    first = finish(app, blindspots(app, 'Review engine', target, foundation), {'summary': 'Engine account.', 'findings': []})
    second = finish(app, blindspots(app, 'Review project', model=foundation), {'summary': 'Project account.', 'findings': []})
    source_attachments = active_attachments(app, foundation)
    source_bundles = [inspect_layer(app, layer, foundation) for layer in (first['layer'], second['layer'])]
    destination_data = capture_model(app, foundation)
    destination_data['model']['model'] = 'variant'
    destination = publish_foundation(app, destination_data)
    changed, unchanged = sorted(source_attachments, key=lambda item: item['subject']['id'])
    ref = lambda item: {'owner': owner, 'kind': 'knowledge', 'id': item['id']}
    associate_destination(app, foundation, destination, [
        {'target': ref(changed), 'layer': changed['layer'], 'action': 'regenerate', 'reasons': [{'reason': 'Changed premise'}]},
        {'target': ref(unchanged), 'layer': unchanged['layer'], 'action': 'preserve', 'reasons': []}], [])
    assert [item['id'] for item in active_attachments(app, destination)] == [unchanged['id']]
    assert active_attachments(app, foundation) == source_attachments
    for layer, before in zip((first['layer'], second['layer']), source_bundles):
        assert inspect_layer(app, layer, foundation) == before


def generated_type_layer(app, model):
    from metaform.layers import create_layer
    subject = {'owner': 'project:' + app.project_id, 'kind': 'type', 'id': 'code.cpp'}
    job = create_layer(app, 'Explain this Type for its receiving context.', subject, model)
    plan = {'name': 'Type implications', 'description': 'Type implications', 'schema_ref': 'urn:test:type-implications',
            'schema': {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:type-implications', 'type': 'string'},
            'selector': {'kind': 'neighbors', 'target': subject, 'depth': 1},
            'groups': [{'subjects': [subject], 'purpose': 'Explain its reusable implications.'}]}
    job = finish(app, job, plan)
    return finish(app, job, contribution(subject, 'Original Type knowledge', plan['schema_ref']))['layer']


def test_relocation_updates_effective_dependencies_and_chained_selector(app, foundation):
    from metaform.layers import associate_destination, active_attachments, inspect_layer
    from metaform.models import capture_model, publish_foundation
    from metaform.transform import impact, patch_snapshot
    layer = generated_type_layer(app, foundation)
    original = active_attachments(app, foundation)[0]
    owner = 'project:' + app.project_id
    knowledge = {'owner': owner, 'kind': 'knowledge', 'id': original['id']}
    current = foundation
    previous = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    for spelling in ('code.cxx', 'code.program'):
        target = previous | {'id': spelling}
        changed = patch_snapshot(capture_model(app, current), [{'op': 'relocate', 'target': previous, 'replacement': target}])
        changed['model']['model'] = spelling
        destination = publish_foundation(app, changed)
        associate_destination(app, current, destination,
            [{'target': knowledge, 'layer': layer, 'action': 'relocate', 'reasons': []}],
            [{'from': previous, 'to': target, 'meaning_preserved': True, 'reason': 'Same Type meaning.'}])
        view = active_attachments(app, destination)[0]
        assert view['subject'] == target
        assert any(d.get('target') == target for d in view['dependencies'])
        assert inspect_layer(app, layer, destination)['association']['selector']['target'] == target
        current, previous = destination, target
    assert active_attachments(app, foundation)[0] == original
    changed = capture_model(app, current)
    changed['types']['code.program']['ef'] = 'A different encounter function.'
    changed['model']['model'] = 'changed-program'
    destination = publish_foundation(app, changed)
    assert impact(app, current, destination, [])['decisions'][0]['action'] == 'regenerate'


def test_scoped_replacement_reinfers_type_request_in_destination_region(app, foundation):
    from metaform.layers import associate_destination, active_attachments, regenerate_layer, inspect_layer
    from metaform.models import capture_model, publish_foundation
    layer = generated_type_layer(app, foundation)
    original = inspect_layer(app, layer, foundation)
    attachment = active_attachments(app, foundation)[0]
    owner = 'project:' + app.project_id
    old = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    replacement = old | {'id': 'code.javascript'}
    engine = {'owner': owner, 'kind': 'element', 'id': 'demo:engine'}
    snapshot = capture_model(app, foundation)
    snapshot['model']['model'] = 'javascript-engine'
    snapshot['types']['code.javascript'] = snapshot['types']['code.cpp'] | {'id': 'code.javascript', 'ef': 'Expresses JavaScript operations.'}
    for binding in snapshot['bindings']:
        if binding['element'] == engine and binding['type'] == old:
            binding['type'] = replacement
    for join in snapshot['joins']:
        if join['receiver'] == engine and join['provider_type'] == old:
            join.update(provider=replacement, provider_type=replacement)
    destination = publish_foundation(app, snapshot)
    mapping = [{'from': old, 'to': replacement, 'meaning_preserved': False,
                'scope': {'kind': 'neighbors', 'target': engine, 'depth': 1}, 'reason': 'Change this engine implementation medium.'}]
    associate_destination(app, foundation, destination, [{'target': {'owner': owner, 'kind': 'knowledge', 'id': attachment['id']},
        'layer': layer, 'action': 'regenerate', 'reasons': []}], mapping)
    job = regenerate_layer(app, layer, destination)
    assert job['inputs']['subjects'] == [engine]
    assert job['inputs']['context']['transformation_mapping'] == mapping
    assert any(row['ref'] == replacement for row in job['inputs']['context']['records'])
    assert job['inputs']['request'] == original['recipe']['request']
    assert inspect_layer(app, layer, foundation)['recipe'] == original['recipe']


@pytest.mark.parametrize('interruption', ['start', 'next'])
def test_scheduled_reinference_recovers_saved_generation_and_assignment(app, foundation, monkeypatch, interruption):
    from metaform.layers import associate_destination, active_attachments, schedule_reinference, inspect_layer
    from metaform.models import capture_model, publish_foundation
    layer = generated_type_layer(app, foundation)
    attachment = active_attachments(app, foundation)[0]
    changed = capture_model(app, foundation)
    changed['model']['model'] = 'changed-type'
    changed['types']['code.cpp']['ef'] = 'A changed function requiring fresh interpretation.'
    destination = publish_foundation(app, changed)
    decisions = [{'target': {'owner': attachment['owner'], 'kind': 'knowledge', 'id': attachment['id']},
                  'layer': layer, 'subject': attachment['subject'], 'action': 'regenerate',
                  'reasons': [{'target': attachment['subject'], 'reason': 'The supplied EF changed.'}]}]
    associate_destination(app, foundation, destination, decisions, [])
    with monkeypatch.context() as patch:
        def interrupted(*args, **kwargs):
            raise RuntimeError('Execution interrupted')
        patch.setattr(Engine, interruption, interrupted)
        with pytest.raises(RuntimeError, match='Execution interrupted'):
            schedule_reinference(app, foundation, destination, decisions, [], 'transform:changed-type')
    jobs = schedule_reinference(app, foundation, destination, decisions, [], 'transform:changed-type')
    again = schedule_reinference(app, foundation, destination, decisions, [], 'transform:changed-type')
    assert len(jobs) == 1
    assert again[0]['run_id'] == jobs[0]['run_id']
    assert again[0]['request_id'] == jobs[0]['request_id']
    assert jobs[0]['inputs']['request'] == 'Explain this Type for its receiving context.'
    assert jobs[0]['inputs']['context']['impact']['decisions'] == decisions
    assert active_attachments(app, destination) == []
    finish(app, jobs[0], contribution(attachment['subject'], 'Updated Type knowledge', 'urn:test:type-implications'))
    assert active_attachments(app, destination)[0]['payload'] == 'Updated Type knowledge'
    replay = schedule_reinference(app, foundation, destination, decisions, [], 'transform:changed-type')[0]
    assert replay['status'] == 'complete'
    assert replay['run_id'] == jobs[0]['run_id']
    assert len(inspect_layer(app, layer, destination)['history']) == 2


def test_layer_deep_reads_use_pinned_model_and_retain_supplied_context(app, foundation):
    import asyncio
    from metaform.layers import create_layer, inspect_layer
    from metaform.models import capture_model, publish_foundation
    from metaform.registry import Registry
    snapshot = capture_model(app, foundation)
    original_ef = 'Original Type meaning with retained detail. ' * 1000
    snapshot['types']['code.cpp']['ef'] = original_ef
    model = publish_foundation(app, snapshot, base=foundation)
    subject = {'owner': 'project:' + app.project_id, 'kind': 'type', 'id': 'code.cpp'}
    job = create_layer(app, 'Explain this Type.', subject, model)
    job = finish(app, job, {'name': 'Type guidance', 'description': 'Explain this Type.', 'schema_ref': 'urn:test:deep-read',
        'schema': {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:deep-read', 'type': 'string'},
        'selector': {'kind': 'target', 'target': subject}, 'groups': [{'subjects': [subject], 'purpose': 'Explain the Type.'}]})
    assert 'workflow.get' in job['tools']
    assert set(job['tools']).issubset(Registry(app).visible())
    assert any(row['value'].get('body_omitted') for region in job['inputs']['context']['regions'] for row in region['records'])
    later = capture_model(app, model)
    later['types']['code.cpp']['ef'] = 'Later meaning in a different revision.'
    publish_foundation(app, later, base=model)
    app.leave()  # Explicit run handles must also work for independently scheduled jobs.
    result = asyncio.run(Registry(app).call('workflow.get', {'run_id': job['run_id'], 'target': subject}))
    assert result['model'] == model
    assert next(row['value']['ef'] for row in result['records'] if row['ref'] == subject) == original_ef
    finish(app, job, contribution(subject, 'Advice based on the expanded context.', 'urn:test:deep-read'))
    bundle = inspect_layer(app, job['layer'], model)
    assert any(read['result'] == result and read['request_id'] == job['request_id'] for read in bundle['recipe']['context_reads'])
    assert all(dependency in bundle['attachments'][0]['dependencies'] for dependency in result['dependencies'])
