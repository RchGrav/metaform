"""Whole-artifact and exact-dispatch regressions for the release repair."""

import asyncio
from pathlib import Path

import pytest

from metaform import workfolders
from metaform.app import App
from metaform import bindings
from metaform.continuation import begin, marker
from metaform.history import checkpoint, initialize
from metaform.util import write_json
from metaform.workflow import Engine, import_workflow


@pytest.fixture(params=["json", "sqlite"])
def release_app(tmp_path, request):
    home = tmp_path / "home"
    write_json(home / "config.json", {
        "knowledge_mode": "legacy", "graph_backend": request.param, "auto_build": False,
    })
    return App(tmp_path / "project", home, binding=False)


@pytest.mark.parametrize("repository", [False, True])
@pytest.mark.parametrize("tracking", ["git", "files"])
def test_whole_artifact_survives_completion_and_apply(release_app, repository, tracking, monkeypatch):
    app = release_app
    if repository:
        workfolders.git(app.project, "init", "-q")
    (app.project / ".gitignore").write_text("*.bin\nignored/\n")
    (app.project / "ignored").mkdir()
    (app.project / "ignored" / "input.txt").write_text("initial\n")
    (app.project / "deleted.bin").write_bytes(b"\0delete")
    (app.project / "rename.txt").write_text("renamed\n")
    import_workflow(app, {"id": "edit", "steps": [{"id": "edit", "prompt": "Edit files"}]})
    engine = Engine(app)
    with monkeypatch.context() as patch:
        if tracking == "files":
            patch.setattr(workfolders.shutil, "which", lambda command: None)
        job = engine.start("edit", workfolder=True)
    folder = Path(job["workfolder"])
    assert (folder / "ignored" / "input.txt").read_text() == "initial\n"
    assert (folder / ".git").is_dir() == (tracking == "git")
    begin(job["nonce"], folder, app.home)
    bound = App(folder, app.home)
    (folder / "ignored" / "input.txt").write_text("edited\n")
    (folder / "added.bin").write_bytes(b"\0\xffadded")
    (folder / "deleted.bin").unlink()
    (folder / "rename.txt").rename(folder / "renamed.txt")
    assert ".agentid" not in workfolders.diff(app, app.load_run(job["run_id"])["workfolder_id"])["diff"]
    receipt = engine.submit(job["run_id"], job["request_id"], "done")
    assert marker(folder) is None and not (folder / ".agentid").exists()
    assert not (app.home / "assignments" / (job["nonce"] + ".json")).exists()
    assert Engine(bound).submit(job["run_id"], job["request_id"], "replay") == receipt
    final = engine.next(job["run_id"])
    workfolders.apply(app, final["result"]["workfolder"]["id"])
    assert (app.project / "ignored" / "input.txt").read_text() == "edited\n"
    assert (app.project / "added.bin").read_bytes() == b"\0\xffadded"
    assert not (app.project / "deleted.bin").exists()
    assert not (app.project / "rename.txt").exists()
    assert (app.project / "renamed.txt").read_text() == "renamed\n"
    assert marker(app.project) is None
    assert (app.project / ".git").exists() == repository


def test_legacy_completed_marker_cannot_rebind_a_source_project(release_app, tmp_path):
    from metaform.util import read_json

    app = release_app
    import_workflow(app, {"id": "one", "steps": [{"id": "one", "prompt": "Work"}]})
    job = Engine(app).start("one", exclusive=False)
    folder = tmp_path / "worker"
    begin(job["nonce"], folder, app.home)
    record = {key: value for key, value in marker(folder).items() if key != "folder"}
    Engine(app).submit(job["run_id"], job["request_id"], "done")
    bindings.record(app.project, record)
    assert marker(app.project) is None
    assert App(app.project, app.home).binding is None


def test_missing_assignment_marker_cannot_create_its_recorded_project(tmp_path):
    missing = tmp_path / "missing-project"
    folder = tmp_path / "worker"
    stale = {
        "project": str(missing), "home": str(tmp_path / "home"), "module": "workflow",
        "run_id": "missing-run", "request_id": "missing-request", "nonce": "123",
    }
    bindings.record(folder, stale)
    assert marker(folder) is None
    assert not missing.exists()

    home = tmp_path / "home"
    write_json(home / "assignments" / "123.json", stale)
    with pytest.raises(ValueError, match="no longer pending"):
        begin("123", folder, home)
    assert not missing.exists()


@pytest.mark.parametrize("tracking", ["git", "files"])
def test_workfolders_preserve_empty_directory_additions_removals_and_modes(release_app, tracking, monkeypatch):
    app = release_app
    (app.project / "kept").mkdir()
    (app.project / "removed").mkdir()
    with monkeypatch.context() as patch:
        if tracking == "files":
            patch.setattr(workfolders.shutil, "which", lambda command: None)
        folder = workfolders.create(app)
    target = Path(folder["path"])
    assert (target / "kept").is_dir()
    (target / "removed").rmdir()
    (target / "new" / "empty").mkdir(parents=True)
    (target / "kept").chmod(0o700)
    assert workfolders.apply(app, folder["id"])["applied"]
    assert (app.project / "new" / "empty").is_dir()
    assert not (app.project / "removed").exists()
    assert (app.project / "kept").stat().st_mode & 0o777 == 0o700


def test_exported_workfolder_retains_directories_and_retires_only_its_copy(release_app, tmp_path):
    from metaform.portable import export, import_bundle

    app = release_app
    (app.project / "empty").mkdir()
    import_workflow(app, {"id": "edit", "steps": [{"id": "work", "prompt": "Work"}]})
    original = Engine(app).start("edit", workfolder=True, exclusive=False)
    begin(original["nonce"], original["workfolder"], app.home)
    (Path(original["workfolder"]) / "added-empty").mkdir()
    archive = tmp_path / "copy.pyz"
    export(app, archive)
    imported = import_bundle(archive, tmp_path / "imports")
    project = Path(imported["path"])
    copied = App(project, project / ".metaform" / "home", binding=False)
    job = Engine(copied).next(original["run_id"])
    assert (Path(job["workfolder"]) / "empty").is_dir()
    assert (Path(job["workfolder"]) / "added-empty").is_dir()
    assert marker(job["workfolder"], copied.home)["request_id"] == original["request_id"], "The packet carried the binding"
    Engine(copied).submit(job["run_id"], job["request_id"], "done")
    assert marker(job["workfolder"], copied.home) is None
    assert marker(original["workfolder"])["request_id"] == original["request_id"]
    result = Engine(copied).next(job["run_id"])
    workfolders.apply(copied, result["result"]["workfolder"]["id"])
    assert (project / "added-empty").is_dir()


def test_cleanup_cannot_remove_a_sibling_binding(release_app, tmp_path):
    from metaform.portable import _selected_assignments, state_dump

    app = release_app
    import_workflow(app, {"id": "one", "steps": [{"id": "one", "prompt": "Work"}]})
    engine = Engine(app)
    first, second = [engine.start("one", exclusive=False) for _ in range(2)]
    folder = tmp_path / "worker"
    begin(first["nonce"], folder, app.home)
    begin(second["nonce"], folder, app.home)
    engine.submit(first["run_id"], first["request_id"], "first")
    assert marker(folder)["request_id"] == second["request_id"]
    assert (app.home / "assignments" / (second["nonce"] + ".json")).exists()
    engine.abort(second["run_id"])
    assert marker(folder) is None
    assert not (app.home / "assignments" / (second["nonce"] + ".json")).exists()
    assert _selected_assignments(app, state_dump(app)) == {}


def test_git_history_baseline_does_not_copy_unchanged_files(release_app):
    app = release_app
    workfolders.git(app.project, "init", "-q")
    path = app.project / "file.txt"
    path.write_text("unchanged\n")
    path.chmod(0o644)
    workfolders.git(app.project, "add", "file.txt")
    workfolders.git(app.project, "-c", "user.name=Test", "-c", "user.email=test@localhost", "commit", "-qm", "baseline")
    assert initialize(app)["baseline_kind"] == "git_commit"
    assert checkpoint(app)["changes"] == {}


def test_running_recursion_carries_inputs_and_reports_missing_data(release_app):
    app = release_app
    import_workflow(app, {"id": "repeat", "steps": [{"id": "work", "prompt": "{{topic}} {{style}}"}]})
    engine = Engine(app)
    parent = engine.start("repeat", {"topic": "project", "style": "brief"}, exclusive=False)
    child = engine.recursive(parent["run_id"], {"style": "detailed"})
    assert child["prompt"] == "project detailed"
    assert engine.next(parent["run_id"]) == parent
    assert app.load_run(child["run_id"])["parent"] == parent["run_id"]
    with pytest.raises(ValueError, match="Missing workflow input.*style"):
        engine.start("repeat", {"topic": "missing"}, exclusive=False)


def test_user_wait_survives_reopen_and_drive_uses_actual_response(release_app):
    from metaform.modules.workflow import drive

    app = release_app
    import_workflow(app, {"id": "choose", "steps": [
        {"id": "choice", "kind": "user", "prompt": "Which direction?", "schema": {"type": "string"},
         "transitions": [{"when": {"==": [{"var": "steps.choice"}, "left"]}, "to": "left"}, {"to": "right"}]},
        {"id": "left", "prompt": "Go left", "next": None},
        {"id": "right", "prompt": "Go right"},
    ]})
    engine = Engine(app)
    job = engine.start("choose", exclusive=False)
    assert job["status"] == "awaiting_user"
    reopened = App(app.project, app.home, binding=False)
    assert asyncio.run(drive(reopened, {"run_id": job["run_id"], "harness": "not-installed"}, None)) == job
    receipt = Engine(reopened).submit(job["run_id"], job["request_id"], "left")
    assert receipt["recorded"]
    assert engine.next(job["run_id"])["prompt"] == "Go left"
    assert engine.submit(job["run_id"], job["request_id"], "right") == receipt
    assert engine.next(job["run_id"])["prompt"] == "Go left"


def test_workflow_discovery_and_answer_require_explicit_identity(release_app):
    from metaform.modules.workflow import answer, drive
    from metaform.registry import Registry

    app = release_app
    import_workflow(app, {"id": "known", "intent": "A procedure", "inputs": {"topic": "Subject"},
                          "steps": [{"id": "one", "prompt": "Work"}]})
    catalog = asyncio.run(Registry(app).call("workflow.list", {}))["workflows"]
    item = next(item for item in catalog if item["id"] == "known")
    assert item["intent"] == "A procedure" and item["inputs"] == {"topic": "Subject"}
    job = asyncio.run(Registry(app).call(item["start"]["command"], item["start"]["arguments"]))
    with pytest.raises(ValueError, match="run_id.*nonce"):
        answer(app, {"answer": "unidentified"}, None)
    report = asyncio.run(drive(app, {"run_id": job["run_id"]}, None))
    assert report["execution"]["status"] == "not_started"
    assert "sampling" in report["execution"]["reason"]
    assert app.load_run(job["run_id"])["pending"] == job
    assert answer(app, {"run_id": job["run_id"], "answer": "identified"}, None)["recorded"]


def test_each_task_runs_its_specialists_and_repair_loop_in_order(release_app):
    app = release_app
    import_workflow(app, {"id": "tasks", "workflows": [
        {"id": "task", "steps": [
            {"id": "implement", "role": "{{role}}", "prompt": "Build {{item}}"},
            {"id": "evaluate", "role": "Evaluator", "context": "fresh", "prompt": "Evaluate {{steps.implement}}",
             "transitions": [{"when": {"var": "steps.evaluate.retry"}, "to": "implement"}, {"to": None}]},
        ]},
    ], "steps": [
        {"id": "each", "kind": "foreach", "items": {"var": "inputs.tasks"}, "workflow": "task",
         "inputs": {"item": {"var": "item"}, "role": {"literal": "Implementer"}}},
    ]})
    engine = Engine(app)
    result = engine.start("tasks", {"tasks": ["A", "B"]}, exclusive=False)
    seen = []
    answers = iter(["A first", {"retry": True}, "A repaired", {"retry": False}, "B first", {"retry": False}])
    for _ in range(30):
        if result["status"] == "complete":
            break
        if result["status"] == "awaiting_answer":
            seen.append((result["role"], result["prompt"]))
            engine.submit(result["run_id"], result["request_id"], next(answers))
        result = engine.next(result["run_id"])
    assert result["status"] == "complete"
    assert seen == [("Implementer", "Build A"), ("Evaluator", "Evaluate A first"),
                    ("Implementer", "Build A"), ("Evaluator", "Evaluate A repaired"),
                    ("Implementer", "Build B"), ("Evaluator", "Evaluate B first")]
    assert [item["steps"]["implement"] for item in result["result"]["steps"]["each"]] == ["A repaired", "B first"]


@pytest.mark.parametrize("external", [False, True])
def test_replacing_directory_symlink_never_mutates_its_target(release_app, tmp_path, external):
    app = release_app
    target = (tmp_path if external else app.project) / "target"
    target.mkdir()
    (target / "keep.txt").write_text("original")
    (app.project / "alias").symlink_to(target, target_is_directory=True)
    folder = workfolders.create(app)
    alias = Path(folder["path"]) / "alias"
    alias.unlink()
    alias.mkdir()
    (alias / "keep.txt").write_text("new")
    assert workfolders.apply(app, folder["id"])["applied"]
    assert (app.project / "alias" / "keep.txt").read_text() == "new"
    assert not (app.project / "alias").is_symlink()
    assert (target / "keep.txt").read_text() == "original"


def test_legacy_git_baseline_does_not_treat_existing_directories_as_added(release_app):
    app = release_app
    (app.project / 'nested').mkdir()
    (app.project / 'nested' / 'file.txt').write_text('before')
    folder = workfolders.create(app)
    # A persisted pre-repair workfolder stored only the Git baseline revision.
    legacy = {key: value for key, value in folder.items() if key != 'files'}
    import json
    with app.db() as db:
        db.execute('UPDATE workfolders SET body=? WHERE id=?', (json.dumps(legacy), folder['id']))
    (Path(folder['path']) / 'nested' / 'file.txt').write_text('after')
    report = workfolders.diff(app, folder['id'])
    assert set(report['changes']) == {'nested/file.txt'}
    workfolders.apply(app, folder['id'])
    assert (app.project / 'nested' / 'file.txt').read_text() == 'after'


def test_receipt_retires_request_dispatch_and_preserves_exact_artifacts(release_app):
    app = release_app
    import_workflow(app, {'id': 'request-artifacts', 'steps': [{'id': 'work', 'prompt': 'Work'}]})
    engine = Engine(app)
    job = engine.start('request-artifacts', exclusive=False)
    request = app.home / 'requests' / job['request_id']
    write_json(request / 'request.json', job)
    write_json(request / 'schema.json', {'type': 'string'})
    (request / 'response.json').write_bytes(b'"raw answer"\n')
    receipt = engine.submit(job['run_id'], job['request_id'], 'raw answer')
    assert not request.exists()
    retained = app.root / 'outputs' / 'requests' / job['request_id']
    assert (retained / 'response.json').read_bytes() == b'"raw answer"\n'
    assert Engine(app).submit(job['run_id'], job['request_id'], 'replay') == receipt
    assert (retained / 'schema.json').read_text()


def test_harness_keeps_inflight_dispatch_until_receipted_executor_exits(release_app):
    import sys
    from metaform.harness import execute

    app = release_app
    app.config['harnesses'] = {'fixture': {'command': [sys.executable, '-c',
        'import time; time.sleep(0.2); print(\'"observed"\')']}}
    import_workflow(app, {'id': 'inflight', 'steps': [{'id': 'work', 'prompt': 'Work'}]})
    engine = Engine(app)
    job = engine.start('inflight', exclusive=False)
    request = app.home / 'requests' / job['request_id']

    async def run():
        execution = asyncio.create_task(execute(app, job, 'fixture'))
        while not app.get('executing:' + job['request_id']):
            await asyncio.sleep(0.01)
        engine.submit(job['run_id'], job['request_id'], 'accepted before executor exit')
        assert request.exists()
        assert await execution == {'status': 'answered', 'answer': 'observed'}

    asyncio.run(run())
    assert not request.exists()
    assert (app.root / 'outputs' / 'requests' / job['request_id'] / 'request.json').exists()


def test_cleaned_empty_output_directory_survives_export_import(release_app, tmp_path):
    from metaform import portable

    app = release_app
    folder = workfolders.create(app, empty=True)
    (Path(folder['path']) / 'empty-output').mkdir(mode=0o750)
    workfolders.cleanup(app, folder['id'])
    archive = tmp_path / 'outputs.pyz'
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / 'copies')['path'])
    output = target / '.metaform' / 'outputs' / folder['id'] / 'empty-output'
    assert output.is_dir()
    assert output.stat().st_mode & 0o777 == 0o750


def test_exported_workfolder_applies_empty_directory_changes_to_reconstructed_source(release_app, tmp_path):
    from metaform import portable

    app = release_app
    (app.project / 'kept-empty').mkdir(mode=0o750)
    (app.project / 'removed-empty').mkdir()
    folder = workfolders.create(app)
    (Path(folder['path']) / 'removed-empty').rmdir()
    (Path(folder['path']) / 'new-empty').mkdir()
    archive = tmp_path / 'directories.pyz'
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / 'copies')['path'])
    imported = App(target, target / '.metaform' / 'home', binding=False)
    assert (target / 'kept-empty').stat().st_mode & 0o777 == 0o750
    assert (target / 'removed-empty').is_dir()
    assert workfolders.apply(imported, folder['id'])['applied']
    assert (target / 'kept-empty').is_dir()
    assert (target / 'new-empty').is_dir()
    assert not (target / 'removed-empty').exists()


def test_embedding_application_handoff_starts_actual_metaform_in_empty_folder(release_app, tmp_path, monkeypatch):
    import json
    import os
    import shlex
    import subprocess
    import sys

    app = release_app
    driver = tmp_path / 'unrelated_embedding_application.py'
    driver.write_text('raise SystemExit("This is the host application, not the worker CLI")\n')
    monkeypatch.setattr(sys, 'argv', [str(driver)])
    import_workflow(app, {'id': 'embedded', 'steps': [{'id': 'work', 'prompt': 'Stored assignment'}]})
    job = Engine(app).start('embedded', exclusive=False)
    folder = tmp_path / 'empty-worker'
    folder.mkdir()
    environment = dict(os.environ, METAFORM_HOME=str(app.home))
    environment.pop('PYTHONPATH', None)
    result = subprocess.run(shlex.split(job['begin']), cwd=folder, env=environment, capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    begun = json.loads(result.stdout)
    assert begun['request_id'] == job['request_id'] and begun['prompt'] == 'Stored assignment'


@pytest.mark.parametrize('content', ['{}', '[]', '{broken'])
def test_malformed_ambient_marker_keeps_reference_available_and_valid_parent_binding(release_app, tmp_path, content):
    import json
    import os
    import subprocess
    import sys
    from metaform.util import python_environment

    app = release_app
    folder = tmp_path / 'malformed-worker'
    folder.mkdir(parents=True)
    with bindings.writing(app.home) as db:
        db.execute("INSERT OR REPLACE INTO bindings VALUES(?,?,?,?,?,?)",
                   (str(folder), 'x', 'x', content, bindings.now(), bindings.now()))
    for command in [['--help'], ['system', 'reference']]:
        result = subprocess.run([sys.executable, '-m', 'metaform', *command], cwd=folder,
                                env=python_environment() | {'METAFORM_HOME': str(app.home)},
                                capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
    import_workflow(app, {'id': 'valid-parent', 'steps': [{'id': 'work', 'prompt': 'Pending parent'}]})
    job = Engine(app).start('valid-parent', exclusive=False)
    begin(job['nonce'], folder.parent, app.home)
    assert marker(folder)['request_id'] == job['request_id']
    write_json(app.home / 'assignments' / 'broken.json', {})
    with pytest.raises(ValueError, match='handoff'):
        begin('broken', folder, app.home)


def test_pending_handoff_after_upgrade_uses_current_installation_without_reissuing(release_app, tmp_path):
    import json
    import os
    import shlex
    import subprocess

    app = release_app
    engine = Engine(app)
    import_workflow(app, {'id': 'upgrade', 'steps': [{'id': 'work', 'prompt': 'Original prompt'}]})
    job = engine.start('upgrade', exclusive=False)
    run = app.load_run(job['run_id'])
    run['pending']['begin'] = '/missing/old-host.py begin ' + job['nonce']
    app.save_run(run)
    current = engine.next(job['run_id'])
    assert current['begin'] != run['pending']['begin']
    assert {key: value for key, value in current.items() if key != 'begin'} == {key: value for key, value in job.items() if key != 'begin'}
    folder = tmp_path / 'recovered-worker'
    folder.mkdir()
    env = dict(os.environ, METAFORM_HOME=str(app.home))
    env.pop('PYTHONPATH', None)
    observed = subprocess.run(shlex.split(current['begin']), cwd=folder, env=env, capture_output=True, text=True)
    assert observed.returncode == 0, observed.stderr
    assert json.loads(observed.stdout)['request_id'] == job['request_id']
    assert app.load_run(job['run_id'])['pending']['begin'] == run['pending']['begin']
    receipt = engine.submit(job['run_id'], job['request_id'], 'done')
    assert engine.submit(job['run_id'], job['request_id'], 'replayed') == receipt
