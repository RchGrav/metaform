import asyncio
import json
import subprocess
import threading
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from metaform.modules import web as viewer


@pytest.fixture(autouse=True)
def fixed_free_port(request):
    """Each test's web interface takes a port of its own, so suites never collide on the fixed default."""
    if "app" in request.fixturenames:
        import socket
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            request.getfixturevalue("app").config["web_port"] = probe.getsockname()[1]


def test_viewer_reuses_global_instance_and_restarts_after_stop(app):
    from metaform.service import service_status

    async def check():
        first = await viewer.start(app, {}, None)
        again = await viewer.start(app, {}, None)
        assert (again["pid"], again["port"], again["instance_id"]) == (first["pid"], first["port"], first["instance_id"])
        assert app.get("viewer") is None
        assert service_status()["instance_id"] == first["instance_id"]
        assert (await viewer.stop(app, {}, None))["stopped"]
        second = await viewer.start(app, {}, None)
        assert second["instance_id"] != first["instance_id"]
        with urllib.request.urlopen(second["url"], timeout=5) as response:
            assert response.status == 200
        await viewer.stop(app, {}, None)

    asyncio.run(check())


def test_viewer_does_not_reuse_an_unrelated_listener(app):
    class OtherViewer(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"product": "metaform-viewer", "instance_id": "another-viewer"}).encode())

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), OtherViewer)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    ready = app.root / "old.ready"
    ready.write_text("{}")
    app.set("viewer", {"id": "old", "instance_id": "old", "ready": str(ready),
                       "stop": str(app.root / "old.stop"), "url": f"http://127.0.0.1:{server.server_port}"})

    async def check():
        actual = await viewer.start(app, {}, None)
        try:
            assert actual["instance_id"] != "old"
            with urllib.request.urlopen(actual["url"] + "/api/health", timeout=5) as response:
                health = json.load(response)
                assert health["product"] == "metaform-viewer"
                assert health["instance_id"] == actual["instance_id"]
                assert health["pid"] == actual["pid"]
            assert ready.exists()
            assert not (app.root / "old.stop").exists()
        finally:
            await viewer.stop(app, {}, None)

    try:
        asyncio.run(check())
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_global_viewer_retires_its_verified_legacy_instance(app):
    from metaform.util import write_json

    identifier = "legacy-instance"
    instance = "viewer-" + identifier
    ready, stop = app.root / (instance + ".ready"), app.root / (instance + ".stop")

    class LegacyViewer(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"product": "metaform-viewer", "instance_id": instance}).encode())

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), LegacyViewer)
    serving = threading.Thread(target=server.serve_forever, daemon=True)
    serving.start()
    url = f"http://127.0.0.1:{server.server_port}"
    write_json(ready, {"url": url, "instance_id": instance})
    app.set("viewer", {"id": identifier, "instance_id": instance, "url": url,
                       "ready": str(ready), "stop": str(stop)})
    finish = threading.Event()

    def monitor():
        while not finish.wait(.02):
            if stop.exists():
                server.shutdown()
                server.server_close()
                ready.unlink()
                stop.unlink()
                return

    watching = threading.Thread(target=monitor, daemon=True)
    watching.start()
    try:
        current = asyncio.run(viewer.start(app, {}, None))
        assert current["instance_id"] != instance
        assert not ready.exists()
        assert app.get("viewer") is None
        serving.join(timeout=2)
        assert not serving.is_alive()
    finally:
        finish.set()
        server.shutdown()
        server.server_close()
        watching.join(timeout=2)
        asyncio.run(viewer.stop(app, {}, None))


def test_report_distinguishes_artifacts_and_retains_pending_handoff(app):
    app.graph.put({"elements": {
        "document.guide": {"entity_schema": "metaform:element", "entity_desc": "Guidance", "entity_json_obj": {"ef": "Guides work"}},
        "guide": {"entity_schema": "metaform:actual-element", "entity_desc": "Project guide", "entity_json_obj": {"type_ids": ["document.guide"]}},
    }, "joins": []}, "native")
    job = {"request_id": "request-1", "run_id": "run-1", "status": "awaiting_answer", "begin": "metaform begin 123", "workfolder": "/example/work"}
    app.save_run({"id": "run-1", "workflow": "example", "status": "running", "pending": job})
    result = viewer.report(app, {}, None)
    assert result["stats"]["elements"] == 1
    assert result["stats"]["types"] == 1
    assert result["assignments"] == [job]
    run = app.load_run("run-1")
    run.update(status="complete", pending=None)
    app.save_run(run)
    assert viewer.report(app, {}, None)["assignments"] == []


def test_report_preserves_continuation_between_workflow_assignments(app):
    from metaform.workflow import Engine, import_workflow

    import_workflow(app, {"id": "two-stage", "steps": [
        {"id": "first", "prompt": "First"}, {"id": "second", "prompt": "Second"}]})
    engine = Engine(app)
    first = engine.start("two-stage")
    engine.submit(first["run_id"], first["request_id"], "Recorded first")
    report = viewer.report(app, {}, None)
    assert report["assignments"] == []
    assert report["continuations"] == [{"run_id": first["run_id"], "workflow": "two-stage",
        "status": "Continue required", "next": {"command": "workflow.next", "arguments": {"run_id": first["run_id"]}}}]
    second = engine.next(first["run_id"])
    assert second["step"] == "second"
    assert viewer.report(app, {}, None)["continuations"] == []
    engine.submit(second["run_id"], second["request_id"], "Recorded second")
    assert viewer.report(app, {}, None)["continuations"]
    engine.next(second["run_id"])
    assert viewer.report(app, {}, None)["continuations"] == []


def test_pending_poll_does_not_export_graph_events_or_full_worker_context(app, monkeypatch):
    from metaform.viewer import create_app

    job = {"request_id": "request-large", "run_id": "run-large", "status": "awaiting_answer",
           "begin": "metaform begin 123", "workfolder": "/example/worker", "prompt": "context" * 200000}
    app.save_run({"id": "run-large", "workflow": "large-context", "status": "running", "pending": job})
    def unexpected_export(*args, **kwargs):
        raise AssertionError("Pending status must not export graph contents")
    monkeypatch.setattr(app.graph, "export", unexpected_export)
    response = create_app(app).test_client().get('/api/pending')
    assert response.status_code == 200
    result = response.get_json()
    assert result['assignments'] == [{key: value for key, value in job.items() if key != 'prompt'}]
    assert len(response.data) < 1000
    assert app.load_run('run-large')['pending']['prompt'] == job['prompt']


def test_pending_user_wait_retains_actual_question_and_response_contract(app):
    from metaform.workflow import Engine, import_workflow

    import_workflow(app, {"id": "ask-user", "steps": [{"id": "choice", "kind": "user",
        "prompt": "Which subject should the next review address?", "schema": {"type": "string"}}]})
    job = Engine(app).start('ask-user')
    displayed = viewer.pending(app)['assignments'][0]
    assert displayed['status'] == 'awaiting_user'
    assert displayed['prompt'] == job['prompt']
    assert displayed['schema'] == job['schema']


def test_activity_reports_stored_failure_without_pending_work(app):
    from metaform.workflow import Engine, import_workflow

    import_workflow(app, {"id": "failure", "steps": [{"id": "work", "prompt": "Work"}]})
    engine = Engine(app)
    job = engine.start("failure")
    failure = {"kind": "worker_failure", "message": "Harness exited 9: deliberate worker crash", "attempts": 2}
    engine.fail(job["run_id"], failure)
    result = viewer.report(app, {}, None)
    saved = next(run for run in result["runs"] if run["id"] == job["run_id"])
    assert saved["status"] == "failed"
    assert saved["failure"]["message"] == failure["message"]
    assert saved["failure"]["attempts"] == 2
    assert viewer.pending(app) == {"assignments": [], "continuations": []}
