import asyncio
import base64
import dataclasses
import os
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest

from metaform.intake import Intake
from metaform.modules import _imagegen as imagegen
from metaform.registry import Registry


PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY2cAAAAASUVORK5CYII="
)


@pytest.fixture
def provider(tmp_path, monkeypatch):
    monkeypatch.setattr(imagegen, "_STATUS_CACHE", {})
    monkeypatch.setattr(imagegen.tempfile, "gettempdir", lambda: str(tmp_path))
    status = imagegen.CodexStatus(
        installed=True, path="unused-codex", node_version="22.0.0",
        node_version_supported=True, version="0.144.0", version_supported=True,
        authenticated=True, login_output="Logged in", exec_available=True,
        image_option_available=True, imagegen_skill_available=True,
        generated_images_dir=str(tmp_path / "shared-generated"), problems=(),
    )
    monkeypatch.setattr(imagegen, "probe_codex", lambda: status)
    return status


@pytest.mark.parametrize("source", ["stale_stdout", "unchanged_output", "other_session"])
def test_imagegen_rejects_files_not_produced_for_invocation(provider, tmp_path, source):
    output = tmp_path / "result.png"
    old = tmp_path / "old.png"
    old.write_bytes(PNG)
    os.utime(old, (1, 1))
    if source == "unchanged_output":
        output.write_bytes(PNG)

    def runner(command, **kwargs):
        if source == "other_session":
            folder = Path(provider.generated_images_dir)
            folder.mkdir()
            (folder / "other.png").write_bytes(PNG)
        text = f"Cannot generate an image. Existing image: {old}"
        return subprocess.CompletedProcess(command, 0, text if source == "stale_stdout" else "No image generated.")

    with pytest.raises(imagegen.ImageToolError, match="without an image file"):
        imagegen.run_codex_image(provider, "request", [], output, runner=runner)
    if source == "unchanged_output":
        assert output.read_bytes() == PNG
    else:
        assert not output.exists()


@pytest.mark.parametrize("preexisting", [False, True, "same_bytes"])
def test_imagegen_accepts_invocation_output_even_with_old_preserved_mtime(provider, tmp_path, preexisting):
    output = tmp_path / "result.png"
    if preexisting:
        output.write_bytes(PNG if preexisting == "same_bytes" else b"previous output")
        os.utime(output, (1, 1))

    def runner(command, **kwargs):
        output.write_bytes(PNG)
        os.utime(output, (1, 1))
        return subprocess.CompletedProcess(command, 0, f"SAVED: {output}")

    saved, text = imagegen.run_codex_image(provider, "request", [], output, runner=runner)
    assert saved == output
    assert saved.read_bytes() == PNG
    assert text == f"SAVED: {output}"


@pytest.mark.parametrize("bound", [False, True])
def test_imagegen_latent_routes_relative_input_and_output_to_assignment(app, bound):
    engine = Intake(app)
    native = engine._start("native")
    run_id = native["run_id"]
    objects = {
        "code": {"entity_desc": "Program code", "entity_schema": "metaform:element",
                 "entity_json_obj": {"en": "Program code", "aliases": [], "notes": "Exact Type context."}},
        "tests": {"entity_desc": "Program tests", "entity_schema": "metaform:element",
                  "entity_json_obj": {"en": "Program tests", "aliases": [], "notes": "Exact test context."}},
    }
    engine.submit(run_id, native["request_id"], {"elements": objects, "joins": []})
    jobs = engine.batch(run_id)
    assert len(jobs) == 1
    for job in jobs:
        folder = Path(job["workfolder"])
        (folder / "source.png").write_bytes(PNG)
        if bound:
            app.binding = {"module": "intake", "run_id": run_id, "request_id": job["request_id"]}
            assert "imagegen.generate" not in Registry(app).visible()
            run = app.load_run(run_id)
            run["pending"]["tools"].append("imagegen.generate")
            app.save_run(run)
        identifiers = {} if bound else {"run_id": run_id, "request_id": job["request_id"]}
        result = asyncio.run(Registry(app).call("imagegen.generate", {
            "prompt": "A red cube", **identifiers,
            "image": "source.png", "dry_run": True,
        }))
        assert f"SAVED: {folder / 'image.png'} last." in result["prompt"]
        assert "source.png" in result["prompt"]
        assert result["generated"] is False


@pytest.mark.parametrize("probe", ["mcp", "cli", "refresh"])
def test_imagegen_status_remediation_allows_generation_in_same_process(app, provider, monkeypatch, capsys, probe):
    statuses = iter([dataclasses.replace(provider, problems=("missing dependency",)), provider])
    monkeypatch.setattr(imagegen, "probe_codex", lambda: next(statuses))
    with pytest.raises(imagegen.ImageToolError, match="missing dependency"):
        imagegen.require_codex()
    if probe == "mcp":
        assert imagegen.call_tool("image_status", {"refresh": True})["ready"]
    elif probe == "cli":
        assert imagegen._cmd_status(SimpleNamespace(json=True)) == 0
        capsys.readouterr()
    else:
        assert imagegen.require_codex(refresh=True).ready
    output = app.project / "image.png"

    def runner(command, **kwargs):
        output.write_bytes(PNG)
        return subprocess.CompletedProcess(command, 0, f"SAVED: {output}")

    monkeypatch.setattr(subprocess, "run", runner)
    result = asyncio.run(Registry(app).call("imagegen.generate", {"prompt": "A red cube"}))
    assert result["generated"] is True
    assert Path(result["output_path"]).read_bytes() == PNG
