from metaform.continuation import marker
import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from mcp import Client
from mcp.client.stdio import StdioServerParameters

from metaform.registry import Registry
from test_knowledge_layers import foundation as published_foundation


def test_skill_cli_prints_guidance_without_opening_project(tmp_path):
    project = tmp_path / "unopened"
    project.mkdir()
    result = subprocess.run(
        [sys.executable, "-m", "metaform", "--project", str(project), "skill"],
        cwd=project, env={**os.environ, "METAFORM_HOME": str(tmp_path / "home")},
        capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    assert result.stdout.startswith("---\n")
    assert "## Registered abilities" in result.stdout
    assert "## Available workflows" in result.stdout
    assert "metaform.library.orchestrator" in result.stdout
    assert "### Knowledge Tool" in result.stdout
    assert "metaform knowledge --help" in result.stdout
    assert "q1_array" not in result.stdout
    assert not list(project.iterdir())
    assert not (tmp_path / "home").exists()


def test_installed_skill_is_base_information_that_points_at_metaform_skill():
    from metaform.onboarding import skill_text

    installed = skill_text(include_catalog=False)
    assert "metaform skill" in installed
    assert "workflows" in installed and "modules" in installed
    assert "## Registered abilities" not in installed
    assert "## Available workflows" not in installed


def test_skill_page_lists_loaded_modules_and_available_workflows(app):
    async def scenario():
        text = (await Registry(app).call("guide.skill"))["text"]
        assert text.index("## Registered abilities") < text.index("## Available workflows")
        workflows = text.split("## Available workflows", 1)[1]
        assert "metaform.library.orchestrator" in workflows
        assert "metaform workflow start --id <id>" in workflows
        from metaform.workflow import import_workflow
        import_workflow(app, {"id": "project.review", "intent": "Review the project's findings.", "start": "review",
                              "steps": [{"id": "review", "kind": "prompt", "prompt": "Review the findings and answer.", "template": False}]})
        text = (await Registry(app).call("guide.skill"))["text"]
        section = text.split("## Available workflows", 1)[1]
        assert "project.review" in section and "Review the project's findings." in section

    asyncio.run(scenario())


def test_instructions_tell_an_agent_it_is_developing_metaform(tmp_path):
    import shutil
    from metaform.app import App
    from metaform.onboarding import instructions, skill_text

    repository = Path(__file__).resolve().parents[1]
    clone = tmp_path / "metaform-clone"
    (clone / "src" / "metaform").mkdir(parents=True)
    (clone / "src" / "metaform" / "cli.py").write_text("")
    (clone / "pyproject.toml").write_text('[project]\nname = "metaform-chassis"\n')
    shutil.copytree(repository / ".agents" / "skills" / "metaform-dev", clone / ".agents" / "skills" / "metaform-dev")
    developing = App(clone, tmp_path / "home")
    text = instructions(developing)
    assert text.startswith("# You are actively developing Metaform in its own repository")
    assert "docs/SPEC.md" in text and "continuation.py" in text and "CLAUDE.md" in text
    assert "actively developing Metaform" in skill_text(developing)
    other = tmp_path / "other"
    other.mkdir()
    assert "developing Metaform" not in instructions(App(other, tmp_path / "home"))


def test_skill_catalog_follows_registered_modules(app):
    import shutil
    from metaform.util import write_json

    directory = app.root / "modules" / "community"
    write_json(directory / "module.json", {
        "id": "community", "name": "Community Reports", "description": "Summarize project findings.",
        "guidance": "Ask which topic to summarize before calling the command.",
        "commands": [
            {"name": "summary", "handler": "handler.py:summary", "description": "Summarize the selected topic."},
            {"name": "archive", "handler": "handler.py:summary", "description": "Archive project findings."},
        ],
    })
    (directory / "handler.py").write_text("def summary(app, args, context): return {'topic': args['topic']}\n")
    app.set("disabled_commands", ["community.archive"])

    async def scenario():
        text = (await Registry(app).call("guide.skill"))["text"]
        section = text.split("### Community Reports", 1)[1].split("###", 1)[0]
        assert "Summarize project findings." in section
        assert "metaform community --help" in section
        reference = await Registry(app).call("system.reference", {"module": "community"})
        assert reference["modules"][0]["guidance"] == "Ask which topic to summarize before calling the command."
        assert "community.summary" in [item["name"] for item in reference["modules"][0]["commands"]]
        assert "community.archive" not in text
        assert text.index("## Registered abilities") < text.index("### Community Reports")
        shutil.rmtree(directory)
        assert "Community Reports" not in (await Registry(app).call("guide.skill"))["text"]
        assert "### Knowledge Tool" in (await Registry(app).call("guide.skill"))["text"]

    asyncio.run(scenario())


def test_guide_reads_intake_state_without_advancing_it(app):
    (app.project / "guide.txt").write_text("Maintenance instructions for this machine.")
    async def scenario():
        registry = Registry(app)
        initial = await registry.call("guide.start")
        assert initial["project"]["path"] == str(app.project)
        assert initial["models"] == []
        assert initial["next"]["command"] == "intake.start"
        assert app.get("mode") is None
        with app.db() as db:
            assert db.execute("SELECT COUNT(*) FROM runs").fetchone()[0] == 0

        assignment = await registry.call("intake.start")
        before = app.load_run(assignment["run_id"])
        active = await registry.call("guide.start")
        assert active["run"]["id"] == assignment["run_id"]
        assert active["run"]["status"] == "running"
        assert active["next"] == {
            "command": "intake.next", "arguments": {"run_id": assignment["run_id"]}
        }
        assert app.load_run(assignment["run_id"]) == before

    asyncio.run(scenario())


@pytest.mark.parametrize("source", ["repository", "plan"])
def test_guide_drives_public_onboarding_through_generated_and_selected_knowledge(app, source):
    from metaform.app import App
    from metaform.onboarding import instructions
    from test_foundation_intake import contribution

    plan = "Design a maintenance guide for this machine.\nPreserve {{ literal intent }} and this exact plan."
    if source == "repository":
        (app.project / "guide.txt").write_text("Explain machine lubrication and inspection.")

    async def scenario():
        registry = Registry(app)
        initial = await registry.call("guide.start")
        if source == "plan":
            assert initial["status"] == "needs_project_input"
            assert initial["next"] is None
            initial = await registry.call("guide.start", {"plan": plan})
            assert initial["next"]["arguments"]["artifact_context"] == {
                "project": str(app.project), "owner": "project:" + app.project_id,
                "subject": "design described by plan", "plan": plan,
            }
        assert initial["status"] == "needs_intake"
        job = await registry.call(initial["next"]["command"], initial["next"]["arguments"])
        begin = subprocess.run(
            [sys.executable, "-m", "metaform", "--project", str(app.project), "begin", job["nonce"]],
            cwd=app.project, env={**os.environ, "METAFORM_HOME": str(app.home)},
            capture_output=True, text=True,
        )
        assert begin.returncode == 0, begin.stderr
        delivered = json.loads(begin.stdout)
        assert delivered["prompt"] == job["prompt"]
        if source == "plan":
            assert delivered["inputs"]["artifact_context"]["plan"] == plan
            assert delivered["inputs"]["artifact_context"]["subject"] == "design described by plan"
            assert delivered["inputs"]["source_manifest"] == {"files": []}
        else:
            assert delivered["inputs"]["source_manifest"]["files"] == ["guide.txt"]
        binding = marker(app.project, app.home)
        bound = App(app.project, app.home, binding=binding)
        assert json.loads(instructions(bound))["prompt"] == job["prompt"]

        await registry.call("intake.answer", {"run_id": job["run_id"], "request_id": job["request_id"], "answer": contribution(app)})
        result = await registry.call("intake.next", {"run_id": job["run_id"]})
        assert result["status"] == "complete"
        setup = await registry.call("guide.start")
        assert setup["status"] == "needs_best_practices"
        assert setup["next"] == {"command": "knowledge.start", "arguments": {
            "request": "Write 3 best practices", "name": "Best Practices", "model": result["model"]}}
        job = await registry.call(setup["next"]["command"], setup["next"]["arguments"])
        pending = await registry.call("guide.start")
        assert pending["status"] == "in_progress"
        assert pending["next"] == {"command": "workflow.next", "arguments": {"run_id": job["run_id"]}}
        answers = {field: ["Recorded advice one", "Recorded advice two", "Recorded advice three"] for field in job["inputs"]["questions"]}
        await registry.call("workflow.answer", {"run_id": job["run_id"], "request_id": job["request_id"], "answer": answers})
        generated = await registry.call("workflow.next", {"run_id": job["run_id"]})
        assert generated["status"] == "complete"
        setup = await registry.call("guide.start")
        assert setup["status"] == "needs_layer_selection"
        assert setup["next"] == {"command": "layer.select", "arguments": {"model": result["model"], "layer": generated["layer"]}}
        await registry.call(setup["next"]["command"], setup["next"]["arguments"])
        ready = await registry.call("guide.start")
        assert ready["status"] == "ready"
        assert ready["selected_layer"] == generated["layer"]
        assert ready["next"] is None
        assert ready["changes"]["status"] == ("planned" if source == "plan" else "available")
        assert ready["changes"]["percentage"] == (None if source == "plan" else 0)
        await registry.call("layer.select", {"model": result["model"], "layer": None})
        ready = await registry.call("guide.start")
        assert ready["status"] == "ready"
        assert ready["selected_layer"] is None
        assert ready["next"] is None
        assert json.loads(instructions(app).rsplit("\n\n", 1)[1])["status"] == "ready"

    asyncio.run(scenario())


def test_guide_exposes_registered_module_commands_with_current_visibility(app):
    from metaform.util import write_json

    directory = app.root / "modules" / "community"
    write_json(directory / "module.json", {
        "id": "community", "name": "Community Reports", "description": "Summarize project findings.",
        "commands": [
            {"name": "summary", "handler": "handler.py:summary", "description": "Summarize the selected topic.",
             "inputSchema": {"type": "object", "properties": {"topic": {"type": "string"}}, "required": ["topic"]}},
            {"name": "archive", "handler": "handler.py:summary", "description": "Archive project findings."},
        ],
    })
    (directory / "handler.py").write_text("def summary(app, args, context): return {'topic': args['topic']}\n")

    async def scenario():
        registry = Registry(app)
        app.set("disabled_commands", ["community.archive"])
        state = await registry.call("guide.start")
        assert [module["id"] for module in state["modules"]] == sorted(module["id"] for module in state["modules"])
        community = next(module for module in state["modules"] if module["id"] == "community")
        assert community == {
            "id": "community", "name": "Community Reports", "description": "Summarize project findings.",
            "commands": [{"name": "community.summary", "description": "Summarize the selected topic.",
                          "inputSchema": {"type": "object", "properties": {"topic": {"type": "string"}}, "required": ["topic"]}}],
        }
        command = community["commands"][0]
        assert await registry.call(command["name"], {"topic": "installer"}) == {"topic": "installer"}
        await registry.call("intake.start")
        active = await registry.call("guide.start")
        assert "community" not in {module["id"] for module in active["modules"]}
        knowledge = next(module for module in active["modules"] if module["id"] == "knowledge")
        assert [command["name"] for command in knowledge["commands"]] == ["knowledge.explain", "knowledge.get", "knowledge.preview"]
        assert "intake" in {module["id"] for module in active["modules"]}

    asyncio.run(scenario())


def test_guide_selects_only_the_relevant_model_when_variants_exist(app, published_foundation):
    async def scenario():
        registry = Registry(app)
        cloned = await registry.call("model.clone", {"source": published_foundation, "destination_model": "variant"})
        variant = cloned["model"]
        state = await registry.call("guide.start")
        assert state["status"] == "needs_model_selection"
        assert state["next"] is None
        assert len(state["models"]) == 2
        await registry.call("layer.select", {"model": published_foundation, "layer": None})
        state = await registry.call("guide.start")
        assert state["model"] == published_foundation
        assert state["next"]["arguments"]["model"] == published_foundation
        explicit = await registry.call("guide.start", {"model": variant})
        assert explicit["model"] == variant
        assert explicit["next"]["arguments"]["model"] == variant
        await registry.call("layer.select", {"model": variant, "layer": None})
        state = await registry.call("guide.start")
        assert state["status"] == "needs_model_selection"
        assert state["next"] is None

    asyncio.run(scenario())


def test_guide_resumes_nonexclusive_practices_and_reports_aborted_work(app, published_foundation):
    from metaform.layers import _start
    from metaform.workflow import Engine

    job = _start(app, "Write 3 best practices", None, published_foundation, "knowledge-tool", exclusive=False, name="Best Practices")
    assert app.get("mode") is None
    registry = Registry(app)
    active = asyncio.run(registry.call("guide.start"))
    assert active["status"] == "in_progress"
    assert active["next"] == {"command": "workflow.next", "arguments": {"run_id": job["run_id"]}}
    Engine(app).abort(job["run_id"])
    app.enter("workflow", job["run_id"])
    stopped = asyncio.run(registry.call("guide.start"))
    assert stopped["status"] == "incomplete_best_practices"
    assert stopped["next"]["command"] == "layer.regenerate"
    assert app.load_run(job["run_id"])["status"] == "aborted"


@pytest.mark.parametrize("transport", ["installed", "portable"])
def test_mcp_concierge_prompt_tracks_selected_project(tmp_path, transport):
    from metaform.util import write_json

    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "legacy", "auto_build": False})
    project = tmp_path / "first"
    second = tmp_path / "second"
    project.mkdir()
    second.mkdir()

    async def scenario():
        params = StdioServerParameters(
            command=sys.executable,
            args=["-m", "metaform.mcp_server"] if transport == "installed" else [
                "-c", "import asyncio; from metaform.app import App; from metaform.portable_mcp import serve; asyncio.run(serve(App()))"
            ],
            env={"METAFORM_HOME": str(home), "METAFORM_PROJECT": str(project), "PYTHONPATH": os.environ.get("PYTHONPATH", ""), "METAFORM_RUNTIME_DIR": os.environ["METAFORM_RUNTIME_DIR"]},
        )
        async with Client(params) as client:
            startup = json.loads(client.instructions.rsplit("\n\n", 1)[1])
            assert startup["project"]["path"] == str(project)
            assert startup["status"] == "needs_project_input"
            listing = await client.list_prompts()
            assert "metaform" in {prompt.name for prompt in listing.prompts}
            prompt = await client.get_prompt("metaform")
            state = json.loads(prompt.messages[-1].content.text)
            assert state["project"]["path"] == str(project)
            knowledge = next(module for module in state["modules"] if module["id"] == "knowledge")
            assert knowledge["name"] == "Knowledge Tool"
            assert [command["name"] for command in knowledge["commands"]] == ["knowledge.explain", "knowledge.get", "knowledge.preview", "knowledge.start"]
            skill = await client.call_tool("guide.skill", {})
            assert not skill.is_error
            assert prompt.messages[0].content.text == skill.structured_content["text"]
            selected = await client.call_tool("project.select", {"project": str(second)})
            assert not selected.is_error
            selected_state = json.loads(selected.structured_content["instructions"].rsplit("\n\n", 1)[1])
            assert selected_state["project"]["path"] == str(second)
            assert selected_state["status"] == "needs_project_input"
            prompt = await client.get_prompt("metaform")
            state = json.loads(prompt.messages[-1].content.text)
            assert state["project"]["path"] == str(second)
            assert state["run"] is None
            assert state["status"] == "needs_project_input"
            assert state["next"] is None

    asyncio.run(scenario())
