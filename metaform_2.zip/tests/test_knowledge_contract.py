import pytest

from metaform.backends import open_graph


def element(name):
    return {"entity_desc": name, "entity_schema": "metaform:element", "entity_json_obj": {"en": name}}


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_raw_import_preserves_source_observations_and_join_identity(tmp_path, backend):
    original = open_graph(tmp_path / "original.json", "json")
    for scope in ("native", "archaeology"):
        original.put({"elements": {"X": element(scope)}, "joins": [
            {"id": "same", "object_id": "X", "element_id": "Y", "type": "dependency", "purpose": scope}
        ]}, scope)
    copied = open_graph(tmp_path / ("copy." + backend), backend)
    copied.import_raw(original.export())
    assert copied.export() == original.export()
    for scope in ("native", "archaeology"):
        assert copied.get("X", scope=scope) == original.get("X", scope=scope)


def test_reference_owner_and_source_are_independent():
    from metaform.knowledge import KnowledgeSnapshot, RecordKey
    partitions = {owner: {"elements": {"X": element(owner)}, "joins": [], "observations": []}
                  for owner in ("project:A", "project:B", "global")}
    partitions["global"]["elements"]["Y"] = element("Y")
    snap = KnowledgeSnapshot(1, partitions, {})
    assert snap.resolve({"ref": "X"}, "project:A") == [RecordKey("project:A", "element", "X")]
    assert snap.resolve({"ref": "X"}, "global") == [RecordKey("global", "element", "X")]
    assert snap.resolve({"ref": "Y"}, "project:A") == [RecordKey("global", "element", "Y")]
    assert snap.resolve({"ref": "X", "owner": "project:B"}, "project:A") == [RecordKey("project:B", "element", "X")]
    assert snap.resolve({"ref": "missing"}, "project:A") == [RecordKey("project:A", "element", "missing"), RecordKey("global", "element", "missing")]


def test_incidence_keeps_endpoints_and_qualified_join_identity():
    from metaform.knowledge import KnowledgeSnapshot, RecordKey
    join = {"id": "j", "type": "dependency", "object_id": "X", "element_id": "Y", "participants": [{"role": "rule", "ref": "rule"}]}
    partitions = {owner: {"elements": {"X": element(owner)}, "joins": [join], "observations": []}
                  for owner in ("project:A", "global")}
    partitions["project:A"]["joins"] = [join, {"id": "higher", "type": "relation", "participants": [{"ref": "j", "owner": "global"}]}]
    snap = KnowledgeSnapshot(1, partitions, {})
    owners = {"project:A", "global"}
    assert set(snap.incident_element("X", owners)) == {RecordKey(o, "join", "j") for o in owners}
    assert RecordKey("project:A", "join", "higher") in snap.incident_join(RecordKey("global", "join", "j"), owners)
    assert RecordKey("project:A", "join", "higher") not in snap.incident_join(RecordKey("project:A", "join", "j"), owners)


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_foreign_participant_incidence_survives_local_rename(tmp_path, backend):
    graph = open_graph(tmp_path / ("rename." + backend), backend)
    graph.owner = "project:A"
    graph.put({"elements": {"X": element("X")}, "joins": [{"id": "foreign", "type": "relation", "participants": [{"ref": "X", "owner": "global"}]}]}, "authored")
    graph.rename_elements({"X": "Z"})
    assert len(graph.joins("X")) == 1
    assert graph.joins("Z") == []
