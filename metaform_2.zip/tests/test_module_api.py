import asyncio
import shutil
from pathlib import Path

from metaform.app import App
from metaform import portable, schemas
from metaform.registry import Registry
from metaform.util import write_json
from metaform.workflow import import_workflow


def install_module(app):
    folder = app.root / "modules" / "reviewer"
    write_json(folder / "module.json", {
        "id": "reviewer", "name": "Artifact reviewer", "description": "Dispatch an artifact review.",
        "commands": [{"name": "start", "handler": "handler.py:start"},
                     {"name": "visits", "handler": "handler.py:visits"}],
    })
    write_json(folder / "review.json", {"id": "shared-review", "steps": [
        {"id": "review", "prompt": "Review {{ subject }}.", "context": "fresh"}]})
    (folder / "handler.py").write_text('''
from pathlib import Path
from metaform.module_api import ModuleAPI
async def start(api, args, context):
    assert isinstance(api, ModuleAPI)
    assert not hasattr(api, "db") and not hasattr(api, "graph")
    api.set("visits", api.get("visits", 0) + 1)
    await api.call("workflow.import", {"path": str(Path(__file__).with_name("review.json"))})
    return await api.call("workflow.start", {"id": "shared-review", "inputs": args, "exclusive": False})
def visits(api, args, context):
    return {"count": api.get("visits", 0), "project": api.project["path"]}
''')
    return folder


def test_external_module_uses_public_lifecycle_and_survives_portable_sharing(app, tmp_path):
    install_module(app)
    registry = Registry(app)
    first = asyncio.run(registry.call("reviewer.start", {"subject": "the source artifact"}))
    assert first["prompt"] == "Review the source artifact."
    assert first["nonce"] and Path(first["workfolder"]).is_dir()
    asyncio.run(registry.call("workflow.answer", {
        "run_id": first["run_id"], "request_id": first["request_id"], "answer": "Reviewed."}))
    assert asyncio.run(registry.call("workflow.next", {"run_id": first["run_id"]}))["status"] == "complete"
    archive = tmp_path / "shared.pyz"
    assert portable.export(app, archive)["unresolved"] == []
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform" / "home", binding=False)
    imported_registry = Registry(imported)
    visits = asyncio.run(imported_registry.call("reviewer.visits"))
    assert visits == {"count": 1, "project": str(target)}
    second = asyncio.run(imported_registry.call("reviewer.start", {"subject": "the portable artifact"}))
    assert second["prompt"] == "Review the portable artifact."
    assert asyncio.run(imported_registry.call("reviewer.visits"))["count"] == 2
    assert asyncio.run(registry.call("reviewer.visits"))["count"] == 1
    shutil.rmtree(target / ".metaform" / "modules" / "reviewer")
    assert "reviewer.start" not in imported_registry.discover()
    assert "reviewer.start" in registry.discover()


def test_existing_raw_example_uses_public_mode_lifecycle(app):
    source = Path(__file__).resolve().parents[1] / "examples" / "module"
    shutil.copytree(source, app.root / "modules" / "example")
    registry = Registry(app)
    assert asyncio.run(registry.call("example.enter"))["module"] == "example"
    assert app.get("mode")["module"] == "example"
    assert asyncio.run(registry.raw(["hello", "world"]))["tokens"] == ["hello", "world"]
    asyncio.run(registry.call("abort"))
    assert app.get("mode") is None


def test_chassis_account_is_functional_discoverable_and_outside_project_knowledge(app):
    registry = Registry(app)
    before = app.graph.export()
    result = asyncio.run(registry.call("guide.chassis"))
    foundation = result["foundation"]
    annotations = schemas.annotations(app, "urn:metaform:schema:foundation:2", foundation)
    assert annotations == [], "a placed position may carry an empty EF"
    assert {item["target"]["id"] for item in foundation["diagnostics"]} == {"document", "exterior"}
    assert foundation["artifact"]["id"] == "chassis:operations"
    assert any(join["receiver"]["id"] == "chassis:customizer" for join in foundation["joins"])
    assert {"build-module", "import-workflow", "use-interface"} <= set(result["procedures"])
    assert app.graph.export() == before
    install_module(app)
    refreshed = asyncio.run(registry.call("guide.chassis"))
    assert refreshed["foundation"] == foundation
    assert any(module["id"] == "reviewer" for module in refreshed["capabilities"]["modules"])


def test_external_guide_provider_and_semantic_operations_use_public_interface(app):
    folder = app.root / "modules" / "notes"
    write_json(folder / "module.json", {
        "id": "notes", "guide_handler": "handler.py:guide", "guide_priority": 0,
        "commands": [{"name": "record", "handler": "handler.py:record"}],
    })
    (folder / "handler.py").write_text('''
def guide(api, state, plan=None):
    return {"guidance": "Record a note through " + api.module,
            "next": {"command": "notes.record", "arguments": {"text": "An observed fact."}}}
async def record(api, args, context):
    value = {"entity_desc": args["text"], "entity_schema": "metaform:element",
             "entity_json_obj": {"en": "Recorded note"}}
    await api.call("graph.put", {"graph": {"elements": {"note:public": value}}})
    return await api.call("graph.get", {"id": "note:public"})
''')
    registry = Registry(app)
    guided = asyncio.run(registry.call("guide.start"))
    assert guided["guidance"] == "Record a note through notes"
    action = guided["next"]
    result = asyncio.run(registry.call(action["command"], action["arguments"]))
    assert result["record"]["entity_desc"] == "An observed fact."


def test_shared_flat_module_keeps_its_raw_and_guidance_handlers_when_exported(app, tmp_path):
    folder = app.home / "modules"
    write_json(folder / "flat.json", {
        "id": "flat", "raw_handler": "raw.py:raw", "guide_handler": "guidance.py:guide",
        "guide_priority": 0, "disable_argparse": True,
        "commands": [{"name": "enter", "handler": "enter.py:enter"}],
    })
    (folder / "enter.py").write_text("def enter(api, args, context): api.enter(); return 'entered'\n")
    (folder / "raw.py").write_text("def raw(api, tokens, context): return {'tokens': tokens}\n")
    (folder / "guidance.py").write_text(
        "def guide(api, state, plan=None): return {'guidance': 'Use the flat module.', 'next': {'command': 'flat.enter', 'arguments': {}}}\n")
    import_workflow(app, {"id": "uses-flat", "steps": [{"id": "use", "kind": "tool", "tool": "flat.enter"}]})
    archive = tmp_path / "flat.pyz"
    portable.export(app, archive)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    registry = Registry(App(target, target / ".metaform" / "home", binding=False))
    assert asyncio.run(registry.call("guide.start"))["guidance"] == "Use the flat module."
    assert asyncio.run(registry.call("flat.enter")) == "entered"
    assert asyncio.run(registry.raw(["retained"])) == {"tokens": ["retained"]}
