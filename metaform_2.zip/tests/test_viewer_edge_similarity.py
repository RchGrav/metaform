import pytest

from metaform.backends import JSONGraph
from metaform.viewer import create_app


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_edge_membership_uses_current_structural_matches(app, backend):
    if backend == "json":
        app.graph = JSONGraph(app.root / "edge-colors.json")
    for scope in ("native", "archaeology"):
        app.graph.put({
            "elements": {name: {
                "entity_desc": scope + " description",
                "entity_schema": "metaform:element",
                "entity_json_obj": {"en": name},
            } for name in ("code.a", "code.b")},
            "joins": [{
                "id": scope + "-" + kind,
                "object_id": "code.a", "element_id": "code.b",
                "type": kind, "purpose": scope + " purpose",
            } for kind in ("shared", scope + "-only")],
        }, scope)
    app.graph.merge_perspectives()
    client = create_app(app).test_client()
    before = app.graph.export()

    def memberships(perspective="inference"):
        response = client.get("/api/network", query_string={
            "perspective": perspective, "q": "code.a",
        })
        assert response.status_code == 200
        joins = {j["id"]: j for j in response.json["joins"]}
        return {(joins[e["join_id"]].get("join_scope"), e["type"]): e["membership"]
                for e in response.json["edges"]
                if joins[e["join_id"]].get("join_scope") in {"native", "archaeology"}}

    assert memberships() == {
        ("native", "shared"): "11", ("archaeology", "shared"): "11",
        ("native", "native-only"): "01", ("archaeology", "archaeology-only"): "10",
    }
    assert memberships("contextual") == {
        ("native", "shared"): "11", ("native", "native-only"): "01",
    }
    assert app.graph.export() == before

    changed = next(j for j in app.graph.joins(scope="archaeology") if j["type"] == "shared")
    changed["type"] = "different-shape"
    app.graph.put({"joins": [changed]}, "archaeology")
    before_refresh = app.graph.export()
    assert memberships() == {
        ("native", "shared"): "01", ("native", "native-only"): "01",
        ("archaeology", "different-shape"): "10", ("archaeology", "archaeology-only"): "10",
    }
    assert app.graph.export() == before_refresh
