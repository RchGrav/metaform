// The explorer shows what the agent sees: every panel is one read and flips to its envelope.
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');
const assert=require('node:assert/strict');
const {python,outputDirectory}=require('./browser_support.cjs');
(async()=>{
  const out=outputDirectory('explorer');
  const server=spawn(python,['tests/archived_structure_viewer_fixture.py','--foundation'],{stdio:['ignore','pipe','pipe'],env:{...process.env,PYTHONPATH:'tests'}});
  let stderr='',browser;server.stderr.on('data',chunk=>stderr+=chunk);
  try{
    const url=await new Promise((resolve,reject)=>{server.stdout.once('data',chunk=>resolve(String(chunk).trim()));server.once('exit',code=>reject(Error('Fixture failed '+code+' '+stderr)));});
    browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1600,height:1000}});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));page.on('response',response=>{if(response.status()>=400)errors.push(response.status()+' '+response.url());});
    await page.goto(url+'/?model=mgm');await page.waitForFunction(()=>document.querySelectorAll('#cards .card').length>0);
    const titles=await page.evaluate(()=>[...document.querySelectorAll('#cards .card .title')].map(node=>node.textContent));
    assert(titles.includes('Gateway Coordinator'),'Cards are named by the namespace, read backward');
    assert(titles.every(title=>!/^(actual )?element$/i.test(title)),'No kind labels on cards');
    assert.equal(await page.locator('#edges text').count(),0,'No text on arrows');
    assert.equal(await page.locator('input.panel-resize').count(),0,'No panel width sliders');
    assert(/needs|ready|awaiting|select/i.test(await page.locator('#stage .stage-status').innerText()),'The stage banner comes from guide.start');
    await page.screenshot({path:out+'/explorer-open.png'});
    // A click inspects without moving the graph.
    const before=await page.evaluate(()=>[...document.querySelectorAll('#cards .card')].map(card=>card.dataset.id+'@'+card.style.left+','+card.style.top));
    await page.locator('#cards .card:not(.focus)').first().click();await page.waitForFunction(()=>document.querySelector('#inspector h1'));
    const after=await page.evaluate(()=>[...document.querySelectorAll('#cards .card')].map(card=>card.dataset.id+'@'+card.style.left+','+card.style.top));
    assert.deepEqual(after,before,'Selecting a card keeps every card where it was');
    const inspected=await page.locator('#inspector h1').innerText();assert(titles.includes(inspected),'The inspector shows the selected card');
    // The envelope flip shows the exact call and its result.
    await page.locator('#inspector .envelope-toggle').click();
    const call=await page.locator('#inspector .envelope .call').innerText();assert(call.startsWith('element.inspect {"target"'),call);
    const envelope=JSON.parse(await page.locator('#inspector .envelope pre').innerText());assert(envelope.records.length>0&&envelope.resolved_target,'The envelope is the read result itself');
    await page.screenshot({path:out+'/explorer-envelope.png'});await page.keyboard.press('Escape');
    assert.equal(await page.locator('#inspector .envelope').count(),0);
    // An arrow opens its join; a double-click centers on the card and keeps it in place.
    await page.locator('#edges path.hit').first().dispatchEvent('pointerup',{bubbles:true});await page.waitForFunction(()=>/dependency|property|supportive/i.test(document.querySelector('#inspector h1')?.textContent||''));
    const target=page.locator('#cards .card:not(.focus)').first();const id=await target.getAttribute('data-id');const position=await target.evaluate(card=>card.style.left+','+card.style.top);
    await target.dblclick();await page.waitForFunction(id=>document.querySelector('#cards .card.focus')?.dataset.id===id,id);
    assert.equal(await page.locator('#cards .card.focus').evaluate(card=>card.style.left+','+card.style.top),position,'The card that was double-clicked stays where it was');
    // The namespace tree expands from namespace.browse and lists members from type.members.
    await page.locator('#tree .twist').first().click();await page.waitForFunction(()=>document.querySelectorAll('#tree .name').length>4);
    await page.locator('#tree ul ul .name').first().click();await page.waitForFunction(()=>document.querySelector('#graph-title').textContent.startsWith('Members of'));
    assert.equal(await page.locator('#graph').getAttribute('data-command'),'type.members');
    // Property joins color the receiving card, not an arrow.
    await page.goto(url+'/?model=zz-interactions&focus=element:demo:engine');await page.waitForFunction(()=>document.querySelector('#cards .card.focus'));
    assert(await page.locator('#cards .card.focus .stripes i').count()>0,'The receiving card carries the property color');
    assert.equal(await page.locator('#edges path.property').count(),0,'No arrow is drawn for a Type-provided property');
    await page.locator('#cards .card.focus').click();await page.waitForFunction(()=>[...document.querySelectorAll('#inspector h3')].some(node=>node.textContent==='Knowledge'));
    await page.screenshot({path:out+'/explorer-property.png'});
    // The console runs any tool and shows the initialization the agent receives.
    await page.locator('#show-console').click();await page.waitForFunction(()=>document.querySelectorAll('#tool option').length>10);
    await page.locator('#run-tool').click();await page.waitForFunction(()=>document.getElementById('tool-result').textContent.startsWith('{'));
    await page.locator('.console-tabs button[data-tab=init]').click();assert((await page.locator('#instructions').innerText()).includes('Metaform'));
    await page.locator('.console-tabs button[data-tab=calls]').click();await page.waitForFunction(()=>document.querySelectorAll('#call-table tbody tr').length>0);
    await page.screenshot({path:out+'/explorer-console.png'});
    assert.deepEqual(errors,[]);
    console.log('Verified namespace names on cards, a still graph on selection, envelope flips, arrow and tree reads, property coloring on the receiver, and the console.');
  }finally{if(browser)await browser.close();server.kill('SIGTERM');}
})().catch(error=>{console.error(error);process.exit(1);});
