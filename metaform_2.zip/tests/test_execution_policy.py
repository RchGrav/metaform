"""Source-authored failure and phase deadlines exercised with real workers."""
import asyncio
import json
import os
import sys
import time
from pathlib import Path

import pytest

from metaform.modules.workflow import drive
from metaform.workflow import Engine, import_workflow


POLICY = {"agent_failure": "retry_once_then_fail", "phase_failure": "stop_execution"}


@pytest.fixture
def worker(app, tmp_path):
    script = tmp_path / "worker.py"
    script.write_text('''import json,os,subprocess,sys,time
from pathlib import Path
job=json.load(sys.stdin)
values=job['inputs']; log=Path(values['log']); case=values['case']
with log.open('a') as stream: stream.write(json.dumps({'case':case,'pid':os.getpid()})+'\\n')
count=sum(json.loads(line)['case']==case for line in log.read_text().splitlines())
if case in ('crash_once','crash_always'):
    if values.get('wait_for'):
        while not Path(values['wait_for']).exists():time.sleep(.005)
    if case=='crash_always' or count==1:
        Path(sys.argv[1]).write_text('"stale failed-attempt response"')
        sys.stderr.write('deliberate worker crash')
        sys.exit(9)
if values.get('started'):Path(values['started']).touch()
if values.get('child_pid'):
    code='import os,signal,time;from pathlib import Path;'
    if values.get('child_ignore_term'):code+='signal.signal(signal.SIGTERM,signal.SIG_IGN);'
    code+='Path('+repr(values['child_pid'])+').write_text(str(os.getpid()));time.sleep(30)'
    child=subprocess.Popen([sys.executable,'-c',code])
    while not Path(values['child_pid']).exists():time.sleep(.005)
    if values.get('exit_after_child'):sys.exit(9)
time.sleep(values.get('sleep',0))
if values.get('finished'):Path(values['finished']).touch()
print(json.dumps({'case':case,'validation_passed':False}))
''')
    app.config["harnesses"] = {"fixture": {"command": [sys.executable, str(script), "{response_file}"]}}
    return tmp_path / "attempts.jsonl"


def task(identifier, log, case="success", **values):
    return {"id": identifier, "prompt": "Perform the assigned operation.", "inputs": {
        key: {"literal": value} for key, value in {"log": str(log), "case": case, **values}.items()}}


def run(app, identifier):
    return asyncio.run(drive(app, {"run_id": identifier, "harness": "fixture"}, None))


def test_authored_retry_uses_two_processes_and_preserves_negative_validation_answer(app, worker):
    step = task("work", worker, "crash_once") | {"execution_policy": POLICY}
    import_workflow(app, {"id": "retry", "steps": [step]})
    job = Engine(app).start("retry")
    result = run(app, job["run_id"])
    assert result["status"] == "complete"
    assert result["result"]["steps"]["work"] == {"case": "crash_once", "validation_passed": False}
    assert len(worker.read_text().splitlines()) == 2
    assert len(app.load_run(job["run_id"])["worker_failures"][job["request_id"]]) == 1


def test_unconfigured_failure_keeps_original_exception_and_resumable_assignment(app, worker):
    import_workflow(app, {"id": "ordinary", "steps": [task("work", worker, "crash_always")]})
    job = Engine(app).start("ordinary")
    with pytest.raises(ValueError, match="Harness exited 9"):
        run(app, job["run_id"])
    assert len(worker.read_text().splitlines()) == 1
    assert Engine(app).next(job["run_id"])["request_id"] == job["request_id"]


def test_manual_resume_uses_new_worker_output_after_failed_attempt_wrote_response_file(app, worker):
    import_workflow(app, {"id": "manual-retry", "steps": [task("work", worker, "crash_once")]})
    job = Engine(app).start("manual-retry")
    with pytest.raises(ValueError, match="Harness exited 9"):
        run(app, job["run_id"])
    result = run(app, job["run_id"])
    assert result["result"]["steps"]["work"] == {"case": "crash_once", "validation_passed": False}
    assert len(worker.read_text().splitlines()) == 2
    retired = app.root / "outputs" / "requests" / job["request_id"]
    assert any(path.read_text() == '"stale failed-attempt response"' for path in retired.glob("response.previous-*.json"))


def test_exhausted_worker_stops_its_parallel_phase_and_owned_process_tree(app, worker, tmp_path):
    started, child_pid = tmp_path / "started", tmp_path / "child-pid"
    import_workflow(app, {"id": "parallel-failure", "steps": [{"id": "phase", "kind": "parallel",
        "execution_policy": POLICY | {"timeout_seconds": 10}, "branches": [
            {"id": "sleeping", "steps": [task("sleep", worker, "sleep", started=str(started), child_pid=str(child_pid), sleep=30)]},
            {"id": "crashing", "steps": [task("crash", worker, "crash_always", wait_for=str(child_pid))]},
        ]}, task("later_phase", worker)]})
    engine = Engine(app)
    phase = engine.start("parallel-failure")

    async def scenario():
        return await asyncio.wait_for(asyncio.gather(*(
            drive(app, {"run_id": child["run_id"], "harness": "fixture"}, None)
            for child in phase["parallel"])), timeout=6)

    results = asyncio.run(scenario())
    assert {value["status"] for value in results} <= {"failed", "aborted"}
    assert engine.next(phase["run_id"])["status"] == "failed"
    assert app.get("mode") is None
    cases = [json.loads(line)["case"] for line in worker.read_text().splitlines()]
    assert cases.count("crash_always") == 2 and cases.count("sleep") == 1
    assert "success" not in cases
    pid = int(child_pid.read_text())
    proc = Path("/proc") / str(pid) / "stat"
    assert not proc.exists() or proc.read_text().split()[2] == "Z"
    for child in phase["parallel"]:
        request_id = child["request_id"]
        assert not app.get("executing:" + request_id)
        assert not (app.home / "assignments" / (child["nonce"] + ".json")).exists()


def test_sequential_children_share_one_deadline_and_do_not_start_later_phase(app, worker, tmp_path):
    first, second = tmp_path / "first-finished", tmp_path / "second-finished"
    import_workflow(app, {"id": "deadline", "steps": [{"id": "phase", "kind": "call", "workflow": "sequential",
        "execution_policy": POLICY | {"timeout_seconds": 0.8}}, task("later", worker)],
        "workflows": [{"id": "sequential", "steps": [
            task("first", worker, "first", sleep=.2, finished=str(first)),
            task("second", worker, "second", sleep=30, finished=str(second)),
        ]}]})
    job = Engine(app).start("deadline")
    result = run(app, job["run_id"])
    assert result["status"] == "failed"
    assert first.exists() and not second.exists()
    assert [json.loads(line)["case"] for line in worker.read_text().splitlines()] == ["first", "second"]


@pytest.mark.skipif(os.name == "nt", reason="POSIX process-group ownership")
def test_exited_worker_cannot_leave_descendant_pipe_blocking_failure_or_retry(app, worker, tmp_path):
    child_pid = tmp_path / "descendant"
    import_workflow(app, {"id": "descendant-failure", "steps": [task("work", worker,
        child_pid=str(child_pid), child_ignore_term=True, exit_after_child=True) | {"execution_policy": POLICY}]})
    job = Engine(app).start("descendant-failure")

    async def scenario():
        import signal
        driving = asyncio.create_task(drive(app, {"run_id": job["run_id"], "harness": "fixture"}, None))
        done, pending = await asyncio.wait({driving}, timeout=9)
        if pending:
            for line in worker.read_text().splitlines():
                try:
                    os.killpg(json.loads(line)["pid"], signal.SIGKILL)
                except ProcessLookupError:
                    pass
            driving.cancel()
            await asyncio.gather(driving, return_exceptions=True)
        assert not pending, "Exited worker descendants blocked phase failure and retry"
        return driving.result()

    assert asyncio.run(scenario())["status"] == "failed"
    assert len(worker.read_text().splitlines()) == 2
    state = Path("/proc") / child_pid.read_text() / "stat"
    assert not state.exists() or state.read_text().split()[2] == "Z"


def test_expired_user_wait_is_failed_on_resume_and_cannot_accept_late_answer(app):
    import_workflow(app, {"id": "user-deadline", "steps": [{"id": "question", "kind": "user", "prompt": "Reply.",
        "execution_policy": POLICY | {"timeout_seconds": .05}}]})
    engine = Engine(app)
    job = engine.start("user-deadline")
    time.sleep(.08)
    assert engine.next(job["run_id"])["status"] == "failed"
    with pytest.raises(ValueError, match="failed"):
        engine.submit(job["run_id"], job["request_id"], "late")


def test_begin_observes_expired_phase_and_retires_its_nonce(app, tmp_path):
    from metaform.continuation import begin, marker

    import_workflow(app, {"id": "begin-deadline", "steps": [{"id": "work", "prompt": "Work.",
        "execution_policy": POLICY | {"timeout_seconds": .05}}]})
    job = Engine(app).start("begin-deadline")
    time.sleep(.08)
    with pytest.raises(ValueError, match="deadline has expired"):
        begin(job["nonce"], tmp_path / "worker", app.home)
    assert app.load_run(job["run_id"])["status"] == "failed"
    assert not (app.home / "assignments" / (job["nonce"] + ".json")).exists()
    assert marker(tmp_path / "worker") is None


def test_actor_repeated_begin_observes_server_bound_phase_deadline(app):
    import urllib.error
    import urllib.request
    from metaform.actor import gateway

    import_workflow(app, {"id": "actor-deadline", "steps": [{"id": "work", "prompt": "Work.",
        "execution_policy": POLICY | {"timeout_seconds": .15}}]})
    job = Engine(app).start("actor-deadline")
    with gateway(app, job) as env:
        def begin_request():
            return urllib.request.urlopen(urllib.request.Request(env["METAFORM_GATEWAY"],
                data=json.dumps({"command": "begin", "arguments": {"nonce": job["nonce"]}}).encode(),
                headers={"Authorization": "Bearer " + env["METAFORM_GATEWAY_TOKEN"]}), timeout=3)
        with begin_request() as response:
            assert json.load(response)["request_id"] == job["request_id"]
        time.sleep(.18)
        with pytest.raises(urllib.error.HTTPError) as raised:
            begin_request()
        assert "deadline has expired" in raised.value.read().decode()
    assert app.load_run(job["run_id"])["status"] == "failed"


def test_failed_phase_preserves_unrelated_run_and_has_no_pending_exported_handoff(app, worker, tmp_path):
    from metaform.continuation import begin, marker
    from metaform.modules.package import export, import_bundle
    from metaform.viewer import create_app

    import_workflow(app, {"id": "failed", "steps": [task("work", worker, "crash_always") |
        {"context": "fresh", "execution_policy": POLICY}]})
    import_workflow(app, {"id": "unrelated", "steps": [task("other", worker)]})
    engine = Engine(app)
    failed = engine.start("failed", exclusive=False)
    unrelated = engine.start("unrelated")
    begin(failed["nonce"], home=app.home)
    result = run(app, failed["run_id"])
    assert result["status"] == "failed"
    assert app.get("mode")["run_id"] == unrelated["run_id"]
    assert engine.next(unrelated["run_id"])["request_id"] == unrelated["request_id"]
    assert not Path(failed["workfolder"]).exists()
    assert marker(app.project) is None
    pending = create_app(app).test_client().get('/api/pending').get_json()
    assert failed["run_id"] not in json.dumps(pending)
    assert unrelated["run_id"] in json.dumps(pending)
    bundle = export(app, {"path": str(tmp_path / "failed-history")}, None)
    restored = import_bundle(app, {"path": bundle["path"], "destination": str(tmp_path / "restored")}, None)
    assert failed["run_id"] not in {job["run_id"] for job in restored["handoffs"]}
    assert unrelated["run_id"] in {job["run_id"] for job in restored["handoffs"]}


@pytest.mark.parametrize("failure", ["crash", "timeout"])
def test_mcp_sampling_failure_obeys_authored_retry_and_phase_deadline(app, failure):
    policy = POLICY | ({"timeout_seconds": .1} if failure == "timeout" else {})
    import_workflow(app, {"id": "sample-failure", "steps": [{"id": "work", "prompt": "Work.", "execution_policy": policy}]})
    job = Engine(app).start("sample-failure")

    class Context:
        calls = 0
        unwound = 0

        async def sample(self, assignment, answer_command):
            self.calls += 1
            try:
                if failure == "timeout":
                    await asyncio.sleep(30)
                raise RuntimeError("worker transport failed")
            finally:
                self.unwound += 1

    context = Context()
    result = asyncio.run(drive(app, {"run_id": job["run_id"]}, context))
    assert result["status"] == "failed"
    assert context.calls == context.unwound == (1 if failure == "timeout" else 2)


def test_resume_after_recorded_second_crash_never_launches_a_third_worker(app, worker, monkeypatch):
    import_workflow(app, {"id": "restart", "steps": [task("work", worker, "crash_always") | {"execution_policy": POLICY}]})
    job = Engine(app).start("restart")

    class Interrupted(BaseException):
        pass

    with monkeypatch.context() as patch:
        def interrupted(*args, **kwargs):
            raise Interrupted
        patch.setattr(Engine, "fail", interrupted)
        with pytest.raises(Interrupted):
            run(app, job["run_id"])
    assert len(worker.read_text().splitlines()) == 2
    assert run(app, job["run_id"])["status"] == "failed"
    assert len(worker.read_text().splitlines()) == 2


def test_failed_phase_cancels_waiting_mcp_sampling_sibling_without_timeout_policy(app):
    import_workflow(app, {"id": "sampling-siblings", "steps": [{"id": "phase", "kind": "parallel", "execution_policy": POLICY,
        "branches": [{"id": name, "steps": [{"id": name, "prompt": "Work."}]} for name in ("waiting", "crashing")]}]})
    phase = Engine(app).start("sampling-siblings")

    async def scenario():
        started = asyncio.Event()
        unwound = asyncio.Event()

        class Context:
            async def sample(self, assignment, answer_command):
                if assignment["step"] == "crashing":
                    await started.wait()
                    raise RuntimeError("transport crashed")
                started.set()
                try:
                    await asyncio.sleep(30)
                finally:
                    unwound.set()

        results = await asyncio.wait_for(asyncio.gather(*(
            drive(app, {"run_id": child["run_id"]}, Context()) for child in phase["parallel"])), timeout=2)
        assert {result["status"] for result in results} <= {"failed", "aborted"}
        assert unwound.is_set()

    asyncio.run(scenario())
