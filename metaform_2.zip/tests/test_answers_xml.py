"""A model's answer is an XML document, and reading one never rejects it (SPEC section 14: no gating on
inference). The reader turns the document into the dict the expansion consumes, records every mismatch for
observation instead of raising, and salvages what closed when the document is cut short, which is the reason
the format is XML rather than JSON. The specimen is a real intake of YuE, `tests/data/yue-intake.xml`."""
from pathlib import Path

import pytest

from metaform import answers

DOCUMENT = (Path(__file__).parent / "data" / "yue-intake.xml").read_text(encoding="utf-8")


def test_the_whole_document_reads_into_the_shape_the_expansion_consumes():
    read = answers.read(DOCUMENT)
    assert read["complete"] is True and read["mismatches"] == []

    assert read["artifact"]["type"] == "code" and read["artifact"]["name"] == "YuE"
    assert read["artifact"]["description"].startswith("An open-weight lyrics-to-song generation system")

    elements = {element["id"]: element for element in read["elements"]}
    assert len(elements) == 12
    assert [element["id"] for element in read["elements"] if element["role"] == "DE"] == ["de_song"]
    assert elements["gen_ar"]["namespace"] == "code.generation.token.autoregressive"
    assert elements["gen_ar"]["name_length"] == 3, "the lookback segment count is a number, not its text"
    assert elements["w_model"]["role"] == "PE"
    assert elements["de_song"]["ef"].startswith("Accepts a symbolic description")

    joins = {join["id"]: join for join in read["joins"]}
    assert len(joins) == 11
    first = joins["j_de_gen"]
    assert first["re"] == "de_song" and first["provider"] == "gen_ar", "ef_ref names the providing element"
    assert first["relation"] == "generates"
    assert first["observation"].startswith("A staged autoregressive model")
    assert first["op"].startswith("YuE produces a song"), "the artifact's own facts stay in the Operative Purpose"
    assert first["refs"]["stage2"] == "m-a-p/YuE-s2-1B-general"
    assert [entity["entity"] for entity in first["combined"]] == [
        "coarse stage generator", "residual stage generator", "sampling constraint processor"]
    assert first["combined"][0]["relation"] == "emits"
    assert joins["j_gen_ft"]["combined"] == [], "a join that combined nothing away carries an empty list"
    assert joins["j_de_seg"]["refs"]["control"] == "run_n_segments"

    assert len(read["subtypes"]) == 21
    assert "code.codec.audio.neural.upsampler" in read["subtypes"]


def test_the_receiving_entity_must_be_an_element_here_and_the_join_is_still_kept():
    broken = DOCUMENT.replace('re="de_song" ef_ref="cont_segment"', 're="no_such_element" ef_ref="cont_segment"')
    read = answers.read(broken)
    assert len(read["joins"]) == 11, "nothing is dropped for being unresolved"
    assert [m for m in read["mismatches"]
            if m["code"] == "unresolved_reference" and m["value"] == "no_such_element" and m["at"] == "j_de_seg"]


def test_a_join_may_reach_a_shared_encounter_function_type_that_is_not_an_element_here():
    """ef_ref names the element or the shared EF type this join connects, so a name outside the answer is not a
    mismatch; only the receiving entity has to be an element of this shape (response schema)."""
    reaching = DOCUMENT.replace('re="rt_infer" ef_ref="w_model"', 're="rt_infer" ef_ref="data.weight.model"')
    read = answers.read(reaching)
    assert next(j for j in read["joins"] if j["id"] == "j_rt_w")["provider"] == "data.weight.model"
    assert read["mismatches"] == []


def test_the_shape_names_exactly_one_defining_element_and_a_second_one_is_recorded():
    two = DOCUMENT.replace('id="gen_ar" role="SE"', 'id="gen_ar" role="DE"')
    read = answers.read(two)
    recorded = [m for m in read["mismatches"] if m["code"] == "unresolved_defining_element"]
    assert recorded and recorded[0]["roots"] == ["de_song", "gen_ar"]
    assert len(read["elements"]) == 12, "the answer is read whole; the count is only observed"


def test_an_element_with_no_encounter_function_is_recorded_not_refused():
    without = DOCUMENT.replace(
        "<ef>Supplies the learned parameter sets that the executing code loads, fetched from an external "
        "distribution point rather than carried in the artifact.</ef>", "")
    read = answers.read(without)
    assert len(read["elements"]) == 12
    assert next(e for e in read["elements"] if e["id"] == "w_model")["ef"] is None
    assert [m for m in read["mismatches"] if m["code"] == "missing_field" and m["at"] == "w_model"]


def test_a_document_cut_short_still_yields_everything_that_closed():
    """The reason for XML: a truncated answer loses the record it was writing, never the whole intake."""
    cut = DOCUMENT[:DOCUMENT.index('<join id="j_gen_layout"')] + '<join id="j_gen_layout" re="gen_ar" ef_r'
    with pytest.raises(Exception):
        __import__("xml.etree.ElementTree", fromlist=["ElementTree"]).fromstring(cut)

    read = answers.read(cut)
    assert read["complete"] is False
    assert [m["code"] for m in read["mismatches"] if m["code"] == "incomplete_document"]
    assert len(read["elements"]) == 12, "every element closed before the cut survives"
    assert [join["id"] for join in read["joins"]] == ["j_de_gen", "j_de_codec", "j_gen_tok"]
    assert read["joins"][0]["refs"]["stage1"] == "m-a-p/YuE-s1-7B-anneal-*"
    assert read["artifact"]["name"] == "YuE"


PROMPT = Path(__file__).parents[1] / "specifications" / "intake.xml"

# The words the reader gives the schema's own, stated in one place so a rename cannot hide.
RENAMED = {"join": {"ef_ref": "provider", "combined_entities": "combined"}, "entity": {"name": "entity"}}


def _declared(node, kind=""):
    """Every field the response schema declares on a record: its attributes and its child tags."""
    renames = RENAMED.get(kind, {})
    return {renames.get(field, field) for field in set(node.attrib) | {child.tag for child in node}}


def test_the_reader_covers_exactly_what_the_prompts_response_schema_declares():
    """The grammar lives in the prompt. If a field is added there and not here, or here and not there,
    this fails rather than letting the prompt and the reader drift apart."""
    import xml.etree.ElementTree as ET

    graph = ET.parse(PROMPT).getroot().find("response_schema/graph")
    read = answers.read(DOCUMENT)

    assert _declared(graph.find("elements/element"), "element") == set(read["elements"][0])
    assert _declared(graph.find("joins/join"), "join") == set(read["joins"][0])
    assert _declared(graph.find("joins/join/combined_entities/entity"), "entity") == set(read["joins"][0]["combined"][0])
    assert _declared(graph.find("artifact")) | {"description"} == set(read["artifact"])
    assert _declared(graph.find("joins/join/refs/ref")) == {"key"} and read["joins"][0]["refs"]
    assert _declared(graph.find("subtypes/subtype")) == {"namespace"} and isinstance(read["subtypes"][0], str)


def test_every_field_the_prompt_requires_of_a_join_is_recorded_when_it_is_missing():
    """The prompt instructs that every join expresses re, ef_ref, op, relation and observation."""
    stripped = DOCUMENT.replace(
        "      <relation>chains</relation>\n"
        "      <observation>Long-form output is assembled from successive context-bounded spans.</observation>\n", "")
    read = answers.read(stripped)
    missing = {m["field"] for m in read["mismatches"] if m["code"] == "missing_field" and m["at"] == "j_de_seg"}
    assert missing == {"relation", "observation"}
    assert len(read["joins"]) == 11, "the answer is read whole; the absence is only recorded"
