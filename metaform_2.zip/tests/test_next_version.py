import asyncio
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

import pytest
from metaform.app import App
from metaform.backends import JSONGraph
from metaform.graph import Graph
from metaform.continuation import marker, begin
from metaform.history import checkpoint, reconstruct, initialize
from metaform.portable import export, import_bundle
from metaform.prompts import put
from metaform.registry import Registry
from metaform.workflow import Engine, import_workflow


def record(name):
    return {
        "entity_desc": name,
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name},
    }


@pytest.mark.parametrize("backend", [JSONGraph, Graph])
def test_reified_join_traversal(tmp_path, backend):
    graph = backend(tmp_path / "graph")
    graph.put(
        {
            "elements": {
                "a": record("A"),
                "b": record("B"),
                "evidence": record("Evidence"),
            },
            "joins": [
                {"id": "j", "object_id": "a", "element_id": "b", "type": "dependency"},
                {
                    "id": "e",
                    "object_id": "j",
                    "element_id": "evidence",
                    "type": "evidence",
                },
            ],
        },
        "authored",
    )
    assembled = graph.assemble("a")
    assert set(assembled["elements"]) == {"a", "b", "evidence"}
    assert {j["id"] for j in assembled["joins"]} == {"j", "e"}
    assert graph.search("ev*")[0]["id"] == "evidence"
    graph.delete_joins(object_id="j", category="evidence")
    assert not graph.joins(category="evidence")


def test_prompt_revisions_parallel_handoffs_and_folder_binding(
    app, tmp_path, monkeypatch
):
    put(app, {"id": "prompt:test", "text": "Use {{ item }} exactly.", "name": "Test"})
    import_workflow(
        app, {"id": "child", "steps": [{"id": "act", "prompt_ref": "prompt:test"}]}
    )
    import_workflow(
        app,
        {
            "id": "parent",
            "steps": [
                {
                    "id": "fork",
                    "kind": "parallel",
                    "branches": [
                        {"workflow": "child", "inputs": {"item": {"literal": "A"}}},
                        {"workflow": "child", "inputs": {"item": {"literal": "B"}}},
                    ],
                }
            ],
        },
    )
    parent = Engine(app).start("parent", exclusive=False)
    assert parent["status"] == "awaiting_parallel"
    a, b = parent["parallel"]
    assert a["nonce"] != b["nonce"] and a["prompt"] == "Use A exactly."
    put(app, {"id": "prompt:test", "text": "Changed {{ item }}", "name": "Test"})
    agent_folder = tmp_path / "agent"
    agent_folder.mkdir()
    begun = begin(a["nonce"], agent_folder, app.home)
    assert begun == a
    monkeypatch.chdir(agent_folder)
    bound = App()
    assert bound.get("mode")["run_id"] == a["run_id"]
    assert "web.start" not in Registry(bound).visible()
    Engine(bound).submit(a["run_id"], a["request_id"], "A result")
    Engine(app).submit(b["run_id"], b["request_id"], "B result")
    Engine(app).next(parent["run_id"])
    final = Engine(app).next(parent["run_id"])
    assert final["status"] == "complete"
    assert len(final["result"]["steps"]["fork"]) == 2
    assert (
        Engine(app).start("child", {"item": "C"}, exclusive=False)["prompt"]
        == "Changed C"
    )


def test_fresh_assignment_owns_folder_tools_and_retryable_cleanup(app, tmp_path, monkeypatch):
    from metaform import workfolders
    from metaform.util import python_environment

    import_workflow(app, {"id": "fresh", "steps": [
        {"id": "one", "prompt": "First", "context": "fresh", "tools": ["graph.stats"]},
        {"id": "two", "prompt": "Second", "context": "fresh", "tools": []},
    ]})
    (app.project / "private.txt").write_text("Project context")
    engine = Engine(app)
    first = engine.start("fresh")
    folder = Path(first["workfolder"])
    assert folder.is_dir() and not (folder / "private.txt").exists()
    assert not (folder / ".agentid").exists()
    assert engine.next(first["run_id"]) == first
    caller = tmp_path / "caller"
    caller.mkdir()
    assert begin(first["nonce"], caller, app.home) == first
    assert marker(folder)["request_id"] == first["request_id"]
    assert marker(caller) is None and not (caller / ".agentid").exists()
    bound = App(folder, app.home)
    assert bound.project == app.project
    assert set(Registry(bound).visible()) == {"graph.stats", "workflow.answer", "workflow.next"}
    assert asyncio.run(Registry(bound).call("graph.stats")) is not None
    with pytest.raises(ValueError, match="Unknown command"):
        asyncio.run(Registry(bound).call("workflow.start", {"workflow": "fresh"}))
    (folder / "answer.txt").write_text("Retained output")
    with monkeypatch.context() as patch:
        def fail_cleanup(*args):
            raise OSError("cleanup interrupted")
        patch.setattr(workfolders, "cleanup", fail_cleanup)
        with pytest.raises(OSError, match="cleanup interrupted"):
            engine.submit(first["run_id"], first["request_id"], "First result")
    receipt = engine.submit(first["run_id"], first["request_id"], "Duplicate result")
    assert receipt["recorded"] and not folder.exists()
    assert (app.root / "outputs" / first["workfolder_id"] / "answer.txt").read_text() == "Retained output"
    second = engine.next(first["run_id"])
    assert second["workfolder"] != first["workfolder"]
    assert Path(second["workfolder"]).is_dir()
    environment = python_environment() | {"METAFORM_HOME": str(app.home)}
    begun = subprocess.run([sys.executable, "-m", "metaform", "begin", second["nonce"]],
                           cwd=caller, env=environment, text=True, capture_output=True, check=True)
    assert json.loads(begun.stdout)["request_id"] == second["request_id"]
    submitted = subprocess.run([sys.executable, "-m", "metaform", "workflow", "answer", "--answer", '"Second result"'],
                               cwd=second["workfolder"], env=environment, text=True, capture_output=True, check=True)
    assert json.loads(submitted.stdout)["recorded"]
    assert not Path(second["workfolder"]).exists()
    final = engine.next(first["run_id"])
    assert final["result"]["steps"] == {"one": "First result", "two": "Second result"}
    assert (app.project / "private.txt").read_text() == "Project context"


def test_history_bytes_branches_export_and_offline_runtime(app, tmp_path):
    (app.project / "photo.png").write_bytes(b"\0original\xff")
    (app.project / "index.html").write_text("<h1>Origin</h1>")
    initialize(app)
    (app.project / "photo.png").write_bytes(b"\0edited\xff")
    first = checkpoint(app, "Photo change")
    (app.project / "index.html").write_text("<h1>Another direction</h1>")
    second = checkpoint(app, "Branch", parent="origin")
    target = tmp_path / "reconstructed"
    reconstruct(app, first["id"], target)
    assert (target / "photo.png").read_bytes() == b"\0edited\xff"
    assert (target / "index.html").read_text() == "<h1>Origin</h1>"
    path = tmp_path / "metaform"
    export(app, path)
    with zipfile.ZipFile(path) as archive:
        assert archive.read("origin/photo.png") == b"\0original\xff"
        assert (
            archive.read("versions/" + first["id"] + "/files/photo.png")
            == b"\0edited\xff"
        )
    result = subprocess.run(
        [sys.executable, "-S", str(path), "graph", "stats"],
        cwd=tmp_path,
        env={**os.environ, "PYTHONPATH": ""},
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout)["project"]["elements"] > 0
    import urllib.request
    import venv

    environment = tmp_path / "empty-python"
    venv.EnvBuilder(with_pip=False, symlinks=os.name != "nt").create(environment)
    python = environment / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

    def portable_command(*arguments):
        response = subprocess.run(
            [str(python), "-S", str(path), *arguments],
            cwd=tmp_path,
            env={**os.environ, "PYTHONPATH": "", "PATH": ""},
            capture_output=True,
            text=True,
            timeout=20,
        )
        assert response.returncode == 0, response.stderr
        return json.loads(response.stdout)

    import socket
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    portable_command("system", "configure", "--scope", "home", "--settings", json.dumps({"web_port": port}))
    viewer = portable_command("web", "start")
    try:
        assert viewer["port"] == port
        with urllib.request.urlopen(viewer["url"], timeout=5) as response:
            assert b"Namespace" in response.read()
        with urllib.request.urlopen(viewer["url"] + "/api/network", timeout=5) as response:
            assert json.load(response)["perspective"] == "inference"
    finally:
        portable_command("web", "stop")
    imported = import_bundle(path, tmp_path / "imports")
    destination = Path(imported["path"])
    assert (destination / "index.html").read_text() == "<h1>Another direction</h1>"
    (destination / "local.txt").write_text("Keep local continuation")
    divergent = import_bundle(path, tmp_path / "imports")
    assert divergent["path"] != imported["path"]
    assert (destination / "local.txt").read_text() == "Keep local continuation"
    assert divergent["mform_sha_id"].endswith("_0001")


def test_workbench_edits_prepares_tests_and_serves_assets(app):
    from metaform.viewer import create_app

    client = create_app(app).test_client()
    assert client.get("/static/explorer.js").status_code == 200
    assert client.get("/static/workbench.js").status_code == 404
    assert client.get("/api/network").json["nodes"] == []
    assert client.get("/api/graph").json
    saved = client.post(
        "/api/call/prompt.put",
        json={"prompt": {"id": "prompt:ui", "text": "Use {{ name }}", "name": "UI"}},
    )
    assert saved.status_code == 200
    prepared = client.post(
        "/api/call/prompt.prepare", json={"id": "prompt:ui", "inputs": {"name": "C"}}
    ).json
    assert prepared["prompt"] == "Use C"
    test = client.post(
        "/api/call/prompt.test", json={"prepared": prepared, "answer": "Actual output"}
    ).json
    assert app.graph.get(test["id"])["entity_json_obj"]["answer"] == "Actual output"


def test_workflow_conversion_applies_without_focal_and_keeps_source(app):
    from metaform.modules import workflow

    job = workflow.convert(app, {"source": "Review, then revise."}, None)
    assert job["prompt_ref"] == "prompt:metaform.workflow.convert"
    answer = {
        "id": "converted",
        "steps": [
            {"id": "review", "prompt": "Review."},
            {"id": "revise", "prompt": "Revise."},
        ],
    }
    Engine(app).submit(job["run_id"], job["request_id"], answer)
    Engine(app).next(job["run_id"])
    result = workflow.apply(app, {"run_id": job["run_id"]}, None)
    assert result["id"] == "converted"
    assert (
        Engine(app).definition("converted")["source_instruction"]
        == "Review, then revise."
    )


def test_inclusive_export_replaces_folder_and_graph_edits_fork_it(app, tmp_path):
    (app.project / "index.html").write_text("One")
    archive = tmp_path / "metaform"
    export(app, archive)
    first = import_bundle(archive, tmp_path / "imports")
    again = import_bundle(archive, tmp_path / "imports")
    assert first["path"] == again["path"]
    local = App(first["path"], Path(first["path"]) / ".metaform" / "home")
    local.graph.put({"elements": {"local": record("Local work")}})
    third = import_bundle(archive, tmp_path / "imports")
    assert first["path"] != third["path"]
    assert local.graph.get("local")


def test_exported_active_workfolder_resumes_without_git(app, tmp_path, monkeypatch):
    from metaform import workfolders
    from metaform.modules.graph import backend

    (app.project / "program.py").write_text("before\n")
    import_workflow(app, {"id": "active", "steps": [{"id": "act", "prompt": "Work"}]})
    job = Engine(app).start("active", workfolder=True, exclusive=False)
    Path(job["workfolder"], "program.py").write_text("after\n")
    archive = tmp_path / "metaform"
    export(app, archive)
    returned = import_bundle(archive, tmp_path / "imports")
    target = Path(returned["path"])
    imported = App(target, target / ".metaform" / "home")
    identifier = imported.load_run(job["run_id"])["workfolder_id"]
    body = workfolders.get(imported, identifier)
    assert body["backend"] == "files"
    assert body["path"].startswith(str(target))
    monkeypatch.setenv("PATH", "")
    difference = workfolders.diff(imported, identifier)
    assert "+after" in difference["diff"]
    workfolders.apply(imported, identifier)
    assert (target / "program.py").read_text() == "after\n"
    workfolders.cleanup(imported, identifier)
    assert (
        target / ".metaform" / "outputs" / identifier / "program.py"
    ).read_text() == "after\n"


def test_static_versions_are_served_on_independent_roots(app):
    from metaform.viewer import create_app
    import urllib.request

    (app.project / "index.html").write_text("<h1>Origin</h1>")
    initialize(app)
    (app.project / "index.html").write_text("<h1>Variant</h1>")
    version = checkpoint(app, "Variant")["id"]
    client = create_app(app).test_client()
    urls = client.post("/api/preview", json={"versions": ["origin", version]}).json
    try:
        assert urls[0]["url"] != urls[1]["url"]
        assert client.get(urls[0]["url"]).data == b"<h1>Origin</h1>"
        assert client.get(urls[1]["url"]).data == b"<h1>Variant</h1>"
    finally:
        client.post("/api/preview/stop", json={})


@pytest.mark.parametrize("backend", [JSONGraph, Graph])
def test_source_scoped_joins_can_reference_other_source_joins(tmp_path, backend):
    graph = backend(tmp_path / "source")
    graph.put(
        {
            "elements": {"a": record("A"), "b": record("B"), "c": record("C")},
            "joins": [
                {
                    "id": "dependency",
                    "object_id": "a",
                    "element_id": "b",
                    "type": "dependency",
                },
                {
                    "id": "evidence",
                    "object_id": "dependency",
                    "element_id": "c",
                    "type": "evidence",
                },
            ],
        },
        "archaeology",
    )
    result = graph.assemble("a")
    assert set(result["elements"]) == {"a", "b", "c"}
    assert not result["unresolved"]
