import asyncio
import json
import subprocess
import sys

from metaform.actor import gateway
from metaform.registry import Registry
from metaform.util import python_environment
from metaform.workflow import Engine, import_workflow


def test_folder_modules_support_nested_relative_imports_and_stay_lazy(app):
    roots = [app.home / "modules", app.root / "modules"]
    for index, root in enumerate(roots):
        directory = root / f"example{index}"
        nested = directory / "steps"
        nested.mkdir(parents=True)
        (directory / "__init__.py").write_text("PREFIX = 'module'\n")
        (directory / "helper.py").write_text(f"VALUE = {index}\n")
        (nested / "__init__.py").write_text("")
        marker = directory / "loaded"
        (nested / "handler.py").write_text(
            "from pathlib import Path\n"
            "from .. import PREFIX\n"
            "from ..helper import VALUE\n"
            f"Path({str(marker)!r}).write_text('loaded')\n"
            "def run(app, args, context): return [PREFIX, VALUE]\n"
        )
        (directory / "module.json").write_text(
            json.dumps(
                {
                    "id": f"example{index}",
                    "commands": [{"name": "run", "handler": "steps/handler.py:run"}],
                }
            )
        )
    registry = Registry(app)
    commands = registry.discover()
    for index, root in enumerate(roots):
        assert f"example{index}.run" in commands
        assert not (root / f"example{index}" / "loaded").exists()
        assert asyncio.run(registry.call(f"example{index}.run")) == ["module", index]


def test_plain_cli_keeps_assignment_surface_after_changing_folder(app, tmp_path):
    import_workflow(
        app,
        {
            "id": "scoped",
            "steps": [{"id": "act", "prompt": "Work", "tools": ["workflow.search"]}],
        },
    )
    job = Engine(app).start("scoped")
    elsewhere = tmp_path / "unrelated"
    elsewhere.mkdir()
    with gateway(app, job) as environment:
        env = python_environment() | environment
        result = subprocess.run(
            [sys.executable, "-m", "metaform"],
            cwd=elsewhere,
            env=env,
            text=True,
            capture_output=True,
            check=True,
        )
        assert {c["name"] for c in json.loads(result.stdout)["commands"]} == {
            "workflow.search",
            "abort",
        }
        denied = subprocess.run(
            [sys.executable, "-m", "metaform", "system.status"],
            cwd=elsewhere,
            env=env,
            text=True,
            capture_output=True,
        )
        assert denied.returncode == 1
        assert not (elsewhere / ".metaform").exists()


def test_expired_gateway_does_not_fall_back_to_main_router(app, tmp_path):
    import_workflow(
        app,
        {
            "id": "expired",
            "steps": [{"id": "act", "prompt": "Work"}],
        },
    )
    job = Engine(app).start("expired")
    with gateway(app, job) as environment:
        env = python_environment() | environment
    elsewhere = tmp_path / "unrelated"
    elsewhere.mkdir()
    result = subprocess.run(
        [sys.executable, "-m", "metaform"],
        cwd=elsewhere,
        env=env,
        text=True,
        capture_output=True,
    )
    assert result.returncode == 1
    assert not (elsewhere / ".metaform").exists()
