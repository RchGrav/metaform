from metaform.continuation import marker
import asyncio
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from metaform.app import App
from metaform.util import write_json


def local_project(path, mode="legacy"):
    write_json(path / ".metaform" / "config.json", {
        "knowledge_mode": mode, "graph_backend": "json", "auto_build": False,
    })
    return path


def test_portable_config_precedes_ambient_home_and_bundle_marker(tmp_path, monkeypatch):
    project = local_project(tmp_path / "portable", "portable")
    ambient = tmp_path / "ambient"
    monkeypatch.setenv("METAFORM_HOME", str(ambient))
    app = App(project)
    assert app.home == project / ".metaform" / "home"
    assert app.knowledge_mode == "portable"
    assert not ambient.exists()
    assert app.graph.path.suffix == ".json"


def test_explicit_project_does_not_override_assignment_binding(tmp_path, monkeypatch):
    project = local_project(tmp_path / "bound")
    binding = {"project": str(project), "home": str(tmp_path / "home"),
               "module": "workflow", "run_id": "run", "request_id": "request", "nonce": "1"}
    monkeypatch.setenv("METAFORM_BINDING", json.dumps(binding))
    app = App(tmp_path / "other")
    assert app.project == project
    assert app.binding == binding
    assert not (tmp_path / "other").exists()


def test_existing_project_remains_legacy_without_adoption(tmp_path):
    project = tmp_path / "existing"
    (project / ".metaform").mkdir(parents=True)
    (project / ".metaform" / "state.sqlite3").touch()
    app = App(project, tmp_path / "home")
    assert app.knowledge_mode == "legacy"
    assert not (app.root / "project.json").exists()


def test_new_project_defaults_to_service_before_seed(tmp_path, monkeypatch):
    calls = []

    class Remote:
        def __init__(self, home, project_id):
            self.project_id = project_id

        def call(self, operation, arguments, request_id=None):
            calls.append((operation, arguments))
            if operation == "project.register":
                return {"project_id": "new-id", "path": arguments["path"], "name": "new"}
            if operation == "project.get":
                return {"project_id": "new-id", "path": str(tmp_path / "new"), "name": "new"}
            raise AssertionError(operation)

    monkeypatch.setitem(sys.modules, "metaform.service", SimpleNamespace(
        RemoteKnowledge=Remote, ensure_service=lambda home: {"ready": True}))
    monkeypatch.setattr(App, "seed", lambda self: calls.append(("seed", self.knowledge_mode)))
    app = App(tmp_path / "new", tmp_path / "home")
    assert app.knowledge_mode == "service"
    assert app.project_id == "new-id"
    assert calls[0][0] == "project.register"
    assert calls[-1] == ("seed", "service")
    assert json.loads((app.root / "project.json").read_text())["project_id"] == "new-id"


def test_cli_selector_is_consumed_before_actor_dispatch(tmp_path, monkeypatch):
    from metaform import actor, cli
    project = local_project(tmp_path / "project")
    captured = []
    monkeypatch.setattr(actor, "main", lambda args: captured.append(args) or 0)
    assert cli.main(["--project", str(project), "actor", "workflow.get"]) == 0
    assert captured == [["workflow.get"]]
    assert not (project / ".metaform" / "state.sqlite3").exists()


def test_begin_selector_conflict_does_not_write_binding(tmp_path):
    from metaform.continuation import begin
    home = tmp_path / "home"
    project = local_project(tmp_path / "project")
    write_json(home / "assignments" / "123.json", {
        "nonce": "123", "project": str(project), "home": str(home),
        "module": "workflow", "run_id": "run", "request_id": "request",
    })
    target = tmp_path / "work"
    target.mkdir()
    with pytest.raises(ValueError, match="bound|assignment|project"):
        begin("123", folder=target, home=home, project=tmp_path / "other")
    assert not (target / ".agentid").exists() and marker(target) is None


def test_project_controls_do_not_expand_assignment_surface(tmp_path):
    from metaform.registry import Registry
    app = App(local_project(tmp_path / "project"), tmp_path / "home")
    assert "project.select" in Registry(app).discover()
    app.binding = {"module": "workflow", "run_id": "same", "request_id": "job"}
    app.save_run({"id": "same", "workflow": "w", "status": "running"})
    assert not any(key.startswith("project.") for key in Registry(app).visible())


def test_workbench_project_urls_keep_tabs_independent(tmp_path):
    from metaform.viewer import create_app
    from metaform.service import stop_service
    home = tmp_path / "home"
    try:
        a = App(tmp_path / "a", home)
        b = App(tmp_path / "b", home)
        client = create_app(a).test_client()
        prefix_a, prefix_b = "/projects/" + a.project_id, "/projects/" + b.project_id
        assert client.get(prefix_a + "/api/settings").json["project"] == str(a.project)
        assert client.get(prefix_b + "/api/settings").json["project"] == str(b.project)
        assert client.get(prefix_a + "/api/settings").json["project"] == str(a.project)
        page = client.get(prefix_b + "/").get_data(as_text=True)
        assert 'data-project-prefix="' + prefix_b + '"' in page
        assert "/legacy" not in page
        assert client.get(prefix_b + "/legacy").status_code == 404
    finally:
        stop_service(home)


def test_mcp_sampling_token_keeps_original_project_after_selection(tmp_path, monkeypatch):
    from mcp import types
    from metaform import mcp_server
    from metaform.modules.project import ProjectSession
    a = App(local_project(tmp_path / "a"), tmp_path / "home")
    b = App(local_project(tmp_path / "b"), tmp_path / "home")
    monkeypatch.setattr(a, "select_project", lambda selector: b)
    session = ProjectSession(a)
    request = SimpleNamespace(protocol_version="2026-07-28")
    context = mcp_server.Context(a, request, session)
    pending = {"run_id": "same", "request_id": "same", "params": {
        "messages": [{"role": "user", "content": {"type": "text", "text": "work"}}],
        "maxTokens": 10,
    }}
    single = asyncio.run(context.dispatch(pending))
    session.select("b")
    assert session.app is b
    assert session.sampling_apps[single.request_state] is a
    batch = context.batch_request({"run_id": "same", "batch": {"same": pending}, "results": []})
    assert isinstance(batch, types.InputRequiredResult)
    assert session.sampling_apps[batch.request_state] is a
    assert a.get("sampling:" + batch.request_state)["run_id"] == "same"
    assert b.get("sampling:" + batch.request_state) is None


def test_service_projects_share_global_knowledge_and_keep_local_state(tmp_path):
    from metaform.service import stop_service
    home = tmp_path / "service-home"
    try:
        a = App(tmp_path / "a", home)
        b = App(tmp_path / "b", home)
        record = {"entity_desc": "Shared", "entity_schema": "metaform:element", "entity_json_obj": {"en": "Shared"}}
        a.global_graph.put({"elements": {"X": record}}, "archaeology")
        a.graph.put({"elements": {"X": dict(record, entity_desc="A")}}, "native")
        b.graph.put({"elements": {"X": dict(record, entity_desc="B")}}, "native")
        a.set("same", "A")
        b.set("same", "B")
        assert b.global_graph.get("X")["entity_desc"] == "Shared"
        assert a.graph.get("X", scope="native")["entity_desc"] == "A"
        assert b.graph.get("X", scope="native")["entity_desc"] == "B"
        assert a.get("same") == "A" and b.get("same") == "B"
        assert a.select_project(b.project_id).project == b.project
    finally:
        stop_service(home)


def test_portable_semantic_owner_is_distinct_from_copy_identity(tmp_path):
    project = local_project(tmp_path / "portable", "portable")
    write_json(project / ".metaform" / "project.json", {
        "knowledge_mode": "portable", "origin_project_id": "origin", "copy_id": "copy",
    })
    app = App(project)
    assert app.project_id == "origin"
    assert app.copy_id == "copy"


def test_portable_mcp_request_uses_captured_app_after_session_selection(tmp_path, monkeypatch):
    from metaform import portable_mcp
    from metaform.modules.project import ProjectSession
    from metaform.registry import Registry
    a = App(local_project(tmp_path / "a"), tmp_path / "home")
    b = App(local_project(tmp_path / "b"), tmp_path / "home")
    monkeypatch.setattr(a, "select_project", lambda selector: b)
    session = ProjectSession(a)
    old_context = portable_mcp.Context(a, session)
    session.select("b")
    response = asyncio.run(portable_mcp.dispatch(
        a, Registry(a), "tools/call", {"name": "project.current"}, old_context))
    assert response["structuredContent"]["project_id"] == a.project_id
    assert session.app.project_id == b.project_id


def test_cli_marker_binding_conflict_is_reported_without_other_project(tmp_path, monkeypatch, capsys):
    from metaform.cli import main
    from metaform.continuation import begin
    from metaform.workflow import Engine, import_workflow

    home = tmp_path / "home"
    monkeypatch.setenv("METAFORM_HOME", str(home))
    project = local_project(tmp_path / "project")
    app = App(project, home, binding=False)
    import_workflow(app, {"id": "bound", "steps": [{"id": "work", "prompt": "Work"}]})
    job = Engine(app).start("bound", exclusive=False)
    bound = tmp_path / "bound-folder"
    begin(job["nonce"], bound, home)
    monkeypatch.chdir(bound)
    other = tmp_path / "other"
    assert main(["--project", str(other), "project", "current"]) == 1
    assert "conflict" in capsys.readouterr().err
    assert not other.exists()


def test_local_dispatcher_tracks_replaced_raw_graphs(tmp_path):
    from metaform.backends import JSONGraph
    app = App(local_project(tmp_path / "project"), tmp_path / "home")
    original = app.knowledge
    app.graph = JSONGraph(app.root / "replacement.json")
    record = {"entity_desc": "Replacement", "entity_schema": "metaform:element", "entity_json_obj": {"en": "Replacement"}}
    app.knowledge.call("graph.put", {"owner": "project:" + app.project_id, "graph": {"elements": {"X": record}}})
    assert app.graph.get("X") == record
    assert original.graphs["project:" + app.project_id].get("X") is None


@pytest.mark.parametrize("selector_kind", ["path", "id"])
def test_cli_relocation_repairs_moved_registration_before_app_startup(tmp_path, monkeypatch, capsys, selector_kind):
    import shutil
    from metaform.cli import main
    from metaform.service import stop_service
    home = tmp_path / "home"
    try:
        original = App(tmp_path / "original", home)
        moved = tmp_path / "moved"
        shutil.move(str(original.project), moved)
        monkeypatch.setenv("METAFORM_HOME", str(home))
        assert main(["--project", str(moved) if selector_kind == "path" else original.project_id, "project", "relocate", "--path", str(moved)]) == 0
        assert App(moved, home).project_id == original.project_id
    finally:
        stop_service(home)


def test_mcp_resume_handler_answers_origin_project_after_switch(tmp_path, monkeypatch):
    import copy
    from mcp import types
    from metaform import mcp_server
    from metaform.workflow import Engine, import_workflow
    a = App(local_project(tmp_path / "a"), tmp_path / "home")
    b = App(local_project(tmp_path / "b"), tmp_path / "home")
    import_workflow(a, {"id": "work", "steps": [{"id": "act", "prompt": "Return work"}]})
    job = Engine(a).start("work")
    b.save_run(copy.deepcopy(a.load_run(job["run_id"])))
    b.enter("workflow", job["run_id"])
    monkeypatch.setattr(a, "select_project", lambda selector: b)
    monkeypatch.setattr(mcp_server, "Server", lambda *args, **kwargs: SimpleNamespace(**kwargs))
    server = mcp_server.server(a)
    context = SimpleNamespace(protocol_version="2026-07-28", session=SimpleNamespace(
        client_capabilities=SimpleNamespace(sampling=types.SamplingCapability())))

    async def scenario():
        pending = await server.on_call_tool(context, types.CallToolRequestParams(
            name="workflow.drive", arguments={"run_id": job["run_id"]}))
        assert isinstance(pending, types.InputRequiredResult)
        switched = await server.on_call_tool(context, types.CallToolRequestParams(
            name="project.select", arguments={"project": "b"}))
        assert switched.structured_content["project_id"] == b.project_id
        resumed = await server.on_call_tool(context, types.CallToolRequestParams(
            name="workflow.drive", request_state=pending.request_state,
            input_responses={"answer": types.CreateMessageResult(
                role="assistant", model="fixture", stop_reason="endTurn",
                content=types.TextContent(type="text", text='{"answer":"A"}'))}))
        assert not resumed.is_error
        assert a.load_run(job["run_id"])["pending"] is None
        assert b.load_run(job["run_id"])["pending"]["request_id"] == job["request_id"]

    asyncio.run(scenario())


def test_cli_connect_new_preserves_copied_service_knowledge(tmp_path, monkeypatch, capsys):
    import shutil
    from metaform.cli import main
    from metaform.service import stop_service
    home = tmp_path / "home"
    try:
        source = App(tmp_path / "source", home)
        record = {"entity_desc": "Copied local knowledge", "entity_schema": "metaform:element", "entity_json_obj": {"en": "X"}}
        source.graph.put({"elements": {"X": record}}, "native")
        copied = tmp_path / "copied"
        shutil.copytree(source.project, copied)
        monkeypatch.setenv("METAFORM_HOME", str(home))
        assert main(["--project", str(copied), "project", "connect", "--new", "--name", "Copied project"]) == 0
        connected = App(copied, home)
        assert connected.project_id != source.project_id
        assert connected.project_context()["name"] == "Copied project"
        assert connected.graph.get("X", scope="native") == record
        assert source.graph.get("X", scope="native") == record
    finally:
        stop_service(home)


@pytest.mark.parametrize("mode", ["portable", "service"])
def test_begin_uses_selected_project_home_before_nonce_lookup(tmp_path, monkeypatch, mode):
    from metaform import cli
    from metaform.workflow import Engine, import_workflow
    from metaform.service import stop_service
    project = tmp_path / "selected"
    home = tmp_path / "custom-service-home"
    if mode == "portable":
        local_project(project, mode)
    app = App(project, home)
    try:
        import_workflow(app, {"id": "selected", "steps": [{"id": "work", "prompt": "Selected work."}]})
        job = Engine(app).start("selected", exclusive=False)
        outside = tmp_path / "outside"
        outside.mkdir()
        monkeypatch.chdir(outside)
        monkeypatch.setenv("METAFORM_HOME", str(tmp_path / "unrelated-home"))
        assert cli.main(["--project", str(project), "begin", str(job["nonce"])]) == 0
        assert marker(outside)["project"] == str(project) and not (outside / ".agentid").exists()
    finally:
        if mode == "service":
            stop_service(home)


def test_viewer_dispatch_passes_concrete_app_to_gateway_thread(tmp_path, monkeypatch):
    import urllib.request
    from metaform import actor
    from metaform.registry import Registry
    from metaform.viewer import create_app
    from metaform.workflow import Engine, import_workflow
    app = App(local_project(tmp_path / "project"), tmp_path / "home")
    import_workflow(app, {"id": "viewer", "steps": [{"id": "work", "prompt": "Work."}]})
    job = Engine(app).start("viewer", exclusive=False)

    async def gateway_request(registry, key, arguments=None, context=None, **kwargs):
        with actor.gateway(registry.app, job) as environment:
            request = urllib.request.Request(environment["METAFORM_GATEWAY"], data=b"{}", headers={
                "Authorization": "Bearer " + environment["METAFORM_GATEWAY_TOKEN"],
                "Content-Type": "application/json",
            })
            with urllib.request.urlopen(request, timeout=5) as response:
                return json.load(response)

    monkeypatch.setattr(Registry, "call", gateway_request)
    response = create_app(app).test_client().post("/projects/" + app.project_id + "/api/call/workflow.drive", json={})
    assert response.status_code == 200, response.json
    assert "commands" in response.json


def test_viewer_unknown_project_url_never_creates_project(tmp_path, monkeypatch):
    from metaform.viewer import create_app
    app = App(local_project(tmp_path / "project"), tmp_path / "home")
    monkeypatch.chdir(tmp_path)
    calls = []
    monkeypatch.setattr(app, "select_project", lambda identifier: calls.append(identifier) or app)
    response = create_app(app).test_client().get("/projects/typo/api/settings")
    assert response.status_code == 404
    assert calls == []
    assert not (tmp_path / "typo").exists()


@pytest.mark.parametrize("operation", ["status", "stop"])
def test_service_inspection_uuid_selector_does_not_start_service(tmp_path, monkeypatch, operation):
    import uuid
    from metaform.modules.project import bootstrap
    from metaform import service
    home = tmp_path / "home"
    monkeypatch.setenv("METAFORM_HOME", str(home))
    calls = []
    monkeypatch.setattr(service.RemoteKnowledge, "call", lambda *args, **kwargs: pytest.fail("Global lifecycle must not resolve the project"))
    monkeypatch.setattr(service, "service_status", lambda: calls.append("status") or {"ready": False})
    monkeypatch.setattr(service, "stop_service", lambda: calls.append("stop") or {"stopped": False})
    result = bootstrap(["service", operation], uuid.uuid4().hex)
    assert calls == [operation]
    assert result == ({"ready": False} if operation == "status" else {"stopped": False})
    assert not home.exists()
