const {test}=require('node:test');
const assert=require('node:assert/strict');
const {structureScene,typeName,shapeKind,zoomAt,purposeText}=require('../src/metaform/static/structure.js');
const node=(id,payload={})=>({id,kind:'element',entity_json_obj:payload});

test('relationship presentation preserves explicit classification and softness without deriving either from purpose',()=>{
  const {joinPresentation,setJoinClassifications}=require('../src/metaform/static/structure.js');
  const property={role:'property',classification:'language',is_soft:true,purpose:'External dependency'};
  const before=JSON.stringify(property);
  assert.equal(joinPresentation(property).label,'Property · language');
  assert.equal(joinPresentation(property).softness,'Non-transitive property');
  assert.equal(joinPresentation({role:'requirement',classification:'compatibility',is_soft:true}).softness,'Optional requirement');
  assert.equal(joinPresentation({role:'requirement',purpose:'Python language'}).label,'Requirement');
  assert.equal(joinPresentation({type:'hard dependency'}).label,'Join');
  assert.equal(joinPresentation({type:'supportive'}).label,'Join');
  setJoinClassifications(require('../src/metaform/static/join-classifications.json'));
  const declared=require('../src/metaform/static/join-classifications.json').property.language;
  assert.equal(joinPresentation(property).color,declared.color);assert(joinPresentation(property).label.startsWith(declared.emoji));
  assert.equal(joinPresentation({role:'property',classification:'custom classification'}).label,'Property · custom classification');
  assert.equal(joinPresentation({role:'requirement',purpose:declared.match}).color,undefined,'Authoring match text is not runtime classification');
  setJoinClassifications({});
  assert.equal(JSON.stringify(property),before);
});

test('namespace navigation retains concrete records and does not mint Elements',()=>{
  const original=[node('code.installer',{notes:'Installs the game into the selected directory'}),node('code.installer.verify'),node('code.engine.game')];
  const before=JSON.stringify(original);
  const root=structureScene(original,[],[],null);
  assert.equal(root.nodes.find(n=>n.id==='code').kind,'namespace');
  const inside=structureScene(original,[],[],'code.installer');
  assert.equal(inside.nodes.find(n=>n.id==='code.installer').entity_json_obj.notes,'Installs the game into the selected directory');
  assert(inside.nodes.some(n=>n.id==='code.installer.verify'));
  assert(!inside.nodes.some(n=>n.id==='code.engine.game'));
  assert.equal(JSON.stringify(original),before);
});

test('joins crossing the open Type retain their actual receivers, purpose and reference targets',()=>{
  const nodes=[node('code.engine'),node('ext.framework.box2d')];
  const joins=[{id:'physics',object_id:'code.engine',element_id:'ext.framework.box2d',type:'hard dependency',purpose:'Resolve moving body collisions'}];
  const edges=[{join_id:'physics',source:'ext.framework.box2d',target:'code.engine'}];
  const scene=structureScene(nodes,joins,edges,'code.engine');
  assert.equal(scene.nodes.find(n=>n.id==='ext.framework.box2d').context,true);
  assert.equal(scene.edges.find(e=>e.join_id==='physics').source,'ext.framework.box2d');
  assert.equal(scene.joins[0].purpose,'Resolve moving body collisions');
});

test('n-ary joins and joins on joins remain navigable without invented direction',()=>{
  const nodes=[node('media.photo'),node('ext.person.couple'),node('ext.environment.paris')];
  const joins=[{id:'scene',type:'supportive',participants:[{ref:'media.photo'},{ref:'ext.person.couple'},{ref:'ext.environment.paris'}]},
    {id:'explanation',object_id:'scene',element_id:'media.photo',type:'supportive'}];
  const scene=structureScene(nodes,joins,[],'media.photo');
  assert(scene.nodes.some(n=>n.id==='scene'&&n.kind==='join'));
  assert(scene.nodes.some(n=>n.id==='explanation'&&n.kind==='join'));
  assert(scene.edges.some(e=>e.source==='explanation'&&e.target==='scene'&&e.kind==='participant'));
  assert(scene.edges.filter(e=>e.kind==='participant').every(e=>!e.directed));
});

test('names use length and exterior kinds determine shapes',()=>{
  assert.equal(typeName(node('code.system.driver.network',{length:2,en:'old name'})),'network driver');
  assert.equal(shapeKind('exterior.framework.box2d'),'framework');
  assert.equal(shapeKind('ext.person.player'),'person');
  assert.equal(shapeKind('media.photo.product.used'),'media');
});

test('pointer anchored zoom keeps the world location fixed',()=>{
  const view={x:40,y:20,k:1.5},pointer={x:210,y:150};
  const next=zoomAt(view,pointer,2);
  assert.equal((pointer.x-next.x)/next.k,(pointer.x-view.x)/view.k);
  assert.equal((pointer.y-next.y)/next.k,(pointer.y-view.y)/view.k);
});

test('a join referenced by another join gets an inspectable junction even when binary',()=>{
  const nodes=[node('code.a'),node('code.b'),node('document.support')];
  const joins=[{id:'ab',object_id:'code.a',element_id:'code.b',type:'dependency'},
    {id:'support',type:'supportive',participants:[{ref:'ab'},{ref:'document.support'}]}];
  const edges=[{join_id:'ab',source:'code.b',target:'code.a'}];
  for(const focus of [null,'document.support']){
    const scene=structureScene(nodes,joins,edges,focus);
    assert(scene.nodes.some(n=>n.id==='ab'&&n.kind==='join'));
    const ids=new Set(scene.nodes.map(n=>n.id));
    assert(scene.edges.every(e=>ids.has(e.source)&&ids.has(e.target)));
  }
});

test('structured purposes label their actual OP while retaining the complete value',()=>{
  const purpose={receiving_entity:'exterior.operator',linked_element:'code.interface',op:'Inspect connectivity and issue operational controls'};
  assert.equal(purposeText(purpose),purpose.op);
  assert.equal(purposeText('Plain purpose'),'Plain purpose');
  assert.equal(purpose.receiving_entity,'exterior.operator');
});

const actual=(id,type_id,en=id)=>node(id,{type_id,en,ef:'Actual behavior of '+en});
const functionalNodes=[node('code.interface'),node('code.manager'),node('data.state'),actual('mgm.interface','code.interface','MGM control interface'),actual('sentry.interface','code.interface','Sentry observations'),actual('gateway','code.manager'),actual('monitor','code.manager'),actual('peers','data.state'),actual('probes','data.state')];
const functionalJoins=[['mgm-control','gateway','mgm.interface'],['sentry-control','monitor','sentry.interface'],['mgm-state','mgm.interface','peers'],['sentry-state','sentry.interface','probes']].map(([id,object_id,element_id])=>({id,object_id,element_id,type:'hard dependency',purpose:id}));
const functionalEdges=functionalJoins.map(j=>({join_id:j.id,source:j.element_id,target:j.object_id}));
test('Type drilldown preserves two actual Elements with the same classification and their different relationships',()=>{
  const scene=structureScene(functionalNodes,functionalJoins,functionalEdges,'code.interface');
  for(const id of ['mgm.interface','sentry.interface','gateway','monitor','peers','probes'])assert(scene.nodes.some(n=>n.id===id),id+' is visible');
  assert(!scene.nodes.some(n=>n.id==='mgm'||n.id==='sentry'),'Actual IDs never become namespace paths');
  assert.equal(scene.edges.length,4);
  assert.equal(scene.nodes.find(n=>n.id==='mgm.interface').type_id,'code.interface');
  assert.equal(typeName(actual('mgm.interface','code.interface','MGM control interface')),'MGM control interface');
  assert.equal(shapeKind(actual('box','ext.framework','Box2D')),'framework');
});
test('Actual Element drilldown follows its relationships, not unrelated Elements with the same Type',()=>{
  const scene=structureScene(functionalNodes,functionalJoins,functionalEdges,'mgm.interface');
  assert(scene.nodes.some(n=>n.id==='gateway'));assert(scene.nodes.some(n=>n.id==='peers'));
  assert(!scene.nodes.some(n=>n.id==='sentry.interface'));
  assert.equal(scene.edges.length,2);
});

test('multiple Type memberships enrich one freeform actual node without membership joins',()=>{
  const description={behavior:'Describe the subject and its surroundings',context:{occasion:'A field survey'}};
  const records=[{...node('survey',{en:'Field survey',description,type_ids:['media.photo','document.report']}),entity_schema:'metaform:actual-element'},node('media.photo',{length:1,ef:'Present a photographic image'}),node('document.report',{length:1,ef:'Convey an account'})];
  const scene=structureScene(records,[],[],'survey');
  assert.equal(scene.nodes.length,1);assert.equal(scene.edges.length,0);assert.equal(scene.joins.length,0);
  assert.deepEqual(scene.nodes[0].entity_json_obj.description,description);
  assert.deepEqual(scene.nodes[0].type_records.map(n=>n.id),['media.photo','document.report']);
  for(const type of ['media.photo','document.report'])assert.equal(structureScene(records,[],[],type).nodes.filter(n=>n.id==='survey').length,1);
  assert.equal(typeName(records[1]),'photo');assert.equal(typeName(records[2]),'report');
});

test('relation to the defining Element follows recorded purposes independently of browsing',()=>{
  const {definingRelation}=require('../src/metaform/static/structure.js');
  const records=[actual('root','code.manager'),actual('interface','code.interface'),actual('state','data.state'),actual('unrelated','data.state')];
  records[0].entity_json_obj.defining_element=true;
  const joins=[{id:'control',object_id:'root',element_id:'interface',type:'hard dependency',purpose:'Control the system'},{id:'report',object_id:'interface',element_id:'state',type:'hard dependency',purpose:'Report current state'}];
  assert.deepEqual(definingRelation(records,joins,'state').steps.map(s=>s.join.purpose),['Report current state','Control the system']);
  assert.equal(definingRelation(records,joins,'state').defining,'root');
  assert.deepEqual(definingRelation(records,joins,'root').steps,[]);
  assert.equal(definingRelation(records,joins,'unrelated'),null);
});

test('relation to defining Element can traverse a reified join',()=>{
  const {definingRelation}=require('../src/metaform/static/structure.js');
  const records=[actual('root','code.manager'),actual('a','code.interface'),actual('b','data.state')];records[0].entity_json_obj.defining_element=true;
  const joins=[{id:'meeting',object_id:'a',element_id:'b',purpose:'Read state'}, {id:'contract',object_id:'root',element_id:'meeting',purpose:'Use the state-reading relationship'}];
  const relation=definingRelation(records,joins,'a');
  assert.equal(relation.defining,'root');assert.deepEqual(relation.steps.map(s=>s.to),['meeting','root']);
});
