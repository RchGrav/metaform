import asyncio
import json

from metaform import schemas
from metaform.portable_mcp import dispatch, tool_list
from metaform.registry import Registry
from metaform.viewer import create_app


def test_output_contract_is_discoverable_and_portable(app):
    """An external caller can validate a plugin result using its advertised schema."""
    schema = {"$id": "urn:test:semantic-result", "$schema": "https://json-schema.org/draft/2020-12/schema",
              "type": "object", "required": ["result"], "properties": {"result": {"type": "string"}}}
    schemas.register(app, schema)
    directory = app.root / "modules" / "semantic-fixture"
    directory.mkdir(parents=True)
    (directory / "read.py").write_text("def inspect(app, args, context): return {'result': args['target']}\n")
    (directory / "module.json").write_text(json.dumps({"id": "fixture", "commands": [{
        "name": "inspect", "handler": "read.py:inspect", "inputSchema": {"type": "object", "properties": {
            "target": {"type": "string"}}, "required": ["target"]}, "outputSchema": schema["$id"]}]}))
    registry = Registry(app)
    tools = tool_list(registry)["tools"]
    advertised = next(tool for tool in tools if tool["name"] == "fixture.inspect")
    response = asyncio.run(dispatch(app, registry, "tools/call", {
        "name": "fixture.inspect", "arguments": {"target": "a/target.with:identity"}}))
    assert response["structuredContent"] == {"result": "a/target.with:identity"}
    assert schemas.annotations(app, advertised["outputSchema"], response["structuredContent"]) == []
    assert "outputSchema" not in next(tool for tool in tools if tool["name"] == "graph.get")


def test_versioned_resource_and_gui_use_the_same_module_command(app):
    from urllib.parse import quote

    directory = app.root / "modules" / "resource-fixture"
    directory.mkdir(parents=True)
    (directory / "read.py").write_text("def inspect(app, args, context): return args\n")
    (directory / "module.json").write_text(json.dumps({"id": "fixture", "commands": [{
        "name": "inspect", "handler": "read.py:inspect", "resourceKind": "fixture",
        "inputSchema": {"type": "object"}}]}))
    registry = Registry(app)
    uri = "metaform://model/" + "/".join(quote(value, safe="") for value in (
        app.project_id, "artifact/model", "revision:1", "fixture", "actual/a.b:c"))
    arguments = {"model": {"project": app.project_id, "model": "artifact/model", "revision": "revision:1"},
                 "target": {"kind": "fixture", "id": "actual/a.b:c"}}
    client = create_app(app).test_client()
    gui = client.post("/api/semantic/fixture.inspect", json=arguments)
    resource = asyncio.run(dispatch(app, registry, "resources/read", {"uri": uri}))
    assert gui.status_code == 200
    assert gui.json == json.loads(resource["contents"][0]["text"]) == arguments
    templates = asyncio.run(dispatch(app, registry, "resources/templates/list", {}))["resourceTemplates"]
    assert any("/fixture/" in item["uriTemplate"] for item in templates)
    app.set("disabled_commands", ["fixture.inspect"])
    assert client.post("/api/semantic/fixture.inspect", json=arguments).status_code != 200
    assert not any("/fixture/" in item["uriTemplate"] for item in asyncio.run(
        dispatch(app, registry, "resources/templates/list", {}))["resourceTemplates"])
