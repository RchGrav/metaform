"""Exercise the real detached knowledge owner and authenticated HTTP boundary."""
import http.client
import json
import os
import subprocess
import sys
import time

import pytest

from metaform.util import python_environment, write_json
from test_knowledge_contract import element


def service_module():
    import metaform.service
    return metaform.service


@pytest.fixture
def home(tmp_path):
    root = tmp_path / "home"
    yield root
    try:
        service_module().stop_service(root, timeout=5)
    except Exception:
        pass


def child(code, *args):
    return subprocess.Popen(
        [sys.executable, "-c", code, *map(str, args)],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env=python_environment(),
    )


def wait_file(path, process=None, timeout=10):
    deadline = time.monotonic() + timeout
    while not path.exists():
        if process is not None and process.poll() is not None:
            raise AssertionError(process.communicate())
        assert time.monotonic() < deadline, str(path)
        time.sleep(0.02)


def test_first_start_verified_reuse_and_stable_restart(home):
    service = service_module()
    first = service.ensure_service(home)
    assert first["host"] == "127.0.0.1"
    assert first["pid"] != os.getpid()
    assert service.ensure_service(home) == first
    status = service.service_status(home)
    assert status["ready"] is True
    assert status["instance_id"] == first["instance_id"]
    assert (home / "service/token").stat().st_mode & 0o077 == 0
    assert service.stop_service(home)["stopped"] is True
    second = service.ensure_service(home)
    assert second["instance_id"] != first["instance_id"]
    assert second["service_id"] == first["service_id"]


def test_stale_files_and_pid_do_not_prevent_start_or_signal_process(home):
    write_json(home / "service/endpoint.json", {
        "protocol": 1, "service_id": "stale", "instance_id": "stale",
        "host": "127.0.0.1", "port": 1, "pid": os.getpid(),
    })
    for name in ("start.lock", "instance.lock"):
        (home / "service" / name).touch()
    assert service_module().ensure_service(home)["pid"] != os.getpid()


def test_eight_competing_process_starters_share_one_instance(home):
    processes = [child(
        "import json,sys; from metaform.service import ensure_service; "
        "print(json.dumps(ensure_service(sys.argv[1])))", home
    ) for _ in range(8)]
    try:
        endpoints = []
        for process in processes:
            out, err = process.communicate(timeout=30)
            assert process.returncode == 0, err.decode()
            endpoints.append(json.loads(out))
        assert len({item["instance_id"] for item in endpoints}) == 1
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)


def test_live_owner_without_readiness_fails_within_deadline(home):
    directory = home / "service"
    directory.mkdir(parents=True)
    ready = directory / "test-lock-held"
    process = child(
        "import sys,time; from pathlib import Path; from filelock import FileLock; "
        "lock=FileLock(Path(sys.argv[1])/'instance.lock'); lock.acquire(); "
        "Path(sys.argv[1],'test-lock-held').touch(); time.sleep(60)", directory
    )
    try:
        wait_file(ready, process)
        start = time.monotonic()
        with pytest.raises(Exception) as failure:
            service_module().ensure_service(home, timeout=0.3)
        assert failure.value.code == "service_unavailable"
        assert "service.log" in str(failure.value)
        assert time.monotonic() - start < 2
        assert process.poll() is None
    finally:
        process.terminate()
        process.wait(timeout=5)
    assert service_module().ensure_service(home)["pid"] != process.pid


def test_authentication_and_health_challenge(home):
    service = service_module()
    endpoint = service.ensure_service(home)
    token = (home / "service/token").read_text().strip()
    connection = http.client.HTTPConnection(endpoint["host"], endpoint["port"])
    connection.request("GET", "/v1/health?challenge=fresh-value", headers={"Authorization": "Bearer wrong"})
    response = connection.getresponse()
    assert response.status == 401
    response.read()
    connection.request("GET", "/v1/health?challenge=fresh-value", headers={"Authorization": f"Bearer {token}"})
    response = connection.getresponse()
    assert response.status == 200
    assert json.loads(response.read())["challenge"] == "fresh-value"
    connection.close()


@pytest.mark.parametrize("bad_field,bad_value", [("product", "other-product"), ("challenge", "replayed"), ("instance_id", "old")])
def test_discovery_rejects_wrong_listener_identity(home, bad_field, bad_value):
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import parse_qs, urlsplit

    class WrongHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            reply = {"product": "metaform-knowledge", "protocol": 1, "service_id": "fake", "instance_id": "fake", "ready": True,
                     "challenge": parse_qs(urlsplit(self.path).query)["challenge"][0]}
            reply[bad_field] = bad_value
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps(reply).encode())
        def log_message(self, *args):
            pass

    listener = ThreadingHTTPServer(("127.0.0.1", 0), WrongHandler)
    thread = threading.Thread(target=listener.serve_forever)
    thread.start()
    try:
        write_json(home / "service/endpoint.json", {"protocol": 1, "service_id": "fake", "instance_id": "fake", "host": "127.0.0.1", "port": listener.server_port, "pid": os.getpid()})
        (home / "service/token").write_text("test-token")
        endpoint = service_module().ensure_service(home)
        assert endpoint["port"] != listener.server_port
    finally:
        listener.shutdown()
        listener.server_close()
        thread.join()


def test_remote_project_envelope_and_durable_request_retry(home, tmp_path):
    service = service_module()
    admin = service.RemoteKnowledge(home, None)
    a = admin.call("project.register", {"path": str(tmp_path / "a")})["project_id"]
    b = admin.call("project.register", {"path": str(tmp_path / "b")})["project_id"]
    project_a = service.RemoteKnowledge(home, a)
    project_b = service.RemoteKnowledge(home, b)
    args = {"owner": "project:" + a, "graph": {"elements": {"one": element("A")}, "joins": []}, "source": "test", "layer": "Latent"}
    first = project_a.call("graph.put", args, request_id="same-id")
    service.stop_service(home)
    assert project_a.call("graph.put", args, request_id="same-id") == first
    with pytest.raises(Exception) as failure:
        project_a.call("graph.put", {**args, "source": "different"}, request_id="same-id")
    assert failure.value.code == "request_id_conflict"
    project_b.call("graph.put", {**args, "owner": "project:" + b, "graph": {"elements": {"one": element("B")}, "joins": []}}, request_id="same-id")
    assert project_a.call("graph.get", {"owner": "project:" + a, "id": "one"}) != project_b.call("graph.get", {"owner": "project:" + b, "id": "one"})
    with pytest.raises(Exception) as failure:
        service.RemoteKnowledge(home, "unknown").call("graph.get", {"owner": "unknown", "id": "one"})
    assert failure.value.code == "unknown_project"


def test_starter_death_releases_start_lock(home):
    directory = home / "service"
    directory.mkdir(parents=True)
    process = child(
        "import sys,time; from pathlib import Path; from filelock import FileLock; "
        "lock=FileLock(Path(sys.argv[1])/'start.lock'); lock.acquire(); "
        "Path(sys.argv[1],'starter-locked').touch(); time.sleep(60)", directory
    )
    try:
        wait_file(directory / "starter-locked", process)
    finally:
        process.terminate()
        process.wait(timeout=5)
    assert service_module().ensure_service(home)["pid"] != process.pid


def initializing_child(home):
    directory = home / "service"
    directory.mkdir(parents=True)
    process = child("""
import sys, time
from pathlib import Path
import metaform.knowledge as knowledge
from metaform.service import serve
original = knowledge.KnowledgeStore.__init__
def delayed(self, *args, **kwargs):
    directory = Path(sys.argv[1]) / 'service'
    (directory / 'initializing').touch()
    while not (directory / 'allow-ready').exists():
        time.sleep(0.02)
    original(self, *args, **kwargs)
knowledge.KnowledgeStore.__init__ = delayed
serve(sys.argv[1])
""", home)
    wait_file(directory / "initializing", process)
    return process


def test_starter_dies_before_child_ready_and_later_client_reuses_owner(home):
    owner = initializing_child(home)
    starter = child("import sys; from metaform.service import ensure_service; ensure_service(sys.argv[1])", home)
    try:
        time.sleep(0.1)
        starter.terminate()
        starter.wait(timeout=5)
        (home / "service/allow-ready").touch()
        endpoint = service_module().ensure_service(home)
        assert endpoint["pid"] == owner.pid
    finally:
        if starter.poll() is None:
            starter.terminate()
            starter.wait(timeout=5)
        service_module().stop_service(home)
        if owner.poll() is None:
            owner.terminate()
        owner.wait(timeout=5)


def test_starter_dies_after_child_ready_and_service_survives(home):
    starter = child("""
import sys,time
from pathlib import Path
from metaform.service import ensure_service
endpoint = ensure_service(sys.argv[1])
Path(sys.argv[1], 'starter-ready').write_text(endpoint['instance_id'])
time.sleep(60)
""", home)
    try:
        wait_file(home / "starter-ready", starter)
    finally:
        starter.terminate()
        starter.wait(timeout=5)
    assert service_module().ensure_service(home)["instance_id"] == (home / "starter-ready").read_text()


def test_child_death_during_initialization_allows_fresh_owner(home):
    owner = initializing_child(home)
    try:
        assert not (home / "service/endpoint.json").exists()
    finally:
        owner.terminate()
        owner.wait(timeout=5)
    assert service_module().ensure_service(home)["pid"] != owner.pid


def test_dropped_connection_after_real_commit_retries_original_receipt(home, tmp_path):
    process = child("""
import socket,sys
from pathlib import Path
from metaform.service import KnowledgeHandler, serve
original = KnowledgeHandler._reply
def drop_once(self, status, value):
    marker = Path(sys.argv[1]) / 'dropped-response'
    if value.get('request_id') == 'drop-after-commit' and status == 200 and not marker.exists():
        marker.touch()
        self.connection.shutdown(socket.SHUT_RDWR)
        self.connection.close()
        return
    original(self, status, value)
KnowledgeHandler._reply = drop_once
serve(sys.argv[1])
""", home)
    try:
        wait_file(home / "service/endpoint.json", process)
        service = service_module()
        remote = service.RemoteKnowledge(home, None)
        project = remote.call("project.register", {"path": str(tmp_path / "a")})["project_id"]
        remote = service.RemoteKnowledge(home, project)
        arguments = {"graph": {"elements": {"committed": element("retained")}}}
        result = remote.call("graph.put", arguments, request_id="drop-after-commit")
        revision = remote.revision
        assert (home / "dropped-response").exists()
        assert remote.call("graph.put", arguments, request_id="drop-after-commit") == result
        assert remote.revision == revision
        assert remote.call("graph.get", {"id": "committed"}) == element("retained")
    finally:
        service_module().stop_service(home)
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)


def test_wrong_credential_cannot_replace_live_owner(home):
    service = service_module()
    first = service.ensure_service(home)
    path = home / "service/token"
    token = path.read_text()
    try:
        path.write_text("wrong-credential")
        assert service.service_status(home)["ready"] is True
        with pytest.raises(Exception) as failure:
            service.ensure_service(home, timeout=0.2)
        assert failure.value.code == "service_unavailable"
    finally:
        path.write_text(token)
    assert service.ensure_service(home) == first


def test_stop_drains_already_accepted_mutation(home, tmp_path):
    import concurrent.futures
    process = child("""
import sys,time
from pathlib import Path
import metaform.service as service
original = service.dispatch_operation
root = Path(sys.argv[1])
def delayed(store, envelope):
    if envelope['request_id'] == 'accepted-mutation':
        (root / 'operation-accepted').touch()
        while not (root / 'finish-operation').exists():
            time.sleep(0.02)
    return original(store, envelope)
service.dispatch_operation = delayed
service.serve(root)
""", home)
    try:
        wait_file(home / "service/endpoint.json", process)
        service = service_module()
        admin = service.RemoteKnowledge(home, None)
        project = admin.call("project.register", {"path": str(tmp_path / "a")})["project_id"]
        remote = service.RemoteKnowledge(home, project)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            mutation = executor.submit(remote.call, "graph.put", {"graph": {"elements": {"saved": element("saved")}}}, "accepted-mutation")
            wait_file(home / "operation-accepted", process)
            stopped = executor.submit(service.stop_service, home)
            time.sleep(2.2)
            assert not stopped.done()
            (home / "finish-operation").touch()
            assert mutation.result(timeout=5)["elements"] == 1
            assert stopped.result(timeout=5)["stopped"] is True
        assert remote.call("graph.get", {"id": "saved"}) == element("saved")
    finally:
        (home / "finish-operation").touch()
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)


@pytest.mark.parametrize('transport', ['installed', 'portable'])
def test_interrupting_mcp_client_preserves_accepted_service_mutation(home, tmp_path, transport):
    import selectors
    import signal
    from metaform.app import App

    write_json(home / 'config.json', {'auto_build': False})
    owner = child("""
import sys,time
from pathlib import Path
import metaform.service as service
original = service.dispatch_operation
root = Path(sys.argv[1])
def delayed(store, envelope):
    if envelope['request_id'] == 'interrupted-client' and not (root / 'operation-finished').exists():
        (root / 'operation-accepted').touch()
        while not (root / 'finish-operation').exists():
            time.sleep(0.02)
    result = original(store, envelope)
    if envelope['request_id'] == 'interrupted-client':
        (root / 'operation-finished').touch()
    return result
service.dispatch_operation = delayed
service.serve(root)
""", home)
    client = None
    try:
        wait_file(home / 'service/endpoint.json', owner)
        app = App(tmp_path / 'project', home, binding=False)
        arguments = {'graph': {'elements': {'saved': element('saved')}}}
        module = app.project / '.metaform/modules/remote'
        write_json(module / 'module.json', {'id': 'remote', 'commands': [{
            'name': 'write', 'handler': 'worker.py:write', 'inputSchema': {'type': 'object', 'properties': {}}}]})
        (module / 'worker.py').write_text(
            'from pathlib import Path\nfrom metaform.service import RemoteKnowledge\ndef write(app, args, context):\n'
            '    try:\n'
            f"        return RemoteKnowledge({str(home)!r}, {app.project_id!r}).call('graph.put', {arguments!r}, request_id='interrupted-client')\n"
            "    finally:\n        Path(__file__).with_name('unwound').touch()\n")
        script = 'import metaform.mcp_server as server; ' + ('server.types=None; ' if transport == 'portable' else '') + 'raise SystemExit(server.main())'
        client = subprocess.Popen([sys.executable, '-c', script], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, cwd=app.project,
            env={**os.environ, 'METAFORM_HOME': str(home), 'METAFORM_PROJECT': str(app.project)})
        client.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
            'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'disconnect', 'version': '1'}}}) + '\n')
        client.stdin.flush()
        with selectors.DefaultSelector() as selector:
            selector.register(client.stdout, selectors.EVENT_READ)
            assert selector.select(timeout=10)
        assert json.loads(client.stdout.readline())['id'] == 1
        client.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'}) + '\n')
        client.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'remote.write'}}) + '\n')
        client.stdin.flush()
        wait_file(home / 'operation-accepted', client)
        client.send_signal(signal.SIGINT)
        assert client.wait(timeout=3) == 130
        assert 'Traceback' not in client.stderr.read()
        assert (module / 'unwound').exists()
        assert owner.poll() is None
        app.knowledge.call('graph.put', {'graph': {'elements': {'other': element('other')}}})
        (home / 'finish-operation').touch()
        wait_file(home / 'operation-finished', owner)
        assert app.knowledge.call('graph.get', {'id': 'saved'}) == element('saved')
        revision = app.knowledge.revision
        assert app.knowledge.call('graph.put', arguments, request_id='interrupted-client')['elements'] == 1
        assert app.knowledge.revision == revision
    finally:
        (home / 'finish-operation').touch()
        if client is not None:
            if client.poll() is None:
                client.kill()
            client.communicate(timeout=5)
        service_module().stop_service(home, timeout=5)
        if owner.poll() is None:
            owner.terminate()
        _, errors = owner.communicate(timeout=5)
        assert b'Traceback' not in errors, errors.decode()


def test_remote_graph_round_trips_unicode_prompt(home, tmp_path):
    service = service_module()
    admin = service.RemoteKnowledge(home, None)
    identifier = admin.call("project.register", {"path": str(tmp_path / "日本語-project")})["project_id"]
    remote = service.RemoteKnowledge(home, identifier)
    record = element("Native expert → café 日本語 🧭")
    remote.call("graph.put", {"graph": {"elements": {"prompt": record}}})
    assert remote.call("graph.get", {"id": "prompt"}) == record


@pytest.mark.parametrize("partial_body", [False, True])
def test_idle_or_incomplete_request_cannot_hold_owner_during_stop(home, partial_body):
    import socket
    service = service_module()
    process = child("import sys; from metaform.service import serve; serve(sys.argv[1])", home)
    connection = None
    try:
        wait_file(home / "service/endpoint.json", process)
        first = service.ensure_service(home)
        connection = socket.create_connection((first["host"], first["port"]))
        if partial_body:
            token = (home / "service/token").read_text().strip()
            connection.sendall(("POST /v1/operations HTTP/1.0\r\n"
                                f"Authorization: Bearer {token}\r\n"
                                "Content-Length: 1000\r\n\r\n{").encode())
        time.sleep(0.1)
        assert service.stop_service(home, timeout=4)["stopped"] is True
        process.wait(timeout=2)
        assert service.ensure_service(home)["instance_id"] != first["instance_id"]
    finally:
        if connection is not None:
            connection.close()
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)


def test_restart_repairs_token_left_empty_by_interrupted_creation(home):
    directory = home / "service"
    directory.mkdir(parents=True)
    creator = child("""
import os,sys,time
from pathlib import Path
from filelock import FileLock
root = Path(sys.argv[1])
with FileLock(root / 'instance.lock'):
    descriptor = os.open(root / 'token', os.O_CREAT | os.O_WRONLY, 0o600)
    (root / 'token-created').touch()
    time.sleep(60)
""", directory)
    try:
        wait_file(directory / "token-created", creator)
    finally:
        creator.terminate()
        creator.wait(timeout=5)
    assert (directory / "token").read_text() == ""
    service = service_module()
    service.ensure_service(home)
    token = (directory / "token").read_text().strip()
    assert len(token) >= 32
    assert (directory / "token").stat().st_mode & 0o077 == 0
    service.stop_service(home)
    service.ensure_service(home)
    assert (directory / "token").read_text().strip() == token


def test_request_at_explicit_restart_boundary_retries_original_receipt(home, tmp_path, monkeypatch):
    service = service_module()
    process = child('import sys; from metaform.service import serve; serve(sys.argv[1])', home)
    try:
        wait_file(home / 'service/endpoint.json', process)
        remote = service.RemoteKnowledge(home, None)
        registered = remote.call('project.register', {'path': str(tmp_path / 'project')})
        original = service._request
        delayed = False

        def cross_restart_boundary(endpoint, token, method, path, body=None, timeout=2):
            nonlocal delayed
            if path == '/v1/operations' and not delayed:
                delayed = True
                service.restart_service(home)
                assert process.wait(timeout=4) == 0
            return original(endpoint, token, method, path, body, timeout)

        monkeypatch.setattr(service, '_request', cross_restart_boundary)
        selected = service.RemoteKnowledge(home, registered['project_id'])
        assert selected.call('graph.put', {'graph': {'elements': {'saved': element('saved once')}}}, 'restart-race')['elements'] == 1
        revision = selected.revision
        selected.call('graph.put', {'graph': {'elements': {'saved': element('saved once')}}}, 'restart-race')
        assert selected.revision == revision
        assert selected.call('graph.get', {'id': 'saved'}) == element('saved once')
    finally:
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)
