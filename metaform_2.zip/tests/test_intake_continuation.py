"""Historical v1 assignment contracts remain resumable after the v2 transition."""
import copy
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from metaform.app import App
from metaform.continuation import current
from metaform.intake import Intake


def test_concurrent_requests_reuse_one_pending_latent_assignment(app):
    job = Intake(app)._start("archaeology")

    def obtain(_):
        return Intake(App(app.project, app.home)).batch(job["run_id"], limit=4)

    with ThreadPoolExecutor(max_workers=3) as pool:
        batches = list(pool.map(obtain, range(3)))
    assert batches == [[job], [job], [job]]


@pytest.mark.parametrize("terminal", ["complete", "aborted"])
def test_terminal_intake_does_not_resume_completed_bound_assignment(app, terminal):
    engine = Intake(app)
    job = engine._start("archaeology")
    bound = copy.copy(app)
    bound.binding = {"module": "intake", "run_id": job["run_id"], "request_id": job["request_id"]}
    assert current(bound) == job
    if terminal == "complete":
        receipt = engine.submit(job["run_id"], job["request_id"], {"elements": {}, "joins": []})
        assert engine.submit(job["run_id"], job["request_id"], {"elements": {}, "joins": []}) == receipt
    else:
        app.abort()
    result = engine.next(job["run_id"])
    assert result["status"] == terminal
    assert not Path(job["workfolder"]).exists()
    if terminal == "complete":
        later = engine.start()
        assert current(bound) == result
        assert engine.next(job["run_id"], request_id=job["request_id"]) == result
        assert engine.next(later["run_id"]) == later
    else:
        with pytest.raises(ValueError, match="not pending"):
            current(bound)
        with pytest.raises(ValueError, match="not pending"):
            engine.next(job["run_id"], request_id=job["request_id"])
