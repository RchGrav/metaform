import asyncio
import json
import os
import subprocess
import sys

import pytest

from metaform.registry import Registry
from metaform.util import read_json, write_json


def cli(project, home, *args):
    return subprocess.run([sys.executable, '-m', 'metaform', '--project', str(project), *args],
                          cwd=project, env={**os.environ, 'METAFORM_HOME': str(home)}, capture_output=True, text=True)


@pytest.mark.parametrize('arguments', [('--help',), ('workflow', '--help'), ('workflow', 'start', '--help'), ('install', '--help'), ('system', 'reference')])
def test_reference_does_not_initialize_a_project_or_home(tmp_path, arguments):
    project = tmp_path / 'project'
    project.mkdir()
    result = cli(project, tmp_path / 'home', *arguments)
    assert result.returncode == 0, result.stderr
    assert not list(project.iterdir())
    assert not (tmp_path / 'home').exists()
    assert result.stdout.strip()


def test_initial_launch_teaches_starting_without_creating_an_accidental_project(tmp_path):
    project = tmp_path / 'project'
    project.mkdir()
    result = cli(project, tmp_path / 'home')
    assert result.returncode == 0, result.stderr
    assert 'Metaform' in result.stdout and 'guide start' in result.stdout
    assert 'install' in result.stdout and 'workflow' in result.stdout
    assert not list(project.iterdir())


def test_global_service_lifecycle_commands_do_not_initialize_a_project(tmp_path):
    project, home = tmp_path / 'project', tmp_path / 'home'
    project.mkdir()
    states = []
    for command in ('status', 'start', 'status', 'restart', 'stop', 'status'):
        result = cli(project, home, 'service', command)
        assert result.returncode == 0, result.stderr
        states.append(json.loads(result.stdout))
        assert not list(project.iterdir())
        assert not home.exists()
    assert states[0]['ready'] is False
    assert states[1]['instance_id'] == states[2]['instance_id']
    assert states[3]['instance_id'] != states[1]['instance_id']
    assert states[3]['port'] == states[1]['port']
    assert states[4]['stopped'] is True
    assert states[5]['ready'] is False


def test_configuration_write_preserves_scope_and_refreshes_active_app(app):
    write_json(app.root / 'config.json', {'sampling_max_tokens': 123, 'custom_project': 'private'})
    app.refresh_config()
    result = asyncio.run(Registry(app).call('system.configure', {'settings': {'debug': True}}))
    stored = read_json(app.home / 'config.json')
    assert 'custom_project' not in stored
    assert stored.get('sampling_max_tokens') != 123
    assert app.debug is True and app.config['debug'] is True
    assert app.config['sampling_max_tokens'] == 123
    assert result['scope'] == 'home'
    result = asyncio.run(Registry(app).call('system.configure', {'scope': 'project', 'settings': {'custom_project': 'changed'}}))
    assert app.config['custom_project'] == 'changed'
    assert result['effective']['custom_project']['source'] == 'project'


def test_module_removal_removes_startup_guidance_and_feature_alias(app, monkeypatch):
    from metaform.onboarding import guide_state, skill_text
    original = Registry.discover
    monkeypatch.setattr(Registry, 'discover', lambda self: {key: value for key, value in original(self).items()
                                                          if value.module not in {'intake', 'knowledge', 'web'}})
    (app.project / 'artifact.txt').write_text('A maintenance manual.')
    text = skill_text(app)
    assert 'intake.start' not in text and 'knowledge.start' not in text and 'web.start' not in text
    assert 'q1_array' not in text
    state = guide_state(app)
    assert state['next'] is None or state['next']['command'] in Registry(app).visible()
    from metaform.cli import run_parser
    with pytest.raises(SystemExit):
        run_parser(Registry(app), ['browse'])


def test_help_and_typed_commands_work_inside_active_modes(app):
    from metaform.workflow import Engine
    from metaform.modules.workflow import import_workflow
    import_workflow(app, {'id': 'help-flow', 'steps': [{'id': 'work', 'prompt': 'Read this task.'}]})
    job = Engine(app).start('help-flow')
    help_result = cli(app.project, app.home, 'workflow', 'start', '--help')
    assert help_result.returncode == 0, help_result.stderr
    assert '--id' in help_result.stdout
    command = cli(app.project, app.home, 'workflow', 'next', '--run-id', job['run_id'])
    assert command.returncode == 0, command.stderr
    assert json.loads(command.stdout)['request_id'] == job['request_id']
    invalid = cli(app.project, app.home, 'workflow', 'next', '--unknown')
    assert invalid.returncode != 0 and 'unrecognized arguments' in invalid.stderr


def test_configuration_nested_updates_preserve_siblings_and_apply_scope_precedence(app):
    write_json(app.home / 'config.json', {'knowledge_mode': 'legacy', 'harnesses': {
        'alpha': {'command': ['alpha'], 'timeout': 10}, 'beta': {'command': ['beta']}}})
    write_json(app.root / 'config.json', {'harnesses': {'alpha': {'timeout': 20}}})
    app.refresh_config()
    result = asyncio.run(Registry(app).call('system.configure', {'settings': {'harnesses': {'alpha': {'timeout': 30}}}}))
    stored = read_json(app.home / 'config.json')['harnesses']
    assert stored['beta'] == {'command': ['beta']}
    assert stored['alpha'] == {'command': ['alpha'], 'timeout': 30}
    assert app.config['harnesses']['alpha'] == {'command': ['alpha'], 'timeout': 20}
    assert result['effective']['harnesses']['value']['beta'] == {'command': ['beta']}
    assert result['effective']['harnesses']['sources']['alpha']['timeout'] == 'project'
    assert result['effective']['harnesses']['sources']['beta']['command'] == 'home'


def test_reference_module_option_is_passed_to_owning_command(app):
    result = cli(app.project, app.home, 'system', 'reference', '--module', 'workflow')
    assert result.returncode == 0, result.stderr
    assert [item['id'] for item in json.loads(result.stdout)['modules']] == ['workflow']


def test_help_remains_available_with_broken_configuration_and_preserves_existing_state(app):
    before = {path.name: path.read_bytes() for path in app.root.iterdir() if path.is_file()}
    result = cli(app.project, app.home, '--help')
    assert result.returncode == 0, result.stderr
    assert {path.name: path.read_bytes() for path in app.root.iterdir() if path.is_file()} == before
    (app.home / 'config.json').write_text('{unfinished')
    broken = cli(app.project, app.home, 'system', '--help')
    assert broken.returncode == 0
    assert str(app.home / 'config.json') in broken.stderr
    assert 'configure' in broken.stdout


def test_the_bare_module_word_runs_the_module_default_command(app):
    from metaform.cli import run_parser
    parsed = run_parser(Registry(app), ['web'], parse_only=True)
    assert parsed['_cli_command_key'] == 'web.start'


def test_configuration_distinguishes_open_graph_backend_from_next_open_setting(app):
    original = app.graph
    result = asyncio.run(Registry(app).call('system.configure', {'settings': {'graph_backend': 'json'}}))
    assert app.graph is original
    assert result['active']['graph_backend'] == 'sqlite'
    assert result['effective']['graph_backend']['value'] == 'json'
    assert result['pending']['graph_backend'] == {'configured': 'json', 'active': 'sqlite'}


@pytest.mark.parametrize('body,field', [('{unfinished', 'JSON'), ('[]', 'object'),
    ('{"id":"broken","commands":[{"name":"run"}]}', 'handler'),
    *[(json.dumps({'id': 'broken', 'commands': [{'name': 'run', 'handler': 'missing.py:run', **entry}]}), field)
      for entry, field in [({'inputSchema': {'properties': []}}, 'properties'),
                           ({'inputSchema': {'properties': {'count': 3}}}, 'count'),
                           ({'inputSchema': {'required': 3}}, 'required'),
                           ({'aliases': 3}, 'aliases'), ({'aliases': [{}]}, 'aliases'),
                           ({'aliases': ['mcp']}, 'aliases')]],
    (json.dumps({'id': 'broken', 'commands': [{'name': 'run', 'handler': 'missing.py:run'}],
                 'settings': {'feature': {'description': [], 'default': True}}}), 'description')])
def test_broken_module_preserves_reference_with_owning_path(tmp_path, body, field):
    project, home = tmp_path / 'project', tmp_path / 'home'
    project.mkdir()
    path = home / 'modules' / 'broken' / 'module.json'
    path.parent.mkdir(parents=True)
    path.write_text(body)
    before = {str(item.relative_to(tmp_path)): item.read_bytes() for item in tmp_path.rglob('*') if item.is_file()}
    for arguments in [('--help',), ('install', '--help'), ('workflow', '--help'), ('system', 'reference')]:
        result = cli(project, home, *arguments)
        assert result.returncode == 0, result.stderr
        assert str(path) in result.stderr and field in result.stderr
        assert result.stdout.strip()
    assert str(path) in '\n'.join(json.loads(result.stdout)['diagnostics'])
    assert {str(item.relative_to(tmp_path)): item.read_bytes() for item in tmp_path.rglob('*') if item.is_file()} == before
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    active = cli(project, home, 'system', 'status')
    assert active.returncode == 0, active.stderr
    assert str(path) in active.stderr


def test_advertised_begin_in_actor_context_replays_only_its_bound_assignment(app, tmp_path):
    import shlex
    from metaform.actor import gateway
    from metaform.continuation import begin, pending_assignment
    from metaform.workflow import Engine, import_workflow

    import_workflow(app, {'id': 'actor-begin', 'steps': [{'id': 'work', 'prompt': 'The exact stored assignment.'}]})
    first = Engine(app).start('actor-begin', exclusive=False)
    sibling = Engine(app).start('actor-begin', exclusive=False)
    worker = tmp_path / 'worker'
    begin(first['nonce'], worker, app.home)
    from metaform import bindings
    original = bindings.lookup(worker)
    with gateway(app, first) as scope:
        environment = {**os.environ, **scope, 'PYTHONPATH': ''}
        command = shlex.split(first['begin'])
        repeated = subprocess.run(command, cwd=worker, env=environment, capture_output=True, text=True)
        assert repeated.returncode == 0, repeated.stderr
        assert json.loads(repeated.stdout) == pending_assignment(app, first['run_id'], first['request_id'])
        conflicting = subprocess.run([*command[:-1], sibling['nonce']], cwd=worker, env=environment, capture_output=True, text=True)
        assert conflicting.returncode != 0
        assert 'nonce' in conflicting.stderr.lower()
    assert bindings.lookup(worker) == original
    assert pending_assignment(app, sibling['run_id'], sibling['request_id'])['nonce'] == sibling['nonce']


def test_guide_preserves_selected_failed_run_result_without_restart(app):
    from metaform.onboarding import guide_state
    from metaform.workflow import Engine, import_workflow

    import_workflow(app, {'id': 'failed-guide', 'steps': [{'id': 'work', 'prompt': 'Work'}]})
    engine = Engine(app)
    job = engine.start('failed-guide')
    failed = engine.fail(job['run_id'], {'kind': 'worker_failure', 'message': 'Worker process exited.', 'attempts': 2})
    app.enter('workflow', job['run_id'])
    state = guide_state(app)
    assert state['status'] == 'failed'
    assert state['result'] == failed['result']
    assert state['next'] is None
    assert app.load_run(job['run_id'])['status'] == 'failed'


def test_backend_migration_does_not_pin_inherited_settings_to_project(app):
    home = read_json(app.home / 'config.json')
    home.update(harnesses={'home-worker': {'command': ['before']}}, modules={'custom': {'option': 'before'}})
    write_json(app.home / 'config.json', home)
    write_json(app.root / 'config.json', {'retained': 'project value'})
    app.refresh_config()
    app.graph.put({'elements': {'document.migration': {'entity_schema': 'metaform:element',
        'entity_desc': 'Retained authored description', 'entity_json_obj': {'ef': 'Records the migration example.'}}}}, 'native')
    before = app.graph.export()
    migrated = asyncio.run(Registry(app).call('graph.backend', {'name': 'json'}))
    assert migrated['backend'] == 'json'
    assert app.graph.export() == before
    assert read_json(app.root / 'config.json') == {'retained': 'project value', 'graph_backend': 'json'}
    assert app.configuration()['effective']['graph_backend']['source'] == 'project'
    asyncio.run(Registry(app).call('system.configure', {'settings': {
        'harnesses': {'home-worker': {'command': ['after']}}, 'modules': {'custom': {'option': 'after'}}}}))
    assert app.config['harnesses']['home-worker']['command'] == ['after']
    assert app.config['modules']['custom']['option'] == 'after'
    assert app.config['retained'] == 'project value'


def test_the_bare_module_word_prints_what_its_default_command_returns(app, capsys, monkeypatch):
    """metaform web must say where the page is: the bare word runs the default command and prints its result,
    the URL with its port in the human form and the whole object in JSON (decided 2026-09-13, seen silent 2026-09-14)."""
    from metaform.util import write_json
    folder = app.root / 'modules' / 'door'
    write_json(folder / 'module.json', {
        'id': 'door', 'name': 'Door', 'description': 'Opens somewhere.', 'default_command': 'open',
        'commands': [{'name': 'open', 'handler': 'handler.py:open', 'always_available': True}]})
    (folder / 'handler.py').write_text('def open(api, args, context):\n    return {"url": "http://127.0.0.1:8642", "instance_id": "x"}\n')
    monkeypatch.setenv('METAFORM_HOME', str(app.home))
    monkeypatch.setenv('METAFORM_PROJECT', str(app.project))
    from metaform import cli as cli_module
    assert cli_module.main(['--human', 'door']) == 0
    out = capsys.readouterr().out
    assert 'http://127.0.0.1:8642' in out.splitlines()
    assert cli_module.main(['door']) == 0
    assert json.loads(capsys.readouterr().out)['url'] == 'http://127.0.0.1:8642'
