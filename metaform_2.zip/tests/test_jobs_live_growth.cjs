// While an intake run is open, the graph advances on each recorded contribution: no reopen, no completion needed.
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');
const assert=require('node:assert/strict');
const {python,outputDirectory}=require('./browser_support.cjs');
(async()=>{
  const out=outputDirectory('jobs-live');
  const server=spawn(python,['tests/jobs_viewer_fixture.py'],{stdio:['ignore','pipe','pipe']});
  let stderr='',browser;server.stderr.on('data',chunk=>stderr+=chunk);
  try{
    const url=await new Promise((resolve,reject)=>{server.stdout.once('data',chunk=>resolve(String(chunk).trim()));server.once('exit',code=>reject(Error('Fixture failed '+code+' '+stderr)));});
    const call=async(command,body)=>{const response=await fetch(url+'/api/call/'+command,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const text=await response.text();assert(response.ok,command+' '+response.status+' '+text);return JSON.parse(text);};
    browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1600,height:1000}});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto(url+'/');await page.waitForFunction(()=>/no foundation/i.test(document.getElementById('graph-title').textContent));
    // An agent starts the intake outside the page, as the CLI or the MCP server would. Nothing drives it from here.
    const started=await call('intake.start',{});const runId=started.run_id;assert(runId,'intake.start returns the run id');
    await page.locator('.side-tabs button[data-side=jobs]').click();
    await page.waitForFunction(id=>document.querySelector(`#job-list li[data-id="${id}"]`),runId);
    await page.locator(`#job-list li[data-id="${runId}"]`).click();
    await page.waitForFunction(()=>/after submission 0 of 0/.test(document.getElementById('graph-title').textContent));
    assert.equal(await page.locator('#cards .card').count(),0);
    // The first recorded contribution: the graph advances while the run stays open.
    await call('intake.put',{run_id:runId,graph:{elements:{'code.loop.clock':{ef:'Shows the current time as a pong rally.'}},joins:[],subtypes:[]}});
    await page.waitForFunction(()=>document.querySelectorAll('#cards .card').length===1,null,{timeout:15000});
    assert.match(await page.locator('#graph-title').textContent(),/after submission 1 of 1/);
    assert.match(await page.locator('#job-title').textContent(),/running/,'The run is still open');
    // The second contribution: it grows again, still without completion and without reopening the job.
    await call('intake.put',{run_id:runId,graph:{elements:{'code.loop.clock.display':{ef:'Draws the digits.'}},joins:[{receiver:'code.loop.clock',provider:'code.loop.clock.display',purpose:'Show the time as digits.'}],subtypes:[]}});
    await page.waitForFunction(()=>document.querySelectorAll('#cards .card').length===2,null,{timeout:15000});
    assert.equal(await page.locator('#edges path.hit').count(),1,'The join between the two contributions is drawn');
    assert.equal(await page.locator('#scrub').getAttribute('max'),'2');
    assert.match(await page.locator('#graph-title').textContent(),/after submission 2 of 2/);
    assert.match(await page.locator('#job-title').textContent(),/running/,'The run is still open');
    await page.screenshot({path:out+'/jobs-live-growth.png'});
    assert.deepEqual(errors,[]);
    console.log('Verified the intake graph advancing on each recorded contribution while the run stayed open.');
  }finally{if(browser)await browser.close();server.kill('SIGTERM');}
})().catch(error=>{console.error(error);process.exit(1);});
