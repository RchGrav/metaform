"""Synthetic semantic interactions supplement the unchanged archived MGM fixture."""
import json
from pathlib import Path
from metaform.models import publish_foundation, capture_model
from metaform.layers import create_layer, associate_destination
from metaform.workflow import Engine


def add_semantic_cases(app):
    owner = 'project:' + app.project_id
    data = json.loads((Path(__file__).parent / 'fixtures/foundation_v2.json').read_text().replace('project:illustrative', owner))
    data['model'].update(project=app.project_id, model='zz-interactions')
    ref = lambda kind, id: {'owner': owner, 'kind': kind, 'id': id}
    for index in range(60):
        identifier = f'provider:{index:02}'
        data['elements'][identifier] = {**data['elements']['demo:engine'], 'id': identifier, 'name': f'Provider {index}', 'summary': 'Synthetic high-degree provider'}
        data['bindings'].append({'id': 'binding:' + identifier, 'owner': owner, 'element': ref('element', identifier), 'type': ref('type', 'code.evaluator.connectivity')})
        data['joins'].append({'id': 'degree:' + identifier, 'owner': owner, 'receiver': data['artifact'], 'provider': ref('element', identifier), 'provider_type': ref('type', 'code.evaluator.connectivity'), 'role': 'supportive', 'purpose': f'Supplement evaluation with observation {index}.'})
    data['joins'].append({'id': 'join:multi', 'owner': owner, 'receiver': ref('element', 'demo:engine'), 'provider': ref('element', 'demo:installer'), 'provider_type': ref('type', 'code.installer'), 'role': 'supportive', 'purpose': 'Coordinate the engine, installer and user at one recorded meeting.', 'participants': [{'role': 'observer', 'ref': ref('element', 'demo:user')}]})
    data['types']['code.cpp']['aliases'] = ['code.oldcpp']
    model = publish_foundation(app, data)
    subject = ref('type', 'code.cpp')
    job = create_layer(app, 'Explain practices that apply through the C++ Type binding.', subject, model)
    def finish(answer):
        nonlocal job
        Engine(app).submit(job['run_id'], job['request_id'], answer)
        job = Engine(app).next(job['run_id'])
    schema = {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:test:browser-practices', 'type': 'string'}
    finish({'name': 'C++ practices', 'description': 'Browser fixture Type knowledge', 'schema_ref': schema['$id'], 'schema': schema, 'selector': {'kind': 'subjects', 'targets': [subject]}, 'groups': [{'subjects': [subject], 'purpose': 'Explain Type practices.'}]})
    finish({'attachments': [{'subject': subject, 'schema_ref': schema['$id'], 'payload': 'Preserve the declared ownership boundary.', 'slot': 'practices', 'applicability': {'scope': {'kind': 'target', 'target': subject}, 'reason': 'Applies through the C++ binding.'}}]})
    from metaform.layers import active_attachments
    attachment = active_attachments(app, model)[0]
    destination = capture_model(app, model)
    destination['model']['model'] = 'zz-stale'
    destination['types']['code.cpp']['ef'] = 'A revised Type function for the browser freshness witness.'
    changed = publish_foundation(app, destination)
    associate_destination(app, model, changed, [{'target': ref('knowledge', attachment['id']), 'layer': attachment['layer'], 'action': 'regenerate', 'reasons': [{'reason': 'Provider Type function changed.'}]}], [])
    history = capture_model(app, model)
    history['model']['model'] = 'zz-revision'
    history['understanding'] = 'Historical artifact understanding.'
    older = publish_foundation(app, history)
    history['artifact'] = ref('element', 'demo:installer')
    history['understanding'] = {'account': 'Current artifact understanding.', 'previous_revision': older['revision']}
    publish_foundation(app, history)
