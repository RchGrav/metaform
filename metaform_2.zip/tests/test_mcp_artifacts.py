"""Binary intake must reach the host and sampled worker as image content."""

import asyncio
import base64
import json
import os
import sys

import pytest
from mcp import Client, types
from mcp.client.stdio import StdioServerParameters

from metaform.util import write_json


PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+X0XcAAAAASUVORK5CYII=')


def server(tmp_path, transport='installed'):
    project, home = tmp_path / 'project', tmp_path / 'home'
    project.mkdir()
    (project / 'photo.png').write_bytes(PNG)
    (project / 'bytes.bin').write_bytes(b'\x00\xffbinary')
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    args = ['-m', 'metaform.mcp_server'] if transport == 'installed' else [
        '-c', 'import metaform.mcp_server as server; server.types = None; server.main()']
    return StdioServerParameters(command=sys.executable, args=args, env={
        'METAFORM_RUNTIME_DIR': os.environ['METAFORM_RUNTIME_DIR'],
        'PYTHONPATH': os.environ.get('PYTHONPATH', ''),
        'METAFORM_PROJECT': str(project), 'METAFORM_HOME': str(home),
    })


async def operation(client, name, arguments=None):
    modern = 'metaform' in {tool.name for tool in (await client.list_tools()).tools}
    result = await client.call_tool('metaform' if modern else name,
                                   {'command': name, 'arguments': arguments or {}} if modern else arguments or {})
    assert not result.is_error, result
    return result


@pytest.mark.parametrize('transport', ['installed', 'portable'])
def test_intake_image_reaches_stdio_host_without_losing_binary_results(tmp_path, transport):
    async def scenario():
        async with Client(server(tmp_path, transport), mode='legacy') as client:
            await operation(client, 'intake.start')
            result = await operation(client, 'intake.read', {'path': 'photo.png', 'description': 'Captured image'})
            images = [block for block in result.content if isinstance(block, types.ImageContent)]
            assert len(images) == 1
            assert images[0].mime_type == 'image/png'
            assert base64.b64decode(images[0].data) == PNG
            metadata = json.loads(next(block.text for block in result.content if isinstance(block, types.TextContent)))
            assert metadata['description'] == 'Captured image'
            assert metadata['dimensions'] == {'width': 1, 'height': 1}
            assert 'data' not in metadata
            assert base64.b64decode(result.structured_content['data']) == PNG
            binary = await operation(client, 'intake.read', {'path': 'bytes.bin'})
            assert all(isinstance(block, types.TextContent) for block in binary.content)
            assert json.loads(binary.content[0].text) == binary.structured_content
            assert base64.b64decode(binary.structured_content['data']) == b'\x00\xffbinary'

    asyncio.run(scenario())


@pytest.mark.parametrize('mode', ['legacy', 'auto'])
def test_native_sampling_receives_actual_image_content(tmp_path, mode):
    async def scenario():
        seen = []

        async def sample(context, params):
            if len(params.messages) == 1:
                return types.CreateMessageResultWithTools(role='assistant', model='fixture', stop_reason='toolUse', content=[
                    types.ToolUseContent(name='intake.read', id='read-image', input={'path': 'photo.png'})])
            tool_result = params.messages[-1].content[0]
            image = next(block for block in tool_result.content if isinstance(block, types.ImageContent))
            seen.append(base64.b64decode(image.data))
            return types.CreateMessageResultWithTools(role='assistant', model='fixture', stop_reason='endTurn', content=[
                types.TextContent(type='text', text='{}')])

        async with Client(server(tmp_path), mode=mode, sampling_callback=sample,
                          sampling_capabilities=types.SamplingCapability(tools=types.SamplingToolsCapability())) as client:
            await operation(client, 'intake.start')
            result = await operation(client, 'intake.drive')
            assert result.structured_content['recorded']
        assert seen == [PNG]

    asyncio.run(scenario())
