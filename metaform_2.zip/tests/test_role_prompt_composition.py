import copy
import importlib.resources

import pytest

from metaform import prompts, schemas
from metaform.app import App
from metaform.util import digest


@pytest.mark.parametrize('role', ['intake', 'expand', 'blindspots', 'layer-design', 'layer-generate', 'reinfer', 'ground-and-specialize'])
def test_role_carries_exact_task_components_schema_and_independent_input_snapshot(app, role):
    inputs = {'request': 'Literal {{ request }}', 'context': {'facts': ['one']}}
    job = prompts.compose_role(app, role, inputs)
    original = copy.deepcopy(job)
    inputs['context']['facts'].append('later')
    root = importlib.resources.files('metaform') / 'data' / 'roles'
    spec = prompts.role_definitions()['roles'][role]
    assert job['source_prompt'] == (root / spec['prompt']).read_text()
    assert job['prompt_revision'] == digest(job['source_prompt'])
    assert [c['id'] for c in job['components']] == spec['components']
    for component in job['components']:
        assert component['text'] == (root / component['id']).read_text()
        assert component['revision'] == digest(component['text'])
    assert job['prompt'] == '\n\n'.join([job['source_prompt'], *(c['text'] for c in job['components'])])
    assert job['schema_ref'] == spec['output_schema']
    assert job['provenance']['composition_status'] == 'managed'
    assert job['provenance']['differences'] == []
    assert job['output_schema'] == schemas.registry(app)[spec['output_schema'].split('#')[0]]
    assert job == original
    assert '<MetaformFoundation>' not in job['prompt']
    assert 'Two complete graphs' not in job['prompt']


def test_report_role_has_attachment_context_and_intake_keeps_naming_mechanism(app):
    report = prompts.compose_role(app, 'blindspots', {})
    intake = prompts.compose_role(app, 'intake', {})
    assert [c['id'] for c in report['components']] == ['components/attachment-semantics.md']
    assert 'provider_type' not in report['schema'].get('properties', {})
    assert intake['components'] == []
    assert intake['prompt'] == intake['source_prompt']
    assert 'It is the only element in the graph which can speak directly to the artifact' in intake['prompt']
    assert 'Find each notable element as a requirement.' in intake['prompt']
    assert app.graph.get('prompt:metaform.intake.proof') is None


def test_custom_literal_task_and_configured_aliases_survive_reopen(app, tmp_path):
    source = '{{ x }}\n{% if example %}literal{% endif %}\n'
    authored = dict(prompts.get(app, 'prompt:metaform.intake.native'), text=source, rule_codes=[], components=['components/aliases.md'])
    prompts.put(app, authored)
    alias = tmp_path / 'aliases.md'
    alias.write_text('Exact configured alias source.\n')
    reopened = App(app.project, app.home)
    reopened.config.setdefault('semantic_sources', {})['aliases'] = str(alias)
    job = prompts.compose_role(reopened, 'intake', {})
    assert job['source_prompt'] == source
    assert job['prompt'].startswith(source + '\n\n')
    assert job['components'][-1]['text'] == alias.read_text()
    assert job['components'][-1]['source'] == str(alias)
    assert job['provenance']['authored_override'] is True
    assert {item['field'] for item in job['provenance']['differences']} == {'text', 'components', 'rule_codes'}
    assert job['rules'] == []
    assert job['rules'] == []


def test_authored_component_and_output_schema_selection_survives_managed_refresh(app):
    identifier = 'prompt:metaform.intake.native'
    authored = dict(prompts.get(app, identifier), components=['components/structural-semantics.md'],
                    rule_codes=list(prompts.INTAKE_RULE_CODES), schema={'type': 'object', 'properties': {'custom': {'type': 'string'}}})
    prompts.put(app, authored)
    reopened = App(app.project, app.home)
    job = prompts.compose_role(reopened, 'intake', {})
    assert [c['id'] for c in job['components']] == authored['components']
    assert job['schema'] == authored['schema']
    assert job['provenance']['composition_status'] == 'authored_override'
    assert {item['field'] for item in job['provenance']['differences']} == {'schema', 'components', 'rule_codes'}
    assert [rule['content']['rule_code'] for rule in job['rules']] == authored['rule_codes']
    assert [rule['content']['rule_code'] for rule in job['rules']] == authored['rule_codes']


def test_inference_projection_sends_selected_text_once_and_preserves_full_assignment(app):
    job = prompts.compose_role(app, 'intake', {})
    snapshot = copy.deepcopy(job)
    payload = prompts.inference_payload(job)
    assert payload['prompt'] == job['prompt']
    assert 'source_prompt' not in payload
    assert 'output_schema' not in payload
    assert all('text' not in component for component in payload['components'])
    assert payload['schema'] == job['schema']
    assert job == snapshot


def test_knowledge_inference_keeps_semantic_records_without_repeated_proof_routes(app):
    from test_enumerator import composite_fixture
    from metaform.knowledge_tool import start
    from metaform.models import publish_foundation
    from metaform.namespace import index_records, key

    document = composite_fixture()
    document['model'] = {'project': app.project_id, 'model': 'transport'}
    document['joins'][0]['signal'] = 'The installed shell executes this component.'
    document['joins'][0]['scope'] = {'source': 'installer.sh', 'extent': 'The installer only.'}
    model = publish_foundation(app, document)
    job = start(app, 'Consider {{ literal }} implications.', 'Implications', model)
    original = copy.deepcopy(job)
    payload = prompts.inference_payload(job)
    account = payload['inputs']['functional_account']
    index = index_records(account)
    proofs = 0
    for field, context in job['inputs']['contexts'].items():
        delivered = payload['inputs']['contexts'][field]
        assert {k: v for k, v in delivered.items() if k != 'property_context'} == {
            k: v for k, v in context.items() if k != 'property_context'}
        assert len(context['property_context']) == len(delivered['property_context'])
        for recorded, sent in zip(context['property_context'], delivered['property_context']):
            assert sent == {k: v for k, v in recorded.items() if k not in {'path', 'visibility_path'}}
            for route in ('path', 'visibility_path'):
                for step in recorded[route]:
                    proofs += 1
                    relation = index[key(step['relation'])]
                    for name in ('signal', 'purpose', 'scope', 'classification', 'is_soft', 'realization', 'category'):
                        if name in step:
                            assert relation[name] == step[name]
                    if 'ef' in step:
                        assert index[key(step['provider_type'])]['ef'] == step['ef']
    assert proofs
    assert account == job['inputs']['functional_account']
    assert payload['inputs']['questions'] == job['inputs']['questions']
    assert payload['schema'] == job['schema']
    assert payload['prompt'] == job['prompt']
    assert job == original
    assert app.load_run(job['run_id'])['pending']['inputs'] == original['inputs']
    unrelated = copy.deepcopy(job)
    unrelated['role'] = 'layer-generate'
    assert prompts.inference_payload(unrelated)['inputs'] == unrelated['inputs']


def test_old_graph_override_exposes_exact_composition_differences_without_rewriting(app):
    from metaform.modules import prompt

    identifier = prompts.role_prompt_id('blindspots')
    issued = prompts.compose_role(app, 'blindspots', {})
    issued_snapshot = copy.deepcopy(issued)
    authored = dict(prompts.get(app, identifier),
                    text='Produce a second complete graph with Elements and joins.\n',
                    schema={'type': 'object', 'properties': {'elements': {'type': 'object'}, 'joins': {'type': 'array'}}},
                    components=['components/structural-semantics.md'])
    prompts.put(app, authored)
    reopened = App(app.project, app.home)
    job = prompts.compose_role(reopened, 'blindspots', {})
    report = job['provenance']
    assert report['composition_status'] == 'authored_override'
    differences = {item['field']: item for item in report['differences']}
    assert set(differences) == {'text', 'schema', 'components'}
    assert '+Produce a second complete graph with Elements and joins.' in differences['text']['diff']
    assert 'blindspot-report:2' in differences['schema']['diff']
    assert '"elements"' in differences['schema']['diff']
    assert 'structural-semantics.md' in differences['components']['diff']
    assert 'attachment-semantics.md' in differences['components']['diff']
    assert prompt.prepare(reopened, {'id': identifier}, None)['provenance'] == report
    assert job['source_prompt'] == authored['text']
    assert job['schema'] == authored['schema']
    assert prompts.get(reopened, identifier)['text'] == authored['text']
    assert issued == issued_snapshot
    assert 'differences' not in prompts.inference_payload(job)['provenance']


def test_matching_authored_prompt_keeps_its_unmanaged_origin(app):
    identifier = prompts.role_prompt_id('blindspots')
    authored = copy.deepcopy(prompts.get(app, identifier))
    authored.pop('managed')
    prompts.put(app, authored)
    provenance = prompts.compose_role(app, 'blindspots', {})['provenance']
    assert provenance['composition_status'] == 'matches_managed_template'
    assert provenance['managed'] is None
    assert provenance['differences'] == []
