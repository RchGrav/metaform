import asyncio
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

from metaform.app import App
from metaform.graph import Graph
from metaform.intake import Intake
from metaform.modules import intake, workflow
from metaform.registry import Registry
from metaform.workflow import Engine, import_workflow


def record(name):
    return {
        "entity_desc": name,
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name},
    }


def test_same_authored_join_id_survives_both_sources_and_export(app, tmp_path):
    join = {
        "id": "shared",
        "object_id": "media.photo",
        "element_id": "data.color",
        "type": "receiving_entity",
        "purpose": "local",
    }
    app.graph.put(
        {"elements": {"media.photo": record("photo")}, "joins": [join]},
        "native",
        "unbounded-custom-layer",
    )
    app.graph.put({"joins": [join | {"purpose": "global"}]}, "archaeology")
    assert len(app.graph.joins("media.photo")) == 2
    dump = app.graph.export()
    other = Graph(tmp_path / "copy.kg")
    other.put(dump, "imported")
    other.put(dump, "imported")
    assert other.joins() == app.graph.joins()
    assert other.search("media.photo")[0]["layer"] == "unbounded-custom-layer"
    assert any(o["source"] == "native" for o in other.provenance("media.photo"))


def test_rule_snapshot_and_concurrent_answer_receipts(app):
    app.graph.put(
        {
            "elements": {
                "data.rule": {
                    "entity_desc": "choose",
                    "entity_schema": "metaform:rule",
                    "entity_json_obj": {"expression": True},
                }
            }
        },
        "authored",
    )
    import_workflow(
        app,
        {
            "id": "choose",
            "steps": [
                {
                    "id": "first",
                    "prompt": "act",
                    "transitions": [
                        {"rule": "data.rule", "to": "third"},
                        {"to": "second"},
                    ],
                },
                {"id": "second", "prompt": "second"},
                {"id": "third", "prompt": "third"},
            ],
        },
    )
    job = Engine(app).start("choose")
    app.graph.put(
        {
            "elements": {
                "data.rule": {
                    "entity_desc": "changed",
                    "entity_schema": "metaform:rule",
                    "entity_json_obj": {"expression": False},
                }
            }
        },
        "authored",
    )

    def submit(_):
        return Engine(App(app.project, app.home)).submit(
            job["run_id"], job["request_id"], "same answer"
        )

    with ThreadPoolExecutor(max_workers=4) as pool:
        receipts = list(pool.map(submit, range(4)))
    assert all(r == receipts[0] for r in receipts)
    assert Engine(app).next(job["run_id"])["step"] == "third"
    with app.db() as db:
        assert (
            db.execute("SELECT count(*) FROM events WHERE kind='answer'").fetchone()[0]
            == 1
        )


def test_removed_graph_transition_does_not_return_from_source_copy(app):
    import_workflow(
        app,
        {
            "id": "edit-control",
            "steps": [
                {"id": "first", "prompt": "first", "next": "third"},
                {"id": "second", "prompt": "second"},
                {"id": "third", "prompt": "third"},
            ],
        },
    )
    with app.graph.db() as db:
        db.execute(
            "DELETE FROM joins WHERE object_id=? AND type='transition'",
            ("workflow:edit-control:first",),
        )
    job = Engine(app).start("edit-control")
    Engine(app).submit(job["run_id"], job["request_id"], "done")
    assert Engine(app).next(job["run_id"])["step"] == "second"


def test_specialized_workflow_retains_source_and_runs(app):
    source = {
        "id": "source",
        "steps": [{"id": "act", "prompt": "Improve its encounter."}],
    }
    import_workflow(app, source)
    app.graph.put({"elements": {"media.photo": record("photo")}})
    job = workflow.specialize(app, {"id": "source", "focal": "media.photo"}, None)
    assert job["inputs"]["source"]["steps"][0]["prompt"] == "Improve its encounter."
    answer = {
        "id": "source",
        "steps": [
            {
                "id": "act",
                "prompt": "Improve the photo's legibility for its Receiving Entity.",
            }
        ],
    }
    Engine(app).submit(job["run_id"], job["request_id"], answer)
    Engine(app).next(job["run_id"])
    applied = workflow.apply(
        app, {"run_id": job["run_id"], "id": "specific-photo"}, None
    )
    assert applied["id"] == "specific-photo"
    assert (
        Engine(app).definition("source")["steps"][0]["prompt"]
        == source["steps"][0]["prompt"]
    )
    assert Engine(app).start(applied["id"])["prompt"] == answer["steps"][0]["prompt"]
    assert app.graph.joins("workflow:specific-photo", category="specialization")


@pytest.mark.parametrize("operation", ["convert", "lexicalize", "specialize"])
def test_specialization_receives_exact_semantic_equations_without_rewriting_prompt(
    app, operation
):
    from metaform import prompts
    from metaform.util import digest

    identifier = "prompt:metaform.workflow." + operation
    authored = dict(prompts.get(app, identifier), text="  Authored wording.\n")
    prompts.put(app, authored)
    import_workflow(app, {"id": "source", "steps": [{"id": "act", "prompt": "Act."}]})
    app.graph.put({"elements": {"code": record("Program Code")}})
    arguments = {
        "convert": {"source": "Improve this."},
        "lexicalize": {"prompt": "Improve this.", "focal": "code"},
        "specialize": {"id": "source", "focal": "code"},
    }
    job = getattr(workflow, operation)(app, arguments[operation], None)
    source = Path("docs/semantics/semantic_equation_reuse_rule.md")
    expected = {
        "source": str(source),
        "text": source.read_text(),
        "revision": digest(source.read_text()),
    }
    assert job["inputs"]["semantic_equations"] == expected
    assert Engine(app).next(job["run_id"])["inputs"]["semantic_equations"] == expected
    assert job["source_prompt"] == authored["text"]
    assert prompts.get(app, identifier)["text"] == authored["text"]


@pytest.mark.parametrize("revise", [False, True])
def test_specialization_applies_inline_changes_with_source_references(app, revise):
    import copy
    from metaform import prompts

    import_workflow(app, {
        "id": "source",
        "steps": [
            {
                "id": "review",
                "prompt": "Review its encounter.",
                "transitions": [
                    {"when": {"var": "steps.review.revise"}, "to": "revise"},
                    {"to": "record"},
                ],
            },
            {"id": "revise", "prompt": "Revise its encounter."},
            {"id": "record", "prompt": "Record the result."},
        ],
    })
    original_prompt = dict(prompts.get(app, "prompt:source:review"), rule_codes=["r1"])
    prompts.put(app, original_prompt)
    app.graph.put({"elements": {"code.installer": record("Installer")}})
    job = workflow.specialize(app, {"id": "source", "focal": "code.installer"}, None)
    source = copy.deepcopy(job["inputs"]["source"])
    answer = copy.deepcopy(source)
    answer["steps"][0]["prompt"] = "Review the Bash installer's encounter."
    answer["steps"][1]["prompt"] = "Revise the Bash installer's encounter."
    engine = Engine(app)
    engine.submit(job["run_id"], job["request_id"], answer)
    engine.next(job["run_id"])
    workflow.apply(app, {"run_id": job["run_id"], "id": "bash-installer"}, None)

    assert engine.definition("source") == source
    assert prompts.get(app, "prompt:source:review") == original_prompt
    specialized = engine.start("bash-installer")
    assert specialized["prompt"] == "Review the Bash installer's encounter."
    assert [rule["content"]["rule_code"] for rule in specialized["rules"]] == ["r1"]
    engine.submit(specialized["run_id"], specialized["request_id"], {"revise": revise})
    following = engine.next(specialized["run_id"])
    if revise:
        assert following["step"] == "revise"
        assert following["prompt"] == "Revise the Bash installer's encounter."
        engine.submit(following["run_id"], following["request_id"], "Revised")
        following = engine.next(specialized["run_id"])
    assert following["step"] == "record"
    assert following["prompt"] == "Record the result."
    assert following["prompt_ref"] == "prompt:source:record"
    engine.submit(following["run_id"], following["request_id"], "Recorded")
    assert engine.next(specialized["run_id"])["status"] == "complete"


@pytest.mark.parametrize("reference", ["unchanged", "existing", "declared"])
def test_specialization_preserves_explicit_prompt_reference_selection(app, reference):
    import copy
    from metaform import prompts

    import_workflow(app, {
        "id": "source",
        "steps": [{"id": "act", "prompt": "Improve its encounter."}],
    })
    app.graph.put({"elements": {"code.installer": record("Installer")}})
    job = workflow.specialize(app, {"id": "source", "focal": "code.installer"}, None)
    answer = copy.deepcopy(job["inputs"]["source"])
    expected_ref = "prompt:source:act"
    expected_text = "Improve its encounter."
    if reference != "unchanged":
        expected_ref = "prompt:authored-installer"
        expected_text = "Apply the authored installer instruction."
        authored = {"id": expected_ref, "text": expected_text}
        answer["steps"][0].update(prompt_ref=expected_ref, prompt="Unused inline text.")
        if reference == "existing":
            prompts.put(app, authored)
        else:
            answer["prompts"] = [authored]
    engine = Engine(app)
    engine.submit(job["run_id"], job["request_id"], answer)
    engine.next(job["run_id"])
    workflow.apply(app, {"run_id": job["run_id"], "id": "specific"}, None)
    specialized = engine.start("specific")
    assert specialized["prompt_ref"] == expected_ref
    assert specialized["prompt"] == expected_text
    assert engine.start("source")["prompt"] == "Improve its encounter."


def test_specialization_copies_source_owned_prompt_declarations(app):
    import copy
    from metaform import prompts

    import_workflow(app, {
        "id": "source",
        "prompts": [{
            "id": "prompt:source-act",
            "text": "Original instruction.",
            "rule_codes": ["r1"],
            "description": "Authored source metadata",
        }],
        "steps": [
            {"id": "removed", "prompt_ref": "prompt:source-act"},
            {"id": "first", "prompt_ref": "prompt:source-act"},
            {"id": "second", "prompt_ref": "prompt:source-act"},
        ],
    })
    app.graph.put({"elements": {"code.installer": record("Installer")}})
    job = workflow.specialize(app, {"id": "source", "focal": "code.installer"}, None)
    source = copy.deepcopy(job["inputs"]["source"])
    original_prompt = copy.deepcopy(prompts.get(app, "prompt:source-act"))
    answer = copy.deepcopy(source)
    answer["prompts"][0]["text"] = "Specialized installer instruction."
    answer["prompts"].append({"id": "prompt:unrelated", "text": "Unrelated instruction."})
    answer["steps"] = [answer["steps"][2], answer["steps"][1]]
    answer["steps"].append({"id": "external", "prompt_ref": "prompt:unrelated"})
    engine = Engine(app)
    engine.submit(job["run_id"], job["request_id"], answer)
    engine.next(job["run_id"])
    workflow.apply(app, {"run_id": job["run_id"], "id": "specific"}, None)

    assert prompts.get(app, "prompt:source-act") == original_prompt
    assert engine.definition("source") == source
    assert engine.start("source")["prompt"] == "Original instruction."
    specialized = engine.start("specific")
    specialized_ref = specialized["prompt_ref"]
    assert specialized_ref != "prompt:source-act"
    for step_id in ("second", "first"):
        assert specialized["step"] == step_id
        assert specialized["prompt_ref"] == specialized_ref
        assert specialized["prompt"] == "Specialized installer instruction."
        assert [rule["content"]["rule_code"] for rule in specialized["rules"]] == ["r1"]
        engine.submit(specialized["run_id"], specialized["request_id"], "Done")
        specialized = engine.next(specialized["run_id"])
    assert prompts.get(app, specialized_ref)["description"] == "Authored source metadata"
    assert specialized["step"] == "external"
    assert specialized["prompt_ref"] == "prompt:unrelated"
    assert specialized["prompt"] == "Unrelated instruction."


def test_real_harness_examines_native_purposes_with_scoped_tools(
    app, tmp_path
):
    (app.project / "artifact.txt").write_text("local project evidence")
    app.graph.put({"elements": {"data.private": record("repository-only sentinel")}})
    script = tmp_path / "fixture_harness.py"
    script.write_text("""import json, subprocess, sys
job=json.load(sys.stdin)
def tool(name,args={}):
    result=subprocess.run(job['tool_transport']['command']+[name,'--arguments',json.dumps(args)],capture_output=True,text=True,check=True)
    return json.loads(result.stdout)
element={'entity_desc':'photo','entity_schema':'metaform:element','entity_json_obj':{'en':'photo','ef':'Present a visual record'}}
join={'id':'same','object_id':'document.listing','element_id':'media.photo','type':'receiving_entity','purpose':'Global purpose'}
if job['role']=='native_expert':
    assert 'artifact.txt' in tool('intake.files')
    assert tool('intake.read',{'path':'artifact.txt'})['text']=='local project evidence'
    join['purpose']='native secret'
    answer={'elements':{'media.photo':element},'joins':[join],'archaeology':['media.photo']}
else:
    assert job['role']=='latent_expert'
    assert job['system_prompt']
    assert job['inputs']['native']['joins'][0]['purpose']=='native secret'
    assert any(r['id']=='data.private' for r in tool('intake.search'))
    assert tool('intake.get',{'id':'media.photo'})['joins'][0]['purpose']=='native secret'
    assert 'intake.read' not in job['tools']
    answer={'elements':{'media.photo':element},'joins':[join]}
print(json.dumps(answer))
print('fixture interaction',file=sys.stderr)
""")
    app.debug = True
    app.config["harnesses"] = {"fixture": {"command": [sys.executable, str(script)]}}
    job = Intake(app)._start("native")
    result = asyncio.run(
        intake.drive(app, {"run_id": job["run_id"], "harness": "fixture"}, None)
    )
    assert result["status"] == "complete"
    assert app.global_graph.joins() == []
    assert {j["purpose"] for j in app.graph.joins(scope="archaeology")} == {"Global purpose"}
    assert len(app.graph.joins(scope="merged")) == 1
    with app.db() as db:
        assert db.execute("SELECT count(*) FROM workfolders").fetchone()[0] == 0
        assert (
            "fixture interaction"
            in db.execute(
                "SELECT body FROM events WHERE kind='debug.harness.response' LIMIT 1"
            ).fetchone()[0]
        )


def test_abort_terminates_active_harness_and_returns_router(app, tmp_path):
    async def scenario():
        script = tmp_path / "wait.py"
        script.write_text("import time\ntime.sleep(30)\n")
        app.config["harnesses"] = {
            "fixture": {"command": [sys.executable, str(script)]}
        }
        job = Intake(app).start()
        task = asyncio.create_task(intake.drive(app, {"harness": "fixture"}, None))
        for _ in range(100):
            if app.get("executing:" + job["request_id"]):
                break
            await asyncio.sleep(0.02)
        app.abort()
        result = await asyncio.wait_for(task, 5)
        assert result["status"] == "aborted" and app.get("mode") is None

    asyncio.run(scenario())


def test_tool_step_can_use_a_hidden_module_without_exposing_it(app):
    import_workflow(
        app,
        {
            "id": "tool",
            "steps": [
                {"id": "report", "kind": "tool", "tool": "graph.put", "arguments": {
                    "graph": {"literal": {"elements": {"tool-result": {
                        "entity_desc": "Created by the workflow tool", "entity_schema": "metaform:report",
                        "entity_json_obj": {"written": True},
                    }}}},
                }}
            ],
        },
    )
    job = Engine(app).start("tool")
    assert "graph.put" not in Registry(app).visible()
    result = asyncio.run(workflow.drive(app, {"run_id": job["run_id"]}, None))
    assert result["status"] == "complete"
    assert app.graph.get("tool-result")["entity_json_obj"]["written"]


def test_local_viewer_starts_and_stops_without_blocking_router(app):
    async def scenario():
        import urllib.request

        import socket
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            app.config["web_port"] = probe.getsockname()[1]
        registry = Registry(app)
        started = await registry.call("web.start")
        try:
            with urllib.request.urlopen(started["url"] + "/api/report") as response:
                assert "stats" in json.load(response)
            status = await registry.call("service.status")
            assert status["ready"]
            assert (status["pid"], status["instance_id"]) == (started["pid"], started["instance_id"])
            assert "commands" in await registry.call("system.status")
        finally:
            stopped = await registry.call("web.stop")
            assert stopped == {"stopped": True, "instance_id": started["instance_id"]}
        assert not (await registry.call("service.status"))["ready"]
        assert "commands" in await registry.call("system.status")

    asyncio.run(scenario())


def test_development_workfolder_diff_applies_to_a_non_git_project(app, tmp_path):
    from metaform import workfolders

    workfolders.git(tmp_path, "init", "-q")
    (tmp_path / "program.py").write_text("parent = 3\n")
    (app.project / "program.py").write_text("old = 1\n")
    import_workflow(
        app,
        {
            "id": "development",
            "steps": [{"id": "change", "prompt": "Make the requested change."}],
        },
    )
    job = Engine(app).start("development", workfolder=True)
    path = Path(job["workfolder"])
    (path / "program.py").write_text("new = 2\n")
    (path / "generated.bin").write_bytes(b"\0\1\2\xff")
    Engine(app).submit(job["run_id"], job["request_id"], "Changed")
    final = Engine(app).next(job["run_id"])
    assert (
        final["status"] == "complete"
        and "+new = 2" in final["result"]["changes"]["diff"]
    )
    assert (app.project / "program.py").read_text() == "old = 1\n"
    identifier = final["result"]["workfolder"]["id"]
    workfolders.apply(app, identifier)
    assert (app.project / "program.py").read_text() == "new = 2\n"
    assert (app.project / "generated.bin").read_bytes() == b"\0\1\2\xff"
    assert (tmp_path / "program.py").read_text() == "parent = 3\n"
    workfolders.cleanup(app, identifier)


def test_global_sync_uses_git_and_excludes_native_joins(app, tmp_path):
    from metaform.modules import sync
    from metaform.workfolders import git

    remote = tmp_path / "upstream.git"
    checkout = tmp_path / "checkout"
    remote.mkdir()
    checkout.mkdir()
    git(remote, "init", "--bare", "--initial-branch=main")
    git(checkout, "init", "--initial-branch=main")
    git(checkout, "config", "user.name", "Test Fixture")
    git(checkout, "config", "user.email", "fixture@example.invalid")
    (checkout / "README.md").write_text("fixture")
    git(checkout, "add", "README.md")
    git(checkout, "commit", "-m", "Baseline")
    git(checkout, "remote", "add", "origin", str(remote))
    git(checkout, "push", "origin", "main")
    git(checkout, "checkout", "-b", "unrelated-code")
    (checkout / "unrelated.py").write_text("do_not_ship = True\n")
    git(checkout, "add", "unrelated.py")
    git(checkout, "commit", "-m", "Unrelated code work")
    app.graph.put(
        {
            "joins": [
                {
                    "object_id": "a",
                    "element_id": "b",
                    "type": "dependency",
                    "purpose": "NATIVE_SENTINEL",
                }
            ]
        },
        "native",
    )
    app.global_graph.put(
        {
            "elements": {"media.photo": record("photo")},
            "joins": [
                {
                    "object_id": "a",
                    "element_id": "media.photo",
                    "type": "dependency",
                    "purpose": "global",
                }
            ],
        },
        "archaeology",
        "custom-layer",
    )
    result = sync.merge(app, {"repository": str(checkout)}, None)
    assert result["pushed"]
    assert git(remote, "rev-parse", "main").strip() == result["commit"]
    assert "unrelated.py" not in git(remote, "ls-tree", "-r", "--name-only", "main")
    files = list((checkout / "src/metaform/data/global").rglob("*.json"))
    assert all("NATIVE_SENTINEL" not in p.read_text() for p in files)
    index = checkout / "src/metaform/data/global/index.json"
    old_hash = json.loads(index.read_text())["content_hash"]
    app.global_graph.put(
        {"elements": {"media.photo": record("Updated photo")}},
        "archaeology",
        "custom-layer",
    )
    sync.merge(app, {"repository": str(checkout)}, None)
    assert json.loads(index.read_text())["content_hash"] != old_hash


def test_bundled_data_update_reaches_global_once_per_version(
    app, tmp_path, monkeypatch
):
    from metaform.modules import sync
    import importlib.resources
    from metaform import schemas
    import shutil

    schemas.register(
        app,
        {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": "custom:bundled",
            "type": "object",
        },
    )

    app.global_graph.put(
        {"elements": {"media.photo": record("first")}}, "archaeology", "photo-expertise"
    )
    sync.export(app, {"repository": str(tmp_path / "bundle")}, None)
    data_root = tmp_path / "bundle/src/metaform"
    for name in ("schemas.json", "rulebook.json", "bases.json"):
        shutil.copy2(
            importlib.resources.files("metaform") / "data" / name,
            data_root / "data" / name,
        )
    shutil.copytree(importlib.resources.files("metaform") / "data" / "roles", data_root / "data" / "roles")
    monkeypatch.setattr(importlib.resources, "files", lambda package: data_root)
    from metaform.util import write_json
    write_json(tmp_path / "recipient-home" / "config.json", {"knowledge_mode": "legacy"})
    recipient = App(tmp_path / "recipient", tmp_path / "recipient-home")
    assert "custom:bundled" in schemas.registry(recipient)
    assert recipient.global_graph.get("media.photo")["entity_desc"] == "first"
    assert next(record for record in recipient.global_graph.search() if record["id"] == "media.photo")["layer"] == "photo-expertise"
    app.global_graph.put({"elements": {"media.photo": record("second")}}, "archaeology")
    sync.export(app, {"repository": str(tmp_path / "bundle")}, None)
    recipient = App(recipient.project, recipient.home)
    assert recipient.global_graph.get("media.photo")["entity_desc"] == "second"
    recipient.global_graph.put(
        {"elements": {"media.photo": record("local global contribution")}},
        "archaeology",
    )
    other_project = App(tmp_path / "other-project", recipient.home)
    assert (
        other_project.global_graph.get("media.photo")["entity_desc"]
        == "local global contribution"
    )
