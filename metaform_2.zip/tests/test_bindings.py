"""Working-folder bindings live in the base db (SPEC sections 9 and 13).

`begin` records the folder and its assignment, the CLI detects the working folder and reads the
record, `done` clears it, a record with no activity for 24 hours acts as absent with no message,
and help writes nothing. No `.agentid/nonce` file is written anywhere.
"""
import sqlite3
from datetime import datetime, timedelta, timezone

from metaform import bindings, cli
from metaform.continuation import begin, marker
from metaform.workflow import Engine, import_workflow


def started(app, tmp_path):
    import_workflow(app, {'id': 'bind-work', 'steps': [{'id': 'work', 'prompt': 'Do the step.'}]})
    job = Engine(app).start('bind-work', exclusive=False)
    worker = tmp_path / 'worker'
    begin(job['nonce'], worker, app.home)
    return job, worker


def set_updated(worker, when):
    with sqlite3.connect(bindings.database()) as db:
        db.execute('UPDATE bindings SET updated=? WHERE folder=?', (when.isoformat(), str(worker)))


def test_begin_records_the_folder_in_the_base_db_and_writes_no_file(app, tmp_path, monkeypatch, capsys):
    job, worker = started(app, tmp_path)
    assert not (worker / '.agentid').exists()
    assert bindings.database().is_file()
    row = marker(worker)
    assert row['nonce'] == job['nonce'] and row['folder'] == str(worker) and row['run_id'] == job['run_id']
    assert marker(worker / 'deeper' / 'still')['nonce'] == job['nonce'], 'A child folder inherits the binding'
    monkeypatch.chdir(worker)
    cli.main([])
    out = capsys.readouterr().out
    assert out.startswith('Status\n') and 'Job id: ' + job['nonce'] in out


def test_done_clears_the_record(app, tmp_path, monkeypatch, capsys):
    job, worker = started(app, tmp_path)
    monkeypatch.chdir(worker)
    assert cli.main(['done']) == 0
    capsys.readouterr()
    assert marker(worker) is None
    cli.main([])
    assert 'Job id' not in capsys.readouterr().out


def test_a_record_idle_for_a_day_acts_as_absent_with_no_message(app, tmp_path, monkeypatch, capsys):
    job, worker = started(app, tmp_path)
    set_updated(worker, datetime.now(timezone.utc) - timedelta(hours=25))
    assert marker(worker) is None
    monkeypatch.chdir(worker)
    cli.main([])
    out = capsys.readouterr().out
    assert 'Job id' not in out
    assert 'expired' not in out.lower() and 'no longer' not in out.lower() and 'stale' not in out.lower()


def test_a_command_under_the_binding_is_activity(app, tmp_path, monkeypatch, capsys):
    job, worker = started(app, tmp_path)
    old = datetime.now(timezone.utc) - timedelta(hours=23)
    set_updated(worker, old)
    monkeypatch.chdir(worker)
    assert cli.main(['workflow', 'next']) == 0
    capsys.readouterr()
    with sqlite3.connect(bindings.database()) as db:
        updated = db.execute('SELECT updated FROM bindings WHERE folder=?', (str(worker),)).fetchone()[0]
    assert datetime.fromisoformat(updated) > old + timedelta(hours=1)


def test_help_in_an_unbound_folder_writes_nothing(tmp_path, monkeypatch, capsys):
    home = tmp_path / 'fresh-home'
    monkeypatch.setenv('METAFORM_HOME', str(home))
    folder = tmp_path / 'nowhere'
    folder.mkdir()
    monkeypatch.chdir(folder)
    assert cli.main(['--help']) == 0
    capsys.readouterr()
    assert not (home / 'service').exists()
    assert not list(folder.iterdir())
