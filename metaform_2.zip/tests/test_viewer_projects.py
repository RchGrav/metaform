from metaform.app import App
from metaform.service import stop_service
from metaform.util import write_json
from metaform.viewer import create_app


def local_project(path, home, *, mode="legacy", project_id=None):
    write_json(path / ".metaform" / "config.json", {
        "knowledge_mode": mode, "graph_backend": "json", "auto_build": False,
    })
    if project_id:
        write_json(path / ".metaform" / "project.json", {
            "knowledge_mode": mode, "project_id": project_id,
        })
    return App(path, home, binding=False)


def test_open_project_keeps_tabs_and_graphs_independent(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home)
    second = local_project(tmp_path / "second", home)
    first.graph.put({"elements": {"first": {"en": "First"}}})
    second.graph.put({"elements": {"second": {"en": "Second"}}})
    client = create_app(first).test_client()
    original = client.get("/api/projects").json[0]
    opened = client.post(original["url"] + "api/projects/open", json={"path": "../second"})
    assert opened.status_code == 200, opened.json
    selected = opened.json
    assert selected["path"] == str(second.project)
    assert len(client.get("/api/projects").json) == 2
    for entry, expected in [(original, first), (selected, second)]:
        assert client.get(entry["url"] + "api/settings").json["project"] == str(expected.project)
        graph = client.get(entry["url"] + "api/dump").json
        assert set(graph["elements"]) & {"first", "second"} == {expected.project.name}
    assert client.get("/api/settings").json["project"] == str(first.project)


def test_open_requires_existing_directory(tmp_path):
    first = local_project(tmp_path / "first", tmp_path / "home")
    client = create_app(first).test_client()
    for path in ["", "../missing", str(first.root / "config.json")]:
        response = client.post("/api/projects/open", json={"path": path})
        assert response.status_code == 400, response.json
    assert not (tmp_path / "missing").exists()


def test_open_new_folder_registers_it_for_other_viewers(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home)
    folder = tmp_path / "new-project"
    folder.mkdir()
    try:
        response = create_app(first).test_client().post("/api/projects/open", json={"path": str(folder)})
        assert response.status_code == 200, response.json
        assert response.json["knowledge_mode"] == "service"
        other_viewer = create_app(first).test_client()
        assert response.json["project_id"] in {
            entry["project_id"] for entry in other_viewer.get("/api/projects").json
        }
        assert other_viewer.get(response.json["url"] + "api/settings").json["project"] == str(folder)
    finally:
        stop_service(home)


def test_local_viewer_discovers_later_registered_project(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "local", home)
    client = create_app(first).test_client()
    assert len(client.get("/api/projects").json) == 1
    try:
        registered = App(tmp_path / "registered", home, binding=False)
        entries = client.get("/api/projects").json
        selected = next(entry for entry in entries if entry["project_id"] == registered.project_id)
        response = client.get(selected["url"] + "api/settings")
        assert response.status_code == 200, response.json
        assert response.json["project"] == str(registered.project)
        assert first.knowledge_mode == "legacy"
        assert not (first.root / "project.json").exists()
    finally:
        stop_service(home)


def test_open_respects_target_service_home(tmp_path):
    first = local_project(tmp_path / "first", tmp_path / "first-home")
    target_home = tmp_path / "target-home"
    try:
        target = App(tmp_path / "target", target_home, binding=False)
        client = create_app(first).test_client()
        response = client.post("/api/projects/open", json={"path": str(target.project)})
        assert response.status_code == 200, response.json
        assert response.json["project_id"] == target.project_id
        assert client.get(response.json["url"] + "api/settings").json["project"] == str(target.project)
        assert not (first.home / "service").exists()
    finally:
        stop_service(target_home)


def test_copies_with_same_semantic_owner_have_distinct_viewer_urls(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home, mode="portable", project_id="same-owner")
    second = local_project(tmp_path / "second", home, mode="portable", project_id="same-owner")
    client = create_app(first).test_client()
    original = client.get("/api/projects").json[0]
    response = client.post("/api/projects/open", json={"path": str(second.project)})
    assert response.status_code == 200, response.json
    assert response.json["url"] != original["url"]
    assert response.json["project_id"] == original["project_id"]
    assert client.get(response.json["url"] + "api/settings").json["project"] == str(second.project)
    assert client.get(original["url"] + "api/settings").json["project"] == str(first.project)


def test_select_from_portable_uses_external_home(tmp_path, monkeypatch):
    home = tmp_path / "external-home"
    write_json(home / "config.json", {"knowledge_mode": "legacy"})
    monkeypatch.setenv("METAFORM_HOME", str(home))
    first = local_project(tmp_path / "portable", home, mode="portable")
    second = local_project(tmp_path / "second", home)
    assert first.select_project(second.project).home == home


def test_select_from_launched_archive_does_not_inherit_embedded_home(tmp_path, monkeypatch):
    from pathlib import Path

    user = tmp_path / "user"
    monkeypatch.setattr(Path, "home", lambda: user)
    first = local_project(tmp_path / "portable", tmp_path / "home", mode="portable")
    monkeypatch.setenv("METAFORM_HOME", str(first.home))
    second = local_project(tmp_path / "second", user / ".metaform")
    assert first.select_project(second.project).home == user / ".metaform"


def test_selection_through_second_archive_keeps_external_home(tmp_path, monkeypatch):
    from pathlib import Path

    user = tmp_path / "user"
    monkeypatch.setattr(Path, "home", lambda: user)
    first = local_project(tmp_path / "first", tmp_path / "home", mode="portable")
    monkeypatch.setenv("METAFORM_HOME", str(first.home))
    second = local_project(tmp_path / "second", user / ".metaform", mode="portable")
    third = local_project(tmp_path / "third", user / ".metaform")
    selected = first.select_project(second.project).select_project(third.project)
    assert selected.home == user / ".metaform"


def test_registered_missing_folder_is_not_recreated(tmp_path):
    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home)
    try:
        registered = App(tmp_path / "registered", home, binding=False)
        registered.project.rename(tmp_path / "moved")
        client = create_app(first).test_client()
        entry = next(item for item in client.get("/api/projects").json if item["project_id"] == registered.project_id)
        response = client.get(entry["url"] + "api/settings")
        assert response.status_code == 404, response.json
        assert not registered.project.exists()
    finally:
        stop_service(home)


def test_copy_previews_are_independent(tmp_path):
    import urllib.request

    home = tmp_path / "home"
    first = local_project(tmp_path / "first", home, mode="portable", project_id="same-owner")
    second = local_project(tmp_path / "second", home, mode="portable", project_id="same-owner")
    (first.project / "index.html").write_text("First copy")
    (second.project / "index.html").write_text("Second copy")
    client = create_app(first).test_client()
    original = client.get("/api/projects").json[0]["url"]
    opened = client.post("/api/projects/open", json={"path": str(second.project)}).json["url"]
    try:
        one = client.post(original + "api/preview", json={}).json[0]["url"]
        two = client.post(opened + "api/preview", json={}).json[0]["url"]
        assert one != two
        assert client.get(one).data == b"First copy"
        client.post(original + "api/preview/stop")
        assert client.get(one).status_code == 404
        assert client.get(two).data == b"Second copy"
    finally:
        client.post(original + "api/preview/stop")
        client.post(opened + "api/preview/stop")


def test_existing_local_project_not_adopted_by_home_default(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "service"})
    project = tmp_path / "local"
    write_json(project / ".metaform" / "config.json", {"graph_backend": "json"})
    try:
        selected = App(project, home, binding=False)
        assert selected.knowledge_mode == "legacy"
        assert not (selected.root / "project.json").exists()
    finally:
        stop_service(home)


def test_open_cannot_change_bound_assignment(tmp_path):
    first = local_project(tmp_path / "first", tmp_path / "home")
    first.binding = {"request_id": "bound"}
    second = tmp_path / "second"
    second.mkdir()
    response = create_app(first).test_client().post("/api/projects/open", json={"path": str(second)})
    assert response.status_code == 400
    assert "bound assignment" in response.json["error"]
    assert not (second / ".metaform").exists()
