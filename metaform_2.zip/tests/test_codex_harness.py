import asyncio
import json
import tomllib
from pathlib import Path

import pytest

from metaform import harness
from metaform.intake import Intake
from metaform.modules.intake import drive


def codex_result(monkeypatch, answer, captured, exit_code=0, stdout=b""):
    monkeypatch.setattr(harness.shutil, "which", lambda name: "/fixture/codex")

    async def launch(*command, **options):
        captured["command"] = command

        class Process:
            returncode = exit_code

            async def communicate(self, data):
                captured["payload"] = json.loads(data)
                if not exit_code:
                    output = Path(command[command.index("--output-last-message") + 1])
                    output.write_text(json.dumps(answer))
                return stdout, b""

        return Process()

    monkeypatch.setattr(harness.asyncio, "create_subprocess_exec", launch)


def test_codex_receives_open_schema_without_strict_transport_restrictions(app, monkeypatch):
    job = Intake(app).start()
    captured = {}
    answer = {"elements": {}, "joins": []}
    codex_result(monkeypatch, answer, captured)
    result = asyncio.run(harness.execute(app, job, "codex"))
    assert result == {"status": "answered", "answer": answer}
    assert captured["payload"]["schema"] == job["schema"]
    assert "source_prompt" not in captured["payload"]
    assert job["source_prompt"] in captured["payload"]["prompt"]
    assert captured["payload"]["response_format"]
    assert "--output-schema" not in captured["command"]
    assert "sandbox_workspace_write.network_access=true" in captured["command"]
    assert captured["command"][captured["command"].index("--sandbox") + 1] == "workspace-write"
    assert not any(arg.startswith("developer_instructions=") for arg in captured["command"])


def test_codex_places_assignment_instructions_before_task_in_developer_channel(app, monkeypatch):
    job = Intake(app).start()
    instructions = 'Keep the outside perspective.\nExamine "why" and its relationships.'
    job["system_prompt"] = instructions
    captured = {}
    codex_result(monkeypatch, {"elements": {}, "joins": []}, captured)

    asyncio.run(harness.execute(app, job, "codex"))

    overrides = [captured["command"][i + 1] for i, arg in enumerate(captured["command"]) if arg == "-c"]
    config = tomllib.loads("\n".join(overrides))
    assert config.get("developer_instructions") == instructions
    assert "system_prompt" not in captured["payload"]
    assert captured["payload"]["prompt"] == job["prompt"]
    saved = json.loads((app.home / "requests" / job["request_id"] / "request.json").read_text())
    assert saved["system_prompt"] == instructions
    assert saved["source_prompt"] == job["source_prompt"]


def test_codex_retains_source_when_it_differs_from_rendered_task(app, monkeypatch):
    job = Intake(app).start()
    job["source_prompt"] = "Inspect {{ subject }}"
    job["prompt"] = "Inspect the photo"
    captured = {}
    codex_result(monkeypatch, {"elements": {}, "joins": []}, captured)
    asyncio.run(harness.execute(app, job, "codex"))
    assert captured["payload"]["source_prompt"] == "Inspect {{ subject }}"


@pytest.mark.parametrize("role", [
    "native_expert", "latent_expert",
])
def test_explicitly_blocked_intake_stays_pending_and_can_be_retried(app, monkeypatch, role):
    engine = Intake(app)
    job = engine.start()
    job["role"] = role
    run = app.load_run(job["run_id"])
    run["pending"] = job
    app.save_run(run)
    answer = {"elements": {}, "joins": [], "status": "blocked", "reason": "Tool unavailable"}
    codex_result(monkeypatch, answer, {})
    result = asyncio.run(drive(app, {"harness": "codex", "steps": 1}, None))
    assert result["status"] == "blocked"
    assert app.load_run(job["run_id"])["status"] == "running"
    assert engine.next(job["run_id"]) == job
    assert app.get("execution:" + job["request_id"]) is None
    direct = engine.submit(job["run_id"], job["request_id"], answer)
    assert direct["status"] == "blocked"
    assert not app.load_run(job["run_id"])["receipts"]
    receipt = engine.submit(job["run_id"], job["request_id"], {"elements": {}, "joins": []})
    assert receipt["recorded"]


def test_codex_stdout_error_is_reported_when_stderr_is_empty(app, monkeypatch):
    job = Intake(app).start()
    codex_result(monkeypatch, None, {}, exit_code=1, stdout=b'{"type":"error","message":"invalid_json_schema"}')
    with pytest.raises(ValueError, match="invalid_json_schema"):
        asyncio.run(harness.execute(app, job, "codex"))
