const {mkdtempSync}=require('node:fs');
const {tmpdir}=require('node:os');
const {join}=require('node:path');
module.exports={
  python:process.env.PYTHON||'.venv/bin/python',
  outputDirectory(name){const directory=mkdtempSync(join(tmpdir(),'metaform-'+name+'-'));console.log('Browser evidence: '+directory);return directory;},
};
