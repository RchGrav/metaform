import json
from pathlib import Path

import pytest
from jsonschema import Draft202012Validator

from metaform import prompts, rulebook, schemas
from metaform.backends import JSONGraph
from metaform.intake import Intake
from metaform.modules import intake, prompt
from metaform.util import digest
from metaform.workflow import Engine, import_workflow


ROOT = Path(__file__).resolve().parents[1]


def test_seeds_preserve_authored_formulas_and_deliver_priming(app):
    seeds = json.loads((ROOT / "src/metaform/data/rulebook.json").read_text())
    for seed in seeds:
        assert schemas.annotations(app, "metaform:semantic-rule", seed) == []
        assert rulebook.get(app, seed["rule_code"]) == seed
        examples = seed["priming"]["examples"]
        assert {example["assessment"] for example in examples} == {"accepted", "rejected"}
        assert all(example["reason"] for example in examples)
    for code, field in [("r1", "name"), ("r2", "description")]:
        text = (ROOT / f"docs/rulebook/element/{field}.md").read_text()
        concise = text.split("## Concise form\n\n", 1)[1].split("\n\n## Expansion", 1)[0]
        assert rulebook.get(app, code)["concise"] == concise
    typology = (ROOT / "docs/semantics/functional_typology.md").read_text()
    assert "> " + rulebook.get(app, "r3")["concise"] in typology
    assert "> " + rulebook.get(app, "r5")["concise"] in typology


@pytest.mark.parametrize("backend", ["sqlite", "json"])
def test_reseeding_preserves_edited_rules(app, backend):
    if backend == "json":
        app.graph = JSONGraph(app.root / "rules.json")
    rulebook.seed(app)
    edited = rulebook.get(app, "r1")
    edited["priming"]["context"] = "Authored clarification retained across startup."
    rulebook.put(app, edited)
    rulebook.seed(app)
    app.seed()
    assert rulebook.get(app, "r1") == edited
    assert rulebook.get(app, "r3")["priming"]["examples"]


def test_concise_preparation_retains_rule_identity_and_revision(app):
    full = rulebook.prepare(app, ["r3"])[0]
    concise = rulebook.prepare(app, ["r3"], concise_only=True)[0]
    assert "priming" not in concise["content"]
    assert concise["revision"] == full["revision"]
    for field in ("rule_code", "purpose", "concise"):
        assert concise["content"][field] == full["content"][field]
    assert "priming" in rulebook.get(app, "r3")


def test_prompt_and_intake_deliver_exact_rules_and_bundled_aliases(app):
    identifier = "prompt:metaform.intake.native"
    prompts.put(app, dict(prompts.get(app, identifier), rule_codes=["r1", "r2", "r3", "r5"]))
    prepared = prompts.snapshot(app, identifier)
    job = Intake(app).start()
    assert job["rules"] == prepared["rules"]
    assert {r["content"]["rule_code"] for r in job["rules"]} >= {"r1", "r2", "r3", "r5"}
    for snapshot in job["rules"]:
        authored = rulebook.get(app, snapshot["content"]["rule_code"])
        assert snapshot["content"] == authored
        assert snapshot["revision"] == digest(authored)
    aliases = (ROOT / "src/metaform/data/semantics/aliases.md").read_text()
    maintained = (ROOT / "docs/semantics/inference_metaform_rules.md").read_text()
    assert aliases.strip() in maintained
    assert job["source_prompt"] == prepared["source_prompt"]
    assert job["components"] == []


def test_configured_alias_source_is_delivered_verbatim(app):
    aliases = "Aliases authored for this context.\nLiteral {{ namespace }} stays exact.\n"
    path = app.project / "aliases.md"
    path.write_text(aliases)
    app.config["semantic_sources"] = {"aliases": str(path)}
    job = prompts.compose_role(app, "expand", {})
    assert job["prompt"].endswith("\n\n" + aliases)
    assert job["components"][-1]["source"] == str(path)
    assert job["components"][-1]["revision"] == digest(aliases)


def test_workflow_freezes_rule_revisions_for_all_steps_and_new_runs_refresh(app):
    prompts.put(app, {"id": "prompt:rules", "text": "Examine {{ inputs.subject }}.", "rule_codes": ["r3"]})
    import_workflow(app, {
        "id": "rules",
        "steps": [
            {"id": "first", "prompt_ref": "prompt:rules"},
            {"id": "second", "prompt_ref": "prompt:rules"},
        ],
    })
    engine = Engine(app)
    first = engine.start("rules", {"subject": "code.cpp"}, exclusive=False)
    assert first["rules"] == prompts.prepare(app, "prompt:rules", {"inputs": {"subject": "code.cpp"}})["rules"]
    original = first["rules"]
    edited = rulebook.get(app, "r3")
    edited["priming"]["context"] += "\nAdditional authored encounter explanation."
    rulebook.put(app, edited)
    assert engine.next(first["run_id"]) == first
    engine.submit(first["run_id"], first["request_id"], "First answer")
    second = engine.next(first["run_id"])
    assert second["step"] == "second"
    assert second["rules"] == original
    fresh = engine.start("rules", {"subject": "code.cpp"}, exclusive=False)
    assert fresh["rules"][0]["content"] == edited
    assert fresh["rules"][0]["revision"] != original[0]["revision"]


def test_prompt_test_receipt_preserves_exact_rule_snapshot(app):
    prompts.put(app, {"id": "prompt:trial", "text": "Interpret the functional path.", "rule_codes": ["r3"]})
    job = prompt.run(app, {"id": "prompt:trial"}, None)
    original = job["rules"]
    edited = rulebook.get(app, "r3")
    edited["priming"]["context"] = "Changed after assignment."
    rulebook.put(app, edited)
    Engine(app).submit(job["run_id"], job["request_id"], "Recorded answer")
    records = app.graph.search("*", "tests")
    assert len(records) == 1
    receipt = records[0]["entity_json_obj"]
    assert receipt["prepared"]["rules"] == original
    assert receipt["prepared"]["source_prompt"] == job["source_prompt"]
    assert receipt["answer"] == "Recorded answer"


def test_latent_receives_native_purposes_and_type_schema_without_source_tools(app):
    schema_header = {"$schema": "https://json-schema.org/draft/2020-12/schema"}
    schemas.register(app, schema_header | {"$id": "custom:label", "type": "string", "minLength": 1})
    schemas.register(app, schema_header | {
        "$id": "custom:type", "type": "object", "properties": {"en": {"$ref": "custom:label"}}, "required": ["en"],
    })
    focal = {"entity_desc": "Program code", "entity_schema": "custom:type", "entity_json_obj": {"en": "Program code"}}
    app.global_graph.put({
        "elements": {"code": focal},
        "joins": [{"object_id": "code", "element_id": "code.cpp", "type": "receiving_entity", "purpose": "Unrelated global purpose"}],
    }, "archaeology")
    secret = {"entity_desc": "PROJECT ONLY", "entity_schema": "metaform:element", "entity_json_obj": {"en": "PROJECT ONLY"}}
    app.graph.put({"elements": {"private": secret}}, "native")
    engine = Intake(app)
    native = engine._start("native")
    engine.submit(native["run_id"], native["request_id"], {
        "elements": {"code": focal},
        "joins": [{"object_id": "code", "element_id": "private", "type": "receiving_entity", "purpose": "Project purpose"}],
    })
    blind = engine.next(native["run_id"])
    assert blind["inputs"]["native"]["elements"]["code"].items() >= focal.items()
    supplied_schema = blind["inputs"]["schemas"]["custom:type"]
    assert supplied_schema["$defs"]["custom:label"]["minLength"] == 1
    validator = Draft202012Validator(supplied_schema)
    assert validator.is_valid({"en": "Program code"})
    assert not validator.is_valid({"en": ""})
    assert blind["context"] == "fresh"
    assert all("priming" in snapshot["content"] for snapshot in blind["rules"])
    assert "intake.files" not in blind["tools"] and "intake.read" not in blind["tools"]
    args = {"run_id": native["run_id"], "id": "code"}
    lookup = intake.get(app, args, None)
    assert lookup["object"].items() >= focal.items()
    assert lookup["joins"][0]["purpose"] == "Project purpose"
    assert intake.get(app, args | {"id": "private"}, None)["object"].items() >= secret.items()
    search = intake.search(app, {"run_id": native["run_id"], "query": "*"}, None)
    assert {record["id"] for record in search} >= {"code", "private"}
    with pytest.raises(ValueError, match="outside"):
        intake.read(app, args | {"path": "private.txt"}, None)
