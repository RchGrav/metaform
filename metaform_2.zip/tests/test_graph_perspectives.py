import asyncio
import copy

import pytest

from metaform.backends import open_graph
from metaform.registry import Registry


@pytest.fixture(params=["sqlite", "json"])
def graph(request, tmp_path):
    return open_graph(tmp_path / ("perspectives." + request.param), request.param)


def element(name):
    return {
        "entity_desc": name + " description",
        "entity_schema": "metaform:element",
        "entity_json_obj": {
            "en": name, "ef": name + " Encounter Function",
            "roles": ["Defining Element", "Notable Element", "Parametric Element", "Stylistic Element"],
        },
    }


def test_source_records_survive_updates_reverts_and_export(graph, tmp_path):
    contextual, latent = element("Contextual"), element("Latent")
    graph.put({"elements": {"code": contextual}}, "native")
    graph.put({"elements": {"code": latent}}, "archaeology")
    assert graph.get("code", scope="native") == contextual
    assert graph.get("code", scope="archaeology") == latent
    assert graph.search("Contextual", scope="native")[0]["entity_json_obj"] == contextual["entity_json_obj"]
    assert graph.search("Contextual", scope="archaeology") == []

    graph.put({"elements": {"code": element("Revised")}}, "native")
    graph.put({"elements": {"code": contextual}}, "native")
    assert graph.get("code", scope="native") == contextual
    assert graph.get("code", scope="archaeology") == latent
    copy_graph = open_graph(tmp_path / "copy.json", "json")
    copy_graph.put(graph.export(), "imported")
    assert copy_graph.get("code", scope="native") == contextual
    assert copy_graph.get("code", scope="archaeology") == latent


def test_reimport_refreshes_the_current_record_of_each_source(graph, tmp_path):
    source = open_graph(tmp_path / "source.json", "json")
    original, revised = element("Original"), element("Revised")
    source.put({"elements": {"code": original}}, "native")
    graph.put(source.export(), "imported")
    source.put({"elements": {"code": revised}}, "native")
    graph.put(source.export(), "imported")
    source.put({"elements": {"code": original}}, "native")
    graph.put(source.export(), "imported")
    assert graph.get("code", scope="native") == original


def test_scoped_export_and_traversal_exclude_other_source_payload(graph):
    graph.put({
        "elements": {"code": element("Contextual"), "project": element("Project only")},
        "joins": [{"id": "local", "object_id": "code", "element_id": "project", "type": "dependency", "purpose": "Local purpose"}],
    }, "native")
    graph.put({
        "elements": {"code": element("Latent")},
        "joins": [{"id": "global", "object_id": "code", "element_id": "project", "type": "dependency", "purpose": "Latent purpose"}],
    }, "archaeology")
    exported = graph.export(scope="archaeology")
    assert set(exported["elements"]) == {"code"}
    assert exported["elements"]["code"]["entity_json_obj"]["en"] == "Latent"
    assert {o["source"] for o in exported["observations"]} == {"archaeology"}
    assert {j["purpose"] for j in exported["joins"]} == {"Latent purpose"}
    traversed = graph.assemble("code", scope="archaeology")
    assert traversed["elements"]["code"]["entity_json_obj"]["en"] == "Latent"
    assert "project" not in traversed["elements"]
    assert traversed["unresolved"] == ["project"]


def test_scoped_search_retains_source_layer(graph):
    graph.put({"elements": {"code": element("Contextual")}}, "native", layer="local-types")
    graph.put({"elements": {"code": element("Latent")}}, "archaeology", layer="global-types")
    assert graph.search(layer="local-types", scope="native")[0]["id"] == "code"
    assert graph.search(layer="global-types", scope="native") == []


def test_graph_commands_expose_independent_perspectives(app):
    app.graph.put({"elements": {"code": element("Contextual")}}, "native")
    app.graph.put({"elements": {"code": element("Latent")}}, "archaeology")
    registry = Registry(app)
    for scope, name in [("native", "Contextual"), ("archaeology", "Latent")]:
        result = asyncio.run(registry.call("graph.get", {"id": "code", "scope": scope}))
        assert result["record"]["entity_json_obj"]["en"] == name
        result = asyncio.run(registry.call("graph.search", {"query": name, "scope": scope}))
        assert result[0]["entity_json_obj"]["en"] == name
        result = asyncio.run(registry.call("graph.dump", {"scope": scope}))
        assert result["elements"]["code"]["entity_json_obj"]["en"] == name


def test_existing_observations_restore_source_views(graph):
    contextual, latent = element("Original contextual"), element("Original latent")
    graph.put({
        "elements": {"code": latent},
        "joins": [],
        "observations": [
            {"id": "old-native", "element_id": "code", "source": "native", "record": copy.deepcopy(contextual), "created": "2026-09-01T00:00:00+00:00"},
            {"id": "old-latent", "element_id": "code", "source": "archaeology", "record": copy.deepcopy(latent), "created": "2026-09-02T00:00:00+00:00"},
        ],
    }, "imported")
    assert graph.get("code", scope="native") == contextual
    assert graph.get("code", scope="archaeology") == latent
