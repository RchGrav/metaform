"""Historical v1 assignment contracts remain resumable after the v2 transition."""
import pytest

from metaform.intake import Intake
from metaform import prompts
from metaform.util import digest


def element(name, description):
    return {
        "entity_desc": description,
        "entity_schema": "metaform:element",
        "entity_json_obj": {
            "en": name,
            "ef": "A function",
            "aliases": ["an alias"],
            "notes": "Exact authored context.\nA second line.",
        },
    }


@pytest.mark.parametrize("role", ["native", "archaeology"])
def test_intake_preserves_literal_authored_prompt(app, role):
    source = "Literal {{ 1 + 1 }}.\n{% if example %}Example syntax.{% endif %}\n"
    prompt_ref = "prompt:metaform.intake." + role
    prompts.put(app, {"id": prompt_ref, "text": source, "rule_codes": []})
    engine = Intake(app)
    job = engine._start("native")
    if role == "archaeology":
        engine.submit(job["run_id"], job["request_id"], {
            "elements": {"code": element("Program code", "Program code description")},
            "joins": [],
        })
        job = engine.next(job["run_id"])
    assert job["prompt_ref"] == prompt_ref
    assert job["source_prompt"] == source
    assert job["prompt_revision"] == digest(source)
    assert job["prompt"].startswith(source + "\n\n")
    assert job["rules"] == []


def test_distinct_actual_elements_share_type_and_retain_purposes_through_empty_final(app):
    type_record = element("Interface program code", "Code exposing an interaction with a function")
    app.global_graph.put({"elements": {"code.interface": type_record}}, "authored")
    actual = {}
    for identifier, name in [("element:gateway-cli", "Gateway CLI"), ("element:monitor-cli", "Monitor CLI")]:
        actual[identifier] = element(name, name + " in this project")
        actual[identifier]["entity_json_obj"].update(type_id="code.interface", artifact="mesh")
    actual["element:operator"] = element("Mesh operator", "Person operating this mesh")
    graph = {"elements": actual, "joins": [
        {"id": "gateway-control", "object_id": "element:operator", "element_id": "element:gateway-cli",
         "type": "hard dependency", "purpose": "Select the gateway", "signal": "Gateway selection command"},
        {"id": "monitor-control", "object_id": "element:operator", "element_id": "element:monitor-cli",
         "type": "hard dependency", "purpose": "Inspect uplink health", "signal": "Health status response"},
    ]}
    engine = Intake(app)
    native = engine._start("native")
    engine.put(native["run_id"], graph, native["request_id"])
    engine.submit(native["run_id"], native["request_id"], {"elements": {}, "joins": []})
    latent = engine.next(native["run_id"])
    received = latent["inputs"]["native"]
    for identifier in ("element:gateway-cli", "element:monitor-cli"):
        assert received["elements"][identifier]["entity_json_obj"] == actual[identifier]["entity_json_obj"]
    assert {(j["object_id"], j["element_id"], j["purpose"], j["signal"]) for j in received["joins"]} == {
        (j["object_id"], j["element_id"], j["purpose"], j["signal"]) for j in graph["joins"]}
    assert received["references"]["global"]["elements"]["code.interface"]["entity_desc"] == type_record["entity_desc"]
    assert app.graph.get("code.interface", scope="native") is None


def test_prepared_native_exposes_element_contract_and_incremental_completion(app):
    from metaform import schemas

    job = Intake(app)._start("native")
    assert "type_ids" in job["inputs"]["schemas"]["metaform:actual-element"]["properties"]
    assert "type_id" not in job["inputs"]["schemas"]["metaform:element"]["properties"]
    assert "svg" in job["inputs"]["schemas"]["metaform:element"]["properties"]
    assert "understanding" in job["schema"]["properties"]
    assert schemas.annotations(app, job["inputs"]["schemas"]["metaform:operative-purpose-join"], {
        "type": "hard dependency", "classification": "Owner-supplied category", "is_soft": True}) == []
    assert "unsaved" in job["completion"]
    assert '{"elements": {}, "joins": []}' in job["completion"]
    assert "type_ids" in job["source_prompt"]
    assert job["source_prompt"].startswith("Identify the project's Defining Element:")
    assert "Stylistic Element" not in job["source_prompt"]


def test_freeform_understanding_and_multiple_type_definitions_reach_latent_unchanged(app):
    from metaform import schemas

    types = {identifier: element(identifier, description) for identifier, description in [
        ("media.photo", "A photograph presents a recorded visual scene"),
        ("document.evidence", "Evidence documents substantiate an account"),
    ]}
    types["media.photo"]["entity_json_obj"]["svg"] = '<svg viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20"/></svg>'
    app.global_graph.put({"elements": types}, "authored")
    description = {"subject": "The worn navigator", "what_matters": ["Scratches are visible", {"label": "Model identifier can be read"}], "context": {"listing": "The sale photographs"}}
    actual = {"entity_desc": "The navigator photograph", "entity_schema": "metaform:actual-element",
              "entity_json_obj": {"en": "Navigator photograph", "description": description,
                                  "type_ids": list(types), "composition": {"foreground": "navigator", "background": "map"}}}
    understanding = {"account": "These photographs document the used navigator for sale.",
                     "sequence": [{"image": "front", "shows": "screen wear"}, {"image": "back", "shows": "model label"}]}
    graph = {"understanding": understanding, "elements": {"actual:navigator-photo": actual}, "joins": []}
    assert schemas.annotations(app, "metaform:actual-element", actual["entity_json_obj"]) == []
    assert schemas.annotations(app, "metaform:actual-element", {"description": "A plain written account"}) == []
    engine = Intake(app)
    native = engine._start("native")
    engine.put(native["run_id"], graph, native["request_id"])
    engine.submit(native["run_id"], native["request_id"], {"elements": {}, "joins": []})
    latent = engine.next(native["run_id"])
    received = latent["inputs"]["native"]
    assert received["understanding"] == understanding
    assert received["elements"]["actual:navigator-photo"]["entity_json_obj"] == actual["entity_json_obj"]
    assert set(received["elements"]) == {"actual:navigator-photo"}
    assert received["joins"] == []
    for identifier, record in types.items():
        assert received["references"]["global"]["elements"][identifier]["entity_json_obj"] == record["entity_json_obj"]
    assert "metaform:actual-element" in latent["inputs"]["schemas"]
