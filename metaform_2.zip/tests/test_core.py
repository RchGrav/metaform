import asyncio
import json
from pathlib import Path

from metaform.app import App
from metaform.graph import composed_search
from metaform.registry import Registry
from metaform.workflow import Engine, import_workflow


def element(name, ef=""):
    return {
        "entity_desc": name,
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name, "ef": ef},
    }


def test_dynamic_modules_are_lazy_and_takeover_preserves_raw_input(app):
    directory = app.home / "modules" / "example"
    directory.mkdir(parents=True)
    marker = directory / "imported"
    (directory / "handler.py").write_text(
        f"from pathlib import Path\nPath({str(marker)!r}).write_text('loaded')\ndef run(app,args,context): return args\ndef raw(app,args,context): return {{'raw':args}}\n"
    )
    (directory / "module.json").write_text(
        json.dumps(
            {
                "id": "example",
                "disable_argparse": True,
                "raw_handler": "handler.py:raw",
                "commands": [
                    {
                        "name": "run",
                        "handler": "handler.py:run",
                        "inputSchema": {"type": "object", "properties": {}},
                    }
                ],
            }
        )
    )
    registry = Registry(app)
    assert "example.run" in registry.discover()
    assert not marker.exists()
    assert asyncio.run(registry.call("example.run", {"x": 3})) == {"x": 3}
    app.enter("example")
    visible = set(registry.visible())
    assert {"example.run", "guide.start", "system.reference", "graph.search", "web.start"} <= visible
    assert "workflow.start" not in visible
    assert asyncio.run(registry.raw(["--help", "-weird", "raw text"])) == {
        "raw": ["--help", "-weird", "raw text"]
    }
    asyncio.run(registry.call("abort"))
    assert "graph.search" in registry.visible()
    (directory / "module.json").unlink()
    assert "example.run" not in registry.discover()


def test_schema_annotations_keep_answer_and_open_ended_forms(app):
    from metaform import schemas

    schemas.register(
        app,
        {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$id": "custom:eleventh",
            "type": "object",
            "properties": {"x": {"type": "integer"}},
        },
    )
    assert "custom:eleventh" in schemas.registry(app)
    import_workflow(
        app,
        {
            "id": "schema",
            "steps": [{"id": "ask", "prompt": "Answer", "schema": "custom:eleventh"}],
        },
    )
    engine = Engine(app)
    job = engine.start("schema")
    result = engine.submit(job["run_id"], job["request_id"], {"x": "not an integer"})
    assert result["recorded"] and result["annotations"]
    assert engine.next(job["run_id"])["result"]["steps"]["ask"] == {
        "x": "not an integer"
    }


def test_conditional_loop_and_no_silent_skip(app):
    example = Path(__file__).resolve().parents[1] / "examples/workflows/conditional_review.json"
    import_workflow(app, json.loads(example.read_text()))
    engine = Engine(app)
    job = engine.start("metaform.conditional_review", {"element": "photo"})
    assert engine.next(job["run_id"]) == job
    engine.submit(
        job["run_id"], job["request_id"], {"revise": True, "work": "Adjust lighting"}
    )
    revision = engine.next(job["run_id"])
    assert revision["step"] == "revise" and "Adjust lighting" in revision["prompt"]
    engine.submit(job["run_id"], revision["request_id"], "done")
    repeated = engine.next(job["run_id"])
    assert repeated["step"] == "review"
    engine.submit(
        job["run_id"], repeated["request_id"], {"revise": False, "work": "finished"}
    )
    final = engine.next(job["run_id"])
    assert final["step"] == "record"
    engine.submit(job["run_id"], final["request_id"], "result")
    assert engine.next(job["run_id"])["status"] == "complete"


def test_recursive_nested_flow_and_foreach(app):
    import_workflow(
        app, {"id": "child", "steps": [{"id": "item", "prompt": "{{ inputs.value }}"}]}
    )
    import_workflow(
        app,
        {
            "id": "parent",
            "steps": [
                {
                    "id": "nested",
                    "kind": "call",
                    "workflow": "child",
                    "inputs": {"value": "nested value"},
                },
                {
                    "id": "repeat",
                    "kind": "foreach",
                    "items": ["a", "b"],
                    "prompt": "{{ item }}",
                    "save_as": "answers",
                },
            ],
        },
    )
    engine = Engine(app)
    run = engine.start("parent")
    job = engine.next(run["run_id"])
    assert job["prompt"] == "nested value"
    engine.submit(run["run_id"], job["request_id"], "child response")
    engine.next(run["run_id"])
    for item in ["a", "b"]:
        job = engine.next(run["run_id"])
        assert job["prompt"] == item
        engine.submit(run["run_id"], job["request_id"], item.upper())
    engine.next(run["run_id"])
    final = engine.next(run["run_id"])
    assert final["result"]["values"]["answers"] == ["A", "B"]
    child = engine.recursive(run["run_id"])
    assert app.load_run(child["run_id"])["parent"] == run["run_id"]


def test_graph_transitions_are_executable_and_prose_import_is_exact(app):
    prompt = "Consider every option.\n\nThen act on the element's purpose."
    result = import_workflow(app, prompt)
    engine = Engine(app)
    job = engine.start(result["id"])
    assert job["source_prompt"] == prompt and job["prompt"] == prompt
    app.abort()
    definition = {
        "id": "graph-control",
        "steps": [
            {"id": "first", "prompt": "first", "next": "second"},
            {"id": "second", "prompt": "second"},
            {"id": "third", "prompt": "third"},
        ],
    }
    import_workflow(app, definition)
    edge = app.graph.joins("workflow:graph-control:first", category="transition")[0]
    edge.update(to="third", element_id="workflow:graph-control:third")
    app.graph.put({"joins": [edge]}, "authored")
    job = engine.start("graph-control")
    engine.submit(job["run_id"], job["request_id"], "ok")
    assert engine.next(job["run_id"])["step"] == "third"


def test_graph_cycles_hyperedge_aliases_and_cleanup(app):
    a = element("A")
    a["entity_json_obj"]["aliases"] = ["alpha"]
    graph = {
        "elements": {"code.a": a, "code.b": element("B"), "code.c": element("C")},
        "joins": [
            {
                "object_id": "code.a",
                "element_id": "code.b",
                "type": "relationship",
                "participants": [
                    {"role": "first", "ref": "code.a"},
                    {"role": "second", "ref": "code.b"},
                    {"role": "third", "ref": "code.c"},
                ],
            },
            {"object_id": "code.b", "element_id": "code.a", "type": "dependency"},
        ],
    }
    app.graph.put(graph)
    app.graph.put(graph)
    assembled = app.graph.assemble("code.c")
    assert set(assembled["elements"]) == {"code.a", "code.b", "code.c"}
    assert len(assembled["joins"]) == 2
    assert composed_search(app, "alpha")[0]["id"] == "code.a"
    assert app.graph.clean()["integrity"] == "ok"


def test_non_git_workfolder_diff_and_cleanup(app):
    from metaform import workfolders

    (app.project / "original.txt").write_text("before")
    folder = workfolders.create(app)
    path = Path(folder["path"])
    (path / "original.txt").write_text("after")
    (path / "new.txt").write_text("new")
    delta = workfolders.diff(app, folder["id"])["diff"]
    assert "+after" in delta and "+new" in delta
    assert (app.project / "original.txt").read_text() == "before"
    workfolders.cleanup(app, folder["id"])
    assert not path.exists()


def test_prompt_files_render_and_resume(app, tmp_path):
    (tmp_path / "prompt.txt").write_text("For {{ inputs.name }}")
    import_workflow(
        app,
        {
            "id": "file",
            "base_dir": str(tmp_path),
            "steps": [{"id": "ask", "prompt": "file:prompt.txt"}],
        },
    )
    first = Engine(app).start("file", {"name": "photo"})
    second = Engine(App(app.project, app.home)).next(first["run_id"])
    assert first == second and first["prompt"] == "For photo"


def test_flask_observatory_and_debug(app):
    from metaform.viewer import create_app

    app.debug = True
    asyncio.run(Registry(app).call("graph.stats"))
    client = create_app(app).test_client()
    assert b"Namespace" in client.get("/").data
    assert client.get("/api/report").json["events"]
    assert client.get("/api/dump").json["elements"]


def test_imagegen_lazy_dry_run(app):
    result = asyncio.run(
        Registry(app).call(
            "imagegen.generate",
            {
                "prompt": "A photo of a red cube",
                "output": str(app.project / "cube.png"),
                "dry_run": True,
            },
        )
    )
    assert "red cube" in result["prompt"] and not result["generated"]
