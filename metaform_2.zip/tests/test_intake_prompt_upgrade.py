"""Managed role migration preserves authored overrides and issued instructions."""
import json
from pathlib import Path

import pytest

from metaform import prompts
from metaform.app import App
from metaform.util import digest
from metaform.workflow import Engine, import_workflow


@pytest.mark.parametrize('role', ['native', 'archaeology'])
@pytest.mark.parametrize('fixture', ['intake-before-artifact-context.json', 'intake-before-whole-native.json',
                                    'intake-before-actual-identities.json', 'intake-before-freeform-understanding.json'])
def test_known_managed_revision_updates_without_changing_issued_assignment(app, fixture, role):
    historical = json.loads((Path(__file__).parent / 'fixtures' / fixture).read_text())
    identifier = 'prompt:metaform.intake.' + role
    expected = prompts.get(app, identifier)['text']
    prompts.put(app, {'id': identifier, 'name': 'Native Expert' if role == 'native' else 'Latent Expert',
                      'text': historical[role], 'description': 'Retained metadata', 'rule_codes': ['r1']})
    import_workflow(app, {'id': 'issued', 'steps': [{'id': 'work', 'prompt_ref': identifier}]})
    issued = Engine(app).start('issued')
    reopened = App(app.project, app.home)
    current = prompts.get(reopened, identifier)
    assert current['text'] == expected
    assert current['revision'] == digest(expected)
    assert current['description'] == 'Retained metadata'
    assert current['rule_codes'] == ['r1']
    assert current['contract_version'] == '2'
    assert Engine(reopened).next(issued['run_id']) == issued
    assert issued['source_prompt'] == historical[role]


@pytest.mark.parametrize('role', ['native', 'archaeology'])
def test_most_recent_whole_graph_seed_is_recognized(app, role):
    identifier = 'prompt:metaform.intake.' + role
    expected = prompts.get(app, identifier)['text']
    previous = json.loads((Path(__file__).parent / 'fixtures' / 'intake-last-whole-graph.json').read_text())[role]
    prompts.put(app, {'id': identifier, 'text': previous})
    assert prompts.get(App(app.project, app.home), identifier)['text'] == expected


@pytest.mark.parametrize('role', ['native', 'archaeology'])
def test_authored_addition_and_metadata_survive_reopening(app, role):
    identifier = 'prompt:metaform.intake.' + role
    historical = json.loads((Path(__file__).parent / 'fixtures/intake-before-actual-identities.json').read_text())
    custom = dict(prompts.get(app, identifier), name='My expert', text=historical[role] + '\nAuthored addition.', rule_codes=[])
    prompts.put(app, custom)
    stored = prompts.get(app, identifier)
    assert prompts.get(App(app.project, app.home), identifier) == stored


def test_existing_proof_snapshot_survives_without_seeding_or_upgrading_the_role(app):
    identifier = 'prompt:metaform.intake.proof'
    assert app.graph.get(identifier) is None
    historical = json.loads((Path(__file__).parent / 'fixtures/intake-before-artifact-context.json').read_text())
    prompts.put(app, {'id': identifier, 'text': historical['proof'], 'rule_codes': []})
    import_workflow(app, {'id': 'proof-history', 'steps': [{'id': 'work', 'prompt_ref': identifier}]})
    issued = Engine(app).start('proof-history')
    reopened = App(app.project, app.home)
    assert prompts.get(reopened, identifier)['text'] == historical['proof']
    assert Engine(reopened).next(issued['run_id']) == issued


def test_intake_receives_live_namespace_rules_and_preserves_authored_attachments(app):
    from metaform import rulebook
    from metaform.intake import Intake

    job = Intake(app).start()
    assert [rule['content']['rule_code'] for rule in job['rules']] == ['r1', 'r2']
    assert job['rules'][0]['content'] == rulebook.get(app, 'r1')
    assert 'program code' in job['rules'][0]['content']['priming']['context']

    identifier = 'prompt:metaform.intake.native'
    authored = dict(prompts.get(app, identifier), rule_codes=['r2'])
    prompts.put(app, authored)
    reopened = App(app.project, app.home)
    assert prompts.get(reopened, identifier)['rule_codes'] == ['r2']
    assert Intake(reopened).next(job['run_id']) == job


def test_existing_managed_intake_adopts_declared_rule_attachments(app):
    identifier = 'prompt:metaform.intake.native'
    previous = dict(prompts.get(app, identifier), rule_codes=[])
    previous['managed'] = dict(previous['managed'])
    previous['managed'].pop('rule_codes', None)
    prompts.put(app, previous)
    assert prompts.get(App(app.project, app.home), identifier)['rule_codes'] == ['r1', 'r2']


def test_multiple_managed_prompt_upgrades_commit_once_and_preserve_authored_history(tmp_path):
    from metaform.knowledge import KnowledgeStore
    from metaform.util import write_json

    home = tmp_path / 'home'
    write_json(home / 'config.json', {'auto_build': False})
    store = KnowledgeStore(home / 'service/knowledge.sqlite3')
    app = App(tmp_path / 'project', home, binding=False,
              knowledge_client=lambda selected_home, project_id: store.bind(project_id))
    previous = json.loads((Path(__file__).parent / 'fixtures/intake-before-artifact-context.json').read_text())
    expected = {}
    for role in ('native', 'archaeology'):
        identifier = 'prompt:metaform.intake.' + role
        expected[identifier] = prompts.get(app, identifier)['text']
        prompts.put(app, {'id': identifier, 'text': previous[role], 'name': 'Preserved name',
                          'description': 'Preserved metadata', 'rule_codes': ['r2']})
    custom_id = 'prompt:metaform.role.expand'
    custom = dict(prompts.get(app, custom_id), text='Authored replacement instructions', rule_codes=[])
    prompts.put(app, custom)
    custom_record = app.graph.get(custom_id)
    import_workflow(app, {'id': 'issued-before-upgrade', 'steps': [
        {'id': 'work', 'prompt_ref': 'prompt:metaform.intake.native'}]})
    issued = Engine(app).start('issued-before-upgrade')
    observations = {record['id'] for record in app.graph.export()['observations']}
    revision = store.revision

    prompts.seed(app)

    assert store.revision == revision + 1
    for identifier, text in expected.items():
        updated = prompts.get(app, identifier)
        assert updated['text'] == text
        assert updated['revision'] == digest(text)
        assert updated['name'] == 'Preserved name'
        assert updated['description'] == 'Preserved metadata'
        assert updated['rule_codes'] == ['r2']
    assert app.graph.get(custom_id) == custom_record
    assert observations <= {record['id'] for record in app.graph.export()['observations']}
    assert Engine(app).next(issued['run_id']) == issued
    assert issued['source_prompt'] == previous['native']
    prompts.seed(app)
    assert store.revision == revision + 1
