import copy
import json
from pathlib import Path

import pytest

from metaform.namespace import key
from metaform.read_model import read_snapshot


@pytest.fixture
def foundation():
    return json.loads((Path(__file__).parent / 'fixtures/foundation_v2.json').read_text())


def by_kind(result, kind):
    return [item for item in result['records'] if item['ref']['kind'] == kind]


def test_actual_inspection_does_not_expand_same_type_peers(foundation):
    foundation['elements']['demo:peer'] = {**foundation['elements']['demo:engine'], 'id': 'demo:peer', 'description': 'A different actual.'}
    foundation['bindings'].append({**foundation['bindings'][1], 'id': 'peer-binding', 'element': {**foundation['bindings'][1]['element'], 'id': 'demo:peer'}})
    result = read_snapshot(foundation, 'element.inspect', {'target': 'demo:engine'})
    assert {item['ref']['id'] for item in by_kind(result, 'element')} == {'demo:engine'}
    assert {item['ref']['id'] for item in by_kind(result, 'type')} == {'code.evaluator.connectivity', 'code.cpp'}
    neighbors = read_snapshot(foundation, 'graph.neighbors', {'target': 'demo:engine'})
    assert 'demo:peer' not in {item['ref']['id'] for item in neighbors['records']}


def test_direct_and_descendant_members_are_distinct(foundation):
    direct = read_snapshot(foundation, 'type.members', {'target': 'code.evaluator'})
    assert not direct['records']
    descendant = read_snapshot(foundation, 'type.members', {'target': 'code.evaluator', 'descendants': True})
    assert [r['ref']['id'] for r in by_kind(descendant, 'element')] == ['demo:engine']
    all_code = read_snapshot(foundation, 'type.members', {'target': 'code', 'descendants': True})
    assert len(by_kind(all_code, 'element')) == 3
    assert all_code['coverage']['selection']['available'] == 3


def test_join_keeps_receiver_purpose_and_provider_facet_together(foundation):
    result = read_snapshot(foundation, 'join.inspect', {'target': 'join:project-evaluation'})
    join = by_kind(result, 'join')[0]['value']
    assert join['receiver']['id'] == 'demo:project'
    assert join['purpose'] == 'Determine usable connectivity for the coordinated result.'
    assert join['provider_type']['id'] == 'code.evaluator.connectivity'
    assert [r['value']['ef'] for r in by_kind(result, 'type')] == ['Determines usable connectivity from supplied observations.']
    assert 'code.cpp' not in {r['ref']['id'] for r in result['records']}
    join.pop('provider_type')
    source_join = next(j for j in foundation['joins'] if j['id'] == join['id'])
    source_join.pop('provider_type')
    unresolved = read_snapshot(foundation, 'join.inspect', {'target': join['id']})
    assert any(d['code'] == 'unresolved_provider_type' for d in unresolved['diagnostics'])
    assert not by_kind(unresolved, 'type')


def test_pagination_preserves_complete_bundles_and_only_selected_record_dependencies(foundation):
    args = {'target': 'demo:project', 'limit': 1}
    pages = []
    while True:
        result = read_snapshot(foundation, 'graph.neighbors', args)
        pages.append(result)
        joins = by_kind(result, 'join')
        assert len(joins) == 1
        refs = {key(item['ref']) for item in result['records']}
        for join in joins:
            assert key(join['value']['receiver']) in refs
            assert key(join['value']['provider']) in refs
            assert key(join['value']['provider_type']) in refs
        assert {key(d['target']) for d in result['dependencies'] if d['kind'] == 'record'} == refs
        cursor = result['coverage']['next_cursor']
        if not cursor:
            break
        args['cursor'] = cursor
    complete = read_snapshot(foundation, 'graph.neighbors', {'target': 'demo:project', 'limit': 100})
    assert {key(r['ref']) for p in pages for r in p['records']} == {key(r['ref']) for r in complete['records']}
    changed = copy.deepcopy(foundation)
    changed['model']['revision'] = 'revision-2'
    with pytest.raises(ValueError, match='revision or query'):
        read_snapshot(changed, 'graph.neighbors', {'target': 'demo:project', 'cursor': pages[0]['coverage']['next_cursor']})
    with pytest.raises(ValueError, match='revision or query'):
        read_snapshot(foundation, 'graph.neighbors', {'target': 'demo:project', 'role': 'property', 'cursor': pages[0]['coverage']['next_cursor']})


def test_op_depth_and_cycles_are_semantic_steps(foundation):
    fixture = foundation['joins'][1]
    foundation['joins'].append({**fixture, 'id': 'cycle', 'receiver': fixture['provider'], 'provider': fixture['receiver'], 'provider_type': foundation['bindings'][0]['type']})
    one = read_snapshot(foundation, 'graph.traverse', {'target': 'demo:project', 'depth': 1})
    assert 'join:engine-medium' not in {r['ref']['id'] for r in by_kind(one, 'join')}
    two = read_snapshot(foundation, 'graph.traverse', {'target': 'demo:project', 'depth': 2})
    assert 'join:engine-medium' in {r['ref']['id'] for r in by_kind(two, 'join')}
    deep = read_snapshot(foundation, 'graph.traverse', {'target': 'demo:project', 'depth': 100})
    assert len(by_kind(deep, 'join')) == len(foundation['joins'])
    assert max(path['depth'] for path in deep['paths']) == 2


def test_grounding_omits_whole_bodies_with_full_handles(foundation):
    result = read_snapshot(foundation, 'model.ground', {'target': 'demo:project', 'max_chars': 100})
    assert result['coverage']['complete'] is False
    assert result['coverage']['omitted']
    for record in result['records']:
        if record['value'].get('body_omitted'):
            assert record['value']['full_content'] == record['uri']
            assert 'purpose' not in record['value']
            assert 'ef' not in record['value']
    assert result['selected_region'] == [foundation['artifact']]


def test_empty_selector_dependency_changes_when_new_members_appear(foundation):
    first = read_snapshot(foundation, 'type.members', {'target': 'code.javascript'})
    foundation['bindings'].append({**foundation['bindings'][1], 'id': 'new-binding', 'type': {'owner': 'project:illustrative', 'kind': 'type', 'id': 'code.javascript'}})
    second = read_snapshot(foundation, 'type.members', {'target': 'code.javascript'})
    assert first['dependencies'][-1]['fingerprint'] != second['dependencies'][-1]['fingerprint']


def test_namespace_envelope_pages_match_pure_browse(foundation):
    first = read_snapshot(foundation, 'namespace.browse', {'target': 'code', 'limit': 2})
    second = read_snapshot(foundation, 'namespace.browse', {'target': 'code', 'limit': 2, 'cursor': first['coverage']['next_cursor']})
    assert not {key(r['ref']) for r in first['records']} & {key(r['ref']) for r in second['records']}


def test_knowledge_keeps_origin_scope_and_explains_nonapplicability(foundation):
    target = foundation['bindings'][1]['element']
    origin = {'owner': target['owner'], 'kind': 'knowledge', 'id': 'cpp-advice',
              'subject': foundation['bindings'][2]['type'], 'layer': {'owner': target['owner'], 'kind': 'layer', 'id': 'practices'},
              'payload': 'Preserve scoped ownership.', 'freshness': 'current',
              'applicability': {'scope': {'kind': 'type', 'target': foundation['bindings'][2]['type'], 'descendants': True}}}
    foundation['knowledge'] = [origin]
    engine = read_snapshot(foundation, 'knowledge.get', {'target': target})
    advice = by_kind(engine, 'knowledge')[0]
    assert advice['explanation']['applies']
    assert advice['explanation']['origin_layer'] == origin['layer']
    assert any(r['ref']['id'] == 'binding:demo:engine:medium' for r in engine['records'])
    installer = read_snapshot(foundation, 'knowledge.explain', {'target': 'demo:installer', 'knowledge': 'cpp-advice'})
    explanation = by_kind(installer, 'knowledge')[0]['explanation']
    assert not explanation['applies']
    assert not explanation['visible_here']
    assert any(d['code'] == 'no_applicability_path' for d in installer['diagnostics'])
    visible = read_snapshot(foundation, 'knowledge.get', {'target': 'code'})
    medium_origins = [r for r in by_kind(visible, 'join') if r.get('explanation')]
    assert {r['ref']['id'] for r in medium_origins} == {'join:engine-medium', 'join:installer-medium'}
    assert all(r['explanation']['visible_here'] and not r['explanation']['applies'] for r in medium_origins)


def test_published_model_reads_match_registry_gui_and_mcp(app, foundation, monkeypatch):
    import asyncio
    from metaform.models import publish_foundation
    from metaform.portable_mcp import dispatch
    from metaform.read_model import read_model
    from metaform.registry import Registry
    from metaform.viewer import create_app
    from metaform.schemas import annotations
    def owned(value):
        if isinstance(value, dict):
            return {k: ('project:' + app.project_id if k == 'owner' and v == 'project:illustrative' else owned(v)) for k, v in value.items()}
        if isinstance(value, list):
            return [owned(v) for v in value]
        return value
    foundation = owned(foundation)
    foundation['model']['project'] = app.project_id
    model = publish_foundation(app, foundation)
    args = {'model': model, 'target': 'demo:engine'}
    expected = read_model(app, 'graph.neighbors', args)
    monkeypatch.setattr(Registry, 'after_call', _noop)
    registry = Registry(app)
    direct = asyncio.run(registry.call('graph.neighbors', args))
    from metaform.cli import run_parser
    cli = run_parser(registry, ['graph', 'neighbors', '--model', json.dumps(model), '--target', 'demo:engine'])
    modern = asyncio.run(dispatch(app, registry, 'tools/call', {'name': 'metaform', 'arguments': {'command': 'graph.neighbors', 'arguments': args}}))
    resource = asyncio.run(dispatch(app, registry, 'resources/read', {'uri': next(r['uri'] for r in expected['records'] if r['ref']['kind'] == 'join')}))
    joined = json.loads(resource['contents'][0]['text'])
    assert joined['resolved_target']['kind'] == 'join'
    binding_uri = next(r['uri'] for r in expected['records'] if r['ref']['kind'] == 'binding')
    binding_resource = asyncio.run(dispatch(app, registry, 'resources/read', {'uri': binding_uri}))
    assert json.loads(binding_resource['contents'][0]['text'])['resolved_target']['kind'] == 'binding'
    assert cli['records'] == expected['records']
    assert cli['coverage'] == expected['coverage']
    assert modern['structuredContent'] == expected
    mcp = asyncio.run(dispatch(app, registry, 'tools/call', {'name': 'graph.neighbors', 'arguments': args}))
    gui = create_app(app).test_client().post('/api/semantic/graph.neighbors', json=args)
    assert gui.status_code == 200
    assert direct == mcp['structuredContent'] == gui.json == expected
    assert not annotations(app, 'urn:metaform:schema:read-envelope:2', expected)
    app.set('disabled_commands', ['graph.neighbors'])
    with pytest.raises(ValueError, match='Unknown command'):
        asyncio.run(registry.call('graph.neighbors', args))


async def _noop(self):
    pass


def test_service_read_uses_revision_index_without_exporting_project(tmp_path, foundation, monkeypatch):
    from types import SimpleNamespace
    from metaform.knowledge import KnowledgeStore, BoundGraph
    from metaform.models import publish_foundation
    from metaform.read_model import read_model
    store = KnowledgeStore(tmp_path / 'knowledge.sqlite3')
    project = store.call(None, 'project.register', {'path': str(tmp_path / 'project')})['project_id']
    knowledge = store.bind(project)
    owner = 'project:' + project
    app = SimpleNamespace(project_id=project, knowledge=knowledge, graph=BoundGraph(knowledge, owner))
    def owned(value):
        if isinstance(value, dict):
            return {k: (owner if k == 'owner' and v == 'project:illustrative' else owned(v)) for k, v in value.items()}
        if isinstance(value, list):
            return [owned(v) for v in value]
        return value
    foundation = owned(foundation)
    foundation['model']['project'] = project
    model = publish_foundation(app, foundation)
    def forbid(*args, **kwargs):
        raise AssertionError('Semantic reads must not export the project graph')
    monkeypatch.setattr(store, '_export', forbid)
    result = read_model(app, 'graph.neighbors', {'model': model, 'target': 'demo:engine', 'limit': 1})
    assert result['coverage']['selection']['returned'] == 1
    assert len(store._model_revision_cache) == 1
    cached = next(iter(store._model_revision_cache.values()))['entity_json_obj']['snapshot']
    assert cached.incident
    repeated = read_model(app, 'graph.neighbors', {'model': model, 'target': 'demo:engine', 'limit': 1})
    assert repeated == result
    assert next(iter(store._model_revision_cache.values()))['entity_json_obj']['snapshot'] is cached


def test_recorded_expansion_opportunity_is_addressable_without_scheduling(foundation):
    foundation['expansion_opportunities'] = [{'target': foundation['artifact'], 'question': 'How does the coordinator retain state?'}]
    result = read_snapshot(foundation, 'expansion.list', {'target': 'demo:project'})
    opportunity = by_kind(result, 'expansion')[0]
    assert opportunity['value']['state'] == 'opportunity'
    assert opportunity['value']['question'] == foundation['expansion_opportunities'][0]['question']
    exact = read_snapshot(foundation, 'model.inspect', {'target': opportunity['ref']})
    assert exact['records'][0]['value'] == opportunity['value']


def test_omitted_historical_knowledge_handle_survives_regeneration(app, foundation, monkeypatch):
    import asyncio
    from metaform.layers import blindspots, regenerate_layer
    from metaform.models import publish_foundation
    from metaform.portable_mcp import dispatch
    from metaform.read_model import read_model
    from metaform.registry import Registry
    from test_knowledge_layers import finish
    foundation = json.loads(json.dumps(foundation).replace('project:illustrative', 'project:' + app.project_id))
    foundation['model']['project'] = app.project_id
    model = publish_foundation(app, foundation)
    subject = {'owner': 'project:' + app.project_id, 'kind': 'element', 'id': 'demo:engine'}
    original_payload = {'summary': 'First report. ' * 200, 'findings': []}
    complete = finish(app, blindspots(app, 'Review the engine.', subject, model), original_payload)
    ground = read_model(app, 'model.ground', {'model': model, 'target': subject, 'max_chars': 100})
    old = next(r for r in ground['records'] if r['ref']['kind'] == 'knowledge')
    assert old['value']['body_omitted']
    finish(app, regenerate_layer(app, complete['layer'], model), {'summary': 'A later report.', 'findings': []})
    monkeypatch.setattr(Registry, 'after_call', _noop)
    result = asyncio.run(dispatch(app, Registry(app), 'resources/read', {'uri': old['value']['full_content']}))
    historical = json.loads(result['contents'][0]['text'])
    assert historical['resolved_target'] == old['ref']
    assert by_kind(historical, 'knowledge')[0]['value']['payload'] == original_payload


def test_compare_target_limits_changed_records_and_incident_relations(app, foundation):
    from metaform.models import capture_model, publish_foundation
    from metaform.read_model import read_model
    foundation = json.loads(json.dumps(foundation).replace('project:illustrative', 'project:' + app.project_id))
    foundation['model']['project'] = app.project_id
    source = publish_foundation(app, foundation)
    changed = capture_model(app, source)
    changed['model']['model'] = 'variant'
    changed['elements']['demo:engine']['description'] = 'A revised engine account.'
    changed['elements']['demo:installer']['description'] = 'A separately revised installer.'
    next(j for j in changed['joins'] if j['id'] == 'join:project-evaluation')['purpose'] = 'Receive the revised evaluation.'
    next(j for j in changed['joins'] if j['id'] == 'join:project-installation')['purpose'] = 'Provision a different environment.'
    destination = publish_foundation(app, changed)
    result = read_model(app, 'model.compare', {'source': source, 'destination': destination, 'target': 'demo:engine'})
    assert {change['ref']['id'] for change in result['changes']} == {'demo:engine', 'join:project-evaluation'}
    assert result['target_scope']['kind'] == 'record_and_incident_relations'
    assert result['coverage']['returned'] == result['coverage']['available'] == 2
    assert result['resolved_target']['id'] == 'demo:engine'


def test_compare_follows_explicit_type_relocation_mapping(app, foundation):
    from metaform.models import capture_model, publish_foundation
    from metaform.read_model import read_model
    from metaform.transform import patch_snapshot
    foundation = json.loads(json.dumps(foundation).replace('project:illustrative', 'project:' + app.project_id))
    foundation['model']['project'] = app.project_id
    source = publish_foundation(app, foundation)
    before = {'owner': 'project:' + app.project_id, 'kind': 'type', 'id': 'code.evaluator.connectivity'}
    after = {**before, 'id': 'code.evaluator.network'}
    changed = patch_snapshot(capture_model(app, source), [{'op': 'relocate', 'target': before, 'replacement': after}])
    changed['model']['model'] = 'renamed'
    destination = publish_foundation(app, changed)
    mapping = [{'from': before, 'to': after, 'meaning_preserved': True, 'reason': 'Meaning-preserving address relocation.'}]
    result = read_model(app, 'model.compare', {'source': source, 'destination': destination, 'target': before, 'mapping': mapping})
    ids = {change['ref']['id'] for change in result['changes']}
    assert {'code.evaluator.connectivity', 'code.evaluator.network', 'binding:demo:engine:function', 'join:project-evaluation'} <= ids
    assert 'demo:installer' not in ids
    assert result['target_scope']['targets'] == [before, after]


def test_empty_discovery_has_no_fabricated_model_revision(app):
    from metaform.read_model import read_model
    from metaform.schemas import annotations
    result = read_model(app, 'model.discover', {})
    assert result['model'] is None
    assert result['models'] == result['records'] == []
    assert result['diagnostics'] == [{'code': 'no_foundation'}]
    assert not annotations(app, 'urn:metaform:schema:read-envelope:2', result)
    wrong = {**result, 'query': {'operation': 'graph.neighbors'}}
    assert annotations(app, 'urn:metaform:schema:read-envelope:2', wrong)


def test_source_snapshot_requires_explicit_inspection(foundation):
    raw = {'encoding': 'base64', 'bytes': 'ZXhhY3Qgc291cmNlIGJ5dGVz'}
    foundation['source_snapshots'] = [{'id': 'v1-source:fixture', 'source_context': {'source': 'archived input'}, 'snapshot': raw}]
    foundation['elements']['demo:engine']['evidence'] = [{'source': 'v1-source:fixture'}]
    ordinary = read_snapshot(foundation, 'element.inspect', {'target': 'demo:engine'})
    assert not by_kind(ordinary, 'source_snapshot')
    target = {'owner': 'project:illustrative', 'kind': 'source_snapshot', 'id': 'v1-source:fixture'}
    explicit = read_snapshot(foundation, 'model.inspect', {'target': target})
    source = by_kind(explicit, 'source_snapshot')[0]
    assert source['ref'] == target
    assert source['value']['snapshot'] == raw
    assert foundation['source_snapshots'][0] == {'id': 'v1-source:fixture', 'source_context': {'source': 'archived input'}, 'snapshot': raw}


def test_search_finds_expanded_alias_without_creating_a_type(foundation):
    from test_namespace_targets import version_types
    foundation = version_types(foundation)
    result = read_snapshot(foundation, 'model.search', {'query': 'code.cpp.11', 'kind': 'type'})
    assert [item['ref']['id'] for item in by_kind(result, 'type')] == ['code.cpp.cxx11']
    assert by_kind(result, 'type')[0]['value']['aliases'] == ['cpp11', '11']
