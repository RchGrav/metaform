import copy
import json
from pathlib import Path

import pytest

from metaform.namespace import browse_namespace, resolve_target


@pytest.fixture
def foundation():
    return json.loads((Path(__file__).parent / 'fixtures/foundation_v2.json').read_text())


def test_owner_resolution_alias_and_ambiguous_label(foundation):
    local = foundation['types']['code.cpp']
    local['aliases'] = ['code.cplusplus']
    assert resolve_target(foundation, 'code.cplusplus')['ref']['id'] == 'code.cpp'
    foundation['types']['global:code.cpp'] = {**local, 'owner': 'global', 'ef': 'Global definition.'}
    assert resolve_target(foundation, 'code.cpp')['ref']['owner'] == 'project:illustrative'
    assert resolve_target(foundation, {'kind': 'type', 'owner': 'global', 'id': 'code.cpp'})['ref']['owner'] == 'global'
    assert resolve_target(foundation, {'owner': 'project:other', 'id': 'code.cpp'})['ref'] is None
    foundation['elements']['other'] = {**foundation['elements']['demo:engine'], 'id': 'other'}
    ambiguous = resolve_target(foundation, 'Connectivity engine')
    assert ambiguous['ref'] is None
    assert len(ambiguous['diagnostics'][0]['candidates']) == 2


def test_categories_are_narrowing_relations_and_members_are_unique(foundation):
    branch = browse_namespace(foundation, 'code')
    assert {item['ref']['id'] for item in branch['records']} == {key for key in foundation['types'] if key.startswith('code.') and key.count('.') == 1}
    evaluator = next(item for item in branch['records'] if item['ref']['id'] == 'code.evaluator')
    assert evaluator['counts'] == {'direct': 0, 'descendant': 1, 'including_descendants': 1}
    assert 'category' not in evaluator['narrowings'][0]
    roots = browse_namespace(foundation)
    code = next(item for item in roots['records'] if item['ref']['id'] == 'code')
    assert code['counts']['including_descendants'] == 3
    assert 'category' not in code['value']


def test_missing_namespace_prefix_is_a_diagnostic_not_a_type(foundation):
    del foundation['types']['code.evaluator']
    branch = browse_namespace(foundation, 'code')
    assert all(item['ref']['id'] != 'code.evaluator' for item in branch['records'])
    assert any(d['code'] == 'unresolved_namespace_position' and d['id'] == 'code.evaluator' for d in branch['diagnostics'])
    assert resolve_target(foundation, 'code.evaluator')['ref'] is None


def test_namespace_cursor_retains_revision_and_filters(foundation):
    first = browse_namespace(foundation, 'code', limit=2)
    second = browse_namespace(foundation, 'code', cursor=first['coverage']['next_cursor'], limit=2)
    assert not {r['ref']['id'] for r in first['records']} & {r['ref']['id'] for r in second['records']}
    changed = copy.deepcopy(foundation)
    changed['model']['revision'] = 'next'
    with pytest.raises(ValueError, match='revision or query'):
        browse_namespace(changed, 'code', cursor=first['coverage']['next_cursor'])
    with pytest.raises(ValueError, match='revision or query'):
        browse_namespace(foundation, 'code.evaluator', cursor=first['coverage']['next_cursor'])


def test_explicit_global_parent_can_narrow_to_local_type(foundation):
    root = foundation['types']['code']
    foundation['types']['global:code'] = {**root, 'owner': 'global'}
    edge = next(n for n in foundation['narrowings'] if n['child']['id'] == 'code.cpp')
    edge['parent']['owner'] = 'global'
    result = browse_namespace(foundation, {'owner': 'global', 'kind': 'type', 'id': 'code'})
    assert [r['ref']['id'] for r in result['records']] == ['code.cpp']
    assert result['records'][0]['counts']['direct'] == 1


def test_type_name_reads_backward_by_authored_length(foundation):
    owner = 'project:illustrative'
    foundation['types']['code.system.driver.network'] = {'id': 'code.system.driver.network', 'owner': owner,
        'description': 'Network driver.', 'ef': 'Drives network operation.', 'length': 2, 'aliases': []}
    resolved = resolve_target(foundation, 'Network Driver')
    assert resolved['ref'] == {'owner': owner, 'kind': 'type', 'id': 'code.system.driver.network'}
    assert resolved['via'][0]['kind'] == 'label'
    foundation['types']['code']['display_name'] = 'Program Code'
    assert resolve_target(foundation, 'Program Code')['ref']['id'] == 'code'


def version_types(foundation):
    owner = 'project:illustrative'
    for identifier, aliases in [('code.c', []), ('code.c.c11', ['11']), ('code.cpp.cxx11', ['cpp11', '11'])]:
        foundation['types'][identifier] = {'id': identifier, 'owner': owner, 'description': identifier,
            'ef': 'Expresses the named version.', 'length': 1, 'aliases': aliases, 'parametric_elements': []}
    return foundation


@pytest.mark.parametrize('indexed', [False, True])
def test_leaf_aliases_expand_only_in_their_parent_namespace(foundation, indexed):
    from metaform.namespace import IndexedSnapshot
    foundation = version_types(foundation)
    before = copy.deepcopy(foundation['types'])
    snapshot = IndexedSnapshot(foundation) if indexed else foundation
    cpp = resolve_target(snapshot, 'code.cpp.11')
    c = resolve_target(snapshot, 'code.c.11')
    assert cpp['ref']['id'] == 'code.cpp.cxx11'
    assert c['ref']['id'] == 'code.c.c11'
    assert cpp['via'][0]['authored_alias'] == '11'
    assert resolve_target(snapshot, '11')['ref'] is None
    assert resolve_target(snapshot, '11')['diagnostics'][0]['code'] == 'ambiguous_target'
    assert foundation['types'] == before
    assert 'code.cpp.11' not in foundation['types']
    assert resolve_target(snapshot, {'owner': 'project:other', 'kind': 'type', 'id': 'code.cpp.11'})['ref'] is None


def test_alias_reservation_collision_is_local_and_annotation_only(foundation):
    from metaform.models import foundation_diagnostics, build_indexes
    foundation = version_types(foundation)
    independent = {**foundation['types']['code.c.c11'], 'id': 'code.c.11', 'aliases': []}
    foundation['types']['code.c.c11']['aliases'] = []
    foundation['types']['code.c.11'] = independent
    assert not any(d['code'] == 'reserved_namespace_collision' for d in foundation_diagnostics(foundation))
    competing = {**foundation['types']['code.cpp.cxx11'], 'id': 'code.cpp.11', 'aliases': [], 'description': 'A competing definition.'}
    foundation['types']['code.cpp.11'] = competing
    diagnostics = foundation_diagnostics(foundation)
    collision = next(d for d in diagnostics if d['code'] == 'reserved_namespace_collision')
    assert collision['address'] == {'owner': 'project:illustrative', 'kind': 'type', 'id': 'code.cpp.11'}
    assert collision['entry']['id'] == 'code.cpp.11'
    assert collision['reservations'][0]['source']['id'] == 'code.cpp.cxx11'
    assert foundation['types']['code.cpp.11'] == competing
    assert foundation['types']['code.cpp.cxx11']['aliases'] == ['cpp11', '11']
    indexes = build_indexes(foundation)
    assert indexes['aliases'][('project:illustrative', 'type', 'code.cpp.11')][0]['id'] == 'code.cpp.cxx11'
    exact = resolve_target(foundation, collision['address'])
    assert exact['ref'] == collision['address']
    assert any(d['code'] == 'reserved_namespace_collision' for d in exact['diagnostics'])


def test_parametric_reservation_is_not_a_type_or_a_global_ban(foundation):
    from metaform.models import foundation_diagnostics
    from metaform.namespace import namespace_reservations
    foundation['types']['code.cpp']['parametric_elements'] = ['timeout', 'tick_rate']
    reserved = namespace_reservations(foundation)
    address = ('project:illustrative', 'type', 'code.cpp.timeout')
    assert reserved[address][0]['kind'] == 'parametric'
    assert reserved[address][0]['source']['id'] == 'code.cpp'
    unresolved = resolve_target(foundation, 'code.cpp.timeout')
    assert unresolved['ref'] is None
    assert any(d['code'] == 'reserved_parametric_address' for d in unresolved['diagnostics'])
    assert not browse_namespace(foundation, 'code.cpp')['records']
    foundation['types']['code.shell.timeout'] = {**foundation['types']['code.shell'], 'id': 'code.shell.timeout', 'aliases': []}
    assert not any(d['code'] == 'reserved_namespace_collision' for d in foundation_diagnostics(foundation))
    foundation['types']['code.cpp.timeout'] = {**foundation['types']['code.cpp'], 'id': 'code.cpp.timeout', 'aliases': [], 'parametric_elements': []}
    collision = next(d for d in foundation_diagnostics(foundation) if d['code'] == 'reserved_namespace_collision')
    assert collision['address']['id'] == 'code.cpp.timeout'
    assert collision['reservations'][0]['kind'] == 'parametric'
    assert foundation['types']['code.cpp']['parametric_elements'] == ['timeout', 'tick_rate']


def test_alias_claims_at_another_owner_do_not_conflict(foundation):
    from metaform.models import foundation_diagnostics
    foundation = version_types(foundation)
    foundation['types']['global|code.cpp.11'] = {**foundation['types']['code.cpp.cxx11'], 'id': 'code.cpp.11', 'owner': 'global', 'aliases': []}
    assert not any(d['code'] == 'reserved_namespace_collision' for d in foundation_diagnostics(foundation))
    local = resolve_target(foundation, {'owner': 'project:illustrative', 'kind': 'type', 'id': 'code.cpp.11'})
    global_result = resolve_target(foundation, {'owner': 'global', 'kind': 'type', 'id': 'code.cpp.11'})
    assert local['ref']['id'] == 'code.cpp.cxx11'
    assert global_result['ref']['id'] == 'code.cpp.11'
    assert not local['diagnostics'] and not global_result['diagnostics']


def test_two_types_claiming_one_leaf_alias_remain_ambiguous(foundation):
    from metaform.models import foundation_diagnostics
    foundation = version_types(foundation)
    foundation['types']['code.cpp.version11'] = {**foundation['types']['code.cpp.cxx11'], 'id': 'code.cpp.version11', 'aliases': ['11']}
    resolution = resolve_target(foundation, 'code.cpp.11')
    assert resolution['ref'] is None
    assert {candidate['ref']['id'] for candidate in resolution['diagnostics'][0]['candidates']} == {'code.cpp.cxx11', 'code.cpp.version11'}
    collision = next(d for d in foundation_diagnostics(foundation) if d['code'] == 'reserved_namespace_collision')
    assert collision['address']['id'] == 'code.cpp.11'
    assert 'entry' not in collision
    assert len(collision['reservations']) == 2
