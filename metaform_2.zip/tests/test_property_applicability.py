"""Behavior witnesses for origin-preserving property scope (V10 and V12)."""
from copy import deepcopy

from metaform.properties import explain_applicability

OWNER = 'project:properties'


def ref(kind, id, owner=OWNER):
    return {'owner': owner, 'kind': kind, 'id': id}


def foundation():
    types = ['code', 'code.cpp', 'code.cpp.c20', 'code.shell', 'code.engine', 'code.installer']
    actuals = ['project', 'engine', 'installer', 'renderer', 'other']
    snapshot = {
        'schema_version': '2',
        'model': {'project': 'properties', 'model': 'demo', 'revision': 'r1'},
        'artifact': ref('element', 'project'), 'understanding': 'A mixed-medium artifact.',
        'types': {id: dict(ref('type', id), description=id, ef=f'Provides {id}.', length=1, aliases=[]) for id in types},
        'elements': {id: dict(ref('element', id), name=id, description=id, artifact=ref('element', 'project')) for id in actuals},
        'bindings': [], 'narrowings': [], 'refinements': [], 'joins': [],
    }
    for id in types[1:]:
        snapshot['narrowings'].append(dict(ref('narrowing', f'n:{id}'), parent=ref('type', id.rsplit('.', 1)[0]), child=ref('type', id), category='encounter', reason=f'{id} specializes its parent.'))
    for actual, type_id in [('engine', 'code.cpp'), ('engine', 'code.engine'), ('installer', 'code.shell'), ('installer', 'code.installer'), ('other', 'code.cpp.c20')]:
        snapshot['bindings'].append(dict(ref('binding', f'b:{actual}:{type_id}'), element=ref('element', actual), type=ref('type', type_id)))
    for actual, type_id in [('engine', 'code.cpp'), ('installer', 'code.shell')]:
        snapshot['joins'].append(dict(ref('join', f'j:{actual}:medium'), receiver=ref('element', actual), provider=ref('type', type_id), provider_type=ref('type', type_id), role='property', purpose='Realize this implementation medium.', scope={'kind': 'refinements', 'target': ref('element', actual), 'descendants': True}))
        snapshot['joins'].append(dict(ref('join', f'j:project:{actual}'), receiver=ref('element', 'project'), provider=ref('element', actual), provider_type=ref('type', f'code.{actual}'), role='hard dependency', purpose=f'Receive {actual} capability.'))
    snapshot['refinements'].append(dict(ref('refinement', 'r:engine:renderer'), parent=ref('element', 'engine'), child=ref('element', 'renderer'), reason='Rendering is a named deeper account of engine operations.'))
    return snapshot


def test_backward_visibility_does_not_restart_into_siblings():
    snapshot = foundation()
    shell, cpp = ref('join', 'j:installer:medium'), ref('join', 'j:engine:medium')
    for origin in [shell, cpp]:
        trunk = explain_applicability(snapshot, ref('type', 'code'), origin, [])
        assert trunk['visible_here'] and not trunk['applies']
        assert trunk['origin'] == origin
        assert trunk['visibility_path']
        assert explain_applicability(snapshot, snapshot['artifact'], origin, [])['visible_here']
    assert not explain_applicability(snapshot, ref('element', 'engine'), shell, [])['applies']
    assert not explain_applicability(snapshot, ref('element', 'other'), cpp, [])['applies']
    renderer = explain_applicability(snapshot, ref('element', 'renderer'), cpp, [])
    assert renderer['applies']
    assert [step['relation']['id'] for step in renderer['path']] == ['j:engine:medium', 'r:engine:renderer']
    snapshot['joins'][0]['scope']['descendants'] = False
    assert not explain_applicability(snapshot, ref('element', 'renderer'), cpp, [])['applies']


def test_unrecorded_refinement_and_shared_type_cannot_supply_a_path():
    snapshot = foundation()
    snapshot['refinements'] = []
    result = explain_applicability(snapshot, ref('element', 'renderer'), ref('join', 'j:engine:medium'), [])
    assert not result['applies'] and not result['path']
    assert result['origin']['id'] == 'j:engine:medium'
    assert result['diagnostics']


def test_property_joins_are_transitive_and_preserve_join_context():
    snapshot = foundation()
    origin = snapshot['joins'][0]
    direct = explain_applicability(snapshot, ref('element', 'engine'), origin, [])
    assert direct['applies'] and direct['visible_here']
    assert direct['path'][0]['purpose'] == 'Realize this implementation medium.'
    assert 'is_soft' not in direct['path'][0] and 'classification' not in direct['path'][0]
    assert explain_applicability(snapshot, ref('join', origin['id']), origin, [])['applies']
    assert explain_applicability(snapshot, ref('element', 'renderer'), origin, [])['applies']
    assert explain_applicability(snapshot, snapshot['artifact'], origin, [])['visible_here']


def test_direct_type_knowledge_stays_at_attachment_point():
    snapshot = foundation()
    attachment = dict(ref('knowledge', 'contextual-cpp'), subject=ref('type', 'code.cpp'),
                      payload=['Manage the engine resources through RAII.'],
                      applicability={'scope': {'kind': 'direct', 'target': ref('type', 'code.cpp')},
                                     'relation_refs': [ref('join', 'j:engine:medium')]})
    assert explain_applicability(snapshot, attachment['subject'], attachment, [])['applies']
    for subject in [ref('element', 'engine'), ref('type', 'code.cpp.c20'),
                    ref('element', 'other'), ref('type', 'code')]:
        result = explain_applicability(snapshot, subject, attachment, [])
        assert not result['applies'] and not result['visible_here']
    assert explain_applicability(snapshot, ref('knowledge', attachment['id']), attachment, [attachment])['applies']
    attachment['applicability']['scope'] = {}
    for subject in [ref('element', 'engine'), ref('type', 'code.cpp.c20'), ref('element', 'other')]:
        assert explain_applicability(snapshot, subject, attachment, [])['applies']


def test_join_context_is_limited_to_declared_meeting_despite_cycle():
    snapshot = foundation()
    first = dict(ref('join', 'j:adapter:consumer'), receiver=ref('element', 'engine'), provider=ref('element', 'installer'), provider_type=ref('type', 'code.installer'), purpose='Consume compatible protocol messages.', role='hard dependency', signal='Matching protocol messages')
    second = dict(first, id='j:unrelated', receiver=ref('element', 'other'), provider=ref('element', 'engine'))
    third = dict(first, id='j:cycle', receiver=ref('element', 'installer'), provider=ref('element', 'other'))
    snapshot['joins'] += [first, second, third]
    attachment = dict(ref('knowledge', 'compatibility'), subject=ref('join', first['id']), payload={'recommendation': 'Preserve the protocol boundary.'}, applicability={'scope': {'kind': 'neighbors', 'target': ref('join', first['id']), 'depth': 1}, 'reason': 'This adapter/consumer protocol meeting.', 'relation_refs': [ref('join', first['id'])]}, dependencies=[])
    before = deepcopy(snapshot)
    result = explain_applicability(snapshot, ref('element', 'engine'), attachment, [])
    assert result['applies']
    assert result['path'][0]['purpose'] == first['purpose']
    assert result['path'][0]['signal'] == first['signal']
    assert not explain_applicability(snapshot, ref('element', 'other'), attachment, [])['applies']
    assert snapshot == before
    attachment['applicability']['relation_refs'] = []
    assert not explain_applicability(snapshot, ref('element', 'engine'), attachment, [])['applies']


def test_qualified_refs_and_narrowing_cycle_diagnostics():
    snapshot = foundation()
    snapshot['narrowings'].append(dict(ref('narrowing', 'n:cycle'), parent=ref('type', 'code.cpp.c20'), child=ref('type', 'code'), category='encounter', reason='Contradictory imported cycle.'))
    origin = ref('join', 'j:engine:medium')
    result = explain_applicability(snapshot, ref('type', 'code'), origin, [])
    cycles = [d for d in result['diagnostics'] if d['code'] == 'narrowing_cycle']
    assert cycles
    assert {r['id'] for r in cycles[0]['relations']} == {'n:code.cpp', 'n:code.cpp.c20', 'n:cycle'}
    wrong_owner = explain_applicability(snapshot, ref('element', 'engine', 'project:other'), origin, [])
    assert not wrong_owner['applies']
    assert any(d['code'] == 'unresolved_subject' for d in wrong_owner['diagnostics'])
