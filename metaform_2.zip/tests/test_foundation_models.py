import copy
from types import SimpleNamespace

import pytest

from metaform.backends import JSONGraph
from metaform.knowledge import KnowledgeError, KnowledgeStore, LocalKnowledge
from metaform.models import build_indexes, capture_model, list_models, publish_foundation


@pytest.fixture(params=['sqlite', 'portable'])
def model_app(request, tmp_path):
    project = 'example'
    if request.param == 'sqlite':
        store = KnowledgeStore(tmp_path / 'knowledge.sqlite3')
        project = store.call(None, 'project.register', {'path': str(tmp_path / 'project')})['project_id']
        knowledge = store.bind(project)
    else:
        knowledge = LocalKnowledge(project, JSONGraph(tmp_path / 'project.json'), JSONGraph(tmp_path / 'global.json'))
    return SimpleNamespace(project_id=project, knowledge=knowledge)


def foundation(app):
    owner = 'project:' + app.project_id
    def ref(kind, identifier):
        return {'owner': owner, 'kind': kind, 'id': identifier}
    return {
        'schema_version': '2', 'model': {'project': app.project_id, 'model': 'fixture'},
        'artifact': ref('element', 'demo:project'), 'understanding': 'Coordinates evaluation.',
        'types': {
            'code': {'owner': owner, 'id': 'code', 'description': 'Executable instructions.', 'ef': 'Directs execution.', 'length': 1, 'aliases': []},
            'code.evaluator': {'owner': owner, 'id': 'code.evaluator', 'description': 'An evaluator determines a result.', 'ef': 'Determines a result.', 'length': 1, 'aliases': []},
        },
        'elements': {i: {'owner': owner, 'id': i, 'name': i, 'description': d, 'artifact': ref('element', 'demo:project')} for i, d in [('demo:project', 'Coordinates evaluation.'), ('demo:engine', 'Evaluates observations.'), ('demo:consumer', 'Receives evaluation.')]},
        'bindings': [{'id': 'binding:engine', 'owner': owner, 'element': ref('element', 'demo:engine'), 'type': ref('type', 'code.evaluator')}],
        'narrowings': [{'id': 'narrowing:evaluator', 'owner': owner, 'parent': ref('type', 'code'), 'child': ref('type', 'code.evaluator'), 'category': 'function', 'reason': 'Narrows to evaluation.'}],
        'refinements': [],
        'joins': [{'id': 'join:' + receiver, 'owner': owner, 'receiver': ref('element', receiver), 'provider': ref('element', 'demo:engine'), 'provider_type': ref('type', 'code.evaluator'), 'purpose': purpose, 'role': 'hard dependency'} for receiver, purpose in [('demo:project', 'Compose the result.'), ('demo:consumer', 'Decide the next action.')]],
    }


def test_publish_preserves_semantics_and_immutable_revisions(model_app):
    source = foundation(model_app)
    original = copy.deepcopy(source)
    first = publish_foundation(model_app, source)
    before = capture_model(model_app, first)
    assert source == original
    assert before['joins'] == source['joins']
    assert len(before['bindings']) == 1
    changed = copy.deepcopy(before)
    changed['types']['code.evaluator']['ef'] = 'Determines an updated result.'
    second = publish_foundation(model_app, changed, base=first)
    assert first != second
    assert capture_model(model_app, first) == before
    assert capture_model(model_app)['model'] == second
    assert list_models(model_app) == [second]
    with pytest.raises(KnowledgeError) as error:
        publish_foundation(model_app, changed, base=first)
    assert error.value.code == 'revision_conflict'
    assert capture_model(model_app)['model'] == second


def test_requirement_classification_is_open_and_optional_flag_is_retained(model_app):
    source = foundation(model_app)
    source['joins'][0].update(role='hard dependency', classification='environment', is_soft=True)
    source['joins'][1].update(role='hard dependency', classification='Owner-supplied category', is_soft=False)
    result = capture_model(model_app, publish_foundation(model_app, source))
    assert result['joins'] == source['joins']
    assert not result['diagnostics']


def test_presentation_has_separate_structural_fingerprint(model_app):
    first = publish_foundation(model_app, foundation(model_app))
    before = capture_model(model_app, first)
    changed = copy.deepcopy(before)
    changed['types']['code']['presentation'] = {'svg': '<svg />'}
    second = publish_foundation(model_app, changed, base=first)
    after = capture_model(model_app, second)
    assert first != second
    assert before['structural_hash'] == after['structural_hash']
    assert 'presentation' not in capture_model(model_app, first)['types']['code']


def test_missing_meaning_is_diagnostic_and_owner_does_not_fall_back(model_app):
    draft = foundation(model_app)
    del draft['joins'][0]['provider_type']
    draft['joins'][1]['provider_type']['owner'] = 'project:unrelated'
    result = capture_model(model_app, publish_foundation(model_app, draft))
    assert 'provider_type' not in result['joins'][0]
    assert any(d['path'] == ['joins', 0] and 'provider_type' in d['message'] for d in result['diagnostics'])
    assert any(d['code'] == 'unresolved_reference' and d['path'] == ['joins', 1, 'provider_type'] for d in result['diagnostics'])
    indexes = build_indexes(result)
    key = ('project:' + model_app.project_id, 'element', 'demo:engine')
    assert len(indexes['incident_joins'][key]) == 2
    assert len(indexes['element_bindings'][key]) == 1


def test_portable_knowledge_closure_retains_revision_history(model_app, tmp_path):
    first = publish_foundation(model_app, foundation(model_app))
    changed = capture_model(model_app, first)
    changed['understanding'] = 'A revised account.'
    second = publish_foundation(model_app, changed, base=first)
    closure = model_app.knowledge.call('knowledge.snapshot', {})
    portable = LocalKnowledge(model_app.project_id, JSONGraph(tmp_path / 'restored.json'), JSONGraph(tmp_path / 'restored-global.json'))
    portable.call('graph.import', {'graph': closure['project']})
    restored = SimpleNamespace(project_id=model_app.project_id, knowledge=portable)
    assert capture_model(restored, first)['understanding'] == 'Coordinates evaluation.'
    assert capture_model(restored)['model'] == second


def test_bundled_fragment_references_are_self_contained(app):
    from jsonschema import Draft202012Validator
    from metaform.schemas import bundled
    schema = bundled(app, {'type': 'object', 'properties': {'target': {'$ref': 'urn:metaform:schema:foundation:2#/$defs/Ref'}, 'snapshot': {'$ref': 'urn:metaform:schema:foundation:2'}}, 'required': ['target', 'snapshot']})
    value = foundation(app)
    value['model']['revision'] = 'fixture'
    validator = Draft202012Validator(schema)
    assert not list(validator.iter_errors({'target': value['artifact'], 'snapshot': value}))
    invalid = copy.deepcopy(value)
    del invalid['joins'][0]['provider_type']
    errors = list(validator.iter_errors({'target': {'id': 'missing-owner'}, 'snapshot': invalid}))
    assert {tuple(e.absolute_path) for e in errors} >= {('target',), ('snapshot', 'joins', 0)}


def test_identical_type_spelling_at_distinct_owners_stays_distinct(model_app):
    snapshot = foundation(model_app)
    external = copy.deepcopy(snapshot['types']['code.evaluator'])
    external['owner'] = 'global'
    external['ef'] = 'A distinct global definition.'
    snapshot['types']['global|code.evaluator'] = external
    captured = capture_model(model_app, publish_foundation(model_app, snapshot))
    indexes = build_indexes(captured)
    assert indexes['records'][('global', 'type', 'code.evaluator')]['ef'] == external['ef']
    assert indexes['records'][('project:' + model_app.project_id, 'type', 'code.evaluator')]['ef'] == 'Determines a result.'
    assert captured['joins'][0]['provider_type']['owner'] == 'project:' + model_app.project_id


def test_schema_fragment_can_be_the_requested_root(app):
    from jsonschema import Draft202012Validator
    from metaform.schemas import annotations, bundled
    identifier = 'urn:metaform:schema:coarse-intake:2#/$defs/IntakeContribution'
    schema = bundled(app, identifier)
    assert not list(Draft202012Validator(schema).iter_errors({}))
    assert not annotations(app, identifier, {})


def test_concurrent_publication_detects_competing_revisions(model_app):
    from concurrent.futures import ThreadPoolExecutor
    first = publish_foundation(model_app, foundation(model_app))
    source = capture_model(model_app, first)

    def publish(account):
        changed = copy.deepcopy(source)
        changed['understanding'] = account
        try:
            return publish_foundation(model_app, changed, base=first)
        except KnowledgeError as error:
            return error.code

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(publish, ['First competing account.', 'Second competing account.']))
    assert results.count('revision_conflict') == 1
    published = next(result for result in results if isinstance(result, dict))
    assert capture_model(model_app)['model'] == published
    assert capture_model(model_app, first) == source


def test_multitype_provider_preserves_each_receiver_purpose_and_facet(model_app):
    source = foundation(model_app)
    second_binding = copy.deepcopy(source['bindings'][0])
    second_binding['id'] = 'binding:engine:execution'
    second_binding['type']['id'] = 'code'
    source['bindings'].append(second_binding)
    source['joins'][1]['provider_type']['id'] = 'code'
    result = capture_model(model_app, publish_foundation(model_app, source))
    assert result['joins'] == source['joins']
    assert len(result['elements']) == len(source['elements'])
    assert len(result['bindings']) == 2
    assert not result['diagnostics']


def test_reused_global_type_is_frozen_in_the_published_revision(model_app):
    universal = {'entity_schema': 'metaform:element', 'entity_desc': 'Reusable evaluator.', 'entity_json_obj': {'ef': 'Produces a reusable evaluation.', 'length': 1, 'aliases': []}}
    model_app.knowledge.call('graph.put', {'owner': 'global', 'graph': {'elements': {'code.evaluator': universal}}, 'source': 'authored'})
    source = foundation(model_app)
    del source['types']['code.evaluator']
    source['narrowings'] = []
    source['bindings'][0]['type']['owner'] = 'global'
    for join in source['joins']:
        join['provider_type']['owner'] = 'global'
    model = publish_foundation(model_app, source)
    captured = capture_model(model_app, model)
    assert captured['types']['code.evaluator']['owner'] == 'global'
    assert captured['types']['code.evaluator']['ef'] == universal['entity_json_obj']['ef']
    universal['entity_json_obj']['ef'] = 'Changed in the mutable registry.'
    model_app.knowledge.call('graph.put', {'owner': 'global', 'graph': {'elements': {'code.evaluator': universal}}, 'source': 'authored'})
    assert capture_model(model_app, model) == captured


def test_record_revision_pins_are_diagnosed_without_inventing_a_match(model_app):
    source = foundation(model_app)
    source['types']['code.evaluator']['revision'] = 'type-v2'
    source['bindings'][0]['type']['revision'] = 'type-v1'
    result = capture_model(model_app, publish_foundation(model_app, source))
    assert any(d['code'] == 'reference_revision_mismatch' and d['path'] == ['bindings', 0, 'type'] for d in result['diagnostics'])
    assert not any(d['code'] == 'unbound_provider_type' for d in result['diagnostics'])
    assert result['bindings'][0]['type']['revision'] == 'type-v1'
    del source['types']['code.evaluator']
    result = capture_model(model_app, publish_foundation(model_app, source))
    assert 'code.evaluator' not in result['types']
    assert any(d['code'] == 'unresolved_reference' for d in result['diagnostics'])


def test_bundled_registered_anchor_is_self_contained(app):
    from jsonschema import Draft202012Validator
    from metaform.schemas import bundled, register
    register(app, {'$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': 'urn:demo:anchored', '$defs': {'Value': {'$anchor': 'Value', 'type': 'string'}}})
    validator = Draft202012Validator(bundled(app, {'$ref': 'urn:demo:anchored#Value'}))
    assert not list(validator.iter_errors('value'))
    assert list(validator.iter_errors(42))


def test_expected_absent_publish_does_not_overwrite_a_concurrent_model(model_app):
    from concurrent.futures import ThreadPoolExecutor
    source = foundation(model_app)

    def create(account):
        draft = copy.deepcopy(source)
        draft['understanding'] = account
        try:
            return publish_foundation(model_app, draft, base=False)
        except KnowledgeError as error:
            return error.code

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(create, ['First model.', 'Competing model.']))
    assert results.count('revision_conflict') == 1
    published = next(result for result in results if isinstance(result, dict))
    assert capture_model(model_app)['model'] == published


def test_narrowing_parent_mismatch_is_an_annotation(model_app):
    source = foundation(model_app)
    source['narrowings'][0]['parent']['id'] = 'code.evaluator'
    result = capture_model(model_app, publish_foundation(model_app, source))
    issue = next(d for d in result['diagnostics'] if d['code'] == 'narrowing_parent_mismatch')
    assert issue['expected_parent'] == 'code'
    assert issue['path'] == ['narrowings', 0, 'parent']
    assert result['narrowings'] == source['narrowings']


def test_reserved_alias_collision_is_retained_with_diagnostics(model_app):
    snapshot = foundation(model_app)
    snapshot['types']['code.evaluator']['aliases'] = ['evaluate']
    snapshot['types']['code.evaluate'] = {**snapshot['types']['code.evaluator'], 'id': 'code.evaluate', 'aliases': []}
    model = publish_foundation(model_app, snapshot)
    captured = capture_model(model_app, model)
    assert captured['types']['code.evaluator']['aliases'] == ['evaluate']
    assert captured['types']['code.evaluate'] == snapshot['types']['code.evaluate']
    diagnostic = next(d for d in captured['diagnostics'] if d['code'] == 'reserved_namespace_collision')
    assert diagnostic['address']['id'] == 'code.evaluate'
