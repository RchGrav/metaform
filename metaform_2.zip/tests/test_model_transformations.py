import copy

import pytest

from metaform.models import capture_model, publish_foundation


def foundation(app):
    owner = 'project:' + app.project_id
    ref = lambda kind, identifier: {'owner': owner, 'kind': kind, 'id': identifier}
    artifact = ref('element', 'demo:engine')
    types = {name: {'id': name, 'owner': owner, 'description': name, 'ef': purpose,
                    'length': 1, 'aliases': []} for name, purpose in (
        ('code.cpp', 'Express program operations'), ('code.shell', 'Express shell operations'))}
    elements = {name: {'id': name, 'owner': owner, 'name': name, 'description': name,
                       'artifact': artifact} for name in ('demo:engine', 'demo:installer')}
    bindings = [{'id': 'binding:' + name, 'owner': owner, 'element': ref('element', name),
                 'type': ref('type', language)} for name, language in (
        ('demo:engine', 'code.cpp'), ('demo:installer', 'code.shell'))]
    joins = [{'id': 'join:engine-medium', 'owner': owner, 'receiver': artifact,
              'provider': ref('type', 'code.cpp'), 'provider_type': ref('type', 'code.cpp'),
              'purpose': 'Implement engine operations', 'role': 'property'}]
    return {'schema_version': '2', 'model': {'project': app.project_id, 'model': 'source', 'revision': ''},
            'artifact': artifact, 'understanding': 'An engine with a shell installer.', 'types': types,
            'elements': elements, 'bindings': bindings, 'joins': joins, 'narrowings': [], 'refinements': []}


def test_relocation_moves_structured_facets_and_preserves_source_and_prose(app):
    from metaform.transform import apply_transformation

    original = foundation(app)
    original['types']['code.cpp']['description'] = 'The original code.cpp description stays verbatim.'
    source = publish_foundation(app, original)
    owner = 'project:' + app.project_id
    old = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    new = old | {'id': 'code.cxx'}
    result = apply_transformation(app, {'id': 'move-cpp', 'source': source, 'destination_model': 'variant',
        'purpose': 'Relocate the same Type', 'operations': [
            {'op': 'relocate', 'target': old, 'replacement': new, 'reason': 'Meaning preserved'}],
        'mapping': [{'from': old, 'to': new, 'meaning_preserved': True, 'reason': 'Meaning preserved'}]})
    destination = capture_model(app, result['model'])
    assert 'code.cpp' in capture_model(app, source)['types']
    assert 'code.cpp' not in destination['types']
    assert destination['types']['code.cxx']['description'] == original['types']['code.cpp']['description']
    assert 'code.cpp' in destination['types']['code.cxx']['aliases']
    assert destination['bindings'][0]['type'] == new
    assert destination['joins'][0]['provider_type'] == destination['joins'][0]['provider'] == new
    assert destination['bindings'][1] == original['bindings'][1]
    assert destination['diagnostics'] == []


def test_nonoverlapping_patch_replays_and_conflicting_patch_names_record(app):
    from metaform.transform import apply_transformation

    original = foundation(app)
    original['elements']['demo:engine']['evidence'] = [{'source': 'Retained source evidence'}]
    source = publish_foundation(app, original)
    changed = copy.deepcopy(original)
    changed['elements']['demo:installer']['description'] = 'A refined installer account'
    publish_foundation(app, changed, base=source)
    target = {'owner': 'project:' + app.project_id, 'kind': 'element', 'id': 'demo:engine'}
    patch = {'id': 'refine-engine', 'source': source, 'destination_model': 'source', 'purpose': 'Refine engine',
             'operations': [{'op': 'update', 'target': target, 'record': original['elements']['demo:engine'] |
                            {'description': 'A refined engine account'}, 'reason': 'Better account'}], 'mapping': []}
    result = apply_transformation(app, patch)
    current = capture_model(app, result['model'])
    assert current['elements']['demo:installer']['description'] == 'A refined installer account'
    assert current['elements']['demo:engine']['description'] == 'A refined engine account'
    assert current['elements']['demo:engine']['evidence'] == original['elements']['demo:engine']['evidence']
    patch['id'] = 'conflicting-engine'
    patch['operations'][0]['record']['description'] = 'A competing engine account'
    with pytest.raises(ValueError, match='demo:engine'):
        apply_transformation(app, patch)


def test_branch_relocation_into_old_subtree_maps_each_reference_once(app):
    from metaform.transform import patch_snapshot

    original = foundation(app)
    original['types']['code.cpp.standard'] = original['types']['code.cpp'] | {'id': 'code.cpp.standard'}
    old = original['bindings'][0]['type']
    new = old | {'id': 'code.cpp.standard'}
    original['narrowings'] = [{'id': 'standard-placement', 'owner': old['owner'],
        'parent': old, 'child': new, 'category': 'encounter', 'reason': 'A specific standard'}]
    before = copy.deepcopy(original)

    moved = patch_snapshot(original, [{'op': 'relocate', 'target': old, 'replacement': new}])

    assert moved['bindings'][0]['type'] == new
    assert moved['joins'][0]['provider'] == moved['joins'][0]['provider_type'] == new
    assert moved['narrowings'][0]['parent'] == new
    assert moved['narrowings'][0]['child'] == new | {'id': 'code.cpp.standard.standard'}
    assert {'code.cpp.standard', 'code.cpp.standard.standard'} <= moved['types'].keys()
    assert original == before


def generate_advice(app, model, subject, request):
    from metaform.layers import create_layer
    from metaform.workflow import Engine

    job = create_layer(app, request, target=subject, model=model)
    schema = {'$id': 'urn:test:transformation-advice', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string'}
    design = {'name': request, 'description': request, 'schema_ref': schema['$id'], 'schema': schema,
              'selector': {'kind': 'target', 'target': subject}, 'groups': [{'subjects': [subject], 'purpose': request}]}
    Engine(app).submit(job['run_id'], job['request_id'], design)
    job = Engine(app).next(job['run_id'])
    Engine(app).submit(job['run_id'], job['request_id'], {'attachments': [{
        'subject': subject, 'payload': request, 'schema_ref': schema['$id'], 'slot': 'advice',
        'applicability': {'scope': {'kind': 'direct', 'target': subject}, 'reason': request}}]})
    return Engine(app).next(job['run_id'])['layer']


def test_changed_engine_context_preserves_installer_advice_and_original_request(app):
    from metaform.layers import active_attachments, inspect_layer, regenerate_layer
    from metaform.transform import apply_transformation

    original = foundation(app)
    source = publish_foundation(app, original)
    owner = 'project:' + app.project_id
    engine = {'owner': owner, 'kind': 'element', 'id': 'demo:engine'}
    installer = engine | {'id': 'demo:installer'}
    request = 'Explain {{ literal }} engine practices.\nKeep the question exactly.'
    engine_layer = generate_advice(app, source, engine, request)
    installer_layer = generate_advice(app, source, installer, 'Explain installer practices.')
    source_advice = active_attachments(app, source)
    result = apply_transformation(app, {'id': 'new-engine-meaning', 'source': source, 'destination_model': 'changed',
        'purpose': 'Change engine Type meaning', 'operations': [{'op': 'update',
            'target': {'owner': owner, 'kind': 'type', 'id': 'code.cpp'},
            'record': original['types']['code.cpp'] | {'ef': 'Express a changed set of operations'},
            'reason': 'The represented meaning changes'}], 'mapping': []})
    decisions = {item['layer']['id']: item['action'] for item in result['impact']['decisions']}
    assert decisions[engine_layer['id']] == 'regenerate'
    assert decisions[installer_layer['id']] == 'preserve'
    assert active_attachments(app, source) == source_advice
    assert [item['layer']['id'] for item in active_attachments(app, result['model'])] == [installer_layer['id']]
    job = regenerate_layer(app, engine_layer, result['model'], engine)
    assert job['inputs']['request'] == request
    assert inspect_layer(app, engine_layer, result['model'])['recipe']['request'] == request


def test_new_matching_relationship_invalidates_negative_context(app):
    from metaform.transform import apply_transformation

    original = foundation(app)
    source = publish_foundation(app, original)
    engine = original['artifact']
    layer = generate_advice(app, source, engine, 'Examine recovery relationships.')
    record = original['joins'][0] | {'id': 'join:recovery', 'purpose': 'Recover the operation', 'role': 'supportive'}
    result = apply_transformation(app, {'id': 'recovery-added', 'source': source, 'destination_model': 'recovery',
        'purpose': 'Record the recovery relationship', 'operations': [{'op': 'add',
            'target': {'owner': engine['owner'], 'kind': 'join', 'id': record['id']},
            'record': record, 'reason': 'Recovery is now represented'}], 'mapping': []})
    decision = next(item for item in result['impact']['decisions'] if item['layer'] == layer)
    assert decision['action'] == 'regenerate'
    assert any('selector' in reason for reason in decision['reasons'])


def test_branch_relocation_preserves_descendants_with_explicit_new_placement(app):
    from metaform.transform import apply_transformation

    original = foundation(app)
    owner = original['artifact']['owner']
    ref = lambda identifier: {'owner': owner, 'kind': 'type', 'id': identifier}
    for identifier in ('code', 'code.language', 'code.cpp.standard'):
        original['types'][identifier] = original['types']['code.cpp'] | {'id': identifier}
    root = {'id': 'place-cpp', 'owner': owner, 'parent': ref('code'), 'child': ref('code.cpp'),
            'category': 'encounter', 'reason': 'Represent this implementation medium.'}
    child = root | {'id': 'place-standard', 'parent': ref('code.cpp'), 'child': ref('code.cpp.standard')}
    original['narrowings'] = [root, child]
    source = publish_foundation(app, original)
    result = apply_transformation(app, {'id': 'place-language', 'source': source, 'destination_model': 'placed',
        'purpose': 'Place the language branch', 'operations': [
            {'op': 'relocate', 'target': ref('code.cpp'), 'replacement': ref('code.language.cpp'), 'reason': 'Move this branch'},
            {'op': 'update', 'target': {'owner': owner, 'kind': 'narrowing', 'id': root['id']},
             'record': root | {'parent': ref('code.language'), 'child': ref('code.language.cpp'),
                               'reason': 'The language is a more specific implementation medium.'},
             'reason': 'Describe the new placement explicitly'}],
        'mapping': [{'from': ref('code.cpp'), 'to': ref('code.language.cpp'), 'meaning_preserved': True, 'reason': 'Meaning-preserving branch move'}]})
    after = capture_model(app, result['model'])
    assert 'code.language.cpp.standard' in after['types']
    assert 'code.cpp.standard' not in after['types']
    assert not after['diagnostics']
    assert next(n for n in after['narrowings'] if n['id'] == child['id'])['parent'] == ref('code.language.cpp')


def test_interrupted_variant_transfer_resumes_without_losing_source_advice(app, monkeypatch):
    from metaform import layers
    from metaform.transform import apply_transformation

    original = foundation(app)
    source = publish_foundation(app, original)
    generate_advice(app, source, original['artifact'], 'Explain the engine.')
    source_advice = layers.active_attachments(app, source)
    patch = {'id': 'resume-transfer', 'source': source, 'destination_model': 'resumed',
             'purpose': 'Clone the foundation', 'operations': [], 'mapping': []}
    transfer = layers.associate_destination
    def interrupted(*args, **kwargs):
        raise RuntimeError('Simulated interruption after foundation publication')
    monkeypatch.setattr(layers, 'associate_destination', interrupted)
    with pytest.raises(RuntimeError, match='Simulated interruption'):
        apply_transformation(app, patch)
    monkeypatch.setattr(layers, 'associate_destination', transfer)
    result = apply_transformation(app, patch)
    assert layers.active_attachments(app, result['model']) == source_advice
    assert layers.active_attachments(app, source) == source_advice
    assert apply_transformation(app, patch)['model'] == result['model']


def test_namespace_impact_compares_the_requested_selection(app):
    from metaform.transform import selector_fingerprint

    before = foundation(app)
    owner = before['artifact']['owner']
    before['types']['code'] = before['types']['code.cpp'] | {'id': 'code'}
    after = copy.deepcopy(before)
    after['types']['code.zzz'] = before['types']['code.cpp'] | {'id': 'code.zzz'}
    selector = {'kind': 'namespace.browse', 'target': {'owner': owner, 'kind': 'type', 'id': 'code'}}
    assert selector_fingerprint(before, selector) != selector_fingerprint(after, selector)
