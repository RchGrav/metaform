"""Executable dependencies remain usable across shared and portable forms."""
from pathlib import Path

from metaform import prompts, schemas
from metaform.util import write_json
from metaform.workflow import Engine, import_workflow


def test_workflow_attachments_replace_projection_without_changing_source(app):
    document = {'id': 'inspect', 'attachments': [{'ref': 'X', 'owner': 'global'}],
                'steps': [{'id': 'act', 'prompt': 'Inspect', 'attachments': ['Y']}]}
    import_workflow(app, document)
    joins = app.graph.joins(category='workflow_attachment')
    assert {(j['object_id'], j['element_id']) for j in joins} == {
        ('workflow:inspect', 'X'), ('workflow:inspect:act', 'Y')}
    global_join = next(j for j in joins if j['element_id'] == 'X')
    assert global_join['participants'][1]['owner'] == 'global'
    assert app.graph.get('workflow:inspect')['entity_json_obj'] == document
    app.graph.put({'joins': [{'object_id': 'workflow:inspect', 'element_id': 'Z',
                              'type': 'workflow_attachment', 'purpose': 'Independent native purpose'}]}, 'native')
    import_workflow(app, {'id': 'inspect', 'steps': [{'id': 'act', 'prompt': 'Inspect'}]})
    assert app.graph.joins(category='workflow_attachment', scope='authored') == []
    assert app.graph.joins(category='workflow_attachment', scope='native')[0]['purpose'] == 'Independent native purpose'


def test_new_workflow_uses_captured_file_prompt_without_rewriting_source(app, tmp_path):
    original = tmp_path / 'external' / 'instruction.txt'
    original.parent.mkdir()
    original.write_text('Inspect {{subject}}')
    prompts.put(app, {'id': 'prompt:external', 'text': 'file:' + str(original)})
    import_workflow(app, {'id': 'external', 'steps': [
        {'id': 'act', 'prompt_ref': 'prompt:external'}]})
    captured = app.home / 'resources' / 'workflows' / 'revision' / 'instruction.txt'
    captured.parent.mkdir(parents=True)
    captured.write_text(original.read_text())
    write_json(app.home / 'resources.json', {str(original): str(captured.relative_to(app.home))})
    original.unlink()
    run = Engine(app).start('external', {'subject': 'interfaces'}, exclusive=False)
    job = Engine(app).next(run['run_id'])
    assert job['prompt'] == 'Inspect interfaces'
    assert prompts.get(app, 'prompt:external')['text'] == 'file:' + str(original)


def test_registered_schema_scope_and_portable_registry(app):
    from metaform.knowledge import LocalKnowledge
    app.project_id = 'A'
    app.knowledge = LocalKnowledge('A', app.graph, app.global_graph)
    app.knowledge_mode = 'portable'
    shared = {'$id': 'test:shared', 'type': 'string'}
    local = {'$id': 'test:local', 'type': 'integer'}
    schemas.register(app, shared)
    schemas.register(app, local, owner='project:A')
    assert schemas.registry(app)['test:shared'] == shared
    assert schemas.registry(app)['test:local'] == local
    assert app.knowledge.call('schema.list', {'owner': 'global'}) == {'test:shared': shared}


def test_prompt_preparation_reaches_shared_relation_and_preserves_owner_views(app):
    def element(label):
        return {'entity_desc': label, 'entity_schema': 'metaform:element',
                'entity_json_obj': {'en': label}}
    app.graph.put({'elements': {'X': element('local X')}})
    app.global_graph.put({'elements': {'X': element('shared X'), 'Y': element('shared Y')},
                          'joins': [{'object_id': 'X', 'element_id': 'Y', 'type': 'uses'}]},
                         'archaeology')
    prompts.put(app, {'id': 'prompt:inspect', 'text': 'Inspect the selected form'})
    prepared = prompts.prepare(app, 'prompt:inspect', focal='X')
    assert prepared['graph']['project']['elements']['X']['entity_desc'] == 'local X'
    assert prepared['graph']['global']['elements']['X']['entity_desc'] == 'shared X'
    assert prepared['graph']['global']['elements']['Y']['entity_desc'] == 'shared Y'


def test_module_dependencies_select_shared_modules_and_keep_project_declarations(app):
    from metaform.registry import Registry
    for location, name, subject in [(app.home, 'chosen', 'X'), (app.home, 'unused', 'Q'),
                                    (app.root, 'local', 'Y')]:
        folder = location / 'modules' / name
        folder.mkdir(parents=True)
        (folder / 'helper.txt').write_text(name)
        write_json(folder / 'module.json', {
            'id': name, 'portable': {'files': ['helper.txt'], 'knowledge_refs': [subject]},
            'commands': [{'name': 'run', 'handler': 'handler.py:run'}]})
    dependencies = Registry(app).portable_dependencies(['chosen'])
    assert {entry['id'] for entry in dependencies['modules']} == {'chosen', 'local'}
    assert {ref['ref'] for ref in dependencies['knowledge_refs']} == {'X', 'Y'}
    assert next(ref for ref in dependencies['knowledge_refs'] if ref['ref'] == 'X')['owner'] == 'global'
    assert 'owner' not in next(ref for ref in dependencies['knowledge_refs'] if ref['ref'] == 'Y')
    assert all(Path(entry['files'][0]).read_text() == entry['id']
               for entry in dependencies['modules'])
    assert dependencies['unresolved'] == []


def test_module_manifest_catalog_preserves_ownership_without_selecting_assets(app):
    from metaform.registry import Registry
    write_json(app.home / 'modules' / 'shared' / 'module.json', {
        'id': 'shared', 'commands': [{'name': 'run', 'handler': 'handler.py:run'}],
        'portable': {'knowledge_refs': ['X']}})
    write_json(app.root / 'modules' / 'local' / 'module.json', {
        'id': 'local', 'commands': [{'name': 'run', 'handler': 'handler.py:run'}]})
    catalog = Registry(app).portable_manifests()
    assert catalog['global']['module:shared']['portable']['knowledge_refs'] == ['X']
    assert catalog['project:' + app.project_id]['module:local']['id'] == 'local'
    assert 'module:local' not in catalog['global']
    assert catalog['global']['command:shared.run'] == {'module': 'shared'}
