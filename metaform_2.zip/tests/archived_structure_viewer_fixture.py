"""Read-only archived intake in an isolated database for graph text observations."""
import json
from pathlib import Path
import signal
import os
import sys
import tempfile

from metaform.app import App
from metaform.util import write_json
from metaform.viewer import create_app
from werkzeug.serving import make_server

with tempfile.TemporaryDirectory(prefix="archived-structure-") as folder:
    root = Path(folder).resolve()
    os.environ["METAFORM_RUNTIME_DIR"] = str(root / "runtime")
    write_json(root / "home/config.json", {"knowledge_mode": "legacy"})
    app = App(root / "MGM archived sample", root / "home")
    sample = Path("examples/intake/mgm-main")
    for filename, scope in [("native.json", "native"), ("latent.json", "archaeology")]:
        graph = json.loads((sample / filename).read_text())
        app.graph.put(graph, scope)
        if scope == "native":
            app.set("native_context", {k: v for k, v in graph.items() if k not in ("elements", "joins")})
    app.graph.merge_perspectives()
    if '--foundation' in sys.argv:
        from metaform.models import import_v1
        import_v1(app, (sample / 'native.json').read_bytes(), {'model': 'mgm', 'source': 'archived GUI fixture'})
        from semantic_browser_data import add_semantic_cases
        add_semantic_cases(app)
    server = make_server("127.0.0.1", 0, create_app(app), threaded=True)
    def stop(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    print(f"http://127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
