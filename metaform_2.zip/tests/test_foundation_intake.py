import asyncio
import copy

from metaform.app import App
from metaform.intake import Intake
from metaform.models import capture_model
from metaform.modules import intake
from metaform.registry import Registry
from metaform.util import digest


def test_source_inventory_excludes_chassis_metadata_with_and_without_git(tmp_path):
    import subprocess
    from metaform.modules.intake import project_files

    project, home = tmp_path / 'project', tmp_path / 'runtime'
    project.mkdir()
    for directory in ('.metaform', '.agentid'):
        path = project / directory
        path.mkdir()
        (path / 'record.json').write_text('{}')
    for use_git in (False, True):
        if use_git:
            subprocess.run(['git', 'init', '-q', str(project)], check=True)
        assert project_files(project, home) == []
        (project / 'design.md').write_text('A design for a small application.')
        assert project_files(project, home) == ['design.md']
        (project / 'design.md').unlink()


def test_source_baseline_preserves_freeform_artifact_context(app):
    context = 'A maintenance guide for the equipment owner.\nKeep {{ literal wording }}.'
    job = Intake(app).start({'artifact_context': context})
    assert job['inputs']['artifact_context'] == context


def contribution(app):
    return {'elements': {'document.guide': {'ef': 'Give procedural understanding'},
                         'document.index': {'ef': 'Locate an entry'}},
            'joins': [{'receiver': 'document.guide', 'provider': 'document.index', 'purpose': 'Find the procedure for a task'}]}


def known_bases():
    """The four bases every intake knows, as the global registry holds them."""
    from metaform.coarse import bases
    return {identifier: {'id': identifier, 'owner': 'global', **record} for identifier, record in bases().items()}


def expected(app, graph):
    from metaform.coarse import expand
    return expand(graph, 'project:' + app.project_id, known=known_bases())


def storage(app, graph=None):
    shape = expected(app, graph or contribution(app))
    return {key: value for key, value in shape.items() if key not in ('reused', 'diagnostics')}


def test_public_incremental_intake_publishes_one_foundation_and_resumes_exact_snapshot(app):
    registry = Registry(app)
    call = lambda operation, arguments: asyncio.run(registry.call(operation, arguments))
    job = call('intake.start', {})
    assert job['contract_version'] == '2'
    assert job['schema_ref'].endswith('#/$defs/IntakeContribution')
    assert 'intake.put' in job['tools']
    graph = contribution(app)
    call('intake.put', {'run_id': job['run_id'], 'request_id': job['request_id'], 'graph': graph})
    reopened = App(app.project, app.home)
    assert Intake(reopened).next(job['run_id']) == job
    receipt = asyncio.run(Registry(reopened).call('intake.answer', {'run_id': job['run_id'], 'request_id': job['request_id'], 'answer': {}}))
    assert 'annotations' not in receipt
    assert receipt['remaining'] == 0
    assert Intake(reopened).submit(job['run_id'], job['request_id'], {}) == receipt
    result = asyncio.run(Registry(reopened).call('intake.next', {'run_id': job['run_id']}))
    assert result['status'] == 'complete'
    assert result['model']['revision']
    foundation = capture_model(reopened, result['model'])
    shape = expected(app, graph)
    assert foundation['artifact'] == {'owner': 'project:' + app.project_id, 'kind': 'element', 'id': 'document.guide'}
    for key in ('types', 'elements', 'bindings', 'narrowings', 'joins'):
        assert foundation[key] == ({**shape['reused'], **shape['types']} if key == 'types' else shape[key]), key
    assert foundation['types']['document']['owner'] == 'global' and foundation['types']['document']['ef']
    assert foundation['types']['document.guide']['length'] == 2
    assert foundation['joins'][0]['role'] == 'hard dependency'
    assert foundation['activities'][0]['inputs'][0]['assignment'] == job
    assert foundation['activities'][0]['inputs'][1]['submissions'][0]['answer'] == graph
    assert not foundation['diagnostics']
    assert reopened.load_run(job['run_id'])['stage'] == 'complete'
    assert app.graph.export(scope='archaeology')['elements'] == {}
    assert Intake(reopened).next(job['run_id']) == result
    continuation = result['next']
    guide = asyncio.run(Registry(reopened).call(continuation['command'], continuation['arguments']))
    action = guide['next']
    practices = asyncio.run(Registry(reopened).call(action['command'], action['arguments']))
    assert practices['role'] == 'knowledge-tool'
    assert practices['model'] == result['model']
    assert practices['schema']['type'] == 'object'
    assert practices['inputs']['questions']
    assert any(module['id'] == 'analysis' for module in guide['modules'])


def test_contributions_preserve_actual_identity_multiple_purposes_and_runtime_metadata(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    engine.put(job['run_id'], graph, job['request_id'])
    changed = dict(graph['joins'][0], purpose='Understand the maintenance sequence')
    engine.put(job['run_id'], {'joins': [changed]}, job['request_id'])
    engine.put(job['run_id'], {'joins': [changed]}, job['request_id'])
    engine.submit(job['run_id'], job['request_id'], {'model': {'model': 'forged', 'revision': 'forged'}, 'activities': []})
    result = engine.next(job['run_id'])
    foundation = capture_model(app, result['model'])
    assert result['model']['model'] != 'forged'
    assert len(foundation['joins']) == 2
    assert len(foundation['elements']) == 2
    assert foundation['activities'][0]['kind'] == 'intake'


def test_intake_read_retains_exact_evidence_with_published_activity(app):
    source = 'The guide explains lubrication and inspection.\n'
    (app.project / 'guide.txt').write_text(source)
    engine = Intake(app)
    job = engine.start()
    assert 'guide.txt' in job['inputs']['source_manifest']['files']
    intake.read(app, {'run_id': job['run_id'], 'path': 'guide.txt'}, None)
    engine.submit(job['run_id'], job['request_id'], contribution(app))
    foundation = capture_model(app, engine.next(job['run_id'])['model'])
    assert foundation['activities'][0]['source_evidence'] == [{'source': 'guide.txt', 'revision': digest(source), 'text': source}]


def test_driver_completes_new_intake_after_one_semantic_assignment(app, monkeypatch):
    from metaform import harness

    jobs = []
    async def execute(scoped_app, job, name):
        jobs.append(copy.deepcopy(job))
        return {'status': 'answered', 'answer': contribution(scoped_app)}
    monkeypatch.setattr(harness, 'execute', execute)
    job = Intake(app).start()
    result = asyncio.run(intake.drive(app, {'run_id': job['run_id'], 'harness': 'fixture'}, None))
    assert result['status'] == 'complete'
    assert len(jobs) == 1
    assert jobs[0]['contract_version'] == '2'
    assert capture_model(app, result['model'])['joins'][0]['purpose'] == 'Find the procedure for a task'


def test_concurrent_v2_continuations_reuse_assignment_and_single_completion_revision(app):
    from concurrent.futures import ThreadPoolExecutor
    from metaform.models import list_models

    job = Intake(app).start()
    def obtain(_):
        return Intake(App(app.project, app.home)).next(job['run_id'])
    with ThreadPoolExecutor(max_workers=3) as pool:
        assert list(pool.map(obtain, range(3))) == [job, job, job]
    Intake(app).submit(job['run_id'], job['request_id'], contribution(app))
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(obtain, range(3)))
    assert results == [results[0]] * 3
    assert len(list_models(app)) == 1


def test_draft_reads_return_common_receiver_purpose_provider_bundle_and_capture_context(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    engine.put(job['run_id'], graph, job['request_id'])
    found = intake.search(app, {'run_id': job['run_id'], 'query': 'guide', 'limit': 1}, None)
    assert found['records']
    result = intake.get(app, {'run_id': job['run_id'], 'id': 'document.guide'}, None)
    records = {(item['ref']['kind'], item['ref']['id']): item['value'] for item in result['records']}
    join = ('join', expected(app, graph)['joins'][0]['id'])
    assert records[join]['receiver']['id'] == 'document.guide'
    assert records[join]['purpose'] == 'Find the procedure for a task'
    assert records[join]['provider_type']['id'] == 'document.index'
    assert records[('type', 'document.guide')]['ef'] == 'Give procedural understanding'
    engine.submit(job['run_id'], job['request_id'], {})
    foundation = capture_model(app, engine.next(job['run_id'])['model'])
    assert foundation['activities'][0]['inputs'][2]['context_reads'] == [found, result]


def test_registry_type_search_is_reused_and_read_revision_is_preserved(app):
    owner = 'global'
    record = {'entity_schema': 'metaform:element', 'entity_desc': 'A reusable maintenance guide.',
              'entity_json_obj': {'ef': 'Explain maintenance', 'length': 1, 'aliases': ['manual']}}
    app.global_graph.put({'elements': {'document.guide': record}}, 'authored')
    engine = Intake(app)
    job = engine.start()
    found = intake.search(app, {'run_id': job['run_id'], 'query': 'guide'}, None)
    assert any(r['ref'] == {'owner': owner, 'kind': 'type', 'id': 'document.guide'} for r in found['records'])
    graph = contribution(app)
    engine.put(job['run_id'], graph, job['request_id'])
    app.global_graph.put({'elements': {'document.guide': dict(record, entity_desc='A later registry revision')}}, 'authored')
    engine.submit(job['run_id'], job['request_id'], {})
    foundation = capture_model(app, engine.next(job['run_id'])['model'])
    assert foundation['types']['document.guide']['description'] == record['entity_desc']
    assert foundation['types']['document.guide']['owner'] == 'global'


def test_offline_intake_start_lists_source_without_git_installed(app, monkeypatch):
    (app.project / 'guide.txt').write_text('Machine maintenance instructions.')
    monkeypatch.setenv('PATH', '')
    job = Intake(app).start()
    assert job['contract_version'] == '2'
    assert 'guide.txt' in job['inputs']['source_manifest']['files']


def test_compact_read_retains_complete_type_snapshot_for_intake_completion(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    graph['elements']['document.guide']['ef'] = 'A detailed reusable account. ' * 1000
    engine.put(job['run_id'], graph, job['request_id'])
    envelope = intake.get(app, {'run_id': job['run_id'], 'id': 'document.guide', 'max_chars': 1}, None)
    type_item = next(item for item in envelope['records'] if item['ref'] == {'owner': 'project:' + app.project_id, 'kind': 'type', 'id': 'document.guide'})
    assert type_item['value']['body_omitted'] is True
    retained = app.load_run(job['run_id'])
    guide_type = expected(app, graph)['types']['document.guide']
    assert retained['referenced_types'][type_item['ref']['owner'] + '|document.guide'] == guide_type
    assert retained['context_reads'][-1] == envelope
    engine.submit(job['run_id'], job['request_id'], {})
    published = capture_model(app, engine.next(job['run_id'])['model'])
    assert published['types']['document.guide'] == guide_type
    assert published['diagnostics'] == []


def test_retained_compact_type_placeholder_does_not_replace_generated_type(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    engine.put(job['run_id'], graph, job['request_id'])
    run = app.load_run(job['run_id'])
    placeholder = {'body_omitted': True, 'full_content': 'metaform://retained/type/document.guide', 'summary': 'document.guide'}
    run['referenced_types']['project:' + app.project_id + '|document.guide'] = placeholder
    app.save_run(run)
    engine.submit(job['run_id'], job['request_id'], {})
    result = engine.next(job['run_id'])
    published = capture_model(app, result['model'])
    assert published['types']['document.guide'] == expected(app, graph)['types']['document.guide']
    assert app.load_run(job['run_id'])['referenced_types']['project:' + app.project_id + '|document.guide'] == placeholder
    assert published['activities'][0]['inputs'][1]['submissions'][0]['answer'] == graph


def test_each_submission_records_its_expansion_for_replay_but_the_activity_keeps_the_answer(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    engine.put(job['run_id'], graph, job['request_id'])
    submission = app.load_run(job['run_id'])['submissions'][0]
    assert submission['answer'] == graph
    shape = expected(app, graph)
    for key in ('artifact', 'types', 'elements', 'bindings', 'narrowings', 'joins'):
        assert submission['expanded'][key] == shape[key], key
    engine.submit(job['run_id'], job['request_id'], {})
    foundation = capture_model(app, engine.next(job['run_id'])['model'])
    recorded = foundation['activities'][0]['inputs'][1]['submissions']
    assert recorded[0]['answer'] == graph and 'expanded' not in recorded[0]


def test_annealed_subtypes_publish_as_inactive_positions_and_browse_beneath_their_parent(app):
    engine = Intake(app)
    job = engine.start()
    graph = contribution(app)
    graph['subtypes'] = ['document.index.alphabetical']
    engine.put(job['run_id'], graph, job['request_id'])
    engine.submit(job['run_id'], job['request_id'], {})
    model = engine.next(job['run_id'])['model']
    foundation = capture_model(app, model)
    assert foundation['subtypes'] == expected(app, graph)['subtypes']
    assert foundation['subtypes'][0]['parent']['id'] == 'document.index' and foundation['subtypes'][0]['status'] == 'inactive'
    assert 'document.index.alphabetical' not in foundation['types']
    branch = asyncio.run(Registry(app).call('namespace.browse', {'model': model, 'target': 'document.index'}))
    assert [r['ref']['id'] for r in branch['records'] if r['ref']['kind'] == 'subtype'] == ['document.index.alphabetical']
