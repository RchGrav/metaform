// The job viewer runs an intake from the page, shows it as steps, and replays it as a growing graph.
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');
const assert=require('node:assert/strict');
const {python,outputDirectory}=require('./browser_support.cjs');
(async()=>{
  const out=outputDirectory('jobs');
  const server=spawn(python,['tests/jobs_viewer_fixture.py'],{stdio:['ignore','pipe','pipe']});
  let stderr='',browser;server.stderr.on('data',chunk=>stderr+=chunk);
  try{
    const url=await new Promise((resolve,reject)=>{server.stdout.once('data',chunk=>resolve(String(chunk).trim()));server.once('exit',code=>reject(Error('Fixture failed '+code+' '+stderr)));});
    browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1600,height:1000}});
    const errors=[];page.on('pageerror',error=>errors.push(error.message));
    await page.goto(url+'/');await page.waitForFunction(()=>/no foundation/i.test(document.getElementById('graph-title').textContent));
    await page.locator('.side-tabs button[data-side=jobs]').click();await page.waitForFunction(()=>document.querySelectorAll('#harness option').length>0);
    await page.selectOption('#harness','stand-in');await page.locator('#start-intake').click();
    await page.waitForFunction(()=>document.querySelectorAll('#step-list li').length>0,null,{timeout:20000});
    await page.waitForFunction(()=>/complete/.test(document.getElementById('job-title').textContent),null,{timeout:60000});
    const steps=await page.evaluate(()=>[...document.querySelectorAll('#step-list li .kind')].map(node=>node.textContent));
    assert.equal(steps[0],'prompt sent');assert(steps.includes('answer'),'The submission is a step');assert.equal(steps[steps.length-1],'result');
    const cards=await page.evaluate(()=>[...document.querySelectorAll('#cards .card .title')].map(node=>node.textContent));
    assert.deepEqual(cards.sort(),['Clock Loop Code','Display Clock Loop Code'],'The replay draws the notable elements named from the namespace');
    assert.equal(await page.locator('#edges path.hit').count(),1);
    assert.equal(await page.locator('#scrub').getAttribute('max'),'1');
    await page.screenshot({path:out+'/jobs-complete.png'});
    await page.locator('#step-list li').first().click();await page.waitForFunction(()=>document.querySelector('#inspector textarea'));
    const prompt=await page.locator('#inspector textarea').inputValue();assert(prompt.length>100,'The authored prompt that was sent is shown for editing');
    await page.locator('#inspector .envelope-toggle').click();assert((await page.locator('#inspector .envelope .call').innerText()).startsWith('assignment'));await page.keyboard.press('Escape');
    // The scrubber replays the graph from empty.
    await page.locator('#scrub').fill('0');await page.waitForFunction(()=>document.querySelectorAll('#cards .card').length===0);
    await page.locator('#scrub').fill('1');await page.waitForFunction(()=>document.querySelectorAll('#cards .card').length===2);
    // The published foundation is now browsable from the namespace tab.
    await page.locator('.side-tabs button[data-side=namespace]').click();await page.waitForFunction(()=>document.querySelectorAll('#tree [data-side=namespace] .name').length>0,null,{timeout:15000});
    assert((await page.locator('#model option').count())>0,'The model chooser lists the published foundation');
    await page.screenshot({path:out+'/jobs-published.png'});
    assert.deepEqual(errors,[]);
    console.log('Verified an intake started and driven from the page, its steps, the growing-graph replay, the editable prompt, and the published foundation appearing in the explorer.');
  }finally{if(browser)await browser.close();server.kill('SIGTERM');}
})().catch(error=>{console.error(error);process.exit(1);});
