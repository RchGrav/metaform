"""Coarse intake is the Type-only functional surface (SPEC sections 5 and 10).

The contract mirrors the prompt's output and nothing more: notable elements
named by their namespace position with one EF each, joined by artifact-specific
Operative Purposes. A field the prompt never asks for is a place to invent, so
there is none. The runtime expands that shape into storage deterministically.
"""
import json
from importlib.resources import files
from pathlib import Path

import pytest

from metaform.coarse import expand

CONTRACT = "urn:metaform:schema:coarse-intake:2"


def bundled():
    return json.loads((files("metaform") / "data" / "schemas.json").read_text(encoding="utf-8"))


def resolve(schema_id):
    catalog = bundled()
    base, _, fragment = schema_id.partition("#")
    node = catalog[base]
    for part in fragment.strip("/").split("/"):
        if part:
            node = node[part]
    return node


def walk(node):
    if isinstance(node, dict):
        yield node
        for child in node.values():
            yield from walk(child)
    elif isinstance(node, list):
        for child in node:
            yield from walk(child)


def test_coarse_contribution_is_notable_elements_and_their_joins():
    contribution = resolve(CONTRACT + "#/$defs/IntakeContribution")
    assert set(contribution["properties"]) == {"elements", "joins", "subtypes"}
    assert contribution["properties"]["subtypes"]["type"] == "array" and contribution["properties"]["subtypes"]["items"] == {"type": "string"}

    element = resolve(CONTRACT + "#/$defs/NotableElement")
    assert contribution["properties"]["elements"]["additionalProperties"] == {"$ref": "#/$defs/NotableElement"}
    assert set(element["properties"]) == {"ef", "name_length"}
    assert element["properties"]["name_length"]["type"] == "integer"

    join = resolve(CONTRACT + "#/$defs/Join")
    assert contribution["properties"]["joins"]["items"] == {"$ref": "#/$defs/Join"}
    assert set(join["properties"]) == {"receiver", "provider", "purpose", "relation", "observation", "combined"}
    for absent in ("role", "signal", "id", "owner", "provider_type"):
        assert absent not in join["properties"], absent

    combined = resolve(CONTRACT + "#/$defs/Combined")
    assert join["properties"]["combined"]["additionalProperties"] == {"$ref": "#/$defs/Combined"}
    assert set(combined["properties"]) == {"relation", "observation"}


def test_the_contract_describes_the_shape_and_never_rejects_an_answer():
    for node in walk(resolve(CONTRACT)):
        assert "required" not in node, node
        assert node.get("additionalProperties") is not False, node


def test_foundation_storage_holds_shallow_narrowings_and_combined_entities():
    narrowing = resolve("urn:metaform:schema:foundation:2#/$defs/Narrowing")
    assert "reason" not in narrowing["required"], "shallow intake places a position; its reason is deep intake"
    assert "category" not in narrowing["properties"]
    join = resolve("urn:metaform:schema:foundation:2#/$defs/OPJoin")
    assert join["properties"]["combined"]["additionalProperties"] == {"$ref": "#/$defs/Combined"}
    assert join["properties"]["relation"]["type"] == "string" and join["properties"]["observation"]["type"] == "string"
    assert "is_soft" not in join["properties"] and "classification" not in join["properties"]


def test_intake_composition_is_the_prompt_alone():
    composition = json.loads((files("metaform") / "data" / "roles" / "composition.json").read_text(encoding="utf-8"))
    intake = composition["roles"]["intake"]
    assert intake["components"] == []
    assert intake["output_schema"] == CONTRACT + "#/$defs/IntakeContribution"


def test_intake_prompt_is_the_specification_and_holds_the_authored_sections_in_order():
    text = (files("metaform") / "data" / "roles" / "runtime" / "intake.md").read_text(encoding="utf-8")
    specification = (Path(__file__).resolve().parents[1] / "specifications" / "intake.md").read_text(encoding="utf-8")
    assert text == specification, "the installed prompt is the specification, byte for byte"
    assert text.startswith("# Digital Archeology\n")
    headings = ["# Purpose", "# Core Concepts", "# Namespace Rules", "## Namespace Validity Examples", "# Method", "# Goal", "# Constraints", "# Completion Condition"]
    positions = [text.index(heading) for heading in headings]
    assert positions == sorted(positions)
    for sentence in (
        "for an artifact or a specification by identifying its categorical notable elements and joining them through type specific Operative Purposes",
        "Artifacts can include photographs, contracts, stories, resale assets, and software.",
        "Entities are elements, joins are elements, not all elements are entities.",
        "**Join**: A dictionary object that exists in the RE with a relation in active voice, an observation as an atomic fact that is present in all artifacts of its type",
        "This is the mechanism, interface, relationship, or method through which an Artifact or Element performs its purpose",
        "It is the only element in the graph which can speak directly to the artifact",
        "The four base valid types are `code`, `document`, `media`, and `data`.",
        "without being a non-functionality based variant.",
        "Children must take their parent’s name as their last name when reversed and read as a noun.",
        "Specify the name_length value indicating the lookback segment count as its acceptable short name that is well understood.",
        "Namespace must narrow from trunk to leaf",
        "This is a typological ontology, it is not a taxonomy",
        "`code.engine.game` — valid; this represents game engine program code. `game engine` is legal because it is a functionality type enabled by an external SDK",
        "`code.engine.game.fps` — valid as a functional subtype",
        "`code.engine.game.platformer` — invalid as a functional subtype",
        "`code.engine.game.doom` — invalid; not a function or type",
        "2. Find each notable element as a requirement.",
        "8. Only combine elements when they can logically share a common join.",
        "a relation in the active voice, and an observation as an atomic fact",
        "Seeking to perform a deep intake will only hurt the project",
        "Elements represent discrete functional roles actively instantiated by this artifact, named and described at their most specific reusable type level.",
        "Never use vague top-level labels where a specific functional mechanism exists.",
        "Keep all artifact-specific instance data strictly confined to the Operative Purpose.",
        "anneal joins and combine elements to a final shape that speaks to the artifact type.",
        "Keep the graph shape minimal, coarse, shallow, and extensible.",
        "minimal base shape of notable categorical elements of the artifact, joined by artifact-specific Operative Purposes",
        "11. List the subtypes you annealed away as `subtypes`, each a full namespace address beneath the element it was combined into.",
        "These subtypes are not part of the intake Metaform; they are held for the next steps as detected inactive subtypes, valid for memories to be attached to or to be named as namespace addresses.",
        "Their dependencies belong to the main type.",
    ):
        assert sentence in text, sentence
    for phrase in ("Save contributions incrementally", "supplied intake-contribution schema", "freeform description", "expansion opportunity"):
        assert phrase not in text, phrase


OWNER = "project:pong"


def pong_clock():
    return {
        "elements": {
            "code.loop.game": {"ef": "Runs the rally that shows the time.", "name_length": 2},
            "code.loop.game.controls.ai": {"ef": "Moves the paddles so the rally lands the right digits.", "name_length": 2},
            "code.loop.clock": {"ef": "Keeps the current time."},
            "code.loop.game.display": {"ef": "Draws the rally and the digits."},
            "code.loop.logic": {"ef": "Decides when a point is scored."},
        },
        "joins": [
            {"receiver": "code.loop.game", "provider": "code.loop.game.controls.ai", "purpose": "Land the rally on the current digits."},
            {"receiver": "code.loop.game", "provider": "code.loop.clock", "purpose": "Know which digits to show."},
            {"receiver": "code.loop.game", "provider": "code.loop.game.display", "purpose": "Show the rally and the digits.",
             "relation": "presents", "observation": "A game loop presents its state through a display.",
             "combined": {"code.loop.game.display.digits": {"relation": "draws", "observation": "Digits are drawn from the rally score."}}},
            {"receiver": "code.loop.game", "provider": "code.loop.logic", "purpose": "Score the rally."},
        ],
    }


def chassis_code():
    return {"id": "code", "owner": "chassis", "description": "program code", "ef": "Tell a computer how to perform a task.", "length": 1, "aliases": []}


def test_expansion_derives_the_defining_element_types_elements_bindings_and_narrowings():
    expanded = expand(pong_clock(), OWNER, known={"code": chassis_code()})
    ref = lambda kind, identifier, owner=OWNER: {"owner": owner, "kind": kind, "id": identifier}

    assert expanded["diagnostics"] == []
    assert expanded["artifact"] == ref("element", "code.loop.game")

    game = expanded["types"]["code.loop.game"]
    assert game == {"id": "code.loop.game", "owner": OWNER, "description": "game loop code", "ef": "Runs the rally that shows the time.", "length": 2, "aliases": []}
    assert expanded["types"]["code.loop.game.controls.ai"]["description"] == "ai controls game loop code"
    assert expanded["types"]["code.loop.game.controls.ai"]["length"] == 2, "name_length is the authored lookback"
    assert expanded["types"]["code.loop.clock"]["length"] == 3, "without name_length the whole reversed name is the name"
    assert expanded["types"]["code.loop"] == {"id": "code.loop", "owner": OWNER, "description": "loop code", "ef": "", "length": 2, "aliases": []}
    assert expanded["types"]["code.loop.game.controls"]["ef"] == ""
    assert "code" not in expanded["types"], "a known position is reused, not re-authored"
    assert expanded["reused"] == {"code": chassis_code()}

    assert set(expanded["elements"]) == set(pong_clock()["elements"])
    assert expanded["elements"]["code.loop.clock"] == {"id": "code.loop.clock", "owner": OWNER, "name": "clock loop code", "artifact": ref("element", "code.loop.game")}

    assert sorted((b["element"]["id"], b["type"]["id"]) for b in expanded["bindings"]) == sorted((name, name) for name in pong_clock()["elements"])
    assert all(b["owner"] == OWNER and b["id"].startswith("binding:") for b in expanded["bindings"])

    steps = sorted((n["parent"]["id"], n["child"]["id"]) for n in expanded["narrowings"])
    assert steps == sorted([
        ("code", "code.loop"), ("code.loop", "code.loop.game"), ("code.loop.game", "code.loop.game.controls"),
        ("code.loop.game.controls", "code.loop.game.controls.ai"), ("code.loop", "code.loop.clock"),
        ("code.loop.game", "code.loop.game.display"), ("code.loop", "code.loop.logic"),
    ])
    root = next(n for n in expanded["narrowings"] if n["child"]["id"] == "code.loop")
    assert root["parent"] == ref("type", "code", "chassis")
    assert all("reason" not in n for n in expanded["narrowings"])


def test_expansion_carries_joins_as_requirements_with_combined_entities():
    expanded = expand(pong_clock(), OWNER, known={"code": chassis_code()})
    ref = lambda kind, identifier: {"owner": OWNER, "kind": kind, "id": identifier}
    joins = {j["provider"]["id"]: j for j in expanded["joins"]}
    assert set(joins) == {"code.loop.game.controls.ai", "code.loop.clock", "code.loop.game.display", "code.loop.logic"}
    display = joins["code.loop.game.display"]
    assert display["receiver"] == ref("element", "code.loop.game")
    assert display["provider_type"] == ref("type", "code.loop.game.display")
    assert display["purpose"] == "Show the rally and the digits."
    assert display["role"] == "hard dependency"
    assert display["relation"] == "presents" and display["observation"] == "A game loop presents its state through a display."
    assert display["combined"] == {"code.loop.game.display.digits": {"relation": "draws", "observation": "Digits are drawn from the rally score."}}
    assert "combined" not in joins["code.loop.clock"] and "relation" not in joins["code.loop.clock"]
    assert all(j["owner"] == OWNER and j["id"].startswith("join:") for j in expanded["joins"])
    assert expand(pong_clock(), OWNER, known={"code": chassis_code()})["joins"] == expanded["joins"], "ids are deterministic"


def test_expansion_reports_an_unresolved_defining_element_instead_of_choosing_one():
    shape = {"elements": {"code.loop.game": {"ef": "a"}, "code.loop.clock": {"ef": "b"}, "code.loop.logic": {"ef": "c"}},
             "joins": [{"receiver": "code.loop.game", "provider": "code.loop.logic", "purpose": "p"},
                       {"receiver": "code.loop.clock", "provider": "code.loop.logic", "purpose": "q"}]}
    expanded = expand(shape, OWNER, known={})
    assert expanded["artifact"] is None
    assert [d["code"] for d in expanded["diagnostics"]] == ["unresolved_defining_element"]
    assert expanded["diagnostics"][0]["roots"] == ["code.loop.clock", "code.loop.game"]
    assert all(element["artifact"] is None for element in expanded["elements"].values())


def test_expansion_reports_a_join_to_an_unnamed_element():
    shape = {"elements": {"code.loop.game": {"ef": "a"}}, "joins": [{"receiver": "code.loop.game", "provider": "code.loop.clock", "purpose": "p"}]}
    expanded = expand(shape, OWNER, known={})
    assert [d["code"] for d in expanded["diagnostics"]] == ["unnamed_join_participant"]
    assert expanded["diagnostics"][0]["ref"] == "code.loop.clock"


def test_the_stored_contract_shape_is_what_the_agent_receives(app):
    from metaform.prompts import compose_role

    prepared = compose_role(app, "intake", {"artifact_context": {"project": str(app.project), "owner": "project:" + app.project_id}})
    assert prepared["components"] == []
    schema_text = json.dumps(prepared["schema"])
    for absent in ("realization", "display_name", "is_soft", "understanding", "role", "signal", "bindings", "narrowings"):
        assert f'"{absent}"' not in schema_text, absent
    assert prepared["prompt"] == prepared["source_prompt"]


def test_a_project_type_narrowed_from_the_global_base_is_not_an_unresolved_position():
    from metaform.namespace import browse_namespace

    owner = OWNER
    ref = lambda kind, identifier, record_owner=owner: {"owner": record_owner, "kind": kind, "id": identifier}
    base = {"id": "document", "owner": "global", "description": "document", "ef": "Carry recorded meaning.", "length": 1, "aliases": []}
    guide = {"id": "document.guide", "owner": owner, "description": "guide document", "ef": "Give procedural understanding.", "length": 2, "aliases": []}
    snapshot = {"model": {"project": "pong", "model": "m", "revision": "r"}, "types": {"document": base, "document.guide": guide},
                "elements": {}, "bindings": [], "refinements": [], "joins": [],
                "narrowings": [{"id": "n1", "owner": owner, "parent": ref("type", "document", "global"), "child": ref("type", "document.guide")}]}
    assert not any(d["code"] == "unresolved_namespace_position" for d in browse_namespace(snapshot)["diagnostics"])
    snapshot["narrowings"] = []
    assert any(d["code"] == "unresolved_namespace_position" and d["id"] == "document" for d in browse_namespace(snapshot)["diagnostics"]), \
        "without a narrowing the global parent is still a gap for this project"


def test_expansion_records_what_the_prompt_did_not_ask_for_and_never_raises():
    shape = {"elements": {"code.loop.game": {"ef": "a", "name": "Pong"}, "code.loop.clock": {}},
             "joins": [{"receiver": "code.loop.game", "provider": "code.loop.clock"},
                       {"provider": "code.loop.clock", "purpose": "p", "role": "property"}]}
    expanded = expand(shape, OWNER, known={})
    assert expanded["types"]["code.loop.clock"]["ef"] == ""
    assert expanded["types"]["code.loop.game"]["ef"] == "a"
    assert expanded["joins"][0]["purpose"] == ""
    assert len(expanded["joins"]) == 1, "a join without a receiver has no owner to record it under"
    codes = sorted((d["code"], d.get("ref") or d.get("field")) for d in expanded["diagnostics"])
    assert codes == sorted([
        ("unexpected_field", "name"), ("missing_field", "ef"), ("missing_field", "purpose"),
        ("missing_field", "receiver"), ("unexpected_field", "role"),
    ])
    odd = expand({"elements": {"code.loop.game": {"ef": "a", "name_length": "two"}}, "joins": []}, OWNER, known={})
    assert odd["types"]["code.loop.game"]["length"] == 3 and any(d["code"] == "unexpected_value" and d["field"] == "name_length" for d in odd["diagnostics"])


def test_intake_records_validation_for_observation_and_never_returns_it_to_the_agent(app):
    from metaform.intake import Intake
    from metaform.models import capture_model

    engine = Intake(app)
    job = engine.start()
    receipt = engine.put(job["run_id"], {"elements": {"code.loop.game": {"ef": "a", "name": "Pong"}}, "joins": [{"receiver": "code.loop.game", "provider": "code.loop.game"}], "extra": 1}, job["request_id"])
    assert receipt == {"recorded": True, "contract_version": "2"}
    run = app.load_run(job["run_id"])
    assert run["submissions"][0]["annotations"], "validation and expansion diagnostics are recorded on the run"
    assert engine.put(job["run_id"], "not even an object", job["request_id"]) == {"recorded": True, "contract_version": "2"}
    assert run["contributions"]["elements"]["code.loop.game"]["name"] == "game loop code"
    answer = engine.submit(job["run_id"], job["request_id"], {})
    assert "annotations" not in answer
    result = engine.next(job["run_id"])
    assert result["status"] == "complete" and result["annotations"], "the workbench reads what was recorded"
    assert capture_model(app, result["model"])["types"]["code.loop.game"]["ef"] == "a"


def test_expansion_holds_annealed_subtypes_as_inactive_positions_beneath_their_main_type():
    shape = pong_clock()
    shape["subtypes"] = ["code.loop.game.controls.ai.paddle", "code.loop.game.display.digits", "code.audio.mixer", 7]
    expanded = expand(shape, OWNER, known={"code": chassis_code()})
    ref = lambda kind, identifier: {"owner": OWNER, "kind": kind, "id": identifier}
    assert expanded["subtypes"] == [
        {"id": "code.loop.game.controls.ai.paddle", "owner": OWNER, "parent": ref("type", "code.loop.game.controls.ai"), "status": "inactive"},
        {"id": "code.loop.game.display.digits", "owner": OWNER, "parent": ref("type", "code.loop.game.display"), "status": "inactive"},
        {"id": "code.audio.mixer", "owner": OWNER, "parent": None, "status": "inactive"},
    ]
    codes = sorted((d["code"], d.get("ref") or d.get("value")) for d in expanded["diagnostics"])
    assert codes == [("unexpected_value", 7), ("unplaced_subtype", "code.audio.mixer")]
    for address in shape["subtypes"][:3]:
        assert address not in expanded["types"] and address not in expanded["elements"]
    assert not any(n["child"]["id"] in shape["subtypes"] for n in expanded["narrowings"])


def test_storage_holds_detected_subtypes():
    from metaform.models import COLLECTIONS, REFERENCE_FIELDS

    assert COLLECTIONS["subtypes"] == "subtype" and REFERENCE_FIELDS["subtype"] == ("parent",)
    subtype = resolve("urn:metaform:schema:foundation:2#/$defs/Subtype")
    assert set(subtype["properties"]) == {"id", "owner", "parent", "status"}
    foundation = resolve("urn:metaform:schema:foundation:2")
    assert foundation["properties"]["subtypes"]["items"] == {"$ref": "#/$defs/Subtype"}
    assert "subtypes" not in foundation["required"]


def test_a_detected_subtype_reserves_its_address_and_shows_inactive_beneath_its_parent():
    from metaform.namespace import browse_namespace, resolve_target

    ref = lambda kind, identifier: {"owner": OWNER, "kind": kind, "id": identifier}
    kind = lambda identifier, length, ef: {"id": identifier, "owner": OWNER, "description": identifier, "ef": ef, "length": length, "aliases": []}
    snapshot = {"model": {"project": "pong", "model": "m", "revision": "r"},
                "types": {"code": kind("code", 1, "Run."), "code.loop": kind("code.loop", 2, ""), "code.loop.game": kind("code.loop.game", 3, "Play.")},
                "elements": {}, "bindings": [], "refinements": [], "joins": [],
                "narrowings": [{"id": "n1", "owner": OWNER, "parent": ref("type", "code"), "child": ref("type", "code.loop")},
                               {"id": "n2", "owner": OWNER, "parent": ref("type", "code.loop"), "child": ref("type", "code.loop.game")}],
                "subtypes": [{"id": "code.loop.game.display", "owner": OWNER, "parent": ref("type", "code.loop.game"), "status": "inactive"}]}
    branch = browse_namespace(snapshot, "code.loop.game")
    inactive = [r for r in branch["records"] if r["ref"]["kind"] == "subtype"]
    assert [r["ref"]["id"] for r in inactive] == ["code.loop.game.display"] and inactive[0]["value"]["status"] == "inactive"
    assert not any(d["code"] == "reserved_namespace_collision" for d in branch["diagnostics"])
    assert resolve_target(snapshot, "code.loop.game.display")["ref"] == ref("subtype", "code.loop.game.display")
    assert not any(r["ref"]["kind"] == "subtype" for r in browse_namespace(snapshot)["records"]), "an inactive subtype is not a root"

    snapshot["types"]["code.loop.game.display"] = kind("code.loop.game.display", 4, "Draw.")
    snapshot["narrowings"].append({"id": "n3", "owner": OWNER, "parent": ref("type", "code.loop.game"), "child": ref("type", "code.loop.game.display")})
    collision = next(d for d in browse_namespace(snapshot, "code.loop.game")["diagnostics"] if d["code"] == "reserved_namespace_collision")
    assert collision["reservations"][0]["kind"] == "subtype" and collision["entry"]["id"] == "code.loop.game.display"


def test_a_bare_id_shared_by_an_element_and_its_type_resolves_by_the_operation_kind():
    from metaform.read_model import read_snapshot

    ref = lambda kind, identifier: {"owner": OWNER, "kind": kind, "id": identifier}
    kind = lambda identifier, length, ef: {"id": identifier, "owner": OWNER, "description": identifier, "ef": ef, "length": length, "aliases": []}
    snapshot = {"model": {"project": "pong", "model": "m", "revision": "r"}, "artifact": ref("element", "code.loop.game"),
                "types": {"code": kind("code", 1, "Run."), "code.loop": kind("code.loop", 2, ""), "code.loop.game": kind("code.loop.game", 3, "Play.")},
                "elements": {"code.loop.game": {"id": "code.loop.game", "owner": OWNER, "name": "game loop code", "artifact": ref("element", "code.loop.game")}},
                "bindings": [{"id": "b1", "owner": OWNER, "element": ref("element", "code.loop.game"), "type": ref("type", "code.loop.game")}],
                "refinements": [], "joins": [],
                "narrowings": [{"id": "n1", "owner": OWNER, "parent": ref("type", "code"), "child": ref("type", "code.loop")},
                               {"id": "n2", "owner": OWNER, "parent": ref("type", "code.loop"), "child": ref("type", "code.loop.game")}],
                "subtypes": [{"id": "code.loop.game.display", "owner": OWNER, "parent": ref("type", "code.loop.game"), "status": "inactive"}]}
    browse = read_snapshot(snapshot, "namespace.browse", {"target": "code.loop.game"})
    assert browse["resolved_target"] == ref("type", "code.loop.game")
    assert not any(d.get("code") == "ambiguous_target" for d in browse["diagnostics"])
    assert [r["ref"]["id"] for r in browse["records"] if r["ref"]["kind"] == "subtype"] == ["code.loop.game.display"]
    inspect = read_snapshot(snapshot, "element.inspect", {"target": "code.loop.game"})
    assert inspect["resolved_target"] == ref("element", "code.loop.game")


def test_intake_module_guidance_carries_no_retired_join_classification():
    manifest = json.loads((files("metaform") / "data" / "modules" / "intake.json").read_text(encoding="utf-8"))
    text = json.dumps(manifest)
    for phrase in ("is_soft", "supplied classification", "property or requirement"):
        assert phrase not in text, phrase
