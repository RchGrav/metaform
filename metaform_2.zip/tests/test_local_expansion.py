import copy

from metaform.models import capture_model, publish_foundation
from metaform.expansion import start_expansion
from metaform.workflow import Engine
from test_knowledge_layers import foundation


def ref(app, kind, identifier):
    return {'owner': 'project:' + app.project_id, 'kind': kind, 'id': identifier}


def expansion_answer(app, model):
    source = capture_model(app, model)
    fine = copy.deepcopy(source['elements']['demo:engine'])
    fine.update(id='demo:engine:observations', name='Observation evaluation', description='Evaluates observed connectivity evidence.')
    refinement = {'id': 'refinement:engine:observations', 'owner': 'project:' + app.project_id,
                  'parent': ref(app, 'element', 'demo:engine'), 'child': ref(app, 'element', fine['id']), 'reason': 'Makes the engine observation account more precise.'}
    return {'id': 'authored-patch', 'source': model, 'destination_model': model['model'], 'purpose': 'Explain observation handling.',
            'operations': [{'op': 'add', 'target': ref(app, 'element', fine['id']), 'record': fine, 'reason': 'Identifies the requested deeper function.'},
                           {'op': 'add', 'target': ref(app, 'refinement', refinement['id']), 'record': refinement, 'reason': refinement['reason']}],
            'mapping': [], 'evidence': [{'source': 'fixture observation account'}]}


def test_public_expansion_resumes_and_preserves_parent(app, foundation):
    source = capture_model(app, foundation)
    purpose = 'Explain {{ observation }} handling.\nKeep this exact question.'
    job = start_expansion(app, foundation, 'demo:engine', purpose)
    assert job['inputs']['purpose'] == purpose
    assert job['inputs']['region']['resolved_target']['id'] == 'demo:engine'
    assert Engine(app).next(job['run_id'])['request_id'] == job['request_id']
    assert capture_model(app, foundation) == source
    answer = expansion_answer(app, foundation)
    receipt = Engine(app).submit(job['run_id'], job['request_id'], answer)
    assert Engine(app).submit(job['run_id'], job['request_id'], answer) == receipt
    result = Engine(app).next(job['run_id'])
    assert result['status'] == 'complete'
    destination = capture_model(app, result['model'])
    assert destination['elements']['demo:engine'] == source['elements']['demo:engine']
    assert destination['elements']['demo:installer'] == source['elements']['demo:installer']
    assert destination['refinements'][-1]['parent']['id'] == 'demo:engine'
    assert capture_model(app, foundation) == source
    saved = app.load_run(job['run_id'])['expansion_job']
    assert saved['contributions'][0]['answer'] == answer
    assert saved['assignment']['inputs']['purpose'] == purpose
    assert saved['publication']['model'] == result['model']


def test_expansion_rebases_nonoverlap_and_records_exact_conflict(app, foundation):
    job = start_expansion(app, foundation, 'demo:engine', 'Explain observation handling.')
    concurrent = capture_model(app, foundation)
    concurrent['elements']['demo:installer']['description'] = 'An independently improved installer account.'
    other = publish_foundation(app, concurrent, base=foundation)
    answer = expansion_answer(app, foundation)
    Engine(app).submit(job['run_id'], job['request_id'], answer)
    result = Engine(app).next(job['run_id'])
    assert result['status'] == 'complete'
    current = capture_model(app, result['model'])
    assert current['elements']['demo:installer']['description'] == concurrent['elements']['demo:installer']['description']
    job = start_expansion(app, result['model'], 'demo:engine', 'Correct the engine account.')
    correction = copy.deepcopy(current['elements']['demo:engine'])
    correction['description'] = 'Requested correction.'
    answer = {'operations': [{'op': 'update', 'target': ref(app, 'element', 'demo:engine'), 'record': correction, 'reason': 'Correct the earlier account.'}], 'mapping': []}
    concurrent = copy.deepcopy(current)
    concurrent['elements']['demo:engine']['description'] = 'A competing correction.'
    latest = publish_foundation(app, concurrent, base=result['model'])
    Engine(app).submit(job['run_id'], job['request_id'], answer)
    conflict = Engine(app).next(job['run_id'])
    assert conflict['status'] == 'conflict'
    detail = conflict['diagnostics'][0]['records'][0]
    assert detail['current']['description'] == 'A competing correction.'
    assert detail['proposed']['description'] == 'Requested correction.'
    assert capture_model(app)['model'] == latest
    assert app.load_run(job['run_id'])['expansion_job']['contributions'][0]['answer'] == answer


def test_expansion_metadata_is_addressable_without_scheduling_opportunities(app, foundation):
    from metaform.read_model import read_model
    from metaform.modules.model import expand
    snapshot = capture_model(app, foundation)
    snapshot['expansion_opportunities'] = [{'target': ref(app, 'element', 'demo:engine'), 'question': 'Explain the observation account.'}]
    model = publish_foundation(app, snapshot, base=foundation)
    listing = read_model(app, 'expansion.list', {'model': model, 'target': 'demo:engine'})
    assert any(record['value'].get('question') == 'Explain the observation account.' for record in listing['records'])
    job = expand(app, {'model': model, 'target': 'demo:engine', 'purpose': 'Explain the observation account.'}, None)
    Engine(app).submit(job['run_id'], job['request_id'], expansion_answer(app, model))
    complete = Engine(app).next(job['run_id'])
    listing = read_model(app, 'expansion.list', {'model': complete['model'], 'target': 'demo:engine'})
    completed = [record['value'] for record in listing['records'] if record['ref']['kind'] == 'expansion' and record['value'].get('state') == 'complete']
    assert len(completed) == 1
    assert completed[0]['purpose'] == 'Explain the observation account.'
    assert completed[0]['run_id'] == job['run_id']


def test_type_join_and_explicit_bounded_region_contexts(app, foundation):
    snapshot = capture_model(app, foundation)
    for target in ['code.evaluator', ref(app, 'join', snapshot['joins'][0]['id']),
                   {'kind': 'region', 'targets': [ref(app, 'element', 'demo:engine')], 'depth': 0, 'limit': 2}]:
        job = start_expansion(app, foundation, target, 'Explain this selected region.')
        assert job['inputs']['target'] == target
        assert 'types' not in job['inputs']['region']
        assert job['inputs']['region']['model'] == foundation
        assert capture_model(app, foundation) == snapshot


def test_unusable_patch_retains_answer_and_existing_foundation(app, foundation):
    job = start_expansion(app, foundation, 'demo:engine', 'Explain the observation account.')
    before = capture_model(app, foundation)
    answer = {'account': 'A useful but structurally incomplete answer.'}
    Engine(app).submit(job['run_id'], job['request_id'], answer)
    result = Engine(app).next(job['run_id'])
    assert result['status'] == 'incomplete'
    assert result['diagnostics'][0]['code'] == 'invalid_patch'
    assert app.load_run(job['run_id'])['expansion_job']['contributions'][0]['answer'] == answer
    assert capture_model(app, foundation) == before


def test_expansion_delegates_pin_reads_and_preserve_extra_context(app, foundation):
    import asyncio
    from types import SimpleNamespace
    from mcp import types
    from metaform.mcp_server import Context
    from metaform.registry import Registry
    from metaform.read_model import read_model

    job = start_expansion(app, foundation, 'demo:engine', 'Explain observation handling.')
    request = SimpleNamespace(session=SimpleNamespace(client_capabilities=types.ClientCapabilities(
        sampling=types.SamplingCapability(tools={}))))
    advertised = Context(app, request).prepare(job, 'workflow.answer')['params']['tools']
    assert {tool['name'] for tool in advertised} == set(job['tools'])
    assert {'workflow.get', 'workflow.ground'} <= set(job['tools'])
    concurrent = capture_model(app, foundation)
    concurrent['elements']['demo:installer']['description'] = 'A later installer account.'
    latest = publish_foundation(app, concurrent, base=foundation)
    registry = Registry(app)
    arguments = {'target': 'demo:installer', 'depth': 0, 'limit': 2}
    actual = asyncio.run(registry.call('workflow.ground', arguments))
    expected = read_model(app, 'model.ground', arguments | {'model': foundation})
    assert actual == expected
    app.set('mode', None)
    inspected = asyncio.run(registry.call('workflow.get', {'id': 'code.evaluator',
        'run_id': job['run_id']}))
    assert inspected['resolved_target']['kind'] == 'type'
    assert inspected['model'] == foundation
    deliberate_read = asyncio.run(registry.call('workflow.get', {'id': 'demo:installer',
        'run_id': job['run_id'], 'model': latest}))
    assert deliberate_read['model'] == latest
    assert any(row['value'].get('description') == 'A later installer account.'
               for row in deliberate_read['records'])
    captured = app.load_run(job['run_id'])
    assert captured['semantic_reads'][0]['result'] == expected
    assert captured['semantic_reads'][-1]['result'] == deliberate_read
    assert captured['semantic_reads'][-1]['request_id'] == job['request_id']
    Engine(app).submit(job['run_id'], job['request_id'], expansion_answer(app, foundation))
    complete = Engine(app).next(job['run_id'])
    assert complete['status'] == 'complete'
    expansion = capture_model(app, complete['model'])['expansions'][-1]
    assert expansion['semantic_reads'] == captured['semantic_reads']
    assert all(item in expansion['dependencies'] for item in captured['context_dependencies'])
    assert expansion['rendered_assignment']['inputs'] == job['inputs']
