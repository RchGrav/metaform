import copy

import pytest

from metaform.backends import open_graph
from metaform.knowledge import BoundGraph, KnowledgeStore


def record(name):
    return {"entity_desc": name, "entity_schema": "metaform:actual-element",
            "entity_json_obj": {"description": name, "type_ids": ["code.interface"]}}


def relation(identifier, purpose):
    return {"id": identifier, "object_id": "shared", "element_id": "provider",
            "type": "hard dependency", "purpose": purpose}


@pytest.fixture(params=["sqlite", "json", "service"])
def graph(request, tmp_path):
    if request.param == "service":
        store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
        project_id = store.call(None, "project.register", {"path": str(tmp_path / "project")})["project_id"]
        return BoundGraph(store.bind(project_id), "project:" + project_id)
    return open_graph(tmp_path / ("graph." + request.param), request.param)


def test_replace_scope_removes_previous_pass_and_preserves_other_sources(graph):
    graph.put({"elements": {"shared": record("Native detail"), "restore": record("Native survivor"),
                            "provider": record("Native provider")},
               "joins": [relation("native", "Native purpose")]}, "native")
    graph.put({"elements": {"authored": record("Authored detail")},
               "joins": [relation("authored", "Authored purpose")]}, "authored")
    graph.put({"elements": {"shared": record("Stale latent detail"), "restore": record("Stale override"),
                            "obsolete": record("Old latent only")},
               "joins": [relation("old-id", "Same purpose")]}, "archaeology")
    before = graph.export()
    native, authored = copy.deepcopy(graph.export("native")), copy.deepcopy(graph.export("authored"))
    current = {"elements": {"shared": record("Fresh latent detail"), "fresh": record("New latent only")},
               "joins": [relation("new-id", "Same purpose")]}
    assert graph.replace_scope(current, "archaeology") == {"elements": 2, "joins": 1}
    assert graph.export("native") == native
    assert graph.export("authored") == authored
    assert graph.get("shared") == record("Fresh latent detail")
    assert graph.get("restore") == record("Native survivor")
    assert graph.get("obsolete") is None
    assert {j["source_id"] for j in graph.joins(scope="archaeology")} == {"new-id"}
    assert {o["record"]["entity_desc"] for o in graph.export("archaeology")["observations"]} == {"Fresh latent detail", "New latent only"}
    assert [o for o in graph.export()["observations"] if o["source"] != "archaeology"] == [o for o in before["observations"] if o["source"] != "archaeology"]
    graph.replace_scope({"elements": {}, "joins": []}, "archaeology")
    assert graph.get("shared") == record("Native detail")
    assert graph.get("fresh") is None
    assert not graph.joins(scope="archaeology")


def test_service_replacement_is_owner_scoped_and_transactional(tmp_path):
    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    ids = [store.call(None, "project.register", {"path": str(tmp_path / name)})["project_id"] for name in ("a", "b")]
    a, b = [BoundGraph(store.bind(identifier), "project:" + identifier) for identifier in ids]
    shared = BoundGraph(store.bind(ids[0]), "global")
    for graph in (a, b, shared):
        graph.put({"elements": {"shared": record("Original")}, "joins": [relation("old", "Old purpose")]}, "archaeology")
    others = b.export(), shared.export()
    before = a.export()
    with pytest.raises(RuntimeError):
        with store.transaction():
            a.replace_scope({"elements": {"shared": record("Aborted")}, "joins": []}, "archaeology")
            raise RuntimeError("abort")
    assert a.export() == before
    a.replace_scope({"elements": {"shared": record("Current")}, "joins": []}, "archaeology")
    assert (b.export(), shared.export()) == others
    assert a.get("shared") == record("Current")


def test_failed_replacement_keeps_previous_scope(graph):
    graph.put({"elements": {"shared": record("Original")}, "joins": [relation("old", "Old")]}, "archaeology")
    before = graph.export()
    with pytest.raises(AttributeError):
        graph.replace_scope({"elements": {"broken": None}}, "archaeology")
    assert graph.export() == before
