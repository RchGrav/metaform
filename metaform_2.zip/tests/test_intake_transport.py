import asyncio
import json
from contextlib import ExitStack
from types import SimpleNamespace
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest
from mcp import types

from metaform.actor import gateway
from metaform.continuation import current
from metaform.intake import Intake
from metaform.mcp_server import Context
from metaform.registry import Registry


@pytest.fixture
def parallel_jobs(app):
    jobs = []
    for identifier in ["first-examination", "second-examination"]:
        job = Intake(app)._start("archaeology")
        job["inputs"]["transport_fixture"] = identifier
        job["tools"] = ["intake.get"]
        run = app.load_run(job["run_id"])
        run["pending"] = job
        app.save_run(run)
        jobs.append(job)
    return jobs


@pytest.fixture
def scoped_call(monkeypatch):
    async def call(registry, name, arguments=None, context=None, **kwargs):
        assert name == "intake.get"
        return {
            "arguments": arguments,
            "binding": registry.app.binding,
            "assignment": current(registry.app),
        }

    monkeypatch.setattr(Registry, "call", call)


def gateway_call(environment, arguments):
    request = Request(
        environment["METAFORM_GATEWAY"],
        data=json.dumps({"command": "intake.get", "arguments": arguments}).encode(),
        headers={
            "Authorization": "Bearer " + environment["METAFORM_GATEWAY_TOKEN"],
            "Content-Type": "application/json",
        },
    )
    with urlopen(request, timeout=5) as response:
        return json.load(response)


def test_parallel_gateways_bind_tools_and_continuations_to_exact_job(
    app, parallel_jobs, scoped_call
):
    with ExitStack() as stack:
        environments = [stack.enter_context(gateway(app, job)) for job in parallel_jobs]
        for index, (job, environment) in enumerate(zip(parallel_jobs, environments)):
            sibling = parallel_jobs[1 - index]
            result = gateway_call(environment, {
                "run_id": "other-run",
                "request_id": sibling["request_id"],
            })
            assert result["arguments"]["request_id"] == job["request_id"]
            assert result["arguments"]["run_id"] == job["run_id"]
            assert result["binding"]["request_id"] == job["request_id"]
            assert result["assignment"] == job
            assert sibling["inputs"]["transport_fixture"] not in json.dumps(result)
            binding = json.loads(environment["METAFORM_BINDING"])
            assert binding["request_id"] == job["request_id"]

        run = app.load_run(parallel_jobs[0]["run_id"])
        run.update(status="complete", pending=None)
        app.save_run(run)
        with pytest.raises(HTTPError) as caught:
            gateway_call(environments[0], {})
        assert "no longer pending" in caught.value.read().decode()
        assert gateway_call(environments[1], {})["assignment"] == parallel_jobs[1]


def test_parallel_sampling_keeps_each_message_and_tool_continuation_isolated(
    app, parallel_jobs, scoped_call, monkeypatch
):
    captured = []

    async def dispatch(context, pending):
        captured.append(pending)
        return pending

    monkeypatch.setattr(Context, "dispatch", dispatch)
    request = SimpleNamespace(
        protocol_version="2025-11-25",
        session=SimpleNamespace(
            client_capabilities=SimpleNamespace(
                sampling=types.SamplingCapability(tools=types.SamplingToolsCapability())
            )
        ),
    )
    context = Context(app, request)

    async def scenario():
        await asyncio.gather(*[
            context.sample(job, "intake.answer") for job in parallel_jobs
        ])
        for index, pending in enumerate(captured):
            job = parallel_jobs[index]
            sibling = parallel_jobs[1 - index]
            assert pending["params"]["includeContext"] == "none"
            assert len(pending["params"]["messages"]) == 1
            message = pending["params"]["messages"][0]["content"]["text"]
            assert json.loads(message)["inputs"] == job["inputs"]
            assert sibling["inputs"]["transport_fixture"] not in message
            result = types.CreateMessageResultWithTools(
                role="assistant",
                content=[types.ToolUseContent(
                    name="intake.get",
                    id="same-tool-id-in-both-jobs",
                    input={"run_id": "other-run", "request_id": sibling["request_id"]},
                )],
                model="fixture",
                stop_reason="toolUse",
            )
            assert await context.accept(pending, result) is None
            reply = pending["params"]["messages"][-1]["content"][0]
            assert not reply.get("isError"), reply
            value = json.loads(reply["content"][0]["text"])
            assert value["arguments"]["request_id"] == job["request_id"]
            assert value["binding"]["request_id"] == job["request_id"]
            assert value["assignment"] == job
            assert sibling["inputs"]["transport_fixture"] not in json.dumps(value)

    asyncio.run(scenario())


def test_modern_batch_retains_completed_answers_during_independent_tool_continuation(
    app, parallel_jobs, monkeypatch
):
    async def call(registry, name, arguments=None, context=None, **kwargs):
        if name == "intake.answer":
            return {"recorded": True, "request_id": arguments["request_id"]}
        assert name == "intake.get"
        return current(registry.app)

    monkeypatch.setattr(Registry, "call", call)
    context = Context(app, SimpleNamespace(
        protocol_version="2026-07-28",
        session=SimpleNamespace(client_capabilities=SimpleNamespace(
            sampling=types.SamplingCapability(tools=types.SamplingToolsCapability())
        )),
    ))

    def answer():
        return types.CreateMessageResult(
            role="assistant", content=types.TextContent(type="text", text="{}"),
            model="fixture", stop_reason="endTurn",
        )

    async def scenario():
        initial = await context.sample_batch(parallel_jobs, "intake.answer")
        first, second = [job["request_id"] for job in parallel_jobs]
        assert isinstance(initial, types.InputRequiredResult)
        assert set(initial.input_requests) == {first, second}
        for index, key in enumerate([first, second]):
            params = initial.input_requests[key].params
            assert params.include_context == "none"
            assert json.loads(params.messages[0].content.text)["inputs"] == parallel_jobs[index]["inputs"]
        followup = await context.accept_batch(
            app.get("sampling:" + initial.request_state),
            {
                first: answer(),
                second: types.CreateMessageResultWithTools(
                    role="assistant",
                    content=[types.ToolUseContent(
                        name="intake.get", id="lookup", input={},
                    )],
                    model="fixture", stop_reason="toolUse",
                ),
            },
        )
        assert set(followup.input_requests) == {second}
        assert parallel_jobs[0]["inputs"]["transport_fixture"] not in json.dumps(
            followup.input_requests[second].model_dump(mode="json")
        )
        completed = await context.accept_batch(
            app.get("sampling:" + followup.request_state), {second: answer()}
        )
        assert completed["recorded"]
        assert {item["request_id"] for item in completed["results"]} == {first, second}

    asyncio.run(scenario())
