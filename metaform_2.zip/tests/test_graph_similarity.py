import copy
import json

import pytest

from metaform.backends import JSONGraph
from metaform.graph import Graph
from metaform.similarity import compare


@pytest.fixture(params=[Graph, JSONGraph])
def graph(tmp_path, request):
    return request.param(tmp_path / "similarity.graph")


def element(name):
    return {"entity_desc": name, "entity_schema": "metaform:element",
            "entity_json_obj": {"en": name, "ef": "SOURCE EF " + name}}


def test_similarity_preserves_both_sources_without_copying_semantics(graph):
    graph.put({"elements": {"X": element("Contextual X"), "C": element("C")}, "joins": [
        {"id": "use", "type": "OP", "object_id": "X", "element_id": "external", "purpose": "CONTEXT PURPOSE", "join_logic": {"context": "private"}},
        {"id": "context-only", "type": "OP", "object_id": "X", "element_id": "C"},
    ]}, "native")
    graph.put({"elements": {"X": element("Latent X"), "L": element("L")}, "joins": [
        {"id": "independent-use", "type": "OP", "object_id": "X", "element_id": "external", "purpose": "LATENT PURPOSE", "join_logic": ["independent"]},
        {"id": "latent-only", "type": "OP", "object_id": "X", "element_id": "L"},
    ]}, "archaeology")
    before = {scope: graph.export(scope) for scope in ("native", "archaeology")}
    view = graph.similarity()
    assert {key: value["membership"] for key, value in view["elements"].items()} == {
        "X": "11", "C": "01", "L": "10", "external": "11",
    }
    assert {join["element_id"]: join["membership"] for join in view["joins"]} == {
        "external": "11", "C": "01", "L": "10",
    }
    assert view["elements"]["X"] == {"membership": "11", "sources": {"native": ["X"], "archaeology": ["X"]}}
    assert all(set(node) == {"membership", "sources"} for node in view["elements"].values())
    allowed = {"id", "membership", "sources", "type", "object_id", "element_id", "participants", "schema_id"}
    assert all(set(join) <= allowed for join in view["joins"])
    assert "PURPOSE" not in json.dumps(view) and "SOURCE EF" not in json.dumps(view)
    assert graph.merge_perspectives() == {"native": 2, "archaeology": 2, "merged": 3}
    assert len(graph.joins(scope="merged")) == 3
    assert {scope: graph.export(scope) for scope in before} == before
    assert graph.similarity() == view


def test_similarity_compares_hyperedge_roles_and_all_participants(graph):
    shared = {"type": "OP", "participants": [
        {"role": "Receiving Entity", "ref": "X"},
        {"role": "Encounter Function", "ref": "Y"},
        {"role": "support", "ref": "external"},
    ]}
    native = [dict(shared, id="hyper", purpose="context"),
              dict(shared, id="pair", object_id="X", element_id="Y")]
    other = copy.deepcopy(shared)
    other["participants"][-1]["ref"] = "different"
    latent = [dict(shared, id="independent", participants=list(reversed(shared["participants"])), purpose="latent"),
              dict(other, id="pair", object_id="X", element_id="Y")]
    graph.put({"joins": native}, "native")
    graph.put({"joins": latent}, "archaeology")
    view = graph.similarity()
    assert sorted(join["membership"] for join in view["joins"]) == ["01", "10", "11"]
    shared_join = next(join for join in view["joins"] if join["membership"] == "11")
    assert {(p["role"], p["ref"]) for p in shared_join["participants"]} == {
        ("Receiving Entity", "X"), ("Encounter Function", "Y"), ("support", "external"),
    }
    assert view["elements"]["external"]["membership"] == "11"
    assert view["elements"]["different"]["membership"] == "10"


def test_similarity_matches_references_to_independently_named_joins(graph):
    for scope, first, second in [("native", "use", "evidence"), ("archaeology", "independent", "support")]:
        graph.put({"joins": [
            {"id": first, "type": "OP", "object_id": "X", "element_id": "Y"},
            {"id": second, "type": "evidence", "participants": [
                {"role": "relationship", "ref": first}, {"role": "source", "ref": "external"},
            ]},
        ]}, scope)
    view = graph.similarity()
    assert len(view["joins"]) == 2
    assert all(join["membership"] == "11" for join in view["joins"])
    use = next(join for join in view["joins"] if join["type"] == "OP")
    evidence = next(join for join in view["joins"] if join["type"] == "evidence")
    assert {p["ref"] for p in evidence["participants"]} == {use["id"], "external"}
    assert set(view["elements"]) == {"X", "Y", "external"}


@pytest.mark.parametrize("latent_length,want", [(2, ["11", "11"]), (1, ["01", "01", "10"])])
def test_similarity_matches_cycles_without_collapsing_different_cycle_shapes(graph, latent_length, want):
    for scope, prefix, length in [("native", "n", 2), ("archaeology", "a", latent_length)]:
        graph.put({"joins": [
            {"id": f"{prefix}{i}", "type": "relation", "participants": [
                {"role": "next", "ref": f"{prefix}{(i + 1) % length}"},
                {"role": "subject", "ref": "X"},
            ]}
            for i in range(length)
        ]}, scope)
    view = graph.similarity()
    assert sorted(join["membership"] for join in view["joins"]) == want
    identifiers = {join["id"] for join in view["joins"]}
    assert all(p["ref"] in identifiers for join in view["joins"] for p in join["participants"] if p["role"] == "next")


def test_similarity_preserves_duplicate_source_joins(graph):
    for scope, names in [("native", ["one", "two"]), ("archaeology", ["other"])]:
        graph.put({"joins": [
            {"id": name, "type": "OP", "object_id": "X", "element_id": "Y"} for name in names
        ]}, scope)
    view = graph.similarity()
    assert sorted(join["membership"] for join in view["joins"]) == ["01", "11"]
    assert sorted(ref for join in view["joins"] for ref in join["sources"].get("native", [])) == sorted(j["id"] for j in graph.joins(scope="native"))


def test_similarity_resolves_duplicate_structure_consistently_with_join_references():
    native = {"elements": {}, "joins": [
        {"id": "a", "type": "OP", "object_id": "X", "element_id": "Y"},
        {"id": "b", "type": "OP", "object_id": "X", "element_id": "Y"},
        {"id": "z", "type": "evidence", "object_id": "a", "element_id": "E"},
    ]}
    latent = {"elements": {}, "joins": [
        {"id": "c", "type": "OP", "object_id": "X", "element_id": "Y"},
        {"id": "d", "type": "OP", "object_id": "X", "element_id": "Y"},
        {"id": "y", "type": "evidence", "object_id": "d", "element_id": "E"},
    ]}
    view = compare(native, latent)
    assert [join["membership"] for join in view["joins"]] == ["11", "11", "11"]
    evidence = next(join for join in view["joins"] if join["type"] == "evidence")
    subject = next(join for join in view["joins"] if join["id"] == evidence["object_id"])
    assert subject["sources"] == {"native": ["a"], "archaeology": ["d"]}


@pytest.mark.parametrize("difference,want", [(None, ["11"]), ("extra", ["01", "10"]), ("role", ["01", "10"]), ("conflict", ["01", "10"])])
def test_similarity_compares_optional_pairwise_projections_as_the_same_role_structure(graph, difference, want):
    native = {"id": "pair", "type": "OP", "object_id": "X", "element_id": "Y"}
    latent = {"id": "roles", "type": "OP", "participants": [
        {"role": "receiver", "ref": "X"}, {"role": "ef_owner", "ref": "Y"},
    ]}
    if difference == "extra":
        latent["participants"].append({"role": "support", "ref": "external"})
    elif difference == "role":
        latent["participants"][0]["role"] = "another role"
    elif difference == "conflict":
        latent["object_id"] = "different"
        latent["element_id"] = "Y"
    graph.put({"joins": [native]}, "native")
    graph.put({"joins": [latent]}, "archaeology")
    before = {scope: graph.joins(scope=scope) for scope in ("native", "archaeology")}
    view = graph.similarity()
    assert sorted(join["membership"] for join in view["joins"]) == want
    assert {scope: graph.joins(scope=scope) for scope in before} == before


@pytest.mark.parametrize("structure", ["independent", "chain", "cycle"])
def test_similarity_handles_large_graphs_and_long_join_reference_chains(structure):
    size = 1100
    graphs = []
    for prefix in ("native", "latent"):
        graphs.append({"elements": {}, "joins": [
            {"id": f"{prefix}:{i:04d}", "type": "OP",
             "object_id": f"{prefix}:{(i + 1) % size:04d}" if structure == "cycle" or structure == "chain" and i + 1 < size else f"receiver:{i}",
             "element_id": f"element:{i}"}
            for i in range(size)
        ]})
    view = compare(*graphs)
    assert len(view["joins"]) == size
    assert all(join["membership"] == "11" for join in view["joins"])
    if structure != "independent":
        references = {join["id"] for join in view["joins"]}
        assert sum(join["object_id"] in references for join in view["joins"]) == (size if structure == "cycle" else size - 1)
