"""Historical v1 assignment contracts remain resumable after the v2 transition."""
import copy
from pathlib import Path

from metaform.app import App
from metaform.intake import Intake
from metaform.modules import intake


def element(description):
    return {"entity_desc": description, "entity_schema": "metaform:element",
            "entity_json_obj": {"en": description, "notes": "Actual artifact context"}}


def native_graph():
    return {
        "description": "Photographs of this used navigator for a resale listing.",
        "elements": {"media.photo.product.used": element("Photograph of the used navigator"),
                     "exterior.person.buyer": element("Buyer inspecting the navigator's condition")},
        "joins": [{"id": "inspect-condition", "object_id": "exterior.person.buyer",
                   "element_id": "media.photo.product.used", "type": "receiving_entity",
                   "purpose": {"text": "Inspect this navigator's wear before purchase"}}],
    }


def test_default_intake_hands_complete_native_to_one_fresh_latent_task(app):
    (app.project / "implementation.txt").write_text("IMPLEMENTATION SECRET")
    engine = Intake(app)
    native = engine._start("native")
    graph = native_graph()
    engine.put(native["run_id"], graph, native["request_id"])
    engine.submit(native["run_id"], native["request_id"], {"elements": {}, "joins": []})
    jobs = engine.batch(native["run_id"], 20)
    assert len(jobs) == 1
    latent = jobs[0]
    assert latent["role"] == "latent_expert"
    assert latent["context"] == "fresh"
    assert latent["inputs"]["native"]["description"] == graph["description"]
    assert set(latent["inputs"]["native"]["elements"]) == set(graph["elements"])
    assert latent["inputs"]["native"]["joins"][0]["purpose"] == graph["joins"][0]["purpose"]
    assert latent["system_prompt"].startswith("You are about to be given a task")
    assert "preserve this context throughout this process" in latent["system_prompt"]
    assert "metaform:element" in latent["inputs"]["schemas"]
    assert "intake.files" not in latent["tools"] and "intake.read" not in latent["tools"]
    assert not (Path(latent["workfolder"]) / "implementation.txt").exists()
    assert App(app.project, app.home).load_run(native["run_id"])["pending"] == latent
    assert Intake(App(app.project, app.home)).next(native["run_id"]) == latent
    assert app.global_graph.get("media.photo.product.used") is None


def test_latent_results_stay_project_local_and_do_not_expand_queue(app):
    engine = Intake(app)
    native = engine._start("native")
    engine.submit(native["run_id"], native["request_id"], native_graph())
    latent = engine.next(native["run_id"])
    assert latent["role"] == "latent_expert"
    answer = copy.deepcopy(native_graph())
    answer["elements"]["media.photo.detail"] = element("Close-up revealing wear on this navigator")
    answer["joins"].append({"id": "wear-detail", "object_id": "media.photo.product.used",
                            "element_id": "media.photo.detail", "type": "dependency",
                            "purpose": "Show wear hidden in the overall photograph"})
    engine.put(native["run_id"], answer, latent["request_id"])
    receipt = engine.submit(native["run_id"], latent["request_id"], {"elements": {}, "joins": []})
    assert engine.submit(native["run_id"], latent["request_id"], {}) == receipt
    assert engine.next(native["run_id"])["status"] == "complete"
    assert app.graph.get("media.photo.detail", scope="archaeology") is not None
    assert app.graph.get("media.photo.detail", scope="native") is None
    assert app.global_graph.get("media.photo.detail") is None
    assert len(app.graph.joins(scope="native")) == 1
    assert len(app.graph.joins(scope="archaeology")) == 2
    assert not Path(latent["workfolder"]).exists()


def test_examine_uses_saved_native_and_exposes_its_relationships(app):
    app.graph.put(native_graph(), "native")
    engine = Intake(app)
    latent = engine._start("archaeology")
    assert latent["role"] == "latent_expert"
    record = intake.get(app, {"id": "media.photo.product.used"}, None)
    assert record["object"]["entity_desc"] == "Photograph of the used navigator"
    assert record["joins"][0]["purpose"]["text"].startswith("Inspect this navigator")
    before = copy.deepcopy(latent)
    app.graph.put({"elements": {"media.photo.later": element("Added after assignment")}}, "native")
    assert engine.next(latent["run_id"]) == before
    assert "media.photo.later" not in {row["id"] for row in intake.search(app, {}, None)}
    engine.submit(latent["run_id"], latent["request_id"], {"elements": {}, "joins": []})
    assert engine.next(latent["run_id"])["status"] == "complete"
    assert "media.photo.later" in engine._start("archaeology")["inputs"]["native"]["elements"]


def test_whole_native_intake_preserves_custom_schemas_and_source_descriptions(app):
    from metaform import schemas
    schema = {"$id": "project:photograph", "$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object",
              "description": "Record photographs for the navigator resale listing",
              "properties": {"subject": {"type": "string", "description": "The particular device pictured"}}}
    schemas.register(app, schema)
    graph = native_graph()
    graph["elements"]["media.photo.product.used"] = {
        "entity_desc": "The original navigator photograph on red fabric",
        "entity_schema": "project:photograph", "entity_json_obj": {"subject": "Used navigator"}}
    engine = Intake(app)
    native = engine._start("native")
    engine.submit(native["run_id"], native["request_id"], graph)
    latent = engine.next(native["run_id"])
    assert latent["inputs"]["schemas"]["project:photograph"]["description"] == schema["description"]
    engine.submit(native["run_id"], latent["request_id"], {
        "elements": {"media.photo.product.used": element("Navigator photograph with better condition visibility")},
        "joins": []})
    assert app.graph.get("media.photo.product.used", scope="native")["entity_desc"] == graph["elements"]["media.photo.product.used"]["entity_desc"]
    assert app.graph.get("media.photo.product.used", scope="archaeology")["entity_desc"] == "Navigator photograph with better condition visibility"
    engine.next(native["run_id"])
    assert engine._start("archaeology")["inputs"]["native"]["description"] == graph["description"]


def test_whole_native_intake_uses_service_project_partition(app, tmp_path):
    from metaform.knowledge import BoundGraph, KnowledgeStore
    store = KnowledgeStore(tmp_path / "knowledge.sqlite3")
    project_id = store.call(None, "project.register", {"path": str(app.project)})["project_id"]
    other_id = store.call(None, "project.register", {"path": str(tmp_path / "other")})["project_id"]
    remote = store.bind(project_id)
    # Retain this fixture's seeded prompts and rules when switching backend.
    exported = app.graph.export()
    app.project_id = project_id
    app.knowledge_mode = "service"
    app.knowledge = remote
    app.__dict__["graph"] = BoundGraph(remote, "project:" + project_id)
    app.__dict__["global_graph"] = BoundGraph(remote, "global")
    app.graph.import_raw(exported)
    engine = Intake(app)
    native = engine._start("native")
    engine.submit(native["run_id"], native["request_id"], native_graph())
    latent = engine.next(native["run_id"])
    assert latent["role"] == "latent_expert"
    engine.submit(native["run_id"], latent["request_id"], native_graph())
    assert engine.next(native["run_id"])["status"] == "complete"
    assert app.graph.get("media.photo.product.used", scope="native") is not None
    assert app.graph.get("media.photo.product.used", scope="archaeology") is not None
    assert app.global_graph.get("media.photo.product.used") is None
    assert store.call(other_id, "graph.get", {"id": "media.photo.product.used"}) is None


def test_native_snapshot_carries_referenced_global_provider_without_reclassifying_it(app):
    provider = element("Existing framework providing collision queries")
    app.global_graph.put({"elements": {"exterior.framework.physics": provider}}, "authored")
    graph = native_graph()
    graph["joins"].append({"id": "provided", "object_id": "media.photo.product.used",
                            "element_id": "exterior.framework.physics", "type": "dependency",
                            "reference_owners": {"element_id": "global"}, "purpose": "An actual supplied function"})
    app.graph.put(graph, "native")
    latent = Intake(app)._start("archaeology")
    assert latent["inputs"]["native"]["references"]["global"]["elements"]["exterior.framework.physics"]["entity_desc"] == provider["entity_desc"]
    assert intake.get(app, {"id": "exterior.framework.physics", "owner": "global"}, None)["object"]["entity_desc"] == provider["entity_desc"]
    assert app.graph.get("exterior.framework.physics", scope="native") is None


def test_copied_reified_native_relations_refer_to_their_latent_counterparts(app):
    graph = native_graph()
    graph["joins"].append({"id": "evidence", "object_id": "inspect-condition", "element_id": "media.photo.product.used",
                            "type": "evidence", "participants": [{"role": "supported", "kind": "join", "ref": "inspect-condition"}]})
    app.graph.put(graph, "native")
    engine = Intake(app)
    latent = engine._start("archaeology")
    engine.submit(latent["run_id"], latent["request_id"], latent["inputs"]["native"])
    joins = {j["source_id"]: j for j in app.graph.joins(scope="archaeology")}
    assert joins["evidence"]["object_id"] == joins["inspect-condition"]["id"]
    assert joins["evidence"]["participants"][0]["ref"] == joins["inspect-condition"]["id"]


def test_latent_can_reference_a_native_relation_without_copying_it(app):
    app.graph.put(native_graph(), "native")
    original = app.graph.joins(scope="native")[0]["id"]
    engine = Intake(app)
    latent = engine._start("archaeology")
    engine.submit(latent["run_id"], latent["request_id"], {"elements": {}, "joins": [
        {"id": "comment", "object_id": original, "element_id": "media.photo.product.used", "type": "examination"}]})
    assert app.graph.joins(scope="archaeology")[0]["object_id"] == original


def test_captured_project_provider_can_be_looked_up_with_or_without_owner(app):
    provider = element("A previously authored provider")
    app.graph.put({"elements": {"media.photo.detail": provider}}, "authored")
    graph = native_graph()
    graph["joins"].append({"id": "detail", "object_id": "media.photo.product.used",
                            "element_id": "media.photo.detail", "type": "dependency"})
    app.graph.put(graph, "native")
    Intake(app)._start("archaeology")
    for args in ({"id": "media.photo.detail"}, {"id": "media.photo.detail", "owner": "project:" + app.project_id}):
        assert intake.get(app, args, None)["object"]["entity_desc"] == provider["entity_desc"]


def test_completed_latent_pass_replaces_previous_result_instead_of_accumulating(app):
    original = native_graph()
    app.graph.put(original, 'native')
    app.graph.put({'elements': {'previous:proposal': element('Old proposal')}, 'joins': [
        {'id': 'old-reading', 'object_id': 'exterior.person.buyer', 'element_id': 'media.photo.product.used',
         'type': 'supportive', 'purpose': 'Inspect condition'},
    ]}, 'archaeology')
    native_before = app.graph.export(scope='native')
    engine = Intake(app)
    latent = engine._start("archaeology")
    engine.submit(latent['run_id'], latent['request_id'], {
        'elements': original['elements'], 'joins': [
            {'id': 'current-reading', 'object_id': 'exterior.person.buyer', 'element_id': 'media.photo.product.used',
             'type': 'supportive', 'purpose': 'Inspect condition'},
        ],
    })
    assert engine.next(latent['run_id'])['status'] == 'complete'
    current = app.graph.export(scope='archaeology')
    assert set(current['elements']) == set(original['elements'])
    assert len(current['joins']) == 1
    assert current['joins'][0]['source_id'] == 'current-reading'
    assert app.graph.export(scope='native') == native_before
