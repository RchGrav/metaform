"""metaform web: one fixed port, start when needed, stop when asked, the root lands on the project (SPEC section 13).

Rich's requirements of 2026-09-12 and 2026-09-13: one port; a consistent command to start it; a start and a stop
command; single process; no pick-a-project page on launch; a link you can make once that works because it is running;
the command is `metaform web`, not `browse`.
"""
import asyncio
import http.client
import socket
import urllib.request

import pytest

from metaform.app import App
from metaform.registry import Registry
from metaform.util import write_json


def free_port():
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        return probe.getsockname()[1]


@pytest.fixture
def web_app(tmp_path):
    home = tmp_path / "home"
    write_json(home / "config.json", {"knowledge_mode": "legacy", "auto_build": False, "web_port": free_port()})
    (tmp_path / "project").mkdir()
    return App(tmp_path / "project", home)


def call(app, key, arguments=None):
    return asyncio.run(Registry(app).call(key, arguments or {}))


def test_web_start_serves_the_project_on_the_configured_port_every_time(web_app):
    port = web_app.config["web_port"]
    first = call(web_app, "web.start")
    assert first["port"] == port
    assert first["url"].startswith(f"http://127.0.0.1:{port}/projects/")
    again = call(web_app, "web.start")
    assert again["instance_id"] == first["instance_id"] and again["url"] == first["url"]
    status = call(web_app, "web.status")
    assert status["ready"] is True and status["port"] == port
    assert call(web_app, "web.stop")["stopped"] is True
    assert call(web_app, "web.status")["ready"] is False
    third = call(web_app, "web.start")
    assert third["port"] == port and third["instance_id"] != first["instance_id"]


def test_web_start_replaces_a_service_listening_on_another_port(web_app):
    from metaform.service import ensure_service

    stray = ensure_service(web_app.home)
    assert stray["port"] != web_app.config["web_port"]
    result = call(web_app, "web.start")
    assert result["port"] == web_app.config["web_port"]
    assert result["instance_id"] != stray["instance_id"]


def test_web_start_names_the_port_and_the_setting_when_the_port_is_taken(web_app):
    port = web_app.config["web_port"]
    with socket.socket() as occupant:
        occupant.bind(("127.0.0.1", port))
        occupant.listen(1)
        with pytest.raises(ValueError) as failure:
            call(web_app, "web.start")
    assert str(port) in str(failure.value) and "web_port" in str(failure.value)
    assert call(web_app, "web.status")["ready"] is False


def test_the_root_lands_on_the_opened_project_and_the_chooser_moves_to_projects(web_app):
    result = call(web_app, "web.start")
    port = web_app.config["web_port"]
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    connection.request("GET", "/")
    response = connection.getresponse()
    response.read()
    assert response.status in {301, 302, 303, 307, 308}
    assert response.getheader("Location").rstrip("/") == result["url"].rstrip("/") \
        or response.getheader("Location").rstrip("/") == result["url"].replace(f"http://127.0.0.1:{port}", "").rstrip("/")
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=5) as landed:
        assert "explorer.js" in landed.read().decode()
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/projects", timeout=5) as chooser:
        assert "Metaform projects" in chooser.read().decode()


def test_web_is_the_command_and_browse_is_gone(web_app):
    from metaform.cli import run_parser

    registry = Registry(web_app)
    discovered = registry.discover()
    assert {"web.start", "web.stop", "web.status"} <= set(discovered)
    assert not any(key.startswith("viewer.") for key in discovered)
    assert run_parser(registry, ["web"], parse_only=True)["_cli_command_key"] == "web.start"
    assert run_parser(registry, ["web", "stop"], parse_only=True)["_cli_command_key"] == "web.stop"
    with pytest.raises(SystemExit):
        run_parser(registry, ["browse"], parse_only=True)


def test_the_service_starts_from_a_folder_that_shadows_a_standard_library_module(tmp_path, monkeypatch):
    from metaform.service import ensure_service, stop_service

    folder = tmp_path / "shadow"
    folder.mkdir()
    (folder / "types.py").write_text("SHADOW = True\n")
    monkeypatch.chdir(folder)
    home = tmp_path / "home"
    write_json(home / "config.json", {"auto_build": False})
    try:
        assert ensure_service(home)["host"] == "127.0.0.1"
    finally:
        stop_service(home, timeout=5)
