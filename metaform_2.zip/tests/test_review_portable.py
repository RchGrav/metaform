"""Regression coverage for review findings R02, R03, and R16."""

import stat
import subprocess
import warnings
import zipfile
from pathlib import Path

import pytest

from metaform import history, portable
from metaform.app import App
from metaform.registry import Registry
from metaform.util import write_json
from metaform.workflow import import_workflow


def append_members(source, destination, members):
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(destination, "w") as changed:
        for item in original.infolist():
            changed.writestr(item, original.read(item))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            for name, mode, content in members:
                item = zipfile.ZipInfo(name)
                item.external_attr = mode << 16
                changed.writestr(item, content)


@pytest.mark.parametrize("second", ["outputs/escape", "project-assets/outputs/escape"])
def test_import_duplicate_link_cannot_overwrite_external_file(app, tmp_path, second):
    archive = tmp_path / "source.pyz"
    portable.export(app, archive)
    outside = tmp_path / "outside.txt"
    outside.write_text("UNTOUCHED")
    malicious = tmp_path / "duplicate.pyz"
    append_members(archive, malicious, [
        ("outputs/escape", stat.S_IFLNK | 0o777, str(outside)),
        (second, stat.S_IFREG | 0o644, "OVERWRITTEN"),
    ])
    try:
        with pytest.raises(ValueError):
            portable.import_bundle(malicious, tmp_path / "copies")
    finally:
        assert outside.read_text() == "UNTOUCHED"


@pytest.mark.parametrize("git_origin", [False, True])
@pytest.mark.parametrize("pattern", ["private/*.txt", "nested/private", "nested/*"])
def test_history_excludes_complete_paths_and_ancestors(app, tmp_path, git_origin, pattern):
    for name in ("public.txt", "private/omit.txt", "nested/private/omit.txt"):
        path = app.project / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("PUBLIC" if name == "public.txt" else "EXCLUDED_SENTINEL")
    if git_origin:
        def git(*args):
            return subprocess.run(["git", "-C", str(app.project), *args], check=True, capture_output=True)
        git("init")
        git("add", "public.txt", "private", "nested")
        git("-c", "user.name=Review", "-c", "user.email=review@localhost", "commit", "-m", "fixture")
    app.config["history_exclude"] = [pattern]
    excluded = "private/omit.txt" if pattern == "private/*.txt" else "nested/private/omit.txt"
    assert excluded not in history.scan(app.project, history.exclusions(app))
    archive = tmp_path / "excluded.pyz"
    portable.export(app, archive)
    with zipfile.ZipFile(archive) as bundle:
        assert "origin/" + excluded not in bundle.namelist()
        assert bundle.read("origin/public.txt") == b"PUBLIC"
    assert excluded not in history.initialize(app)["origin"]


@pytest.mark.parametrize("owner", ["project", "global"])
def test_internal_absolute_module_links_run_after_source_removed_and_reexport(app, tmp_path, owner):
    folder = (app.root if owner == "project" else app.home) / "modules" / "linked"
    write_json(folder / "module.json", {"id": "linked", "commands": [{"name": "run", "handler": "handler.py:run"}]})
    (folder / "implementation.py").write_text("def run(app, args, context): return 'offline implementation'\n")
    (folder / "handler.py").symlink_to(folder / "implementation.py")
    import_workflow(app, {"id": "linked-user", "steps": [{"id": "run", "kind": "tool", "tool": "linked.run"}]})
    archive = tmp_path / "linked.pyz"
    result = portable.export(app, archive)
    assert result["unresolved"] == []
    app.project.rename(tmp_path / "source-project-unavailable")
    app.home.rename(tmp_path / "source-home-unavailable")
    for count in range(2):
        target = Path(portable.import_bundle(archive, tmp_path / f"copies-{count}")["path"])
        imported = App(target, target / ".metaform/home", binding=False)
        registry = Registry(imported)
        assert registry.load(registry.discover()["linked.run"])(imported, {}, None) == "offline implementation"
        archive = tmp_path / f"reexport-{count}.pyz"
        assert portable.export(imported, archive)["unresolved"] == []


def test_module_external_link_is_explicitly_unresolved(app, tmp_path):
    folder = app.root / "modules" / "linked"
    write_json(folder / "module.json", {"id": "linked", "commands": [{"name": "run", "handler": "handler.py:run"}]})
    external = tmp_path / "external.py"
    external.write_text("def run(app, args, context): return 'external'\n")
    (folder / "handler.py").symlink_to(external)
    result = portable.export(app, tmp_path / "external.pyz")
    assert any(item.get("path") == str(folder / "handler.py") and item.get("target") == str(external)
               for item in result["unresolved"])


def test_import_preserves_ordinary_duplicate_regular_members(app, tmp_path):
    archive = tmp_path / "source.pyz"
    portable.export(app, archive)
    duplicate = tmp_path / "duplicate.pyz"
    append_members(archive, duplicate, [
        ("outputs/value.txt", stat.S_IFREG | 0o644, "first"),
        ("project-assets/outputs/value.txt", stat.S_IFREG | 0o644, "last"),
    ])
    target = Path(portable.import_bundle(duplicate, tmp_path / "copies")["path"])
    assert (target / ".metaform/outputs/value.txt").read_text() == "last"


def test_import_retains_history_symlink_provenance_and_external_target(app, tmp_path):
    external = tmp_path / "outside.txt"
    external.write_text("UNTOUCHED")
    (app.project / "reference.txt").symlink_to(external)
    archive = tmp_path / "source.pyz"
    portable.export(app, archive)
    before = history.initialize(app)
    target = Path(portable.import_bundle(archive, tmp_path / "copies")["path"])
    imported = App(target, target / ".metaform/home", binding=False)
    assert (target / "reference.txt").is_symlink()
    assert (target / "reference.txt").readlink() == external
    assert history.initialize(imported) == before
    assert external.read_text() == "UNTOUCHED"
