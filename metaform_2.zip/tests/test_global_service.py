"""One OS-user runtime owns all attached storage homes and project routes."""
import json
import os
from pathlib import Path
import time
import pytest

from metaform import service
from metaform.util import write_json
from test_service_lifecycle import child, wait_file


def test_distinct_storage_homes_share_one_persistent_owner_without_merging_data(tmp_path):
    homes = [tmp_path / "first-home", tmp_path / "second-home"]
    endpoints = []
    for index, home in enumerate(homes):
        write_json(home / "config.json", {"service_idle_timeout": .05, "auto_build": False})
        remote = service.RemoteKnowledge(home, None)
        registered = remote.call("project.register", {"path": str(tmp_path / f"project-{index}")})
        endpoints.append(service.ensure_service(home))
        assert remote.call("project.list", {}) == [registered]
    assert len({(item["pid"], item["port"], item["instance_id"]) for item in endpoints}) == 1
    assert endpoints[0]["service_id"] != endpoints[1]["service_id"]
    time.sleep(.2)
    assert service.ensure_service(homes[0]) == endpoints[0]
    assert service.ensure_service(homes[1]) == endpoints[1]
    assert service.stop_service(homes[0])["stopped"]
    assert not any((home / "service/endpoint.json").exists() for home in homes)
    assert service.RemoteKnowledge(homes[1], None).call("project.list", {})[0]["path"] == str(tmp_path / "project-1")


def test_global_start_status_and_restart_need_no_project_or_storage_home(tmp_path):
    endpoint = service.start_service()
    assert endpoint["pid"] != os.getpid()
    assert endpoint["runtime_dir"] == os.environ["METAFORM_RUNTIME_DIR"]
    assert service.service_status()["instance_id"] == endpoint["instance_id"]
    restarted = service.restart_service()
    assert restarted["instance_id"] != endpoint["instance_id"]
    assert restarted["port"] == endpoint["port"]
    assert not (tmp_path / ".metaform").exists()
    assert service.stop_service()["stopped"]


def test_eight_starters_with_different_homes_converge_on_one_runtime(tmp_path):
    processes = [child("import json,sys;from metaform.service import ensure_service;print(json.dumps(ensure_service(sys.argv[1])))",
                       tmp_path / f"home-{index}") for index in range(8)]
    try:
        endpoints = []
        for process in processes:
            output, error = process.communicate(timeout=30)
            assert process.returncode == 0, error.decode()
            endpoints.append(json.loads(output))
        assert len({(item['pid'], item['instance_id'], item['port']) for item in endpoints}) == 1
        assert len({item['service_id'] for item in endpoints}) == 8
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=3)


def test_both_viewer_projects_and_rpc_share_the_same_listener(tmp_path):
    import urllib.request
    from metaform.app import App

    projects = []
    for index in range(2):
        home = tmp_path / f"home-{index}"
        write_json(home / "config.json", {"auto_build": False})
        app = App(tmp_path / f"project-{index}", home)
        selected = service.open_viewer(app.project, home)
        with urllib.request.urlopen(selected['url'].rstrip('/') + '/api/settings', timeout=3) as response:
            assert json.load(response)['project_id'] == app.project_id
        with urllib.request.urlopen(selected['url'].rstrip('/') + '/api/health', timeout=3) as response:
            health = json.load(response)
        endpoint = service.ensure_service(home)
        assert health['pid'] == selected['pid'] == endpoint['pid']
        assert health['instance_id'] == selected['instance_id'] == endpoint['instance_id']
        projects.append(selected)
    assert len({(item['port'], item['pid']) for item in projects}) == 1
    assert projects[0]['url'] != projects[1]['url']


def test_different_build_requires_explicit_restart_without_stopping_current_owner(tmp_path, monkeypatch):
    endpoint = service.start_service()
    with monkeypatch.context() as patch:
        patch.setattr(service, 'runtime_fingerprint', lambda: 'different-loaded-build')
        import pytest
        with pytest.raises(service.ServiceError) as raised:
            service.start_service()
        assert raised.value.code == 'restart_required'
        assert service.service_status()['instance_id'] == endpoint['instance_id']
        assert service.service_status()['restart_required']
    assert service.start_service() == endpoint


def test_global_owner_migrates_verified_prior_home_owner_and_preserves_storage(tmp_path):
    import secrets
    from metaform.knowledge import KnowledgeStore

    home = tmp_path / 'legacy-home'
    directory = home / 'service'
    directory.mkdir(parents=True)
    store = KnowledgeStore(directory / 'knowledge.sqlite3')
    registered = store.call(None, 'project.register', {'path': str(tmp_path / 'project')}, request_id='original-registration')
    revision = store.revision
    write_json(directory / 'identity.json', {'service_id': 'retained-store-identity'})
    (directory / 'token').write_text(secrets.token_urlsafe(48))
    old = child('''
import json,os,sys,threading
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit,parse_qs
from filelock import FileLock
from metaform.util import write_json
root=Path(sys.argv[1]); token=(root/'token').read_text()
identity={'service_id':'retained-store-identity','instance_id':'prior-home-owner'}
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def reply(self,value):
  body=json.dumps(value).encode();self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_GET(self):
  assert self.headers['Authorization']=='Bearer '+token
  self.reply({'product':'metaform-knowledge','protocol':1,**identity,'ready':True,'challenge':parse_qs(urlsplit(self.path).query)['challenge'][0]})
 def do_POST(self):
  assert self.headers['Authorization']=='Bearer '+token
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  assert self.path=='/v1/stop' and body['instance_id']==identity['instance_id']
  self.reply({'stopping':True});threading.Thread(target=server.shutdown,daemon=True).start()
with FileLock(root/'instance.lock'):
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
 write_json(root/'endpoint.json',{'protocol':1,'host':'127.0.0.1','port':server.server_port,'pid':os.getpid(),**identity})
 server.serve_forever(poll_interval=.02);server.server_close();(root/'endpoint.json').unlink()
''', directory)
    try:
        wait_file(directory / 'endpoint.json', old)
        previous = json.loads((directory / 'endpoint.json').read_text())
        endpoint = service.ensure_service(home)
        assert old.wait(timeout=3) == 0
        assert endpoint['pid'] != old.pid
        assert endpoint['service_id'] == previous['service_id']
        remote = service.RemoteKnowledge(home, None)
        assert remote.call('project.register', {'path': str(tmp_path / 'project')}, request_id='original-registration') == registered
        assert remote.revision == revision
        assert remote.call('project.get', {'project_id': registered['project_id']}) == registered
    finally:
        if old.poll() is None:
            old.terminate()
        old.wait(timeout=3)


def test_service_launch_uses_the_loaded_package_with_pythonpath_cleared(tmp_path):
    import shutil
    import subprocess
    import sys
    import urllib.request

    package = tmp_path / 'copied-package'
    shutil.copytree(Path(service.__file__).parent, package / 'metaform', ignore=shutil.ignore_patterns('__pycache__'))
    asset = package / 'metaform/static/explorer.css'
    asset.write_text(asset.read_text() + '\n/* copied package identity */\n')
    runtime = tmp_path / 'copied-runtime'
    environment = {**os.environ, 'PYTHONPATH': '', 'METAFORM_RUNTIME_DIR': str(runtime)}
    bootstrap = 'import json,sys;sys.path.insert(0,sys.argv[1]);from metaform.service import start_service,runtime_fingerprint;print(json.dumps(start_service() | {"expected":runtime_fingerprint()}))'
    result = subprocess.run([sys.executable, '-c', bootstrap, str(package)], env=environment, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    endpoint = json.loads(result.stdout)
    assert endpoint['runtime_fingerprint'] == endpoint['expected']
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{endpoint['port']}/static/explorer.css", timeout=3) as response:
            assert response.read() == asset.read_bytes()
    finally:
        stopped = subprocess.run([sys.executable, '-c', 'import sys;sys.path.insert(0,sys.argv[1]);from metaform.service import stop_service;stop_service()', str(package)],
                                 env=environment, capture_output=True, text=True, timeout=10)
        assert stopped.returncode == 0, stopped.stderr


@pytest.mark.parametrize('command', ['service.stop', 'web.stop', 'service.restart'])
def test_public_viewer_lifecycle_returns_before_its_own_handler_is_drained(tmp_path, command):
    import urllib.request
    from metaform.app import App

    home = tmp_path / 'home'
    write_json(home / 'config.json', {'auto_build': False})
    app = App(tmp_path / 'project', home)
    selected = service.open_viewer(app.project, home)
    started = time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(selected['url'] + '/api/semantic/' + command,
            data=b'{}', headers={'Content-Type': 'application/json'}), timeout=3) as response:
        result = json.load(response)
    assert time.monotonic() - started < 3
    assert result['restarting' if command == 'service.restart' else 'stopping'] is True
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        status = service.service_status()
        if command == 'service.restart':
            if status['ready'] and status['instance_id'] != selected['instance_id']:
                assert status['port'] == selected['port']
                return
        elif not service._owned(service.runtime_directory()):
            assert not status['ready']
            assert not service._owned(home / 'service')
            return
        time.sleep(.02)
    pytest.fail('The acknowledged lifecycle action did not finish')


def test_explicit_stop_drains_an_already_running_viewer_command(tmp_path):
    import concurrent.futures
    import urllib.request
    from metaform.app import App

    home = tmp_path / 'home'
    write_json(home / 'config.json', {'auto_build': False})
    app = App(tmp_path / 'project', home)
    module = app.root / 'modules/slow-view'
    write_json(module / 'module.json', {'id': 'slow-view', 'name': 'Slow fixture', 'commands': [{
        'name': 'wait', 'handler': 'handler.py:wait', 'inputSchema': {'type': 'object', 'properties': {
            'entered': {'type': 'string'}, 'release': {'type': 'string'}}}}]})
    (module / 'handler.py').write_text('import time\nfrom pathlib import Path\ndef wait(app,args,context):\n'
        '    Path(args["entered"]).touch()\n    while not Path(args["release"]).exists():time.sleep(.01)\n    return {"finished":True}\n')
    selected = service.open_viewer(app.project, home)
    entered, release = tmp_path / 'entered', tmp_path / 'release'
    def request():
        with urllib.request.urlopen(urllib.request.Request(selected['url'] + '/api/semantic/slow-view.wait',
                data=json.dumps({'entered': str(entered), 'release': str(release)}).encode(),
                headers={'Content-Type': 'application/json'}), timeout=5) as response:
            return json.load(response)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        pending = executor.submit(request)
        try:
            wait_file(entered, timeout=3)
            stopping = executor.submit(service.stop_service)
            time.sleep(.15)
            assert not stopping.done()
        finally:
            release.touch()
        assert pending.result(timeout=3) == {'finished': True}
        assert stopping.result(timeout=3)['stopped']


@pytest.mark.parametrize('name,value', [('METAFORM_PORTABLE', '1'), ('METAFORM_BINDING', 'invalid caller binding')])
def test_global_child_does_not_retain_the_starting_clients_project_context(tmp_path, monkeypatch, name, value):
    import urllib.request
    from metaform.app import App

    with monkeypatch.context() as patch:
        patch.setenv(name, value)
        original = service.start_service()
    home = tmp_path / 'unrelated-home'
    write_json(home / 'config.json', {'auto_build': False})
    selected = App(tmp_path / 'unrelated-project', home)
    assert selected.knowledge_mode == 'service'
    viewer = service.open_viewer(selected.project, home)
    assert viewer['instance_id'] == original['instance_id']
    with urllib.request.urlopen(viewer['url'] + '/api/settings', timeout=3) as response:
        settings = json.load(response)
    assert settings['knowledge_mode'] == 'service'
    assert settings['assignment'] is None


def test_invalid_restart_address_leaves_the_existing_global_owner_running():
    original = service.start_service()
    with pytest.raises(ValueError):
        service.restart_service(host='not-a-loopback-listener')
    assert service.service_status()['instance_id'] == original['instance_id']


def test_slow_new_home_does_not_block_existing_reads_and_same_home_opens_serialize(tmp_path):
    import concurrent.futures
    import urllib.request
    from filelock import FileLock
    from metaform.app import App

    home = tmp_path / 'ready-home'
    write_json(home / 'config.json', {'auto_build': False})
    selected = App(tmp_path / 'ready-project', home)
    opened = service.open_viewer(selected.project, home)
    origin = f"http://127.0.0.1:{opened['port']}"
    waiting_home = tmp_path / 'waiting-home'
    write_json(waiting_home / 'config.json', {'auto_build': False})
    directory = waiting_home / 'service'
    directory.mkdir()
    projects = [tmp_path / 'new-a', tmp_path / 'new-b']
    for project in projects:
        project.mkdir()

    def request(url, body=None, timeout=5):
        call = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None,
                                      headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(call, timeout=timeout) as response:
            return json.load(response)

    held = FileLock(directory / 'instance.lock')
    held.acquire()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            pending = [executor.submit(request, origin + '/api/projects/open', {'path': str(project), 'home': str(waiting_home)})
                       for project in projects]
            try:
                for project in projects:
                    wait_file(project / '.metaform/config.json', timeout=3)
                assert all(not future.done() for future in pending)
                catalog = request(origin + '/api/projects', timeout=1)
                assert any(entry['project_id'] == selected.project_id for entry in catalog)
                assert request(opened['url'] + '/api/semantic/graph.get', {'id': 'absent'}, timeout=1)['record'] is None
            finally:
                held.release()
            attached = [future.result(timeout=5) for future in pending]
    finally:
        held.release()
    assert len({entry['project_id'] for entry in attached}) == 2
    records = service.RemoteKnowledge(waiting_home, None).call('project.list', {})
    assert {record['path'] for record in records} == {str(project) for project in projects}
    assert service.ensure_service(waiting_home)['instance_id'] == opened['instance_id']
