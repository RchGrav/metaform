"""Interrupt a real automatic PEP 517 build without leaving its worker behind."""
import json
import os
import selectors
import signal
import subprocess
import sys
import time

import pytest

from metaform.app import App
from metaform.locking import lock
from metaform.util import write_json
from test_release_packaging import build_source


@pytest.mark.parametrize('transport', ['installed', 'portable'])
def test_mcp_interrupt_cancels_automatic_build_and_releases_lock(tmp_path, transport):
    source = build_source(tmp_path / 'source')
    backend = source / 'fixture_backend.py'
    original = backend.read_text()
    backend.write_text(original.replace('    counter = Path("build-count")',
        '    import time\n    Path("build-started").touch()\n    time.sleep(30)\n    counter = Path("build-count")'))
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': True})
    script = 'import metaform.mcp_server as server; ' + ('server.types=None; ' if transport == 'portable' else '') + 'raise SystemExit(server.main())'
    process = subprocess.Popen([sys.executable, '-c', script], cwd=source, stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True,
        env={**os.environ, 'METAFORM_HOME': str(home), 'METAFORM_PROJECT': str(source)})
    try:
        def send(value):
            process.stdin.write(json.dumps(value) + '\n')
            process.stdin.flush()
        send({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
            'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'build-cancel', 'version': '1'}}})
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            assert selector.select(timeout=10)
        assert json.loads(process.stdout.readline())['id'] == 1
        send({'jsonrpc': '2.0', 'method': 'notifications/initialized'})
        send({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'system.debug', 'arguments': {'enabled': True}}})
        deadline = time.monotonic() + 10
        while not (source / 'build-started').exists():
            assert process.poll() is None
            assert time.monotonic() < deadline
            time.sleep(0.01)
        process.send_signal(signal.SIGINT)
        assert process.wait(timeout=4) == 130
        assert 'Traceback' not in process.stderr.read()
        app = App(source, home, binding=False)
        assert app.get('built_hash') is None
        assert app.get('debug') is True
        claim = lock(app, 'build')
        claim.acquire(timeout=0)
        claim.release()
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
        process.communicate(timeout=5)


def test_cancelled_auto_build_releases_waiter_without_releasing_another_build(tmp_path, monkeypatch):
    import asyncio
    import threading
    from filelock import FileLock
    from metaform import locking
    from metaform.registry import Registry

    source = build_source(tmp_path / 'source')
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': True})
    app = App(source, home, binding=False)
    other_build = lock(app, 'build')
    waiting = threading.Event()

    class ObservedLock(FileLock):
        def acquire(self, *args, **kwargs):
            waiting.set()
            return super().acquire(*args, **kwargs)

    monkeypatch.setattr(locking, 'FileLock', ObservedLock)

    async def scenario():
        task = asyncio.create_task(Registry(app).after_call())
        assert await asyncio.to_thread(waiting.wait, 2)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await asyncio.wait_for(task, timeout=1)

    with other_build:
        asyncio.run(scenario())
        assert other_build.is_locked
    assert not (source / 'build-count').exists()
