import asyncio
import json
import os
import sys

import pytest
from mcp import Client, types
from mcp.client.stdio import StdioServerParameters


@pytest.mark.parametrize("mode", ["legacy", "auto"])
def test_stdio_discovery_takeover_and_sampling(tmp_path, mode):
    from metaform.util import write_json
    write_json(tmp_path / "home" / "config.json", {"knowledge_mode": "legacy"})
    async def scenario():
        async def sample(context, params):
            request = json.loads(params.messages[0].content.text)
            assert "schema" in request and "run_id" not in request
            return types.CreateMessageResult(
                role="assistant",
                content=types.TextContent(
                    type="text", text=json.dumps({"elements": {}, "joins": []})
                ),
                model="test-fixture",
                stop_reason="endTurn",
            )

        params = StdioServerParameters(
            command=sys.executable,
            args=["-m", "metaform.mcp_server"],
            env={
                "METAFORM_RUNTIME_DIR": os.environ["METAFORM_RUNTIME_DIR"],
                "PYTHONPATH": os.environ.get("PYTHONPATH", ""),
                "METAFORM_HOME": str(tmp_path / "home"),
                "METAFORM_PROJECT": str(tmp_path / "project"),
            },
        )
        async with Client(params, mode=mode, sampling_callback=sample) as client:
            listing = await client.list_tools()
            names = {t.name for t in listing.tools}
            assert "abort" in names and "imagegen.generate" in names
            modern = "metaform" in names

            async def call(command, arguments=None):
                return await client.call_tool(
                    "metaform" if modern else command,
                    {"command": command, "arguments": arguments or {}}
                    if modern
                    else arguments or {},
                )

            started = await call("intake.start")
            assert not started.is_error, started
            hidden = (
                await client.call_tool("metaform", {})
                if modern
                else await client.list_tools()
            )
            if modern:
                assert "graph.put" not in {
                    c["name"] for c in hidden.structured_content["commands"]
                }
            else:
                assert "graph.put" not in {t.name for t in hidden.tools}
            response = await call("intake.drive")
            assert not response.is_error, response
            assert response.structured_content["recorded"]
            final = await call("intake.next")
            assert final.structured_content["status"] == "complete"
            resources = await client.list_resources()
            assert any("schema" in str(r.uri) for r in resources.resources)

    asyncio.run(scenario())


@pytest.mark.parametrize("mode", ["legacy", "auto"])
def test_stdio_sampling_examines_complete_native_graph_without_project_tools(
    tmp_path, mode
):
    async def scenario():
        project = tmp_path / "project"
        project.mkdir()
        (project / "example.txt").write_text("repo-only-evidence")
        home = tmp_path / "home"
        home.mkdir()
        (home / "config.json").write_text(json.dumps({"debug": True, "knowledge_mode": "legacy"}))
        reads = []
        roles = []

        async def sample(context, params):
            first = params.messages[0].content
            payload = json.loads(first.text)
            role = payload["role"]
            roles.append(role)
            assert params.include_context == "none"
            names = {t.name for t in params.tools or []}
            if role == "native_expert" and len(params.messages) == 1:
                assert "intake.read" in names
                return types.CreateMessageResultWithTools(
                    role="assistant",
                    content=[
                        types.ToolUseContent(
                            name="intake.read",
                            id="read-file",
                            input={"path": "example.txt"},
                        )
                    ],
                    model="fixture",
                    stop_reason="toolUse",
                )
            if role == "native_expert":
                content = params.messages[-1].content
                reads.append(content[0].content[0].text)
                purpose = "repo-only-OP"
            else:
                assert "intake.read" not in names and "intake.files" not in names
                assert role == "latent_expert"
                assert params.system_prompt
                assert "repo-only-evidence" not in json.dumps([m.model_dump() for m in params.messages])
                assert payload["inputs"]["native"]["joins"][0]["purpose"] == "repo-only-OP"
                assert set(payload["inputs"]["native"]["elements"]) == {"media.photo", "document.listing"}
                purpose = "Outside examination OP"
            if role == "latent_expert" and len(params.messages) == 1:
                return types.CreateMessageResultWithTools(
                    role="assistant",
                    content=[types.ToolUseContent(
                        name="intake.get", id="global-lookup",
                        input={"id": "media.photo"},
                    )],
                    model="fixture", stop_reason="toolUse",
                )
            answer = {
                "elements": {
                    "media.photo": {
                        "entity_desc": "photo",
                        "entity_schema": "metaform:element",
                        "entity_json_obj": {"en": "photo"},
                    },
                    "document.listing": {
                        "entity_desc": "listing",
                        "entity_schema": "metaform:element",
                        "entity_json_obj": {"en": "listing"},
                    },
                },
                "joins": [
                    {
                        "object_id": "document.listing",
                        "element_id": "media.photo",
                        "type": "receiving_entity",
                        "purpose": purpose,
                    }
                ],
            }
            return types.CreateMessageResultWithTools(
                role="assistant",
                content=[types.TextContent(type="text", text=json.dumps(answer))],
                model="fixture",
                stop_reason="endTurn",
            )

        params = StdioServerParameters(
            command=sys.executable,
            args=["-m", "metaform.mcp_server"],
            env={
                "METAFORM_RUNTIME_DIR": os.environ["METAFORM_RUNTIME_DIR"],
                "PYTHONPATH": os.environ.get("PYTHONPATH", ""),
                "METAFORM_HOME": str(tmp_path / "home"),
                "METAFORM_PROJECT": str(project),
            },
        )
        from metaform.app import App
        from metaform.intake import Intake
        Intake(App(project, home))._start("native")
        async with Client(
            params,
            mode=mode,
            sampling_callback=sample,
            sampling_capabilities=types.SamplingCapability(
                tools=types.SamplingToolsCapability()
            ),
        ) as client:
            modern = "metaform" in {t.name for t in (await client.list_tools()).tools}

            async def call(name, arguments=None):
                response = await client.call_tool(
                    "metaform" if modern else name,
                    {"command": name, "arguments": arguments or {}}
                    if modern
                    else arguments or {},
                )
                assert not response.is_error, response
                return response.structured_content

            await call("intake.drive")
            await call("intake.next")
            await call("intake.drive")
            assert (await call("intake.next"))["status"] == "complete"
            assert "repo-only-evidence" in reads[0]
            assert roles.count("native_expert") == 2
            assert roles.count("type_proofreader") == 0
            assert roles.count("latent_expert") == 2
            global_data = await call("graph.dump", {"global": True})
            assert "repo-only-OP" not in json.dumps(global_data)

    asyncio.run(scenario())


@pytest.mark.parametrize("transport", ["installed", "portable"])
@pytest.mark.parametrize("entrypoint", ["cli", "module"])
@pytest.mark.parametrize("ending", ["interrupt", "eof", "blocked_output", "large_response"])
def test_mcp_server_releases_open_input_on_exit(tmp_path, transport, entrypoint, ending):
    import selectors
    import signal
    import subprocess

    from metaform.util import write_json

    project = tmp_path / "project"
    project.mkdir()
    write_json(tmp_path / "home" / "config.json", {"knowledge_mode": "legacy", "auto_build": False})
    write_json(tmp_path / "home" / "schemas.json", {"urn:large": {"$id": "urn:large", "$schema": "https://json-schema.org/draft/2020-12/schema", "type": "string", "description": "é日本語 🧭" * 100_000}})
    cleanup = tmp_path / "process-cleanup"
    script = f"import sys,atexit; from pathlib import Path; atexit.register(Path({str(cleanup)!r}).write_text, 'closed'); import metaform.mcp_server as server; "
    if transport == "portable":
        script += "server.types = None; "
    if entrypoint == "cli":
        script += "from metaform.cli import main; sys.exit(main(['mcp']))"
    else:
        script += "sys.exit(server.main())"
    process = subprocess.Popen(
        [sys.executable, "-c", script], cwd=project,
        env={**os.environ, "METAFORM_HOME": str(tmp_path / "home"), "METAFORM_PROJECT": str(project)},
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    try:
        process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": "2025-11-25", "capabilities": {}, "clientInfo": {"name": "shutdown-test", "version": "1"}
        }}) + "\n")
        process.stdin.flush()
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            assert selector.select(timeout=10), "MCP did not answer initialize"
        assert json.loads(process.stdout.readline())["id"] == 1
        process.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n")
        process.stdin.flush()
        if ending in {"blocked_output", "large_response"}:
            process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": 2, "method": "resources/read", "params": {"uri": "metaform://schema/urn:large"}}) + "\n")
            process.stdin.flush()
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                assert selector.select(timeout=5), "MCP did not begin its resource response"
        if ending == "large_response":
            process.stdin.write(json.dumps({"jsonrpc": "2.0", "id": 3, "method": "ping"}) + "\n")
            process.stdin.flush()
            replies = [json.loads(process.stdout.readline()), json.loads(process.stdout.readline())]
            replies = {reply["id"]: reply["result"] for reply in replies}
            assert json.loads(replies[2]["contents"][0]["text"])["description"] == "é日本語 🧭" * 100_000
            assert replies[3] == {}
        if ending in {"interrupt", "blocked_output"}:
            process.send_signal(signal.SIGINT)
            # communicate() closes stdin and would conceal the blocked-reader bug.
            assert process.wait(timeout=5) == 130
            assert not process.stdin.closed
        else:
            process.stdin.close()
            process.stdin = None
            assert process.wait(timeout=5) == 0
        stderr = process.stderr.read()
        assert "Traceback" not in stderr, stderr
        assert cleanup.read_text() == "closed"
    finally:
        if process.poll() is None:
            process.kill()
        process.communicate(timeout=5)


@pytest.mark.parametrize('transport', ['installed', 'portable'])
def test_removed_project_module_is_absent_from_mcp_discovery_and_dispatch(tmp_path, transport):
    from metaform.util import write_json
    project = tmp_path / 'project'
    other = tmp_path / 'other'
    project.mkdir()
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    script = (
        "from metaform.registry import Registry; original = Registry.discover; "
        "Registry.discover = lambda self: {key: command for key, command in original(self).items() if command.module != 'project'}; "
        "import metaform.mcp_server as server; "
        + ("server.types = None; " if transport == 'portable' else '')
        + 'raise SystemExit(server.main())'
    )

    async def scenario():
        params = StdioServerParameters(command=sys.executable, args=['-c', script],
                                       env={'PYTHONPATH': os.environ.get('PYTHONPATH', ''), 'METAFORM_HOME': str(home), 'METAFORM_PROJECT': str(project), 'METAFORM_RUNTIME_DIR': os.environ['METAFORM_RUNTIME_DIR']})
        async with Client(params) as client:
            listing = await client.list_tools()
            assert not any(tool.name.startswith('project.') for tool in listing.tools)
            for name, arguments in [('project.select', {'project': str(other)}),
                                    ('metaform', {'command': 'project.select', 'arguments': {'project': str(other)}})]:
                result = await client.call_tool(name, arguments)
                assert result.is_error
                assert not other.exists()

    asyncio.run(scenario())


@pytest.mark.parametrize('transport', ['installed', 'portable'])
def test_interrupt_unwinds_synchronous_module_handler(tmp_path, transport):
    import selectors
    import signal
    import subprocess
    import time
    from metaform.util import write_json

    home, project = tmp_path / 'home', tmp_path / 'project'
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    module = project / '.metaform/modules/blocking'
    write_json(module / 'module.json', {'id': 'blocking', 'commands': [{
        'name': 'wait', 'handler': 'worker.py:wait', 'inputSchema': {'type': 'object', 'properties': {}}
    }]})
    (module / 'worker.py').write_text('''from pathlib import Path
import time
def wait(app, args, context):
    Path(__file__).with_name('accepted').touch()
    try:
        time.sleep(10)
    finally:
        Path(__file__).with_name('unwound').touch()
    return {}
''')
    script = 'import metaform.mcp_server as server; ' + ('server.types=None; ' if transport == 'portable' else '') + 'raise SystemExit(server.main())'
    process = subprocess.Popen([sys.executable, '-c', script], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, cwd=project,
                               env={**os.environ, 'METAFORM_HOME': str(home), 'METAFORM_PROJECT': str(project)})
    try:
        process.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {
            'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'interrupt-test', 'version': '1'}}}) + '\n')
        process.stdin.flush()
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            assert selector.select(timeout=10)
        assert json.loads(process.stdout.readline())['id'] == 1
        process.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'}) + '\n')
        process.stdin.write(json.dumps({'jsonrpc': '2.0', 'id': 2, 'method': 'tools/call', 'params': {'name': 'blocking.wait', 'arguments': {}}}) + '\n')
        process.stdin.flush()
        deadline = time.monotonic() + 5
        while not (module / 'accepted').exists():
            assert process.poll() is None
            assert time.monotonic() < deadline
            time.sleep(0.01)
        process.send_signal(signal.SIGINT)
        assert process.wait(timeout=3) == 130
        assert (module / 'unwound').exists()
        assert 'Traceback' not in process.stderr.read()
    finally:
        if process.poll() is None:
            process.kill()
        process.communicate(timeout=5)


def test_portable_invalid_identifiers_do_not_terminate_transport(tmp_path):
    import subprocess
    from metaform.util import write_json

    project, home = tmp_path / 'project', tmp_path / 'home'
    project.mkdir()
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': False})
    invalid_ids = [{}, [], True, None, 1.5]
    messages = [{'jsonrpc': '2.0', 'id': value, 'method': 'ping'} for value in invalid_ids]
    messages.extend([
        {'jsonrpc': '2.0', 'method': 'notifications/cancelled', 'params': {'requestId': []}},
        {'jsonrpc': '2.0', 'method': 'notifications/cancelled', 'params': []},
        {'jsonrpc': '2.0', 'id': 8, 'method': 'ping', 'params': []},
        {'jsonrpc': '2.0', 'id': 9, 'method': 'ping'},
    ])
    result = subprocess.run([sys.executable, '-c',
        'import metaform.mcp_server as server; server.types=None; raise SystemExit(server.main())'],
        input=''.join(json.dumps(message) + '\n' for message in messages),
        capture_output=True, text=True, timeout=10, cwd=project,
        env={**os.environ, 'METAFORM_HOME': str(home), 'METAFORM_PROJECT': str(project)})
    assert result.returncode == 0, result.stderr
    responses = [json.loads(line) for line in result.stdout.splitlines()]
    assert [response['error']['code'] for response in responses if 'error' in response] == [-32600] * 5 + [-32602]
    assert responses[-1] == {'jsonrpc': '2.0', 'id': 9, 'result': {}}
    assert 'Traceback' not in result.stderr


def test_interrupt_during_future_callback_finishes_callback_before_cancelling(monkeypatch, capsys):
    import signal
    import metaform.mcp_server as server

    events = []

    async def serving(app):
        loop = asyncio.get_running_loop()
        pending = loop.create_future()

        def complete():
            assert not pending.cancelled()
            signal.raise_signal(signal.SIGINT)
            pending.set_result(None)
            events.append('callback completed')

        loop.call_soon(complete)
        try:
            await pending
        finally:
            events.append('serving unwound')

    previous = signal.getsignal(signal.SIGINT)
    monkeypatch.setattr(server, 'serve', serving)
    assert server.main() == 130
    assert events == ['callback completed', 'serving unwound']
    assert signal.getsignal(signal.SIGINT) is previous
    assert 'Traceback' not in capsys.readouterr().err
