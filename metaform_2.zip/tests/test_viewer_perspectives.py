import pytest

from metaform.backends import JSONGraph
from metaform.viewer import create_app


def record(name):
    return {
        "entity_desc": name + " description",
        "entity_schema": "metaform:element",
        "entity_json_obj": {"en": name, "ef": name + " function"},
    }


@pytest.fixture(params=["sqlite", "json"])
def perspectives(app, request):
    if request.param == "json":
        app.graph = JSONGraph(app.root / "perspectives.json")
    app.graph.put({"elements": {"code.shared": record("Contextual")}}, "native")
    app.graph.put({"elements": {"code.shared": record("Latent")}}, "archaeology")
    return create_app(app).test_client()


@pytest.mark.parametrize("perspective,name", [("contextual", "Contextual"), ("latent", "Latent")])
def test_network_uses_selected_source_payload(perspectives, perspective, name):
    response = perspectives.get("/api/network", query_string={"perspective": perspective})
    assert response.status_code == 200
    node = response.json["nodes"][0]
    assert node["name"] == name
    assert node["entity_desc"] == name + " description"
    assert node["entity_json_obj"]["ef"] == name + " function"


@pytest.mark.parametrize("endpoint", ["/api/network", "/api/graph"])
def test_search_matches_only_selected_source_payload(perspectives, endpoint):
    contextual = perspectives.get(endpoint, query_string={"perspective": "contextual", "q": "Contextual"})
    latent = perspectives.get(endpoint, query_string={"perspective": "latent", "q": "Contextual"})
    assert contextual.status_code == latent.status_code == 200
    contextual_records = contextual.json["nodes"] if endpoint.endswith("network") else contextual.json
    latent_records = latent.json["nodes"] if endpoint.endswith("network") else latent.json
    assert [row["id"] for row in contextual_records] == ["code.shared"]
    assert latent_records == []


def test_inspector_returns_selected_source_and_its_joins(app, perspectives):
    for source in ("native", "archaeology"):
        app.graph.put({"joins": [{"id": "relation", "object_id": "code.shared", "element_id": "code.other", "type": "dependency", "purpose": source}]}, source)
    result = perspectives.get("/api/element/code.shared?perspective=contextual").json
    assert result["record"] == record("Contextual")
    assert [join["purpose"] for join in result["joins"]] == ["native"]
    assert {observation["source"] for observation in result["provenance"]} == {"native"}


def test_missing_source_node_stays_a_reference(app, perspectives):
    app.graph.put({"elements": {"code.other": record("Latent only")}}, "archaeology")
    app.graph.put({"joins": [{"id": "relation", "object_id": "code.shared", "element_id": "code.other", "type": "dependency"}]}, "native")
    network = perspectives.get("/api/network?perspective=contextual").json
    node = next(node for node in network["nodes"] if node["id"] == "code.other")
    assert node == {"id": "code.other", "name": "code.other", "kind": "reference", "sources": []}
    assert perspectives.get("/api/element/code.other?perspective=contextual").json["record"] is None


def test_edit_updates_only_selected_source(app, perspectives):
    response = perspectives.post("/api/element/code.shared", json={"perspective": "contextual", "record": record("Revised")})
    assert response.status_code == 200
    assert perspectives.get("/api/element/code.shared?perspective=contextual").json["record"] == record("Revised")
    assert perspectives.get("/api/element/code.shared?perspective=latent").json["record"] == record("Latent")
    revised = [observation for observation in app.graph.provenance("code.shared") if observation["record"]["entity_json_obj"]["en"] == "Revised"]
    assert [observation["source"] for observation in revised] == ["native"]


def test_join_edit_stays_in_selected_source(app, perspectives):
    for source in ("native", "archaeology"):
        app.graph.put({"joins": [{"id": "relation", "object_id": "code.shared", "element_id": "code.other", "type": "dependency", "purpose": source}]}, source)
    join = app.graph.joins(scope="native")[0]
    join["purpose"] = "Revised purpose"
    response = perspectives.post("/api/element/" + join["id"], json={"perspective": "contextual", "join": join})
    assert response.status_code == 200
    assert [item["purpose"] for item in app.graph.joins(scope="native")] == ["Revised purpose"]
    assert [item["purpose"] for item in app.graph.joins(scope="archaeology")] == ["archaeology"]


def test_similarity_view_contains_structure_without_source_payloads(app, perspectives):
    for source in ("native", "archaeology"):
        app.graph.put({"joins": [{"id": "relation", "object_id": "code.shared", "element_id": "code.other", "type": "dependency", "purpose": "Secret purpose", "join_logic": "Secret logic"}]}, source)
    response = perspectives.get("/api/network?perspective=similarity")
    assert response.status_code == 200
    assert {node["id"]: node["membership"] for node in response.json["nodes"]} == {"code.shared": "11", "code.other": "11"}
    assert [join["membership"] for join in response.json["joins"]] == ["11"]
    assert response.json["joins"][0]["sources"] == {
        "native": [app.graph.joins(scope="native")[0]["id"]],
        "archaeology": [app.graph.joins(scope="archaeology")[0]["id"]],
    }
    for semantic in ("Secret purpose", "Secret logic", "Contextual", "Latent", "entity_desc", "entity_json_obj", "purpose", "join_logic"):
        assert semantic not in response.get_data(as_text=True)
    assert perspectives.get("/api/network?perspective=similarity&q=Contextual").json["nodes"] == []
    assert {node["id"] for node in perspectives.get("/api/network?perspective=similarity&q=code.shared").json["nodes"]} == {"code.shared", "code.other"}


def test_persisted_similarity_join_cannot_be_semantically_edited(app, perspectives):
    shape = {"id": "shape", "object_id": "code.shared", "element_id": "code.other", "type": "dependency", "membership": "11", "schema_id": "metaform:merged-join", "sources": {"native": ["native-reference"], "archaeology": ["latent-reference"]}}
    app.graph.put({"joins": [shape]}, "merged")
    before = app.graph.joins(scope="merged")
    response = perspectives.post("/api/element/shape", json={"join": {"id": "shape", "object_id": "code.shared", "element_id": "code.other", "type": "dependency", "purpose": "New semantic content"}})
    assert response.status_code == 400
    assert "read-only" in response.json["error"]
    assert app.graph.joins(scope="merged") == before
