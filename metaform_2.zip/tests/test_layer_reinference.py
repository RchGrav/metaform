import copy

import pytest

from metaform.layers import active_attachments, inspect_layer
from metaform.models import capture_model, publish_foundation
from metaform.transform import apply_transformation, impact
from metaform.workflow import Engine
from test_model_transformations import foundation, generate_advice


def branch_foundation(app):
    snapshot = foundation(app)
    owner = snapshot['artifact']['owner']
    root = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    child = root | {'id': 'code.cpp.standard'}
    snapshot['types'][child['id']] = snapshot['types'][root['id']] | {
        'id': child['id'], 'description': 'The original code.cpp.standard account stays verbatim.',
        'ef': 'Expresses operations according to a shared standard.'}
    snapshot['narrowings'] = [{'id': 'narrowing:standard', 'owner': owner, 'parent': root,
                               'child': child, 'category': 'encounter', 'reason': 'Uses the shared standard.'}]
    snapshot['bindings'][0]['type'] = child
    snapshot['joins'][0].update(provider=child, provider_type=child)
    return snapshot


@pytest.mark.parametrize('explicit_mapping', [False, True])
def test_branch_relocation_preserves_knowledge_then_changed_ef_schedules_reinference(app, explicit_mapping):
    original = branch_foundation(app)
    source = publish_foundation(app, original)
    owner = original['artifact']['owner']
    root = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    child = root | {'id': 'code.cpp.standard'}
    destination_root = root | {'id': 'code.cxx'}
    destination_child = child | {'id': 'code.cxx.standard'}
    exact_request = 'Explain {{ literal }} code.cpp.standard implications.\nPreserve this question.'
    child_layer = generate_advice(app, source, child, exact_request)
    engine_layer = generate_advice(app, source, original['artifact'], 'Explain this engine context.')
    source_snapshot = capture_model(app, source)
    source_advice = active_attachments(app, source)
    patch = {'id': 'relocate-language-branch', 'source': source, 'destination_model': 'moved',
             'purpose': 'Move the same Type branch.', 'operations': [
                 {'op': 'relocate', 'target': root, 'replacement': destination_root, 'reason': 'Meaning preserved.'}],
             'mapping': [{'from': root, 'to': destination_root, 'meaning_preserved': True,
                          'reason': 'Meaning preserved.'}] if explicit_mapping else []}
    result = apply_transformation(app, patch)
    assert result['reinference'] == []
    assert all(row['action'] in ('preserve', 'relocate') for row in result['impact']['decisions'])
    assert any(move['from'] == child and move['to'] == destination_child for move in result['effective_mapping'])
    destination_advice = active_attachments(app, result['model'])
    assert {item['id'] for item in destination_advice} == {item['id'] for item in source_advice}
    assert next(item for item in destination_advice if item['layer'] == child_layer)['subject'] == destination_child
    assert all(any(dep.get('target') == destination_child for dep in item['dependencies']) for item in destination_advice)
    assert capture_model(app, source) == source_snapshot
    assert active_attachments(app, source) == source_advice
    moved = capture_model(app, result['model'])
    assert moved['activities'][-1]['transformation'] == patch
    assert moved['types']['code.cxx.standard']['description'] == original['types']['code.cpp.standard']['description']
    assert inspect_layer(app, child_layer, result['model'])['recipe']['request'] == exact_request
    # The external read-only impact call receives only a root mapping.
    external = impact(app, source, result['model'], [{'from': root, 'to': destination_root,
        'meaning_preserved': True, 'reason': 'Meaning preserved.'}])
    assert [item['action'] for item in external['decisions']] == [item['action'] for item in result['impact']['decisions']]
    changed = moved['types']['code.cxx.standard'] | {'ef': 'Expresses an intentionally changed set of operations.'}
    followup = apply_transformation(app, {'id': 'change-moved-meaning', 'source': result['model'],
        'destination_model': 'changed', 'purpose': 'Change the moved Type meaning.',
        'operations': [{'op': 'update', 'target': destination_child, 'record': changed, 'reason': 'The EF changed.'}], 'mapping': []})
    assert {job['layer']['id'] for job in followup['reinference']} == {child_layer['id'], engine_layer['id']}
    assert active_attachments(app, followup['model']) == []
    for job in followup['reinference']:
        assert any(record['ref'] == destination_child and record['value'].get('ef') == changed['ef']
                   for record in job['inputs']['context']['records'])
        if job['layer'] == child_layer:
            assert job['inputs']['request'] == exact_request
        subject = job['inputs']['subjects'][0]
        Engine(app).submit(job['run_id'], job['request_id'], {'attachments': [{'subject': subject,
            'schema_ref': 'urn:test:transformation-advice', 'slot': 'advice', 'payload': 'New destination advice.',
            'applicability': {'scope': {'kind': 'direct', 'target': subject}, 'reason': 'Reinferred from the changed EF.'}}]})
        assert Engine(app).next(job['run_id'])['status'] == 'complete'
    assert len(active_attachments(app, followup['model'])) == 2
    assert active_attachments(app, source) == source_advice


@pytest.mark.parametrize('authored_marker', [{'authored': True}, {'provenance': {'source': 'authored'}}])
def test_changed_upstream_knowledge_preserves_authored_dependents(app, authored_marker):
    original = foundation(app)
    source = publish_foundation(app, original)
    owner = original['artifact']['owner']
    engine_layer = generate_advice(app, source, original['artifact'], 'Explain the engine.')
    installer = original['artifact'] | {'id': 'demo:installer'}
    authored_layer = generate_advice(app, source, installer, 'Retain my own installer note.')
    derived_layer = generate_advice(app, source, installer, 'Derive installer implications from the engine.')
    upstream = next(item for item in active_attachments(app, source) if item['layer'] == engine_layer)
    for layer, manual in ((authored_layer, True), (derived_layer, False)):
        record = app.graph.get('layer-state:' + layer['id'])
        bundle = record['entity_json_obj']['generations'][record['entity_json_obj']['latest']]
        attachment = bundle['attachments'][0]
        attachment['dependencies'] = [{'kind': 'record', 'target': upstream['generation'], 'fingerprint': 'recorded-generation'}]
        if manual:
            attachment.update(copy.deepcopy(authored_marker))
        app.graph.put({'elements': {'layer-state:' + layer['id']: record}, 'joins': []}, source='authored', layer='knowledge-layers')
    before = active_attachments(app, source)
    type_ref = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    result = apply_transformation(app, {'id': 'change-upstream', 'source': source, 'destination_model': 'changed',
        'purpose': 'Change the engine Type.', 'operations': [{'op': 'update', 'target': type_ref,
            'record': original['types']['code.cpp'] | {'ef': 'A changed engine function.'}, 'reason': 'Meaning changed.'}], 'mapping': []})
    decisions = {item['layer']['id']: item for item in result['impact']['decisions']}
    assert decisions[authored_layer['id']]['action'] == 'preserve'
    assert decisions[derived_layer['id']]['action'] == 'regenerate'
    assert any('affected generation' in reason['reason'] for reason in decisions[derived_layer['id']]['reasons'])
    assert {job['layer']['id'] for job in result['reinference']} == {engine_layer['id'], derived_layer['id']}
    assert [item['layer'] for item in active_attachments(app, result['model'])] == [authored_layer]
    assert active_attachments(app, source) == before


def test_effective_branch_mapping_requires_existing_destination_and_unknown_dependencies_remain_diagnostic(app):
    from metaform.transform import effective_mapping, patch_snapshot
    original = branch_foundation(app)
    source = publish_foundation(app, original)
    owner = original['artifact']['owner']
    root = {'owner': owner, 'kind': 'type', 'id': 'code.cpp'}
    child = root | {'id': 'code.cpp.standard'}
    moved_root = root | {'id': 'code.cxx'}
    moved_child = child | {'id': 'code.cxx.standard'}
    layer = generate_advice(app, source, child, 'Explain this standard.')
    mapping = [{'from': root, 'to': moved_root, 'meaning_preserved': True, 'reason': 'Move the branch.'}]
    after = patch_snapshot(original, [{'op': 'relocate', 'target': root, 'replacement': moved_root, 'reason': 'Move the branch.'},
                                     {'op': 'remove', 'target': moved_child, 'reason': 'Remove this narrower Type.'}])
    assert not any(move['from'] == child for move in effective_mapping(original, after, mapping))
    after['model']['model'] = 'removed-standard'
    destination = publish_foundation(app, after)
    assert impact(app, source, destination, mapping)['decisions'][0]['action'] == 'invalidate'
    record = app.graph.get('layer-state:' + layer['id'])
    state = record['entity_json_obj']
    attachment = state['generations'][state['latest']]['attachments'][0]
    attachment['dependencies'] = []
    app.graph.put({'elements': {'layer-state:' + layer['id']: record}, 'joins': []}, source='authored', layer='knowledge-layers')
    unchanged = original | {'model': {'project': app.project_id, 'model': 'unchanged'}}
    unchanged_ref = publish_foundation(app, unchanged)
    decision = impact(app, source, unchanged_ref, [])['decisions'][0]
    assert decision['action'] == 'reconsider'
    assert 'no recorded input dependencies' in decision['reasons'][0]['reason']
    attachment['dependencies'] = [{'kind': 'selector', 'selector': {'kind': 'custom-semantic-region'}, 'fingerprint': 'recorded-selection'}]
    app.graph.put({'elements': {'layer-state:' + layer['id']: record}, 'joins': []}, source='authored', layer='knowledge-layers')
    decision = impact(app, source, unchanged_ref, [])['decisions'][0]
    assert decision['action'] == 'reconsider'
    assert 'no deterministic comparison adapter' in decision['reasons'][0]['reason']


@pytest.mark.parametrize('remove_actual', [False, True])
def test_recorded_member_selector_schedules_new_subject_after_last_member_removed(app, remove_actual):
    from metaform.layers import create_layer

    original = branch_foundation(app)
    # Keep the artifact identity while replacing its only member of this Type branch.
    original['artifact'] = original['elements']['demo:installer']['artifact'] = original['artifact'] | {'id': 'demo:installer'}
    original['elements']['demo:engine']['artifact'] = original['artifact']
    original['joins'] = []
    source = publish_foundation(app, original)
    owner = original['artifact']['owner']
    old = {'owner': owner, 'kind': 'element', 'id': 'demo:engine'}
    new = old | {'id': 'demo:new-engine'}
    selector = {'kind': 'type.members', 'target': {'owner': owner, 'kind': 'type', 'id': 'code.cpp'},
                'parameters': {'descendants': True}}
    request = 'Explain {{ literal }} implications for every current member.\nRetain this request.'
    job = create_layer(app, request, model=source)
    schema = {'$id': 'urn:test:population-advice', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string'}
    Engine(app).submit(job['run_id'], job['request_id'], {'name': 'Member implications', 'description': request,
        'schema_ref': schema['$id'], 'schema': schema, 'selector': selector,
        'groups': [{'subjects': [old], 'purpose': request}]})
    job = Engine(app).next(job['run_id'])
    Engine(app).submit(job['run_id'], job['request_id'], {'attachments': [{'subject': old, 'slot': 'advice',
        'schema_ref': schema['$id'], 'payload': 'Advice for the old member.',
        'applicability': {'scope': {'kind': 'direct', 'target': old}, 'reason': request}}]})
    layer = Engine(app).next(job['run_id'])['layer']
    before = active_attachments(app, source)
    patch = {'id': 'replace-population', 'source': source, 'destination_model': 'new-population',
        'purpose': 'Replace the last old member with a newly matching actual.', 'mapping': [], 'operations': [
            {'op': 'remove', 'target': {'owner': owner, 'kind': 'binding', 'id': 'binding:demo:engine'}, 'reason': 'Remove its binding.'},
            {'op': 'add', 'target': new, 'record': original['elements'][old['id']] | {'id': new['id']}, 'reason': 'A new actual.'},
            {'op': 'add', 'target': {'owner': owner, 'kind': 'binding', 'id': 'binding:new-engine'},
             'record': original['bindings'][0] | {'id': 'binding:new-engine', 'element': new}, 'reason': 'A new matching binding.'}]}
    if remove_actual:
        patch['operations'].insert(0, {'op': 'remove', 'target': old, 'reason': 'The old member is absent.'})
    result = apply_transformation(app, patch)
    delta = next(item for item in result['impact']['selector_changes'] if item['layer'] == layer)
    assert delta['selector'] == selector
    assert delta['added'] == [new] and delta['removed'] == [old]
    assert inspect_layer(app, layer, result['model'])['association']['resolved_targets'] == [new]
    assert result['impact']['decisions'][0]['action'] == 'invalidate'
    assert active_attachments(app, result['model']) == []
    assert len(result['reinference']) == 1
    job = result['reinference'][0]
    assert job['inputs']['subjects'] == [new]
    assert job['inputs']['request'] == request
    assert job['inputs']['payload_schema'] == schema
    assert job['inputs']['context']['impact']['selector_changes'] == [delta]
    assert any(record['ref'] == new for record in job['inputs']['context']['records'])
    assert any(dep.get('selector') == selector for dep in job['dependencies'])
    assert apply_transformation(app, patch)['reinference'][0]['request_id'] == job['request_id']
    Engine(app).submit(job['run_id'], job['request_id'], {'attachments': [{'subject': new, 'slot': 'advice',
        'schema_ref': schema['$id'], 'payload': 'Destination advice inferred for the new member.',
        'applicability': {'scope': {'kind': 'direct', 'target': new}, 'reason': request}}]})
    Engine(app).next(job['run_id'])
    assert [item['subject'] for item in active_attachments(app, result['model'])] == [new]
    assert active_attachments(app, source) == before
    assert capture_model(app, source)['elements'][old['id']] == original['elements'][old['id']]



def test_empty_custom_selector_remains_diagnostic_without_inferred_subjects(app):
    from metaform.layers import create_layer

    original = foundation(app)
    source = publish_foundation(app, original)
    selector = {'kind': 'custom-semantic-region', 'parameters': {'meaning': 'Exact authored selection'}}
    job = create_layer(app, 'Preserve this custom selection.', model=source)
    schema = {'$id': 'urn:test:custom-advice', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string'}
    Engine(app).submit(job['run_id'], job['request_id'], {'name': 'Custom', 'description': 'Custom selection',
        'schema_ref': schema['$id'], 'schema': schema, 'selector': selector, 'groups': []})
    layer = Engine(app).next(job['run_id'])['layer']
    result = apply_transformation(app, {'id': 'clone-empty-custom', 'source': source, 'destination_model': 'custom-copy',
        'purpose': 'Carry the explicit custom selection.', 'operations': [], 'mapping': []})
    assert result['reinference'] == []
    assert result['impact']['selector_changes'] == []
    assert result['impact']['selector_diagnostics'] == [{'layer': layer, 'selector': selector,
        'destination_selector': selector,
        'reason': 'This selector has no deterministic subject-selection adapter; population changes were not inferred.'}]
    assert inspect_layer(app, layer, result['model'])['recipe']['selector'] == selector
