# Executable workflow format

This document describes the current execution API. [SPEC](SPEC.md) defines
intended operation and specialization behavior; [current work](current-work.md)
tracks outstanding alignment and semantic demonstrations.

`metaform workflow reference` provides the module-owned grammar inside the
installed wheel or executable. The converter receives that same packaged grammar.
`workflow list` includes bundled and imported procedures, caller inputs, source
revisions, execution requirements and unresolved source inputs; `workflow inspect`
returns the complete definition and its exact source instruction.

`metaform workflow progress --run-id RUN_ID` returns the selected run and its
descendants: workflow and step identities, states, transitions, pending request
IDs, and references to completed answers. Its default response omits full
assignments, inputs, and raw answers. Follow a returned reference with
`workflow progress --run-id RUN_ID --result-request-id REQUEST_ID` to retrieve
that exact answer. An assignment-bound caller sees its own subtree. Controllers
can use this view to mirror progress into project files at their authored
checkpoints, using the host's filesystem tools.

A workflow has an `id`, optional `intent` and `start`, and ordered `steps`.
Import creates an Element Table record for the procedure and each step, plus
membership and transition joins. The engine reconstructs its definition from
those records. Editing a transition join changes subsequent runs. Each frame
snapshots its steps and referenced rule expressions when it starts.

```json
{
  "id": "example.review",
  "steps": [
    {
      "id": "review",
      "prompt": "Review {{ inputs.element }} against its Operative Purposes.",
      "focal": "{{ inputs.element }}",
      "depth": 2,
      "schema": {
        "type": "object",
        "properties": {"revise": {"type": "boolean"}, "work": {"type": "string"}}
      },
      "transitions": [
        {"when": {"var": "steps.review.revise"}, "to": "revise"},
        {"to": "record"}
      ]
    },
    {"id": "revise", "prompt": "Perform: {{ steps.review.work }}", "next": "review"},
    {"id": "record", "prompt": "Record the completed work.", "next": null}
  ]
}
```

The sample specifies no extra quality rubric or frozen properties. Its condition
is an authored control-flow decision. There is no hidden round, recursion, or
graph-layer limit. `drive --steps` in the structured interface, or raw
`drive HARNESS STEPS`, gives an explicit execution budget. Hosts can also impose
their own protocol limits; the pending assignment remains durable if they stop.

| Step kind | Additional fields | Execution |
| --- | --- | --- |
| `prompt` (default) | `prompt`, optional `schema`, `focal`, `inputs`, `save_as` | Yield an assignment and wait for its answer |
| `user` | `prompt` or `prompt_ref`, optional `schema` | Yield `awaiting_user`; retain the question until the actual user's answer arrives through `workflow.answer` |
| `branch` | `transitions` | Evaluate conditions and advance one structural step |
| `foreach` | `items`, `prompt`/`prompt_ref` or `workflow` and `inputs` | Snapshot items and retain ordered answers; `workflow` runs a complete child procedure for each item |
| `call` | `workflow`, `inputs` | Push a child workflow frame and return its result |
| `parallel` | `branches` (workflow IDs, workflow/input objects, or inline definitions) | Start independent child runs; retain ordered results after every branch completes |
| `tool` | `tool`, `arguments` | Invoke the named chassis command and record its result |

`next: null` finishes a frame. Without transitions or `next`, execution continues
to the next ordered step. Transitions are evaluated in order; their `to` can be
null. A transition can reference `rule: "data.some_rule"`, whose record contains
`{"expression": ...}`. A top-level recursive run, created by `workflow.recurse`,
records its parent and carries the parent's saved values plus explicit inputs.
A running parent's root frame supplies its current values; explicit inputs override
those values. Missing Jinja input values produce a named input error instead of
being sent to a worker as unresolved placeholder text. Authored Jinja defaults
remain available for optional values.

Assignment steps accept `role`, `context` (`project` or `fresh`), `tools`
(module command names), `inputs` (expressions), `schema`, `save_as`, `rule_codes`,
and `output` (graph record identity, description, schema, subject and layer).
`prompt_ref` selects a reusable prompt. A `user` step uses the same persisted
request and answer mechanism; `drive` returns its question without asking a
model or command harness to answer on the user's behalf. The source procedure
determines whether and where user interaction occurs.
An authored role can use Jinja input values. A definition's optional `workflows`
array bundles child definitions with the parent import. A `foreach` child gets
its declared input expressions evaluated with `item` and `index`; its complete
`{values, steps}` result joins the ordered iteration result before the next item.

Use `workflow list` to discover installed procedures and `workflow inspect --id
WORKFLOW` to read their definitions. `workflow answer` requires `--run-id RUN`
unless the caller is bound by `begin NONCE`; `--request-id REQUEST` selects an
exact issued request for replay. The default `workflow drive` harness is MCP
sampling. A plain CLI call explains the missing sampling context and leaves the
assignment pending; use a configured `--harness` or the supplied nonce handoff.

The expression environment includes `inputs`, `steps`, saved values, and during
foreach, `item` and `index`. `{ "var": "steps.review.revise" }` reads a value;
`{ "literal": value }` passes data without interpreting it as an expression.
Other supported operators: `and`, `or`, `if`, `==`, `===`, `!=`, `<`, `<=`, `>`,
`>=`, `+`, `-`, `*`, `/`, `%`, `!`, `in`, `cat`, and `count`. This is a small
Python-semantics expression language inspired by JsonLogic, not a compatible
implementation of all JsonLogic operators/coercions. Unknown condition operators
raise an execution error. There is no Python `eval` or implicit code execution.

`map` and `all` take `[array_expression, item_expression]`. The item expression
keeps the current input and step scope and adds `item` and zero-based `index`.
`map` returns ordered results; `all` is true when every item satisfies its
predicate, including an empty array. These operations express authored conditions
such as every planned task identity appearing among completed tasks.

Jinja expressions bind declared values in prompt text. A `file:relative/path`
prompt resolves relative to the imported workflow file. Plain-text imports retain
their source text. An inline prompt without a `prompt_ref` creates a prompt record
for that workflow step. An existing `prompt_ref` selects the referenced prompt
text at execution, including when inline text is also present. Imported prose is
not automatically parsed into a guessed branch structure.

Applying a specialization preserves revised inline wording when a step retains
its source `prompt_ref`: the revised text receives a specialization-local prompt
record. Embedded declarations that reuse source prompt IDs also receive local
IDs, with specialized step references updated together. Source prompts retain
their wording, and authored control flow remains in the specialized definition.

Prompt records and steps can attach semantic rules through `rule_codes`. The
selected rules use `metaform:semantic-rule`, with `rule_code`, `purpose`,
`concise`, and `priming`; they are distinct from the executable `metaform:rule`
conditions above. Prepared assignments carry the exact selected rule content
and revisions, with full priming for each assignment. A running workflow frame
retains its rule snapshots. Explicit concise-only rule preparation is available
for a context that has already received the priming.

The initial rule content and the status of its explanations and examples are
documented in [rule seed sources](rulebook/seed-sources.md). Editing stored
wording does not establish a new semantic agreement.

Optional `output` stores an answer as graph data:

```json
{
  "id": "data.learning.{{ item.id }}",
  "schema": "metaform:learning",
  "layer": "my_learning_layer",
  "subject": "{{ item.id }}"
}
```

An optional `tools` array controls the tools offered to the step's sampled or
subprocess agent. Default workflow tools browse the graph and read the working
copy. Operational information, selected graph data, schema, and prompt remain
separate fields in an assignment. `context: "fresh"` requests a separate empty
workfolder for an external harness; outside-report roles use fresh context.
Actor gateways and sampled tool calls bind the exact issued request ID as well
as the run. Tool calls and `continuation.current` retain that assignment even
when sibling assignments are active; caller-supplied IDs cannot select a
sibling's context. A completed binding remains bound to that completed request.
Completion retires ambient `.agentid/nonce` markers and active nonce lookups.
Explicit in-memory or gateway bindings retain the original receipt identity;
an old answer never selects a newer assignment. Retained markers with missing,
malformed or no-longer-pending records do not bind a fresh process. Completed
dispatch request files move from the runtime home to project
`.metaform/outputs/requests/<request_id>/` after their executor exits.
The coordinator retrieves subsequent work outside the binding with the run ID
and begins the newly issued nonce in its agent folder. Sampling requests
`includeContext: none`; this describes the
request to the host, not a guarantee about an external model's prior context.

## Foundation and knowledge jobs

New intake uses contract version 2 and produces one foundation. Incremental
`intake.put` contributions retain the whole-artifact account, records and expansion
opportunities. An empty final contribution completes publication. An expansion
opportunity records a question; it does not schedule an exhaustive pass.

`analysis.blindspots` requests an outside report using the complete Native account.
`layer.create` first designs a schema and subject grouping for the supplied request,
then generates attachments. `layer.regenerate` repeats that layer's original
request against the selected model and optional region. `layer.remove` removes
its active association while retaining its history and the foundation.

`knowledge.start` creates a named layer from the user's unchanged instruction.
Base functional knowledge and whole property-qualified composites receive
separate questions. Composites retain the providing Type and EF, Element,
Receiving Entity, Operative Purpose, role, signal and participants with the
recorded properties of their components. Backward property summaries retain
their origins and visibility status separately from forward applicability.
The worker returns one answer array per question; the runtime attaches each
answer to its recorded base or composite using the stored mapping.
`knowledge.preview` shows the actual sentences without inference.

```sh
metaform layer create --request "Explain maintenance choices for this artifact."
metaform layer list
metaform layer inspect --target layer:YOUR_LAYER_ID
metaform layer regenerate --layer layer:YOUR_LAYER_ID --region demo:engine
metaform layer remove --layer layer:YOUR_LAYER_ID
```

Use IDs returned by the preceding operations. Commands that create jobs return
normal Engine assignments. `metaform answer @answer.json` records an answer;
`metaform next` resumes the saved run. Explicit `workflow.answer --run-id ...
--request-id ... --answer @answer.json` and `workflow.next --run-id ...` preserve
selection when coordinating several jobs. Replayed request IDs return their
original receipts.

An expansion selects a model, target and purpose. Model arguments below are
illustrative JSON; use the project, model and revision from `model.discover`.

```sh
metaform model expand --model '{"project":"PROJECT_ID","model":"MODEL_ID","revision":"REVISION_ID"}' --target demo:engine --purpose "Explain how observations reach the engine."
metaform expansion list --target demo:engine
metaform model clone --source '{"project":"PROJECT_ID","model":"MODEL_ID","revision":"REVISION_ID"}' --destination-model alternate
metaform model transform --patch @patch.json
```

Expansion and transformation use `urn:metaform:schema:transformation:2`.
Operations add, update, remove, relocate or replace owner-qualified records,
with reasons and mappings. Meaning-preserving relocation updates structured
references and aliases; meaning replacement preserves the source Type. An
explicit narrowing update supplies the semantic reason when a branch moves to
a different parent. Source prompt strings and historical answers remain unchanged.

`model.ground` prepares a bounded deterministic context. Workflow conversion and
specialization accept `--model` and `--target`; they retain the source instruction
and use that selected context. Their generated output remains available for
review and the existing apply operation. A variant expresses a destination
semantic account, with affected knowledge regenerated through its original
requests; it does not claim that implementation files have already been ported.

Each role assignment retains its source prompt, exact literal inputs, component
and schema snapshots, dependencies and answer annotations. Unusable patches and
conflicting edits retain the submitted answer and the existing foundation.
Already-issued v1 intake assignments continue their recorded Native/Latent
contract rather than interpreting an old graph answer as a new report.

### Historical direct inference operations

The knowledge service separately retains direct global inference operations.
`inference.read` returns `id`, `inference_complete`, `status`, and `graph` for a
selected global structure. Incomplete inference returns no graph; a completion
marker without a snapshot reports `unresolved_structure`. Retrieval preserves
exact reference owners and kinds. Non-global and missing references remain
reported while captured joins retain their contents. Global Element lookup uses
current records, then the completion snapshot, then captured archive dependencies.

In service mode, `inference.commit` atomically checks completion, writes eligible
global knowledge and its completion observation, retains the project's Latent
copy, and records a project-scoped request receipt. The first completed graph
is retained and late commits reuse it. Contributions and promotion also preserve
their existing checks inside service transactions. Stable request IDs recover a
committed result after a lost response.

Intake durably records its local transition and cleanup target before removing an
assignment's workfolder. A repeated answer can finish retained cleanup after a
local save failure. Portable JSON retains its separate-file crash boundary.

Run transitions are serialized across processes. Replayed answer IDs return the
same receipt; repeated `next` calls return the same pending assignment. Assignment
execution is locked and completed execution results are cached before submission.
A process crash between an external side effect and its durable result can still
require reconciliation; arbitrary external tools are not promised exactly-once
execution. Debug events and workfolder diffs provide the evidence for recovery.

An authored phase can provide `execution_policy` with `timeout_seconds`,
`agent_failure: "retry_once_then_fail"` and `phase_failure: "stop_execution"`.
The deadline covers the whole nested phase, including parallel children or a
sequence in a child call. An executor failure is distinct from an ordinary answer
containing validation findings. Policies are absent by default; the Python-to-C
library procedure supplies its source's 3,600-second phase deadlines and one
7,200-second deadline for the three sequential synthesis assignments.

The distributed library contains all seven original sources and their reviewed
definitions: `metaprompt`, `dual_agent`, `multi_agent_orchestrator`, `orchestrator`,
`extractor`, `python_to_c` and `taskeengineplus`, under IDs
`metaform.library.<name>`. Host execution requirements remain visible: graph and
file-reading actor commands do not themselves execute code or materialize files.
The Codex command harness provides its own process and filesystem tools; separate
fresh assignments receive separate working folders. Exact source text, conversion
outputs and subsequent corrections have distinct provenance.

Project selection belongs to the client context, not the workflow definition.
A CLI `--project` selector, an MCP session selection, and a workbench tab each
identify their App; issued assignments and in-flight requests keep their captured
project. Workflow definitions and step/rule references can resolve through project
and global knowledge. Imported workflow and step attachments become ordinary
`workflow_attachment` joins, so they also participate in selected export.
New model-aware preparation uses the common selected-region grounding envelope.
Legacy preparation still exposes owner-labelled source graphs and historical
structural similarity under its original depth/source contract.

An executable version 2 archive carries selected workflow definitions, prompts,
schemas, rule revisions, nested workflow dependencies, assignments, and required
assets with JSON knowledge and restored local SQLite state. It preserves the
logical project owner with a separate portable copy identity, and continues
through the same answer/next/export operations without service access.
Returning that archive uses portable history import; it does not reconcile
changes into a registered service owner.
