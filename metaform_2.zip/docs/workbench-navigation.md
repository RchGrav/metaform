# Using the workbench

`metaform web` starts the web interface on its fixed port and prints its address. The root lands on the project opened most recently; `/projects` lists every project the service knows, marks the ones whose folder is gone, and Forget drops an entry from the list and the registry without touching its folder. The page shows
the project the way an agent sees it through the Metaform MCP server. Every
panel is filled by one read, and every panel can show the exact envelope that
read returns. The same text is available inside the page under Help.

## What is on the screen

The header holds the project name, the Model chooser, the Layer chooser, the
stage banner, and the links. The stage banner is the answer to `guide.start`
for the chosen model: where the agent is and the next command it would be told
to run.

The left panel is the namespace. Its top rows are the bases the project uses:
code, document, media, data, and exterior. Open a base with the triangle to see
the Types narrowed under it. Click a Type to see the Elements bound to it as
cards.

The middle is the neighborhood: the Element in focus with the Elements it
receives from on its left and the Elements it provides to on its right.

The right panel is the inspector. It reads whatever you clicked.

## Reading a card

A card is an Element. Its name is the name from the namespace, read backward
from its Type's address, so `code.synthesizer.audio` reads Audio Synthesizer.
The smaller line under the name is the name the intake gave the Element. The
band on the left edge is the base: blue for code, amber for documents, purple
for media, teal for data. A dashed grey card is exterior to the project. The
card marked ARTIFACT is the artifact itself.

Click a card to read it. Nothing moves when you click. Double-click a card to
center the neighborhood on it. The card you double-clicked stays where it was
and the other cards arrange around it.

## Reading an arrow

An arrow runs from the Element that provides to the Element that receives. A
solid arrow is a hard dependency, a thin arrow is supportive, and a dashed
arrow is a property provided by another Element. Arrows carry no text. Click
one and the inspector shows the join: its Receiving Entity, its provider and
provider Type, its Operative Purpose, and its Signal.

When a property comes from a Type rather than from an Element there is no
arrow. The color goes where the property applies: a colored band along the
bottom of the receiving card. The inspector lists the property under
"Receives through its Operative Purposes" with the same color. The Knowledge
section under it shows what that property brings in the selected layer, with
the reason it applies.

## Moving around

Drag the background to pan. The mouse wheel zooms at the pointer. Fit brings
every card into view. Panel changes and window resizes never re-arrange the
cards.

## Seeing what the agent sees

Each panel has a `{ }` button. It replaces the panel with the call that filled
it and the envelope that came back, exactly as the agent receives it. Escape
puts the panel back. The Knowledge section has its own `{ }` for
`knowledge.get`.

Console opens the developer view at the bottom:

- Run a tool sends any tool the agent is offered, with the arguments you type,
  and shows the envelope back. The arguments start with the current model and
  the selected record.
- Initialization shows the instructions the agent receives when it connects
  and the tools it is offered, with their descriptions.
- Calls lists every request this page has made, with server time and payload
  size. The same list is served at `/api/trace`.

## Jobs

The Jobs tab on the left lists every run recorded for the project, newest
first. Start intake runs a Native intake with the harness you choose. Codex is
offered when it is installed; any other harness comes from `harnesses.<name>`
in settings, with a command that receives `{request_file}` and
`{response_file}`. The run appears at once and is driven in the background;
the page polls it while it runs.

Click a run to see it as steps in the left panel:

- prompt sent: the assignment, with the authored prompt in an editable box,
  the components appended to it, the inputs the agent received, and the answer
  schema;
- read: each context read the agent made, with the envelope it received;
- evidence: each artifact file the agent read;
- answer: each submission, with its contribution counts and annotations;
- the recorded events of the run;
- result: the published model, its diagnostics, and a comparison with another
  intake run.

For an intake the graph replays the contributions as they arrived. Drag the
scrubber under the run title to watch the graph grow one submission at a time.
While the agent is still working the replay fills in live.

Clear project in the header clears the project's Metaform data after you
confirm: every model, run and layer of this project goes, the folder and its
files stay, and the page returns to needs intake so New intake starts from
nothing. `metaform project clear` does the same from the CLI.

Save prompt keeps the edited text as the prompt's next revision; the next
intake composes its assignment from it. Run again saves and starts another
intake with the chosen harness. When an intake completes, the Model chooser
offers the published foundation without a reload.

## Palette

The Palette chooser in the header switches between Graphite, a dark ground
with an amber accent, and Paper, a warm light ground with an oxblood accent.
The choice is kept in the browser.

## The earlier page
