# The shape of what is built

Written 2026-09-14 from the code at commit `024a658`, for the person who
asked for the tool. Plain words, one page. Where the code does not match the
design, this page says so.

## Three doors, one set of objects

- `metaform` in a terminal is the command line. Its entry point is
  `metaform.cli:main`.
- `metaform mcp` serves the same commands as MCP tools over stdio to an AI
  harness.
- `metaform web` starts the page on port 8642 and offers the same commands
  there.

All three are built at startup from one read of the module files. No command
tree is typed into the code. Add a module and all three doors show it.

## A module

A module is two files: a JSON file that describes its commands, and a Python
file that holds the functions. The code and the docs call the JSON file a
manifest. Each command line in it has a name, a description, the arguments it
takes, and the Python function it leads to. There are 28 built in, under
`src/metaform/data/modules/` and `src/metaform/modules/`.

A community module is the same two files in a folder, dropped under
`~/.metaform/modules/`, under `<project>/modules/`, or under a path named in
the home config. It loads through the same loop as the built-in ones.

One runtime difference: a built-in function receives the whole application; a
community function receives a `ModuleAPI` wrapper that can call other commands
and keep its own settings but never touches storage directly. The code says
this is deliberate: storage stays with the chassis.

## A workflow

A workflow is a definition the engine runs: a start step and a list of steps,
each with a kind, a role and a prompt. Seven ship in the library under
`src/metaform/data/workflows/definitions/`, with their markdown sources beside
them. The workflow module's commands list, import, begin and run them. Many can
be made. The format today is JSON; plan unit 5 changes it to XML.

A module and a workflow are different objects today. The plan's unit 6 turns
intake, expand and blindspots from Python state machines into definitions the
engine runs.

## The chassis

The chassis reads the modules, builds the three doors, owns the nonce and the
bindings of working folders, the status header and the menus, provisioning,
the project registry, the knowledge service and history. Modules supply their
commands into it.

What the chassis hard-codes today, against specification section 14:

- The launcher words begin, done, abort, skill, mcp and install. They are a
  dictionary in `src/metaform/registry.py` and string matches in
  `src/metaform/cli.py`, not modules.
- The menu text: the lines the starting page prints are typed into
  `src/metaform/cli.py`, not read from the loaded modules.
- Module names inside chassis code: `guide.start` in seven places in
  `src/metaform/cli.py`, two intake commands in `src/metaform/viewer.py`
  (the Jobs tab), four intake and workflow commands in
  `src/metaform/actor.py`, two in `src/metaform/onboarding.py`.

Everything else the chassis offers is derived from the module files.

## Where things live

Home, `~/.metaform/`:

- `config.json`, the home settings, including `web_port`.
- `modules/`, community modules.
- `service/knowledge.sqlite3`, the base db: the registered projects, the
  bindings of working folders, and the knowledge store.
- `service/endpoint.json`, present while the service runs.
- `assignments/`, `workfolders/`, `runtime/`.

Project, `<folder>/.metaform/`:

- `state.sqlite3`, the runs, answers and events.
- `config.json`, project settings.
- `history/`, `outputs/`.
- Older backend files such as `metaform.json` and `metaform.lbdb` may remain
  from earlier storage modes.

Package, `src/metaform/data/`:

- `modules/`, the 28 module files.
- `workflows/`, the seven library workflows and their sources.
- `roles/runtime/`, the prompts: `intake.md`, `expand.md`, `blindspots.md`
  and the others.
- `bases.json`, the four bases every intake reuses.
- `schemas.json`, the contracts answers are checked against.

## Not built, or built wrong, at this commit

- Menus and launcher as objects read from the modules: typed in instead.
- Checkout, plan unit 4: a diff from 2026-09-13 sits in a git stash,
  unreviewed and off the plan's order.
- The words kept in section 14, `modules`, `run`, `admin`, `status` and
  `deploy`: not present.
- Plan units 5 to 11: the XML workflow format, operations as definitions, the
  memory node surface, the rest of the nonce mechanics, provenance, chassis
  onboarding, and the knowledge service process design.
