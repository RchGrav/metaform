# Verification

**Storage retirement — 2026-09-11:** Ladybug and its Cypher analysis copies are
retired. Current storage checks cover SQLite, JSON and the shared SQLite service.
Older results below retain their original backend scope as historical evidence;
they do not advertise a supported Ladybug feature.

The [specification's acceptance scenarios](SPEC.md#acceptance-scenarios) define
the semantic demonstrations. Passing implementation tests establish semantic
correctness only where their expectations follow that contract. Tests of
supporting infrastructure and tests encoding superseded assumptions serve
different purposes; the latter need correction alongside the implementation.
The current correction work is tracked in [Current work](current-work.md).

## Release-quality verification — 2026-09-11

The [final source integration report](reviews/2026-09-11-final-integration-verification.md)
records **884 passing Python tests**, **all four browser suites**, and 163
unchanged source/data/build hashes across those runs. The later deletion of
unconditional optional-module guidance has its own focused source/browser
verification. [Distribution evidence](release-distribution-evidence.md) records
exact artifact hashes, fresh Python 3.11/3.13 installations, public entry points,
interrupts, portable workfolder transfer, configuration/reference and execution
policies. [The per-entry audit](reviews/2026-09-11-release-evidence-audit.md)
retains all 84 established work items and the limits of their evidence.

Seven actual workflow conversions, actual Native/outside inference and a bounded
documentation-role execution have retained outputs and independent semantic
review. These are distinct from fixture execution and from unexecuted corpus
branches. The [release repair status](release-quality-status.md) records original
checkout integration and remaining product decisions. The [original checkout
delivery](reviews/2026-09-11-checkout-integration.md) additionally verifies its
relocated artifact with 44 public calls and five standalone interruption/EOF/
large-output/handler cases on the available Python 3.10.12.

### Earlier focused repair checks

The following results predate final integration and retain their original scope.

- Viewer slice: `tests/test_review_viewer.py`, `test_viewer_projects.py`, and
  `test_viewer_scope.py`: **25 passed** on Python 3.13.5. The new report check
  failed before the repair because seeded infrastructure made one actual
  Element appear as 21 Elements; it now distinguishes actuals and Types and
  exposes/clears the saved pending assignment.
- All four browser suites passed with the pinned Playwright build. History now
  checks the direct expand-controls → click-Element sequence that reproduced
  the offset. Foundation now checks Create layer → navigate to Activity →
  reload → retained pending handoff → abort → cleared banner. The existing
  SVG and text/desktop/mobile checks also passed.
- `run_demo.py` completed from fresh temporary application/result directories
  with its existing lifecycle, property, variant, reinference and transport
  parity assertions. `capture_demo.cjs` used that new summary and captured the
  actual Foundation workbench and HTTP requests with no page errors. This is
  an illustrative authored fixture, not a live real-project intake.
- The MGM loader imported the preserved v1 sample into a new portable project.
  No model execution or original source/screenshot modification was involved.
- Comparison source generation left the tracked source's SHA-256 unchanged and
  wrote into the selected output directory. All three baseline resources were
  read successfully from the pinned `b7aea90142067185153c974b826b6e609d9f1464`.
  Live comparison inference was not rerun for this script repair.

Browser evidence directories are printed by each check and live under the
operating system's temporary directory. Install declared dependencies with
`npm ci` and `npx playwright install chromium`, then run `npm run test:browser`.
For a worktree, set `PYTHON` to its interpreter and `PYTHONPATH` to its `src`.
The lockfile pins the Playwright build used in these runs. No current whole-suite
count is inferred from older dated records below.

## Realignment integration — 2026-09-10

The September 10 realignment added versioned foundation publication and migration, shared
semantic reads, focused one-foundation intake, generic layers, applicability,
local expansion, variants/reinference and grounded specialization. The tests use
recorded fixtures unless a section explicitly identifies a live provider run.

Observed integration evidence:

- Full Python regression passed 663 tests on Python 3.13 (161.95 seconds) and
  Python 3.11 (167.77 seconds), including selector population changes, branch
  relocation and workflow deep-read provenance. Logs:
  `.test-tmp/realignment-python-integrated.log` and
  `.test-tmp/realignment-python311-integrated.log`.
- The final custom-prompt difference-report change passed 72 tests across role
  composition, foundation intake, grounded specialization, review intake,
  rulebook, execution and knowledge layers. Reports retain complete text,
  schema and component differences while preserving authored/issued content
  and excluding those reports from inference payloads.
- The 22 JavaScript model/renderer tests and all four browser suites passed:
  semantic workbench, historical structure navigation, authored SVG rendering
  and text visibility. Exact logs, requests and screenshots are retained at
  `.test-tmp/semantic-browser/verification.md` and `.test-tmp/text-visibility/`.
- The unchanged historical MGM Native/Latent inputs migrated to 47 Types,
  58 current Native actuals, 59 bindings and 101 OP joins. Two provider Type facets
  and 43 narrowing meanings remained explicitly unresolved; one historical
  outside snapshot was retained. Both original source hashes were unchanged.

Subsequent review fixes include pinned-reference diagnostics, self-contained
schema anchors, expected-absent model creation and canonical narrowing-parent
mismatch annotations. The final wheel matched every packaged source file and
passed `tools/check_distribution.py` from separate Python 3.11 and 3.13 wheel
installations: installed CLI/MCP, direct-wheel CLI/MCP, offline GUI/export and
shared-service portable continuation under the v2 one-foundation contract.
Logs are retained at `.test-tmp/realignment-build-final.log`,
`.test-tmp/realignment-smoke311-integrated.log` and
`.test-tmp/realignment-smoke313-integrated.log`.
The [demonstration](../examples/realignment/README.md) records its fixture inputs
and execution scope. Its end-to-end lifecycle passed source/destination CLI,
MCP and GUI parity, property explanation, automatic affected-layer reinference
and source preservation. All 131 retained JSON artifacts parsed successfully.

Six fresh live intake arms completed across three matched source pairs. The
[artifact-specific review](../examples/realignment/evidence/live-comparison/review.md)
records exact inputs, output contracts, raw responses, reported usage, timings
and mixed semantic findings. The focused multi-Type output misplaced property
origins despite schema validity; its actual applicability probe is retained.
A separate [fresh grounded task](../examples/realignment/evidence/live-grounded-task/review.md)
correctly used actual Element/join and knowledge provenance references. MGM
input was a selected archived account, and the other fixtures were narratives;
these trials do not establish source-level porting correctness or general gains.

The first live trial reproduced a compact-Type-cache completion failure. The
unchanged retained run completed after the cache repair; original submissions,
read evidence and before/after replay records are preserved. Final review also
repaired overlapping branch relocation, workflow-tool read provenance, and
newly matching/removed layer members (including binding-only removal). Unknown
custom selector populations remain explicit diagnostics.
All twelve installed role/composition files match the supplied archive bytes.

Relevant focused commands:

```sh
.venv/bin/python -m pytest -q tests/test_foundation_models.py tests/test_foundation_migration.py tests/test_local_expansion.py tests/test_model_transformations.py
.venv/bin/python -m pytest -q tests/test_semantic_reads.py tests/test_namespace_targets.py tests/test_role_prompt_composition.py tests/test_knowledge_layers.py
```

## Historical verification records

The dated evidence below describes earlier implementations and environments.
Native/Latent two-pass checks and older source-comparison expectations retain
their historical meaning; they are not the default v2 intake contract.

Before the documentation consolidation, the focused command
`.venv/bin/python -m pytest tests/test_core.py tests/test_intake_pipeline.py tests/test_rulebook.py tests/test_execution.py -q`
passed 54 tests. The terminology correction subsequently passed all 9 tests in
`tests/test_rulebook.py`. The existing merged-join test requires copied source
purposes, so its passing result does not demonstrate the specified structural
similarity layer. Fixture answers also do not establish the semantic reasoning
outcomes in A-5 through A-8.

## Native to Latent intake — 2026-09-10

### Actual detail and navigable viewer delivery

Verification of that earlier delivery passed **546 Python tests**, **22
JavaScript model/renderer tests**, the full structure browser suite, and the SVG
browser suite. A wheel built successfully with
`.venv/bin/python -m build --wheel --no-isolation`.

The [completed MGM intake sample](../examples/intake/mgm-main/README.md)
preserves the real Native and Latent output for semantic analysis: Native has
58 actual elements, 47 Types, and 101 joins; Latent has 72 actual elements,
47 Types, and 204 joins. It includes the Native functional account supplied to
Latent and a screenshot from the installed viewer. The sample manifest records
the source and prompt revisions and content hashes. Native reused prior source
inspection and checked repository guides; the run was not an exhaustive new
source audit or runtime validation. Passing infrastructure tests does not certify
the quality of these generated descriptions or joins.

### Earlier engine verification

The runtime suite passed **486 tests** after the standalone Native → Latent
engine was established. Coverage includes complete Native graph and schema
handoff, incremental contributions, project-local results, service partition
isolation, saved snapshots, callable examination, provider ownership, and
references between reified joins. Driver, command-harness, and both MCP
protocol modes exercise the two-assignment flow.

Earlier wheel verification with `python -m build --wheel --no-isolation` completed Native and
Latent fixture passes from the wheel itself, then invoked `intake.examine`
through the command registry. The supplied context survived and the artifact
was not promoted into global storage. MCP role delivery uses `systemPrompt`;
installed Codex prompt rendering verified its supported `developer_instructions`
channel precedes task input. Saved prompt snapshots are retained while duplicate
source text is omitted from model input when already present in the intake prompt.

These checks establish runtime behavior and context delivery. No live model
intake was restarted, and they do not establish inference quality or absence of
contextual bias. Existing Name/length migration and other remaining work in
[Current work](current-work.md) are separate from this delivery.

## System review repairs — 2026-09-09

### Workbench project selection follow-up

The final source suite passed **516 tests on Python 3.13.5** (117.54 seconds).
New regressions exercise opening existing folders, tab and graph isolation,
later service registrations, target service homes, existing local storage,
bound assignments, missing folders, and portable copies with shared semantic
owners. Portable preview isolation and selection through multiple archives are
covered. The runtime Name-rule check now targets its preserved earlier source
wording while the agreed replacement remains documented for implementation.

The wheel and standalone archive were rebuilt from the final source. A fresh
wheel installation passed `tools/check_distribution.py`, covering installed and
direct-wheel CLI/MCP, offline GUI/export, and shared-service portable continuation.
Chromium exercised the always-visible selector, invalid paths, relative folder
opening, independent tabs, project switching, registration refresh, and narrow
screen controls without JavaScript errors. The local installation was updated
and its running workbench was checked in Chromium as well.

### Original repair batch

All 21 reproduced [review findings](reviews/2026-09-09-end-to-end-system-review.md)
were repaired and independently rechecked. The complete source suite, run with
each environment's `python -m pytest -q`, passed **501 tests on Python 3.11.6**
and **501 tests on Python 3.13.5** (124.77 and 124.63 seconds respectively).

The regression coverage includes parallel workfolder inheritance and abort
lifecycle, exact assignment binding and delayed MCP answers, repeated foreach
visits, directory replacement, archive symlink boundaries and exclusions,
schema ownership/migration, prepared schema handoffs, reused join identities,
dependency scheduling, qualified similarity, image attribution/readiness, and
viewer crash recovery with live legacy-instance reuse. Abort checks use real
fixture harness processes; viewer checks exercise HTTP endpoints.

Similarity retains exact maximum structural correspondence. The review's
eleven-join divergent fixture now completes in about 0.002 seconds with the same
ten matches, compared with the review's 26–30 seconds. This is a specific
regression result, not a general scaling guarantee. Raw graph, CLI, viewer, and
intake paths use fresh owner-aware knowledge rather than a detached snapshot.

`python tools/build_distribution.py` rebuilt the wheel and standalone archive.
Fresh wheel installations on Python 3.11 and 3.13 both passed
`python tools/check_distribution.py`: installed and direct-wheel CLI/MCP,
offline GUI/export, installed Ladybug/Cypher analysis, and shared-service portable
continuation with the service stopped and original home unavailable.

Provider responses and semantic answers in these regressions are fixtures. The
checks establish the repaired mechanics; no live model or image-provider trial
was performed for this repair batch. The semantic demonstrations identified in
[Current work](current-work.md#build-corrections-remaining) remain outstanding.

## Shared knowledge and portable projects — 2026-09-08

The full source suite passed **396 tests on Python 3.11.6** and **396 tests on
Python 3.13.5**, using each environment's `python -m pytest -q`. Focused
regressions cover owner-qualified references, independent source records,
transactional inference recovery, service startup/reuse and shutdown, project
selection, indexed export closure, captured dependencies and schema refresh.
The closure fixture includes 10,000 unrelated global records and a concurrent
writer. Review findings were repaired and independently rechecked.

`python tools/build_distribution.py` built the wheel and standalone archive.
Fresh installed-wheel environments on Python 3.11 and 3.13 both passed
`python tools/check_distribution.py`: installed and direct-wheel CLI/MCP,
intake completion and reuse, an empty-Python GUI/export round trip, verified
service reuse, and Cypher over a revision-labelled Ladybug copy. The shared
project export excluded unrelated global and other-project relationships, then
continued a nested workflow with `-S`, empty `PATH`/`PYTHONPATH`, the service
stopped and original home unavailable. Re-exporting and reopening retained the
pending request. A regression also proves that two archives with the same file
origin reuse their own working copies without resetting continuation.

A Chromium check opened two service-backed project tabs, changed one tab's
selected project without changing the other, and refreshed a Ladybug analysis
copy. Project/mode display and analysis status were correct, with no JavaScript
errors. This was a desktop check, not a complete accessibility or mobile audit.

Ordinary central graph mutations still reconstruct one owner partition; these
results do not establish large-corpus mutation performance. Live model reasoning
was not part of this feature verification.

## Earlier build checks

The earlier build was checked locally on Linux with Python 3.13.5 and official MCP SDK 2.1.1.
The full suite passed 138 tests with
`uv run --frozen pytest -q --basetemp=.test-tmp/final-verified`.
The rule editor, Metaform filters, and semantic field saves were also exercised
in Chromium, including keyboard operation and the mobile Rules view.

A live Codex intake of the repository's small example module exposed and led
to fixes for strict output-schema rejection, access to the assigned tool bridge,
and blocked answers being treated as completed intake. The native scan and Type proof completed. The first focal latent inference answer
exposed schema-valid optional participant/projection storage failures; after
repair it was replayed successfully. The original answer also contains model
formatting errors, retained for review in [the live trial notes](mvp-review.md).
A second independent focal assignment used the clarified schema, saved four
OP joins with referenced participants and no schema annotations, and displayed
its links in the Latent view. This does not establish semantic quality or
completion of the full latent pass.

## Earlier executed checks

The earlier automated suite exercised the following through real filesystem, SQLite,
subprocess, Git, HTTP, and MCP transports. Agent outputs are labeled fixtures;
they are not presented as model-generated expertise.

- Lazy drop-in module discovery, raw argument preservation, command hiding,
  always-available imagegen, removal, and abort.
- Native intake, individual fresh latent inference assignments, independent global
  joins, matching source-attributed joins, and no native join export.
- Concurrent answer replay, durable pending requests, rule snapshots, conditional
  loops, nested calls, foreach, related recursive runs, and tool steps.
- Graph-backed transition edits changing execution, exact prose imports,
  filesystem prompt binding, graph specialization with retained source, and
  schema annotations that retain the original answer.
- Cycles and n-ary participant traversal, aliases as lookup candidates,
  source-specific join IDs, additional schema forms and arbitrary layers,
  export/import retention, packaged custom schemas, and integrity cleanup.
- A real harness process using the scoped actor bridge to read project evidence;
  its separate Latent Expert process querying global records without local joins.
- Abort terminating an active harness; fresh workfolder cleanup and trace capture.
- Non-Git development copies, text and binary diffs, conflict checks, application
  back to the original ordinary directory, and cleanup.
- Global export and a real Git merge/push against a local bare remote, excluding
  native joins and unrelated source-code commits; later bundle updates loading
  once without resetting global contributions on each new project.
- Flask endpoints plus managed viewer startup/shutdown while the router remains
  responsive; imagegen dry-run integration without generating an image.
- Rules and prompt attachments edited through the GUI retain exact wording and
  existing fields. Graph perspectives retain reified participant closure;
  semantic editors preserve structured EF, OP, and join-logic values.
- Optional pairwise join projections and participant roles preserved through
  SQLite, JSON, Ladybug, intake ownership, completion, reuse, and viewer output.
- Exact semantic equation source and revision supplied to conversion and
  specialization without overwriting authored prompt text.
- Official SDK clients using both the 2025-11-25 and 2026-07-28 paths, sampling
  tool calls that read project evidence, blind global assignments, and debug mode.
- A separately installed wheel: installed CLI, installed stdio MCP, direct-wheel
  CLI, and direct-wheel stdio MCP outside the source checkout.

Reproduce with:

```sh
uv sync --frozen
uv run --frozen pytest -q
uv run --frozen python -m build --wheel --no-isolation
uv venv /tmp/metaform-wheel-check
uv pip install --python /tmp/metaform-wheel-check/bin/python dist/*.whl
/tmp/metaform-wheel-check/bin/python tools/check_distribution.py
```

The GitHub workflow runs the tests and wheel checks on Python 3.11 and 3.13 and
uploads the wheel, including for data-only updates. Its configuration is supplied;
local verification alone does not establish a GitHub Actions result.

## Not established by these checks

- The automated suite does not run live model or image generation. Provider capability probing,
  authored prompt construction, routing, and fixture execution are implemented.
  The bounded live handoff comparison is recorded in [current work](current-work.md);
  it does not establish general model reliability or the remaining semantic outcomes.
- The maintained Aliases section is now bundled and supplied verbatim, with
  configured source overrides retained. Its delivery is tested; model application
  of the equations still requires a live inference trial.
- No claim is made that a host obeys `includeContext: none`, that a subprocess is
  an OS sandbox, or that fixture agents prove independent latent reasoning.
- No empirical claim is made about saved inference, reduced omissions, automatic
  porting quality, or the semantic correctness of a generated metaform.
- Arbitrary external side effects cannot be guaranteed exactly once across a
  crash between the side effect and durable result recording.
- Distributed multi-host workers, production deployment of the viewer, and live
  package-index publication are not implemented or implied by the local chassis.
