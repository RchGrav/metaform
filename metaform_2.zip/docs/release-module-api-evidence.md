# Public module interface and chassis account — 2026-09-11

This records source implementation for R44–R47 in the release-quality worktree. The final artifact subsequently passed the [delivered verification matrix](release-distribution-evidence.md), including an independent 44-call module/customization/user-wait/share journey using only the archive's own public guidance. The semantic review remains separate from those runtime checks and is described below.

## Public module interface

External module command handlers, raw handlers, and guidance providers receive `ModuleAPI`. Built-in handlers retain their chassis implementation context. The public facade supplies asynchronous registered-operation calls, module-scoped persistent state, copied project/effective-setting descriptors, and chassis mode entry/exit. It does not expose database or graph handles or implement a new Python sandbox.

Semantic reads/writes and workflow import/start/answer/next run through the existing registry and operation owners. Host context is forwarded. Enabled module operations remain callable during module-owned orchestration; existing command disabling still applies. Assignment rendering, identity, folders, receipts, and cleanup stay with workflow/continuation services.

The example in `examples/module` now teaches this interface without changing its raw-mode behavior. Its README describes manifests, settings, guidance providers, portable assets, installation, operation calls, and sharing.

## Chassis functional account

`guide.chassis` returns a bundled Native foundation-shaped account in `data/chassis.json`, plus explicit procedures for building modules, importing/converting workflows, and using public operations. The account identifies exterior receivers, the composite Defining Element, actual subsystem Elements, their Type bindings and Receiving Entity–Operative Purpose–Encounter Function joins, property relationships, and source evidence. Current registry/reference and workflow inventory are attached on demand.

The account is separate from selected-project knowledge and viewer content. Reading it neither publishes a project model nor adds removable project records. Its stable functional descriptions are separate from live capability discovery.

An initial semantic review found inaccuracies despite structural validation: the accepted program-code Description/name had been rewritten, some child Descriptions omitted ancestral Names, Python naming used the wrong length, and unresolved document/exterior base meanings had been invented. Those were corrected. The exact accepted code Description and recorded root name are preserved; inferred child Descriptions include ancestral Names. Document/exterior universal Description/EF fields remain explicitly unresolved with diagnostics. The exterior project boundary is retained separately. Other Type meanings are labeled as source-derived interpretations for this local chassis account, not canonical global base seeds.

The independent semantic worker then identified missing Medium labels and missing receiving-purpose dependencies on exterior worker reasoning. Python property joins now retain `property_type: Medium`; separate execution/native-to-worker dependencies describe where external reasoning is received, alongside worker-to-handoff instruction delivery. The account's Python transport property describes the CLI/MCP adapters, not every medium shipped in the distribution.

## Verification performed

Five public-interface cases exercise:

- Creating/discovering a self-contained module, starting its fresh worker through public workflow operations, answering/completing it, exporting/importing the project, preserving module state, executing in the copy, and removing the copied installation without removing the original.
- Entering, using, and aborting the existing raw-mode example through the facade.
- Reading chassis knowledge without changing project graph contents, checking its explicit unresolved meaning, and observing newly installed capabilities without rewriting the account.
- Running an external guidance provider and following its next action through public semantic write/read operations.
- Sharing a flat module with separate raw/guidance handler files and exercising those callbacks in the imported copy.

These tests establish interface and data-delivery behavior. They do not establish that the functional account is semantically complete or that live workflow conversions preserve their source meaning. Those claims require their separate reviews and actual inference evidence.

Adversarial review also reproduced reference side effects: archive reference operations materialized their working project, and reading `guide.chassis` could trigger an automatic source build through nested workflow discovery. Module-owned `reference_only` and `read_only` declarations now coordinate reference routing and build suppression. The lifecycle owner supplied read-only workflow catalogue access; fresh archive reference passes its captured knowledge directly so imported workflows remain discoverable without materialization. These exact regressions pass in the combined **71-test source run (47.98 seconds)** recorded in `release-packaging-evidence.md`, and the independent final-archive journey preserves reference state before and after materialization.
