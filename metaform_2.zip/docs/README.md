# Metaform documentation

The [SPEC](SPEC.md) states Metaform's intended semantic behavior. Explicit user
corrections govern that contract. The [reconciled repair backlog](repair-backlog.md)
and [release repair status](release-quality-status.md) track delivery work;
[current work](current-work.md) and [verification](verification.md) distinguish
implemented mechanisms from the evidence for them.

| Start here | Purpose |
| --- | --- |
| [Project README](../README.md) | First result, installation, project onboarding and capabilities. |
| [The shape of what is built](shape.md) | One page: the three doors, modules, workflows, the chassis, what is hard-coded, where files live. |
| [CLI and harnesses](cli-and-harnesses.md) | Built-in help, settings scopes, project selection, MCP and host verification. |
| [Knowledge and revisions](knowledge-and-revisions.md) | Layer selection, outside reports, recovery and a runnable transformation example. |
| [Workflows](workflows.md) | Executable grammar, literal import, conversion and assignment lifecycle. |
| [Plan](plan.md) | The ordered units still to build, what each delivers, and the decisions still open. |
| [Version guide](next-version.md) | Installed/service, legacy and portable storage; export/import; command effects. |
| [Workbench navigation](workbench-navigation.md) | Foundation and History controls, pending assignments and Activity. |
| [Workbench brief](workbench-brief.md) | The definition the workbench front end is rebuilt against, and the order of work. |
| [Workbench calls](workbench-calls.md) | What the page requests and what moved on its own, before and after the speed work. |
| [Examples index](../examples/README.md) | Runnable workflows, authored demos, historical MGM sample and retained live evidence. |
| [Architecture](architecture.md) | Knowledge authority, shared projections, transport and runtime boundaries. |
| [Semantic sources](semantics/README.md) and [Rulebook](rulebook/README.md) | Defined meanings, source provenance and task-specific rules. |
| [CI](ci.md) | Local/hosted verification and fork setup. |

The [primer](primer/README.md), dated handoffs and review folders preserve earlier
reasoning and observations. In particular, automatic two-pass Native/Latent
intake and the `01`/`10`/`11` shape comparison are historical v1 mechanics. Current
v2 intake publishes one Native foundation and attaches separately requested
knowledge. Historical samples remain available in History / Compare.

`metaform --help`, `metaform <module> --help`, and `metaform system reference`
provide the installed tool's own reference. Module availability and its returned
next actions come from the current registry; a documentation list is not a second
registry.
