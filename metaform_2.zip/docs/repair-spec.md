# Repair specification, 2026-09-10

> Current work is reconciled in [repair-backlog.md](repair-backlog.md) and tracked in [release-quality-status.md](release-quality-status.md). This original review retains its recorded snapshot; its repair claims do not supersede current verification.

This records what the onboarding review of 2026-09-10 repaired in the working
tree and what it found but did not repair. Each open item names the evidence,
the effect on a user, and the repair a following session should make. Items
marked *decision* change prompt semantics or product behavior Rich owns; make
them only after he decides. [Current work](current-work.md) and
[verification](verification.md) describe the surrounding state.
The agent outputs the review drew on are kept in
[reviews/2026-09-10-onboarding-review](reviews/2026-09-10-onboarding-review/README.md).
The complete inventory is [merged-issues.md](reviews/2026-09-10-onboarding-review/merged-issues.md):
every distinct issue merged by hand from the agents' 759 raw items, with
severity, sources, repair, and status. The lists below are the finalized things that need addressing, distilled from
that inventory; the bracketed ids point back to it.
The raw items are in [issues.md](reviews/2026-09-10-onboarding-review/issues.md).

## Repaired in this tree (uncommitted)

| Repair | Files | Verified by |
| --- | --- | --- |
| `metaform mcp` no longer hangs and tracebacks on ctrl-c; it prints one line and exits 130. Root cause: shutdown waited on the stdin reader thread blocked on the tty. | `src/metaform/cli.py` | `tests/test_mcp.py::test_mcp_server_stops_promptly_on_interrupt` |
| Ctrl-c at the `metaform install` harness prompt skips harness setup instead of tracebacking. | `src/metaform/installation.py` | `tests/test_installation.py::test_interactive_selection_reprompts_for_invalid_choice_and_allows_skip` |
| The skill is composed per SPEC section 12: a short concierge core in `SKILL.md` followed by a catalog rendered from registered modules (name, description, guidance, commands). Removing a module removes its section; community modules bring their own `guidance`. `metaform skill`, `guide.skill`, the `metaform` prompt and MCP initialization all use it. | `src/metaform/onboarding.py`, `data/skills/metaform/SKILL.md`, `data/modules/*.json`, `modules/guide.py`, `mcp_server.py`, `portable_mcp.py` | `tests/test_onboarding.py::test_skill_catalog_follows_registered_modules` |
| Every module manifest carries `name` and `description`; intake, enumerator, layer, knowledge, analysis and workflow carry `guidance` moved out of the old static skill text. | `src/metaform/data/modules/*.json` | same test; `test_guide_exposes_registered_module_commands_with_current_visibility` |
| The skill core tells an agent to save `guide.skill` into its host's skill directory when the host loads skills and the skill is missing. | `data/skills/metaform/SKILL.md` | read |
| `metaform install` writes the skill to `~/.metaform/skills/metaform/SKILL.md`, `~/.agents/skills/metaform/SKILL.md`, and for chosen harnesses to `~/.claude/skills`, `~/.codex/skills`, or `gemini skills install`. | `src/metaform/installation.py` | `tests/test_installation.py::test_install_writes_the_skill_where_configured_harnesses_discover_it`; isolated end-to-end run (`uv tool install`, `metaform install --harness cursor --harness claude`, `claude mcp list` reported Connected) |
| Assignment `begin` commands name the running entry point (installed launcher, `python <archive>`, or `python -m metaform`) instead of the fixed `python -m metaform`. The retained live trials show both agents wasting startup on the wrong spelling. | `src/metaform/continuation.py` | `tests/test_intake_continuation.py::test_assignment_begin_command_reaches_the_running_entry_point` |
| Installer test failed when run alone because the MCP client bound a captured stderr; imports moved to module scope. | `tests/test_installation.py` | 10 tests pass alone and in the suite |
| README rewritten around a no-model first result and the agent-driven path; version guide, current work and rulebook docs corrected (six views, dash-form flags, installer behavior). | `README.md`, `docs/next-version.md`, `docs/current-work.md`, `docs/rulebook/README.md` | commands in the README were run: demo, serve, install, build, distribution check |
| GitHub description corrected from "Interfence Metaform"; topics added. | repository metadata | `gh repo view` |

## Fix first

These block a first-time user, hide a failure, or corrupt state.

1. `metaform install` registers the current folder as a project and starts the knowledge service before it parses its own arguments; run from the home directory it registers `~`. Parse first, open the App only when needed. [A2]
2. The knowledge service never exits; every home used by a command, test, or scratch run leaves a daemon. Add an idle timeout and stop it in test teardown. [A3]
3. Once any assignment starts, the CLI swallows `--help`, typos, `system status`, and the documented `workflow answer --run-id` form, echoing the pending assignment with exit 0. Return an error that names the mode; make the explicit `--run-id` form work in mode. [C1]
4. An unbound `metaform answer` from any process lands on whichever run holds the mode; it corrupted an open Best Practices run in the review. Require the run id or the nonce binding, and refuse an answer whose schema does not match. [C2]
5. The CLI surface flips between argparse and raw words across one intake, and `metaform next` fails once the folder is bound. Accept both spellings in both states; add `put` to the raw help. [C3]
6. A stale `.agentid/nonce` in any parent folder rebinds every command below it until removed by hand. Ignore markers whose assignment is no longer pending and say which file. [C4]
7. Removing the Best Practices layer dead-ends onboarding (`incomplete_best_practices`, no next action), because the layer is found by its name string. Record the layer reference on the model and re-offer `enumerator.start`. [B6]
8. Creating or regenerating a layer from the workbench locks the semantic API ("Unknown command: layer.list") until the assignment is answered or aborted. Keep reads visible during exclusive layer runs. [I1]
9. Knowledge Enumerator packs 2^k questions per context into one all-fields-required assignment with no cap or count; a real project will hit this first. Report the count, chunk by subject group, re-ask only the missing fields. [F1]
10. `workflow.recurse` on a running parent starts a run with empty inputs, and Jinja renders missing inputs as literal placeholder text inside the prompt an agent receives. Refuse recursion on running runs; make undefined inputs an error. [H1]
11. `model.compare` ignores mappings recorded on the destination's transformation activity when computing layer impact, and the CLI cannot pass `--source` or `--mapping`. [G3]
12. The first history checkpoint after a git baseline marks every file modified with an empty diff (tar mode 0664 versus 0644) and stores a full copy of every file. Normalize modes. [J2]
13. Any command run with the Metaform checkout selected rebuilds `dist/` in a background thread; undocumented, untested, and triggered by test subprocesses. Document and gate. [J1]
14. `run_demo.py` fails on a fresh clone (needs an existing `.test-tmp`), defaults its output into tracked evidence, and `serve_demo.py`, `capture_demo.cjs`, `run_grounded_trial.py` chain through an absolute scratch path from the author's machine. Create the scratch dir, default output outside the tree, ignore `.test-tmp`. [L2]
15. No command loads the real MGM sample, the best no-model first result. Ship `examples/intake/mgm-main/load_sample.py` or `model import`, then move the README's first result onto it. [L1]
16. `intake.read` is UTF-8 only, so a photograph intake can record no evidence. Add a binary-aware read (size, hash, image dimensions) and let the agent attach its description. [D4]
17. MCP initialization sends about 39 KB per connection because `guide_state` embeds every command's input schema. Drop the schemas from the instructions copy. [B2]
18. `--debug` sticks in project state forever with no `--no-debug`. Add it and document. [C5]
19. `drive` with the default `mcp` harness from a plain CLI returns the job unchanged with no message, which looks like nothing happened. Print why it could not execute. [H2]
20. Nonce and request files under the home are never pruned, and an aborted intake leaves a dangling `workflow:metaform.intake` reference in exports. Prune on completion; drop aborted roots from export. [H3]
21. `uv tool install` and `metaform install` both own `~/.local/bin/metaform`; the second overwrites the first and `uv tool upgrade` may clobber it back. Document, or skip the launcher when a current uv shim exists. [A4]
22. The History-mode browser suite fails at HEAD: after "Display & layout controls" expands, the canvas shifts without resizing and clicks miss nodes. Resize Cytoscape on toggle. [I2]
23. The workbench gives no sign of pending assignments after Create layer, Regenerate, Run/handoff, or Edit revision, and Regenerate/Remove have no confirmation. [I4]
24. Superseded semantics are still bundled unmarked: `data/semantics/glossary.md` (two complete graphs), `metaform-intake.source.md`, the primer's 01/10/11 layer, and the "Implementation status" section of `artifacts-and-functional-intake.md`. One supersession pass with a header on each. [M1]
25. `compare_prompts.py` rewrites a tracked source file on every run and rebuilds its baseline from whatever HEAD is current, so the retained baseline arm cannot be reproduced. Pin the commit; stop writing the source. [L3]
26. The module manifest schema (`hidden_when`, `resourceKind`, `outputSchema`, `portable.*`, `raw_handler`, `disable_argparse`, flat manifests, `module_paths`) is documented only by example. Write `examples/module/README.md`. [K1]

## Fix next

Friction, missing diagnostics, small features.

27. Add `metaform --version` printing the package version and source hash. [A6]
28. Default `viewer serve` to port 0 like `browse`; 5077 cannot bind on WSL2. [A12]
29. On an ambiguous or missing `--model`, return the `model.discover` or `intake.start` hint instead of "Select a model from this project." Same for reads on multi-model archives. [C7, G11]
30. Add a compact CLI view for semantic reads; today `dependencies` dominates (40 KB for one element, 533 KB for `knowledge get`). [C8]
31. Give `history diff` and `history extract` manifest descriptions. [C9]
32. Accept `abort --run-id` so non-exclusive runs can be aborted from the CLI. [C11]
33. Allow `expansion list` without a target; make `layer.publish` reachable during its own run. [C13]
34. Make the intake completion string say that `intake.next` publishes; mark the two semantics copies of the intake text historical. [D9]
35. Declare `expansion_opportunities` in the foundation schema; document that acting on one is a manual `model expand`. [D10]
36. Validate `intake.start --artifact-context` against its schema. [D15]
37. Give `analysis.blindspots` a `name` argument; today the layer is named after the request text. [E3]
38. Document the three meanings of `knowledge.get` `layers` (absent, null, empty). [F3]
39. Let `layer.regenerate` re-ask only `coverage.missing`; align the `region` and `target` names. [F6]
40. Let `layer.inspect` resolve a removed layer with a `removed` flag. [F7]
41. Cache `knowledge.get` explanations per revision; profile on the MGM sample. [F10]
42. Key clone replay on the activity id so a different `--purpose` does not fail; document the rebase rule. [G4]
43. Mark the legacy `graph.*` commands as legacy in their manifests. [G8]
44. Add a sample transformation patch to `docs/workflows.md`. [G7]
45. Complete the `docs/workflows.md` step table (`parallel`, the prompt-step fields) and deliver the full expression grammar to the convert builder. [H5]
46. Default `base_dir` for `file:` prompts from the workflow file path. [H9]
47. Empty-state text in the Graph view names how to start intake; Activity's element count excludes seeded prompts and rules. [I5]
48. Label the MGM screenshot as History mode in its README; capture a Foundation screenshot of a real project once one exists. [I6]
49. `metaform browse` prints the URL on its own line, or gets `--open`. [I10]
50. Add a `package.json` pinning playwright; write browser-test output under a temp dir. [I11]
51. Superseded by established Ladybug/Cypher retirement (2026-09-11): remove the retired console and its guidance. [I13]
52. Hide `package build` when there is no `pyproject.toml`. [J3]
53. Document the export destination rule and the archive's sibling working folder in CLI help and START-HERE; document the portable dependency boundary and MCP SDK fallback; check module imports at export. [J4, J5]
54. Add `sync merge --dry-run`; check `gh` authentication before `package ci` runs. [J6]
55. Update the `package import` manifest description to say the result is a portable copy. [J8]
56. Report the effective service home in `system status` and warn when it differs from `METAFORM_HOME`. [J13]
57. Inspect the failed CI runs on `main` and the review branch. [J12]
58. Point `examples/realignment/README.md` at the complete live-comparison folders. [L4]
59. Add `examples/README.md`; delete or document `examples/review.json`; test or retire `element_prompts.json`. [L5]
60. Relabel the MGM sample README as a v1 two-pass record and expand "MGM" once. [L6]
61. Add a `docs/README.md` index and one terminology pass across README, SPEC, primer, and semantics. [M2]
62. Fix the `docs/workflows.md` examples that assume one model head or the exclusive-mode answer form. [M3]
63. Refresh the test counts in `docs/verification.md`. [M4]
64. Add the SPEC success signal sentence to the README's state section. [N9]
65. Commit `tests/test_installation.py` so CI covers the install path. [N8]
66. Document the `--no-exclusive` boolean flag form. [C6]
67. Record which hosts were verified to apply MCP instructions and to advertise sampling. [B4]
68. Verify VS Code and Cursor registration on a machine that has them. [A11]

## Tests to add

69. `output` step and `branch` step; remove the unread `requires_answer`. [H4]
70. `reusable_types` on intake; v2 abort with a running harness; a contract-2 run through the actor gateway. [D11, D13]
71. `knowledge.explain` at the read-operation level. [F11]
72. `history.diff`, the package import handoff re-publish, `auto_build`. [J9]
73. The archive-install path and the Windows `.cmd` shim. [A10]
74. Workflow `attachments` joins; the GUI Edit revision button. [H9, I8]
75. Watch the once-flaky `test_changed_engine_context_preserves_installer_advice_and_original_request` (vanished workfolder in a combined run). [L8]
76. Retain one live run each of blind-spot, Codex intake, a v2 intake of a real codebase, and a Metaform self-intake as evidence. [E2, H6, L9, K6]

## Decide

Only you can settle these. Each changes semantics or product behavior.

1. Does recorded source evidence (the verbatim file text the Native agent read) count as repository content the latent side must not see? Today the blind-spot assignment receives it. [E1]
2. Should `intake.answer` publish the foundation when it completes the run, or does the concierge always call `next` from outside the bound folder? [D1]
3. Seed the five bases as Types, or diagnose a Type rooted outside them at publish? Today `document.guide` publishes clean and then browses as unresolved. [D3]
4. Select the `reinfer` role for regenerate and reconsider jobs, or retire it? Today it is defined and never used. [G1]
5. Which rulebook rules does a v2 intake receive by default? Today none. [K2]
6. Is a second intake of the same repository a new revision of the same model, and are `evidence_handles` and `existing_model` meant to exist? Today each intake makes a new model and the two inputs are ignored. [D7]
7. Should harness registration carry the project, or does the harness's launch directory select it? [A5]
8. Record the last blind-spot generation on the model so `guide.start` can report it, or leave it to agent discretion? [B5]
9. Is a missing narrowing after a relocation a diagnostic (today) or a rejected patch, as SPEC section 11 reads? [G2]
10. Restore the Open project control the old README described, or remove its endpoint? Render the Defining Element path in the Foundation inspector? Which fields are editable there? [I3, I7, I8]
11. Settled: Ladybug was retired; remove its dependency, selectable backend and Cypher analysis support. This is an established repair, not an installation-extra decision. [A8]
12. Expose more of the image tool (presets, size, quality, references) through `imagegen.generate`? Build the photograph workflow as a bundled example? [K3]
13. License and pyproject metadata (authors, urls, name `metaform-chassis`); and the root clutter: tracked screenshot, `out.md`, the 3.5 MB archive, `feature-briefs/`, and the untracked swap, backup, and Zone.Identifier files. [N6, N7]
14. Should `intake.put` and `intake.answer` stay annotate-only (never reject), with the annotations surfaced in the completion summary? [D5]
15. Add the required Element field names to the intake role text, or keep them in the schema only? [D6]
16. Remove the vestigial `batch --limit`, `drive --concurrency`, `--steps` from `intake.json`? [D8]
17. Should the enumerator guidance say that the request phrasing is the whole instruction, and should display names be recorded at intake so the "program code" substitution goes away? [F2]
18. Align the SPEC's "applicable properties" wording with the code's backward visibility for enumerator contexts, and should join `participants` get entries? [F4]
19. Should property-combination advice flow down the branch (scope `target`) or stay `direct`? [F5]
20. Should `model.ground`'s `task` argument influence selection, or only be recorded? [G5]
21. Do you want a correction record type and a Medium marker, as SPEC sections 11 and A-11 read? [G9]
22. Keep the global-knowledge packaging mechanism dormant (no `data/global/` exists) or seed it? [J7]
23. Move the six review folders out of `dist/`? [J11]
24. Expose `disabled_commands` through `system configure`, or keep it internal? [C10]
25. Add a read-only workbench route, given `/api/semantic` dispatches writes and `/api/call` bypasses visibility? [I9]
26. Should design-step context reads count as dependencies of the generated attachments? [F8]
27. Gate the live intake that misplaced property joins with a diagnostic, or keep observing first? [E4]
28. Retire History / Compare mode once the MGM records are re-intaken under v2? [I6]

## Observed but outside this review's scope

- The live multi-Type trial placed engine-only and installer-only property
  joins on the coordinator (recorded in
  `examples/realignment/evidence/live-comparison/review.md`); the applicability
  resolver then reports them wrongly. This is prompt quality, retained as
  evidence per Rich's instruction to observe before gating.
- The photograph pipeline Rich describes (reason from the Inference Metaform,
  then prompt the photo's purpose onto its receivers) has no bundled workflow
  that calls `imagegen`; `media.photo.product.used` is a static example set.
