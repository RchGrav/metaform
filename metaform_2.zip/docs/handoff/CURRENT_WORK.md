# Current work

Snapshot captured on 2026-09-07 at approximately 18:24 UTC.

## Goal to resume

Complete the rulebook's agreed representation, then continue with Rich on the
remaining Element-schema rules and their use in the task/workflow interface.
Establish a maintainable development continuity process in this persistent CLI
workspace while doing that work.

## Remote state

Repository: <https://github.com/RchGrav/metaform>

| Item | Verified state at capture |
| --- | --- |
| `main` | `8085b1ae811e9fe53bd660b9b7b80d7eace76805` |
| Workbench cleanup | Merged through PR #2; included in `main` |
| Rulebook PR | <https://github.com/RchGrav/metaform/pull/3> — open, unmerged |
| PR #3 branch | `codex/element-rulebook` |
| PR #3 head | `5e9acea1427a9a9abb0b6af298c046a2516479b8` |

The handoff package was prepared without changing these branches or PRs. The
new checkout and its present working-tree state are the starting workspace.

## What is saved

Main contains the semantic source documents, narrative primers, existing
`AGENTS.md`, and the workbench cleanup. PR #3 adds a rulebook index, separate Name
and Description entries, the supplied `code` example, and a navigation link from
the semantic-source index.

PR #3 preserves the complete sentences verbatim, but calls them expanded forms
and uses shorter phrases as concise forms. D02 in `DECISIONS.md` records the
later agreed correction. It has not yet been applied to that PR.

## Current implementation and scope

- The merged cleanup makes the default graph represent intake knowledge, with
  an empty state when none has been collected. Supporting records remain
  inspectable with their recorded provenance.
- Viewer and preview startup return links. Automatic browser opening was
  removed.
- Example workflows are retained under `examples/workflows/` for explicit use.
  Automatic example seeding and the earlier Doors implementation were removed
  in the merged cleanup.
- The workflow GUI still presents forms; the requested named-workflow-to-steps
  presentation remains work to design and implement.
- The rulebook changes are documentation. They have not implemented a Rules
  editor, rule attachment UI, or first-exposure delivery mechanism.
- The CLI remains sufficient to operate the system. The current MCP router
  exposes broader commands; the role Rich presently wants to discuss is graph
  browsing.
- The viewer currently serves one selected project per process. Multiple
  project viewers and shared global knowledge exist. The desired longer-term
  project-selection and server arrangement remains open.

`docs/workbench-cleanup.md` is the concise inventory of the retained chassis,
intake, workflow, graph, packaging, image generation, and provenance capabilities.
`docs/serena-reference.md` records implementation references for the server/MCP
discussion.

## Documentation items to reconcile during relevant work

- `docs/next-version.md` still says browsing opens a browser; the merged cleanup
  removed that behavior.
- The authoritative Aliases material is bundled in
  `docs/semantics/inference_metaform_rules.md`. Older verification/source notes
  describe it as missing, while runtime source wiring still needs review.
- Some older source examples use `code.language.cplusplus`. The maintained
  namespace rules identify `code.cpp` as valid and the intervening `language`
  level as invalid.

## Validation carried forward

The cleanup pass reported 50 passing tests and successful distribution/offline
CLI, MCP, viewer, and export checks. That is the last reported software
verification, not a new test run for this handoff. A complete browser visual
inspection was not performed in that workspace because its browser connection
was blocked.

PR #3 was checked for exact preservation of the supplied sentences and example,
valid local document links, and whitespace. Its remote tree matched the local
committed contents. The handoff itself is a documentation transfer.
