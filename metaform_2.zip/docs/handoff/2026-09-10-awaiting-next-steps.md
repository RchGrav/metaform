# Development handoff — awaiting Rich's next-steps plan and specifications

## Where we are stopping

Rich is preparing the next-steps plan and specifications. **The next development
work is awaiting that plan and those specs.** His latest assessment is that
“the gui is heading in the right direction.” This is a positive assessment of
the direction, not a claim that the interface or semantic implementation is
finished.

## Start of the next session

Start by pulling the latest changes from `origin/main`. Rich's next-steps plan
and specifications should be present in an archive added as a new file. Locate
that newly added archive, inspect its contents, and read the plan and specs
before selecting implementation work. The archive's filename has not yet been
specified.

Read the plan and specs against the current implementation and established
semantics, resolve material ambiguities with Rich, and proceed with the agreed
work. Earlier backlogs and assistant suggestions
are context; they do not select the next task. The assistant's suggestion to
judge Defining Element relationships and join explanations was not an agreed
next-steps plan.

## Delivered baseline

The project work was committed and pushed to `main` as
`8c2f4a3ae6f8d858a14939f11a85450d9d5f3157`:
“Implement artifact-level intake and navigable graph viewer with real sample.”
That commit incorporates the upstream prompt changes through `c115a6c`.

- Native intake records actual project functions and freeform descriptions,
  organized through references to Type records. The overall `understanding`
  can contain a freeform diagram and functional account.
- Actual records use `metaform:actual-element` with `description` and `type_ids`.
  Type records retain `metaform:element`, their universal descriptions, existing
  namespaces, and backward name extraction through `length`. Type membership
  is displayed together with the actual record, without extra membership OP joins.
- Latent receives the complete Native account in a fresh assignment, outside
  the repository implementation frame. A completed Latent pass replaces its
  previous scope while preserving Native and other independently owned data.
- The viewer uses Cytoscape with directed layouts and authored Type SVGs.
  Clicking a node replaces the view with its immediate neighborhood. Neighbor
  browsing does not accumulate an ever-growing visible path.
- The inspector exposes incident joins, their purposes and signals, the
  element's relationship to the Defining Element, and its actual and Type
  descriptions separately. A fixed Defining Element control and viewport
  navigation support returning and backing out.

Primary implementation entry points are
[`intake.py`](../../src/metaform/intake.py),
[`schemas.json`](../../src/metaform/data/schemas.json),
[`viewer.py`](../../src/metaform/viewer.py),
[`workbench.js`](../../src/metaform/static/workbench.js),
[`structure.js`](../../src/metaform/static/structure.js), and
[`cytoscape-view.js`](../../src/metaform/static/cytoscape-view.js).
See also [workbench navigation](../workbench-navigation.md).

## Real intake available for analysis

The [MGM sample](../../examples/intake/mgm-main/README.md) contains the completed
run's original Native and Latent graphs, provenance manifest, hashes, and a
screenshot from the installed viewer.

| Perspective | Actual elements | Types | OP joins |
| --- | ---: | ---: | ---: |
| Native | 58 | 47 | 101 |
| Latent | 72 | 47 | 204 |

Run: `10c99044b7ca45f8944349b8b23dd21b`.
Defining Element: `mgm:project`, referencing `code.coordinator.gateway`.
Source revision: `5906ded0cd80177046340df41a822801501a0bcd`.
Native reused the prior source-inspection map and checked the current checkout
and repository guides. This was not a fresh exhaustive source audit or runtime
validation. Preserve the sample as generated when evaluating its quality.

The last verified installed viewer address was `http://127.0.0.1:45503`.
The MGM project route was
`/projects/7db2a051-0ad5-4ffb-9df8-53b93ca304eb/`.
The intake had completed; no further intake was requested for this handoff.

## Verification carried forward

Before the delivery commit, fresh verification passed 546 Python tests,
22 JavaScript model/renderer tests, both browser suites, and the wheel build.
The real installed viewer also passed local-neighborhood pointer navigation.
These results establish the exercised implementation behavior; the generated
intake remains available for semantic analysis. No tests were rerun solely to
write this handoff. [Verification details](../verification.md) retain the scope
and limits of the evidence.

## Context to preserve

The project's current `AGENTS.md`, semantic sources, and Rich's forthcoming
specifications carry the working definitions. Actual artifact detail and
universal Type descriptions have distinct places. Join roles are hard dependency,
property, and supportive; the join belongs to the receiving entity's Operative
Purpose. Signal describes the way that purpose is satisfied. Property
transitivity is settled, as recorded in the
[contract](../SPEC.md#7-encounter-propagation), and is not an open semantic blocker.

Native is the project's Inference Metaform. Latent sees Native's functional
understanding while remaining outside its implementation frame. Artifact scope
is not limited to code or to one project per repository. Preserve the namespace
and backward naming rule while describing actual elements freely.

The September 7 handoff files and older sections of `current-work.md` contain
historical implementation states. This handoff identifies the delivered baseline
for the next plan; it does not turn older proposed work into current instructions.

Temporary test output, `AGENTS.bak`, the duplicate `metaform.zip`, editor swap
files, and Windows `:Zone.Identifier` metadata remain local and uncommitted.
They were preserved during delivery. No cleanup of those files is pending as
part of this handoff.
