# Development continuity process

This is a proposed starting structure for the next context to refine with Rich
inside the persistent CLI workspace.

## Small maintained records

| Record | Purpose |
| --- | --- |
| `docs/decisions.md` | Current agreed decisions, brief reasons, sources, and supersession references. |
| `docs/current-work.md` | Current goal, implementation state, repository references, verification, open questions, and the next work to resume. |
| Existing semantic source files | Exact authoritative wording and worked examples, referenced by the other records. |

The handoff's `DECISIONS.md`, `CURRENT_WORK.md`, and `OPEN_QUESTIONS.md` provide
initial content for that structure. Their long-term location and organization
can be refined in the new workspace. A short reference in the checkout's
`AGENTS.md` can make the maintained records discoverable.

## During collaboration

When a decision is settled, record its identifier, capture date, wording or
source reference, brief rationale, and implementation status. Keep proposals
identified as proposals. A later decision can supersede an earlier one, with
Git preserving the history.

Preserve semantic formulas in their authoritative files and reference them from
the decision record. Record which files or behavior need to reflect a changed
decision. This keeps an accepted refinement visible even before implementation.

After a meaningful unit of work, update the current goal and work state with the
actual branch, commit or PR, completed changes, verification performed, and
remaining work. Commit and publish those development records along with the
relevant work using the project's normal Git workflow.

## Before another handoff

Review the current decisions and working state against what was actually saved.
Write a short collaboration review of practices that helped and specific
adjustments that would improve the next session. Keep its observations factual
and useful to the work ahead.

Lead the handoff with the next goal and a concrete starting item. Then point to
the maintained decisions, exact semantic sources, current state, and open
questions. Rich and the agent shape the intended context together before the
handoff is finalized.
