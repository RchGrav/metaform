# Current design decisions

Captured on 2026-09-07 from the development conversation. These are settled
directions; open matters are in `OPEN_QUESTIONS.md`. Implementation status is
separate and recorded in `CURRENT_WORK.md`.

## D01 — Rulebook purpose

A rulebook contains the precise rules that attach to a task or a process used
to complete a task. Name and Description are separate rules for completing the
Element schema. Their established wording is in `RULE_WORDING.md`.

## D02 — Rule presentation

The concise component is the complete semantic formula, which may be a complex
single sentence. The expanded component is additional explanation and examples
provided alongside it. First exposure presents both; later repetition in the
same agent context can use the concise rule when needed.

Rich's final clarification:

> the expanced version need not repeat the concise version the expanded version is extra detail provided alongside the concise version to lock in correct understanding on first exposure to the rule.

This supersedes the earlier arrangement recorded in PR #3. Application of this
refinement to the repository remains outstanding.

## D03 — Worked examples

The expanded presentation brings one wrong, one substandard, and one correct
example together. Use existing established material; other entries can provide
additional examples by reference. The supplied `code` trunk is preserved in
`RULE_WORDING.md`. The complete example set is still to be selected.

## D04 — Rules in the interface

Rules are a concrete, inspectable and editable interface feature, attached to
tasks or processes. Their placement in navigation is open. Rich suggested they
may sit inside an area containing related things such as tasks.

## D05 — Recognizable presentation

The interface should expose the actual system through direct, descriptive names
and relationships. A named workflow opens into its steps and the prompts used
there. The project graph represents collected and inferred project information,
with source attribution visible. Supporting prompt and workflow records have
their own identifiable role.

These are serious engineering tools for understanding and refining the system.
Interface organization should preserve Rich's ability to reason about what he
is viewing. The relevant earlier cleanup is documented in
`docs/workbench-cleanup.md` in the checkout.

## D06 — Scope of the Metaform concept

Rich described a Metaform as using a semantic function to express an invariant;
in the current base form, that invariant is Type. Encounter Function, Receiving
Entity, and Operative Purpose are the principal dimensions discussed for this
form. The broader concept allows other dimensions and forms. This is a
conceptual clarification to carry into future definition work, rather than a
newly authored replacement definition.

## D07 — Construction and semantic source

Construction starts with the composite artifact and decomposes it into its
participating Elements. Operative Purpose belongs to receiving relationships.
The namespace's levels carry semantic meaning, and the work is stated at the
Type level. The maintained namespace and alias equations are in
`docs/semantics/inference_metaform_rules.md`.

Contextual and independent inference remain attributable. Global inference
authors its own joins without receiving the project's contextual OP joins.
The repository's semantic sources already describe this separation in detail.

## D08 — Collaboration and implementation scope

Brainstorming is an invitation to develop an idea together. Established work
can proceed; consequential unresolved design choices belong in the discussion.
Use exact semantic source wording when preserving rules and prompts. The
checkout's `AGENTS.md` contains the existing collaboration guidance.

The next version's detailed interface organization and broader MCP role remain
open matters, as recorded in `OPEN_QUESTIONS.md`.
