# Discussions to resume

## Rulebook

- Develop the Alias and Dependency rule entries from existing source material
  and Rich's explanations. Alias equations already exist in
  `docs/semantics/inference_metaform_rules.md`; the typological process and OP
  dependency direction are described in
  `src/metaform/data/semantics/metaform-intake.source.md`.
- Develop the “rule rule” with Rich. The agreed concise-plus-supplement
  presentation is recorded in D02; a final rule sentence has not been settled.
- Select the complete wrong/substandard/correct example sets from existing
  material and retain the reason each example illustrates its category.
- Work out how the rulebook is stored and how applicable rules are attached to
  tasks or processes. The exact rule schema and runtime first-exposure tracking
  have not been designed.

## Record notes and terminology

Rich proposed a notes field. This is a schema proposal, not an implemented or
settled field. His supplied note for the `code` record is:

> We chose to use "programming language" over "computer code" because it better supported our desire to have all elements id's reverse into a natural description.

Element IDs, Type IDs, and Objects were left undecided. The assistant suggested
“namespace” for the particular sentence about reading lineage in reverse; Rich
has not finalized that naming choice. “Record” was also an assistant suggestion
for the stored representation.

## Interface organization

- Determine the containing area for tasks and related material, including
  rules. A dedicated top-level Rules navigation item has not been selected.
- Develop the named-workflow/step presentation and make the associated prompts
  and rules understandable in that context.
- Discuss how prompt trials relate to a concrete workflow and target. The
  existing answer/note storage is an observation facility; a workflow-level
  evaluation procedure has not been agreed.

## Server and MCP

Discuss project selection, process ownership, and graph browsing with Rich.
Serena was examined as a reference for running-server and deployment patterns.
Its patterns are reference material, not an adopted architecture. Broader MCP
workflow exposure remains open.
