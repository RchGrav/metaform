# Established rule wording

These are Richard Graver's established initial Name and Description rules for
completing the Element schema. The sentences below retain the supplied wording
verbatim, including its original grammar. They are the concise formulas under
the latest agreed arrangement.

## Name

The most basic universal name as a singular proper noun which places itself comfortably into the definitions of its children

## Description

The most basic universal statement that both defines uses the ancestral proper nouns of its lineage in reverse namespace order in a semantically proper statement but never name or include the most basic universal definition of the encounter or functions of its children

## Supplied trunk example

```yaml
code:
  name: programming language
  description: a set of precise instructions that tells a computer how to perform a task or process data
```

The other starting trunks are `document`, `media`, and `data`. Their corresponding
seed definitions were not settled in this discussion.

Expanded supporting material accompanies a rule on first exposure. The complete
set of wrong, substandard, and correct worked examples remains to be selected
from existing established material with Rich.
