# Collaboration review

## Practices worth carrying forward

The work was strongest when conceptual discussion was connected to concrete
source material and observable implementation. Exact rule wording was preserved,
repository changes were isolated and published with identifiable contents, and
software verification was distinguished from design interpretation.

Rich values an active sounding board. Offer specific judgments and useful
connections, help develop ideas, and explain concrete reasons for criticism.
When a decision becomes clear, carry the agreed work through to a usable result.

## Improvements for the next session

**Keep implementation aligned with the visible design.** Some implementation
choices advanced before their role and presentation had been jointly
understood. Begin from the named things and relationships Rich expects to
inspect, then choose the implementation that serves them. Surface consequential
new choices during the design conversation.

**Maintain decisions as they evolve.** Exact source preservation worked, but
later refinements to the rule presentation remained only in conversation.
Record a settled refinement when it happens and identify the affected source or
implementation, so the saved state continues to represent the current intent.

**Use examples to demonstrate meaning.** Example selection needs the same
semantic care as the rule text. Existing established material is the starting
point. A problem with an example should be addressed at the example; any proposed
change to a settled rule needs its own concrete semantic reason.

**Keep status explicit.** Distinguish accepted decisions, assistant proposals,
implemented behavior, and completed verification. This lets discussion remain
open without making provisional ideas look like product requirements.

These are development collaboration practices. The existing `AGENTS.md` keeps
that role separate from the instructions authored for Metaform's runtime agents.
