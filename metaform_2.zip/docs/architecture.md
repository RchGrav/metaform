# Architecture and research

Realignment architecture updated 2026-09-10. External research links below retain
their original 2026-09-05 review context; implementation claims describe the local
code and recorded verification.

[SPEC](SPEC.md) defines intended semantic behavior. This document describes the
current chassis; [current work](current-work.md) tracks outstanding alignment.

## Shared chassis

JSON manifests describe commands independently of Python imports. The CLI builds
argparse entries from their input schemas. MCP exposes the same registry.
Takeover and command disabling operate at dispatch; raw input is delivered to
the owning module without main-parser interpretation. An always-available
command survives takeover. `abort` is intrinsic to the chassis.

Runtime state remains in project-local SQLite at `.metaform/state.sqlite3`.
Per-run file locks serialize transitions across CLI and server processes; local
transactions retain answers, run stacks, events, and workfolder identities.
Knowledge operations have a separate interface: `BoundGraph` adapts existing
per-owner methods, while `RemoteKnowledge` and `LocalKnowledge` dispatch the same
graph, schema, assembly, and inference operations.

New installed projects register with one user-local service per resolved
`METAFORM_HOME`. Its central database is `service/knowledge.sqlite3`. Legacy
projects continue using their configured SQLite or JSON files until
`project connect` explicitly adopts them. Adoption preserves original files,
imports source records without generating replacement observations, reports
competing content, and publishes the service marker after transaction commit and
source verification. Global imports are tracked by source home and digest.
Portable mode selects local JSON before service discovery or ambient seeding.

The service uses authenticated loopback HTTP. Startup requires a fresh challenge
response matching the service, instance, and protocol identities and readiness;
endpoint files, PID values, and open ports alone are insufficient. OS-backed
startup and lifetime locks serialize discovery and ownership. `service status`
probes actual liveness; `service stop` addresses the verified instance. The service
owns knowledge and performs no model work.

A registered project UUID is separate from its canonical path and history ID.
`--project` accepts a path or registered ID; assignment binding takes precedence
over invocation selection. `project select` replaces an MCP session's selected
App for subsequent calls, while in-flight requests keep their captured App.
Workbench URLs identify projects so tabs remain independent. Moves use
`project relocate`; explicit `project connect --new` creates a new owner, copies
the registered source partition, and translates structured self-owner references.
Execution state stays with each project directory.

## MCP workflow orchestration

The implementation uses the official Python SDK 2.1 line. It supports the older
session protocol and the 2026-07-28 protocol, whose requests can return
`InputRequiredResult` and resume with input responses. This avoids trying to
make the server initiate unsupported modern sampling requests.
[Python SDK](https://github.com/modelcontextprotocol/python-sdk),
[sampling specification](https://modelcontextprotocol.io/specification/2026-07-28/client/sampling).

The modern tools specification disallows changing a tool catalog as a side effect
of another request. Consequently the modern server exposes a stable `metaform`
router, `abort`, and always-available tools. Available module commands are data
returned by the router. Older clients receive individual tools and list-change
notifications. This preserves the requested mode semantics across both protocols.
[Modern tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools),
[2025-11-25 tools](https://modelcontextprotocol.io/specification/2025-11-25/server/tools).

Sampling can itself call scoped tools, receive their results, and continue before
answering an assignment. A server-held continuation retains the same request ID
and explicit message history. The local intake agent can read repository files;
the outside-report role receives the full Native account without project file
reads. Already-issued v1 Latent assignments retain their recorded tool contract.
The host-answer loop remains available when client sampling is unavailable.
Durability is application-owned, rather than tied to experimental task APIs;
tasks changed to an extension in the modern protocol.
[Protocol changes](https://modelcontextprotocol.io/specification/2026-07-28/changelog).

The modern protocol returns independently keyed requests in one
`InputRequiredResult`; completed answers remain retained while unfinished jobs
continue their own tool exchanges. The older protocol uses concurrent sampling
calls. Actor gateways and MCP tool calls bind the exact issued request ID, and
`continuation.current` resolves that assignment rather than a sibling request.

## Reified graph and executable logic

Elements retain the ET fields: `entity_desc`, `entity_schema`, `entity_json_obj`,
keyed in the shared store by `(owner, id)`. Owners are `global` or
`project:<uuid>`; semantic source and physical location are separate axes. Joins
have identities, endpoints, scope, and an arbitrary list of
role-bearing participants. This implements n-ary relations whose purposes,
conditions, and attribution can be addressed directly. Relations can participate
in further relations. It does not reduce every association to an unannotated
pair of nodes. W3C's n-ary pattern is useful here; ordinary RDF statement
reification and an n-ary domain relation are distinct concepts.
[W3C n-ary relations](https://www.w3.org/TR/swbp-n-aryRelations/).

Workflow membership and transitions are graph relations. A condition may refer
to a rule Element and that Element's serialized expression. The executable
snapshot is reconstructed from this graph, so graph logic is operational rather
than a decorative copy of code. The evaluator is deliberately small and explicit;
new operators can be implemented as code while workflow instances remain data.
[JsonLogic](https://jsonlogic.com/),
[SQLite JSON support](https://sqlite.org/json1.html).

References retain their authored strings. Optional `participants[].owner` and
endpoint `reference_owners` make cross-owner references precise. Unqualified
project references resolve locally, then globally; global references resolve in
global knowledge. Equal IDs in different owners remain independently addressable.
Element-address incidence can discover both selected-project and global joins;
references to joins compare qualified join identities. Endpoints remain relevant
even when a join also supplies participants.

Cycle-safe traversal follows endpoints, participants, and reified joins. Runtime
assembly retains owner partitions and honors caller depth, category, and source.
`knowledge.snapshot` follows the complete selected-project closure in one SQLite
read transaction, using owner/reference indexes rather than exporting the entire
global graph first. Other projects' private joins do not expand it; explicit
references outside the selected owners and missing bodies remain reported.
Current source relationships expand closure, while exact historical completion
bodies and their dependencies remain evidence. Similarity does not expand the
source traversal. Indexed selection has dedicated scale and concurrent-writer
checks. Ordinary central graph mutations currently reconstruct and replace one
owner partition inside their transaction; that remains a practical scale limit.

Source observations retain object contributions. Scoped retrieval, search,
assembly, and export use the selected source's latest record. Native and
Latent Expert joins have separate source identities even when their authored IDs
coincide. Structural similarity compares node identities, join types, participant
roles, and references, including references to joins. Its `01`, `10`, and `11`
records contain structure and source references; semantic contents stay in the
Contextual and Latent graphs. `graph.similarity` retains this legacy comparison view under the historical
source contract. New foundation publication does not create a merged structural
Metaform. The viewer retains explicit legacy source inspection. The implementation does not claim
full PROV-O conformance.
[W3C PROV-O](https://www.w3.org/TR/prov-o/).

## Semantic models and attached knowledge

`models.py` exposes `capture_model`, `publish_foundation` and the lossless
`import_v1` adapter. A ModelRef names project, model and immutable revision. The
foundation contains Types, Elements, bindings, narrowing relationships,
refinements and Receiving Entity-owned OP joins. A join records its `property` or
`requirement` role and supplied `classification`. For a property, `is_soft: true`
means non-transitive; for a requirement, it means optional. Absent or false means
transitive or required respectively. References carry owner, kind and ID;
optional revision pins expose mismatches as diagnostics rather than selecting
another owner's or revision's meaning.

The foundation journal and current-model pointer are schema-specific records in
the existing owner partition. Service publication uses its SQLite transaction;
portable publication uses the existing local graph and locks. A base ModelRef
provides compare-and-publish behavior, and expected-absent publication protects a
new model name from a concurrent creator. Referenced existing Type definitions
are frozen into the revision. The structural hash excludes artwork, timestamps,
execution records and attached-layer payloads; it records unchanged serialized
meaning, not a proof of semantic equivalence.

`namespace.py` and `read_model.py` implement the shared resolver and bounded
projections. Type inspection, Type membership, namespace children and OP
traversal are separate questions. Results carry canonical targets, complete OP
bundles, coverage, revision-bound cursors and record/selector dependencies.
CLI/MCP manifests and the viewer delegate to these helpers. Explicit revision
reads use the service's revision lookup and reusable projection indexes.

`properties.py` resolves applicability with the origin, path and scope retained.
Backward visibility at an ancestor is separate from forward applicability.
Type inheritance, Element refinement and join context each use their own recorded
relationship. Layer origin remains separate from an inheritance path.

`layers.py` stores named layers, recipes, generations and attachments through
owner-qualified graph records. Generation and selected regeneration use Engine
runs and answer receipts. Recipes retain the exact semantic request, source and
rendered prompt, component/schema snapshots, selected context and dependencies.
The outside role receives the complete coarse foundation and attaches a report;
its findings do not become foundation Elements.

`knowledge_tool.py` implements **Knowledge Tool**, exposed through
`knowledge.preview` and `knowledge.start`. It renders the user's unchanged
instruction prefix followed by `for` and recorded context. Names use recorded
names and Type `length` with leaf-backward reading. Base functional knowledge
and whole property-qualified composites have separate questions and attachment
origins. A composite keeps the recorded component properties together with their
Type meanings, provider EF, Receiving Entity, Operative Purpose, role, signal
and participants. Backward property visibility retains its branch origin rather
than becoming a property claim on unrelated branches.

Preview returns those questions, the answer schema and attachment mapping.
Start requires the user's layer name and passes the rendered questions to one
assignment declaring fresh context. The response is an object of string arrays
keyed `q1_array`, `q2_array`, and so on. The runtime maps each
array to its recorded base or whole-composite attachment and publishes it
in the named layer. Existing layer reads expose those attachments through MCP
and the viewer. `Write 3 best practices` with the name `Best Practices` is one
default instruction for this generic module; its execution uses the same
continuation engine and does not commission a layer-design agent.

`expansion.py` prepares one requested region and purpose, then applies a structural
patch with stable Element identities and explicit refinements. `transform.py`
creates source-preserving variants and applies record-aware changes. Nonoverlapping
changes can rebase; conflicting records remain observable. Impact compares
records and selectors, including newly matching and absent context, and preserves
or regenerates the corresponding destination layer associations.

## Focused intake and workflow context

Managed runtime prompts are composed from the role text, selected semantic
components, output schema and named inputs. Authored overrides and already-issued
assignments retain their provenance. Source instruction text is kept separate
from literal input values and runtime controls.

The runtime renders workflow and subagent prompts deterministically and stores
the exact assignment before handoff. Its nonce binds the project, run and
request to that stored assignment. The executing agent receives that assignment;
the orchestrator routes the nonce and follows continuations without paraphrasing
or redesigning the prompt. This boundary applies to Knowledge Tool as well
as other workflow assignments.

Task and nonce registration, `.agentid/nonce` creation, preparation of the empty
workfolder, command scoping including answer submission, and folder cleanup
belong to the chassis. Modules reuse this lifecycle; Knowledge Tool
supplies its rendered questions and result mapping without owning those runtime
duties.

New v2 intake records its whole-artifact account incrementally and publishes one
foundation when complete. It does not schedule a second structural archaeology
pass. `analysis.blindspots`, and `intake.examine` for new v2 use, request a separate
outside report layer. Historical v1 assignments keep their recorded interpretation.

Grounding reads a selected region deterministically. Specialization uses that
prepared context while retaining the original instruction and workflow control
flow. Layers, expansion and reinference reuse the existing continuation engine;
there is no second queue or per-client semantic state.

### Historical global knowledge operations

### Direct global knowledge operations

The implementation retains the focal authored structure in completion
provenance and records each join's `inference_type` and `authored_id`, with
namespaced stored IDs for concurrent contributions. Reuse follows this ownership
rather than importing every record reachable by undirected traversal. For
example, A depending on B does not make A part of B's dependency graph.
The knowledge service's `inference.read` operation retrieves a selected completed
global structure. These direct store operations are separate from the project
intake flow.

The `inference.read` result contains `id`, `inference_complete`, `status`, and `graph`.
Its completed graph holds focal-authored joins and explicitly named or referenced
Type members resolved from current global records, then captured completion
records, then retained archive dependencies. Incomplete results have no graph;
legacy completion markers without a stored snapshot report
`unresolved_structure`. The snapshot is on the completion observation, preserving
the authored Element record. `inference.commit` performs the completed check,
global contribution and completion observation, project Latent write, and durable
receipt in one central SQLite transaction. `inference.contribute` and promotion
also keep their existing checks and writes within that boundary. Receipts are
keyed by project context and request ID; reusing an ID with different arguments
reports a conflict. Retrying a committed request returns its original result,
allowing the caller to recover a committed result after a lost response.

Concurrent global inference commits retain the first completed graph and reuse
it for later commits. Portable knowledge uses local locking; its separate JSON
files retain their local crash boundary.

Project archives use `metaform-export/2`. They carry the selected closure, source
observations, owner-qualified schemas, historical dependency material, selected
executable assets, and project-bound execution/assignment state. The exported
logical project UUID is preserved; a separate `copy_id` identifies the portable
working copy. JSON graph records and restored local SQLite execution state support
continued prompt/workflow operations and another export without the service
or unrelated packaged global inference. Imports accept versions 1 and 2
and retain inclusive-history replacement and divergent-history sibling behavior.
They create portable copies, not shared-service reconciliation.

The shared knowledge service uses SQLite. Legacy local storage supports SQLite
and JSON, and portable projects use JSON. Ladybug and its Cypher analysis copies
were retired; they are not an installation dependency, backend choice or public
query interface. Existing retired-backend files are not converted or modified.

The separate `sync export` operation produces one JSON file per global object
or join, plus observations and an
index containing a content hash. Wheels load an updated indexed bundle once per
shared installation; a later project using the same unchanged bundle does not
reset local global contributions. Changed packaged versions update canonical
records while retaining prior observations. Native joins are never part of this
export path. Sync contributes only data from an isolated worktree based on shared
history; it does not push unrelated development commits. Git merges surface
conflicting edits for resolution.

## Distribution, interface, and remaining evidence

Git diff works on chassis-created repositories even when the original project
is an ordinary directory. Completed development copies remain available for
review and explicit application. Fresh latent inference copies are cleaned after
their assignment. File locks coordinate same-host execution and builds.
[Filelock](https://py-filelock.readthedocs.io/).

Flask provides the local inspection UI in a separate process. A production
deployment can use its WSGI application factory with a suitable WSGI server.
[Flask deployment](https://flask.palletsprojects.com/en/stable/deploying/).

CI tests, builds, and uploads wheels, including graph-data-only commits. It has
no automatic PyPI publishing or PR-merging step.
[GitHub Python workflows](https://docs.github.com/actions/guides/building-and-testing-python),
[PyPA packaging guidance](https://packaging.python.org/guides/publishing-package-distribution-releases-using-github-actions-ci-cd-workflows/).

Working control flow is not proof of semantic correctness. Current tests exercise
fixture agents through real processes and MCP clients. Comparative measurements
of token use, inference quality, omission rate, refactoring success, and model
context isolation remain future evaluations. The Aliases source is bundled;
live model/image-provider authentication remains necessary for provider runs.
