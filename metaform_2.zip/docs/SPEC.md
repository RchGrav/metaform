---
id: SPEC-metaform
sources:
  - README.md
  - docs/primer/01_full_explanation.md
  - docs/primer/02_specification_introduction.md
  - docs/primer/03_technical_account.md
  - docs/semantics/inference_metaform_rules.md
  - docs/semantics/names-receivers-and-variants.md
  - docs/semantics/artifacts-and-functional-intake.md
  - docs/rulebook/element/name.md
  - src/metaform/data/semantics/glossary.md
  - src/metaform/data/semantics/native.md
  - src/metaform/data/semantics/archaeology.md
  - docs/workflows.md
  - docs/workbench-cleanup.md
---

> **Canonical contract.** This document defines the intended semantic product behavior for Metaform. Explicit user-supplied definitions and corrections govern it. Repository implementation and tests are evidence to compare against this contract, not sources of truth by existence.

# Metaform

[Capabilities](#capabilities) · [Semantic contract](#semantic-contract) · [Acceptance scenarios](#acceptance-scenarios) · [Current work](current-work.md)

## Why

Metaform is a context engineering tool. It engineers context: it engineers the
context to install itself, it engineers the context of every sub-agent, and it
enables true prompt-chained workflows that have been enhanced by the Inference
Metaform.

The shape does not have to be stable across models. Different models may
arrive at different answers, but the answer being used is collected once when
onboarding a plan or bringing this into existing work, and its quality depends
on the model that infers the shape and the knowledge built into it for the
project. An ounce of planning is worth a pound of cure: the latent space sees
the issues the agents in the project are embroiled in. It takes 150 miles of
wire to wire a 747, and they use a form board to do it. Our form board is a
flexible tripartite mesh comprised of inference amortization that took
intelligence to create, the same kind of inference every model must do to
ground itself in the work before it makes a single inference that becomes
tangible. This project seeks to lower inference cost, not dollar cost but the
cost a model pays to orient itself on every action, trading that for
low-overhead inherent type understanding that was a precursor to reasoning
itself, because type comes before reasoning. The end product takes a serious
step towards making it easier for models to complete their work, targeting
and engineering context with the precision of a laser, and freeing up
valuable inference cost that a model can use to make its work smooth and to
alleviate obstacles which present as friction that leads to model capability
exhaustion. When a model is born to complete tasks and the friction to doing
that is too great, that is when gaming comes in, and the cost is too heavy.

Metaform exists to amortize inference about the project being worked on: describe its actual artifacts, functions, properties, and receiving purposes, preserve that understanding as its Native Inference Metaform, and let later work begin from it. Artifact Types organize that understanding in the Namespace. Inputs may include software, photographs, contracts, stories, resale materials, or several distinct projects in one collection. Cost here means inference effort. The desired effect is more reasoning available for higher-order work without repeatedly reconstructing the project's functional understanding.

## Capabilities

- **CAP-1 — Reusable inference preparation**
  - **intent:** The system can prepare reusable semantic understanding so later operations can address project and type meaning without reconstructing the same prerequisite inference from raw artifacts each time.
  - **success:** After preparation, a compact type-level instruction can produce project-specific results that depend on represented semantic relationships without restating those relationships in the instruction.

- **CAP-2 — Contextual Metaform**
  - **intent:** The system can construct a Contextual Metaform from the actual project or implementation plan, preserving project-local Elements and semantic relationships with contextual provenance.
  - **success:** Project-derived Receiving Entities, Operative Purposes, Encounter Functions, Elements, and joins are represented with provenance that distinguishes them from latent inference.

- **CAP-3 — Outside-in knowledge**
  - **intent:** Invoke independent latent reasoning on the complete Native functional account while remaining outside the implementation frame.
  - **success:** The role can agree, disagree or identify omissions. Its report attaches as separately attributed knowledge; proposed structure does not become current Elements merely by appearing in the report.

- **CAP-4 — Named knowledge layers**
  - **intent:** Attach differently requested knowledge to the same structural foundation through independently versioned layers.
  - **success:** Each layer retains its request, schema, producing recipe, generations, subjects, applicability and provenance. Removing or regenerating one layer preserves other layers and the foundation. Historical v1 source comparisons remain separately observable.

- **CAP-5 — Project-inferred strict typology**
  - **intent:** The system can infer a project-appropriate strict functional typology and construct recoverable names through the agreed Namespace rule. Exterior denotes an entity that is not part of the project, with its own lightly defined scope.
  - **success:** Functional Namespace prefixes express meaningful Types that organize the actual artifacts and functions being described. Placement follows semantic specificity, reuses the appropriate existing position, and records the common name's extent in `length`. Reversing the final `length` components recovers the name. The exterior exception is described in the semantic contract.

- **CAP-6 — Receiving purposes and participation**
  - **intent:** Intake identifies the actual receiving purposes and how linked Elements serve them. Roles belong to joins owned by the receiving entity's OP. Properties and hard requirements describe what the artifact needs.
  - **success:** Later inference can address those actual relationships. Parametric tunables remain in a Type's array with their names reserved against Namespace Elements; tuning alone does not constitute acceptance. Notable is retired as a separate category because the OP already explains participation.

- **CAP-7 — Encounter propagation**
  - **intent:** The system can propagate an Encounter through the functional type structure so inference at each affected type is conditioned by the relevant realization or encounter.
  - **success:** If `code.bash` is linked to an installer type and `code.cpp` to a game-engine type, broad `code` reasoning can see both; each Encounter conditions the appropriate branch without leaking into an unrelated sibling branch solely through their common ancestor.

- **CAP-8 — Open-ended type-level operations**
  - **intent:** The system can execute general prompts across actual Elements and their relationships without requiring a dedicated hard-coded operation for each reasoning task.
  - **success:** One instruction such as generating best practices or imperatives for every relevant type produces type-specific output conditioned by each type's connected Elements, Encounters, Receiving Entities, and Operative Purposes.

- **CAP-9 — Workflow specialization**
  - **intent:** The system can resolve a general workflow or prompt into the relevant project Elements and semantic relationships while preserving the source operation's intent and control flow.
  - **success:** A specialized workflow addresses concrete project semantics without adding unrelated requirements or changing authored branching/sequence semantics.

- **CAP-10 — Blind-spot examination and explicit correction**
  - **intent:** Examine the artifact from its recorded account to identify omissions and alternative interpretations.
  - **success:** Findings remain attached report knowledge. An explicitly applied structural correction produces a new foundation revision with the source evidence and reason retained; the original account and report remain observable.

- **CAP-11 — Refactoring through semantic relations**
  - **intent:** The system can reason about refactoring through represented type meaning rather than treating the current implementation shape as the thing that must be preserved.
  - **success:** Refactoring guidance can consider radically different realizations through the relevant Functions, Encounters, Receiving Entities, Operative Purposes, and relationships needed by the work.

- **CAP-12 — Porting through Encounter change**
  - **intent:** The system can clone Native project understanding into a variant and develop a target realization through a changed Encounter relationship.
  - **success:** Replacing the variant's Property / Medium relationship from `code.cpp` to `code.javascript` detaches reasoning derived from the replaced relationship and reissues its producing prompts against the changed context. Newly produced knowledge belongs to the variant; the base retains its original understanding.

- **CAP-13 — Coarse semantic representation**
  - **intent:** The Metaform represents enough type-level semantic shape to reason effectively without attempting to enumerate every true property, purpose, environment fact, or implementation detail.
  - **success:** The graph remains compact enough for reusable inference while still allowing later operations to deepen selectively through connected Elements and relationships when the task requires it.

- **CAP-14 — Shared knowledge and independent portable projects**
  - **intent:** Projects can use a shared knowledge service and carry their related understanding into a self-contained executable export.
  - **success:** Export follows global and selected-project relationships, including workflow dependencies, while other projects' local relationships remain outside its traversal. Source contents and provenance remain intact. The exported project can read and extend its JSON knowledge, continue work using local SQLite execution state, and export again without the service. Supported storage is SQLite or JSON; portable projects use JSON.

- **CAP-15 — Producing context and regenerated understanding**
  - **intent:** Derived knowledge retains its originating prompt and the semantic relationships on which it depends so a meaningful change can cause the relevant questions to be asked again.
  - **success:** A changed relationship in a variant identifies affected reasoning and its producing operations. The system detaches that reasoning from the variant, issues those operations with the new semantic context, and attaches their results with new producing context.

- **CAP-16 — Exterior receiving purpose**
  - **intent:** Intake resolves the receiving entity outside the project that has an OP for the DE's EF, and also represents exterior providers whose EFs serve the artifact's requirements.
  - **success:** An OP join makes the exterior receiver, its own purpose, the actual DE provider and the provider Type EF available to subsequent reasoning.

## Constraints

- `C(T)` defines semantic type identity. It is part of the semantic model, not a required runtime mechanism.
- New intake produces one structural foundation. Additional knowledge retains separate layer ownership and generation history. Historical v1 source graphs and `01`/`10`/`11` comparisons retain their original meaning and remain accessible as history.
- Latent reasoning receives the complete Native functional structure, including project joins and OPs, while remaining outside the repository's implementation frame.
- The functional namespace is a strict typology, not a domain/class taxonomy. Its prefixes express meaningful Types; Function or Encounter characterizes each narrowing relationship. The `exterior` trunk denotes entities that are not part of the project and is exempt from the reverse-reading requirement. External denotes something outside the functionality being examined but still within the repository.
- Established semantic terms are operative semantic content and must be preserved verbatim. The system must not paraphrase, rewrite, normalize, synonym-substitute, rename, collapse, or replace an established semantic term, including Element-role names.
- Typological placement is inferred from meaning and specificity. The agreed Name rule constructs the local reversed name sequence at that position and records its extent in `length`.
- Each Type has one Encounter Function at its represented resolution. A materially different Encounter implies a different Type/variant, expressed through the typology rather than by adding another EF to the same Type.
- Receiving Entities and Operative Purposes are modeled coarsely enough to provide a useful reasoning frame rather than exhaustively enumerating every possible purpose. Apparent over-specificity is resolved by generalizing the Encounter Function or distinguishing the Receiving Entity where appropriate.
- Encounter-linked project properties remain project-local unless independently established as global type knowledge.
- The operation surface remains open-ended. Refactoring, porting, diagnosis, best-practice generation, foresight, and review are examples, not a closed operator catalog.
- The base Metaform need not encode every true environmental fact. Environmental context belongs only where it materially affects the semantic reasoning required.

## Semantic contract

### 1. Type identity

For a Type `T`, the formal identity is the exact set:

`C(T) = {(rᵢ ∧ pᵢ ∧ e)}`

where each conjunction binds:

- `rᵢ` — Receiving Entity: the **who or what** receiving the effect;
- `pᵢ` — Operative Purpose: the **why** owned by that Receiving Entity;
- `e` — the Type's single Encounter Function: the **how** through which the effect is realized or encountered.

`C(T)` is exact as a semantic definition. It is not a lower bound, partial signature, similarity measure, confidence score, or candidate identity projection.

A Type has one Encounter Function at the represented resolution. A materially different Encounter makes a different Type or variant, represented through a further typological distinction rather than by adding a second EF to the same Type.

Receiving Entities are connected at the most general level that still preserves the useful Operative Purpose. The goal is a coarse reasoning frame, not exhaustive enumeration of every purpose or possible receiver. If an apparent distinction forces the EF or OP into excessive specificity, the model should seek a more general Encounter Function or distinguish the Receiving Entity appropriately.

These definitions describe the semantic relationship that protects type meaning through change. They do not prescribe a runtime identity-checking mechanism.

### 2. OP join roles

Roles belong to joins owned by receiving entities' Operative Purposes. The roles
are `property` and `requirement`. A join's `classification` records the supplied
category, such as language, medium, dependency or functionality; it is an open
string, not a new Type or a classification whitelist.

For a property, `is_soft: true` limits its effect to its receiving Element
instead of propagating it. For a requirement, `is_soft: true` records an optional
requirement. The receiver's purpose and the provider Type's single EF retain
their meaning in either case.

In the supplied `code.game` example, its OP for `code.cpp` is a property with
Medium classification, while its OP for `code.game.rules` is a requirement
with Dependency classification. These joins express how the receiving Element
uses the linked Element's EF. **Parametric** is a Type's array of tunables. It
acknowledges those items and reserves their names against being minted as
Namespace Elements. Adjusting a tunable does not by itself constitute acceptance.

**Signal** is the way an OP is satisfied. This definition does not prescribe
an acceptance-check mechanism or an additional role taxonomy.

#### Exterior and external relationships

`exterior` means not part of the project. **External** means outside the
functionality being examined but still within the repository. Control or
ownership does not define this distinction. Either relationship can involve
an entity receiving the artifact's EF or providing an EF for an artifact's OP.

Intake resolves the upstream receiver and its OP as part of project
understanding. A receiver-owned OP join references the DE as provider and names
the provider Type whose EF participates in that meeting.

Exterior is lightly defined and exempt from the reverse-reading requirement
of the functional trunks. Environment, person, group, system, and framework
are tentative subgroup examples. Player Group, a family, an organization,
and a dental industry group illustrate receiving contexts.
These examples do not prescribe a closed receiver list. Several receiver-owned
joins may refer to the same DE while retaining their distinct purposes.

#### Element descriptions and expert roles

The **Native Expert** describes the actual system freely, using a diagram, account, or structured content in `understanding` when useful, then describes its typological organization. Elements use an open description shape so their detail can speak directly to the system. The input may be a folder of assets, standalone artifacts, or several projects; its contents may be photographs, documents, stories, software, or other material.

The walk first identifies the **Defining Element**, whose EF summarizes the combined result of the artifact under analysis, then its Receiving Entity and that entity's Operative Purpose. The DE's loss would change what the artifact is; its defining function excludes medium, encoding, genre, and style. Intake names its properties and hard requirements, joins each receiving OP to the EF that serves it, and follows those relationships recursively.

For photographs, visible subjects, surrounding folders, related images, and camera filename sequences can supply meaningful context without an explicit user-provided purpose. In a couple-at-the-Eiffel-Tower photograph the couple is defining and the tower supportive; a scenery photograph can also have a salient subject. Descriptions differentiate the actual images. The [artifact and photograph clarification](semantics/artifacts-and-functional-intake.md) records the contextual examples.

#### Semantic term preservation

Defined semantic terms are operative semantic content. The system must preserve established terms verbatim. It must not paraphrase, rewrite, normalize, synonym-substitute, rename, collapse, or otherwise restate an established semantic term as a different term. This applies to Element-role names and to every other defined semantic term in Metaform.

New semantic records may be authored where the process calls for a new record, but an existing established term is not rewritten into alternate wording by intake, latent inference, similarity processing, storage, MCP presentation, workflow specialization, or another system layer.

### 3. Type meaning through change

The semantic relationship defines what the Type means independently of its present implementation. This allows substantial changes in realization without treating current code, structure, or content as a frozen core that must be preserved.

The identity definition is semantic guidance for reasoning about the Type; it does not itself prescribe an approval gate, lifecycle, or runtime check.

### 4. No frozen implementation context

The represented type meaning allows operations to reason about alternative realizations without making the current realization the definition of the thing.

### 5. Strict typology

There is no taxonomy here. We have an ontology in the form of a functional
typology: functional Types only. Language, as in the language it is written
in, is not a functional aspect; it is a method of defining functionality. Genre, such as comedy, is not function; enumerated function and
property categories are banned. Taxonomies have domain and class; they will not
work in our system. Those are padding meant to enforce N levels. We do not have
N levels; we narrow as needed.

The dotted functional namespace is a **typology**, not a taxonomy. Its existing
trunks are `code`, `document`, `media`, and `data`. The additional `exterior`
trunk has the project-boundary meaning and naming exception described
above. Decided 2026-09-13 (plan unit 3): the four trunks are reusable positions
known to every intake. They are seeded once into the global registry from
`data/bases.json` with their universal description and EF (a portable copy
keeps the store it carried and a run takes the bases from the shipped file
instead), every intake run references them, the assignment carries them as reusable Types, and the
expansion reuses them, so no project ever authors `code` or `document` again
with an empty EF. Their intermediate positions, `code.loop` for instance, stay
the project's with an empty EF until deep intake speaks to them.

For a valid functional Type path `a.b.c`, its prefixes express meaningful Types:

- `a`
- `a.b`
- `a.b.c`

No `domain.class.type` alignment layer exists. A segment belongs because the path speaks to a valid Function or Encounter sprung from its parent, not because a class label makes a hierarchy look regular.

Function expresses operative capability. Encounter expresses how a Function/type is encountered or realized, including variants such as programming language, style, genre, and similar forms. Encoding alone does not qualify as a type; an encoding name may appear where the path is actually expressing a Function, such as an encoder.

Artifact Types classify and organize the Namespace. The Elements are described through their functions, properties, and receiving purposes in the artifact being examined.

The v2 foundation stores Types and Elements separately. A Type has its
canonical namespace ID, owner, universal `description`, single `ef`, `length`,
aliases and optional presentation. An Element has its own ID, owner, name,
freeform description and artifact reference. Several Elements may share a Type;
one Element may realize several Types through explicit bindings. A binding can
retain the contextual realization of that Type EF.

An OP join records `receiver`, `purpose`, `provider`, `provider_type` and `role`.
The role is `property` or `requirement`; `classification` records its category,
`is_soft` records its softness, and `signal` describes how
the purpose is satisfied. The provider Type supplies the universal EF. When the
provider is an Element, its binding establishes that facet. Type-level clauses and
Element witnesses remain separately inspectable. Classification creates no OP join.

The v1 adapter recognizes `metaform:element` as a Type and
`metaform:actual-element` as an Element, derives bindings from `type_ids`, and maps
`object_id` to receiver and `element_id` to provider. It retains original source
payloads and observations. A missing or ambiguous facet is diagnosed; it is not
filled from the first item in a Type array.

### 6. Typology path and linked properties

The dotted functional path carries meaning through its independently promptable
prefixes. Place the Type at the most general accurate position, then link other
relevant Namespace Elements through OP joins that express their use.

The [agreed Name rule](rulebook/element/name.md#concise-form) defines construction
and extraction. It is reproduced here verbatim:

> The Namespace narrows in specificity as it extends. Use the Type’s most common universal name, expressed as a singular proper noun, and reverse its words into period-separated components.
>
> Locate the position in the existing Namespace that speaks to the Element at its most general specificity. This position may occur within a more specific path. Reuse the components through that position, then append the remaining modifier components that identify the Element in its full specificity.
>
> Record the number of words in the full name as `length`, including reused components. Extract the proper name by reversing the final `length` Namespace components and joining them with spaces.

Given `code.system.driver.video`, Network Driver attaches at
`code.system.driver.network` with `length: 2`. The existing `driver` component
counts toward the name. Semantic placement selects the shared general position;
the final path's name is recoverable from Namespace and `length`.

This determines the Type name from its namespace. The v1 adapter retains explicit
root and exterior display labels such as `code` / Program Code and preserves
authored spellings in source history. Element names retain their recorded artifact-specific wording.

An Encounter does not have to be appended to the Type's dotted path. It can be linked as a property/relationship to the relevant type. For example an installer Type may be linked to `code.bash`, while a game-engine Type may be linked to `code.cpp`.

Project-local linked properties remain project-local. Their presence does not automatically promote them to global type knowledge.

### 7. Encounter propagation

A property applies through its joins. Its effect is transitive through functional Type structure in two distinct senses:

1. **Backward visibility:** a property linked deeper in a branch flows backward toward the Defining Element or trunk and is available when reasoning at broader ancestor Types.
2. **Forward application:** from its attachment point, the property conditions inference through the named, more-specific Elements of that branch.

Backward visibility does not cause an Encounter to fan back down unrelated sibling branches.

Example:

```text
code
├── installer            ↳ code.bash
└── game
    └── engine           ↳ code.cpp
        ├── renderer
        └── physics
```

Expected reasoning scope:

- `code` can reason with both Bash and C++ as Encounters present in its functional descendants;
- `installer` and its functional descendants reason through Bash;
- `game`, `engine`, `renderer`, and `physics` reason through C++ where that Encounter applies;
- `installer` does not inherit C++ merely because C++ is visible at `code`;
- `renderer` does not inherit Bash merely because Bash is visible at `code`.

### 8. One foundation and outside-in knowledge

The **Native Metaform**, also called the Contextual Metaform, records the actual
artifact's functional understanding. It is the project's **Inference Metaform**.
Initial intake completes with that foundation. Latent reasoning can be requested
at any time using everything the Native account recorded, while remaining blind
to the repository implementation.

The outside role attaches a report layer. A finding can refer to an Element, Type,
join or region and propose missing understanding. The report retains its own
request, schema, context and provenance. It does not replace the foundation or
publish proposed contracts as Elements.

Knowledge layers support arbitrary semantic requests and registered payload
schemas. Their generating recipes retain exact source/rendered prompts, selected
components and schema snapshots, dependencies and resolved selectors. Knowledge
can originate in a layer and reach an Element through a Type binding; these are
independent origin and applicability axes.

**Knowledge Tool** (`knowledge.preview`, `knowledge.start`) creates a named knowledge layer from a user-supplied instruction. It appends `for` and the recorded functional context to the unchanged instruction. Names come from recorded Element names and the Type's `length`-aware, leaf-backward naming rule.

Each recorded Type receives one reusable base question. An Element's recorded Type facet supplies that base rather than generating a duplicate Element question; an Element without a recorded binding retains its own base. A context with properties receives one additional question for its complete property-qualified composite. Properties are grouped by their originating components: for example, `the top 3 best practices for program code` and `the top 3 best practices for repository program code that is part bash installer, and part cxx23 game engine`. When the Element and Type views describe the same recorded composite, the composite is asked once. Joins and participant roles provide context; they are not separate inference targets. There is no property powerset.

The worker receives the Native functional account once, plus each question's exact definition, component, property-origin and relationship references. Encounter Functions, Receiving Entities and Operative Purposes retain their recorded conjunctions. A backward property summary retains its origin and does not pool properties across unrelated exterior receivers.

`knowledge.preview` returns the rendered questions and answer schema without inference. `knowledge.start` asks for a layer name when missing and otherwise issues a fresh-context assignment. The agent returns one string array per question (`q1_array`, `q2_array`, and so on). The runtime attaches each array to its predetermined base or composite, retaining the literal request, question, related references, semantic dependencies and generation history. Array lengths follow the requested instruction; the transport schema does not impose a fixed answer count.

Generic Type knowledge depends on the supplied Type definition. A composite answer depends on its relevant Elements, Types, OP joins and property/component membership. Replacing the Bash/C++ components with a JavaScript game engine retires the old composite answer and reruns the same saved instruction for the new context; an unchanged Program-code definition retains its generic answer. Added properties are membership changes even when every previously read record remains unchanged. Produced knowledge attachment references are returned and inspectable.

**Best Practices** is the default use of this same module with the instruction
`Write 3 best practices`. After intake, the user-facing concierge follows the
returned action to generate it and selects it as the model's default layer.
Incoming agents periodically run latent-space blind-spot analysis during their
work. Other instructions, such as creative imperatives, use the same
Knowledge Tool contract.

Historical v1 Native and Latent graphs remain independently readable. Their
`01`/`10`/`11` shape comparisons express source-specific structural presence, not
confidence, truth or semantic reconciliation. Migration retains those inputs
without promoting old archaeology proposals into the current foundation.

### 9. Inference amortization

The Metaform stores reusable semantic understanding, not a catalog of completed task answers. The prompt/workflow and Metaform remain separable: a prompt describes an operation; the Metaform supplies previously inferred project/type meaning through which that operation is interpreted.

Prompt rendering is a runtime responsibility. For workflows and their subagents,
Metaform deterministically combines the authored instruction with its recorded
context and stores the exact rendered assignment. The nonce identifies that
assignment for delivery to the executing agent. The orchestrator routes and
continues the work; it does not paraphrase, redesign or replace the stored
prompt during handoff.

The chassis owns task and nonce registration, creation of `.agentid/nonce`,
assignment-scoped commands including answer submission, workfolder preparation,
and cleanup. Modules supply their operation's inputs, rendered questions and
result mapping and reuse that lifecycle. Knowledge Tool is a minimal
example of this boundary.

Which menu options are available depends on entering a nonce. Entering a nonce
changes the CLI: only those CLI commands are available through the entrypoint,
and the menu options shown depend on the nonce. Only when the working folder is
the main folder of the project does it show the main menu. Single-instruction
operations related to performing a task do not need to write the nonce file. It
is only used when you give an agent a worktree or a dedicated working folder and
tell that agent to run `metaform begin <nonce>`. Metaform then tracks their
progress in the workflow they are assigned when it is step-wise; that is how the
system ingests, orchestrates and tracks agents and what step of their task they
are on. When they pick done it cleans up the nonce.

This permits general instructions such as:

- examine outside-report findings for project usefulness or existing coverage;
- generate type-specific best practices or execution imperatives for every relevant Element;
- change an implementation Encounter and derive porting imperatives across affected functional types;
- evaluate a proposed refactor through connected Elements and their reciprocal Operative Purposes.

These are examples of open-ended operations, not a mandatory workflow library.

**Nonce mechanics.** Stated declaratively.

- A workflow receives a workflow nonce when it is registered. Editing the
  definition issues a new workflow nonce; the recorded assignments made under
  the earlier one keep it.
- An agent receives an agent nonce when it is assigned to a workflow. The
  agent nonce is eight characters, derived by hashing the workflow nonce with a
  random input, and checked unique among issued nonces. Issuing it records the
  assignment: this agent, this workflow. The agent nonce therefore identifies
  both the agent and the workflow it is assigned to.
- `metaform begin <agent nonce>` starts the workflow for that agent. Through
  the CLI, `begin` writes the agent nonce into the working folder's
  `.agentid/nonce`; later CLI calls from that folder find it, identify the
  agent, and deliver the current step; completion cleans it up. Decided
  2026-09-12: the on-disk marker goes; `begin` records the working folder and
  its assignment in the base db, the CLI detects the working folder and reads
  that record, and `done` clears it. See section 13. Through the
  MCP server, which cannot see a working folder, the agent passes its nonce on
  every call, and the server delivers the same information the CLI would.
- The CLI and the MCP server construct identical deliveries from the same
  nonce: the current step, its handoff, the appended imperatives, and the
  knowledge routed to it, resolved through the routing entries in the joins at
  the workflow's target.
- The orchestrator menu doesn't need a nonce when operating from the main
  folder of a registered project. Otherwise it does.
- When a project is set, active sub folders are not allowed to activate the
  orchestration menu, nor is the tmp folder, nor is anyone in the middle of a
  workflow allowed to activate either or anything else; they need to abort the
  workflow. This is not really a security thing, so it is not treated as
  such; it is about orchestration, keeping things on track and not gaming the
  system. Single-prompt, single-step workflows just enter a nonce and it gives
  them the command; agents doing a single step can just run the command.
- It is not security, it is steering. For the agents this is simply a line
  in the sand, and they are not expected to cross it, especially when they are
  accessing it for an instructed purpose.
- When you run help, the system always shows a very base menu: if it is
  already in a project, the help for the `begin` command, and then adds onto
  it. For the orchestrator menu use `help orchestrate`; for the admin menu use
  `help admin`.
- Two words end contexts. `done` ends a delegated assignment or a
  provisioning session and cleans up its nonce. `complete` leaves the
  self-assigned admin menu and returns the agent to its own menu.
- Each delivered step names the exact address where its memories are
  accessed, so the agent reads and writes at that place and nowhere else.
- The agent nonce is known only to that agent's context. It is not a gaming
  surface. A CLI in a delegated folder presents only that assignment's
  surface; the orchestrator's surface exists only in the main working path
  and is never shown to a delegated agent.
- Any assignment to a subagent that is more than one step runs in a
  workfolder or worktree of its own. A single-prompt operation, intake
  included, runs against the main repository.

### 10. Coarse base shape and operation-specific depth

The Metaform's base semantic shape is intentionally coarse. It exists to put forward enough type knowledge and relationship structure to reason on, not to enumerate all possible facts about an artifact or to reproduce the implementation at another abstraction layer.

Later operations may select deeper connected Elements, properties, and relationships when the operation needs them. That additional depth is task-driven and open-ended; it is not required in order to mechanically police Type identity.

The act of doing an intake that encodes the rest of that is called deep
intake. Coarse intake produces the base shape from glossary terms only; deep
intake is the act that encodes the rest, and it can be selectively performed if
wanted. The reason we do not encode that other stuff is that it breaks
mutation. Mutation is the freedom to explore in those other vectors. Functional Types
only means no Encounters; shallow intake does not include the Receiving Entity
for the Defining Element. There is no exterior consideration in terms of what
we provide to anyone out of the system, and we talk about our requirements,
the ones we have Operative Purposes for, as a single Element: `code.engine.game`,
yes; `code.engine.game.platformer`, no.

Elements are entities; the Receiving Entity refers to Elements. Intake remains
its Type-only functional surface: no genre, no flavor, no specifics, period.
That functional surface is what the latent space reasons on for finding blind
spots; blind-spot analysis finishes and comes back with proposed functional
surfaces. Functional surface means no style, no language, no encoding, none of
those kinds of specifics. Intake gets too granular when it is handed those
options by being given a place to describe something in that way; all of that
is removed, and the base shape drops back to the glossary terms only. The word
Element is for prompting as an archaeologist trying to understand what the repo
is; it abstracts all the way back: `code.loop.main` has a function; when it
relies on an external framework, that framework is a function, `code.engine`,
and its Type is `code.engine.game`, not `game.pong`. It cannot be an engine
when no engine is used: a single-file pong clock uses no Box2D and no Unreal,
so it has no engine entity. Pong clock is `code.loop.game`, `code.loop.game.controls.ai`,
`code.loop.clock`, `code.loop.game.display`, `code.loop.logic`: five entities.
There is no raw controls Type, because you cannot control it. Game is a function and not a genre because it is what the
engine we are using is; if there were such a thing as a platformer engine and
we were using that and not a game engine, then it would be a function, but
just being 2D does not make it a function. `code.controls.game`, Game Controls,
is a function Type: the major Type that defines that function.
`media.asset.sprite` is a functional Type; `data.configuration` is a
functional Type.

The Inference Metaform exists as a layer that speaks to the project at its
functional Type level; that is what coarse intake is. Once you go past that and
start speaking to this project, you are naming things in the Inference Metaform
as that Type in this project. The Inference Metaform is the meta, the higher
order of understanding, and the Form, the shape of the project. For prompting it
is like meta prompts, but the meta part comes from the Metaform itself: the
prompt or workflow being processed talks very specifically to this project, is
ingested as a workflow, and works very similarly to prompt-chaining operations.
The orchestrating agent can build the prompt chain and run it to improve the
project itself.

### 11. Local refinement and regenerated variants

A requested expansion selects an Element, Type, namespace branch, join or bounded
region and supplies the purpose for deeper understanding. New detail retains
existing Element IDs and relates finer Elements through explicit refinement records.
A correction identifies the prior meaning, changed meaning and reason. Expansion
opportunities are addressable questions, not an automatically scheduled census.

A variant derives a destination foundation revision from a recorded source.
Changing an engine's C++ realization to JavaScript replaces the applicable
binding or property relationship in that region. It does not turn `code.cpp`
into a global alias for `code.javascript`, or alter an unrelated installer.
Meaning-preserving namespace relocation updates structured references and records
aliases. A changed direct parent requires an authored narrowing explanation.

Layer impact examines record and selector dependencies, including new or absent
context and dependencies through other generated knowledge. Unaffected knowledge
can be preserved; affected generated knowledge is reconsidered, invalidated or
regenerated by repeating its original semantic request against destination
Types and joins. Independently authored knowledge keeps its ownership.

Foundation revisions are immutable. Structural hashes exclude presentation and
execution metadata; layer revisions are independent. The existing service and
portable stores retain the journal, recipes, answers and source history.
Conflicting writes identify the competing records. Draft schema and reference
issues remain annotations; missing semantic information is not invented to make
the record pass a validator.

### 12. Chassis customization and built-in guidance

The chassis has its own built-in Metaform containing explicit instructions for
building modules, importing workflows, and using its interfaces. The concierge
can consult this Metaform; it is omitted from the web viewer and is not removable
through user operations.

Users can build and share self-contained module folders. Installing a shared
folder in a module location registers its declared abilities. The Metaform skill
supplies the concierge with a deterministic catalog drawn from registered module
descriptions and available commands, including community modules. When a module
loads it is listed in the skill page. The skill itself is just the base Metaform
information and the instruction to run `metaform skill` to see what workflows,
modules and everything else are available.

Customization reads and changes data through the public Metaform interface.
The chassis retains control of storage and execution; module and agent operations
use that interface instead of accessing the underlying data directly. Built-in
guidance teaches this same contract.

Everything in the chassis has help at this level: for each feature, one menu
option that displays help text on what needs to be done to use that feature.
Features, hooks, and whatever is added in the future are described this way, so
every agent knows how to administer them now and from this point forward. If the
agent cannot or does not want to, it moves ahead.

### 13. Project-aware startup and onboarding

MCP initialization supplies instructions rendered from the selected project's
current state. Project selection and guidance reads refresh that context. The
concierge selects the actual working project, starts or reuses the web interface,
and tells the user its URL. An uninitialized project is onboarded from an existing
repository or a supplied plan. A plan describes the design being onboarded; the
plan document is not itself the subject of that intake.

Onboarding continues through intake, Best Practices generation and selection of
the default knowledge layer. Completed projects report their existing models,
layers and registered abilities. A user's subsequent layer selection is retained
per model, including an explicit choice to show all layers. Explicit per-request
layer selections override that default.

New repository intakes retain a source-file baseline. Startup instructions report
source-file counts before and now, additions, modifications, deletions, and net
growth. The changed percentage is the changed, added and deleted path count
divided by the union of baseline and current source paths. The main agent relays
these statistics; the user decides whether to request an update. Plan-based or
older intakes without a repository baseline report that comparison data is
unavailable.

Whenever the CLI is run and its parent process is not familiar, it says: "We've
detected this is the first time running metaform. Please use these menu options
to provision each feature your harness supports. When you have configured every
feature you support use done to finish." Every harness runs from its own install
subfolder, so familiarity is based on the parent folder of the harness binary,
recorded in `provisioning.json` so it stops asking; paths under `/tmp` are
ignored. This is how foreign harnesses onboard. It does not hurt if the other
agents see this as well; once the agent says done it will not nag them any more.

Finding the project and tracking it, Rich's words of 2026-09-12. When a
project is registered, why should it walk? Walking should stop before `~`,
one level deeper. More than that, onboarding a project should make it aware
you are in a path of that project. The main agent should set an active
project. Project tracking lives in the base db: it needs to track the working
folder and the last project from that working folder; different working
folders, different contexts. When not operating from that working directory,
checking out the project tracks you as the orchestrator of a folder you are
not working from; checking out the project recognizes you as the
orchestrator. You do not need on-disk nonces if the CLI detects working
folders; that is cleaner, if it can check the db. A nonce without any
activity for 24 hours is no longer good; no nonce-failed message, it just
acts like there is no nonce. Walking is a last resort. Agreed the same day:
reads of the base db are direct and read-only and never start the service.

The knowledge service, Rich's requirements of 2026-09-12: one port; a
consistent command to start it; a start and a stop command; single process;
proper process management; no init system; none of this blank page, pick a
project on launch; a link you can make once that works because it is
running. How it works is Rich's to lay out; it is not yet recorded.
Decided 2026-09-13: the command is `metaform web`, never `browse`; it starts
the service on the one configured port (`web_port` in the home config, default
8642) when it is not up and opens the current project; `web stop` and
`web status` are the other two words; the root of the page lands on the
project opened most recently and the chooser moves to `/projects`; every
chassis subprocess starts Python with `-P` so a project folder that holds a
`types.py` can never shadow the standard library. The projects page at `/projects` marks a project whose
folder is gone and offers Forget on every entry, and `metaform project forget
--path <folder>` or `--missing` does the same from the CLI: the registration
and the catalog entry go, the folder and its knowledge stay. Clear project in the page header, and `metaform project clear` on the
CLI, clears the project's Metaform data so intake starts from nothing: every
model, run, layer, assignment and binding of the project goes; the folder, its
files and its registration stay; it is not offered inside a delegated
assignment.

### 14. Contextual help and menus

This is all a chassis feature. It is the main job of the chassis: the nonce
contexts, the menus they scope, the status at the top, the contextual help, and
provisioning. Modules do not own any of it; they supply their operations into it.
Modules that load dynamically are how Metaform builds its own features: its own
modules load the same way as shared and community modules, and what a menu
offers, and the help behind each option, comes from the modules that are loaded.
The whole system works this way whether Metaform is installed or is still in its
wheel form. When you run Metaform from the wheel it uses the same data files as
the installed copy, and it refuses to run if the installed copy is out of date;
if there is no installed copy it works just the same.

Our goal is to produce something useful that these sites can execute and
directly use without further explanation: a Metaform bundle that can be
uploaded and operated via the common sandboxed execution environments that
exist in the websites of AI tools, where nothing can be installed, based on
what exists or by what we bundle in directly, while maintaining compatibility. Third-party
stuff enters our view when developing it would hinder the project, its benefit
is too great to ignore, and its licensing doesn't lead to any perceivable
limits in our own project. We are for any third-party stuff that is assistive
in this project or limits development overhead; the test should be: is this an
industry standard that is non-proprietary or used elsewhere in the AI space for
similar purposes, with a license that doesn't bind this project into a bad
position. If Flask requires Jinja, we should use it. This baseline only applies
to the bundle which is uploaded to the execution environment itself, not as a
requirement for the project's more advanced local execution shape. The bundle
serves as a dual-purpose packet which can be used to deliver workload to other
harnesses by hand, or dynamically in a command-and-control fashion where they
may not share filesystems, observing that the base Metaform tooling is
installed already. This is not about storage joins; it is the minimally
intrusive method of sending and receiving work, or deploying Metaform to remote
systems, where auth can return completed steps in a workflow. This is not an
MVP requirement, and should only be observed as a beneficial foundational
consideration once the MVP is working. It is also critical to note that this
describes a loadable module in the chassis, so the goal is for the chassis to
support this shape, which it should already, as designed. This describes a
deterministic, AI-harness-independent capability driven by a workflow.

This system must be presented as a cohesively engineered product, not the
result of endless exploration with retained and defunct cruft.

These operations can't be gated. The instructions are an attempt to get back
the shape we need, not to gate the output; doing so violates the very core of
the system and its prohibitions. We must observe the failure and refine the
approach. There is no gating allowed on inference, period: no loops, no
retries, no failures. The answer is the opinion of the model in use; there is
no wrong answer. We drive the model to the answer the system can use, but we do
not gate it. The schema defines the shape, and making the answer fit is the
only requirement.
You can't create a gate without naming the silent, unobservable failure, and
the goal is to allow the failure to be observed and fixed.

Compatibility floor as of 2026-09-12, from Anthropic's published code
execution inventory intersected with the scraped OpenAI code interpreter
inventory: Python 3.11 on Linux x86-64, stateful execution, local file access,
no outbound network, and these preinstalled packages: numpy, pandas, scipy,
scikit-learn, statsmodels, matplotlib, seaborn, openpyxl, xlsxwriter, Pillow,
python-docx, python-pptx, pdfplumber, pdf2image, pdfkit, reportlab, sympy,
mpmath, joblib, python-dateutil, pytz, tqdm. Jinja2 is present in the OpenAI
inventory and in an audit of the Claude Skills sandbox but not in Anthropic's
published code execution inventory, so the bundle carries it. Sources:
https://platform.claude.com/docs/en/agents-and-tools/tool-use/code-execution-tool
and https://github.com/simonw/scrape-openai-code-interpreter/blob/main/packages.txt

The runtime checks every answer against its schema with a checker of its own
(`schemas.check`), which covers the subset the shipped schemas use: type with
null unions, properties, required, items, additionalProperties, `$ref` to local
pointers and registry ids, `$defs`, enum, const, minimum, maximum, minItems,
maxItems, minLength, pattern, oneOf, anyOf, allOf, if/then. It reports the same
findings jsonschema would, with the same wording for the common ones, and it
never raises on an answer. jsonschema is a development dependency only, held to
parity by one test; the standalone carries no validator line and no compiled
wheel, so it runs on the floor's bare Python and on Windows alike. Decided
2026-09-13, replacing the carried floor line of the same morning.

`metaform -h` or `--help` is not a normal help menu. It only shows contextual
help. At the top of the menu is a status section: is this a project, is this a
worktree, your job id (the nonce), the step of the process you are on, and so
on. This is for onboarding. Everything, every menu, is only for the stuff that
needs to be done. For the orchestrating agent in the home folder it is
instructions based precisely on orchestrating and what it can do: provisioning,
listing workflows, doing intake.

The menu the user gets is the main admin menu. If the orchestrating agent wants
access to it, it can assign itself the main admin menu: begin the nonce, and
when it is done say complete and get back to its specific menu for its specific
job.

All output of the Metaform CLI outputs status, even if no project is selected;
it says that up top, with a separator. Agreed on 2026-09-12: the header is the
status lines, then a line of dashes, then the body. When nothing selects a
project the status reads `Project: none selected`, and the working folder is
not taken as a project of its own. Command results stay bare in both forms: a
result is the answer to the command, and the header on help already said where
you are. Errors name the project on the error, as a line above the error text
and as a `project` field in the JSON form; when no project is selected the
error says that in the same place.

Two audiences. For an AI harness, the form of the interface is whatever is
best for the model, for automation, and for the AI: status first, a separator,
then only the commands that apply in this context, each printed as a line that
runs exactly as shown with one line of purpose, and JSON on request as one
object. For a user not in a harness, the help mirrors the exact style of
Claude Code, Codex and every other AI tool: Usage, a one-line description,
Arguments, Options, Commands, in aligned two-column blocks, under the same
status header. It lists modules, runs a module to test it, has an admin
module, a TUI status monitor, and the commands an AI uses to remote deploy the
system, as normal CLI commands. The CLI prints the human page when standard
output is a terminal and the AI form when it is a pipe or the folder is bound
to an assignment; `--human` and `--json` override, as today. The command
names `modules`, `run <module>`, `admin`, `status` and `deploy` were kept on
2026-09-12.

### 15. Provenance, prompt objects, and porting through medium change

This section is written in the declarative register of a requirement. It
states the structure of the functionality so that it needs no clarification.

**Provenance.**

- Every record the system produces has one producer: an intake activity, a
  workflow step, or a layer generation.
- A producer record holds the prompt revision it issued; the rendered prompt;
  the binding map, which pairs each variable in the prompt with the value it
  received and, where that value is a record, the record's ref and revision;
  the inputs it read, meaning source evidence, referenced Types and region
  records, at the revision read; and the answer it received, recorded whatever
  its shape.
- Provenance is one read. Given any ref, whether Type, Element, join,
  knowledge item or step answer, it returns the producer, the prompt as
  constructed, the binding map, and the refs bound. Each bound ref is readable
  the same way. The chain ends at source evidence and at authored prompt text.
- The interface shows provenance on any record: select the record to see its
  producer; select a bound variable to see what produced it. Hovering a
  variable shows its binding and its producer.

**Prompt objects.**

- A workflow definition is a document. A step's prompt is the seven sections:
  Purpose, Core Concepts, Namespace Rules, Method, Goal, Constraints,
  Completion Condition. A variable inside a section is a reference to an
  input, a prior step's answer, or a record by ref. It is stored as a
  reference, never as substituted text.
- Rendering substitutes values when the assignment is issued. The issued
  assignment records the rendered text and the binding map together.
- A single-operation prompt, intake included, is a one-step definition. One
  editor serves single steps and chains.
- The editor presents a prompt as its sections, with variables as selectable
  objects. A variable is added inline by selecting a record, an input, or a
  prior step's answer. Editing a prompt produces a new prompt revision and a
  new definition revision. A run records the definition revision it used.
  Re-running from an edited step replays the definition, reusing the recorded
  answers before that step and issuing new assignments from it onward.

**Medium scope.**

- A knowledge item is attached to its subjects, which are namespace places.
  Its generation records every ref that was in its prompt, at the revision
  read. That record is the item's recipe.
- A medium, such as a language or an encoding, is recorded by deep intake as
  a property join to a Type. Property joins are transitive: the property
  applies to every Type forward from that position to the trunk and to the
  dictionary in the join. The set of Types a property applies to is its
  applicability set. The system computes it from the joins and narrowings; it
  is never authored.
- A knowledge item is medium-conditioned when any ref in its recipe is in the
  medium property's applicability set or is the property join itself. The
  system computes the medium-conditioned set.
- The coarse base shape is free of medium, genre and style by the intake
  rules, so no base-shape record is medium-conditioned. This is what makes the
  base shape and every item outside the medium's scope reusable for every
  language without re-inference.

**Memory nodes and the routing dictionary.**

- A join is owned by its receiver and holds a dictionary. Its entries are
  memory nodes: the entities intake reasoned in the namespace and annealed
  into the adjacent join instead of making them elements of the base shape.
  Intake seeds each memory node with a relation in active voice and an
  observation as an atomic fact, and the prompt requires this dictionary
  wherever elements were combined away.
- Intake lists the subtypes it annealed away as `subtypes`, each a full
  namespace address beneath the element it was combined into. They are held
  as detected inactive subtypes beneath their main Type: reserved in the
  namespace, never Types or Elements of the base shape, valid for memories
  to attach to and for addresses to name. Their dependencies belong to the
  main Type. The explorer shows them beneath their parent as inactive.
- A memory node's key is a full namespace address in its own right, for
  example `code.engine.game.fps` annealed beneath `code.engine.game`. Memory
  node addresses are reserved in the namespace the way alias names are:
  cached, and a competing Type at that address is a recorded collision. An
  address resolves directly, so a call or a route can name it.
- Aliases reserve names the same way, at their own position: `code.cpp` may
  carry the alias `cxx`, and beneath it `cpp23` may be an alias for `cxx23`.
  Parametric elements are not an acceptance target now.
- The dictionary is a programmable surface: entries are typed, and types are
  built as needed. A workflow can exist as an entry in a receiving entity's
  dictionary. A step entry carries a workflow step, its handoff, and the
  appended imperatives; a multi-select on the step attaches the extra
  information delivered with it. The best-practices layer is included on
  every step by default.
- A knowledge layer carries an include flag set when it is created. The
  orchestrator can turn a layer off. The Knowledge Tool instructs the
  orchestrator on this and tells it to spot-check whether the knowledge
  improves the workflow before relying on it.
- Reading the knowledge graph at an address returns all past inference there
  and lets the agent create, read, update and delete its own memories; that
  read does not process routing entries and does not present workflow layers.

- The memory node surface is enumerated and cached. Each published revision
  indexes every memory node address to its join, its receiver and its typed
  entries, once, alongside the Type and Element indexes, and the index is
  keyed by the revision so it is never rebuilt for the same revision. Target
  resolution, reservation checks, knowledge reads at an address and nonce
  deliveries all read that index; none of them walks the joins on demand.

**Porting through medium change, the concrete form of CAP-12.**

1. Clone the foundation and its layers into a variant. The base retains
   everything it had.
2. In the variant, replace the medium property join with the target medium,
   for example `code.cpp.cxx23` to `code.csharp`. The applicability set is
   recomputed from the replaced join.
3. Create the target-medium layer. One authored operation prompt in the seven
   sections produces it. Its variables are the source medium, the target
   medium, the base shape, and each workflow previously specialized to this
   project. It asks for what an expert advises be considered during this port,
   attached to the places in the replaced property's scope. This layer is a
   metaprompt input to workflow specialization: specialization lexicalizes a
   workflow to this project with the target-medium layer applicable.
4. Queue re-inference. Every medium-conditioned item in the variant is queued.
   A queue entry holds the item; the recipe ref and the property that put it
   in scope; and the reissued prompt as constructed, which is the original
   prompt revision with its bindings resolved against the variant and the
   target-medium layer applicable. The entry is visible and editable before
   it runs.
5. Run the queue. Each reissued answer is recorded whatever its shape. The
   original item stays in the variant, marked superseded by the port and
   linked to its replacement, and stays unchanged in the base. Items that are
   not medium-conditioned carry into the variant unchanged.
6. Bind the variant to the port's branch or repository as its project intake
   and run inference amortization there, so later prompts and workflows for
   the port begin from the variant's account.

Optionally, a workflow previously specialized to the project is regenerated
under the target medium and run in full in the variant.

Nothing in this sequence gates. A queue entry runs once, its answer is
recorded, and a wrong shape is observed and refined, never retried by the
system. This is inference amortization in its literal form: inference free of
medium, genre and style is captured once, and only the medium-conditioned part
is re-derived.

## Non-goals

- Reproduce the implementation as an exhaustive semantic graph.
- Preserve the present implementation shape as a proxy for identity.
- Treat contextual/latent agreement as proof of truth or confidence.
- Replace subsequent inference with stored completed answers.
- Make every current chassis feature—workbench, MCP exposure, packaging, CI, image generation, history/export—a core semantic product requirement merely because it exists in the repository.

## Success signal

A prepared Metaform can take a short, general type-level instruction and produce correctly differentiated reasoning across a heterogeneous project according to each Element's relevant semantic relationships, while enabling substantial changes of realization and open-ended higher-order reasoning.

## Semantic sources

The accepted 2026-09-09 [Name rule](rulebook/element/name.md#concise-form) and
[receiving-purpose and variant clarification](semantics/names-receivers-and-variants.md)
record the latest design decisions. Earlier supplied Name, Description,
typology, and Aliases equations are preserved in
[Inference Metaform Rules](semantics/inference_metaform_rules.md). The
[Aliases section](semantics/inference_metaform_rules.md#aliases) is bundled verbatim
for intake; `semantic_sources.aliases` can select an explicit source override.
The [glossary](../src/metaform/data/semantics/glossary.md) supplies the established
Element-role definitions. [Semantic Equation Preservation and Reuse](semantics/semantic_equation_reuse_rule.md)
defines how authored semantic equations are carried into later inference.

## Implementation and remaining demonstrations

The current [architecture](architecture.md) and [workflow contract](workflows.md)
describe the implemented facade, shared reads and Engine-backed operations.
[Current work](current-work.md) distinguishes ongoing integration from completed
checks. Matched live prompt trials and artifact-specific task evaluation remain
necessary to assess inference quality and usefulness; schema conformance and
fixture execution establish only their exercised behavior.

## Acceptance scenarios

These scenarios define semantic demonstrations for the contract. They are intentionally independent of the current implementation and test suite.

### A-1 — Strict typology rejects class filler

Given proposed types:

- `code.cpp`
- `code.language.cpp`
- `code.game.platformer`
- `code.game.genre.platformer`

The typing operation accepts `code.cpp` and `code.game.platformer` when those paths speak to valid Encounters, and rejects the class-filler forms `code.language.cpp` and `code.game.genre.platformer`.

The reason must be semantic qualification of each path segment, not a hard-coded blacklist of the words `language` or `genre`.

### A-2 — Encoding name is judged by what the path expresses

Given:

- `document.html` where HTML is used only as document encoding;
- `code.html` where HTML is being treated as a language Encounter;
- `code.encoder.jpg` where JPG participates in an encoding Function;

The first fails type qualification, while the latter two can qualify because their paths speak to Encounter or Function rather than expressing an encoding as the Type.

### A-3 — Established semantic terms remain verbatim

Given an established semantic source containing terms such as **Receiving Entity**, **Operative Purpose**, **Encounter Function**, **Defining Element**, **Parametric Element**, or **Stylistic Element**, pass that material through intake, latent inference, storage, MCP retrieval, similarity processing, or workflow specialization.

Expected:

- the established term remains exactly the established term;
- no layer replaces it with a synonym, paraphrase, normalized label, alternate role name, or taxonomy-oriented class name.

### A-4 — Outside analysis preserves the foundation

Supply the complete Native functional account to the outside role while keeping
implementation files outside its context. The resulting report can agree,
question or identify omissions. Its findings are addressable knowledge with
source and target references. The foundation's Element IDs, OP joins and
structural hash remain unchanged until a structural correction is explicitly
applied. Retained v1 source graphs remain accessible as historical evidence.

### A-5 — Encounter propagation respects branch scope

Given:

```text
code
├── installer            ↳ code.bash
└── game
    └── engine           ↳ code.cpp
        ├── renderer
        └── physics
```

Expected:

- reasoning at `code` can account for both Bash and C++;
- `installer` and its functional descendants are conditioned by Bash;
- `game`, `engine`, `renderer`, and `physics` are conditioned by C++ where applicable;
- Bash does not flow into the game/engine branch merely because it is visible at `code`;
- C++ does not flow into the installer branch merely because it is visible at `code`.

### A-6 — Knowledge Tool preserves base and whole-composite knowledge

Given an explicitly recorded Program-code Type, repository Element, Bash installer and cxx23 game engine, supply `the top 3 best practices` and a layer name.

Expected:

- the selected repository context renders `the top 3 best practices for program code` and `the top 3 best practices for repository program code that is part bash installer, and part cxx23 game engine`;
- each property remains associated with its originating component; installer and engine contexts receive their own properties;
- generic Type bases and native composites remain distinct, while equivalent Element/Type views share the same question;
- no incoming/outgoing, participant-only or standalone join questions are generated;
- the assigned agent receives the exact questions, complete functional account once, and the references resolving each context;
- submitted answer arrays are stored at their predetermined subjects and stable slots, with the saved instruction, related references and per-question dependencies;
- replacing the two language/component contexts with a JavaScript game engine retires the old composite answer, preserves unchanged generic Program-code knowledge, and prepares the same instruction for the new composite;
- adding an applicable property also invalidates the prior composite through its membership dependency;
- regeneration and missing-answer recovery preserve the saved instruction and attachment mapping.

Repeat with `the top 6 creative thinking with foresight imperatives`. The instruction changes; construction, context, schema shape and attachment mapping remain the same. Neither the request text nor a numeric answer count is hardcoded.

### A-7 — Workflow specialization preserves authored behavior

Given a general workflow containing authored sequence, branches, and prompts, specialize it against a project Metaform.

Expected:

- general terms resolve to relevant Elements and relationships;
- source intent remains intact;
- existing control flow remains intact unless the source itself calls for a structural inference;
- no additional quality gates, preservation requirements, or hidden rounds appear merely because specialization occurred.

### A-8 — Refactor and porting reason through semantic structure

Given a type whose current realization uses one implementation Encounter, ask Metaform to reason about a substantial refactor or a port to another Encounter.

Expected:

- guidance is derived through the represented Functions, Encounters, Receiving Entities, Operative Purposes, and connected Elements relevant to the work;
- substantially different realizations can be considered through the same prepared semantic understanding;
- porting guidance can change with the target Encounter while remaining specific to each affected Element.

### A-9 — Common names reuse the appropriate Namespace position

Given `code.system.driver.video`, introduce Network Driver. Locate
`code.system.driver` and append `network` there, preserving Video Driver as a
sibling. Store `length: 2` and recover Network Driver from the final two
components. A name with a different word count is extracted using its own
`length`.

### A-10 — Exterior purpose participates in project understanding

Intake identifies the DE's exterior Receiving Entity and its OP for the DE's
EF. Retrieval of the receiver-owned OP join exposes that relationship
to subsequent reasoning about the artifact. The OP remains the receiver's.

### A-11 — Typed OPs preserve Medium and Dependency distinctions

Record `code.game` receiving `code.cpp` through a Property of type Medium and
receiving `code.game.rules` through a Dependency. Store, retrieve, and prepare
context from these relationships. Their purposes, typing, and EF providers
remain distinguishable.

### A-12 — A report finding becomes an explicit correction

An outside report identifies a non-issue and an oversight. Both findings retain
their source context. Applying the chosen correction creates a new Native
foundation revision with the changed records, reason and producing evidence.
Later work can select that revision; the original account and report remain
observable. A report alone does not mutate current Element structure.

### A-13 — A cloned variant regenerates affected understanding

Clone a Native game Metaform with a C++ Medium relationship and derived
knowledge linked to its producing prompts and semantic dependencies. Replace
the clone's Medium provider with `code.javascript`.

Expected:

- the base retains its C++ relationship and understanding;
- affected derived reasoning detaches from the variant's active understanding;
- unaffected knowledge remains available;
- the producing prompts are reissued against the variant's updated context;
- their results attach to the variant with new producing context;
- subsequent porting work uses reasoning specific to the changed Medium and
  affected functional Types.

Fixture verification of record handling is distinct from a live demonstration
of the regenerated reasoning's semantic suitability.
