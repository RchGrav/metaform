# Workbench brief

Recorded 2026-09-10 from Rich's statements. This is the definition the
workbench front end is rebuilt against. His wording is kept where he gave it.

## Definition

The workbench is a navigable simulacrum, presented graphically, of the MCP
server surface: a web-based simulation of the data shape the AI sees in the
MCP server, with additional dev capabilities to trace what is going on so the
user can see what the AI sees. It is also a job viewer: a graph version to see
the way the intake went, and the same for other jobs, such as a workflow viewer
so prompts can be edited.

The point of the interface is to have an intuitive interface for editing the
prompts and understanding the intake process, visualizing the data that is
collected, showing the stages of the intake procedure when a prompt is sent,
and the ability to refine the wording. It should be responsive so it can show
the process trace and the relationships. The user should be able to click a
button on the side to see the prompt that generated the data. The workbench
should know how to call Codex or Claude on its own.

## What the user is doing

A person on a desktop, observing and understanding intake results and browsing
the knowledge graph. Not an agent. Not a phone.

## Rules taken from the review of the current front end

- The namespace name is the name. `code.synthesizer.audio` reads backward as
  Audio Synthesizer; that is what the card says. The intake's summary is a
  subtitle at most.
- No kind labels on cards. Never "Element" or "actual Element" stamped on
  things. "Actual" is not a term for the screen.
- No ids or long strings in the view, and the actual data of any record must
  still be one click away. Removing ids must never remove the data.
- A property join's provider is a distinct thing, never the receiver itself.
  Three joins from a card to itself is a prompt defect, not a fact.
- Labels come off the arrows. Purposes are read in the inspector.
- Exterior cards only for real outside receivers and providers, such as the
  person who receives the clock.
- Intake is coarse typological intake, not a code trace. Sixteen objects for a
  single-file pong clock is too granular. The artifact's own name never enters
  a Type address (`code.clock.pong`, `code.simulator.pong` are wrong; pong is
  the thing bound to `code.clock`).
- Colors show where a join's effect applies to the thing joined, not the join
  itself.
- The graph holds still. No re-layout on panel toggles, no sliders that redraw
  per pixel, wheel zoom at normal speed. Clicks answer at once.
- No filler: no gesture hint lines, no footer legend written from the code's
  point of view, no over-labeling.
- Not the recognizable AI default look: no rounded-pill styling, no muted
  green palette. A palette the user approves from options shown on the real
  screen.
- Layers must be visible and browsable.
- Path entry fields and file browsers do not belong in the page. The system
  knows its paths.
- No delete-join buttons. Clearing the data and re-intaking is a project
  operation.
- Help is written for the person using the page, not for agents.

## Design that follows from the definition

Every panel is one MCP call and can flip to show the exact envelope the agent
receives for that call:

| Panel | Call |
| --- | --- |
| Stage banner | `guide.start` |
| Namespace tree | `namespace.browse` |
| Card | `element.inspect` |
| Arrow | `join.inspect` |
| Knowledge on a card, per selected layer | `knowledge.get`, `knowledge.explain` |
| Layer chooser | `layer.list`, `layer.select` |
| Job list and steps | `workflow.progress` and the run's retained assignments |
| Dev console | any tool, its input schema, its envelope |
| Initialization view | the instructions the agent receives on connect |

The job viewer shows any run as its steps: for each, the prompt as sent, what
the agent read, what it answered, and what that answer attached. Intake gets a
growing-graph replay on top, scrubbable step by step, filling in live while an
agent works. From any record, one control opens the assignment that produced
it and its prompt; editing the prompt and re-running shows the two results side
by side.

Driving Codex or Claude from the page is the same `drive` call the CLI makes.

## Acceptance

The check is the one Rich asked for: run an intake the normal way through the
workbench with a real agent, watch it, and judge the result. Passing unit tests
establish mechanics only.

## Order of work

0. Restore the intake semantics: revert the role and composition files to the
   settled roles (hard dependency, property, supportive), the actual-versus-Type
   wording, and the platformer example; remove the classification taxonomy,
   the path-entry landing page, the delete buttons, and per-edge classification
   coloring. Keep the concurrent session's mechanical repairs.
1. Speed: record the page's calls, cache the read snapshot per revision, stop
   re-layout on toggles, keep positions across selections.
2. Real information: the explorer as defined above.
3. Polish: palette options on the real screen, consistent controls, remove
   what does not work.
4. Help for the person, in the page and in `docs/workbench-navigation.md`.
5. Job viewer with intake replay; prompt editing from inside it.
