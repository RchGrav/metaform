# Relationship display correction and intake reset

Rich directed the previous collected data to be cleared rather than patched.
The example and its isolated global store now contain no collected Elements,
joins, completed inferences, runs, pending assignments, or responses. The
example's `handler.py` and `module.json` source files remain.

The workbench is available at <http://127.0.0.1:43679/> while its local server
is running; <http://127.0.0.1:43679/?view=list> opens the list presentation.
Both Graph and List show only Metaform data and are empty after reset.
Rules contains five refreshed seeds; Prompts contains nine refreshed seeds.
The handler and dispatcher examples explain comprehensive functional parents,
single-word Namespace components, and deterministic construction. The original
Name and Description concise statements remain intact.

Intake has not restarted. The next work is to agree on the collected Element
and OP record shape before collecting new data. OP ownership, provider-to-
receiver display, and purpose labels must be represented faithfully. The
renderer now displays unambiguous provider → receiver relationships directly,
with OP labels. It does not turn join records into Element nodes. This does not
validate the discarded records or finalize the intake/storage contract.

The status counts are recorded locally in `dist/mvp-review/reset-status.json`.


## Preserved explanations

[Developed understanding, receiving relationships, and work](semantics/understanding-and-work.md)
contains Rich's exact statements, separately marked interpretation, and links to
his photograph examples in `media.photo.product.used/`. Name removal and complete
photo seed definitions remain proposals, not implementation changes.

## Display review

The Elements and Joins tables use the same filtered Metaform as the graph.
Selecting an Element shows the providers it receives from and the receivers it
supplies in that view. Selecting an arrow or a join row opens the OP editor.
Namespace lineage alone creates no displayed dependency edges. Joins without an
unambiguous pair of endpoints remain inspectable in List; the viewer does not
invent their direction or decompose them into false binary relationships.

The isolated browser-check fixture at `dist/graph-review/` uses exactly the
supplied `media.image.sheet.sprite → code.game.platformer.2d` relationship,
labeled “visual representation of objects.” It supplies no inferred definitions
and runs no intake. It is separate from the empty example project.
Browser captures are `dist/graph-review/direct-relationship.png` and
`dist/graph-review/mobile-list.png`; these are local verification artifacts.

Browser checks cover direction, exact OP, both neighborhood directions,
connection navigation, canvas and list inspection, filtering, and mobile layout,
with no writes or browser errors. API tests also preserve structured OP values,
provenance filters, partial records, and multi-party or join-referencing records.

Verification on 2026-09-08: **144 tests passed** with
`uv run --frozen pytest -q --basetemp=.test-tmp/graph-view-suite`.
`node --check src/metaform/static/workbench.js` and `git diff --check` passed.
The browser check script and captures are in `dist/graph-review/`. The full-suite
temporary directory must not be Git-ignored: intake file discovery respects Git
exclusions, so placing its project fixtures under ignored `dist/` hides their
input files. The failed ignored-directory run passed after correcting that test
invocation; production code was not changed for it.
