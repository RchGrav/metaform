# Release-quality repairs implementation plan

> For agentic workers: use the subagent-driven-development and verification workflows. The user explicitly authorized execution of established repairs without another approval round. Preserve all protected instruction/tooling files and the existing working-tree changes.

**Goal:** Make the agreed Metaform system usable from the delivered executable, close the established repair backlog, and verify it through independent adversarial review and actual user journeys.

**Architecture:** Extend the existing module registry, workflow/continuation engine, and semantic stores. Module metadata owns reference, settings, and operative guidance; the chassis owns dispatch identity and lifecycle. Keep authored semantic behavior and source workflow conditions intact.

**Tech stack:** Existing Python CLI, JSON module manifests, SQLite/portable knowledge, MCP transports, Flask/Cytoscape workbench, pytest and current browser harnesses.

**Spec:** `docs/SPEC.md`, `docs/repair-backlog.md`, both source repair lists, and the user's current conversation and MetaformFoundation. New decision items X01–X10 remain narrowly scoped; they do not block independent established repairs.

## Working state and ownership

Worktree: `/home/rich/metaform/.worktrees/release-quality`, branch `repair/release-quality`. It includes the full original dirty tracked diff and untracked docs/installation test. Starting hashes and patch are retained in the parent `.worktrees` directory. Do not commit, push, delete instruction files, or overwrite other workers' changes. Run source tests with `PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest ...` so imports resolve to this worktree.

Keep an implementation/evidence log in `docs/release-quality-status.md`. Do not mark an R item delivered until its actual distribution journey passes. A partial source repair receives a partial status.

## Task 1: Module-driven CLI, reference, settings, and onboarding

Owner: CLI worker. Files: `cli.py`, `registry.py`, `onboarding.py`, `app.py`, `installation.py`, `modules/system.py`, `modules/guide.py`, relevant module metadata; communicate before touching another worker's module manifest. Tests: CLI/onboarding/installation plus focused public settings and module-removal reproductions.

- [ ] Reproduce help creating project state, active-mode parser failures, wrong-scope settings, and absent-module recommendations with temporary homes/projects.
- [ ] Separate read-only discovery/reference from App initialization; render real module help and no-argument starting guidance. Preserve explicitly selected projects and machine output.
- [ ] Supply module-owned parameter/default/example/settings reference, effective scope/source, and persistent scope-safe configuration with active refresh. Keep arbitrary module configuration supported.
- [ ] Route feature shortcuts through owning modules and make current guidance/continuations follow actual capabilities. Deliver feature details when requested rather than appending all worker instructions to startup.
- [ ] Verify module removal/restoration, nested help in active modes, wrong-run input handling, configuration isolation/refresh, and installed launcher preservation. Return the ownership/interface changes for independent review.

## Task 2: Shutdown and service ownership

Owner: shutdown worker. Files: `portable_mcp.py`, `mcp_server.py`, `service.py`, `modules/service.py`; focused MCP/service tests. Coordinate CLI signal boundary changes with Task 1.

- [ ] Reproduce initialized portable MCP with stdin held open, send SIGINT, and use `wait(timeout=...)` before closing stdin; demonstrate the regression test cannot pass by closing the pipe.
- [ ] Replace the blocked-reader/shutdown mechanism at its actual source. Verify SIGINT, EOF, protocol close, and normal installed transport without using forced exit as a substitute for cleanup.
- [ ] Reconcile owned service/test-process lifetime and teardown without terminating another client's active work.
- [ ] Run isolated source transport checks; hand off exact distribution checks to Task 8. No real user homes or credentials are changed.

## Task 3: Assignment identity, workflow mechanics, workfolders, and history

Owner: lifecycle worker. Files: `continuation.py`, `workflow.py`, `workfolders.py`, `history.py`, `modules/workflow.py`; relevant runtime/execution/history tests. Coordinate intake terminal integration with Task 4 and CLI parsing with Task 1.

- [ ] Reproduce retained marker → completion → diff → apply → stale source binding; also reproduce ignored file omissions under Git/plain directories and both knowledge backends.
- [ ] Retire ambient terminal identity while preserving exact historical request binding and replay; finish nonce cleanup, durable output retention, and abort/export consistency.
- [ ] Make snapshot/baseline/diff/apply cover the same working artifacts, excluding only actual chassis/Git bookkeeping; fix history mode mismatch. Verify binary/delete/rename and directory replacement behavior.
- [ ] Repair recursion's lost input/placeholder failure, truthful drive results, exact answer attribution, and missing public workflow discovery. Preserve authored controls and annotation semantics.
- [ ] Exercise sibling assignments, replay, fresh versus retained folders, and public CLI/MCP handoff. Review the whole lifecycle before delivery.

## Task 4: Intake, semantic reads, layers, and transformations

Owner: semantic worker. Files: `intake.py`, `modules/intake.py`, `layers.py`, `enumerator.py`, `models.py`, `namespace.py`, `read_model.py`, `transform.py`, `modules/model.py`, `modules/layer.py`, `modules/analysis.py` and their specific manifests. Tests: foundation/layers/reads/transformation fixtures with grounded semantic expectations.

- [ ] Repair reachable intake publication, truthful completion diagnostics, binary-artifact evidence access, and schema/reference delivery without adding semantic rejection gates.
- [ ] Preserve causal design-read dependencies into generated attachment impact, compare mappings, clone replay identity, removed-layer inspection, and missing coverage regeneration.
- [ ] Restore semantic read availability during jobs in coordination with registry ownership; make region/target and names coherent.
- [ ] Restore established base/namespace/Medium/name semantics from authoritative sources. Assess participant coverage and enumerator size without capping required combinations or changing the one-worker contract.
- [ ] Demonstrate each semantic fix through public read/write operations and record any precise unresolved owner decision rather than inventing meaning.

## Task 5: Workbench, examples, and portable delivery ergonomics

Owner assigned after initial lanes settle to avoid file conflicts. Files: `static/workbench.js`, viewer routes, example scripts, packaging/export helpers, browser dependency metadata.

- [ ] Reproduce and repair History layout/click resize, persistent pending-work visibility, selection/empty-state guidance, and meaningful Element counts.
- [ ] Make sample loading and demos work from a fresh checkout and installed distribution without machine-local scratch dependencies or rewriting retained source/evidence.
- [ ] Repair implicit build controls, export/import reference and dependencies, launcher/port/version identity, and browser test output isolation while preserving valid explicit-source build paths.
- [ ] Verify supported browser and portable workflows, including current Foundation and retained History behavior.

## Task 6: Complete built-in reference and synchronize current documentation

Owner: documentation worker after CLI metadata interface stabilizes; initially audit and prepare exact module reference inventory. Files: module reference/data and ordinary `docs`, `README`, examples. Do not modify protected agent instructions or historical prompt source text.

- [ ] Cover every command's owner, purpose, parameters, defaults, returned values, examples, context and lifecycle; module authors receive complete manifest/public interface reference.
- [ ] Correct current-versus-historical semantics, rulebook component delivery, layer selections, command spellings, screenshots, portability and host capabilities.
- [ ] Keep all R/S/Q rows traceable in the status log and link completed source/artifact evidence; documentation drift remains work until corrected.

## Task 7: Conversion library, chassis Metaform, and public customization

Owner assigned when registry/workflow interfaces are stable. Files: workflow conversion/grammar, module public API, bundled functional account/library and source-preserving seeding.

- [ ] Complete the already-agreed public module interface, with representative external modules using it for knowledge, assignments, results, and lifecycle instead of internal storage.
- [ ] Author the chassis's actual functional Metaform from inspected implementation, with module/workflow customization knowledge discoverable on demand and live capabilities supplied by registered modules.
- [ ] Convert the actual seven source procedures using real inference, preserving authored roles, context separation, user waits, artifacts, conditions and outputs; retain per-source semantic evidence.
- [ ] Package discoverable editable workflows and dependencies, then demonstrate create/import/run/customize/share/remove in two clean installations.

## Task 8: Adversarial review and distribution verification

- [ ] Independently review each completed lane for requirement compliance, code correctness, scope, semantic preservation, and tests that can mask the failure.
- [ ] Return substantive findings to the owner, verify fixes, and keep unresolved findings visible. Do not silently defer release-blocking defects.
- [ ] Run full applicable regression and browser suites after integration, build the actual distribution, and exercise fresh help/settings/module lifecycle/onboarding/handoff/diff/interrupt journeys from outside the source tree.
- [ ] Verify each established backlog entry or explicitly retain its real dependency/decision; do not label source-only or fixture-only results release quality.
- [ ] Integrate reviewed changes back to the user's workspace without losing pre-existing changes. Public push/release/deploy remains a separate owner action.
