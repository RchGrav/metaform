# Native and Latent Intake Implementation Plan

**Goal:** Make ordinary intake construct Native understanding and then examine that complete understanding once in a fresh latent task.

**Architecture:** Intake is a standalone Native → Latent flow. The project owns both attributed perspectives. Latent examination is also callable against the saved Native understanding.

**Spec:** `docs/semantics/artifacts-and-functional-intake.md` and Rich's subsequent discussion establishing the latent orientation before the task.

## Constraints

- Preserve actual artifact descriptions, receiving purposes, joins, schemas, and authored context.
- Supply the complete Native account to the latent agent; keep repository implementation access outside that assignment.
- Preserve existing graph/Element/OP names and independently attributed Native and Latent results.
- Preserve issued prompt snapshots and custom prompts.
- Retain open-ended output; add no unknown enums, tentative gates, or output restrictions.
- Work in the current shared workspace, preserving the existing edits and instruction files.

## Execution

- [x] Add failing integration tests in `tests/test_native_latent_intake.py` for the two-assignment flow, complete context, project-local storage, incremental contributions, continuation, and repeated latent examination.
- [x] Implement the standalone Native → Latent engine in `src/metaform/intake.py`.
- [x] Update `src/metaform/modules/intake.py` and its command definitions for full-Native retrieval and the callable `examine` operation.
- [x] Put Rich's opening orientation in a dedicated latent role source; snapshot it as `system_prompt` with each latent assignment. Transport it through MCP sampling and the supported Codex instruction channel, with transport tests.
- [x] Replace the active latent recursive-construction task with whole-artifact examination. Register known bundled prompt revisions while preserving custom text and issued snapshots.
- [x] Cover the Native → Latent flow through driver and transport tests. Run focused tests, then the suite.
- [x] Update the specification, source provenance, and current-work account to distinguish delivered behavior from remaining work. Verify links, whitespace, and a local end-to-end fixture run.

Verification proves delivery, persistence, and execution behavior. It does not establish live inference quality or absence of contextual bias.
