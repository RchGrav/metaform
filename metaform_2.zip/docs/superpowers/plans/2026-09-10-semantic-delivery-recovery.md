# Metaform semantic delivery recovery plan

**Goal:** Deliver Rich's existing property-propagation example through storage, retrieval, prompt preparation, and a faithful graph view, preserving the working project.

**Architecture:** The stored receiver-owned OP joins and namespace structure provide the source facts. One implementation of property reach supplies graph retrieval, prepared inference context, and visualization. Evaluate Bugscope, the viewer Rich identifies as the intended integration, against that same representation before selecting the visualization implementation.

**Sources:** Current user instructions and corrections; `docs/SPEC.md`; `docs/semantics/artifacts-and-functional-intake.md`; `docs/semantics/names-receivers-and-variants.md`; the attributable user quotations in `docs/semantics/understanding-and-work.md`. Historical quotations remain distinguishable from current requirements.

**Current stack:** Python, schema-governed records, shared SQLite knowledge service, local graph adapters including Ladybug, and a custom Flask/canvas workbench. Bugscope is not currently integrated.

## 1. Trace the settled requirements into their implementations

- [ ] Map each requirement below to its source, persisted representation, retrieval path, prepared prompt, and displayed result. Record concrete missing behavior beside the existing specification.
- [ ] Cover the receiver/OP/EF conjunction; the representative, medium-free Defining Element; actual artifact detail organized by Type; typed receiver-owned joins; Signal; namespace naming; property transitivity; Parametric arrays and their reservations; exterior boundaries; and whole-Native delivery to Latent.
- [ ] Recover terminology from current user corrections and attributable conversation records. Resolve the missing property-subtype list separately from the confirmed exterior kinds. Preserve distinctions between namespace kinds, join participation, property classification, and participant positions.
- [ ] Identify obsolete active prompt text, including Stylistic Element, and correct its active use as part of the corresponding implementation change. Protect user-authored instruction files and custom prompt text.

This is an implementation trace against the existing specification. Its deliverable is an accurate account of what exists and what is missing, followed by the repairs below.

## 2. Deliver property reach through storage and retrieval

**Relevant files:** `src/metaform/data/schemas.json`, `src/metaform/graph.py`, `src/metaform/knowledge.py`, `src/metaform/knowledge_export.py`, `src/metaform/modules/graph.py`, and the local adapters in `src/metaform/backends.py`.

- [ ] Turn the observed failure into an executable example: named Elements `code`, `code.installer`, `code.engine.game`, `code.bash`, and `code.cpp`; a property join from the installer receiving Bash; a property join from the engine receiving C++.
- [ ] Verify the existing failure: both joins are stored, but retrieval/assembly at `code` does not expose either property through the namespace.
- [ ] Implement the declared OP-join categories in the applicable schema and their delivery to intake. Account for the generic store's other schema-governed relationships when placing these declarations.
- [ ] Implement property reach according to its recorded namespace attachment: forward through applicable named Elements and backward to the relevant Defining Element or trunk. Retain the originating join, receiver, purpose, provider, source perspective, and attachment scope in retrieval.
- [ ] Make retrieval at `code` expose both media with the installer and engine contexts intact. Requirement relationships retain their own participation semantics.
- [ ] Verify retrieval after reopening the database, through the shared service, and through the existing local graph interfaces. Verify an attachment change changes the retrieved reach while preserving separately attributed Native and Latent facts.

The exact persisted/query representation is chosen by inspecting the existing schema and adapter boundaries; this plan does not invent a replacement ontology or an inferred migration for the discarded intake data.

## 3. Carry the same understanding into work

**Relevant files:** `src/metaform/prompts.py`, `src/metaform/intake.py`, `src/metaform/modules/intake.py`, `src/metaform/data/semantics/native.md`, `src/metaform/data/semantics/archaeology.md`, and `src/metaform/data/semantics/glossary.md`.

- [ ] Connect the property-aware retrieval to `prompts.assemble` / `prompts.prepare` and the applicable intake retrieval tools.
- [ ] Prepare the user's imperative request focused on `code` and save the exact model-facing context. Verify it contains Bash, C++, their originating joins, and the actual uses that justify both properties.
- [ ] Verify that the recorded Native understanding and applicable relationships reach Latent together, with its outside role preserved.
- [ ] Inspect the actual prepared context for semantic sufficiency using Rich's example. Report runtime test results separately from that inspection.

**First delivery milestone:** An inspectable stored example, its query result at `code`, and the actual prepared imperative request all carry the same property understanding. This milestone precedes cosmetic viewer changes.

## 4. Evaluate and integrate the intended viewer

**Relevant boundary:** `src/metaform/viewer.py` currently projects stored graph data into a restricted canvas representation; `src/metaform/static/workbench.js` implements the current drawing and interaction.

- [ ] Inspect Bugscope's source and current documented interface in parallel with the core repair, keeping this investigation read-only until an integration design is concrete.
- [ ] Demonstrate the same stored example in the candidate view: namespace structure, OP relationships, property reach, original attachment, and purpose text must be visible and inspectable.
- [ ] Check custom SVG support and interaction for `code`, `document`, `media`, `data`, and exactly `ext.environment`, `ext.person`, `ext.group`, `ext.system`, `ext.framework`. Preserve a larger Defining Element. These shapes describe namespace kinds; they do not replace join typing.
- [ ] Check joins with several participants and joins referencing joins against the current viewer's omissions.
- [ ] Present any concrete Bugscope incompatibility with supporting evidence before proposing a different library. Carry the property-aware retrieval into the chosen view rather than calculating separate semantics in the renderer.
- [ ] Verify project selection through the server registry, selection of nodes and joins, zoom, labels, and both desktop and narrow layouts.

## 5. Demonstrate actual intake and leave a clear handoff

- [ ] Run a bounded fresh intake after the semantic path is working. Inspect its actual artifact descriptions, receiver-owned purposes, typed joins, and property retrieval against the source artifact.
- [ ] Include an existing photograph example when checking that the path is artifact-general and preserves the subject/support relationship described by Rich.
- [ ] Show the Native result, the Latent review, the prepared work context, and the viewer as connected parts of the same recorded understanding.
- [ ] Report completed behavior and remaining implementation gaps with evidence. Keep the existing working project and its authored material; the user has not authorized another wholesale restart.

## Execution order

Requirements trace and core retrieval repair lead. Bugscope assessment may run independently. Prompt delivery depends on the core retrieval result; viewer integration depends on both that result and the Bugscope assessment. Full intake demonstration follows the connected path.

This document records the delivery sequence. It does not claim that the enum, transitive retrieval, SVG rendering, or Bugscope integration is already implemented.
