# CLI, settings and harness connections

Use the installed tool to discover its current modules and operations:

```sh
metaform
metaform --help
metaform intake --help
metaform intake start --help
metaform system reference --module intake
metaform system reference --module workflow --command start
metaform system settings
```

Help, reference, settings inspection and installer argument parsing can run
without creating a project. A no-argument launch explains how to begin; for an
existing project it reports the current guide state and next action. Parameter
names use dash-form flags, for example `--run-id` and `--artifact-context`.
`--human` selects readable output and `--json` selects complete structured results.
MCP always retains its protocol output.

Project selection belongs to the client:

```sh
metaform --project /path/to/artifact guide start
metaform --project /path/to/artifact browse
```

An initial `--project` accepts a path or registered project ID. Otherwise the
launch directory or `METAFORM_PROJECT` supplies the project. An MCP session can
use `project.select`; each workbench tab has its own project URL. Issued work
retains its project/run/request identity. Help remains available in an exclusive
mode, and unavailable commands return errors. `workflow start --no-exclusive`
starts a run without taking over the project's command mode.

An answer needs the issued run and request IDs or an exact assignment binding.
Copy the runtime's returned `begin` command; it names the actual launcher and
nonce. The coordinator retrieves subsequent work outside a completed worker's
binding. Saved assignment/result history remains available after terminal
ambient markers are cleaned. See [workflows](workflows.md) for continuation and
replay.

## Configuration

```sh
metaform system settings
metaform system configure --scope home --settings '{"sampling_max_tokens":8192}'
metaform system configure --scope project --settings '{"debug":true}'
metaform system debug --no-enabled
```

`system settings` reports module-declared defaults, effective values and their
sources, and the resolved configuration paths. Home configuration is
`<effective-home>/config.json`; project configuration is
`<project>/.metaform/config.json`. Project values override home values, which
override module defaults. Portable runtime constraints are shown separately.
Updating one scope persists that scope's own settings, without copying the
merged effective project view into the home file. Active configuration refreshes
after a write. Nested objects merge by key so sibling harness/module settings
survive; arrays and scalar values replace the corresponding value. Storage/backend or module changes may take effect when the
corresponding component is reopened; consult the setting's built-in description.

A registered project can retain its service home. Inspect the reported effective
home instead of assuming an environment change relocated that project's service.
An explicit `auto_build: false` disables the changed-source rebuild after module
calls. Its declared default remains true for the selected Metaform source tree;
portable mode disables it. Explicit `package build --source /path/to/source`
works independently of the selected artifact's layout.

## Shared server and workbench

One persistent process and HTTP port serves the operating-system user's knowledge
clients and workbench projects. Opening another project or using another storage
home attaches it to that same server. Each home keeps its existing database,
credentials and project identities; opening a legacy or portable project does
not adopt or convert it.

```sh
metaform service start
metaform service status
metaform --project /path/to/artifact browse
metaform service restart
metaform service stop
```

These service commands work without initializing a project. `browse` returns the
selected project's URL; the server's root page lists attached projects and can
open an existing project folder. Each tab keeps its own project URL. Closing
clients or browser windows leaves the server running. `service stop` and
`viewer stop` stop the shared server for all projects after accepted requests
finish; they leave stored workflow state available for continuation.

The first start selects an available loopback port unless `--port` is supplied.
Later starts reuse that endpoint. Use `service restart --port <port>` to change
it; a restart without a port retains the current port. Status reports the loaded
runtime fingerprint and `restart_required` when the caller's package differs.
An explicit restart replaces that runtime, so clients from different
installations cannot repeatedly replace each other's shared server.

The runtime identity and endpoint live in `~/.metaform/runtime`. Storage-home
endpoint files refer to that same process and port. Tests set
`METAFORM_RUNTIME_DIR` to a separate temporary directory before starting any
client or server; different storage homes alone do not isolate server lifetime.

## Installation and MCP

`metaform install` detects Codex, Claude Code, Gemini CLI, Cursor and VS Code.
It configures selected hosts, backs up touched configuration files and preserves
other server entries. It preserves an existing launcher, including a uv-managed
one. Use repeated `--harness` flags in a noninteractive run. Installer setup
alone does not select or register the launch folder as an artifact.

The installed skill is a concise concierge entry point. `metaform skill` and
`guide.skill` provide the current core plus live module summaries; module
reference provides detailed capabilities and operative instructions when needed.
`metaform guide chassis` provides the chassis functional account and customization
procedures on demand. A host with its own MCP configuration can register the absolute launcher with
`args: ["mcp"]`, optionally setting `METAFORM_PROJECT` to an explicit artifact.

The installed MCP SDK supports host sampling when the client advertises it.
Newer negotiated protocols expose the `metaform` router plus directly exposed
commands; older protocols expose individual visible commands. A portable archive
without the SDK uses the bundled stdio transport. It returns assignments for
external execution and answer submission; it does not acquire host sampling by
printing a handoff. From a plain terminal, select an executable harness such as
Codex, or follow the returned assignment.

| Host/path | Evidence retained in this repository |
| --- | --- |
| MCP SDK clients in tests | Initialization, discovery, command calls, sampling fixtures and exact assignment binding are exercised; this tests protocol behavior. |
| Codex command harness | Retained live comparison and grounded-task runs record actual execution and role delivery through developer instructions. This is separate from Codex-as-MCP-client behavior. |
| Claude Code registration | The September 10 installer review records a successful connection check. Applying every server instruction and advertising sampling were not established by that connection check. |
| Cursor and VS Code | Registration adapters exist. Real-host registration/application of instructions remains environment verification work. |
| Gemini CLI | Registration and skill-install adapters exist; real-host sampling and instruction application are not established here. |

The host ultimately determines whether its agent receives and applies server
instructions and whether sampling is supported. The table records the observed
boundary instead of treating registration as a reasoning result. See
[verification](verification.md) and the [retained installer review](reviews/2026-09-10-onboarding-review/mcp-onboarding-install.md).
