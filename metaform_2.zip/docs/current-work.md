# Current work

The 2026-09-10 realignment implements one artifact-shaped foundation with
separately attached knowledge. The [specification](SPEC.md) defines the semantic
contract; [architecture](architecture.md) describes its storage and read
boundaries, and [workflows](workflows.md) describes the executable operations.
This page tracks the current checkout. Dated earlier runs and samples remain
historical evidence in [verification](verification.md).

## Coarse intake contract v2 — 2026-09-12

The old workbench page, its template, six scripts and five browser suites are
removed; the product has one page, the explorer, with the Jobs tab. The
intake prompt is `specifications/intake.md` (Digital Archeology), installed
byte for byte as the runtime prompt; its `name_length`, `relation` and
`observation` are in the contract. Two PongClock runs are recorded under
`docs/reviews/2026-09-12-pongclock-coarse-intake/`.
Intake now lists annealed subtypes; they publish as inactive positions
beneath their main Type, reserve their address, and show in the explorer's
tree as inactive rows.

The intake prompt is Rich's authored seven-section prompt
(`src/metaform/data/roles/runtime/intake.md`: Purpose, Core Concepts,
Namespace Rules, Method, Goal, Constraints, Completion Condition) with no
components appended. The contract `urn:metaform:schema:coarse-intake:2` mirrors
its output and nothing more: notable elements keyed by namespace position with
one EF each, and joins carrying the receiver's Operative Purpose plus an optional
`combined` dictionary of entities combined away (relation, observation). The
runtime expands that shape into storage in `src/metaform/coarse.py`: the
Defining Element is the one element no join provides, prefix positions become
Types with an empty EF, narrowings carry no reason, and every shallow join is a
`hard dependency`. Each submission records its expansion for the Jobs replay;
the activity keeps the raw answer. Nothing gates the answer: the contract
describes the shape and never rejects, the expansion makes whatever came back
fit and records each mismatch on the run for observation, and `intake.put`
and `intake.answer` return only `recorded` and `contract_version`. The spec's chassis section records the
sandbox bundle goal, the dependency test, and the compatibility floor.

## Release-quality repair work — 2026-09-11

The [reconciled backlog](repair-backlog.md) is the current work inventory. It
preserves all R/S/Q references, separates established repairs from additional
product choices, and reconciles the two earlier agent lists. The
[repair status](release-quality-status.md) tracks lane review and integrated
artifact verification. An item remains open at delivery until its actual
user journey passes in the rebuilt tool.

The repair source now includes module-organized CLI help and reference for 120
commands, explicit settings scopes, module-owned guidance, corrected
continuation/shutdown paths, semantic completion/read recovery, the public module
API and packaged chassis account, seven converted procedures, and workbench
repairs. The final frozen source run passed 884 Python tests and all four browser
suites. A later small viewer guidance deletion has separate focused verification;
the [integration report](reviews/2026-09-11-final-integration-verification.md)
records the exact source snapshots. The rebuilt wheel and standalone archive
passed the installed/portable matrix on Python 3.11 and 3.13, a 44-call public
customization journey and the installed-wheel module-removal browser check.
The source and both artifacts are now integrated in the original checkout. Its
relocated executable also passed 44 public calls and five standalone shutdown
cases on Python 3.10.12. [Checkout delivery](reviews/2026-09-11-checkout-integration.md)
records exact identity and preservation checks; the repair status retains the
remaining decisions and verification limits.
[CLI and harnesses](cli-and-harnesses.md), [knowledge and revisions](knowledge-and-revisions.md),
and [workbench navigation](workbench-navigation.md) describe the repaired source
interfaces.

Actual Native self-intake, outside review, and a bounded specialist file handoff
through the converted Orchestrator now have retained model outputs, semantic
reviews and browser/file evidence. They do not establish every branch of all
seven workflows or general inference superiority. The earlier tool's reported
million-question workload is reopened as a [property-scope and sample-provenance
investigation](reviews/2026-09-11-enumerator-count-audit.md); assignment splitting
is not yet an established need. Missing authoritative base definitions remain
separate input to resolve. [The backlog](repair-backlog.md) retains the repairs,
documentation work and conditional proposals separately.

## Implemented realignment

- **Foundation and migration:** immutable model revisions over the existing owner
  partitions; separate Types, Elements, bindings, narrowing/refinement records and
  receiver-owned OP joins. V1 import preserves raw inputs, Element identities,
  observations and historical outside results. Unknown facets and narrowing
  meanings remain diagnostics.
- **One-foundation intake:** focused versioned role composition, incremental
  contributions and independent completion. Requested outside analysis attaches
  a blind-spot report. Already-issued v1 assignments retain their old contract.
- **Shared semantic access:** namespace resolution, Type/member inspection, Element
  and join reads, bounded grounding/traversal and revision-bound pagination through
  common CLI, MCP and viewer projections. Targets remain owner-qualified.
- **Knowledge layers:** separately owned requests, schemas, recipes, generations,
  attachments and selected regeneration. Original semantic requests and actual
  assignment/context snapshots remain recoverable.
- **Applicability:** origin-carrying explanations distinguish backward visibility,
  forward applicability, Type inheritance, Element refinement and join context.
  Layer origin remains visible along a Type-derived path.
- **Expansion and variants:** requested local depth retains existing Element IDs;
  explicit patches add refinements or correct meaning. Nonoverlapping changes
  can rebase; conflicts retain the competing records and submitted answer.
  Destination variants preserve source revisions and evaluate affected knowledge
  through record/selector dependencies and the original generation requests.
- **Grounding and specialization:** deterministic selected-region context feeds
  subsequent work while the source instruction and workflow control flow remain
  separately retained.
- **Workbench:** rebuilt from the [workbench brief](workbench-brief.md) as an
  explorer of what the agent sees through MCP. All five units are built:
  settled intake semantics restored; the graph holds still and reads are
  cached per revision ([calls record](workbench-calls.md)); the explorer
  serves at the root; two palettes; help for the person; and the Jobs tab, which starts
  and drives an intake from the page, shows any run as steps, replays an
  intake as a growing graph, and edits the prompt for a rerun
  ([navigation](workbench-navigation.md)). Acceptance is a real intake run
  through the page with a real agent, judged by Rich.

These changes reuse SQLite service authority, portable JSON knowledge, existing
workflow/continuation runs, editable prompt records and manifest-driven commands.
They do not require another database, frontend framework or execution queue.

## Earlier realignment verification and live observations — 2026-09-10

The earlier realignment regression passed 663 tests on Python 3.11 and 3.13. The final prompt-report
change passed its 72-test integration slice; exact scope is recorded in
[verification](verification.md).
The 22 JavaScript model/renderer tests and all four browser suites passed.
The unchanged MGM sample migration retained 47 Types, 58 Native actuals, 59
bindings and 101 joins, with two unresolved provider facets and 43 unresolved
narrowing meanings reported explicitly. Its original source hashes were unchanged.

A fresh wheel and installed-distribution check passed CLI/MCP, direct-wheel
CLI/MCP, offline GUI/export and shared-service portable continuation using the
v2 one-foundation contract. The reproducible
[realignment demonstration](../examples/realignment/README.md) retains one-foundation
intake, property explanation, requested layers, a source-preserving variant,
automatic affected-layer reinference and exact source/destination transport parity.

Six matched live intake arms completed for a maintenance guide, a multi-Type
coordinator and a selected MGM archived account. A separate fresh task agent
successfully oriented to the demonstration model and produced a grounded plan
using actual Element, join, layer and generation references. Inputs, outputs,
timings and provider-reported usage are retained in the
[live review](../examples/realignment/evidence/live-comparison/review.md).

## Knowledge Tool and customization

Knowledge Tool applies arbitrary literal instructions to base functional
understanding and whole property-qualified composites, then maps returned arrays
into a named layer. `knowledge.preview` displays the actual sentences and
`knowledge.start` creates the generation assignment.
The concierge discovers registered module abilities through `guide.start`.
Fresh workflow assignments now reuse chassis-managed folders, nonce binding,
scoped commands, and submission cleanup.

The installed skill is a concise concierge core. `metaform skill`, `guide.skill`
and live module reference supply current module summaries and operative guidance;
removing a module removes its discovered capabilities. The source now provides
`guide.chassis`, which returns the separately held Native functional foundation
and customization procedures with live module reference. Community handlers
receive `ModuleAPI` operations and module-scoped state rather than the internal
App storage object. The [module example](../examples/module/README.md) demonstrates
that interface. Chassis semantic review, the conversion library and delivery
demonstrations are tracked individually in the [backlog](repair-backlog.md) and [repair status](release-quality-status.md).

## Observed semantic limitation

The focused multi-Type output described engine-local C++ and installer-local
shell correctly in prose but placed the property joins on the coordinator.
An executable applicability probe records the resulting incorrect application.
The output passed schema validation. The raw generated output is retained, and
the twelve installed role/composition files match the supplied realignment
package exactly. This observation does not
establish focused-prompt semantic superiority or general inference savings.

The live trials also observed a project-relative handoff command without a local
launcher; both arms recovered through installed actor discovery. The retained
review records that transport-context issue. The grounded task is a semantic
handoff from supplied narrative evidence, not a verified implementation-source port.

Custom prompt preparation exposes complete text, schema and component differences
against the managed composition. Authored overrides and issued snapshots retain
their original content; difference reports remain outside inference payloads.

The [historical MGM intake](../examples/intake/mgm-main/README.md), dated reviews,
and earlier handoffs remain evidence of their recorded runs. Their two-complete-
graph intake directions are superseded for new v2 work. They are not a second
current specification or a reason to rewrite saved source material.
