# Plan, from 2026-09-12

The order of the units still to build, each finished end to end before the
next starts, each begun with failing tests. No unit spends inference except
an acceptance run, and every run is one execution, stated before it starts.

| # | Unit | Spec | Delivers |
| --- | --- | --- | --- |
| 1 | Live graph growth in the Jobs tab | workbench brief | The graph advances on each recorded contribution while a run is open, not only in the replay after completion. Page only. Done 2026-09-13: the page already advanced on each `intake.put` while the run stayed `running`; `tests/test_jobs_live_growth.cjs` now enforces it through a real browser, two contributions before completion. |
| 2 | Sandbox packet jsonschema | 14 | The standalone carries the pure-Python jsonschema line with attrs and pyrsistent; the validator accepts either API; the local form is untouched. A test builds the zipapp, installs only the floor packages in a fresh venv, and runs an intake and a workflow there. Done 2026-09-13, then reversed the same night: the runtime checks answers with its own checker, jsonschema is dev-only behind a parity test, and the packet carries no validator line and no compiled wheel. `tests/test_sandbox_packet.py` builds the packet, makes a fresh Python 3.11 venv holding only the floor packages, and runs an intake and a workflow through it there. |
| 3 | Chassis bases known to every intake | 5 | `code`, `document`, `media`, `data` are reusable positions for every run, never re-authored per project with an empty EF. Done 2026-09-13 night: `data/bases.json`, seeded into the global registry at first start, referenced by every run, reused by the expansion (`tests/test_chassis_bases.py`). The `code` words are Rich's settled ones; the `document`, `media` and `data` descriptions and EFs are mine for his word. |
| 4 | Cruft removal | Why, 14 | The v1 native and archaeology intake path, its two prompt files, the old graph schema and their tests; the unused `join_logic`, `participants` and `scope` join fields unless a use is named; the header overlap at 1600 px. The review archives stay or go on Rich's word. |
| 5 | XML workflow format | 14, 15 | Grammar, loader onto the existing step kinds, Jinja substitution and Jinja `when` expressions, variables stored as references, the binding map recorded on every issued assignment, a composer for the seven sections, the seven library definitions converted by script, the convert prompt retargeted. |
| 6 | Operations as definitions | 15 | Intake, expand, blindspots and the layer roles become definitions the engine runs; their Python state machines are retired; the Jobs tab drives the run. |
| 7 | Memory node surface | 15 | Typed entries in the join dictionary; the revision-cached index of every memory node address, its join, receiver and entries; address resolution and reservation; knowledge reads at an address including the agent's own memories; the layer include flag and the orchestrator's spot-check instruction; the best-practices layer on every step by default. |
| 8 | Nonce mechanics and project tracking | 9, 13 | Workflow nonce at registration, agent nonce derived from it, `begin` binding a folder to an assignment, identical CLI and MCP deliveries, each step naming its memory address, a delegated CLI showing only its own surface, workfolder isolation for multi-step subagent assignments. Progress 2026-09-13: the on-disk marker is gone; `begin` records the folder in the base db, `done` clears it, children inherit, a command is activity, 24 hours idle acts as absent, help writes nothing, the packet carries the records (`tests/test_bindings.py`). Checkout and the last project per folder remain. |
| 9 | Provenance read, browser and editor | 15 | One read from any ref to its producer, prompt as constructed, binding map and bound refs; the explorer shows it on every record; the editor presents sections with variables as objects, hover provenance, edit to a new revision, rerun from a step. |
| 10 | Chassis onboarding | 12, 13, 14 | First-run provisioning notice and menu keyed on the harness binary's parent folder; contextual `--help` with the status section and separator on every help output, `Project: none selected` when nothing selects one; the human page in Claude Code layout when stdout is a terminal, the AI form when piped or bound; errors naming the project; the wheel form's installed-copy check; nonce-scoped menus once the done or complete word is settled. |
| 11 | Knowledge service process | 13 | Rich's requirements: one port, a consistent start command, start and stop commands, single process, proper process management, no init system, no pick-a-project page on launch, a link made once that works. Design to be laid out by Rich before tests. |

Deferred until specified: deep intake (needs Rich's prompt), the porting queue
and target-medium layer (needs deep intake and units 5, 7, 9), the work packet
module (post-MVP by instruction).

Decisions still with Rich: the done or complete word; whether the join
dictionary's typed entries are keyed by name with the nonce as a field; the
initial entry types; the palette default; the four glossary entries and two
spec sentences flagged on 2026-09-12.

## Unit in progress: nonce-scoped menus and nonce mechanics (sections 9 and 14)

What exists: the binding comes from `.agentid/nonce` found from the working
folder upward; `registry.visible()` already narrows commands to the bound
assignment's tools; the starting page is one generic page with no status and
no scoping; nonces are nine random digits per assignment; there is no `done`
or `complete` command; the MCP server only reports a job's nonce.

Words, read from Rich's statements: `done` ends a delegated assignment or
provisioning and cleans the nonce; `complete` leaves the self-assigned admin
menu and returns the agent to its own menu.

Progress: tests 1 to 3, the `done` half of 4, 6 and 7 are green. A workflow's registration record carries a 16-hex nonce, renewed on re-import and hidden from the definition read; an agent nonce is eight characters of sha256(workflow nonce + salt), recorded with the workflow, its nonce and the salt; a multi-step workflow assignment publishes with a workfolder, a single-prompt operation does not. Isolation is keyed on a delegated child frame (a `call` into a workflow of more than one step); the orchestrator's own top-level run stays in the main folder. The orchestrator menu needs no nonce from the main folder of a registered project. Open: the admin menu and `complete` (5, needs Rich's command word) and an MCP delivery assertion (6).

Failing tests to write, in order:

1. `metaform` and `metaform --help` in a bound folder print a status section
   first (project, folder or worktree, job id, workflow, step) and then only
   that assignment's commands; no module list, no project chooser.
2. In the project's main folder, unbound, the main menu: status (project,
   stage), then the orchestrator's instructions only: provisioning, listing
   workflows, doing intake, and the installed modules.
3. In any other unbound folder: no main menu, one line pointing at the
   project's main folder and `begin`.
4. `metaform done` in a bound folder ends the assignment's delivery and
   removes `.agentid/nonce`; `metaform complete` in a folder bound to the
   admin menu retires that binding and the agent's own menu returns.
5. The admin menu is an assignment: the orchestrating agent obtains its nonce
   from the CLI in the main folder and enters it with `begin`; the command
   name that issues it is not yet Rich's word and is flagged.
6. A workflow receives a workflow nonce when registered; an agent nonce is
   eight characters hashed from the workflow nonce and a random input, checked
   unique, and its record names the agent and the workflow; `begin` accepts
   it; the CLI and the MCP construct the same delivery from it.
7. A multi-step subagent assignment is issued with a workfolder; a
   single-prompt operation is not.

## Handoff note, 2026-09-12 evening

Committed through `655fe7e` plus an uncommitted one-line fix in `cli.py`: the
subfolder walk now recognizes a project by `.metaform/state.sqlite3`. The full
suite could not complete twice: the system killed it for memory. Under a
6 GB cap with `-x`, the first failure is the untracked
`tests/test_installation.py::test_install_cli_registers_a_launcher_that_serves_onboarding`,
stderr `{"error": "Unknown project: <id>"}` then an MCP "Connection closed";
it passed in this morning's clean runs, so a CLI change today broke the
launcher's onboarding path. Start there: run that test alone, read its stderr,
and check the `help` routing and the parent walk in `cli.main`. Then rerun the
full suite alone and watch memory. Menu, nonce and CLI reference suites are
green (75 passed).

Rich, on the handoff: there are too many tests; question any that give
trouble. A test exists to protect a requirement of the design; one that costs
more than the requirement it guards is suite cruft. So the launcher onboarding
test is questioned before it is fixed, and the cruft removal unit includes
the tests.

## Progress note, 2026-09-13 early morning

The launcher onboarding test failed because the subfolder walk climbed into
`~` and took `~/.metaform`, the Metaform home, as a project; a test run at
18:08 the day before had written `project.json` and `state.sqlite3` into the
home that way. The walk now stops before `~`, one level deeper, with a test in
`tests/test_nonce_menus.py`. The debris was moved out of the home. The full
suite ran green under a memory cap: 952 passed in 5:03, no memory kill; the
earlier kills were not reproduced. `package.json` had a trailing comma that
broke `npm ci`; fixed. Unit 1 is done by test. Unit 2 is done by test; the pure-Python
jsonschema line was tried first and dropped because the packet already writes to the
drive on first run, so the compiled rpds-py loads from there and one API serves both forms. Decisions of the evening are
recorded in SPEC sections 9, 13 and 14: status header on all help, the human
page in Claude Code layout, project tracking in the base db keyed by working
folder, no on-disk nonces, the 24 hour rule, and Rich's requirements for the
knowledge service process, whose design is his to lay out.

## Handoff note, 2026-09-13 morning

State of the tree, all committed through `f56b69a`, suite green at 959 in 5:22
under an 8 GB cap, no memory kill:

- Units done by test: 1 (Jobs tab live growth, browser test), 2 (sandbox
  packet on the floor, `tests/test_sandbox_packet.py`), and the working-folder
  bindings in the base db (`tests/test_bindings.py`, no `.agentid/nonce`
  anywhere). The walk stops before `~`.
- Rich's decisions of the night are in `specs/data_folder.md`, in his words,
  and in `docs/SPEC.md` sections 9, 13 and 14. Read `specs/data_folder.md`
  first; it also quotes the vivi specification and TEMPO 0.5.2 with paths.

Next, in this order:

1. Intake is one `put` per object, live, through the MCP tool or the CLI with
   named flags; no JSON authored by the model. Build the CLI flags for
   `intake put`, then a small validator of our own for the schema subset with
   a dev-only jsonschema parity test, then remove jsonschema from runtime
   dependencies and undo the floor line of unit 2 (the six wheels in
   `data/sandbox`, `floor_wheels`, `add_wheel`, `_floor_path`). Keep
   `test_an_intake_and_a_workflow_run_inside_the_packet_on_the_floor` as the
   proof the packet runs on bare Python; it should pass with no floor at all.
2. Checkout: `checkout <project>` from an outside folder records folder to
   last project in the base db and shows the orchestrator menu there;
   registration decides the project before any walk; nowhere prints
   `Project: none selected` and never makes the folder a project.
3. The history unit from `specs/data_folder.md`: repo bases keyed by commit,
   non-repo under `~/.metaform/origins/<mform_sha_id>` with the origin copy,
   variants as changed text whole under 3 MB or diffs above, binaries whole,
   reconstruction from the packet's menu, the 240+16 and 48+16 identity forms.
4. The knowledge service to Rich's requirements: one fixed port, start and
   stop commands, single process, no init system, no chooser page; Windows
   and macOS runners in CI and no signals on Windows. Rich lays the design out.
5. Cruft removal, tests included: every test names the requirement it guards
   or goes; model delete and the retired backends first, they cost 25 s.
   `pytest-xdist` would take the suite from five minutes to about one.

Open on Rich's word: the `checkout` command name; the folder name `origins`
(mine, from vivi); the desktop rpds-py wheels become moot under step 1.

## Handoff note, 2026-09-13 night

Rich's words that govern from here: a failing inherited test is questioned in
passing, never a reason to stop; commit every finished unit; everything should
be a workflow; a clear-and-reintake project operation is required and always
has been; `browse` is gone, the command is `web`.

Landed tonight, each with tests, each committed (`27efa17`, `0e5b99b`,
`a541d8d`):

- The launcher on PATH was a stale wheel from `.test-tmp`; it is now an
  editable install of this tree (`uv tool install -e .`). The wheel under
  `dist/` is older still; never run it. `tempo/` is deleted from the repo; its
  live copy is `~/tempo`.
- `metaform web` starts the service on one fixed port (`web_port` in the home
  config, default 8642) when it is down, opens the current project, prints the
  URL. `web stop`, `web status`. The root of the page lands on the project; the
  chooser is at `/projects`. A module may declare `default_command` for its
  bare word.
- Forget: the projects page marks folders that are gone and offers Forget per
  entry; `project forget --path|--missing` on the CLI.
- Clear project in the page header; `project clear` on the CLI: models, runs,
  layers, assignments and bindings of the project go, the folder, its files and
  its registration stay, the built-in prompts are re-seeded; not offered inside
  a delegated assignment.
- Chassis subprocesses start Python with `-P`, so a project folder's `types.py`
  can never shadow the standard library again (that is how tempo's copy took
  the service down).
- This project's `.metaform/config.json` no longer pins the retired ladybug
  backend. The home config still carries a dead `service_idle_timeout` key.

Next, in this order, all decided, no questions to ask:

1. The validator swap and the floor removal (step 1 of the morning note). The
   shipped schemas use exactly: type with null unions, properties, required,
   items, additionalProperties, `$ref` to local pointers and registry ids,
   `$defs`, enum, const, minimum, maximum, minItems, maxItems, minLength,
   pattern, oneOf, anyOf, allOf, if/then. No anchors. Own checker for that
   subset with a dev-only jsonschema parity test; jsonschema out of runtime
   dependencies (the mcp SDK still pulls it locally, our code never imports
   it); the six wheels in `data/sandbox`, `floor_wheels`, `add_wheel`,
   `_floor_path` and the two floor tests go; the bare-Python packet test stays
   and passes with no floor.
2. Unit 3: the four bases known to every intake.
3. Cruft: the v1 native and archaeology intake path and its prompts, the
   retired backends, model delete, tests that guard nothing; pytest-xdist.
4. Checkout: `checkout <project>` from an outside folder records folder to
   project in the base db and shows the orchestrator menu there; registration
   decides the project before any walk; `Project: none selected` never prints.

Waiting on Rich: the shape of intake as a workflow (one step or several, what
ends a step with no final JSON, whether the role composition survives, the
finish as a tool step or a completion hook, workfolders for a multi-step
intake) and the XML workflow format itself. The per-object `intake put` is
built inside that unit, as the engine's put with named fields, not on the
Intake class. The per-call nonce over MCP from section 9 is not built: only
`workflow.begin` takes a nonce.

## Handoff note, 2026-09-14 early morning

Rich killed the session that built checkout (step 4 of the night note). It
also rebuilt the help and menus (unit 10, waiting on his done and complete
word), replaced the AI form's contextual menu with the human Usage, Options,
Modules page, deleted the admin menu and `metaform complete` from the tests,
inverted the other-folder test, added a `summary` field to all 24 module
files, and let json.dump escape his apostrophe and en dash in two of them. All
its tests passed because they were rewritten to fit the code. That diff is in
`git stash` under the name "killed session 2026-09-13", unreviewed; the tree
is at `024a658` and the nonce, binding and viewer tests pass there.

Found the same night: the plugin layer is real (four discovery roots, one
loader, the CLI parser, the MCP tools and the web tools all built from the
module objects), but the menus, the launcher words and the installer's screens
are typed into `cli.py`, `registry.py` and `installation.py`, and chassis code
names `guide.start` (cli.py, seven places), intake commands (viewer.py, two;
actor.py, four; onboarding.py, two). `docs/shape.md` records the shape as
built, for Rich.

Decided 2026-09-14, recorded in SPEC section 14: menus and screens are
renderers over the module objects, drawn through Rich, Typer and Questionary;
whatever a built-in gets from its declaration a community module gets from its
declaration; no chassis file names a module.

Order from here: the menu and screen renderer unit, then checkout on top of
it. Failing tests to write for the renderer, once Rich names the placement
field and lays out each context's screen:

1. A module dropped into the home's modules folder, declaring the context its
   commands belong to, appears in that context's menu with its own line and
   purpose, with no chassis change.
2. With every built-in module removed, the chassis still prints status, the
   separator and the menu of what is loaded, and nothing errors.
3. The next action on the page comes from whichever loaded module declares
   the guide handler, never from a name in chassis code.
4. Piped output is plain text; a terminal gets the drawn screen; `--human`
   and `--json` override.
5. The installer's screens come from the renderer, not from print.

Open on Rich's word: the placement field and its values; the layout of each
context's screen; whether the JSON module declaration becomes XML with the
workflow format (his words: "json is the old format it was going to change to
xml"); the sdist exclude list in pyproject.toml (the source tarball is 58 MB
because hatchling sweeps `.worktrees`, `docs/reviews` and the stray archives).

Decided 2026-09-14: one document language. Unit 5 puts workflow definitions in
XML, and the answers a model writes as text use the same grammar, so the
contract that describes a shape and the definition the engine runs are the same
kind of document. The reason answers move with it is the no-gating rule: a
broken JSON answer is unparseable in whole, an XML answer still yields the
elements whose tags closed, and prose fields carry no escaping. It does not
touch the per-object `intake put`, where the model authors nothing and the
harness sends named fields. The parse layer converts to the same dict the
contract already describes, so `schemas.check` is unchanged, and it records each
mismatch the way the expansion does rather than coercing silently. The grammar's
conventions for lists, absence and numbers are authored work and are the part
that must not invent.

Also landed 2026-09-14: process identity. Each agent is its own server process,
so a server records its pid, the ppid of the harness that spawned it, its folder
and its project in the live db (`agents` table in the base db). The nonce is
entered once by `begin` and linked to that parent, because a harness starts its
server from its own folder and never the assignment's, so the folder cannot
carry the identity. `system.whoami` reports folder, pid, ppid, project, home,
nonce and binding. Four tests in `tests/test_mcp_identity.py`; one is a strict
xfail holding the section 13 rule that a folder belonging to nothing is never
made a project, which lands with the checkout unit.
