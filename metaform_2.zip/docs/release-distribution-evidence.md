# Delivered artifact verification — 2026-09-11

The final wheel and byte-identical standalone archive pass the delivered-user-journey checks on Python 3.11.6 and 3.13.5. Their SHA256 is **`2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027`**. Both are in the worktree's `dist/` directory; no public release was performed.

The build source fingerprint is `e593dcbc2d7317fe1b57e79f536065f9461be4fb1c39308792498a8e05d0ecb4`, unchanged across the build and the complete final verification matrix. All 161 package source files are present and byte-identical in the wheel. The inventory checks all seven source/definition pairs, their source and definition revision hashes, the workflow grammar, chassis functional account and historical MGM sample files.

Fresh environments installed this exact wheel separately for Python 3.11 and 3.13. Their package imports resolve to their own `site-packages`, never the editable checkout. Subprocesses run outside the source tree with `PYTHONPATH` cleared and disposable project/home directories. Standalone checks use `python -S` and the archive's bundled runtime; selected runs also clear `PATH` entirely.

## Final checks

| Check | Actual delivery evidence |
| --- | --- |
| Integrated distribution, Python 3.11 and 3.13 | Installed CLI/MCP, direct wheel CLI/MCP, empty-interpreter viewer and export, rulebook, two intake/revision cycles, and shared-service nested continuation after the original home becomes unavailable. |
| Packaged reference | Workflow grammar, chassis account and settings are available without project initialization. All seven library entries and both revision hashes match the archived bytes. |
| Shutdown, installed and standalone on both Python versions | Open-stdin interrupt, EOF, full unread stdout pipe interrupt, complete large Unicode response plus ping, and interrupted synchronous handler with `finally` observed. SIGINT returns 130 with stdin still open; EOF returns 0. |
| Automatic-build cancellation, both installed versions | A real sleeping PEP 517 backend is terminated; no completed-build hash is recorded; the build lock can be reacquired. |
| Whole-artifact transfer | Installed Git workfolder with JSON knowledge over an ordinary source, exact returned begin command, export of active work, dependency-free Python 3.11 continuation through the file tracker, completion and apply. Ignored/binary content, additions/deletions, renames, symlinks, empty directories and directory modes survive. The original source and its nonce remain independent. |
| Malformed-module recovery | 104 routes across installed and standalone: twelve malformed declaration shapes and a valid missing-implementation control, each through top-level help, install help, system reference and workflow reference. Exact file/field diagnostics, available built-ins, exclusion of invalid modules from the partial catalog, and unchanged file hashes are checked. |
| Authored execution policies, installed and standalone on both versions | One failed attempt is retried when authored; negative validation answers continue normally; absent policy preserves explicit failure/resume; manual resumption uses the new answer; failed workers' stubborn descendants cannot retain pipes; parallel failure stops its siblings while preserving an unrelated run; sequential children share one phase deadline and later work does not start. |
| Sync-absent installed viewer | Actual browser and API checks confirm settings/community contain no unconditional Sync recommendations; author, repository and module paths remain available, with no page errors. |
| Independent customization journey | 44 public calls using the final archive: discover its own module-building example, customize and run it, exact worker handoff/answer/replay, actual user-wait persistence and fixture response, export/import state isolation, copy-only module removal, archive reference before/after materialization, and packaged historical sample loading. |

The policy fixture children deliberately use an absolute installed Python interpreter. The Metaform runtime under test still runs as the standalone `-S` archive; these fixtures do not require or invoke a model provider. The independent user-wait probe supplies a fixture user's response. These checks establish runtime behavior and delivery, not the quality of future model-generated answers or every external tool integration.

The stdout-pressure check measures the real pipe capacity with `F_GETPIPE_SZ` and waits for `FIONREAD` to reach that capacity before interrupting. Failed schema registration and a short error response cannot satisfy it; independent negative controls confirmed this. Signal/process-group checks here target Linux, matching CI.

## Retained evidence and reproduction

[Final matrix summary](reviews/final-distribution/summary.json), [build provenance](reviews/final-distribution/provenance.json), [Python 3.11 dependencies](reviews/final-distribution/dependencies311.json), and [Python 3.13 dependencies](reviews/final-distribution/dependencies313.json) record the exact artifacts, interpreters and resolved libraries. Fresh installations used MCP 2.2.0 and AnyIO 4.15.1.

The complete output is in [final-distribution](reviews/final-distribution/): `distribution311.log`, `distribution313.log`, `inventory.log`, `shutdown311.log`, `shutdown313.log`, `workfolder.log`, `reference.log`, `policy311.log`, and `policy313.log`. The independent journey has its own [summary](reviews/2026-09-11-final-customization.json) and [complete transcript](reviews/2026-09-11-final-customization-transcript.json). The final installed viewer has separate [Sync-absent evidence](reviews/2026-09-11-final-sync-absent-viewer.json).

CI now runs all six retained tools against the built artifact:

- `tools/check_distribution.py` accepts an optional explicit wheel path and records import origin and hash.
- `tools/check_distribution_shutdown.py` exercises actual entrypoint processes, worker cleanup and build cancellation.
- `tools/check_workfolder_distribution.py` transfers active work and applies the complete artifact changes.
- `tools/check_reference_distribution.py` exercises broken-module recovery without mutating project state.
- `tools/check_policy_distribution.py` uses one shared journey for installed and standalone operation.
- `tools/check_customization.py` uses the artifact's own reference and public commands.

Run the first five with the freshly installed wheel's interpreter. The shutdown, workfolder, reference and policy tools accept `--portable-python` for a separate standalone interpreter. The customization tool accepts the archive and a fresh output directory and invokes it with `-S`.

## Failures found before final delivery

Earlier candidates are historical evidence, not the final distribution. Candidate one (`bea1ca02…`) passed basic delivered journeys but exposed an installed MCP initialized-notification/SIGINT race and omitted empty source directories during transfer. Candidate two (`8423b535…`) verified both corrections but preceded the final corpus, metadata and execution policies.

The fully verified `6c1ae3a5…` candidate was then superseded by a late correction removing unconditional Sync instructions from the viewer. Its [retained evidence](reviews/verified-candidate-6c1ae3a5/) remains historical; every final matrix process and the independent customization/browser journeys were rerun against `2432498b…`.

Further read-only audits reproduced malformed custom declarations disabling help/reference, parser failures from malformed nested metadata, retry exhaustion being bypassed after an interrupted terminal-state save, sampling siblings remaining active after phase failure, and manual resumption consuming a failed attempt's stale response. The final artifact checks above verify the delivered corrections; the source-only exhausted-budget and waiting-sampling reproductions were independently rerun after repair.

Historical reproductions remain in [malformed artifact reference](reviews/2026-09-11-artifact-malformed-reference.json), [nested source metadata](reviews/2026-09-11-source-malformed-structure.json), [policy adversarial findings](reviews/2026-09-11-policy-adversarial.json), [manual retry finding](reviews/2026-09-11-policy-no-policy-resume.json), and [corrected independent policy results](reviews/2026-09-11-policy-adversarial-fixed.json). Semantic completeness and the seven actual model-produced conversions have their own review and inference records; artifact presence alone is not their proof.
