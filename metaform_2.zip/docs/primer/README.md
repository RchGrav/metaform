# Inference Metaform primer

These narrative explanations introduce Metaform's approach and mechanisms.
These supplied texts are retained as historical narrative. The
[canonical specification](../SPEC.md) defines the current semantic contract and
acceptance scenarios. Its one-foundation intake and attached knowledge layers
supersede the independent-graph and automatic two-pass mechanics described here.

The [semantic source rules](../semantics/README.md) are available alongside this
primer.

| Document | What it covers |
| --- | --- |
| [Full explanation](01_full_explanation.md) | Previously performed inference, contextual and latent understanding, Encounter propagation, prompting, and higher-order work. |
| [Specification introduction](02_specification_introduction.md) | A concise introduction to the approach and its principal relationships. |
| [Technical account](03_technical_account.md) | Semantic construction, provenance, type structure, propagation, identity, and inference reuse. |
| [Combined edition](inference_metaform_documentation.md) | All three explanations together, in their supplied order. |

Start with the full explanation for the narrative, or the specification
introduction for a shorter overview. The technical account develops the
mechanisms in more detail.

[Return to the project README](../../README.md)
