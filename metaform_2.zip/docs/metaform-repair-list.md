# Metaform Repair List

> Current work is reconciled in [repair-backlog.md](repair-backlog.md) and tracked in [release-quality-status.md](release-quality-status.md). This original review retains its recorded snapshot; its repair claims do not supersede current verification.

**Date:** September 11, 2026  
**Baseline:** `realignment-2026-09-10` at `d264f512ceba89cf3a5152f66cdc60c0e1a06ba4`  
**Deliverable:** 50 repair and verification items. No implementation changes are included.

## Target outcome

A fresh user and a fresh AI agent can start with the distributed Metaform executable alone, understand what it can do, select the actual project, and carry an operation through completion using instructions supplied by the system. Module-organized help, documented commands and settings, coherent defaults, and a clean exit are baseline product quality—not optional personal preferences.

The user-facing agent is the concierge in the chosen harness. It discovers capabilities and workflows, initiates work, communicates with the user, and follows returned actions. The workflow owns worker assignments. The chassis owns assignment identity, folders, persistence, cleanup, and working-copy change tracking. The system’s own functional Metaform supports deeper customization and integration without turning the initial skill into a development manual.

## Scope and evidence

This backlog consolidates the conversation, the earlier pinned source inspection, retained runtime and module-removal probes, and new isolated checks of the distributed executable and configuration behavior. It is not a claim that all 50 entries are newly discovered bugs. Entries distinguish reproduced defects, source-confirmed omissions, agreed design gaps, and verification still needed.

The complete repository was not downloaded. The packaged runtime was available in full; selected repository documentation and the root-level prompt corpus were read through GitHub. The full test suite and live conversion of the corpus were not rerun. The user’s Python 3.10 interrupt trace remains user-reported, with a source-supported investigation lead. Findings apply to the pinned build, not to uninspected later changes.

Priority is suggested repair order: **P0** covers current state contamination, invalid continuation, or unusable shutdown; **P1** covers the core product and integration contract; **P2** covers the supporting test-quality audit. These labels are backlog ordering, not new conditions inside imported workflows.

### Evidence already in hand

| Observation | Result | Evidence |
|---|---|---|
| Bundled manifest inventory | 26 modules; 111 command declarations; 1 module description; 35 of 287 parameter declarations described; no command-declared examples | E04 |
| `python metaform --help` from clean `dist` | Bare module choices; creates project model/state files in `dist/.metaform`; no defaults file | E04 |
| Configuration update | A project override is written into home configuration; the current App remains stale | E04 |
| Remove Intake/Enumerator registrations | Commands disappear but skill remains unchanged and guide recommends absent `intake.start` | E03 |
| Complete a retained-folder assignment | Marker remains, enters diff, is applied to source, and rebinds source to completed work | E01 |
| Whole-folder tracking | Ignored Git-root source file omitted; ignored plain-folder edit absent from diff; JSON knowledge selects non-Git tracking | E01 |
| Workflow mechanics | Stored handoff, repeated next, conversion submission/application, conditional routes, nested calls, iteration, and snapshots exercised with fixtures | E01, E02 |
| Complex prompt conversion | Actual model-generated corpus conversion has not yet been established | E02, S11 |

## Repair index

| ID | Repair | Priority | Evidence status |
|---|---|---|---|
| R01 | Make top-level help a readable module directory | P1 | Reproduced; source-confirmed |
| R02 | Complete the reference supplied by every module | P1 | Measured documentation gap |
| R03 | Give a no-argument launch an actual starting point | P1 | Source-confirmed; agreed product requirement |
| R04 | Keep help inspection from initializing the dist directory as a project | P1 | Reproduced |
| R05 | Present human guidance and machine results without confusing them | P1 | Source-confirmed; agreed product requirement |
| R06 | Explain the command inventory and its module ownership | P1 | Measured inventory; organization review needed |
| R07 | Remove feature-specific dispatch that bypasses module registration | P1 | Source-confirmed; removal paths need broader verification |
| R08 | Create a discoverable settings file with real defaults | P1 | Source-confirmed; requested baseline behavior |
| R09 | Let modules supply their own settings descriptions and defaults | P1 | Source-confirmed metadata gap |
| R10 | Show effective values, their source, and precedence | P1 | Source-confirmed; usability gap |
| R11 | Stop project overrides leaking into home configuration | P0 | Reproduced |
| R12 | Make settings changes take effect coherently in running sessions | P1 | Reproduced; nested-update semantics also need clarification |
| R13 | Reduce the standing skill to the concierge’s actual role | P1 | Source-confirmed |
| R14 | Make features and workflows supply the operative instructions | P1 | Partial implementation; agreed responsibility boundary |
| R15 | Make onboarding recommendations follow the live module registry | P0 | Reproduced |
| R16 | Make MCP orientation concise, current, and refreshable | P1 | Source-confirmed; cross-transport verification needed |
| R17 | Make the skill command’s output and effect unambiguous | P1 | Source-confirmed; user-reported confusion |
| R18 | Connect human and AI onboarding to the same project-aware process | P1 | Partial implementation; agreed behavior |
| R19 | Expose an actual catalog of available workflows | P1 | Reproduced discovery gap |
| R20 | Distinguish literal prompt import from workflow conversion | P1 | Source-confirmed; interface gap |
| R21 | Analyze the source procedure before assigning executable structure | P1 | Conversion quality not yet demonstrated on the corpus |
| R22 | Translate agent responsibilities into real assignments and context boundaries | P1 | Core importer requirement; live evidence outstanding |
| R23 | Preserve authored branching, iteration, parallelism, and dependencies | P1 | Engine primitives partly exercised; semantic conversion unverified |
| R24 | Represent required user interaction as workflow state | P1 | Source requirement; runtime representation needs explicit verification |
| R25 | Preserve literal source, placeholders, examples, and output contracts | P1 | Source complexity confirmed; conversion checks outstanding |
| R26 | Carry artifact production and tool use across the workflow boundary | P1 | Corpus requirement; integration verification outstanding |
| R27 | Preserve authored meaning through conversion and specialization | P1 | Agreed semantic requirement; corpus-specific verification outstanding |
| R28 | Evaluate conversion using the actual root-level prompt corpus | P1 | Evaluation not yet performed |
| R29 | Ship the source prompts and reusable workflows inside the distribution | P1 | Requested capability; current corpus packaging not established |
| R30 | Return a handoff command that works in the actual execution environment | P1 | Source-confirmed; earlier live report noted launcher recovery |
| R31 | Clear completed assignment markers in retained development folders | P0 | Reproduced |
| R32 | Retire active nonce lookups while retaining execution history | P1 | Reproduced persistence; intended cleanup incomplete |
| R33 | Preserve exact request binding and replay semantics during the repairs | P1 | Existing behavior to retain; broader checks needed |
| R34 | Unify fresh-folder completion with durable result retention | P1 | Partly reproduced as working; shared lifecycle verification |
| R35 | Make progress and next actions explicit to the concierge | P1 | Partial implementation; delivery gap |
| R36 | Include ignored working content in the initial workfolder snapshot | P1 | Reproduced |
| R37 | Include ignored-content changes in workfolder diffs | P1 | Reproduced |
| R38 | Keep ephemeral agent identity out of patches and source projects | P0 | Reproduced end-to-end failure |
| R39 | Separate Git change tracking from the knowledge storage backend | P1 | Reproduced |
| R40 | Make the actual edit location and its baseline explicit | P1 | Source-confirmed; coverage verification needed |
| R41 | Repair Ctrl-C shutdown rather than merely hiding its traceback | P0 | User-reported; source-supported lead, exact environment not reproduced |
| R42 | Keep shutdown, abort, and resume behavior consistent with durable runs | P1 | Lifecycle integration requires verification |
| R43 | Verify the direct executable, installed command, and MCP connection as delivered | P1 | Distribution requirement; reported environment differs from earlier probes |
| R44 | Implement the chassis’s own functional Metaform | P1 | Explicit existing design requirement; documented as unimplemented |
| R45 | Connect self-understanding to installed capabilities without making it a static catalog | P1 | Agreed architecture alignment |
| R46 | Provide the public integration interface described by the design | P1 | Source-confirmed; documented design gap |
| R47 | Demonstrate end-user customization as one complete workflow | P1 | Requested outcome; end-to-end proof outstanding |
| R48 | Test the shipped user journeys rather than just internal handlers | P1 | Observed coverage gap |
| R49 | Review existing tests for purpose, redundancy, and semantic reach | P2 | Audit required; no unsupported test-quality verdict |
| R50 | Close repairs with reproducible evidence and synchronized built-in documentation | P1 | Delivery requirement |

## Detailed repair backlog

## 1. CLI, navigation, and built-in reference

### R01 — Make top-level help a readable module directory

**Priority:** P1 · **Status:** Reproduced; source-confirmed

**Problem:** The distributed program’s --help output presents a long comma-separated list of module identifiers. Its readable descriptions cover the manually added top-level entries, not the discovered modules. Module grouping exists internally but is not explained at the entry point.

**Repair:** Render each discovered module as a readable entry with its name, purpose, and route to detailed help. Use module metadata rather than another hand-maintained catalog. Give the usage synopsis a compact presentation instead of repeating every choice in a dense block.

**Completion evidence:** Run python metaform --help from a clean dist directory. A newcomer can distinguish the modules, understand their purposes, and find the next level without opening source files.

**Relevant locations:** src/metaform/cli.py::run_parser; src/metaform/data/modules/*.json. **Sources:** E04, S01, S03.

### R02 — Complete the reference supplied by every module

**Priority:** P1 · **Status:** Measured documentation gap

**Problem:** The inspected artifact has 26 module manifests and 111 command declarations. Only one module has a module-level description; 109 commands have short descriptions, but only 35 of 287 parameter declarations have descriptions. None declares command examples. These are manifest counts, not a claim that no examples exist elsewhere.

**Repair:** Have each module ship its purpose, command descriptions, argument meanings, required inputs, defaults, output meanings, and useful invocation examples. Explain lifecycle-sensitive operations such as start, answer, apply, and cleanup in operational terms. Package detailed reference alongside that module.

**Completion evidence:** For each declared command, the executable can explain what it does, what to supply, what it returns, and a usable example. Configuration and workflow-conversion help must explain their input objects rather than just naming them.

**Relevant locations:** src/metaform/data/modules/*.json; src/metaform/registry.py::Command.definition; CLI and MCP help readers. **Sources:** E04, S02, S03.

### R03 — Give a no-argument launch an actual starting point

**Priority:** P1 · **Status:** Source-confirmed; agreed product requirement

**Problem:** A normal launch without a selected command falls back to parser help. Project-aware guidance exists elsewhere, but the first interaction does not bring the user to it.

**Repair:** Make normal startup explain Metaform briefly and offer the applicable begin-or-resume path. Direct users to project selection, onboarding, existing work, and AI connection through installed capabilities. Let the runtime determine the actual next operation instead of duplicating the whole process in introductory prose.

**Completion evidence:** A fresh user starts the distributed program and reaches project selection or an applicable continuation without knowing guide.start or consulting the repository.

**Relevant locations:** src/metaform/cli.py::main/run_parser; src/metaform/onboarding.py; src/metaform/modules/guide.py. **Sources:** S01, S05.

### R04 — Keep help inspection from initializing the dist directory as a project

**Priority:** P1 · **Status:** Reproduced

**Problem:** In a fresh disposable dist directory, requesting help created .metaform/metaform.json, state.sqlite3, and a lock file. CLI setup opens an App before argparse handles --help, so inspecting the executable also creates project state in its launch directory.

**Repair:** Resolve ordinary command/reference discovery without initializing a working project. Keep the executable’s location, invocation directory, and selected work target distinct. Project creation belongs to the actual startup/onboarding operation, not to printing reference information.

**Completion evidence:** Record the filesystem before and after top-level and nested --help calls. No project database or model is created merely by reading help; subsequent onboarding uses the actual selected target, not dist by accident.

**Relevant locations:** src/metaform/cli.py::main; src/metaform/app.py::App.__init__; registry initialization. **Sources:** E04, S01, S04.

### R05 — Present human guidance and machine results without confusing them

**Priority:** P1 · **Status:** Source-confirmed; agreed product requirement

**Problem:** The CLI generally serializes command results as JSON, while skill prints a long Markdown document. These outputs do not consistently tell a human whether they are reading documentation, seeing current state, or being instructed to take an action.

**Repair:** Give user-facing entry, help, and status views concise explanations with a discoverable route to complete details. Keep machine-readable results available for agents and retain the same underlying meaning. Identify reference text, active assignments, and next actions distinctly; human formatting must not damage MCP transport output.

**Completion evidence:** A user can read startup and progress without interpreting an assignment payload. An agent receives the complete structured action/result through its actual transport, with no human banner inserted into a protocol stream.

**Relevant locations:** src/metaform/cli.py; src/metaform/onboarding.py; src/metaform/mcp_server.py; src/metaform/portable_mcp.py. **Sources:** S01, S05, S06.

### R06 — Explain the command inventory and its module ownership

**Priority:** P1 · **Status:** Measured inventory; organization review needed

**Problem:** The 111 declarations mix user operations, workflow-worker access, project/model inspection, and administration. A large count alone does not establish redundancy, and some similarly named commands intentionally operate in different assignment contexts.

**Repair:** Produce a command-by-command ownership/reference inventory from the manifests. Explain each operation’s purpose and context, and distinguish settings from operations. Identify actual duplicate responsibilities for a separate consolidation decision instead of deleting commands solely to make the count smaller.

**Completion evidence:** Every exposed operation can be traced to a module and explained in its working context. The user can answer “where did this command come from?” from the tool itself.

**Relevant locations:** src/metaform/registry.py::discover/visible; src/metaform/modules/system.py::modules; module manifests. **Sources:** E04, S02, S03, S04.

### R07 — Remove feature-specific dispatch that bypasses module registration

**Priority:** P1 · **Status:** Source-confirmed; removal paths need broader verification

**Problem:** The CLI contains direct feature dispatch before the registry, including browse calling the viewer implementation. Removing a module’s registration therefore does not necessarily remove every path to that feature. The earlier removal probe covered Intake and Enumerator registrations, not every shortcut.

**Repair:** Make public feature commands and their convenience entry points resolve through the owning module. Keep launcher/transport mechanics distinct from module functionality. Audit the existing skill, browse, install, begin, project, and service special cases against that boundary rather than inventing a new parallel command catalog.

**Completion evidence:** Removing a module removes its callable feature entry points and active help references. An alias cannot continue calling a deregistered feature through a direct Python import.

**Relevant locations:** src/metaform/cli.py::main/run_parser; src/metaform/registry.py; owning module manifests. **Sources:** S01, S02, E03.

## 2. Settings and defaults

### R08 — Create a discoverable settings file with real defaults

**Priority:** P1 · **Status:** Source-confirmed; requested baseline behavior

**Problem:** Configuration readers fall back to values in Python code, and a normal help inspection does not produce a usable settings reference or defaults file. Having a configure command is not the same as supplying a complete settings experience.

**Repair:** During actual initialization/setup, materialize persistent settings with the applicable defaults in a clearly reported location. Retain existing user choices. Distinguish service/user configuration from project and portable-copy configuration, and keep transient assignment identity in runtime state rather than treating it as a preference.

**Completion evidence:** A new installation shows where its settings live and starts with usable documented defaults. A second initialization leaves edits intact. Reading --help remains non-mutating.

**Relevant locations:** src/metaform/app.py; src/metaform/modules/system.py::configure; src/metaform/installation.py; module configuration metadata. **Sources:** E04, S04.

### R09 — Let modules supply their own settings descriptions and defaults

**Priority:** P1 · **Status:** Source-confirmed metadata gap

**Problem:** system.configure advertises settings as an object without describing its supported contents. Module manifests currently have no settings/default declarations, while modules read configuration values directly from the shared App.

**Repair:** Have each configurable module publish its persistent setting names, meanings, types, defaults, scope, and examples. Assemble the reference/defaults from installed modules so community modules participate without editing a central hardcoded settings list.

**Completion evidence:** Adding a configurable module makes its settings explainable through CLI and MCP reference. Updating unrelated settings preserves existing module configuration; removing a module stops advertising its settings as active capabilities.

**Relevant locations:** src/metaform/data/modules/system.json; module manifests; src/metaform/modules/system.py; configuration readers. **Sources:** E04, S03, S04.

### R10 — Show effective values, their source, and precedence

**Priority:** P1 · **Status:** Source-confirmed; usability gap

**Problem:** App combines home and project configuration and then applies portable-mode behavior. Users cannot readily tell which file or mode supplied the value they are observing.

**Repair:** Expose the resolved configuration with its relevant source and scope. Explain the existing home/project precedence, invocation/environment selectors, and portable-mode overrides. Display the actual active paths so users do not edit a file that this invocation will not read.

**Completion evidence:** A project override and a portable invocation both show the effective setting and why it differs from the default. Documentation and runtime behavior agree.

**Relevant locations:** src/metaform/app.py::App.__init__/project_path; src/metaform/modules/system.py; packaged settings reference. **Sources:** S04, E04.

### R11 — Stop project overrides leaking into home configuration

**Priority:** P0 · **Status:** Reproduced

**Problem:** configure merges the already-resolved app.config with the requested settings, then writes that entire result to app.home/config.json. In the probe, changing debug also persisted the project’s sampling_max_tokens=2048 over the home value of 8192.

**Repair:** Apply updates to the selected persistent scope’s own configuration rather than serializing the merged effective view. Preserve unrelated project and home choices, including portable-mode distinctions.

**Completion evidence:** Repeat the two-scope probe: updating debug in home configuration does not copy the project-specific token setting there, and another project still sees the original home default.

**Relevant locations:** src/metaform/modules/system.py::configure; src/metaform/app.py configuration merge. **Sources:** E04, S04.

### R12 — Make settings changes take effect coherently in running sessions

**Priority:** P1 · **Status:** Reproduced; nested-update semantics also need clarification

**Problem:** The same probe returned configured debug=true and wrote it to disk, but the existing App.config remained unchanged. A long-lived session can therefore report one configuration while continuing with another.

**Repair:** Refresh or replace the active configuration consistently after a change and explain any setting that takes effect only on a subsequent operation or restart. Define nested-object update behavior so edits to a harness or module do not accidentally erase sibling settings.

**Completion evidence:** In one running session, a configuration write is followed by a read and an operation that observe the documented effective value. An unrelated module or harness entry survives the update.

**Relevant locations:** src/metaform/modules/system.py::configure/debug; src/metaform/app.py; session-owned Apps. **Sources:** E04, S04, S06.

## 3. Concierge, onboarding, and live guidance

### R13 — Reduce the standing skill to the concierge’s actual role

**Priority:** P1 · **Status:** Source-confirmed

**Problem:** The packaged skill contains onboarding procedures, Enumerator mechanics, response-field examples, and transport details. It repeats instructions that the current feature or assignment should supply.

**Repair:** Keep the standing introduction focused on Metaform’s purpose, the concierge role, capability discovery, and following returned continuations. Move feature execution details into feature-owned guidance and move worker response contracts into the worker assignment. Keep deeper system knowledge discoverable.

**Completion evidence:** A fresh concierge can begin without receiving the Enumerator’s qN_array schema or a manual for every module. The worker still receives its complete schema when that assignment starts.

**Relevant locations:** src/metaform/data/skills/metaform/SKILL.md; src/metaform/onboarding.py::skill_text/instructions. **Sources:** S05, E03.

### R14 — Make features and workflows supply the operative instructions

**Priority:** P1 · **Status:** Partial implementation; agreed responsibility boundary

**Problem:** The runtime already stores worker assignments and returns some guidance/next actions, but the static skill separately narrates execution. This divides procedural authority between standing prose and runtime responses.

**Repair:** Make the selected feature/workflow supply what the concierge must do now, including any user interaction, dispatch, response route, and continuation. Deliver the stored worker instructions to the executing worker. Retain explanatory documentation separately from current execution instructions.

**Completion evidence:** Trace a complete operation: each concrete action follows a runtime response, and the worker executes the stored prompt. The concierge never has to reconstruct the procedure or rewrite the worker assignment from general documentation.

**Relevant locations:** src/metaform/onboarding.py; src/metaform/workflow.py; src/metaform/continuation.py; feature modules. **Sources:** E01, S05, S07, S08.

### R15 — Make onboarding recommendations follow the live module registry

**Priority:** P0 · **Status:** Reproduced

**Problem:** Removing Intake and Enumerator registrations removed their commands, but the unchanged skill still named them and guide.start still recommended intake.start. Dispatching that recommendation failed with Unknown command.

**Repair:** Derive feature availability and feature-specific onboarding instructions from the installed modules. Preserve the declared onboarding intent while clearly reporting an unavailable required capability rather than pretending its command exists. Do not maintain a second hardcoded list of active modules in the guide.

**Completion evidence:** Repeat removal and restoration of the tested module registrations. No guide or active skill section recommends an absent operation, and the restored module becomes discoverable without manual text edits.

**Relevant locations:** src/metaform/onboarding.py::guide_state; src/metaform/registry.py; module-supplied guidance. **Sources:** E03, S02, S05.

### R16 — Make MCP orientation concise, current, and refreshable

**Priority:** P1 · **Status:** Source-confirmed; cross-transport verification needed

**Problem:** Startup instructions concatenate the entire skill and guide state, including command schemas. Static guidance can remain attached to an earlier project/module context, while some read paths repeat a large amount of material.

**Repair:** Supply a compact bootstrap and current project/capability summary, with detailed module reference available on demand. Refresh operational guidance after project, module, or run-state changes through the applicable MCP path. Preserve the protocol-specific tool exposure already implemented rather than assuming every client behaves identically.

**Completion evidence:** Connect, select another project, install/remove a module, and resume a run. The host retrieves current guidance and matching callable operations without receiving the full manual at every step.

**Relevant locations:** src/metaform/mcp_server.py; src/metaform/portable_mcp.py; src/metaform/onboarding.py; project session. **Sources:** S05, S06, E03.

### R17 — Make the skill command’s output and effect unambiguous

**Priority:** P1 · **Status:** Source-confirmed; user-reported confusion

**Problem:** skill prints packaged Markdown and exits. It does not register an integration with the current AI harness, yet the entry experience does not adequately distinguish exported guidance from an installed or active skill.

**Repair:** Explain, in the tool’s own help, whether this operation prints, exports, installs, or activates anything. Supply a concise usable bootstrap artifact and the actual connection/use instructions for the selected harness or CLI path. Let feature detail remain module-provided.

**Completion evidence:** A user can tell what running skill did, how an AI receives the content, and how to start actual work. The command does not imply an integration has been installed merely because it printed text.

**Relevant locations:** src/metaform/cli.py skill branch; src/metaform/modules/guide.py; packaged skill/help. **Sources:** S01, S05.

### R18 — Connect human and AI onboarding to the same project-aware process

**Priority:** P1 · **Status:** Partial implementation; agreed behavior

**Problem:** The required onboarding sequence exists in guide code and the specification, but the delivered entry experience does not lead a fresh user and a fresh AI through it together.

**Repair:** Guide selection of the actual project, repository or supplied plan, applicable intake/resumption, web-view access, Best Practices generation, and default-layer selection through current runtime actions. Preserve a supplied plan literally and treat its intended design as the subject. Preserve an already-selected layer and existing completed work.

**Completion evidence:** Demonstrate a repository, a non-repository folder, a plan-based start, and a resumed project using the shipped tool alone. Each reaches the correct state without treating dist or the plan document itself as the intended artifact.

**Relevant locations:** src/metaform/onboarding.py; modules/guide.py, project.py, intake.py; layer selection; docs/SPEC.md §13. **Sources:** S05, S10.

### R19 — Expose an actual catalog of available workflows

**Priority:** P1 · **Status:** Reproduced discovery gap

**Problem:** The guide lists workflow commands but did not list a workflow imported in the probe. Knowing that workflow.start exists does not tell the concierge which reusable procedures it can offer.

**Repair:** Expose stored workflow identities, purposes, source/origin, required inputs, and how to start them. Include embedded and user-created workflows through the same discovery path, with relevant dependencies and current availability explained.

**Completion evidence:** Import a custom workflow, refresh discovery, and start it from the returned catalog information. The concierge does not have to invent an ID or search raw graph storage to learn what can be run.

**Relevant locations:** src/metaform/onboarding.py; src/metaform/modules/workflow.py; graph-backed workflow records. **Sources:** E01, S05, S07.

## 4. Workflow import, semantic conversion, and the embedded library

### R20 — Distinguish literal prompt import from workflow conversion

**Priority:** P1 · **Status:** Source-confirmed; interface gap

**Problem:** workflow.import can retain prose as an exact prompt, while workflow.convert commissions a model to produce an executable definition and workflow.apply stores the result. These are different operations, but the onboarding/reference does not make that distinction adequately useful.

**Repair:** Explain and expose the difference: retaining a prompt is not evidence that its roles, branches, or loops were converted. Provide an understandable route from source prompt to analysis, generated definition, reusable workflow, and execution, using the existing machinery.

**Completion evidence:** Import a multi-role source both ways. The tool accurately identifies the literal-prompt result and the converted procedure; it never labels one large delegated prompt as proven multi-agent conversion.

**Relevant locations:** src/metaform/modules/workflow.py::import_file/convert/apply; workflow import helpers; built-in reference. **Sources:** S07, E02.

### R21 — Analyze the source procedure before assigning executable structure

**Priority:** P1 · **Status:** Conversion quality not yet demonstrated on the corpus

**Problem:** The conversion path supplies source text and an execution grammar, but the earlier local probe supplied a hand-authored answer. It proved conversion transport/application, not whether a model understands a complex source prompt.

**Repair:** Refine conversion so it identifies the source goal, roles, user interactions, inputs, intermediate outputs, dependencies, conditions, repetition, and completion behavior. Retain a reviewable mapping between source responsibilities and generated workflow structure so omissions and added behavior can be located.

**Completion evidence:** For a real root-level source prompt, compare the generated structure to a source-derived account. Each operative requirement has a destination or an explicitly explained unresolved representation; syntactically valid JSON alone is not the result.

**Relevant locations:** src/metaform/modules/workflow.py::convert; src/metaform/data/prompts.json; conversion role composition and retained outputs. **Sources:** S07, S11, E02.

### R22 — Translate agent responsibilities into real assignments and context boundaries

**Priority:** P1 · **Status:** Core importer requirement; live evidence outstanding

**Problem:** The corpus explicitly distinguishes developers, evaluators, planners, and other specialists. Several require independent context. A list of persona labels inside one prompt would not realize that separation.

**Repair:** Generate actual specialist assignments where the source requires delegation. Supply each with the evidence and prior outputs its work needs. Separate context according to the authored role requirements; the concierge performs transport and user interaction rather than composing every specialist prompt.

**Completion evidence:** Execute the dual-agent source and an artifact-only evaluator source. Record separate assignment IDs, delivered prompts, selected context, and return paths, demonstrating that required independent workers received the intended evidence.

**Relevant locations:** src/metaform/modules/workflow.py; workflow.py assignment preparation; continuation.py; harness.py; corpus dual_agent.md and extractor.md. **Sources:** S07, S08, S11.

### R23 — Preserve authored branching, iteration, parallelism, and dependencies

**Priority:** P1 · **Status:** Engine primitives partly exercised; semantic conversion unverified

**Problem:** Conditional routing, nested calls, iteration, and snapshots worked in local fixtures. Real source prompts additionally express per-task repair loops, phase barriers, optional documentation, and specified retry behavior. The converter’s grammar, engine capabilities, and reference documentation need one consistent account.

**Repair:** Translate the source’s actual dependencies and control flow into the existing engine constructs. Include parallel phases where authored, join their required results, and preserve loop inputs/outputs. Reconcile grammar/documentation drift; resolve any primitive genuinely missing for these sources without silently substituting a different process.

**Completion evidence:** Exercise both sides of a generated condition, a repeated task, nested calls, and a phase with concurrent workers followed by a dependent phase. Compare execution to the source, including its authored retry/termination behavior.

**Relevant locations:** src/metaform/modules/workflow.py::convert execution_grammar; src/metaform/workflow.py; src/metaform/logic.py; docs/workflows.md. **Sources:** E02, S07, S11.

### R24 — Represent required user interaction as workflow state

**Priority:** P1 · **Status:** Source requirement; runtime representation needs explicit verification

**Problem:** Several corpus prompts require a question, permission response, plan approval, or final feedback. The documented engine kinds do not by themselves establish a distinct user-wait contract; treating all requests as model answers risks manufacturing the user’s response.

**Repair:** Ensure the workflow can issue the authored user-facing request through the concierge, retain the correct suspended continuation, and accept the actual reply. Support resumption and source-directed feedback loops. Add no approval stages beyond those in the imported source or an explicitly requested operation.

**Completion evidence:** Convert a prompt with an authored plan-review pause. The concierge asks the intended question, the workflow remains resumable, and the actual user response selects the next action. A worker does not answer on the user’s behalf.

**Relevant locations:** src/metaform/workflow.py; modules/workflow.py; returned action/assignment representation; CLI/MCP concierge paths. **Sources:** S07, S11.

### R25 — Preserve literal source, placeholders, examples, and output contracts

**Priority:** P1 · **Status:** Source complexity confirmed; conversion checks outstanding

**Problem:** The corpus mixes prose, XML-like sections, YAML agent configurations, JSON examples, and placeholders. metaprompt.md generates a prompt rather than performing the task described by that generated prompt. python_to_c.md also includes illustrative data and named dependencies not fully defined within that file.

**Repair:** Distinguish instructions from quoted examples, supplied input from template variables, and generated prompts from instructions to execute immediately. Retain literal source and bind values deliberately. Carry actual output contracts into the correct worker; report unresolved source references without inventing supporting agents or findings.

**Completion evidence:** Metaprompt conversion produces the intended prompt artifact, not an accidental execution of it. Example timestamps/files remain examples, placeholders receive the correct inputs, and unresolved referenced components remain visible as such.

**Relevant locations:** src/metaform/modules/workflow.py::convert/apply; src/metaform/prompts.py; templating; prompts/metaprompt.md and python_to_c.md. **Sources:** S07, S11.

### R26 — Carry artifact production and tool use across the workflow boundary

**Priority:** P1 · **Status:** Corpus requirement; integration verification outstanding

**Problem:** The sources name output files, documentation folders, shared context, tools, and harness-specific command locations. The workflow must move more than a short natural-language answer between specialists.

**Repair:** Represent authored artifact destinations, dependencies, and tool operations in the working context supplied by Metaform. Translate harness-specific invocation details through the actual selected interface while retaining their operative purpose and recording the mapping. Return artifact locations and the next continuation to the concierge.

**Completion evidence:** A converted documentation workflow creates its intended artifacts, later roles read the correct versions, and the final result identifies the actual files. The same test launched from an isolated workfolder does not depend on a repository-relative launcher that is absent there.

**Relevant locations:** src/metaform/workflow.py; src/metaform/workfolders.py; src/metaform/actor.py; harness.py; importer outputs. **Sources:** S07, S08, S09, S11.

### R27 — Preserve authored meaning through conversion and specialization

**Priority:** P1 · **Status:** Agreed semantic requirement; corpus-specific verification outstanding

**Problem:** Importing complex prompts creates opportunities to change obligations while making the output look cleaner. The source corpus itself contains explicit approval, coverage, critique, and stopping conditions; those are not universal chassis policies.

**Repair:** Preserve the source’s operative requirements, prompt identity, role boundaries, and conditions. Keep specialization’s project grounding separate from source intent. Do not add new quality gates or remove source-authored ones by substituting the repair agent’s own habits. Record any necessary interface adaptation as an explicit mapping.

**Completion evidence:** Compare source and generated behavior for a gated and a non-gated source. Existing conditions remain specific to their source, unrelated constraints do not appear, and specialization changes context without silently changing the procedure.

**Relevant locations:** src/metaform/modules/workflow.py::specialize/convert/apply; prompts.py; docs/SPEC.md §9 and workflow-specialization acceptance scenario. **Sources:** S07, S10, S11.

### R28 — Evaluate conversion using the actual root-level prompt corpus

**Priority:** P1 · **Status:** Evaluation not yet performed

**Problem:** The seven root-level prompt documents provide materially different conversion cases. Earlier evidence established runtime control flow using fixtures; it did not establish faithful model-produced conversion of this corpus.

**Repair:** Create a corpus review using the source-derived expectations in the matrix below. Save actual converter assignments, model responses, executable definitions, and representative executions. Assess omissions, added conditions, incorrect role/context placement, wrong outputs, and broken continuation separately from schema validity.

**Completion evidence:** Publish per-source findings with concrete source-to-output examples, including any unresolved or failed cases. Keep model-derived semantic results distinct from deterministic engine tests.

**Relevant locations:** prompts/*.md listed in the corpus matrix; existing prompt test/convert machinery; examples for retained evaluation evidence. **Sources:** E02, S07, S11.

### R29 — Ship the source prompts and reusable workflows inside the distribution

**Priority:** P1 · **Status:** Requested capability; current corpus packaging not established

**Problem:** The user wants these procedures embedded in the system, not stranded in a development repository. Presence in prompts/ does not establish that the executable ships and registers a corresponding reusable workflow library.

**Repair:** Package the source prompts, converted definitions, referenced prompt/schema dependencies, descriptions, inputs, and source revisions. Register them through the same workflow discovery as user-created procedures. Retain user customizations on updates and distinguish a source template with unresolved dependencies from a fully demonstrated procedure.

**Completion evidence:** From the distributed artifact without the repository, discover a bundled procedure, inspect its source/purpose, supply its inputs, and execute it. Customize a copy and show that a distribution refresh does not silently replace that authored copy.

**Relevant locations:** src/metaform/packaging.py; prompt/workflow seeding; package data; src/metaform/modules/workflow.py; workflow catalog. **Sources:** S07, S11, S12.

## 5. Handoff, identity, and assignment lifecycle

### R30 — Return a handoff command that works in the actual execution environment

**Priority:** P1 · **Status:** Source-confirmed; earlier live report noted launcher recovery

**Problem:** publish currently emits python -m metaform begin <nonce>. That instruction assumes an importable installation. The distributed executable and an empty worker folder are different launch contexts, and a copied relative launcher may not exist there.

**Repair:** Derive the concrete worker invocation from the executable/installation and selected harness actually in use. Return its working folder, nonce, invocation context, and response route. Keep the handoff independent of a guess by the concierge about paths or installation state.

**Completion evidence:** Start a worker from an empty folder using only the returned handoff, with the program launched directly from dist and without an installed metaform command. Repeat with the installed entry point.

**Relevant locations:** src/metaform/continuation.py::publish/begin; src/metaform/installation.py; actor.py; harness.py; assignment handoff. **Sources:** S08, S10, E01.

### R31 — Clear completed assignment markers in retained development folders

**Priority:** P0 · **Status:** Reproduced

**Problem:** Completing a normal assignment left .agentid/nonce in the retained development workfolder. Subsequent commands there remained bound to the completed request and failed instead of operating in the intended context.

**Repair:** Separate the lifetime of a development folder from the lifetime of its active assignment marker. Remove the completed assignment’s ambient binding while retaining the development artifacts and durable receipt. Make cleanup safe to resume for the same request.

**Completion evidence:** Begin and complete an assignment in a retained workfolder. The folder and outputs remain, the completed marker does not, and a new assignment or normal unbound operation does not inherit the old request.

**Relevant locations:** src/metaform/continuation.py; src/metaform/workflow.py::_cleanup_completed/submit; src/metaform/workfolders.py. **Sources:** E01, S07, S08, S09.

### R32 — Retire active nonce lookups while retaining execution history

**Priority:** P1 · **Status:** Reproduced persistence; intended cleanup incomplete

**Problem:** Both normal and fresh-context completion left the assignment lookup JSON in place. begin rejects a completed request through pending-assignment checks, but active dispatch artifacts and historical evidence are not cleanly separated.

**Repair:** Complete the nonce lifecycle across the assignment-home and project-local lookup copies. Retire completed/cancelled dispatch bindings without erasing the run, delivered assignment, result, or replay receipt needed for history and recovery.

**Completion evidence:** After completion, no stale lookup is presented as startable work. Historical assignment/result inspection and repeated answer receipts still work, and cleanup can finish after a retained local failure.

**Relevant locations:** src/metaform/continuation.py::publish/begin; workflow cleanup; app home/project assignment records. **Sources:** E01, S07, S08.

### R33 — Preserve exact request binding and replay semantics during the repairs

**Priority:** P1 · **Status:** Existing behavior to retain; broader checks needed

**Problem:** Existing probes confirmed repeated next returns the same pending assignment and begin retrieves that exact stored assignment. The architecture also binds sibling work to individual request IDs. Lifecycle repairs must preserve this functioning behavior.

**Repair:** Keep project/run/request identity attached to all handoff, read, tool, answer, and cleanup operations. Distinguish a completed binding from a newly issued assignment and keep answer replay tied to its original receipt rather than advancing unrelated work.

**Completion evidence:** Use two pending assignments, complete one, replay its answer, and continue the other. No tool call, cleanup, or result crosses to its sibling; repeated next does not mint competing work.

**Relevant locations:** src/metaform/continuation.py; src/metaform/workflow.py; src/metaform/actor.py; MCP sampling/answer paths. **Sources:** E01, E02, S07, S08, S06.

### R34 — Unify fresh-folder completion with durable result retention

**Priority:** P1 · **Status:** Partly reproduced as working; shared lifecycle verification

**Problem:** Fresh-context completion removed the temporary workfolder and retained a generated output in the existing probe. Modules are intended to reuse this chassis lifecycle instead of independently managing folders and nonces.

**Repair:** Retain that working behavior while reconciling it with ordinary completion, interrupted cleanup, and replay. Publish/recover outputs and receipts before removing their temporary source, and have feature modules use the common lifecycle.

**Completion evidence:** Complete a fresh assignment that produces a file, replay its submission, and inspect its result after cleanup. The output remains available and cleanup does not remove another request’s files or require module-specific manual steps.

**Relevant locations:** src/metaform/workflow.py::_cleanup_completed/submit; workfolders.py; intake.py; enumerator/layer job integration. **Sources:** E01, S07, S08, S09.

### R35 — Make progress and next actions explicit to the concierge

**Priority:** P1 · **Status:** Partial implementation; delivery gap

**Problem:** Results already include statuses and some next-command information, but the user-facing process still relies heavily on a static procedural explanation. A receipt, a completed step, and a completed workflow are not interchangeable.

**Repair:** Return enough current information to distinguish queued work, active worker work, a user wait, recorded output, cleanup, completion, and an operation error. Supply the applicable next action and final artifact references at each transition without requiring the concierge to infer success from a worker’s prose.

**Completion evidence:** Follow a multi-step run solely through its public responses. The concierge can accurately explain progress, resume the right action, and state completion only when the runtime’s result supports it.

**Relevant locations:** src/metaform/workflow.py; modules/workflow.py; onboarding.py; output/receipt presentation. **Sources:** S05, S07, E01, E02.

## 6. Workfolders, baselines, and complete diffs

### R36 — Include ignored working content in the initial workfolder snapshot

**Priority:** P1 · **Status:** Reproduced

**Problem:** For a Git-root source, the initial copy uses git ls-files with --exclude-standard. An ignored, untracked source file was absent from the copied workfolder, so the snapshot was not of the complete working folder.

**Repair:** Make source capture match the stated whole-workfolder requirement rather than the source repository’s tracking policy. Account explicitly for Metaform-owned runtime bookkeeping and Git administrative data, which are not the user’s working artifacts.

**Completion evidence:** Create a Git source with tracked, untracked, and ignored user files. The snapshot includes the working artifacts in all three categories, with any non-content exclusions visible and tied to their purpose.

**Relevant locations:** src/metaform/workfolders.py::create; source inventory and copy logic. **Sources:** E01, S09.

### R37 — Include ignored-content changes in workfolder diffs

**Priority:** P1 · **Status:** Reproduced

**Problem:** A plain-directory source copied an ignored file, but the copied .gitignore excluded its later modification from Git’s diff. Applying that diff left the source file unchanged.

**Repair:** Make the baseline/index and subsequent diff cover the actual workfolder content independently of project ignore rules. Use the same content boundary for snapshot, change reporting, and application.

**Completion evidence:** Modify and add ignored user files in workfolders created from repository and non-repository sources. Both changes appear in the reviewable diff and reach the source through the intended application operation.

**Relevant locations:** src/metaform/workfolders.py::create/diff/apply; baseline/index setup. **Sources:** E01, S09.

### R38 — Keep ephemeral agent identity out of patches and source projects

**Priority:** P0 · **Status:** Reproduced end-to-end failure

**Problem:** The uncleared .agentid/nonce entered the Git diff. Applying that patch copied it into the source project, and the next App opened there bound itself to an already-completed request.

**Repair:** Correct both sides of the failure: assignment cleanup and the separation of runtime identity from user artifact diffs. Inspect existing copy/apply paths so runtime markers cannot become part of a transferred development patch.

**Completion evidence:** Repeat the exact begin → complete → diff → apply → reopen sequence. No marker enters the patch or source project, while actual edits still apply. Source commands are not rebound to completed work.

**Relevant locations:** src/metaform/continuation.py::marker/begin; src/metaform/workfolders.py::create/diff/apply; App binding discovery. **Sources:** E01, S08, S09.

### R39 — Separate Git change tracking from the knowledge storage backend

**Priority:** P1 · **Status:** Reproduced

**Problem:** Selecting graph_backend=json causes workfolders.create to use file-based tracking even when Git is available. Portable mode selects JSON knowledge, so its data-storage choice also changes the workfolder mechanism.

**Repair:** Make the workfolder tracking decision serve the workfolder requirement, independently of knowledge serialization. Preserve portable/local knowledge behavior while using Git for complete working-copy diffs where that is the intended execution contract. Explain any actual unavailable-tool fallback.

**Completion evidence:** With Git available, repeat the same workfolder scenario under SQLite and JSON/portable knowledge. Both satisfy the stated Git-diff behavior; changing knowledge format does not silently remove it.

**Relevant locations:** src/metaform/workfolders.py::create/create_files; src/metaform/app.py portable configuration. **Sources:** E01, S04, S09.

### R40 — Make the actual edit location and its baseline explicit

**Priority:** P1 · **Status:** Source-confirmed; coverage verification needed

**Problem:** workflow.start defaults workfolder to false, while fresh-context jobs allocate their own empty folders. It is therefore incorrect to assume every workflow automatically runs in a copied, Git-tracked project workfolder.

**Repair:** Connect each artifact-editing operation to its actual working location and baseline, and expose that location in the handoff. Preserve separate fresh-analysis folders and reviewable development copies. Verify full-file behavior for additions, edits, deletions, binary changes, renames, and relevant file metadata, rather than proving only one text edit.

**Completion evidence:** For repository and plain-directory work, show where the worker edited, what baseline applies, the complete resulting diff, and the explicit destination of application. Fresh analysis does not masquerade as a copied project.

**Relevant locations:** src/metaform/modules/workflow.py::start; workflow.py; workfolders.py; history.py. **Sources:** E01, S07, S09.

## 7. Shutdown and distributed execution

### R41 — Repair Ctrl-C shutdown rather than merely hiding its traceback

**Priority:** P0 · **Status:** User-reported; source-supported lead, exact environment not reproduced

**Problem:** The supplied Python 3.10 traceback shows repeated KeyboardInterrupt during asyncio default-executor shutdown and thread joining. The portable MCP path performs blocking stdin.readline through asyncio.to_thread; the CLI lacks an encompassing interrupt lifecycle. That is a concrete investigation lead, not a proven diagnosis of the user’s exact binary.

**Repair:** Reproduce the actual launch/transport path, locate the still-blocked input/task/thread, and make one Ctrl-C exit cleanly. Coordinate cancellation, reader shutdown, and owned resources. Catching the visible exception alone is insufficient if the process still waits for a blocked reader.

**Completion evidence:** Run the shipped artifact in the reported launch context with stdin open, then interrupt once. It returns control without a traceback or a second interrupt. Exercise EOF and normal close as well as the active-operation case.

**Relevant locations:** src/metaform/cli.py::main; src/metaform/mcp_server.py::serve; src/metaform/portable_mcp.py::serve; owned harness subprocess lifecycle. **Sources:** U01, S01, S06, S08.

### R42 — Keep shutdown, abort, and resume behavior consistent with durable runs

**Priority:** P1 · **Status:** Lifecycle integration requires verification

**Problem:** A clean process exit and a finished workflow are different events. Repairing interruption must not erase recoverable work, leave misleading active bindings, or terminate a shared service simply because one client closes.

**Repair:** Define and implement the actual effect of client exit, workflow abort, and resumable interruption using existing run/receipt state. Release resources owned by the exiting process, retain the right continuation, and clean only terminal assignment state. Present the resulting state accurately to the user.

**Completion evidence:** Interrupt an active run, restart the client, and recover the documented continuation without duplicate committed results. Separately abort a run and verify its terminal cleanup. Another client’s work remains intact.

**Relevant locations:** src/metaform/app.py::abort; workflow/intake lifecycle; continuation.py; MCP and harness shutdown; service ownership. **Sources:** U01, S04, S06, S07, S08.

### R43 — Verify the direct executable, installed command, and MCP connection as delivered

**Priority:** P1 · **Status:** Distribution requirement; reported environment differs from earlier probes

**Problem:** The user runs python metaform from dist. Earlier probes used an isolated packaged runtime on a different Python version and did not reproduce the reported Python 3.10 shutdown environment. A development checkout or installed console command alone does not establish direct-artifact behavior.

**Repair:** Exercise the actual distribution entry points and document their real Python/dependency and transport behavior from within the package. Include current-directory handling, connection instructions, launcher discovery, offline reference access, and clean exit. Distinguish a compatibility issue from an application defect using evidence.

**Completion evidence:** Record the artifact hash, Python version, command, cwd, selected project, and result for direct CLI, installed CLI, and supported MCP paths. The documented first-use path works without development files or an undocumented local launcher.

**Relevant locations:** packaging configuration; src/metaform/installation.py; cli.py; portable_mcp.py; mcp_server.py; tools/check_distribution.py. **Sources:** E04, U01, S01, S06, S12.

## 8. Built-in self-understanding and customization

### R44 — Implement the chassis’s own functional Metaform

**Priority:** P1 · **Status:** Explicit existing design requirement; documented as unimplemented

**Problem:** SPEC §12 calls for a built-in chassis Metaform teaching module construction, workflow import, and interface use. current-work.md explicitly identifies it as unimplemented. A long skill and a command-schema dump do not substitute for that account.

**Repair:** Build the specified functional understanding of the chassis: purposes, capabilities, relationships, ownership boundaries, and how the interfaces support customization. Package it with the system, retain its specified separation from ordinary viewer/project content, and make it available to the concierge on demand.

**Completion evidence:** An agent starting from the distribution can explain how to add a workflow or module and which public interfaces to use by consulting the built-in account, without reading the development repository.

**Relevant locations:** docs/SPEC.md §12; docs/current-work.md; model/knowledge services; package data and concierge retrieval. **Sources:** S10.

### R45 — Connect self-understanding to installed capabilities without making it a static catalog

**Priority:** P1 · **Status:** Agreed architecture alignment

**Problem:** The system needs both stable understanding of its mechanisms and live knowledge of what is installed. Confusing those roles is already visible in static guidance that continues naming removed features.

**Repair:** Let the built-in account explain how the chassis works while installed modules contribute their own functional account and reference. Resolve what is currently usable through live discovery, including user workflows. Keep historical or generic explanations distinguishable from available actions.

**Completion evidence:** Install and remove a community module. The concierge’s available actions and module-specific guidance change, while its accurate understanding of the general module mechanism remains.

**Relevant locations:** built-in chassis Metaform; registry.py; onboarding.py; module-supplied documentation/knowledge; workflow catalog. **Sources:** E03, S02, S05, S10.

### R46 — Provide the public integration interface described by the design

**Priority:** P1 · **Status:** Source-confirmed; documented design gap

**Problem:** Registry dispatch currently passes the internal App to community handlers. current-work.md acknowledges that the intended public module interface and storage/execution ownership boundary have not been implemented.

**Repair:** Define and implement the public operations modules need for configuration, knowledge access, workflow creation, assignment publication, results, and lifecycle use. Keep storage and execution ownership in the chassis. Teach and demonstrate this interface in the built-in customization guidance instead of instructing authors to manipulate internal storage directly.

**Completion evidence:** A representative external module completes its operation, including a worker assignment and stored result, through the public interface. Its implementation does not depend on App’s internal database layout or recreate nonce/workfolder handling.

**Relevant locations:** src/metaform/registry.py::call; src/metaform/app.py; module integration surface; docs/SPEC.md §12. **Sources:** S02, S04, S10.

### R47 — Demonstrate end-user customization as one complete workflow

**Priority:** P1 · **Status:** Requested outcome; end-to-end proof outstanding

**Problem:** Module discovery and authoring primitives exist, but the user’s goal is to express an operation, create or import it, discover it, run it, and share it without reverse-engineering the source.

**Repair:** Connect the built-in guidance, converter/module builder, public interface, module folder packaging, registration, help, settings, and worker lifecycle into a demonstrable customization path. Keep user workflows editable and use the same discovery/execution mechanisms as bundled work.

**Completion evidence:** A fresh agent creates one useful custom workflow and one small module using only the delivered system’s guidance. A second clean installation discovers their details and runs them; removing the module removes its active references.

**Relevant locations:** built-in guidance; module builder prompt; registry.py; workflow authoring; package/portable dependency handling. **Sources:** S02, S07, S10, S12.

## 9. Verification and repair delivery

### R48 — Test the shipped user journeys rather than just internal handlers

**Priority:** P1 · **Status:** Observed coverage gap

**Problem:** The actual help/removal/configuration probes reveal defects despite prior reported test success. Those results do not establish that every existing test is poor; they show that successful internal checks have not established this delivery experience.

**Repair:** Add focused integration coverage for the real journeys listed below using the built artifact, temporary projects, public interfaces, and captured outputs. Reuse each scenario to verify its related repairs instead of creating many implementation-mirroring tests.

**Completion evidence:** Evidence covers first launch/help, settings, module add/remove, AI orientation, workflow import/execute, handoff cleanup, complete diffs, and interruption/resumption through the actual distributed program.

**Relevant locations:** tools/check_distribution.py; relevant existing CLI/MCP/workflow/continuation tests; packaged artifact fixtures. **Sources:** E01–E04, U01, S12.

### R49 — Review existing tests for purpose, redundancy, and semantic reach

**Priority:** P2 · **Status:** Audit required; no unsupported test-quality verdict

**Problem:** The user reasonably questions a large test count alongside basic failures. The complete current test suite was not downloaded and audited in this investigation, so its quality and exact count should not be invented.

**Repair:** Classify existing tests by the user-visible behavior or substantive invariant they establish. Retain valuable concurrency, provenance, semantic-boundary, and regression checks; identify duplicated implementation mirrors for reduction. Keep real model-conversion evaluations separate from fixture-generated workflow tests.

**Completion evidence:** Produce an evidence-based coverage map and specific consolidation candidates. Report which journeys are proved and which remain untested, rather than presenting a larger count as a quality improvement.

**Relevant locations:** tests/; tools/check_distribution.py; docs/verification.md; retained prompt-conversion evaluations. **Sources:** E02, S10, S12.

### R50 — Close repairs with reproducible evidence and synchronized built-in documentation

**Priority:** P1 · **Status:** Delivery requirement

**Problem:** A repair can appear complete in source while the distributed wheel still carries old skill text, missing module metadata, an outdated conversion grammar, or a broken entry point.

**Repair:** For each completed repair, record the original observation, changed behavior, evidence scenario, and exact built artifact. Update the owning module’s packaged reference and applicable source documentation together. Keep remaining unknowns explicit and verify that source prompts and user-authored customizations remain intact.

**Completion evidence:** Open the rebuilt artifact in a clean location and repeat the relevant observed failure. The result, built-in help, module catalog, and repair record agree on what is implemented and what is still pending.

**Relevant locations:** package data/build; module-owned help; docs/verification.md; this repair backlog and associated evidence. **Sources:** E01–E04, S03, S10, S12.

## Source-prompt conversion matrix

These are source-specific expectations, not universal workflow rules. Conditions contained in an imported prompt belong to that prompt; the converter must neither generalize them to all work nor remove them just because another source operates differently.

| Root-level source | Distinct conversion behavior to examine |
|---|---|
| `prompts/metaprompt.md` | The initial request for a topic, user-input continuation, task refinement, optional specialist use, and final production of a prompt. The generated prompt must not accidentally become an instruction to execute that new task immediately. |
| `prompts/dual_agent.md` | Separate Dev and independent Eval assignments; prerequisite/user-response interaction; plan review; repeated implementation slices; source-authored completion conditions. |
| `prompts/multi_agent_orchestrator.md` | Analyst → Planner → Developer → Evaluator roles, authored plan approval, develop/evaluate repetition, and source-specific communication behavior. |
| `prompts/orchestrator.md` | Initialization trigger, bootstrap, architecture and document-sharding assignments, per-module implementation/review loops, integration outputs, persistent artifacts, and harness-specific command placement. |
| `prompts/extractor.md` | Core-function documentation rather than implementation, target-language input, per-task artifacts, an artifact-only fresh evaluator, and user-feedback-driven reruns of affected work. |
| `prompts/python_to_c.md` | Mixed YAML configurations and examples; phased parallel work and dependencies; named artifacts and shared context; authored failure/timeout behavior; illustrative output versus real results. Referenced agents and schemas not defined in this file must remain identifiable dependencies rather than invented implementations. |
| `prompts/taskeengineplus.md` | Ten role responsibilities, dynamic task/dependency records, optional documentation, per-task critique/evaluation, requeue behavior, retry counts, and the final assembled deliverable. |

**Important distinction:** The existing local authoring probe injected a valid workflow answer and exercised execution. It did not ask a model to infer these workflows from their source prompts. R28 addresses that missing semantic evidence. A model-produced JSON document that validates but collapses independent agents or loses a user wait is still a failed conversion for that source.

## Focused completion demonstrations

These are a small set of end-to-end checks, not a demand for one new test per repair item. Existing checks should be reused where they establish the actual behavior.

| Demonstration | Concrete exercise | Main repair coverage |
|---|---|---|
| First encounter | Copy the built executable into a clean dist folder; read top-level and nested help; start normally; choose a different project; reach the next action without repository documentation. | R01–R07, R17–R18, R43 |
| Settings lifecycle | Initialize defaults; inspect their location and origin; make distinct home/project choices; update one; read and use the result in the same session. | R08–R12 |
| Module lifecycle | Add a small module with commands, reference, and settings; discover it through CLI/MCP; remove it and check help, guide recommendations, shortcuts, and session refresh. | R02, R06–R07, R09, R15–R16, R45–R47 |
| Fresh AI orientation | Connect without prior Metaform repository knowledge; discover a usable workflow; start it; follow actual continuations; retrieve deeper documentation only when needed. | R13–R19, R35, R44 |
| Real source conversion | Run the converter against the corpus, retain actual responses and source mappings, and execute representative role, loop, user-wait, and parallel cases. | R20–R29 |
| Identity and cleanup | Begin two distinct assignments; finish and replay one; continue the other; retain development output; clean fresh output correctly; apply a patch and reopen the source. | R30–R35, R38 |
| Whole-workfolder changes | Use Git-root and ordinary-directory sources with tracked, untracked, ignored, binary, and deleted files; compare snapshot, diff, and application under both knowledge backends. | R36–R40 |
| Interrupt and resume | Interrupt the actual shipped transport with stdin open, then restart; distinguish resumable client exit from an explicit workflow abort; inspect workers, markers, results, and service ownership. | R31–R34, R41–R43 |
| Distribution/library round trip | Use the wheel without the source checkout; discover an embedded workflow; customize a copy; share a module/workflow; open in another clean installation and use only its built-in reference. | R19, R29–R30, R43–R47, R50 |

## Suggested work order

1. **Contain current runtime failures:** R11, R15, R31–R32, R38, and R41–R42. These address wrong-scope settings, nonexistent recommended actions, stale assignment identity, patch contamination, and interruption.
2. **Complete the public entry/reference and settings experience:** R01–R12, then the concise bootstrap/current guidance work in R13–R19. Use module-owned metadata once rather than writing another static manual.
3. **Finish handoff/workfolder behavior and distribution proof:** R30, R33–R40, and R43. Preserve the existing durable workflow behavior already exercised.
4. **Refine conversion and embed the real workflow library:** R20–R29. Use source-derived semantic evidence instead of schema validity as the sole measure.
5. **Complete self-understanding and public customization:** R44–R47, reusing the repaired discovery and lifecycle. Carry R48–R50 alongside the corresponding repairs rather than postponing verification and packaged documentation to the end.

The ordering describes dependencies and impact. Independent documentation/reference work can proceed alongside lifecycle work; it does not require a wholesale chassis rewrite.

## Evidence and source locator

All `src/` paths below refer to the pinned repository revision. In the executable archive they appear under `metaform/` without `src/`.

| ID | Source or retained observation |
|---|---|
| E01 | `evidence/runtime-probe-results.json` and `evidence/initial-inspection-report.md`: earlier isolated handoff, cleanup, discovery, and diff observations. |
| E02 | `evidence/authoring-probe-results.json`: earlier fixture-based authoring/control-flow observations; see the evidence archive for its producer script. |
| E03 | `evidence/module-removal-results.json`: disposable Intake/Enumerator registration-removal probe. Implementation files were retained; this was not a complete binary uninstall experiment. |
| E04 | `evidence/delivery-observations.json` and `evidence/inspect_delivery.py`: newly captured built-artifact help, manifest inventory, help side effects, and real-App configuration-scope/reload observations. |
| U01 | The user-supplied Python 3.10 traceback in this conversation: `cli.py` → `asyncio.run` → default executor shutdown, then thread joining and repeated `KeyboardInterrupt`. Exact installed artifact/version and full triggering command for that interrupt were not established. The separately specified help command was `python metaform --help` from `dist`. |
| S01 | `src/metaform/cli.py`: early direct dispatch, App initialization before parser help, top-level module parser creation, generic JSON output, and exception boundary. |
| S02 | `src/metaform/registry.py`: packaged/home/project/configured discovery, visibility, command definitions, and dispatch passing internal App. |
| S03 | `src/metaform/data/modules/*.json`: command metadata, with `system.json`, `guide.json`, `workflow.json`, and `enumerator.json` particularly relevant. |
| S04 | `src/metaform/app.py` and `src/metaform/modules/system.py`: configuration merge, portable overrides, settings write scope, current App, and module inventory output. |
| S05 | `src/metaform/onboarding.py`, `src/metaform/modules/guide.py`, and `src/metaform/data/skills/metaform/SKILL.md`: static skill, guide stages, command catalogs, and next actions. |
| S06 | `src/metaform/mcp_server.py` and `src/metaform/portable_mcp.py`: startup/prompt guidance, tool exposure, project sessions, host answer loop, and portable blocking stdin reader. |
| S07 | `src/metaform/modules/workflow.py`, `src/metaform/workflow.py`, `src/metaform/prompts.py`, `src/metaform/data/prompts.json`, `src/metaform/logic.py`, and `docs/workflows.md`: authoring, conversion grammar, execution, templates, snapshots, receipts, and documentation. |
| S08 | `src/metaform/continuation.py`, `src/metaform/actor.py`, and `src/metaform/harness.py`: published nonce commands, marker binding, worker transport, and assignment delivery. |
| S09 | `src/metaform/workfolders.py` and `src/metaform/history.py`: copying, baselines, Git/file tracking, diffs, application, output retention, and cleanup. |
| S10 | `AGENTS.md`; `docs/SPEC.md` especially §§9, 12, 13; `docs/architecture.md`; `docs/current-work.md`; `docs/verification.md`. The built-in chassis Metaform/public customization interface are explicitly documented as unfinished in the inspected current-work record. |
| S11 | The seven root-level source prompts in the conversion matrix. Their filenames were verified against the pinned GitHub directory; content was read in this conversation. |
| S12 | `src/metaform/installation.py`, `src/metaform/packaging.py`, package-data/build configuration, `tools/check_distribution.py`, and the downloaded executable/wheel. Test/build files not inspected in full remain investigation locations rather than asserted defects. |

## Delivery boundary

This document records repair work; it does not apply it. No repository source, runtime prompt, module manifest, or existing project was changed by preparing the backlog. New checks used separate disposable fixtures. No model-derived corpus conversion, full-suite test audit, or reproduction of the exact Python 3.10 interrupt environment is claimed.
