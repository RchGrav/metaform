# Metaform 0.2

Metaform by Richard Graver prepares reusable type knowledge so subsequent
instructions can address the project through its Elements and joins. This
version makes the prompts and workflow operations inspectable and portable.

This document describes the 0.2 source interfaces, including the September 11
repairs. [Repair status](release-quality-status.md) identifies what has passed
integrated delivery checks. [SPEC](SPEC.md) defines intended
semantic behavior; [current work](current-work.md) tracks outstanding alignment.

## Start

Install the release wheel normally with pip, or install from the repository.
The installed dependencies include the MCP SDK. Run `metaform install`
to create a missing launcher in `~/.local/bin` and preserve an existing one.
An optional destination argument selects
another user bin directory. The installer detects Codex, Claude Code, Gemini CLI,
Cursor and VS Code, registers the MCP server for the harnesses you choose
(`--harness <id>` without a terminal), and writes the Metaform skill to
`~/.metaform/skills/metaform/SKILL.md`, to `~/.agents/skills/metaform/SKILL.md`,
and to each chosen harness's skill directory.
No package or extension downloads occur inside this setup command.

`metaform web` starts the knowledge service on its one fixed port when it is
not up, opens the current project, and returns its URL; `metaform web stop`
stops it and `metaform web status` reports it. The port is `web_port` in the
home config, default 8642, so a link made once keeps working. The root of the
page lands on the project opened most recently; the chooser is at `/projects`.
CLI and stdio MCP commands remain available. A direct release wheel also runs without
an extension: `python metaform`. The release build includes pure-Python portable
dependencies under `_portable`; normal package installation uses its declared
dependencies. Native dependencies are not represented as portable pure Python.
Without the MCP SDK, stdio uses a standard-library transport for the 2025-11-25
tools/resources protocol. It returns assignments for the host to execute and
answer. Installed use retains SDK sampling and newer protocol features.

New installed projects use the shared knowledge service automatically. Existing
project directories keep legacy storage until `metaform project connect` adopts
them. `metaform --project <path-or-registered-id>` selects the invocation;
`project current` and `project list` expose its context and registrations.
`project select --project <path-or-id>` changes a client's selection; assignments
retain their issued project and each workbench tab uses a project-specific URL.
Use `project relocate --path <new-path>` after a move or `project connect --new`
after a copy. `service status` checks actual liveness and `service stop` stops the
verified instance. The service releases idle resources after its configured
`service_idle_timeout` (60 seconds by default), allowing active operations to
finish; later requests restart it. Selection creates no global active-project setting.

The main workbench has six views:

- **Graph:** current Foundation models, actuals, Types, joins, layers and
  revision inspection; retained v1 records remain in History / Compare, with
  source views and graph editing.
- **Rules:** the editable semantic rules supplied to prepared assignments.
- **Prompts:** authored text, input values, exact prepared input, harness runs or
  nonce handoffs, actual answers, review notes, and recorded responses.
- **Workflows:** source, builder handoff, executable JSON, step handoffs, answers,
  and application of completed conversion results.
- **Versions:** parent-linked checkpoints, file diffs, extraction, export,
  re-import, and static web previews on separate local ports.
- **Activity:** run state, recorded execution events, actual Element/Type counts
  excluding seeded infrastructure, and graph dumps. Pending assignments remain
  visible across workbench pages and reloads.

The browser assets are shipped in the package; no CDN is used. Previews serve
static artifacts. An application that needs a build step or its own application
server still needs that process. Preview URLs are independent roots so `/assets`
works for each version. Preview commands return links for you to open.

## Prompts and workflow conversion

`data/prompts.json` supplies editable initial prompts for conversion,
specialization, continuity, module building, and self-review. Current v2 intake and outside roles are composed from the versioned
`data/roles/composition.json` and its task/component files. Historical v1 task
texts remain available for issued older continuations.
The exact maintained Aliases section is bundled and supplied to intake; an
explicit `semantic_sources.aliases` configuration selects an alternative authored
source. [Semantic rule seeds](rulebook/README.md) supply concise wording and
priming material with recorded revisions.

A prompt node has `entity_schema: metaform:prompt` and data containing `id`,
`name`, `text`, and its text SHA-256 revision. Editing preserves observations.
Imported inline prompts become prompt nodes, and steps reference them through
`prompt_ref` and `step_prompt` joins. A workflow may also supply a `prompts`
array. A running frame retains the prompt text and revision it received.
Subsequent runs resolve the edited prompt.

Template substitution uses the existing Jinja syntax, such as `{{ name }}`.
Source text and the rendered instruction are recorded separately. Arbitrary
answers remain answers; the runtime's own checker supplies annotations, in the
standalone as everywhere else.

`workflow convert` creates a builder assignment from the exact source, selected
Metaform, and the execution grammar. A configured harness may execute it; an
external model can answer through the nonce/answer interface. `workflow apply`
imports the returned workflow and records its derivation. Converting a natural
language process is an inference operation, not a deterministic text parser.
Its semantic quality is intended to be tested and refined in the workbench.

Supported execution forms are `prompt`, `branch`, `call`, `foreach`, `parallel`,
`output`, and `tool`; [workflows](workflows.md) describes their exact fields. Sequence uses step order unless a transition selects another step.
Transitions can return to earlier steps. A `parallel` step contains `branches`
with workflow references or inline workflow definitions. Each branch gets its
own run and nonce, while inheriting the parent's development workfolder. The
parent waits for the branch results. The external orchestrator may dispatch ready
branches concurrently to any harness. Aborting a branch preserves the shared
folder; aborting its owner stops descendant harnesses and retains the folder
until their execution and trace capture finish.

## Handoff and continuity

The orchestrator passes the returned `begin` command, which names the actual
launcher and nonce without retelling the stored instructions. Metaform records
the folder and its assignment in the base db, the `bindings` table of the user's
`service/knowledge.sqlite3`; no marker file is written (decided 2026-09-12). The
record locates the project, module, run, and issued request. Commands invoked in
that folder or its children use that continuation and count as activity; a
record with no activity for 24 hours acts as absent, with no message. Reads of
the record are direct and never start the service. The nonce names stored work,
not a persistent agent identity.

Assignments are recorded under `~/.metaform/assignments/<nonce>.json`. Their
inputs, exact prompts, responses, and workflow state reside with the project.
The default issuance uses a random nine-digit nonce and checks the assignment
index for collisions. Retrieving the same pending step returns the same nonce.
New steps receive new handoffs. A saved explicit binding retains its exact issued assignment and replay
receipt after completion; it cannot advance to another assignment. Terminal
ambient folder markers and dispatch lookups are cleaned separately from that
durable history. The coordinator requests subsequent work outside that binding using
the run ID, then begins the new nonce in its agent folder. Run origins record the
launch folder and target; workfolder records identify execution and application
locations.

CLI subprocesses launched by a harness inherit the scoped bridge. Plain
`metaform` routes through that bridge after a directory change instead of opening
the main router. File bindings cover separate CLI processes in a bound folder.
These are command-surface controls, not operating-system isolation from files
accessible to the same account. A separately launched process outside both the
binding's directory tree and the scoped harness environment has no association
with that continuation.

## Storage

The service owns global and registered-project knowledge in
`<METAFORM_HOME>/service/knowledge.sqlite3`. Elements, joins, observations, and
schemas use owner-qualified keys; `global` and `project:<uuid>` records may have
the same semantic ID without overwriting each other. Native, archaeology, authored,
and completion observations remain independent from ownership. Endpoint and
participant owner metadata retain precise cross-owner references.

CLI and MCP startup probe authenticated loopback health with a fresh challenge,
matching service and instance identity and readiness. OS-backed locks coordinate
startup and service ownership; a PID file or listener alone does not establish
liveness. The service performs knowledge operations while project-local SQLite
and files retain execution, assignments, and workfolders.

`project connect` reads the configured legacy SQLite or JSON backend,
preserves original files, verifies copied source records, and writes the service
marker after commit. Conflicting existing content is reported for resolution.
Home global imports are tracked by source home and digest. Legacy paths remain
`.metaform/metaform.kg` or `metaform.json`, with global knowledge
under the selected home's `inference/` directory. Inspection alone does not adopt
an existing project.

The shared service uses SQLite. `graph backend` reports the active store; legacy
projects may select SQLite or JSON, while portable projects retain JSON. Ladybug
and Cypher analysis copies have been retired from installation, backend selection
and the public graph interface. Existing retired-backend files remain untouched;
there is no automatic conversion of their contents.

Selected service export traverses owner/reference indexes within one SQLite read
transaction, including reified joins, both endpoints, and participants. It does
not materialize all global records first. Ordinary central graph mutations still
reconstruct and replace one owner partition within a transaction; large mutation
workloads remain a practical scaling limit.

Operational state remains in `.metaform/state.sqlite3`; archives serialize its
tables and restore a local SQLite database. Portable project/global knowledge is
stored in `.metaform/metaform.json` and `.metaform/home/inference/metaform.json`.
The portable dispatcher captures both JSON files under their locks and bypasses
service discovery and unrelated packaged inference.

Scoped graph reads and exports preserve each source's Element and join contents.
Structural similarity compares node identities and join structure, including
participant roles and references to joins. Its `01`, `10`, and `11` records carry
structure and provenance references. The viewer exposes Contextual, Latent, and
read-only similarity views. [Current work](current-work.md) tracks remaining
alignment with the [SPEC](SPEC.md).

## Versions and exports

History lives in `.metaform/history/`. `origin/` stores the baseline bytes. At a
Git repository root with Git available, the baseline comes from the starting
commit; an export checkpoint captures working-tree changes. For an ordinary
folder, the initial contents form the baseline. The manifest records which case
applies and the commit when present.

Each checkpoint references a parent and contains additions, modifications, and
deletions. Added and modified files are complete files under
`versions/<version>/files/`; they are compressed by the outer ZIP. Each version
also stores its project Metaform and work provenance. Export selects all current
project records and related global inference through eligible project/global
joins, workflow attachments, and explicit execution dependencies. Another
project's private joins do not expand that closure. Source observations and exact
historical snapshots travel with separately retained historical dependencies.
Schemas and module declarations follow their selecting records. Unrelated global
additions leave the selected knowledge digest unchanged. Unchanged file contents
are inherited from the parent chain.

The origin SHA-256 is derived from the canonical path/content-hash/mode manifest.
The initial suffix is `0000`. `mform_sha_id` is the full hash plus `_` and the
four-digit hexadecimal suffix. `mform_id` is the first 48 hash bits plus that
16-bit suffix, represented as 16 hexadecimal characters to preserve all bits
through JSON and JavaScript.

`package export` captures pending file or graph/run changes and produces one
executable `metaform-export/2` archive. The archive contains ordinary `origin/`
and `versions/` paths, selected graph JSON, owner-qualified schema and dependency
metadata, project-bound continuation assignments, active workfolders, retained
outputs, selected module folders and declared assets, and its portable runtime.
Shared modules enter closure when referenced or selected by configuration,
including retained portable module selections. A native Git
workfolder is exported with a file-based baseline so it can continue without Git.
No model, model credentials, or image-generation service is embedded.

On execution, the archive materializes a working copy in its sibling
`<mform_sha_id>` folder, or a suffixed sibling when history diverges. Subsequent
invocations reuse the copy whose saved bundle hash matches that archive. Edits are
made in the working copy; `package export` creates the returned archive. The ZIP
is not rewritten after every command. The portable copy preserves the logical
project UUID in `project_id`/`origin_project_id` and has its own `copy_id`; moving
that copy does not change the meaning of its explicit owner references. It can
resume pending work, edit source records, and export the continued archive with
the shared service and original home unavailable.

On re-import, pending local file or graph/run changes are captured first. If
incoming history includes every local version with matching content and origin,
the corresponding folder is replaced. Otherwise the incoming suffix increments
and both continuations remain. A staged replacement keeps the prior directory
until the new copy is ready. Both `metaform-export/1` and `/2` are accepted;
version 1 retains its supplied historical extent and is re-exported through the
selected closure. Archive import creates or updates a portable working copy,
including beside a connected project; shared-service reconciliation is not
implemented. Binary SHA-256 checks detect damaged stored files
when reconstructing a version. Path checks protect extraction boundaries.

`history_exclude` accepts additional path patterns. Chassis metadata, assignment
markers, and Git internals are separated from the project-file history to avoid
recursive capture. Selected custom module folders and active outputs are exported
in their own sections.

## Modules, self-targeting, and community

Modules live under `~/.metaform/modules/<module>/` or
`<project>/.metaform/modules/<module>/`. A `module.json` declares commands and
handlers. Handler files can use relative imports into child packages. Importing
one module does not import the other modules. `disable_argparse`, `raw_handler`,
`always_available`, and conditional command visibility remain available.

External handlers receive `ModuleAPI`: async public command dispatch,
module-scoped state, copied project/configuration context, and module mode
entry/exit. A module can reuse prompt/workflow/knowledge operations through that
interface and ship its data alongside its Python code. See the
[community module example](../examples/module/README.md) for the exact interface.

`metaform guide chassis` retrieves the bundled Native functional account of the
chassis, its customization procedures, and current module reference, without
adding that account to the selected artifact's graph. An explicit self-intake
of Metaform's checkout is a separate semantic demonstration. The editable
module-builder and self-review prompts remain available for that work.
`sync export` writes global inference as reviewable JSON in the source checkout;
`sync merge` merges and pushes that data through the configured remote. Data-only
updates trigger CI repackaging. Contributions can contain new modules, prompts,
workflows, schemas, or global type knowledge. Uploading is a user-invoked action.

## Validation scope

Shared-service and portable integration tests pass on Python 3.11 and 3.13.
Checks cover authenticated startup/reuse and races, owner isolation, request
receipts, inference rollback/recovery, indexed closure under concurrent writes,
and source-preserving JSON copies.
Dated full-suite and rebuilt-wheel evidence is recorded in [verification](verification.md);
current release-repair delivery is tracked separately in [repair status](release-quality-status.md).

Existing checks exercise SQLite and JSON storage, reified joins on joins, prompt
revision snapshots, parallel handoffs, folder bindings, workflow conversion
application, binary file reconstruction, inclusive/divergent
imports, active workfolder continuation without Git, static previews, and a
portable archive under Python `-S`. Existing tests cover installed CLI/MCP
routing, blind latent inference, schemas, harness processes, and data synchronization.
The release check also creates an empty Python environment and exercises the
extensionless wheel's CLI/MCP, GUI launch, project export, and returned export's
GUI without installed dependencies or Git.

This feature verification did not run live model or image generation. Prepared
prompts and data paths are exercised; semantic quality needs real model testing.
Earlier Chromium evidence included a now-retired Ladybug analysis-copy refresh.
That historical result is not a current capability or release requirement.
Current storage coverage retains independent project selection and SQLite/JSON
knowledge operations.

## Research references

- [MCP lifecycle and version negotiation](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle)
- [MCP stdio transport](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)
- [MCP tools and structured results](https://modelcontextprotocol.io/specification/2025-11-25/server/tools)

The Metaform router remains its own CLI/MCP implementation.
