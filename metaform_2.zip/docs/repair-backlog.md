# Reconciled Metaform repair backlog

**Date: 2026-09-11. Status: implementation authorized and in progress; see [execution status](release-quality-status.md).**

Metaform's delivered CLI did not provide Rich a usable way to understand, start, continue, or exit the system. Hardcoded guidance and feature dispatch, unusable command organization, incomplete built-in help, missing settings reference/defaults, stale documentation, and broken continuation/shutdown are substantive system failures. The required outcome is a self-contained tool that teaches both user and concierge how to begin and supplies the instructions for the operation being performed.

**The previous review's eight passing tests were not a count of remaining issues and did not establish product usability or engineering completeness.** Its short findings list was not an exhaustive reconciliation. This document provides that reconciliation: every R01–R50 item, every numbered 1–76 supplemental item, and every Decide 1–28 item has a disposition below. Settled requirements and outdated docs remain actionable work. No confirmation of the already-agreed core system is needed.

Sources: [50-item repair list](metaform-repair-list.md), [76-item repair specification and 28 questions](repair-spec.md), [merged issue inventory](reviews/2026-09-10-onboarding-review/merged-issues.md), and [review evidence and source references](reviews/2026-09-11-repair-backlog-review.md). Rich's supplied conversation establishes the required CLI/reference/settings/onboarding experience. His definitions and [SPEC](SPEC.md) govern semantic meaning.

## Reading this backlog

- **Implementation (I):** repair behavior or complete agreed system functionality. Some mechanisms exist; integration and delivery remain work.
- **Documentation/reference (D):** repair the tool's own reference, runtime guidance, repository docs, or their agreement. This is an open deliverable, including when code already works.
- **Verification/delivery (V):** establish the stated behavior through the relevant actual transport/artifact or semantic demonstration. Existing fixtures do not establish an untested user journey.
- **Decision/proposal (X):** a narrowly identified unresolved choice or additional behavior. These are separated below; they do not suspend unrelated repairs.

The primary tables retain the original R IDs. Supplemental rows either map to those items or introduce an additional S item using the original number, such as S11. Q IDs denote additional work recovered from the former decision list. These are work entries, not an assertion that every entry is an independent reproduced bug. Documentation accompanies implementation; a primary category prevents counting the same entry twice.

The baseline review used HEAD `d264f512ceba89cf3a5152f66cdc60c0e1a06ba4` with earlier uncommitted repairs and distribution SHA-256 `24973b0df6614e498feca39f294f71f5b46164f9371a9cb0bb3a383665196ff2`. The tables below preserve the issues and their disposition **at that review**, not the current implementation state. Current per-entry evidence is maintained in the [84-entry independent audit](reviews/2026-09-11-release-evidence-audit.md); rebuilt artifact identities and results are in [distribution evidence](release-distribution-evidence.md). Source progress alone does not close delivery.

## Established implementation and integration work

At the baseline review, all of these remained open at the complete-user-experience or delivered-artifact level. “Partial source work” preserves credit for mechanisms that existed then. Follow the independent audit for subsequent repairs and remaining limits.

| ID | Remaining required outcome | Current disposition |
| --- | --- | --- |
| R01 | Present readable module names/purposes, commands within each module, and usable help in every CLI mode. | Open. Internal grouping is insufficient; argparse ignores module descriptions and active modes swallow help. |
| R03 | Make a normal launch explain Metaform and lead to selecting, beginning, or resuming actual work. | Open. No-argument launch still falls through to generic help. |
| R04 | Handle reference/help and installer arguments without creating or registering an accidental project. | Open. App opens before ordinary help/install parsing. |
| R05 | Make human-facing state, errors, semantic reads, URLs, results, and next actions understandable while preserving complete machine output. | Open. Large JSON and misleading unchanged results obstruct use. |
| R07 | Resolve public feature shortcuts through their owning modules; make module removal affect callable features and active guidance together. | Open. Direct feature dispatch, including browse, bypasses registry ownership. |
| R08 | Create persistent, discoverable settings with applicable defaults during actual initialization; preserve later edits. | Open. Agreed baseline functionality. |
| R09 | Have configurable modules supply their settings, types, meanings, defaults, scope, and examples. | Open. No module settings declarations were found. |
| R10 | Show effective configuration, active files, scope, source, and precedence, including selected service home and portable behavior. | Open. Users cannot reliably identify what configuration controls the invocation. |
| R11 | Update the selected configuration scope without leaking project overrides into home defaults. | Open. Configure writes the merged effective view into home config. |
| R12 | Make configuration changes take effect coherently and provide usable enable/disable controls, including debug. | Open. Current App retains stale config; CLI debug reversal is unclear. |
| R13 | Supply a concise concierge introduction and capability discovery; deliver worker and feature detail in its operative context. | Partial source work. Moving text into manifests does not finish progressive delivery when all details are appended again. |
| R14 | Make installed modules and selected workflows supply operative instructions and continuations; workers receive the stored assignment. | Partial mechanisms. Eliminate remaining procedural authority duplicated in central prose/feature-specific logic. |
| R15 | Derive available onboarding actions and guidance from installed capabilities. | Partial catalog repair. Guide still recommends hardcoded operations that can be absent. |
| R16 | Provide concise MCP orientation and refresh usable guidance/tools as project, modules, or run state changes. | Partial refresh paths. Full command schemas and guidance still inflate startup. |
| R18 | Carry user and concierge through actual project selection, intake/resume, web access, Best Practices, default selection, and later return. | Partial. Wrong initial project, missing capabilities, deleted layers, and continuation failures still interrupt the journey. |
| R19 | Discover available workflows with identity, purpose, source, inputs, and a working start action. | Open. A list of workflow commands is not a workflow library. |
| R21 | Have conversion account for the source's actual procedure and make the source-to-structure mapping reviewable. | Existing converter; complete source-derived behavior remains to be demonstrated and repaired where deficient. |
| R22 | Realize authored specialist roles as actual assignments with the required context and response routes. | Existing assignment machinery; corpus-specific role/context delivery remains open. |
| R23 | Preserve authored branches, loops, calls, parallel dependencies, and continuation semantics; supply a complete execution grammar. | Existing engine primitives; grammar gaps and source-derived integration remain open. |
| R24 | Preserve source-authored user questions, approvals, and feedback as resumable interactions answered by the actual user. | Required behavior lacks a demonstrated complete user-wait path. |
| R25 | Preserve literal source, examples, placeholders, generated prompts, and actual output contracts at the correct stage. | Partial source preservation; full corpus behavior remains open. |
| R26 | Carry authored files, artifact destinations, shared evidence, and tool operations across worker boundaries. | Existing workfolders/tools; complete source-derived artifact journeys remain open. |
| R27 | Preserve operative meaning through conversion and specialization, including each source's own conditions. | Existing intent-preservation machinery; semantic success must be demonstrated on real conversions. |
| R29 | Ship and register the requested prompt corpus, reusable workflows, dependencies, reference, and revision information. | Open. Repository prompt files are not the delivered workflow library. |
| R30 | Return a worker launch command that works from the actual executable/installation and empty handoff folder. | Source launcher derivation improved; existing dist still has older invocation. Packaged journey remains open. |
| R31 | Retire completed ambient assignment markers while retaining development outputs. | Open. Retained workfolders can remain bound to completed work. |
| R32 | Retire terminal active nonce/request lookups while preserving historical assignments, receipts, and recovery. | Open. Include aborted export references from supplemental item 20. |
| R35 | Supply accurate progress, pending work, next actions, and final artifacts through CLI, concierge, and workbench. | Partial receipts/display. Complete continuation and persistent pending-work visibility remain open. |
| R36 | Capture the required working artifacts from Git and ordinary folders, including ignored user files. | Open. Git source capture excludes ignored files. |
| R37 | Use the same content boundary for baseline, diff, and apply, including ignored-content changes. | Open. Copied ignore rules can hide actual edits. |
| R38 | Keep ephemeral assignment identity out of development patches and source projects. | Open. Marker contamination chain remains supported by source. |
| R39 | Select workfolder change tracking independently of knowledge serialization. | Open. JSON knowledge currently forces file-based tracking. |
| R41 | Make one Ctrl-C exit the actual CLI/MCP launch path gracefully while stdin is still open. | Reopened. Source and dist portable MCP both remained running until stdin closed in the review probe. |
| R42 | Make client exit, workflow abort, resumable interruption, worker cleanup, shared-service ownership, and test teardown coherent. | Open implementation/integration work. Service lifetime and abort selection remain part of this item. |
| R44 | Build and ship the chassis's functional Metaform for using interfaces, importing workflows, and constructing modules. | Explicitly agreed and unimplemented. A generated command catalog does not fulfill it. |
| R45 | Connect functional self-understanding with live installed modules and workflows. | Partial command discovery; integrated functional account and available procedures remain open. |
| R46 | Provide the public integration interface that keeps storage/execution ownership in the chassis and lets modules reuse lifecycle services. | Explicitly agreed and unimplemented. Community handlers still receive internal App. |

## Documentation and built-in reference remain required work

| ID | Remaining required outcome | Current disposition |
| --- | --- | --- |
| R02 | Every module supplies usable command, argument, default, output, lifecycle, configuration, and example reference inside the tool. | Open. Source has 109/111 command and 35/287 parameter descriptions, zero command examples, and no module settings declarations. Short descriptions do not establish usable help. |
| R06 | Explain each command's module ownership, purpose, working context, and relationship to settings/worker operations. | Partial inventory. Organize reference rather than treating 111 declarations as self-explanatory. |
| R17 | Clearly distinguish printing/exporting guidance, installing a skill, registering a harness, and actually beginning work. | Source help/install improved; shipped reference and complete entry path remain open. |
| R20 | Explain and expose literal prompt import versus executable workflow conversion, application, and reuse. | Some repository documentation exists; the distributed user path remains incomplete. |
| R50 | Synchronize module-owned reference, runtime instructions, repository docs, implementation status, and actual distribution; retain reproducible evidence. | Open across the backlog. Fix stale docs as deliverables, preserve dated historical evidence, and record source versus delivery status. |

These five are broad reference workstreams. The supplemental and decision-recovery tables below retain the specific documentation repairs within them. Calling a question “already settled” never closes those repairs.

## Verification and delivery work retained from the original list

| ID | Required demonstration | Current disposition |
| --- | --- | --- |
| R28 | Real model-produced conversion of the seven root source prompts, retaining assignments, generated definitions, and representative execution. | Open. Hand-authored fixture answers do not establish conversion quality. |
| R33 | Exact run/request attribution, sibling isolation, repeated next, and receipt replay through public transports. | Preserve working behavior and fix the wrong-run answer defect; supplemental item 4 is explicitly retained here. |
| R34 | Fresh and retained workfolder completion, durable outputs, interrupted cleanup, and replay without cross-request deletion. | Some fixture behavior established; lifecycle integration remains open. |
| R40 | Actual edit location, baseline, additions, edits, deletes, binaries, renames, and relevant metadata for repository/plain-directory work. | Open full-journey evidence. An empty analysis folder is not a copied development folder. |
| R43 | Fresh direct executable, installed CLI, supported MCP, install/update, and portable continuation journeys with recorded artifact/interpreter identity. | Open. Current dist is stale; source checks do not close it. |
| R47 | Create/import, discover, run, customize, share, install, and remove a useful workflow and module using delivered guidance alone. | Open. Requires the already-agreed customization system. |
| R48 | Run the actual shipped user journeys and targeted regressions against observed failures. | Open. Include first launch/help, module removal, settings, onboarding, workbench, handoff/diffs, and interruption. |
| R49 | Map existing tests to substantive behavior, identify real gaps and redundant mirrors, and keep semantic evaluations distinct. | Open audit. Eight targeted passes were not this audit or a product-quality verdict. |

## Full disposition of the 76 supplemental entries

“Mapped” means the detailed issue remains part of the named R work; it is not dropped or claimed fixed. “Additional I/D/V” adds a separately identifiable work entry absent from the original R list's specific outcomes. Original numbers and merged-issue IDs are retained. Broader proposed remedies are separated while their underlying failures remain.

| Original # / issue | Destination | Concrete remaining work |
| --- | --- | --- |
| 1 / A2 | Mapped R04, R18 | Parse install arguments before project creation/service registration. |
| 2 / A3 | Mapped R42, R48 | Repair service/process lifetime and test teardown; choose a suitable idle/ownership mechanism without disrupting other clients. |
| 3 / C1 | Mapped R01, R05, R33 | Keep help, typos, status, and explicit workflow answer forms meaningful in active modes. |
| 4 / C2 | Mapped R33 | Fix wrong-run answer attribution through explicit run/request or nonce identity. Blanket schema rejection is not the required remedy. |
| 5 / C3 | Mapped R01, R02, R35 | Reconcile raw/parser spellings, bound-folder next, and missing put help; document usable forms. |
| 6 / C4 | Mapped R31, R38 | Retire stale ancestor markers without rebinding old requests to new work. |
| 7 / B6 | Mapped R18, R35 | Recover onboarding after Best Practices is removed/incomplete and return a usable next action. |
| 8 / I1 | Additional I: S08 | Restore semantic browsing during exclusive layer generation while preserving worker assignment identity. |
| 9 / F1 | Additional I: S09 | Replace erroneous subset/join enumeration with the Knowledge Tool: generic node knowledge plus its complete applicable composite, exact question preview, retained instruction and per-context origins for reinference. Verify additions, removals and ports without regenerating unaffected generic knowledge. The million-question calculation is defect evidence, not an accepted workload. |
| 10 / H1 | Additional I: S10 | Repair/diagnose lost recursion inputs and misleading unresolved placeholders. A blanket ban on running parents is not established. |
| 11 / G3 | Additional I: S11 | Include recorded transformation mappings in compare impact and expose required source/mapping arguments through CLI. |
| 12 / J2 | Additional I: S12 | Correct baseline mode normalization so unchanged files do not become false modifications/full stored copies. |
| 13 / J1 | Additional I: S13 | Make implicit auto-build behavior controllable, documented, and correctly scoped in tests. It is an awaited changed-hash build, not unconditional after every command. |
| 14 / L2 | Additional I: S14 | Make demos run from a fresh clone without existing scratch state, machine-specific paths, or overwriting tracked evidence by default. |
| 15 / L1 | Additional I: S15 | Provide a documented, working real-sample loading path. Choosing historical MGM as the first README example is separate from making the sample usable. |
| 16 / D4 | Additional I: S16 | Support evidence access for binary artifacts, including photographs, under the established arbitrary-artifact intake contract. |
| 17 / B2 | Mapped R13–R16 | Remove unnecessary full schemas/manuals from startup while keeping complete feature/worker reference available when needed. |
| 18 / C5 | Mapped R08–R12 | Make debug's persistence, disabling operation, and CLI flag behavior explicit and usable. |
| 19 / H2 | Mapped R05, R35 | Explain when CLI drive cannot execute because there is no sampling context instead of silently returning the same assignment. |
| 20 / H3 | Mapped R31–R34, R42 | Retire terminal active dispatch artifacts and prevent dangling aborted-intake workflow roots in exports; preserve history. |
| 21 / A4 | Additional I: S21 | Reconcile installer and uv launcher ownership so installation/upgrades do not silently overwrite each other's entry points; document the result. |
| 22 / I2 | Additional I: S22 | Reproduce and repair retained History canvas-offset/click failure after layout controls expand. |
| 23 / I4 | Mapped R05, R35 | Retain pending-work visibility after navigation/reload. Transient generation details already exist; new confirmation controls belong to X05. |
| 24 / M1 | Additional D: S24 | Mark superseded semantic directions, correct current authority links, and distinguish v1 samples/primer/glossary content from current intake. Preserve historical wording. |
| 25 / L3 | Additional I: S25 | Stop comparison runs rewriting source prompts; pin reproducible baseline identity and update the evidence instructions. |
| 26 / K1 | Mapped R02, R06, R09, R46 | Publish the complete module-manifest/interface reference, including visibility, handlers, schemas, portable files, module paths, and settings. |
| 27 / A6 | Additional I: S27 | Expose delivered version/source identity in an obvious CLI operation and reference. |
| 28 / A12 | Additional I: S28 | Make the documented viewer launch work when its fixed default port is unavailable; explain actual port/URL behavior. |
| 29 / C7, G11 | Mapped R05, R18, R35 | Return actionable model discovery/selection/intake guidance for missing or ambiguous model selection, including archives. |
| 30 / C8 | Mapped R05, R16 | Provide useful compact human semantic reads while retaining complete machine-readable dependencies. |
| 31 / C9 | Mapped R02 | Add missing history diff/extract command reference. |
| 32 / C11 | Mapped R42 | Allow CLI abort to identify a nonexclusive run; document and verify its cleanup. |
| 33 / C13 | Additional I: S33 | Make expansion discovery usable without an already-known target and make layer publication reachable during its own run. |
| 34 / D9 | Mapped R14, R35, S24 | Make completion guidance describe the actual publication/next step and label historical intake copies. |
| 35 / D10 | Additional I: S35 | Declare expansion opportunities in the foundation schema and explain their manual model-expand route. |
| 36 / D15 | Additional I: S36 | Check artifact-context input against its declared contract and expose useful diagnostics; preserve semantic annotation behavior. |
| 37 / E3 | Additional I: S37 | Give a blind-spot layer a usable name independent of its full request text and document the input. |
| 38 / F3 | Additional D: S38 | Explain absent, null, and empty layer selection distinctly in built-in knowledge reference. |
| 39 / F6 | Additional I: S39 | Reconcile region/target names and enable recovery of missing layer coverage without needlessly repeating completed work. |
| 40 / F7 | Additional I: S40 | Make a removed layer's retained recipe/history inspectable through the public interface with its status explicit. |
| 41 / F10 | Additional V: S41 | Measure knowledge-read cost on the real sample and retain findings; implement caching only if the measured problem warrants it. |
| 42 / G4 | Additional I: S42 | Preserve clone replay identity despite changed purpose text and document nonconflicting rebase behavior. |
| 43 / G8 | Mapped R02, R06, S24 | Label legacy graph commands and explain their current versus historical role. |
| 44 / G7 | Additional D: S44 | Supply a usable transformation patch example, including authored narrowing, mappings, and traceable correction meaning. |
| 45 / H5 | Mapped R02, R21–R23 | Complete the workflow step/reference table and deliver the actual expression grammar to the converter. |
| 46 / H9 | Addressed source claim; mapped R25, R43 verification | Public file import already derives base_dir; isolated external-folder probe passed. Preserve that behavior in distribution verification and accurate docs. Do not reimplement it. |
| 47 / I5 | Mapped R03, R05, R18 | Correct empty-state onboarding text and exclude seeded supporting prompts/rules from the displayed actual-artifact Element count. |
| 48 / I6 | Additional D: S48 | Label the historical MGM screenshot correctly and add a real Foundation screenshot once captured by the retained live demonstration. |
| 49 / I10 | Mapped R03, R05 | Make the returned browse URL directly usable and documented. A new auto-open feature is not necessary to satisfy this. |
| 50 / I11 | Additional V: S50 | Make browser checks reproducible with declared dependencies and isolated output; retain the relevant repaired browser journey. |
| 51 / I13 | Established retirement; mapped R02, R10, R43 | Remove retired Ladybug/Cypher support and its advertised guidance; preserve SQLite/JSON/service coverage. |
| 52 / J3 | Mapped R02, R05 | Explain/diagnose build source applicability. Preserve valid explicit-source builds instead of hiding the command solely from selected-project layout. |
| 53 / J4, J5 | Mapped R02, R26, R43 | Explain export destination, sibling working folder, dependency boundary, and unsupported module imports; verify actual portable use. |
| 54 / J6 | Mapped R05, R43; proposal X10 | Make merge effects and CI prerequisites/failures understandable. New merge dry-run and authentication-preflight mechanisms remain explicit proposals. |
| 55 / J8 | Mapped R02, R43 | Say that package import creates a portable copy; distinguish it from reconciliation into the registered source project. |
| 56 / J13 | Mapped R10 | Show effective service home and precedence. An extra warning policy is not needed to expose the actual value. |
| 57 / J12 | Mapped R43, R48, R50 | Investigate retained failed CI runs and record current applicable results; do not treat an old remote failure as freshly reproduced. |
| 58 / L4 | Mapped R28, R50 | Point the example reference at the completed live-comparison arms. |
| 59 / L5 | Mapped R02, R19, R47–R50 | Inventory/document examples and placement, inspect unexplained/stale examples, verify supported ones; retain any retirement as an explicit disposition. |
| 60 / L6 | Mapped S24, R50 | Label MGM as a historical v1 two-pass record and expand its acronym. |
| 61 / M2 | Mapped S24, R02, R50 | Provide a docs index and synchronize current terminology/authority across README, SPEC, primer, and semantics. |
| 62 / M3 | Mapped R02, R33, R50 | Correct model-selection and answer-mode examples alongside the intended CLI behavior. |
| 63 / M4 | Mapped R49, R50 | Add current scoped verification results while preserving dated historical evidence and separating test counts from demonstrated quality. |
| 64 / N9 | Mapped R50 | State the already-defined SPEC success signal in the README's implementation/status account. |
| 65 / N8 | Mapped R43, R48, R50 | Include the existing installation tests in eventual change delivery so CI receives them; currently untracked. No commit is performed by this review. |
| 66 / C6 | Mapped R02 | Document the actual --no-exclusive boolean form. |
| 67 / B4 | Mapped R16, R18, R43 | Verify and document which hosts apply instructions and support sampling. |
| 68 / A11 | Mapped R17, R43 | Verify registration on machines with VS Code/Cursor installed. |
| 69 / H4 | Mapped R23, R48, R49 | Check output/branch behavior and existing coverage; give the unread requires_answer field an evidence-based disposition. |
| 70 / D11, D13 | Mapped R22, R33, R42, R48 | Verify reusable Types, v2 abort during harness execution, and contract-2 actor-gateway delivery. |
| 71 / F11 | Additional V: S71 | Verify knowledge.explain through the public read-operation boundary. |
| 72 / J9 | Mapped S12, S13, R37, R43, R48 | Verify history diff, imported handoff republication, and auto-build behavior. |
| 73 / A10 | Mapped R43, R48 | Verify archive installation and Windows launcher behavior. |
| 74 / H9, I8 | Mapped R26, R48 | Existing attachment projection test passed; retain any uncovered attachment journey and GUI Edit revision verification. Do not call the entire item fixed. |
| 75 / L8 | Mapped R34, R42, R49 | Investigate the retained workfolder flake/cross-test cleanup if reproducible; preserve the observation without inventing its cause. |
| 76 / E2, H6, L9, K6 | Mapped R28, R43–R45, R47–R50 | Retain live blind-spot, Codex intake, real-codebase v2 intake, and self-intake evidence. A self-intake demonstration does not by itself complete packaged chassis understanding. |

## Work recovered from the former decision list

These six additional entries are retained separately because the R/S work does not fully name their semantic outcome. Other settled questions map to existing R/S items in the next table.

| ID | Category | Remaining outcome |
| --- | --- | --- |
| Q03 | I | Supply authoritative known base/prefix meaning to intake and reads and surface missing namespace context consistently. Verify a valid document.guide account can be inspected without an unresolved known base; do not fabricate intermediate meanings. |
| Q05 | V | Compare actual v2 semantic components and rulebook delivery against established wording; repair any demonstrated omission and document the real delivery path under S24/R02. |
| Q17 | I | Remove the hardcoded program-code name substitution through the established recorded-name/length mechanism. Verify node/relationship questions preserve the recorded names and exact instruction. |
| Q18 | V | Check participant-only relationship context coverage against the recorded participation model and fix any demonstrated omission. Preserve established ancestor visibility and branch-specific applicability. |
| Q21 | I | Preserve the supplied Medium distinction through authoring, storage, retrieval, and prepared context; verify corrections retain before/after meaning, reason, and evidence through existing records or the minimally necessary representation. |
| Q26 | I | Carry design-stage context dependencies through generated grouping/instructions to attachment impact analysis. Verify that changing a design dependency identifies the resulting generated knowledge as affected. |

## Every former question retains its implementation/documentation consequences

| Decide # | Established work that remains | Separate new choice, if any |
| --- | --- | --- |
| 1 | R14, R22, R48, S24: verify complete Native account delivery, inspect source_evidence payload, and document the outside implementation frame. | X01: exact treatment of captured raw implementation excerpts, if the inspected case remains ambiguous. |
| 2 | R18, R35: complete foundation publication and Best Practices continuation; synchronize answer/next/help. | No new product decision between implementation methods. |
| 3 | Q03, S24, R02: authoritative bases/prefixes, diagnostics, and clear reference. | Ask only about a genuinely missing authoritative definition; five bases are settled. |
| 4 | R14, R48, R02: verify original requests/destination context in reinference and document actual role use; inspect dormant reinfer role. | A filename choice is routine implementation, not an owner-level approval. |
| 5 | Q05, S24, R02: semantic wording comparison and correction of legacy r1–r4 claims about v2. | No blanket decision to add another historical rule bundle. |
| 6 | R02, R18: document that evidence_handles/existing_model reach prompt inputs and what runtime does. | X02: model/revision identity for explicitly requested re-intake. |
| 7 | R04, R10, R17, R18, R43: usable per-client project selection, actual launch behavior, and host reference. | Client ownership is settled; resolve only a concrete unsupported host requirement. |
| 8 | R16, R18, R35: keep periodic blind-spot guidance and existing analyses discoverable. | X08: dedicated last-run tracking is one possible additional mechanism. |
| 9 | Q03, S44, R02: surface required narrowing meaning and document an authored relocation example. | Rejection gates are excluded from this repair scope; annotation behavior is settled. |
| 10 | R03, R05, R18, R48: deliver usable project selection, inspector information, and documented current editing behavior. | X05: additional controls and specifically named editable fields. |
| 11 | R02, R43, S24: remove the retired Ladybug dependency, backend and Cypher analysis interface. | Settled by Rich on 2026-09-11; not a new optional-dependency decision. |
| 12 | R02, R09, R19: accurate imagegen/reference and current example capability/limitations. | X06: expanded image options or a particular photograph workflow not already established by the supplied corpus request. |
| 13 | R43, R50: inventory metadata, sources, generated artifacts, evidence, and ownership. | X07: license/authorship/public package identity. Preserve protected instructions and evidence; no blanket cleanup authorization. |
| 14 | R35, R02: retain annotations and surface accumulated completion diagnostics. | None; do not ask again whether to reject schema-mismatched semantic outputs. |
| 15 | R14, R22, R48, R02: verify worker delivery of required fields/schema and correct help. | Repeating field names in prose is a delivery choice only if needed. |
| 16 | R02, R06: document actual batch/concurrency/steps effects and correct misleading controls while preserving active behavior. | Do not remove functional --steps as vestigial. |
| 17 | Q17, R02, R14: recorded naming, unchanged instruction, accurate module guidance. | No new semantic direction required. |
| 18 | Q18, S24, R02: participant coverage check and precise visibility/applicability reference. | Backward visibility is already required. |
| 19 | R02: document current direct/target advice scope and prepare a concrete example. | X03: intended descendant applicability of property-combination advice. |
| 20 | R02, R14: document task's actual role and deterministic target/depth/budget selection. | X09: using task text to choose a different semantic region. |
| 21 | Q21, S44, R02: preserve Medium and traceable correction meaning. | An entire new subtype taxonomy or correction class is not automatically required. |
| 22 | R43–R45, R50: document current global packaging behavior and deliver the agreed chassis account. | X08: additional global seed content beyond established requirements. |
| 23 | S14, R50: inventory dist review artifacts and clarify evidence versus build output. | Concrete relocation/destruction only after its scope is known; this does not block system repairs. |
| 24 | R02, R10: explain supported command availability/configuration and actual disabled_commands storage. | X08: a new public mutation surface for an internal control. |
| 25 | R06, R07, S08, R43: explain writable workbench behavior and correct confirmed dispatch/visibility inconsistencies. | X05: a separate read-only serving mode. |
| 26 | Q26, R48, R50: repair and demonstrate the causal design-to-generation dependency chain. | None; provenance is already required. |
| 27 | R48–R50: retain misplaced-property evidence, investigate the semantic cause, and keep quality claims accurate. | New gates are excluded under Rich's current observe-first instruction. |
| 28 | S24, S48, R43, R50: preserve historical access, label v1 records, and capture a current Foundation demonstration. | Retirement of History/Compare is excluded from repairs; current direction retains historical access. |

## Genuinely unresolved choices and separate proposals

This list is for the particular change named. It is not a new approval checklist for the main backlog. Existing requirements continue without reconfirmation.

| ID | Narrow decision/proposal | Impact and what proceeds independently |
| --- | --- | --- |
| X01 | Whether a specific captured implementation excerpt belongs in the outside assignment, after inspecting that payload. | Complete Native functional understanding must be delivered. Payload inspection/documentation proceeds; do not remove Native understanding wholesale. |
| X02 | Whether explicit re-intake updates an existing artifact model/revision or creates a separately identified model, and how the caller selects that behavior. | Affects model identity. Current behavior/input documentation and broken continuation repairs proceed. |
| X03 | How generated advice conditioned on a property combination/receiving relationship applies to descendants. | Affects knowledge scope. Established property propagation and its reference remain unchanged. |
| X04 | Splitting a Knowledge Tool request across multiple assignments or changing its partial-answer protocol. | A separate proposal only if the corrected workload demonstrates a need. The user's base-plus-composite operation is settled and belongs to S09; neither subsets nor million-question batching require user approval as part of that repair. |
| X05 | Additional workbench controls/fields, confirmation dialogs, or a new read-only mode. | Separate concrete UX proposals. Usable existing selection, read availability, and pending-work visibility remain repairs. |
| X06 | Additional imagegen controls and a particular photograph workflow beyond the agreed bundled source corpus. | Specific feature scope. Existing image functionality/reference and arbitrary-artifact intake remain work. |
| X07 | License, authorship, and changed public package identity. | Owner/release decisions. Metadata inventory and all local functional/reference work proceed. |
| X08 | Additional mechanisms: last-blindspot field, new global seed content, public disabled-command mutation. Ladybug retirement is established repair work, not an extra proposal. | Independent proposals, not prerequisites for accurate settings/reference or the agreed chassis Metaform. |
| X09 | Task-text-driven semantic region selection. | Additional selection behavior. Current deterministic grounding and truthful reference proceed. |
| X10 | New merge dry-run/authentication-preflight mechanisms. | Separate additions. Explain current operation effects/prerequisites and report actual failures now. |

Blanket schema rejection, arbitrary enumeration caps, new semantic acceptance gates, blanket running-parent recursion bans, and removal of historical access are not included as required remedies. The actual routing, capacity, missing-input, semantic-quality, and stale-documentation problems remain in the tables above. Removing an unsupported remedy does not remove the issue.

## Completion evidence and work order

The original R list's per-item completion evidence remains linked and applicable. Additional S/Q items are completed by demonstrating the outcome in their row through the relevant public operation, correcting the owning module's help, and verifying the delivered form. Report-only profiling/coverage tasks retain the actual result rather than inventing a code fix. Use existing meaningful tests where they prove the behavior; add focused reproductions for uncovered failures. No one-test-per-row requirement is implied.

1. **Restore a usable entry experience while addressing corruption and shutdown:** module-organized help/reference, actual project selection, settings scope, active-mode commands, correct answer attribution, marker cleanup, graceful exit. Documentation work runs alongside these repairs.
2. **Complete the module-driven system:** module-owned capability/guidance/settings contributions, live next actions, concise concierge orientation, complete workflow discovery, and coherent install/distribution.
3. **Complete reliable work execution and semantic access:** workfolders/diffs, public reads during work, publication, layer recovery, transformations, causal dependencies, and correct semantic/name delivery.
4. **Deliver the already-agreed higher-level system:** actual source-faithful conversion/library, built-in chassis Metaform, public customization interface, sharing, and demonstration through the distributed tool.

The completion standard is the original agreed journey: a fresh user and a fresh AI can use the distribution alone to discover, start, delegate, answer, resume, inspect results, and exit. Correct metadata or passing selected tests cannot substitute for that outcome.

## Accounting and scope

The checked inventory contains **84 established work entries: 62 implementation/integration, nine documentation/reference, and 13 verification/delivery entries**. These retain all original issues through explicit overlap mappings. Ten separate proposal groups identify additional or unresolved choices. These are work-entry counts, not an assertion of 84 independent reproduced bugs. Original references are retained even where they overlap, contain a corrected claim, or propose a separate choice. Supplemental 46's particular source defect was disproved; supplemental 74 has existing attachment coverage but retains the GUI journey. No complete R item is closed as delivered merely because a source fragment improved.

Preparing this reconciliation changed documentation only. The user subsequently authorized implementation; actual changes, tests, reviews, and distribution status are tracked in [execution status](release-quality-status.md). This inventory alone is not evidence that any repair is delivered.
