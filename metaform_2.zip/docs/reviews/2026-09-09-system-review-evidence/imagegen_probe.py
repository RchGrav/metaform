"""Run from review-checkout with PYTHONPATH=src .venv/bin/python ../review-imagegen/reproduce.py.
No real model/provider calls. Each run uses an isolated temporary directory.
"""
import asyncio
import base64
import os
import subprocess
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from metaform.modules import _imagegen as im
from metaform.app import App
from metaform.intake import Intake
from metaform.registry import Registry
from metaform.util import write_json

PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aY2cAAAAASUVORK5CYII=')


def run(root):
    status = SimpleNamespace(path='unused-codex', generated_images_dir=str(root / 'shared-generated'))
    old = root / 'old.png'
    old.write_bytes(PNG)
    os.utime(old, (1, 1))
    def no_generation(command, **kwargs):
        return subprocess.CompletedProcess(command, 0, f'Cannot generate an image. Existing image: {old}')
    output = root / 'reported-success.png'
    path, _ = im.run_codex_image(status, 'request', [], output, runner=no_generation)
    assert path == output and output.read_bytes() == PNG and output.stat().st_mtime == 1
    print('REPRODUCED stale stdout-mentioned PNG accepted; output mtime =', output.stat().st_mtime)

    recent = root / 'recent.png'
    recent.write_bytes(PNG)
    path, _ = im.run_codex_image(status, 'request', [], recent, runner=lambda command, **kwargs: subprocess.CompletedProcess(command, 0, 'No image generated.'))
    assert path == recent
    print('REPRODUCED unchanged recent output accepted despite no generation')

    def unrelated_session(command, **kwargs):
        directory = Path(status.generated_images_dir)
        directory.mkdir()
        (directory / 'unrelated-session.png').write_bytes(PNG)
        return subprocess.CompletedProcess(command, 0, 'No image generated for this request.')
    path, _ = im.run_codex_image(status, 'request', [], root / 'other-session-result.png', runner=unrelated_session)
    assert path.read_bytes() == PNG
    print('REPRODUCED unrelated shared-directory image accepted')

    write_json(root / 'home' / 'config.json', {'knowledge_mode': 'legacy', 'graph_backend': 'json', 'auto_build': False})
    app = App(root / 'project', root / 'home', binding=False)
    engine = Intake(app)
    native = engine.start()
    run_id = native['run_id']
    objects = {'code': {'entity_desc': 'Program code', 'entity_schema': 'metaform:element', 'entity_json_obj': {'en': 'Program code', 'aliases': [], 'notes': 'Exact Type context.'}}}
    engine.submit(run_id, native['request_id'], {'elements': objects, 'joins': []})
    proof = engine.next(run_id)
    engine.submit(run_id, proof['request_id'], {'elements': {key: proof['inputs']['elements'][key] for key in proof['inputs']['new_type_ids']}, 'archaeology_objects': {key: proof['inputs']['elements'][key] for key in proof['inputs']['handoff_ids']}})
    job = engine.batch(run_id)[0]
    arguments = {'prompt': 'A red cube', 'run_id': run_id, 'request_id': job['request_id'], 'dry_run': True}
    result = asyncio.run(Registry(app).call('imagegen.generate', arguments))
    assert 'SAVED: ' + str(app.project / 'image.png') in result['prompt']
    assert job['workfolder'] not in result['prompt']
    print('REPRODUCED Latent assignment output routed to project instead of workfolder')
    print('Assigned workfolder:', job['workfolder'])
    print('Prepared destination:', app.project / 'image.png')
    (Path(job['workfolder']) / 'source.png').write_bytes(PNG)
    try:
        asyncio.run(Registry(app).call('imagegen.generate', arguments | {'image': 'source.png'}))
    except ValueError as exc:
        assert str(app.project / 'source.png') in str(exc)
        print('REPRODUCED workfolder edit fails:', str(exc))
    else:
        raise AssertionError('Expected wrongly routed relative input to fail')

    class Status:
        def __init__(self, ready):
            self.ready = ready
            self.problems = () if ready else ('missing dependency',)
        def as_dict(self):
            return {'ready': self.ready}
    im._STATUS_CACHE.clear()
    with patch.object(im, 'probe_codex', side_effect=[Status(False), Status(True)]):
        try:
            im.require_codex()
        except im.ImageToolError:
            pass
        else:
            raise AssertionError('Expected initial readiness failure')
        healthy = im.call_tool('image_status', {'refresh': True})
        assert healthy == {'ready': True}
        print('Provider status after remediation:', healthy)
        try:
            im.require_codex()
        except im.ImageToolError as exc:
            print('REPRODUCED stale failed readiness after healthy status:', str(exc).replace('\n', ' '))
        else:
            raise AssertionError('Expected cached readiness defect')
    im._STATUS_CACHE.clear()


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='run-', dir=Path(__file__).resolve().parent) as directory:
        run(Path(directory))
    print('All defect reproductions confirmed; no provider invoked.')
