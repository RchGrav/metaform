> Source provenance: the primary reviewer verified all 185 text files against Git blob hashes at `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Original lane notes below are retained with script links adjusted; use the evidence README for commands from the repository root.

# Semantic preparation and intake review lane

Baseline: parent-provided remote baseline `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`, source archive at `<reviewed-source>`. This directory has no `.git`; I did not independently verify its content against remote. No repository code or instructions modified. All experiments use temporary projects/homes under `review-semantic`, with legacy SQLite knowledge and the same intake/knowledge operation implementation used by other modes.

## Confirmed findings

### S1 — Reusing distinct completed structures silently collapses joins with the same original authored ID (P1)

**Location:** `src/metaform/intake.py:57-63`, `src/metaform/intake.py:73-76` (`_owned`, `_remember`).

The public `intake.inference` output correctly returns distinct globally namespaced join IDs for independent Type inferences B and C. Both can legitimately retain `authored_id: dependency`. When another focal inference A submits those returned joins, `_owned` selects their `authored_id` before their distinct `id`, replaces `inference_type` with A, and derives both new IDs from `[A, dependency]`. `_remember` converts the list into an ID-keyed dictionary and silently discards the first relationship. This is not a graph-schema error or a collision in the agent's submitted IDs: its submitted IDs are distinct.

**Reproduction:** Last case in `reproduce.py`: complete B→D and C→E independently, each using the local authored name `dependency`; obtain both graphs using `Intake.inference`; include their joins unchanged in A's completion answer. Output `REUSE_JOIN_IDS` shows two unique submitted IDs and purposes, but only the C→E purpose in A's retained completion graph. Original B/C inferences remain intact.

**Violated meaning/contract:** `src/metaform/data/semantics/archaeology.md:9` explicitly directs retrieval and reuse of completed dependency structure; `docs/architecture.md:190-194` promises retention of focal authored structure and namespaced join IDs; `docs/SPEC.md:CAP-1` requires reusable represented semantic understanding. Reuse should not delete one of two distinct submitted relationships.

**Consequence:** A successful completion silently loses part of the submitted expert structure. Subsequent A reuse starts from that reduced snapshot, even though original B and C data still exist. Fix identity translation to retain the originating inference identity when importing already-owned joins, including reified references, while keeping ordinary incremental local authored-ID updates working. Do not solve by requiring every expert to rename otherwise unique retrieved IDs manually.

### S2 — A clean proof record does not keep project OPs out of the fresh Latent assignment when its schema contains them (P1/P2; configuration-dependent)

**Location:** `src/metaform/intake.py:213-216`; `src/metaform/schemas.py:26-28, 81-108`.

Proof preparation returns clean `archaeology_objects`, but the assignment independently loads the registered schema again. Registry resolution overlays project schemas over global/bundled schemas; bundling copies schema `description`, `$comment`, examples and referenced schema prose unchanged. Proof's response format only prepares records, not a corresponding decontextualized schema.

**Reproduction:** Register `custom:validator` for the selected project with schema description `PROJECT OP: project.checkout receives code.validator to reject orders over its merchant-specific purchase limit.` Native returns a Type using that schema; proof returns a clean record with no such OP. The next assignment is `context: fresh`, its object contains no sentinel, but its `inputs.schema.description` contains the entire project relationship verbatim. Output `SCHEMA_CONTEXT` captures this.

**Violated source:** `docs/SPEC.md:88,210,309` excludes project OP relationships from Latent construction and its input, not just from the Element JSON. `src/metaform/data/semantics/proof.md:7` establishes the preparation boundary and preservation of Contextual records. This is a concrete known project relationship, not the open question of the general contents of contextual OPs.

**Consequence:** A project-owned schema can supply exactly the relational answer the Latent pass is supposed to derive independently. That answer can then be retained as reusable global inference. Confirmed input contamination; no claim that a live model copied it. Extend preparation to all supplied schema context while preserving validation structure and Contextual source records. This need not entail indiscriminately removing semantically useful descriptions.

### S3 — Every fresh built-in intake role receives the superseded graph-merging instruction (P2)

**Location:** `src/metaform/data/semantics/glossary.md:20`; `src/metaform/prompts.py:46-60`; `src/metaform/intake.py:153-166`.

The glossary says: `When complete the two graphs are merged by matching the NS with fields indicating the source of every OP`. `prompts.seed` concatenates this entire glossary with each of Native, Proof and Latent role text. All three fresh assignments therefore issue the old semantic model. The current role text does not carry the SPEC's independent-graph/structural-similarity replacement. This is effective runtime input, not merely unused historical documentation.

**Reproduction:** `STALE_PROMPT` in the saved output shows all three fresh roles contain `obsolete_merge=true`, `independent_graphs=false`, `shape_similarity=false`, with prompt revisions:

- Native: `eb88a6a858cec14dba64fbdf44651781f6de1f18f1eae349c285f7d0e7034059`
- Proof: `da7c9a42d59e954c7984d3a4931a066fc8a6b0e2bc0777b18d3b347f04cba057`
- Latent: `1a3ec7258b20c6b7f50fbf9ea7047a7d92375036e7023b1359e1592c0dad27da`

**Violated source:** `docs/SPEC.md:212` requires complete independent graphs and explicitly says they are not merged, averaged or rewritten into a third semantic graph. Semantic equation preservation (`docs/semantics/semantic_equation_reuse_rule.md:5-17`) requires composition to preserve the selected authoritative relationship.

**Consequence:** The reasoning agents are oriented toward an obsolete system purpose while the current storage/similarity code implements source separation. This does not establish that storage actually merges graphs or that a live model followed the stale sentence. Correct the maintained semantic source and use the existing provenance-aware migration pattern for recognizable bundled prompt revisions, preserving custom text and issued snapshots.

**Migration reach:** `prompts.py:11-24,63-71` upgrades only enumerated historical text digests. Arbitrary authored text stays unchanged; pending assignments retain snapshots. `rulebook.py:12-16` inserts absent rules without overwriting existing rules. This preservation is documented and should not itself be reported as a defect. A deployment of a corrected bundle therefore must explicitly account for stored current built-ins too.

### S4 — Referring to an existing incomplete dependency in a join does not schedule its own inference (P2)

**Location:** `src/metaform/intake.py:391-392`, also incremental path `:102`; finish path `:114-125`.

Scheduling examines answer Element keys and the optional `archaeology` list, but not references in joins. A Latent Expert can look up admitted Type B, then author the A→B relationship using B's existing ID without redundantly authoring B's record. A's graph correctly resolves B on retrieval, but B never enters the queue. `_finish` visits B for import, sees its inference graph is absent, and nevertheless terminates the run.

**Reproduction:** Put B globally with source `promoted`, intake A, then complete A with only its own Element record and one receiving-entity join to B. `JOIN_DEPENDENCY` reports `run_status=complete`, `a_complete=true`, `b_complete=false`, `queue=[]`. A's returned graph includes both Type records and the A→B join with no unresolved references.

**Violated source:** `src/metaform/data/semantics/archaeology.md:5`: “Where completed inference is missing, the dependency receives its own independent assignment”; `:7` says admitted incomplete Types may be referenced while awaiting their assignment. The issue is missing scheduling, not that A's focal-completion flag must certify B's completion; the latter is explicitly not required.

**Consequence:** The retained graph can permanently stop at a dependency Type definition without developing its independent relationships. Requires the agent to discover an undocumented redundant record/explicit-queue convention to achieve the authored behavior. Use owner/kind-aware join reference extraction to discover eligible referenced Types and schedule incomplete dependencies; preserve focal-only completion semantics.

## Verification and coverage

Executed:

```sh
.venv/bin/pytest -q tests/test_rulebook.py tests/test_intake_prompt_upgrade.py tests/test_intake_handoff.py tests/test_intake_pipeline.py
# 55 passed in 6.78s
.venv/bin/python semantic_probe.py
```

All four isolated repro cases complete successfully and their factual outputs are in `reproduction-output.txt`. They use authored deterministic fixture answers, not live models. Thus they establish issued context, state transitions, reference translation, storage and retrieval behavior, not quality of inferred Type relationships.

| Area | Coverage and result | Remaining limitation |
|---|---|---|
| Semantic authority | Read review role, AGENTS, SPEC, both requested primers, maintained typology/equation/worked-understanding sources, bundled active roles and provenance, current-work and relevant workflow/architecture sections | Did not independently retrieve prior conversations; parent owns history/source baseline verification |
| Rules and prompt seeds | Read seeding/snapshot/migration; passed rulebook and prompt-upgrade tests; captured actual fresh roles | No retained user-issued runtime sampled; edited rule preservation intentionally remains |
| Native→proof→Latent | Read all intake paths and module lookup bindings; passed handoff/pipeline tests; new schema-input repro | No live semantic proof or latent provider invocation |
| Completion/reuse | Read shared `inference_operation`, owned joins, completion/import, explicit lookup, global/initial Type distinction; two new scheduling/reuse repros | Legacy SQLite reproduction only; same functions serve service/portable, but no separate backend reproduction in this lane |
| Schemas | Read entire bundled schemas and registry/bundling/annotation; confirmed ED remains in outer `entity_desc`, so absent inner `ed` alone is not data loss | Element-role intake/storage reconciliation remains documented unfinished; no new mandatory schema validation gate inferred |
| Alias/Parametric addresses | Inspected search/get; aliases are matched as raw labels, not expanded Namespace addresses; no Parametric reservation path found | Known incomplete implementation in current-work, not a new source contradiction; no separate address repro |
| Graph source separation | Relevant intake handoff tests pass and source-aware storage/import paths inspected | Main graph/ownership/similarity lane owns broad backend and traversal evidence |
| Higher-order operations | Read SPEC A-5–A-8 and prerequisite semantics | No differentiated live Encounter/operation demonstration in this lane; generic passing fixtures cannot close that evidence gap |

The corrected implementation does preserve literal prompt snapshots, separate proof correction and latent input records, incomplete-vs-complete Type state, and independent focal assignment contexts under the tested cases. Existing tests deliberately check these mechanics and are valuable, but do not detect the four counterexamples above. Contextual OP content is settled by the subsequent actual-artifact clarification; environmental representation questions were not counted as defects in this review.
