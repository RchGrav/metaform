import asyncio, copy, json, tempfile
from pathlib import Path
from metaform.app import App
from metaform.util import write_json
from metaform.workflow import Engine, import_workflow
from metaform.registry import Registry
from metaform.continuation import current, begin
from metaform import workfolders

root=Path(tempfile.mkdtemp(prefix='cases-',dir=None))
def app_at(case, backend='sqlite'):
    home=root/case/'home'
    write_json(home/'config.json', {'knowledge_mode':'legacy','graph_backend':backend,'auto_build':False})
    return App(root/case/'project',home,binding=False)

a=app_at('loop'); e=Engine(a)
import_workflow(a, {'id':'loop','steps':[
    {'id':'each','kind':'foreach','items':{'var':'inputs.items'},'prompt':'Visit {{item}}'},
    {'id':'decide','prompt':'Repeat?', 'transitions':[{'when':{'var':'steps.decide'},'to':'each'},{'to':None}]}]})
j=e.start('loop',{'items':['A']},exclusive=False); rid=j['run_id']
e.submit(rid,j['request_id'],'A'); print('foreach finished:',e.next(rid))
j=e.next(rid); e.submit(rid,j['request_id'],True)
print('foreach reentry:',e.next(rid)); print('job after reentry:',e.next(rid)['step'])

a=app_at('binding'); e=Engine(a)
import_workflow(a,{'id':'two','steps':[{'id':'one','prompt':'FIRST {{who}}'},{'id':'two','prompt':'SECOND {{who}}'}]})
first=e.start('two',{'who':'A'},exclusive=False); sibling=e.start('two',{'who':'B'},exclusive=False)
bound=copy.copy(a); bound.binding={'project':str(a.project),'home':str(a.home),'module':'workflow','run_id':first['run_id'],'request_id':first['request_id'],'nonce':first['nonce']}
leaked=asyncio.run(Registry(bound).call('workflow.next',{'run_id':sibling['run_id']}))
print('bound A reads explicit B:', leaked['prompt'])
asyncio.run(Registry(bound).call('workflow.answer',{'run_id':sibling['run_id'],'request_id':sibling['request_id'],'answer':'ANSWER FROM A'}))
print('bound A answered B:', e.next(sibling['run_id'])['step'])
e.submit(first['run_id'], first['request_id'],'done')
print('old binding current:',current(bound)['prompt'])
print('old nonce begin:',begin(first['nonce'], root/'old-handoff',a.home)['prompt'])

for direction in ('directory-to-file','file-to-directory'):
    a=app_at(direction,'json')
    target=a.project/'entry'
    if direction=='directory-to-file': target.mkdir(); (target/'nested').write_text('old')
    else: target.write_text('old')
    folder=workfolders.create(a); target=Path(folder['path'])/'entry'
    if direction=='directory-to-file': (target/'nested').unlink(); target.rmdir(); target.write_text('new')
    else: target.unlink(); target.mkdir(); (target/'nested').write_text('new')
    try: print(direction, workfolders.apply(a,folder['id']))
    except Exception as exc: print(direction, type(exc).__name__, str(exc))

a=app_at('parallel-folder'); e=Engine(a)
(a.project/'target.txt').write_text('original')
import_workflow(a,{'id':'child','steps':[{'id':'act','prompt':'Edit target.txt'}]})
import_workflow(a,{'id':'parent','steps':[{'id':'fork','kind':'parallel','branches':['child']}]})
p=e.start('parent',exclusive=False,workfolder=True); c=p['parallel'][0]
from metaform.modules.workflow import project_path
print('parallel parent workfolder:',a.load_run(p['run_id'])['workfolder_id'])
print('parallel child actual target:',project_path(a,{'run_id':c['run_id']}))
print('parallel child job workfolder:',c.get('workfolder'))
import sys
from metaform.modules.workflow import drive
a.config['harnesses']={'fixture':{'command':[sys.executable,'-c',"from pathlib import Path; Path('target.txt').write_text('modified by child'); print('done')"]}}
print('parallel child drive:',asyncio.run(drive(a,{'run_id':c['run_id'],'harness':'fixture'},None))['status'])
e.next(p['run_id']); finished=e.next(p['run_id'])
print('parallel original after drive:',(a.project/'target.txt').read_text())
print('parallel parent reported diff:',repr(finished['result']['changes']['diff']))

a=app_at('mcp-mode'); e=Engine(a)
import_workflow(a,{'id':'wait','steps':[{'id':'act','prompt':'Work'}]})
j=e.start('wait',exclusive=False)
from metaform.intake import Intake
from metaform.mcp_server import accept_sample
from mcp import types
Intake(a).start()
result=types.CreateMessageResult(role='assistant',content=types.TextContent(type='text',text='result'),model='fixture',stop_reason='endTurn')
try:
    print('inflight answer after module switch:',asyncio.run(accept_sample(a,{'run_id':j['run_id'],'request_id':j['request_id'],'command':'workflow.answer'},result)))
except Exception as exc:
    print('inflight answer after module switch:',type(exc).__name__,str(exc))

print('root:',root)
