import tempfile
from pathlib import Path
import os, stat, zipfile
from metaform.app import App
from metaform.util import write_json
from metaform import portable
from metaform.registry import Registry
R=Path(tempfile.mkdtemp(prefix='metaform-portable-review-'))
write_json(R/'home'/'config.json', {'knowledge_mode':'legacy','graph_backend':'json'})
app=App(R/'project', R/'home', binding=False)
module=app.root/'modules'/'linked'
write_json(module/'module.json', {'id':'linked','commands':[{'name':'run','handler':'handler.py:run'}]})
external=R/'external-handler.py'
external.write_text("def run(app,args,context): return 'OK'\n")
(module/'handler.py').symlink_to(external)
archive=R/'linked.pyz'
print('export linked',portable.export(app, archive))
external.unlink()
target=Path(portable.import_bundle(archive, R/'copies')['path'])
imported=App(target,target/'.metaform'/'home',binding=False)
registry=Registry(imported)
try: print('offline linked result',registry.load(registry.discover()['linked.run'])(imported,{},None))
except Exception as e: print('offline linked error',type(e).__name__,str(e))
# Make a separate valid bundle to test extraction boundary, solely against a scratch sentinel.
outside=R/'outside.txt'; outside.write_text('UNTOUCHED')
malicious=R/'boundary.pyz'
with zipfile.ZipFile(archive) as src, zipfile.ZipFile(malicious,'w') as dest:
    for item in src.infolist():
        if item.filename != 'modules/project/linked/handler.py': dest.writestr(item,src.read(item))
    link=zipfile.ZipInfo('outputs/escape');link.external_attr=(stat.S_IFLNK|0o777)<<16
    dest.writestr(link,str(outside))
    regular=zipfile.ZipInfo('outputs/escape');regular.external_attr=(stat.S_IFREG|0o644)<<16
    dest.writestr(regular,'OVERWRITTEN')
try: print('boundary import',portable.import_bundle(malicious,R/'boundary-copies'))
except Exception as e: print('boundary error',type(e).__name__,str(e))
print('outside content',outside.read_text())
