> Source provenance: the primary reviewer verified all 185 text files against Git blob hashes at `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Original lane notes below are retained with script links adjusted; use the evidence README for commands from the repository root.

# Runtime and workbench review

Reviewed checkout: `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d` at `<reviewed-source>`.

Reproduce all five findings from that checkout:

```sh
.venv/bin/python runtime_probe.py
```

Captured output: `runtime.log`. Script creates only unique isolated case directories under `/workspace/scratch/888a16105650/review-runtime`, with explicit legacy/JSON homes and `auto_build: false`. It does not modify reviewed source or use a shared service. The parallel case launches an actual Python subprocess as a configured fixture harness. Other cases exercise runtime APIs used by the CLI/MCP/viewer.

## 1. P1 — Parallel child execution bypasses the parent's requested development workfolder

**Location:** `src/metaform/workflow.py:352` (child `self.start` call passes `parent` and `exclusive`, but no working-copy association); consequences in `src/metaform/harness.py:17` and `src/metaform/modules/workflow.py:34`.

**Reproduction:** Import a one-prompt child workflow and a parent with one parallel branch calling it. Start the parent with `workfolder=True`. Drive the child with a fixture harness that writes `target.txt` in its current directory. Complete the parent.

**Observed:** Parent has a managed workfolder, child has no `workfolder` field, and child file tooling resolves to the original project. Actual child subprocess changes the original `target.txt` to `modified by child`. Parent completes with `changes.diff == ''`.

**Expected/source:** Starting development work in a workfolder should preserve source until explicit application, and the final diff should include performed work. `docs/architecture.md` describes retained development copies for review and explicit application; `tests/test_execution.py::test_development_workfolder_diff_applies_to_a_non_git_project` establishes this behavior for sequential execution.

**Impact/recommendation:** Ordinary parallel development can mutate the source immediately and falsely report no changes. Carry a deliberate working-copy context into child runs and harness/tool routing; ensure child ownership/cleanup does not delete the parent's shared folder. If branches require separate copies, their results must be explicitly retained/reconciled rather than falling back to source.

## 2. P1 — Bound workflow commands can read and answer sibling assignments

**Location:** `src/metaform/modules/workflow.py:56` and `src/metaform/modules/workflow.py:64`; related continuation behavior at `src/metaform/continuation.py:104`.

**Reproduction:** Start two two-step runs, A and B. Bind an App to A's exact run/request/nonce as `begin` does. Through `Registry(bound).call`, request `workflow.next` with B's run ID, then `workflow.answer` with B's run/request IDs. Separately, answer A's initial assignment and call `continuation.current` on its old binding, or `begin` with the old nonce.

**Observed:** A-bound calls return `FIRST B` and successfully answer B, advancing it to step `two`. The old A binding and nonce return `SECOND A`. The binding's request ID is ignored.

**Expected/source:** `docs/workflows.md` explicitly says caller-supplied IDs cannot select a sibling context and `continuation.current` retains the exact issued assignment. Intake's `run_id`/`request_id` helpers already prioritize the binding. Actor-gateway and sampled-tool paths override IDs, but direct bound CLI/MCP routing reaches these unguarded workflow helpers.

**Impact/recommendation:** A worker bound to one assignment can inspect or submit another run, and a stale handoff silently migrates to later work. Enforce bound run/request selection in workflow routing and continuation lookup. A completed handoff should return its own durable result or reject further pending-work access, never silently return the next assignment. Preserve intentional parent-run orchestration separately.

## 3. P2 — Branching back to a foreach step skips the repeated work

**Location:** `src/metaform/workflow.py:370` (retained iteration state), with completion at `src/metaform/workflow.py:375` and no reset in `finish_step` (`:281`).

**Reproduction:** Workflow: `each` loops over input `['A']`, then `decide` asks whether to repeat and transitions back to `each` when answered true. Answer the first `each` job, finish the iteration, answer `decide` true, and request the next assignment twice.

**Observed:** Re-entering `each` emits only a structural `running` result; the following assignment is `decide` again. No new item assignment is issued because `iteration.index` is still at the end of the old item snapshot.

**Expected/source:** `docs/workflows.md` permits authored back transitions, loops, and unbounded authored control flow. An item list is snapshotted for one foreach execution; revisiting the step must execute a new iteration while repeated `next` calls during that execution stay idempotent.

**Impact/recommendation:** Review/revise workflows silently skip subsequent passes and reuse prior answers. Clear completed iteration state when leaving the step, or key it by execution occurrence rather than only the step ID. The adjacent parallel implementation shares a similar state shape, but parallel re-entry was not experimentally tested in this lane.

## 4. P2 — In-flight MCP answers are rejected after a module takeover

**Location:** `src/metaform/mcp_server.py:247`.

**Reproduction:** Start a nonexclusive prompt workflow. Before accepting its sampled response, start intake in the same project. Invoke the actual `accept_sample` helper with the workflow's saved run/request IDs and an MCP `CreateMessageResult`.

**Observed:** `ValueError: Unknown command: workflow.answer`; the original workflow remains pending. `accept_sample` routes its captured answer through an unbound Registry, whose visibility now follows intake's current mode.

**Expected/source:** Issued assignments and in-flight requests retain their captured context (`docs/workflows.md`, project-selection/execution discussion). The sampling tool-call path creates an assignment-bound App, but final sampled answer routing does not.

**Impact/recommendation:** Valid model responses can be lost to unrelated activity in another client/tab using the same project. Dispatch the answer against the original assignment's module/run/request binding, honoring its status and receipt checks without relying on the current project router mode. This experiment exercises the helper directly; no live provider or concurrent network timing was required.

## 5. P2 — Portable workfolder application fails for a directory-to-file replacement

**Location:** `src/metaform/workfolders.py:271` (especially `target.unlink()` at `:274`).

**Reproduction:** With JSON/file-backed workfolders, create `entry/nested`, copy into a workfolder, replace directory `entry` with a regular file there, then call `workfolders.apply`.

**Observed:** `IsADirectoryError` on the unchanged source's `entry` directory. `report['changes']` visits `entry` before `entry/nested`; apply attempts to unlink the directory as a file. The reciprocal file-to-directory case passes and is included as a control.

**Expected/source:** Portable projects are executable and extensible (`SPEC CAP-14`); working-copy apply is intended to apply reviewed changes with conflict checks. Directory/file reshaping is an ordinary refactoring operation.

**Impact/recommendation:** A supported change cannot be applied in the service-free JSON runtime. Apply deletions before additions and remove directories only after validating their entire affected contents. Preserve the preflight conflict checks; avoid a fix that recursively deletes unexamined source additions. Earlier unrelated changes could already be applied before this error, although that partial-write variant was not separately reproduced.

## Coverage and limits

Read `AGENTS.md`, canonical `docs/SPEC.md`, architecture, workflows, workbench cleanup, and current-work status; inspected runtime and relevant tests across CLI/registry, actor gateway, harness, continuation, workflow engine/specialization, project context, portable MCP, viewer routes, and workbench JS. Traced prompt frame snapshots, stored transitions, nested calls/parallel jobs, answers/receipts, tool dispatch, workfolder routing/application, source/perspective inspection and project-prefixed viewer routing.

No source edits. No full-suite/build claims from this lane; parent runs those. No live model/provider calls or browser visual QA. UI named-workflow presentation, MCP breadth, and shared-server design remain design questions in workbench-cleanup; this report does not classify those undecided choices as defects. The experiments establish runtime mechanics, not semantic quality or A-5 through A-8 model outcomes.
