"""Review-only probe: live HTTP views and restart after a viewer crash."""
import asyncio
import json
import subprocess
import tempfile
import urllib.request
from pathlib import Path
from unittest.mock import patch
from metaform.app import App
from metaform.util import write_json
from metaform.modules import viewer

root = Path(tempfile.mkdtemp(prefix="metaform-viewer-review-"))
write_json(root / "home/config.json", {"knowledge_mode": "legacy", "auto_build": False})
app = App(root / "project", root / "home", binding=False)
children = []
real_popen = subprocess.Popen

def capture(*args, **kwargs):
    process = real_popen(*args, **kwargs)
    children.append(process)
    return process

try:
    with patch("subprocess.Popen", capture):
        state = asyncio.run(viewer.serve(app, {"port": 0}, None))
    results = []
    for route in ("", "/api/report", "/api/network", "/api/workflows", "/api/history", "/api/settings", "/api/projects", "/api/dump"):
        with urllib.request.urlopen(state["url"] + route, timeout=5) as response:
            results.append({"route": route or "/", "status": response.status, "bytes": len(response.read())})
    print("LIVE_HTTP", json.dumps(results))
    children[-1].terminate()
    children[-1].wait(timeout=5)
    second = asyncio.run(viewer.serve(app, {"port": 0}, None))
    try:
        urllib.request.urlopen(second["url"], timeout=2)
        reachable = True
    except Exception as exc:
        reachable = False
        failure = str(exc)
    print("VIEWER_RESTART", json.dumps({"same_url": state["url"] == second["url"], "ready_file_remains": Path(state["ready"]).exists(), "reachable": reachable, "error": failure if not reachable else None}))
finally:
    for child in children:
        if child.poll() is None:
            child.terminate()
            child.wait(timeout=5)
