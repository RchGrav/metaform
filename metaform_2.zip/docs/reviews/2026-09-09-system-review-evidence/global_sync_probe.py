import tempfile
from pathlib import Path
import json
from metaform.app import App
from metaform.util import write_json, digest
from metaform.modules import sync
R=Path(tempfile.mkdtemp(prefix='metaform-portable-review-'))
project=R/'sync-project'; write_json(project/'.metaform'/'config.json',{'knowledge_mode':'legacy','graph_backend':'json'})
app=App(project,R/'sync-home',binding=False)
shared={'$id':'custom:shared','type':'string'}
local={'$id':'custom:shared','type':'integer','description':'LOCAL_SCHEMA_SENTINEL'}
private={'$id':'custom:private','type':'object','description':'PRIVATE_ONLY_SENTINEL'}
app.knowledge.call('schema.put',{'owner':'global','schema':shared})
for s in [local,private]:app.knowledge.call('schema.put',{'owner':'project:'+app.project_id,'schema':s})
app.global_graph.put({'elements':{'X':{'entity_desc':'X','entity_schema':'custom:shared','entity_json_obj':{}}}})
result=sync.export(app,{'repository':str(R/'sync-output')},None)
print('sync export',result)
for identifier in ['custom:shared','custom:private']:
    print(identifier,json.loads((Path(result['directory'])/'schemas'/(digest(identifier)+'.json')).read_text()))
print('stored shared schema',app.knowledge.call('schema.get',{'owner':'global','id':'custom:shared'}))
