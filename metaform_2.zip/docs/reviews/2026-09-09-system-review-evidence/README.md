# Review evidence

Baseline: `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. See the [main review](../2026-09-09-end-to-end-system-review.md).

These files preserve observations against the unchanged reviewed source. The probes intentionally expose defects; a successful probe process can mean it reproduced the defect. Read the printed witness and the associated detail report. They are review artifacts, not additions to the product's test suite or behavior.

## Execution

From the repository root, install the locked environment with `uv sync --frozen`. Run a probe using `.venv/bin/python docs/reviews/2026-09-09-system-review-evidence/<filename>`.

| Probe | Findings | Captured output |
| --- | --- | --- |
| [runtime_probe.py](runtime_probe.py) | R01, R06, R13, R14, R17 | [runtime.log](runtime.log) |
| [portable_import_probe.py](portable_import_probe.py) | R02; additional external-link example | [portable-import.log](portable-import.log) |
| [portable_history_probe.py](portable_history_probe.py) | R03, R16 | [portable-history.log](portable-history.log) |
| [global_sync_probe.py](global_sync_probe.py) | R04 | [global-sync.log](global-sync.log) |
| [semantic_probe.py](semantic_probe.py) | R05, R07, R11, R12 | [semantic.log](semantic.log) |
| [service_probe.py](service_probe.py) | R08, R09, R10; small R15 fixture | [service.log](service.log) |
| [imagegen_probe.py](imagegen_probe.py) | R18, R19, R21 | [imagegen.log](imagegen.log) |
| [viewer_probe.py](viewer_probe.py) | Healthy live HTTP routes, R20 | [viewer.log](viewer.log) |

The larger R15 case is optional: `service_probe.py --slow` runs it in a subprocess with a 45-second timeout. The separately captured [similarity-cost.log](similarity-cost.log) is the bounded primary-reviewer repeat: 11 joins per source, 26.74 seconds. The first lane measurement was 30.05 seconds.

Probes use disposable fixture projects and stores. The archive boundary case changes only its own temporary external sentinel. The workflow case edits only its fixture's original project. Global sync writes a local export and performs no push. Image tests inject process/probe results and do not contact a provider. Some temporary fixture directories remain for inspection.

## Verification records

- [pytest.log](pytest.log): all 396 existing tests passed on Python 3.12.14.
- [build.log](build.log): wheel and standalone build completed.
- [distribution.log](distribution.log): fresh installed and offline distribution checks passed.
- [baseline.json](baseline.json): revision, runtime and scope.
- [ci-jobs.json](ci-jobs.json): current-revision Python 3.11/3.13 job/step results observed through GitHub.
- [source-manifest.json](source-manifest.json): Git blob IDs and sizes for the 185 inspected/materialized text files. For each file, verification hashes `blob <byte-count>\\0<file-bytes>` using SHA-1. All matched before and after review.

## Detailed reasoning

The [semantic](semantic-details.md), [runtime](runtime-details.md), [service/storage](service-details.md), [portable/history/sync](portable-details.md), and [image-generation](imagegen-details.md) notes preserve source locations, expectations, causes, reproductions, consequences, and recommended repair directions.

Historical absolute temporary paths in logs identify the original observations. Use the commands above for a fresh run. The primary reviewer repeated the core probes after consolidating the scripts. The source runtime was not patched to make the counterexamples pass.

## Evidence limits

Fixtures establish data, context, execution and retention behavior. This review did not run a live model intake, image generation, or higher-order A-5–A-8 semantic demonstration. The cloud browser rejected local navigation with `ERR_BLOCKED_BY_CLIENT`; live HTTP and existing viewer tests succeeded, but fresh visual/mobile/accessibility checks were not completed. Six historical PNG examples were inventoried without visual re-review. No user runtime database or installed build was supplied.

