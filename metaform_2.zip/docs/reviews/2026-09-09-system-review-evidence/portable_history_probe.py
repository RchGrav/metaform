import tempfile
from pathlib import Path
import shutil, subprocess,zipfile
from metaform.app import App
from metaform.util import write_json
from metaform import portable, history
from metaform.registry import Registry
R=Path(tempfile.mkdtemp(prefix='metaform-portable-review-'))
project=R/'git-project'; project.mkdir()
(project/'private').mkdir(); (project/'private'/'omit.txt').write_text('EXCLUDED_SENTINEL')
(project/'public.txt').write_text('included')
def git(*a): subprocess.run(['git','-C',str(project),*a],check=True,capture_output=True)
git('init');git('add','.');git('-c','user.name=Review','-c','user.email=review@localhost','commit','-m','fixture')
write_json(project/'.metaform'/'config.json',{'knowledge_mode':'legacy','graph_backend':'json','history_exclude':['private/*.txt']})
app=App(project,R/'git-home',binding=False)
print('scan',history.scan(project,history.exclusions(app)))
archive=R/'excluded.pyz';print('export',portable.export(app,archive))
with zipfile.ZipFile(archive) as z:
    print('excluded members', [(n,z.read(n).decode()) for n in z.namelist() if n.endswith('/private/omit.txt')])
# All bytes of this selected module are included; its absolute internal link still points to source.
project=R/'symlink-project'; write_json(project/'.metaform'/'config.json',{'knowledge_mode':'legacy','graph_backend':'json'})
app=App(project,R/'symlink-home',binding=False)
module=app.root/'modules'/'linked'
write_json(module/'module.json', {'id':'linked','commands':[{'name':'run','handler':'handler.py:run'}]})
(module/'implementation.py').write_text("def run(app,args,context): return 'OK'\n")
(module/'handler.py').symlink_to(module/'implementation.py')
archive=R/'internal-symlink.pyz';print('internal link export',portable.export(app,archive))
project.rename(R/'symlink-project-unavailable')
target=Path(portable.import_bundle(archive,R/'internal-link-copies')['path'])
print('bundled target exists',(target/'.metaform/modules/linked/implementation.py').is_file())
imported=App(target,target/'.metaform/home',binding=False); registry=Registry(imported)
try: print('offline internal link result',registry.load(registry.discover()['linked.run'])(imported,{},None))
except Exception as e: print('offline internal link error',type(e).__name__,str(e))
