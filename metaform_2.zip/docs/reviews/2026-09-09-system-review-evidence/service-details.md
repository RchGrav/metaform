> Source provenance: the primary reviewer verified all 185 text files against Git blob hashes at `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Original lane notes below are retained with script links adjusted; use the evidence README for commands from the repository root.

# Service/storage review evidence

Reviewed checkout: `<reviewed-source>`, requested baseline `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Review only; no checkout source changes. Experiments used disposable stores beneath this directory.

## Confirmed findings

### P2 — Connecting another project silently reverts shared schema edits

Location: `src/metaform/knowledge.py:533-534` (related import digest at 512-514).

Reproduction: legacy home `schemas.json` contains `example` with `type:string`; adopt A; service `schema.put` changes it to `type:number`; adopt B from the same unchanged home. A's next `schema.get` returns `type:string`. No migration conflict is raised. The home schema import runs on every adoption, outside the graph import's digest skip and content-conflict handling.

Contract: accepted design section 10 says global imports are tracked by source home and digest so subsequent registrations do not repeatedly overwrite the imported corpus, and competing source/current contents are returned for a migration choice. Section 6 treats schemas as owner-bound registered knowledge, preserving existing home registration as global. This changes shared validation/prompt schema behavior for already-connected projects merely by connecting a second project.

Recommendation: include schema contents in migration import identity and apply the same conflict/verification policy before publishing the marker; do not unconditionally replay old home schemas.

### P2 — Adoption drops explicit project schema registrations

Location: `src/metaform/knowledge.py:533-535`; project schema storage is established at 230-235.

Reproduction: legacy JSON `LocalKnowledge` registers `{owner:project:old,schema:{$id:local:schema,type:string}}`, retained at `.metaform/schemas.json`; adoption succeeds and publishes service mode; `schema.get` for the new project owner returns null. The original file remains, but is no longer used by the service-backed project.

Contract: section 6 says explicit project schema registration is local; section 10 requires preservation across successful adoption. The service migration copies local graph data and home schemas, but never the local schema registry. Existing project records and response schemas can become unresolved after a successful connect.

Recommendation: import the project-local registry under the newly registered project owner, with source verification/conflict handling before publishing service mode.

### P2 — Similarity loses qualified join identity and reports false agreement

Location: `src/metaform/similarity.py:9,17-18`; compare node collection at 152-160.

Reproduction through real KnowledgeStore calls: global authored join `j` has type `global-relation`; selected-project authored join `j` has type `local-relation`. Native evidence points to `{ref:j,owner:global,kind:join}`; archaeology evidence points to `{ref:j,owner:project:<uuid>,kind:join}`. Source records preserve both references. Snapshot resolution produces different owner-qualified join keys. `graph.similarity` emits one evidence join with `membership:11`, removes owner/kind, and emits a fabricated Element `j` with membership 11. The authored joins use their ordinary `authored` source, so the native/archaeology comparison treats those references as external.

Contract: P6 says explicit owners are precise references and equal join strings from different owners must not become one relationship accidentally. CAP-4/P6 define similarity as structural agreement, with source references retained. This example concerns distinct join identities, not the intentional cross-owner semantic Element-address shortcut.

Recommendation: carry resolved owner/kind identity into structural matching and rendering; distinguish external join references from Elements, and preserve qualifications when they identify different structural targets.

### P2 — Similarity explores factorial duplicate mappings on a small divergent graph

Location: `src/metaform/similarity.py:112-140`.

Fixture: each source has N identical OP joins from X to Y plus two evidence joins. Both native evidence joins target the same native OP; latent evidence joins target two distinct latent OPs. A full correspondence is impossible, but matching repeatedly permutes equivalent OP leaves before establishing that fact.

Measured direct `compare` times with ordinary string IDs (repro script): N=4 .002 seconds; N=5 .009; N=6 .061; N=7 .430; N=9 30.046 seconds (only 11 joins per source). No larger case was run. Through `KnowledgeStore.graph.put` with source-normalized join IDs, `graph.similarity` measured N=7 .182 seconds and N=8 1.380 seconds. Ordering changes cost, but not the combinatorial search. The 1100-record existing scale test uses fully matching uniquely distinguished structures and does not exercise this case.

This computation is invoked by graph similarity, merge/clean, runtime assembly and selected snapshot export. `graph.merge_perspectives` executes inside the central write transaction, so expensive comparison can also delay other project writes. Remote operations use a 30-second response timeout; the direct eleven-join fixture already reaches that duration. This is a measured operational performance defect, not a claim that every 11-join graph is slow.

Recommendation: prune equivalent mappings and use incoming/reified structural constraints to prioritize restrictive matches; retain exact structural semantics while avoiding permutations of indistinguishable leaves. Include a small divergent-duplicate regression with bounded execution.

## Coverage and limitations

Read AGENTS.md, canonical SPEC, architecture, accepted feature design, and all assigned source files: service.py, knowledge.py, graph.py, backends.py, similarity.py, locking.py. Inspected corresponding source/owner, receipt, lifecycle, migration, assembly and analytical-copy tests. Also read the snapshot adapters and schema registration integration needed to check findings.

Executed: `.venv/bin/python -m pytest tests/test_service_lifecycle.py tests/test_service_analysis.py tests/test_service_intake.py tests/test_knowledge_store.py tests/test_graph_similarity.py tests/test_graph_perspectives.py tests/test_knowledge_contract.py -q` — **116 passed in 21.59s**. These exercise real detached starts/stops, eight competing starters, stale endpoints and invalid credentials/challenges, accepted-operation drain, response-loss receipt recovery, atomic inference competition, three-backend source preservation, analytical copy refresh/isolation, and missing native-engine operation.

No confirmed lifecycle, receipt isolation, or inference transaction defect found in this bounded review. Core service transaction and source preservation cases have substantial existing coverage. Reviewed but did not independently fault-inject every crash boundary or test multiple OS platforms. No live model semantic evaluation, high-volume production benchmark, or source fixes were performed. Parent is running broader system/build coverage. The whole-owner reconstruction in KnowledgeStore graph operations is an existing documented scale limitation, not elevated here without a separate concrete workload result.

Rerun: `.venv/bin/python service_probe.py`. Captured default output: `repro-output.txt`. Optional `--slow` runs the eleven-join comparison in a child with a 45-second process timeout; default is quick. The earlier timing measurements above were captured in the review tool transcript; the saved script intentionally does not rerun the slow measurement by default.
