import json, tempfile
from pathlib import Path
from metaform.app import App
from metaform.intake import Intake
from metaform import schemas
from metaform.util import write_json

def app_for(label):
    root = Path(tempfile.mkdtemp(prefix=label+'-', dir=None))
    write_json(root/'home'/'config.json', {'knowledge_mode':'legacy'})
    return App(root/'project', root/'home')

def record(name, schema='metaform:element', notes=None):
    fields = {'en':name,'ef':'provides '+name}
    if notes: fields['notes']=notes
    return {'entity_desc':name,'entity_schema':schema,'entity_json_obj':fields}

def begin(app, objects):
    engine=Intake(app)
    native=engine.start()
    engine.submit(native['run_id'],native['request_id'],{'elements':objects,'joins':[]})
    proof=engine.next(native['run_id'])
    engine.submit(native['run_id'],proof['request_id'],{'elements':{},'archaeology_objects':objects})
    latent=engine.next(native['run_id'])
    return engine,native,proof,latent

app=app_for('seed')
a=record('A')
engine,native,proof,latent=begin(app,{'code.a':a})
print('STALE_PROMPT', json.dumps({j['role']:{'obsolete_merge':'When complete the two graphs are merged' in j['prompt'], 'independent_graphs':'complete, independent graphs' in j['prompt'], 'shape_similarity':'shape-similarity' in j['prompt'], 'revision':j['prompt_revision']} for j in [native,proof,latent]}))

app=app_for('join-dependency')
a,b=record('A'),record('B')
app.global_graph.put({'elements':{'code.b':b}},'promoted')
engine,native,proof,latent=begin(app,{'code.a':a})
engine.submit(native['run_id'],latent['request_id'],{'elements':{'code.a':a},'joins':[{'id':'requires-b','object_id':'code.a','element_id':'code.b','type':'receiving_entity','purpose':'A needs B capability'}]})
final=engine.next(native['run_id'])
print('JOIN_DEPENDENCY',json.dumps({'run_status':final['status'],'a_complete':engine.inference_complete('code.a'),'b_complete':engine.inference_complete('code.b'),'queue':app.load_run(native['run_id'])['queue'],'a_inference':engine.inference('code.a')}))

app=app_for('schema-context')
secret='PROJECT OP: project.checkout receives code.validator to reject orders over its merchant-specific purchase limit.'
schemas.register(app,{'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'custom:validator','description':secret,'type':'object','properties':{'en':{'type':'string'}}},owner='project:'+app.project_id)
a=record('Validator',schema='custom:validator')
engine,native,proof,latent=begin(app,{'code.validator':a})
print('SCHEMA_CONTEXT',json.dumps({'record_contains_op':secret in json.dumps(latent['inputs']['object']),'latent_context':latent['context'],'latent_schema_contains_op':secret in json.dumps(latent['inputs']['schema']),'schema':latent['inputs']['schema']}))

app=app_for('reuse-join-ids')
engine=Intake(app)
objects={x:record(x) for x in ['code.a','code.b','code.c','code.d','code.e']}
native=engine.start()
engine.submit(native['run_id'],native['request_id'],{'elements':objects,'joins':[]})
proof=engine.next(native['run_id'])
engine.submit(native['run_id'],proof['request_id'],{'elements':{},'archaeology_objects':objects})
jobs={j['inputs']['id']:j for j in engine.batch(native['run_id'])}
for x,dependency in [('code.d',None),('code.e',None),('code.b','code.d'),('code.c','code.e')]:
    joins=[] if dependency is None else [{'id':'dependency','object_id':x,'element_id':dependency,'type':'receiving_entity','purpose':x+' requires '+dependency}]
    engine.submit(native['run_id'],jobs[x]['request_id'],{'elements':{x:objects[x]},'joins':joins})
reused_joins=engine.inference('code.b')['graph']['joins']+engine.inference('code.c')['graph']['joins']
engine.submit(native['run_id'],jobs['code.a']['request_id'],{'elements':objects,'joins':reused_joins})
retained=engine.inference('code.a')['graph']['joins']
print('REUSE_JOIN_IDS',json.dumps({'submitted_ids':[j['id'] for j in reused_joins],'submitted_authored_ids':[j['authored_id'] for j in reused_joins],'submitted_purposes':[j['purpose'] for j in reused_joins],'retained_ids':[j['id'] for j in retained],'retained_purposes':[j['purpose'] for j in retained]}))
