> Source provenance: the primary reviewer verified all 185 text files against Git blob hashes at `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Original lane notes below are retained with script links adjusted; use the evidence README for commands from the repository root.

# Portable / history / distribution review

Reviewed source snapshot `<reviewed-source>`, identified by parent as remote baseline `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. This extracted checkout has no `.git`, so commit identity was not independently verified here. No repository source changes or external pushes were made.

## Confirmed findings

### P1 — Archive import follows an existing final-component symlink outside staging

- Location: `src/metaform/portable.py:447–453`; supporting guard `src/metaform/history.py:29–38`.
- `safe_path` verifies only the resolved parent. The extraction loop first creates symlinks and subsequently calls `output.write_bytes` for regular members without rejecting a symlink already at that output. Duplicate members are accepted.
- Reproduction: `portable_import_probe.py`. Started with a valid locally produced bundle. Added a symlink ZIP member `outputs/escape` pointing to the scratch-only `outside.txt` sentinel, followed by a regular member `outputs/escape` containing `OVERWRITTEN`. Called `portable.import_bundle` directly, without executing ZIP `__main__.py`.
- Actual: import returned successfully and outside sentinel changed from `UNTOUCHED` to `OVERWRITTEN`.
- Contract: `docs/next-version.md`, Versions and exports: path checks protect extraction boundaries; import stages replacement before modifying the target.
- Impact: importing an untrusted project archive can overwrite arbitrary writable files outside the selected destination. This does not depend on executing the bundled runtime or custom handlers.
- Proposed action: reject colliding materialized destinations (including different archive prefixes mapping to the same output) and ensure regular-file writes never follow a final-component symlink. Validate link handling for extraction and subsequent reconstruction, preserving legitimate project symlinks as metadata where possible. Add a harmless external-sentinel regression test.

### P1 — Git-origin capture ignores nested history exclusion patterns

- Location: `src/metaform/history.py:115–120`, especially `entry.name.split("/")[0]` on line 117.
- The working-directory scanner applies patterns to complete relative paths. Git baseline initialization applies them only to the first component. Consequently configured nested patterns have different meanings across the two baseline forms.
- Reproduction: `portable_history_probe.py`. A local Git repository has committed `private/omit.txt` containing `EXCLUDED_SENTINEL`, plus `public.txt`; project config sets `history_exclude: ["private/*.txt"]`. Exported through the ordinary portable API.
- Actual: `history.scan(project, history.exclusions(app))` returns only `public.txt`, but exported ZIP contains `origin/private/omit.txt` with the complete sentinel bytes. Export reports no unresolved items.
- Contract: `docs/next-version.md:224`, `history_exclude` accepts additional path patterns; baseline and checkpoint history are the project-file history.
- Impact: deliberately excluded files can still be distributed in the permanent origin even though the reconstructed current project excludes them. This may disclose private files and undermines the user's exclusion setting.
- Proposed action: share a single relative-path exclusion implementation between Git archive capture and working-tree scanning, including excluded ancestor directories. Test nested patterns against both baseline types and inspect ZIP origin bytes, not only the final reconstructed tree.

### P1 — Global sync exports project-private schemas and overwrites same-ID global schema definitions

- Location: `src/metaform/modules/sync.py:20–25`; supporting effective registry union in `src/metaform/schemas.py:26–28`.
- Sync exports the global graph, but iterates the effective schema registry, which overlays project-owned schemas on global schemas.
- Reproduction: `global_sync_probe.py`. Stored global `custom:shared` with `type: string`; project-owned `custom:shared` with `type: integer` and a local sentinel; and project-only `custom:private`. Called only `sync.export` into a separate scratch output directory. No push performed.
- Actual: exported global schema for `custom:shared` is the local integer definition, even while `schema.get(owner=global)` remains the string definition. `custom:private` also appears in `src/metaform/data/global/schemas` and the generated index. Export reports two schemas.
- Contract: feature specification owner-qualified schemas must remain independent; `docs/next-version.md:243–244` describes sync export/merge as global inference contribution. Existing sync tests explicitly check that project-native graph content does not travel.
- Impact: `sync merge` would publish project-private schema material and distribute a schema that no longer matches the accompanying global records. The same-ID case silently changes reusable meaning for downstream installations.
- Proposed action: select schemas from the actual global owner/catalog, preserving global definitions; do not use the effective project-overlaid registry for global publication. Add private-only and same-ID owner collision tests alongside existing global sync tests.

### P2 — Selected directory modules retain absolute symlinks into their unavailable source copy

- Location: `src/metaform/portable.py:95–97` (symlink bytes captured unchanged), through `_capture_modules` tree capture and `import_bundle` line 451.
- Reproduction: second fixture in `portable_history_probe.py`. A selected project module has `handler.py` as an absolute symlink to `implementation.py` in the same module directory. Manifest command points to `handler.py:run`. Both paths belong to the selected module. Export, rename the original source project to make its old path unavailable, import into a different directory, and invoke through `Registry.load`.
- Actual: export returns `unresolved: []`; imported `implementation.py` exists, but `handler.py` still points to the original project's absolute path. Registry fails with `ModuleNotFoundError` for the handler module.
- Contract: CAP-14 and feature P7c/P9 require selected module folders/declared handler assets to remain usable from the independent portable copy with original home unavailable, or report known unresolved dependencies. This example has all needed bytes already bundled.
- Impact: a module that works installed fails after a successful export/import despite having no undeclared external dependency. Existing flat symlink-handler tests pass because `captured_file` dereferences the symlink; directory-module capture takes a different path.
- Proposed action: normalize internal executable-asset links to relative bundled targets or materialize their referent bytes in the module asset section. Report truly external unresolved targets. Add absolute internal link fixtures for project and selected shared directory modules, then continue/re-export with source unavailable.

## Coverage and limits

Read canonical `docs/SPEC.md`, `docs/next-version.md`, the shared knowledge feature specification, AGENTS, and selected implementation/test paths. Static review covered `knowledge_export.py`, `portable.py`, `portable_mcp.py`, `history.py`, `packaging.py`, `installation.py`, `modules/sync.py`, `ci.py`, distribution build/check tools, and relevant workflow/module/schema code.

Ran:

```
.venv/bin/python -m pytest -q tests/test_portable_knowledge.py tests/test_knowledge_export.py tests/test_knowledge_dependencies.py tests/test_ci.py
```

Result: **63 passed in 14.74s**. These cover owner-qualified closure, reified/historical evidence, ordinary offline nested continuations/re-export, file prompts, source preservation, selected modules, schema ownership and CI command assembly. The three standalone scratch scripts above independently reproduce the four findings; existing tests do not cover those cases.

Root handles full suite and rebuilt distribution; this lane did not duplicate full suite/build or exercise live GitHub API, remote sync push, model generation, Windows, or additional Python versions. No further confirmed defect emerged from the selected-closure/historical traversal pass. Tests passing are evidence of covered behavior, not proof of full product semantics.
