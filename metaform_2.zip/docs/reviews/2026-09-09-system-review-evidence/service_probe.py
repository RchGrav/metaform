"""Reproduce review findings without touching the checkout or normal homes.

Run with the checkout's venv and PYTHONPATH=.../review-checkout/src.
Default similarity fixture is bounded at eight joins per source. Optional
--slow runs the eleven-join fixture in a child with a 45-second process timeout.
"""
import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from time import perf_counter

from metaform.backends import JSONGraph
from metaform.knowledge import KnowledgeStore, LocalKnowledge
from metaform.similarity import compare
from metaform.util import write_json


def schema_migration(root):
    home = root / "home"
    store = KnowledgeStore(home / "service/knowledge.sqlite3")
    write_json(home / "schemas.json", {"example": {"$id": "example", "type": "string"}})
    a = store.adopt(root / "a", home)["project_id"]
    store.call(a, "schema.put", {"owner": "global", "schema": {"$id": "example", "type": "number"}})
    before = store.call(a, "schema.get", {"owner": "global", "id": "example"})
    store.adopt(root / "b", home)
    after = store.call(a, "schema.get", {"owner": "global", "id": "example"})
    print("SCHEMA_OVERWRITE", json.dumps({"before": before, "after": after}), flush=True)
    assert before["type"] == "number" and after["type"] == "string"

    project = root / "legacy"
    write_json(project / ".metaform/config.json", {"graph_backend": "json", "knowledge_mode": "legacy"})
    local = LocalKnowledge("old", JSONGraph(project / ".metaform/metaform.json"), JSONGraph(home / "inference/metaform.json"))
    schema = {"$id": "local:schema", "type": "string"}
    local.call("schema.put", {"owner": "project:old", "schema": schema})
    identifier = store.adopt(project, home)["project_id"]
    after = store.call(identifier, "schema.get", {"id": "local:schema"})
    print("LOCAL_SCHEMA_LOSS", json.dumps({"before": schema, "after": after}), flush=True)
    assert after is None


def similarity_ownership(root):
    store = KnowledgeStore(root / "knowledge.sqlite3")
    project = store.call(None, "project.register", {"path": str(root / "project")})["project_id"]
    owner = "project:" + project
    for selected, relation in [("global", "global-relation"), (owner, "local-relation")]:
        store.call(project, "graph.put", {"owner": selected, "source": "authored", "graph": {"joins": [{"id": "j", "type": relation}]}})
    for source, target in [("native", "global"), ("archaeology", owner)]:
        store.call(project, "graph.put", {"source": source, "graph": {"joins": [{"id": source + "-higher", "type": "evidence", "participants": [{"role": "relationship", "ref": "j", "owner": target, "kind": "join"}]}]}})
    view = store.call(project, "graph.similarity", {})
    sources = [j for j in store.call(project, "graph.joins", {}) if j.get("participants")]
    print("QUALIFIED_SOURCES", json.dumps(sources), flush=True)
    print("FALSE_SIMILARITY", json.dumps(view), flush=True)
    assert len(view["joins"]) == 1 and view["joins"][0]["membership"] == "11"
    assert "j" in view["elements"]


def similarity_cost(size):
    graphs = []
    for prefix in ["n", "a"]:
        joins = [{"id": f"{prefix}:{i}", "type": "OP", "object_id": "X", "element_id": "Y"} for i in range(size)]
        joins += [{"id": f"{prefix}:z{i}", "type": "evidence", "object_id": f'{prefix}:{0 if prefix == "n" else i}', "element_id": "E"} for i in range(2)]
        graphs.append({"elements": {}, "joins": joins})
    start = perf_counter()
    result = compare(*graphs)
    print("SIMILARITY_COST", json.dumps({"joins_per_source": size + 2, "seconds": perf_counter() - start, "matching": sum(j["membership"] == "11" for j in result["joins"])}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--slow", action="store_true")
    parser.add_argument("--cost-child", type=int)
    args = parser.parse_args()
    if args.cost_child:
        similarity_cost(args.cost_child)
    else:
        with tempfile.TemporaryDirectory(prefix="service-review-", dir=Path(__file__).parent) as temporary:
            root = Path(temporary)
            schema_migration(root / "schemas")
            similarity_ownership(root / "owners")
            similarity_cost(6)
        if args.slow:
            try:
                subprocess.run([sys.executable, __file__, "--cost-child", "9"], check=True, timeout=45)
            except subprocess.TimeoutExpired:
                print("SIMILARITY_COST: 11 joins/source exceeded bounded 45-second timeout", flush=True)
