> Source provenance: the primary reviewer verified all 185 text files against Git blob hashes at `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`. Original lane notes below are retained with script links adjusted; use the evidence README for commands from the repository root.

# Image generation and standalone prompt collection review

Baseline: `55a8bda72f7851eb697a0ce42fda9beb1e2cd06d`, inspected in `review-checkout`.
No source edits and no live model/image provider calls.

## Confirmed findings

1. **P2: False success from stale or unrelated images.** `src/metaform/modules/_imagegen.py:389-402` accepts a recently modified preexisting destination, any existing non-input image path found in subprocess stdout, or the newest image in the shared generated-images directory. None establishes production by this invocation. `src/metaform/modules/imagegen.py:72` reports `generated: true` after this returns. Injected-runner reproductions confirm all three paths: old PNG with mtime 1 copied following text saying generation failed; unchanged recent destination accepted despite no generation; unrelated image from another session accepted. Wrong deliverables can appear successful.

2. **P2: Latent assignment image operations resolve in the project directory.** `src/metaform/modules/imagegen.py:20-25` reads only `run.pending`, ignoring `request_id` and `run.assignments`. Intake stores Latent Expert jobs in `run.assignments` (`src/metaform/intake.py:217-225`); actor forwarding supplies both IDs (`src/metaform/actor.py:71-74`). An actual local intake through native submission, proof submission, and batch produces an imagegen dry-run save instruction naming project/image.png instead of the assigned workfolder. A source.png existing only in that workfolder fails edit validation against project/source.png. This causes failed/wrong relative edits, bypasses intended assignment output retention, and sends concurrent default outputs to the same project file. No claim of live-model contamination is made.

3. **P2: Failed provider readiness remains cached after remediation.** `_imagegen.py:197-203` caches failed status. The integrated handler always uses `require_codex(False)` (`imagegen.py:47`) without exposing refresh. Standalone MCP image_status probes anew but does not update the cache (`_imagegen.py:714-716`). Injecting an initial failed probe and later healthy probe reproduces status returning ready=true while subsequent generation readiness still raises the original failure. Persistent MCP processes require restart; independent CLI invocations avoid this cache persistence.

## Evidence

Run from `review-checkout`:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src .venv/bin/python ../review-imagegen/reproduce.py
```

`reproduce.py` creates and cleans a fresh temporary directory beside itself. Subprocess runners and readiness probes are injected, so it cannot invoke a paid provider. `reproduction-output.txt` contains captured successful reproduction output.

Existing targeted checks executed:

```sh
.venv/bin/python -m pytest -q tests/test_core.py::test_imagegen_lazy_dry_run tests/test_module_scope.py tests/test_mcp.py
```

Result: **8 passed in 8.01s**. Existing tests therefore do not detect these reproduced defects.

Additional local injected-runner checks produced expected errors for missing output, nonzero exit, timeout, and missing executable. Direct dry-run validation rejected empty prompts, edits without a target, and input/output path collisions. These supplementary checks were executed but are not duplicated in reproduce.py.

## Coverage and limits

Inspected provider probes, fixed Codex invocation, module wrapper/manifest, standalone CLI/MCP helpers, preset/guide assembly, relevant workfolder retention, examples, and standalone prompt collection purpose. No live authentication/provider compatibility or image-quality tests. README explicitly says provider testing remains outstanding. The integrated manifest exposes prompt/output/image/dry_run; the standalone module's richer presets/reference roles are not exposed through it. This alone is not a defect against the stated Codex integration intent.

`prompts/README.md` describes maintenance/enhancement prompts and future candidates for bundled workflows. Packaging includes src/metaform; no runtime loader for the standalone Markdown collection was found. `examples/workflows/` contains explicitly imported examples. Their varied orchestration, approval, and evaluation instructions are not current runtime restrictions or intake defects. The collection was inventoried and representative/general and Metaform maintenance prompts inspected; no claim of exhaustive model-quality testing for each draft.

No concrete blacklist/whitelist defect was established in this lane. Image idea/preset descriptions expressly allow requests beyond their example vocabulary. Runtime Metaform semantic prompts belong to another review lane.
