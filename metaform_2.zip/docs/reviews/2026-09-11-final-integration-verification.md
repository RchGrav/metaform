# Final source integration verification

This report records independent checks of the repair worktree at `/home/rich/metaform/.worktrees/release-quality`. Source execution and delivered-artifact execution are separate evidence. The source environment uses Python 3.13.5, MCP 2.1.1, and AnyIO 4.15.1; the exact interpreter and package origin are retained in `2026-09-11-final-source-environment.json`.

## Final frozen-tree result

The final full Python suite passed **884 tests in 294.86 seconds**. All four browser suites also passed, including actual authored deadline expiration followed by the exact stored failure cause displayed in Activity and retirement of its pending handoff. The failure screenshot was independently viewed and is retained as `2026-09-11-frozen-failed-phase-activity.png`.

The source/data/build snapshot covered **163 files with zero differences before and after both runs**. `git diff --check` passed. Retained evidence:

- `2026-09-11-frozen-source-tests.log`
- `2026-09-11-frozen-browser-tests.log`
- `2026-09-11-frozen-source-start.json`
- `2026-09-11-frozen-source-end.json`
- `2026-09-11-frozen-source-delta.json` (empty)

Browser artifacts are `/tmp/metaform-test_structure_browser-xMD6FR`, `/tmp/metaform-semantic-browser-vg47Ro`, `/tmp/metaform-test_cytoscape_svg_browser-uOnk4H`, and `/tmp/metaform-text-visibility-xkdFPw`.

Visual review identified a remaining central instruction promoting the optional Sync module. Its removal occurred after these processes exited and their identical hashes were recorded. The final snapshot, `2026-09-11-final-ui-source-end.json`, still covers 163 files; `2026-09-11-final-ui-source-delta.json` records exactly three later changes: `src/metaform/viewer.py`, `src/metaform/static/workbench.js`, and `src/metaform/templates/index.html`. They remove the central contribution text and unused community command recommendations. Author, repository, and module locations remain available.

Independent verification against all final deletions passed **35 viewer/reference tests in 13.83 seconds** (`2026-09-11-final-ui-tests.log`). The runtime reviewer also exercised a real browser with Sync absent: its module reference reports unavailable, the Activity page contains no contribution instruction or page errors, and the settings/community responses preserve their useful remaining fields. That evidence is retained in `2026-09-11-sync-absent-viewer.json` and `2026-09-11-sync-absent-activity.png`. The root reviewer ran the declared JavaScript model/renderer suite after this deletion: **22 passed**, retained in `2026-09-11-final-javascript-tests.log`. `git diff --check` passed after the final deletion.

The full Python/browser result predates these three small deletions; the focused final checks cover their changed surfaces. Final rebuilt-artifact checks remain separate evidence.

## Earlier browser integration

The complete configured sequence exited successfully:

```sh
PYTHONPATH=$PWD/src PYTHON=/home/rich/metaform/.venv/bin/python npm run test:browser
```

All four suites passed: structure/navigation, Foundation/semantic reads and continuation, authored SVG, and text visibility. The semantic suite includes answering the first assignment in a two-step workflow, reloading while continuation is required, advancing, answering the second assignment, and observing the pending panel disappear only at terminal completion.

The retained log is `2026-09-11-final-browser-tests.log`. Browser artifacts and screenshots from this run are in:

- `/tmp/metaform-test_structure_browser-MrbXZT`
- `/tmp/metaform-semantic-browser-jL0sEZ`
- `/tmp/metaform-test_cytoscape_svg_browser-25olpC`
- `/tmp/metaform-text-visibility-qE9Xiv`

These checks exercise the source server and actual browser. They do not establish model inference quality, all browser/platform combinations, or behavior of a subsequently built wheel.

## Earlier Python integration

The full suite ran with the worktree import path explicitly selected:

```sh
PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest -q
```

The process exited with **823 passes and four failures in 260.60 seconds**. The failures were the JSON and SQLite variants of two lifecycle cases: restoring directory entries from an older Git baseline, and retiring dispatch files while retaining exact request artifacts. Their implementation changed after this run imported the relevant modules; fresh verification of the updated implementation is required.

The complete output is retained in `2026-09-11-final-source-tests.log`. Source SHA-256 values captured before and after execution are in `2026-09-11-final-source-start.json` and `2026-09-11-final-source-end.json`. `2026-09-11-final-source-delta.json` records 13 changed files, including lifecycle, semantic context, MCP interrupt, archive/chassis, and workflow library changes. This run therefore does not establish a passing final source tree.

Fresh independent verification of `tests/test_release_lifecycle.py`, `tests/test_execution.py`, and `tests/test_model_transformations.py` passed **69 tests in 21.89 seconds**, including all four failing cases and the historical workfolder test in its combined execution context. The retained output is `2026-09-11-final-lifecycle-tests.log`.

Later live-data review reproduced excessive full-report polling in the viewer. After the narrow pending-status endpoint replaced that polling path, the complete four-suite browser sequence was rerun and exited successfully. Its log is `2026-09-11-final-browser-recheck.log`; evidence directories are `/tmp/metaform-test_structure_browser-nrxOFF`, `/tmp/metaform-semantic-browser-5kBuzA`, `/tmp/metaform-test_cytoscape_svg_browser-HQvxhz`, and `/tmp/metaform-text-visibility-BDdeh7`.

Live browser review then exposed `graph.neighbors` being unavailable during an active workflow. An independent public-endpoint regression reproduced HTTP 400; declaring `graph.neighbors` and `graph.traverse` as always-available reads repaired it. The regression also verifies OP join results, absence of an automatic build during navigation, and continued restriction of bound workers to their declared tools. `tests/test_active_semantic_navigation.py` passed after the metadata correction and is included in the final frozen full-suite result above.

## Later integration findings

The next full run retained in `2026-09-11-final-source-recheck.log` ended with **839 passes and five failures in 257.74 seconds**. Four cases compared launcher strings against fabricated empty executables; their obsolete assumption was replaced by actual subprocess handoff checks. The fifth case exposed `always_available` bypassing explicit command disabling. Registry now distinguishes availability across ambient modes from explicit disabling, and both public and internal dispatch preserve the latter.

Further adversarial checks reproduced malformed custom manifests preventing all help, missing scope/bounds in service settings help, and a repeated advertised `begin` being misparsed in an actor environment. Malformed modules are now isolated as a whole with file/field diagnostics while valid modules remain usable; the ten malformed cases cover four reference surfaces plus a valid operation and verify unchanged files during reference. The independent reference audit exercised 52 routes. Actor replay executes the exact command in a real gateway with source-path environment removed; a sibling nonce fails without changing either assignment or the local marker.

The failed-run integration check first returned `needs_project_input` for an explicitly selected failed run. Guidance now returns the exact recorded failure result and no next action. The engine remains responsible for clearing the failed tree's ambient mode.

After these corrections, **64 CLI, onboarding, module integration, and execution checks passed in 26.94 seconds** (`2026-09-11-final-cli-bootstrap-tests.log`). The actor replay plus execution slice separately passed **21 tests in 8.96 seconds** (`2026-09-11-actor-begin-tests.log`). The later frozen full-suite result above includes the final authored execution-policy and conversion changes.

## Independent evidence audit

The test-purpose audit was checked against the concrete test and runtime changes. It correctly distinguishes subprocess fixture transport from real inference, metadata/reference checks from delivered entry points, and substantive storage/transport parameterizations from duplicated implementation assertions. It does not claim that a large passing count proves semantic quality. The current release disposition remains in the per-item evidence ledger and `../release-quality-status.md`.
