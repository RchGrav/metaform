# Review of the two repair backlogs — 2026-09-11

Both reviews found real gaps. They also mix different code snapshots, stale documentation, verification tasks, and proposed behavior changes. The repair lists should be reconciled before implementation; their individual proposed remedies are not all established requirements.

This review covers [Metaform Repair List](../metaform-repair-list.md), [Repair specification](../repair-spec.md), and the latter's [merged inventory](2026-09-10-onboarding-review/merged-issues.md). `Rnn` refers to the first list; letters such as `F1` refer to the merged inventory; “Decide” numbers refer to the repair specification. All 28 Decide items are addressed below. This is a review, not implementation of the backlogs or a new audit of all 759 raw observations.

The governing sources are Rich's current instructions and MetaformFoundation, [SPEC](../SPEC.md), and the prior conversation supplied during this review. That conversation explicitly establishes self-contained startup, module-owned command reference and settings defaults, concise concierge orientation, runtime-provided instructions, bundled procedures, and chassis self-understanding. These are accepted requirements, not preferences to ask Rich to approve again. Code and tests establish implementation behavior; they do not supersede semantic intent.

## The three snapshots must be distinguished

HEAD is `d264f512ceba89cf3a5152f66cdc60c0e1a06ba4`, the repair list's pinned revision. The working tree contains substantial uncommitted repairs. The existing distribution still contains older source.

| Observation | Current working tree | Existing distribution |
| --- | --- | --- |
| Module descriptions | 26 of 26 | 1 of 26 |
| Concierge skill | Short core plus generated module catalog/guidance | Earlier static content |
| Worker launcher | Derived from running entry point | Earlier fixed invocation |
| MCP interrupt handling | New outer interrupt catch, but portable reader still hangs with stdin open | Older handler; hang also reproduced |

Both `dist/metaform` and `dist/metaform_chassis-0.2.0-py3-none-any.whl` have SHA-256 `24973b0df6614e498feca39f294f71f5b46164f9371a9cb0bb3a383665196ff2`. Archive inspection confirms their `cli.py`, `continuation.py`, and `onboarding.py` differ from current source. Neither archive includes `dual_agent.md` from the requested corpus.

Consequently, some older observations remain accurate for the shipped artifact even where source has improved. “Fixed in this tree” and “delivered” need separate status. Existing uncommitted work and original review documents were preserved.

## Confirmed defects to prioritize

1. **MCP interruption is not fixed on the portable path (R41).** Both current source forced through portable MCP and the actual executable successfully initialized, then remained alive three seconds after one SIGINT while stdin remained open. Closing stdin allowed source to exit 130; the distribution instead emitted a KeyboardInterrupt traceback. The blocking reader remains at [portable_mcp.py:184](../../src/metaform/portable_mcp.py#L184). The catch at [cli.py:97](../../src/metaform/cli.py#L97) is outside `asyncio.run`, after executor shutdown. The claimed regression test calls `communicate()` after SIGINT at [test_mcp.py:220](../../tests/test_mcp.py#L220), closing stdin and masking this condition. Reopen the “repaired” claim. This was Python 3.13.5; Rich's exact Python 3.10 environment was not reproduced.

2. **Configuration leaks between scopes and stays stale in memory (R11–R12).** [system.configure](../../src/metaform/modules/system.py#L24) writes the merged effective configuration to the home file and does not update the active App. [App configuration loading](../../src/metaform/app.py#L61) includes project overrides and runtime-derived values. Updating home settings can therefore change another project's defaults. Persist the selected scope's own settings and make the reported/effective result coherent.

3. **Assignment identity can contaminate a development patch (R31–R32, R38; C4/H3).** Ancestor marker discovery in [continuation.py:39](../../src/metaform/continuation.py#L39), incomplete terminal cleanup in [workflow.py:585](../../src/metaform/workflow.py#L585), and Git diff/application in [workfolders.py:109](../../src/metaform/workfolders.py#L109) still support the reported chain: retained marker → diff → source project → stale binding. Retire ambient markers and active dispatch lookups while preserving historical request identity and replay receipts. An old worker must not silently become bound to the next assignment.

4. **Help/install initialize the invocation directory (R04; A2).** [cli.py:72](../../src/metaform/cli.py#L72) opens App before normal help and install argument parsing. App can create state, start service access, and register that directory. Reference inspection and installer argument handling should not accidentally select `dist` or the home directory as the artifact.

5. **Discovery and continuation remain inconsistent (R15; C1–C3, B6, I1).** The module catalog is dynamic, but [guide_state](../../src/metaform/onboarding.py#L105) still chooses literal intake/enumerator/layer actions without checking availability. Raw CLI handlers can return the pending assignment for help, typos, or unsupported structured forms. Removing Best Practices can leave onboarding with no next action. Exclusive layer runs hide reads the workbench needs. These are concrete failures in the agreed self-guiding experience.

6. **Workfolder capture and tracking disagree with whole-folder behavior (R36–R39).** [workfolders.py:24](../../src/metaform/workfolders.py#L24) couples tracking backend to JSON knowledge. Git source capture uses `--exclude-standard`; baseline and diff also honor copied ignore rules. The stated requirement is working-artifact coverage across snapshot, diff, and apply. Preserve the distinction between user artifacts and runtime bookkeeping, and between empty analysis folders and development copies.

7. **Intake completion and generated-knowledge dependencies need repair (D1, F8).** [intake.submit](../../src/metaform/intake.py#L359) records completion of the answering stage but publication occurs later in [_finish](../../src/metaform/intake.py#L389). The public continuation must reliably carry that through. Separately, design reads enter recipe dependencies at [layers.py:330](../../src/metaform/layers.py#L330), but generated attachment dependencies are rebuilt at [layers.py:421](../../src/metaform/layers.py#L421); impact analysis examines attachment dependencies. Meaning used to design a generation can therefore be absent from the dependency chain that determines its later impact.

Other source-supported repairs include binary-aware intake access, example scripts depending on local scratch paths, prompt comparison rewriting its source and using moving HEAD, missing command/parameter reference, and unavailable sampling producing an unexplained unchanged job. The retained browser failure, history permission reproduction, remote CI failures, and reported flaky test were not independently rerun here.

## Corrections to proposed repairs

| Backlog item | Corrected assessment |
| --- | --- |
| R02 module metadata | The current module-description gap is repaired, but detailed reference is not: 109/111 command descriptions, 35/287 parameter descriptions, no command examples, and no module settings declarations. The distribution retains the old module count. |
| R13–R16 concierge guidance | Moving guidance into manifests and composing a live catalog is real progress ([onboarding.py:6](../../src/metaform/onboarding.py#L6)). It does not complete progressive delivery: the entire module guidance is still appended, and MCP state includes command schemas. The supplied conversation explicitly asks for operative detail when the operation is selected. |
| R17 skill behavior | Current help explicitly says it prints the skill; installation is separate. Do not describe the source as still printing the old packaged file verbatim. Plain `skill` uses packaged modules; App-backed guidance uses the selected project's visible registry. |
| R30 handoff | Launcher derivation is repaired in source and its four existing cases passed. A complete packaged handoff remains open because dist is stale. |
| Fix first 4 / C2 | Answer identity repair is warranted. Adding blanket schema rejection is a separate behavior change and conflicts with established annotation behavior. Do not bundle it into the routing repair. |
| Fix first 9 / F1 | Every property subset is intentional; SPEC §8/A-6 also specifies one fresh-context assignment. Size is a real capacity concern. Reporting counts does not change that contract; splitting workers, changing answer semantics, or capping subsets does. No arbitrary cap is established by the review. |
| Fix first 10 / H1 | Recursion with missing inputs can produce unusable placeholders, but a blanket prohibition on running-parent recursion is broader than the demonstrated problem. [Engine.recursive](../../src/metaform/workflow.py#L622) accepts explicit inputs. Separate input-loss/diagnostic repair from any new lifecycle restriction. |
| Fix first 13 / J1 | Auto-build is implicit and insufficiently explained, but it does not rebuild unconditionally after every command. [packaging.py:109](../../src/metaform/packaging.py#L109) checks enablement, project layout, and changed source hash. The registry awaits the thread ([registry.py:266](../../src/metaform/registry.py#L266)). |
| Fix first 23 / I4 | The workbench already displays Generation request, IDs, status, and expandable assignment content ([workbench.js:525](../../src/metaform/static/workbench.js#L525)); Edit revision also displays reinference. Persistent discoverability after navigation is a narrower gap. Confirmation dialogs are a proposed UX change. |
| Fix next 46 / H9 | File import already sets `base_dir` from the workflow file's parent ([modules/workflow.py:78](../../src/metaform/modules/workflow.py#L78)). An isolated probe imported a relative `file:prompt.txt` from outside the project and rendered it correctly. Retire this defect as written; in-memory imports have no file path to infer. |
| Tests to add 74 / H9 | Workflow attachment coverage already exists in [test_knowledge_dependencies.py:9](../../tests/test_knowledge_dependencies.py#L9) and passed. Identify any missing behavior specifically instead of claiming attachments have no test. GUI Edit revision coverage remains separate. |
| Fix next 52 / J3 | A blanket hide based on selected-project `pyproject.toml` could remove a usable operation: package build accepts an explicit source. Improve applicability/error reference without erasing that route. |
| R21–R28 conversion | Existing converter and engine primitives are real. Missing live corpus evidence is not proof that they fail every source. Repair demonstrated grammar/reference gaps, then assess actual generated behavior. |
| R33–R34, R42–R43, R48–R50 | These include functioning behavior to preserve and delivery/verification work. Do not count each as a separately reproduced defect. |

## Disposition of all 28 questions for Rich

“Settled” below means the direction is already available. It does not claim the implementation satisfies it.

| Decide | Disposition |
| --- | --- |
| **1 — Native source evidence in latent context** | **Boundary settled; packaging needs a precise distinction.** Latent receives the complete Native functional account. [layers.py:200](../../src/metaform/layers.py#L200) also supplies snapshot activities containing verbatim source-file evidence ([intake.py:402](../../src/metaform/intake.py#L402)). Inspect copied implementation content separately from Native-authored understanding. Removing Native descriptions, joins, findings, or context wholesale would violate the Foundation. Any remaining question should concern the precise disputed evidence, not whether to supply the Native account. |
| **2 — Publish in answer or next** | **Implementation choice under an established completion requirement.** The foundation must become available through the returned continuation. Fix the broken route and document the chosen endpoint; Rich does not need to choose between Python methods. |
| **3 — Seed bases or diagnose** | **False binary.** Five bases and meaningful prefixes are established ([SPEC §5](../SPEC.md#5-strict-typology)). Defined base records and truthful missing-prefix diagnostics can coexist. Neither warrants fabricating unknown Type meanings or a new rejection gate. |
| **4 — Reinfer role** | **Prompt-maintenance question, not missing reinference.** [layers.py:649](../../src/metaform/layers.py#L649) already reissues original requests with destination context. Check whether the unused role contributes anything required before selecting or retiring it. |
| **5 — Rulebook defaults** | **Stale documentation plus composition verification.** [rulebook README:34](../rulebook/README.md#L34) says default intake gets r1–r4; those defaults apply to legacy prompt IDs. V2 gets structural, namespace, Name/Description, and alias semantics through [composition.json](../../src/metaform/data/roles/composition.json). No rulebook references does not mean no semantic rules. Compare delivered meaning before duplicating old rules. |
| **6 — Repeat intake and unused inputs** | **Split.** `evidence_handles` and `existing_model` are passed to the prompt ([intake.py:186](../../src/metaform/intake.py#L186)); “ignored” overstates this. Runtime does allocate a new model. Whether repeat intake revises the same model remains a genuine identity/lifecycle choice. |
| **7 — Project in harness registration** | **Ownership settled.** Project selection belongs to client/session context ([workflows](../workflows.md#L202), SPEC §13); assignments keep the captured project. Fix accidental initialization and selection delivery rather than asking whether installation should permanently freeze a project. |
| **8 — Track last blind-spot run** | **Periodic latent analysis already agreed.** A timestamp/last-generation display is an optional presentation mechanism, not a reason to block the existing direction. |
| **9 — Missing narrowing: reject or annotate** | **Required meaning settled; rejection not established.** SPEC §11 requires an authored narrowing explanation and also preserves schema/reference issues as annotations. Surface missing meaning without silently introducing a hard gate. |
| **10 — Open project, DE path, editable fields** | **Three separate UI matters.** Current serving is multi-project and the old one-project description is stale. Additional controls and editable semantic fields need concrete proposals; restore only a demonstrated promised behavior. |
| **11 — Ladybug optional** | **Mostly terminology.** Installed dependency is required in `pyproject.toml`; use of analysis copies is optional; portable mode has a separate dependency boundary. Describe these accurately. Moving a dependency into an extra is a separate distribution change. |
| **12 — Imagegen options and photograph workflow** | **Feature proposals.** The supplied conversation confirms the root prompt corpus should become bundled procedures. It does not by itself choose every additional image option or make a specific photograph pipeline mandatory. |
| **13 — License, metadata, clutter** | **Split owner decisions from housekeeping.** License, authorship, and distribution identity need Rich's input. Preserve local evidence and protected instruction material, including instruction backups; these are not generic deletion candidates. |
| **14 — Annotate-only intake** | **Settled.** Retain annotation behavior. The useful repair is making accumulated diagnostics visible at completion, not reopening acceptance policy. |
| **15 — Required fields in role prose** | **Delivery verification.** The full schema is supplied by role composition and the role asks for conforming contributions. Verify the worker receives it. Repeating field names is an implementation choice, not a new semantic requirement. |
| **16 — Remove limit/concurrency/steps** | **Overbroad cleanup.** Batch currently returns one job, making some controls misleading, but `--steps` actively bounds [the driver](../../src/metaform/modules/intake.py#L209), including retained v1 work. Examine each control independently. |
| **17 — Enumerator instruction and display names** | **Meaning already settled.** Preserve the request and derive names through recorded names/length. The hardcoded “program code” substitution is concrete naming debt ([enumerator.py:29](../../src/metaform/enumerator.py#L29)); do not replace it with another invented semantic mapping. |
| **18 — Property visibility and participants** | **Split.** Backward visibility is explicitly required by SPEC §7/A-6, including both Bash and C++ at `code`. Participant-only relationship coverage is a separate mismatch to inspect against the enumeration contract. Do not change propagation merely to match loose wording in a review. |
| **19 — Propagate property-combination advice** | **Genuine unresolved scope detail.** Physical/semantic property propagation does not automatically settle propagation of every generated piece of relationship-conditioned advice. Compare concrete direct versus descendant results before choosing. |
| **20 — Task-aware grounding** | **Current deterministic selection is documented.** `task` does not prove an intended semantic selector is missing. Document its actual role; using free text to change region selection would add behavior. |
| **21 — Medium marker and correction record** | **Split.** Medium semantics were explicitly supplied by Rich ([semantic clarification](../semantics/names-receivers-and-variants.md#L76)); authoring/storage must preserve them. Corrections must retain changed meaning, reason, and evidence. A new correction record class is not mandated if existing revision/activity records can carry those facts. |
| **22 — Global knowledge seed** | **Content work, not a default bug.** A dormant loader does not determine what knowledge should be authored. Keep separate from the already-agreed chassis Metaform requirement. |
| **23 — Move dist review folders** | **Housekeeping.** Organizing retained evidence is not a product-direction question and need not hold up functional repairs. Preserve the evidence. |
| **24 — Expose disabled_commands** | **Optional interface change.** This is runtime state, while configure writes persistent config. Exposing the same key without reconciling those semantics would not implement it. |
| **25 — Read-only workbench route** | **New mode/policy proposal.** Current write-capable dispatch is real, but a new read-only mode is distinct from restoring semantic reads during assignments. Do not turn that repair into additional unspecified gates. |
| **26 — Design reads as dependencies** | **Existing provenance requirement.** Context that influenced generated instructions/grouping must remain represented in the chain used for impact analysis. The missing chain is an implementation gap, not an optional meaning choice. |
| **27 — Gate misplaced property joins** | **Already instructed to observe before gating.** Preserve the retained failure and investigate prompt/context causes. This review does not reopen that decision. |
| **28 — Retire History/Compare** | **New product proposal conflicting with current retention direction.** SPEC explicitly retains historical v1 graphs and comparison meaning. Re-intaking the sample does not authorize retiring that access. |

## Documentation drift that explains the confusion

- [The September 7 decision record](../handoff/DECISIONS.md#L70) describes outside inference without contextual OP joins. Current SPEC and the Foundation require the complete Native account, including those joins. Keep the older decision as dated history and make its supersession explicit; do not use it to remove Native context.
- [The rulebook README](../rulebook/README.md#L34) describes legacy default rule references as current intake behavior. V2 semantic components are a different delivery path.
- Bundled historical intake/glossary material, the primer's two-graph framing, and historical sample descriptions are still reachable alongside current guidance. Current-work labels historical records, but current links and bundled reference need the same distinction. Historical inputs should retain their original text and provenance.
- [Current work](../current-work.md#L78) correctly says catalog composition is implemented and chassis self-understanding/public customization are not. R44/R46 therefore identify unfinished agreed work, not missing decisions.
- `docs/workflows.md` distinguishes literal import from conversion, but its step table omits implemented parallel work. The converter's operator list at [modules/workflow.py:325](../../src/metaform/modules/workflow.py#L325) is smaller than the actual [expression engine](../../src/metaform/logic.py#L51). Synchronize executable grammar and packaged reference.
- Verification counts describe dated runs. Preserve those records; add current evidence with its exact source/artifact scope rather than replacing historical counts or using them as evidence of today's delivery.

## Conversion and customization assessment

R19–R29 and R44–R47 remain substantial work. Workflow import, conversion, application, branching, calls, iteration, and parallel assignments exist. The conversion test used here supplies a hand-authored answer, so it proves source retention and application, not model understanding of the corpus. The seven-source matrix is useful because it evaluates authored roles, user waits, independent contexts, artifacts, and control flow separately from JSON validity.

The requested outcome is already agreed: a user and concierge should discover, create/import, execute, and share procedures using the delivered system. Remaining work includes workflow-specific discovery, complete module reference/settings, coherent runtime next actions, the chassis's functional Metaform, a public module interface, and live corpus evidence. Some execution representation details, especially actual user waits and artifact transfer, still require demonstration. That is a focused design/verification task, not evidence that the whole engine should be replaced.

The order should be: correct state contamination and shutdown; complete entry/reference/settings and reliable continuation; verify workfolder and distribution behavior; demonstrate faithful corpus conversion and the agreed customization path. Documentation updates belong with each repair. Optional UX features, new gates, and cleanup should not be folded into those changes merely because they appeared in an agent's suggested remedy.

## Verification performed for this review

- Current-source and archive inspection; module/command/parameter metadata counts; distribution hashes and selected file comparisons.
- Portable MCP probe on Python 3.13.5 using temporary portable projects: initialize, retain an open stdin pipe, send one SIGINT, check process after three seconds, then close stdin and collect exit/error output. Both source and `python -S dist/metaform` remained running until stdin closed. No shared service was launched.
- Isolated file-import probe: workflow JSON and `file:prompt.txt` stored outside the selected project; public import followed by Engine start rendered `Review the artifact.` successfully. An initial probe had an erroneous teardown call to nonexistent `App.close`; it was corrected and rerun successfully. The temporary legacy configuration disabled auto-build and required no service.
- **8 existing tests passed in 2.05 seconds**, covering live skill catalog removal, four launcher forms, attachment projection/provenance, captured file prompts, and conversion application/source retention:

```sh
.venv/bin/python -m pytest -q \
  tests/test_onboarding.py::test_skill_catalog_follows_registered_modules \
  tests/test_intake_continuation.py::test_assignment_begin_command_reaches_the_running_entry_point \
  tests/test_knowledge_dependencies.py::test_workflow_attachments_replace_projection_without_changing_source \
  tests/test_knowledge_dependencies.py::test_new_workflow_uses_captured_file_prompt_without_rewriting_source \
  tests/test_next_version.py::test_workflow_conversion_applies_without_focal_and_keeps_source
```

No full regression, browser suite, live model conversion, external host registration, or remote CI recheck was performed. The first backlog's referenced `evidence/runtime-probe-results.json`, `authoring-probe-results.json`, `module-removal-results.json`, and `delivery-observations.json` were not found in this checkout. Their reported observations remain attributable to that review; current reproduction claims above are limited to the checks actually performed here.

Only this review document was added. No runtime code, authored prompts, instruction files, original backlogs, distribution artifacts, or pre-existing changes were modified; nothing was committed or pushed.
