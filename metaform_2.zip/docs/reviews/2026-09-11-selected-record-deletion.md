# Selected semantic record deletion

Implemented `model.delete` in the original checkout. This work does not delete any existing project data; every execution below used isolated temporary projects and homes.

The operation requires the exact selected model revision and an owner-qualified Element, Type, or join. Preview returns the selected target, exact affected references, remaining semantic diagnostics, and knowledge impact. Apply removes that same set through the existing transformation mechanism and returns a new revision plus any required reinference assignments. If another revision added relationships after preview, apply rejects the stale selection before changing the model.

The deletion closure includes incident bindings, narrowings, refinements, joins, and joins that refer to removed joins. Other Elements and Types remain, including namespace descendants of a deleted Type. Project identity, configuration, source files, shared Type storage, and prior immutable model revisions remain intact. Selecting the artifact Element removes that Element and its incident relationships; surviving records retain their existing artifact references and normal unresolved-reference diagnostics. The operation does not invent a replacement artifact.

Existing `model.transform` remove operations retain their exact-record-only behavior. A retry of `model.delete` returns its original deletion revision and reinference work even after later edits, without redirecting the retry to the latest revision or creating additional jobs.

Publication now resolves Type references from structural relationship fields. Metadata such as retained provenance, evidence, and presentation references does not cause a deleted Type to reappear. Complete snapshots retain explicitly supplied Types without automatically rebuilding their namespace parents. Unfinished intake drafts explicitly request known-parent enrichment, preserving the existing draft continuation contract. Newly resolved external Types still resolve their known parents. No Type exclusion list or deletion tombstone is introduced.

The Knowledge Tool integration stores actual fixture answers through its ordinary workflow. Deleting the Bash installer preserves the generic program-code answer unchanged, invalidates the affected whole-artifact composite answer, and issues its replacement with the exact same saved creative-foresight instruction and remaining C++23 game-engine context. Recording that replacement keeps the original revision's knowledge intact. This establishes runtime dependency and continuation behavior, not model-generated answer quality.

## Verification

`PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest -q tests/test_model_delete.py tests/test_foundation_models.py tests/test_semantic_repairs.py tests/test_model_transformations.py tests/test_intake_continuation.py`

Result: **92 passed, 1 setup error in 49.64s**. The only error occurred before the service-backed Knowledge Tool deletion case began: another agent edited packaged source between server startup and its build-fingerprint check. The service correctly reported `restart_required`.

Fresh-process rerun of that exact case:

`PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest -q 'tests/test_model_delete.py::test_deletion_preserves_generic_knowledge_and_rerenders_only_the_affected_composite[service]'`

Result: **1 passed in 3.39s**. No fingerprint checks were bypassed. These are two executions, not a claim that the complete suite passed in a single frozen-source run.

Independent review reproduced and then verified repairs for deleted-Type resurrection through retained metadata, replay after later edits, and malformed relationship scopes. It also verified the original revision/shared store remained unchanged and replay kept the same actual stored reinference job with the run count unchanged.

The UI lane owns verification of the visible Delete and Native intake actions. Its agreed Native rerun contract uses a fresh `intake.start` assignment and selects its newly completed model; it does not reset or delete the project. This API work does not claim the separate MGM intake cleanup or the entire release audit is complete.
