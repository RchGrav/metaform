# PongClock coarse intake, 2026-09-12

One Codex execution of the authored seven-section intake prompt
(`src/metaform/data/roles/runtime/intake.md`, no components) against Rich's
`pongclock.zip` (five files), through `intake.drive` with the `codex` harness,
contract `urn:metaform:schema:coarse-intake:2`. No retries, no annotations, no
diagnostics. Elapsed 125.6 s. Commit `481c6a5`.

The answer arrived as two `intake.put` calls and an empty final answer
(`run.json`, `submissions`). The published foundation is `foundation.json`;
`workbench.png` is the explorer on the Defining Element.

## The shape the model reached

Four notable elements, three joins, Defining Element `code.display.time`.

| Element | EF |
| --- | --- |
| `code.display.time` (DE) | Indicates the current time of day through a continually updated representation. |
| `code.simulation` | Evolves modeled objects and resolves their interactions to produce state changes and outcomes. |
| `code.synchronizer.time` | Reconciles a represented time with a reference time through corrective state updates. |
| `code.renderer` | Converts current state into a visual presentation. |

| Receiver | Provider | OP | Combined away |
| --- | --- | --- | --- |
| `code.display.time` | `code.simulation` | Make Pong Clock's hour and minute readings emerge from scoring events in an automatically played paddle-and-ball match. | animation loop, ball dynamics, paddle control |
| `code.simulation` | `code.synchronizer.time` | Steer paddle misses and score corrections so Pong Clock's left score approaches the local hour and its right score approaches the local minute. | miss selection, score correction, time sampling |
| `code.display.time` | `code.renderer` | Make Pong Clock's evolving match and two-digit hour and minute scores readable on a canvas fitted to the browser viewport. | font-ready startup, score drawing, viewport fitting |

Rich's reference shape for this artifact: `code.loop.game`,
`code.loop.game.controls.ai`, `code.loop.clock`, `code.loop.game.display`,
`code.loop.logic`, five entities. Rich judges.

## Observed, not gated

- The prefix positions `code`, `code.display`, `code.synchronizer` were authored
  as project Types with an empty EF; no reusable base was supplied to the run.
- The explorer's neighbourhood on the Defining Element shows three cards; the
  fourth element is one hop further.
- The header's stage banner overlaps the palette control at 1600 px.

## Run 2, the refined prompt (`specifications/intake.md`)

One Codex execution of the refined seven-section prompt, Digital Archeology,
with `name_length`, `relation` and `observation` in the contract. Elapsed
123.8 s. No annotations, no diagnostics, no retries. Evidence in `run-2/`.

Three notable elements, two joins, Defining Element `code.clock`.

| Element | name_length | EF |
| --- | ---: | --- |
| `code.clock` (DE) | 1 | Clock program code maintains an indication of current time. |
| `code.simulation.motion` | 2 | Motion simulation program code computes how modeled bodies move and interact over time. |
| `code.renderer.canvas` | 2 | Canvas renderer program code draws a visual representation onto a programmable two-dimensional surface. |

| Receiver | Provider | Relation | Observation |
| --- | --- | --- | --- |
| `code.clock` | `code.simulation.motion` | runs | Motion simulation computes changes in modeled object positions. |
| `code.clock` | `code.renderer.canvas` | presents through | Canvas rendering converts display state into a visible image. |

Both OPs name the artifact and its files: "In js/script.js, local time from
Date guides paddle interception or deliberate misses ..." and "css/styles.css
arranges the display and declares fonts/ScoreFont.ttf, whose readiness through
webfont.js gates startup." No `combined` dictionary was used; the annealed
detail went into the OP prose instead, following the constraint "Keep all
artifact-specific instance data strictly confined to the Operative Purpose."

Compared with run 1 under the previous prompt: four elements became three,
`combined` dictionaries (nine entities) became none, the Defining Element moved
from `code.display.time` to `code.clock`, and file-level particulars moved from
observations into the OPs.
