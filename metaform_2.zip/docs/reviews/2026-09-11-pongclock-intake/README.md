# PongClock intake against the supplied archive

## User correction: defining Type and granularity

Rich rejected the third intake’s defining `code.clock.pong` Type: Pong is a
genre property, while the defining Type must express the core function. The
prior semantic acceptance is withdrawn. The 66 completed knowledge answers
prove execution and attachment provenance; they do not validate this model’s
typology or its intended low granularity. The original model, assignments and
answers remain as evidence.

The Native instruction now requests a coarse typological account, with
“accurate” removed and genre kept separate from the defining core function.
The genre description now applies beyond its previous architecture-only wording. This correction has not yet been established by
a fresh model-produced intake.

The input is Rich's `pongclock.zip`, not a generated fixture. The archive contains
five files: an HTML entry, CSS, the main JavaScript, the bundled webfont loader,
and a TrueType font. Each trial used a new extraction and separate Metaform home.
All three ran the runtime's Native assignment through `metaform.harness.execute`
with Codex. Their final models were published through intake.put/answer/next.
The original archive and extracted source bytes were not edited.

The latest intake is available at:
<http://127.0.0.1:44759/projects/ac95007a6d0a5e17991d400f077c4776>

## Actual trials and what changed

| Trial | Elements | Types | Joins | Result |
| --- | ---: | ---: | ---: | --- |
| First | 13 | 23 | 30 | Completed, but omitted observed language/encoding properties and missed the established Program Code account. |
| Second | 25 | 26 | 59 | Completed with properties, but invented synthetic `data.record` property-value Elements. |
| Third | 14 | 36 | 61 | Reuses actual functional Element identities across meaningful property facets; the synthetic record substitution is gone. |

The first trial exposed missing live r1/r2 rules in the managed Native composition.
The repair includes those rules and preserves authored prompt overrides and
already-issued assignment snapshots. The second exposed insufficient instruction
about typing the represented property by its function/encounter. The Native role
now explains that relationship using Rich's installer/Bash example. No expected
PongClock model or property whitelist was supplied to the worker.

All raw assignments, outputs, events and models remain in their respective trial
folders. Earlier generated models were not converted into the third result.
Each execution report records unchanged source hashes and completed nonce cleanup.
The third run took 620.35 seconds and produced no structural diagnostics; the
separate semantic review evaluates meaning rather than treating that result as
proof of correctness.

## Third account

The Defining Element is an autonomous score-clock: its rally scores seek the
local hour and minute. The account records the zero-start catch-up behavior,
automatic paddle misses, presentation, initially disabled event sound and
optional diagnostic overlay. It keeps the bundled font loader inside the
artifact boundary and the browser/time source outside it. Properties include
JavaScript, HTML, CSS, source text, the TrueType font and the applicable local
source-layout observations.

Generated source-level concerns are kept as observations: duplicate animation
scheduling, equality expressions used where assignment may have been intended,
and duplicate Ball.draw definitions. Intake did not modify or repair PongClock.
These observations are not a substitute for executing the application.

## Browser and Knowledge Tool evidence

The live browser opens the third generated model through the single global
server on port 44759. `retry-3/live-browser-evidence.json` and its screenshots
retain the visible Elements, actual recorded property/requirement relationships,
classification colors and emoji, the CF inspector, and literal Knowledge Tool
preview. The browser check reads generated records; it does not inject a graph.

The full preview has 66 questions: 36 generic Type questions and 30 complete
composites. There are no property-subset or isolated-join questions. Compact
sentences summarize names; the inference also receives the complete functional
account, origin records, signals and dependency references. In particular, UTF-8
and source-layout specifics live in the recorded signals, not in invented Type
names. The duplicate-label rendering correction retains those separate records.

The first actual Knowledge Tool launch was rejected before inference: repeated
applicability-proof paths inflated the delivered request to 1,098,606 characters,
above the harness's 1,048,576-character limit. The full assignment and failure
remain in `retry-3/knowledge/`. The repair removes duplicated traversal proofs
from inference transport while retaining the recorded origins, applicability
flags, complete functional account and durable dependency evidence. The same
assignment completed on retry in 495.3 seconds after the delivered input fell to
569,076 characters. It produced 66 answer arrays containing 198 instructions,
with no missing questions. All 66 attachments exactly match their previewed
subjects, property origins and dependencies. The generated layer is
**PongClock best practices**; the live browser retrieves its actual root
composite advice and explains its origin. The original structural model and
all five source files remain unchanged, and the fresh worker folder was
removed after completion. Raw output, receipts, attachment verification and
browser retrieval evidence are in `retry-3/knowledge/`.

The earlier advice-display wheel and standalone archive had SHA-256
`d103e1b859563383d8dcd21221623d9f21baed2c85ae339e988596ce725653b7`.
It is superseded by the [namespace and Ladybug retirement delivery](../2026-09-11-namespace-and-storage/README.md), which includes the Native prompt correction.
The preceding candidate passed installed CLI/MCP/distribution journeys,
11 shutdown cases and six global lifecycle cases. The final package differs
only by displaying generated layer instructions before property-origin details;
its semantic browser suite and actual installed browser retrieval passed. The verified private installation now owns port 44759;
all five existing catalog paths were preserved across restart. The two retired
ports no longer accept connections. [Delivery evidence](../2026-09-11-pongclock-delivery/README.md)
records the checks separately from generated model quality. The broader release repair inventory
remains in `docs/repair-backlog.md`; this test does not close that inventory by
itself.
