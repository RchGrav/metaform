The transport projection preserves the semantics supplied by this actual 66-question assignment. It removes repeated traversal proofs from the inference copy; the stored assignment and its dependencies remain unchanged.

I checked all 573 omitted path steps (85 distinct step objects) against the unchanged functional account. Every referenced relation and endpoint resolves. Every copied purpose, signal, scope, role, classification, softness value, binding realization, narrowing category and provider Encounter Function agrees with that account. Each context retains its exact subject, related record references, selected properties, originating components, relationships and computed applicability/visibility flags. No context reference is missing.

Only the `path` and `visibility_path` arrays differ in the transported contexts. These arrays repeated the selected records with runtime traversal labels and order; the worker still receives the computed selection and original property origins, so it does not need to reconstruct applicability. The complete functional account, all questions, answer schema and dependencies remain equal. The original assignment object was not mutated.

This check establishes preservation of the supplied account during transport. It does not establish the quality of a model response or a completed inference. The original failed launch remains retained beside this review.

Exact counts, input hash and comparison results: [projection-semantic-review.json](projection-semantic-review.json).
