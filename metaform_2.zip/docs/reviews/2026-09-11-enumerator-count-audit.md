# Audit of the historical MGM enumeration count

**The reported 1,198,625 is the rejected historical algorithm's question count, not a count
of Elements or joins and not a validated required workload.** It is driven mainly
by broad property visibility at a shared exterior receiver and by treating fifteen
origin-specific property joins as independent subset dimensions. A batching
decision based on that number was premature.

The user subsequently clarified the intended operation with exact sentences:
one generic node question and one question for its complete applicable composite.
The current repair is called the **Knowledge Tool**. Separate join questions and
property subsets were implementation errors, not a workload the user needs to
approve. This report retains the historical calculation as diagnostic evidence.

This read-only audit used the exact stored `examples/intake/mgm-main/native.json`
bytes, SHA-256
`8deabe99d2b987927a0be2737263de72b709075d64cf464ee5509f775caf93b9`,
through the existing in-memory `import_v1` path and property explanations. It
reproduced the actual summary without materializing questions. The historical
file's Native label does not establish uncontaminated Native provenance; that
question is being audited separately. No runtime, authored prompt or sample was
changed. Exact diagnostic data is in the adjacent JSON file.

## What multiplies

There are 408 base contexts: 105 nodes, 101 provider-end presentations called
incoming by the implementation, 101 receiver-end presentations called outgoing,
and 101 joins. There are **zero additional participant-only contexts** in this
sample. The implementation and stale specification described those relationship
presentations, but they did not match the user's intended operation. That stale
description does not justify the additional inference.

| Property joins selected per context | Contexts | Subset questions |
|---:|---:|---:|
| 0 | 91 | 91 |
| 1 | 75 | 150 |
| 2 | 80 | 320 |
| 3 | 22 | 176 |
| 5 | 10 | 320 |
| 6 | 44 | 2,816 |
| 7 | 18 | 2,304 |
| 9 | 1 | 512 |
| 12 | 35 | 143,360 |
| 15 | 32 | 1,048,576 |

Thus **32 × 32,768 = 1,048,576** and **35 × 4,096 = 143,360** account
for almost all the total. The 32 largest contexts are the `mgm:operators` Element,
its `exterior.group.operator` Type, and three presentations of each of the ten
relationships received by those operators:

| Provider | Operator's recorded purpose |
|---|---|
| `mgm:mgmconfig` | Prepare generic mesh nodes without reconstructing UCI wiring. |
| `mgm:cli` | Inspect and control running gateway coordination. |
| `mgm:observer` | Distinguish startup phases and confirm bounded readiness evidence. |
| `mgm:luci` | Configure address-provider profiles and inspect management fallback. |
| `mgm:leds` | See bounded WAN/mesh status without a command session. |
| `mgm:pidemo` | Bring up and inspect demonstration nodes. |
| `mgm:guide` | Configure, inspect and troubleshoot the deployed package set. |
| `mgm:sentryhandoff` | Inspect direct-uplink decisions and probe performance. |
| `mgm:project` | Keep upstream gateways usable with manageable deployment and diagnosis. |
| `mgm:autoap` | Retain local management access when upstream DHCP is unavailable. |

The JSON preserves the exact join IDs and purpose text. Other large node contexts
include `mgm:project` and `code.coordinator.gateway`, each with twelve visible
property joins, and `code.interface` with nine.

## The concrete scope problem

`enumerator.property_context()` selects `visible_here`, then unions the bags for
the focal subject, receiver, provider and relationship. The property engine
already distinguishes this from `applies`.

JavaScript applies at the LuCI configuration interface. Its visibility travels
from LuCI to Mesh network operators because those people receive configuration
functionality. At the operators it is **visible but not applicable**. At the
operations guide it is **neither visible nor applicable**. Nevertheless, the
guide-to-operators relationship gets JavaScript and all fourteen other property
joins from the operators' pooled visibility. The context has fifteen selected
properties but zero properties that the engine marks applicable anywhere in that
context.

The generated question retains the property origin, such as JavaScript joined to
LuCI. It does not literally claim the guide is JavaScript. However, that qualification
does not establish that every subset of every other thing those people receive
is a relevant property context for this particular guide relationship. This is
where the million-count claim exceeds demonstrated semantic correctness.

## Why neither blanket replacement nor deduplication settles it

The fifteen property joins use seven provider Elements and six provider Types:
Shell has six origin joins, C11 three, C two, and JavaScript, an assurance
constraint and two configuration providers supply the remaining four. The two
configuration providers share one Type. Distinct receiver/purpose/origin joins
are not exact duplicates. Collapsing solely by Type would lose that placement.

For diagnosis, applying alternative selectors to the same stored graph gives:

| Diagnostic selector | Property-count histogram (properties: contexts) | Subset count |
|---|---|---:|
| Existing context union, `applies` only | 0:214, 1:124, 2:55, 3:15 | 802 |
| Focal subject, `applies` only | 0:308, 1:82, 2:18 | 544 |
| Existing visibility union, distinct provider Types | 0:91, 1:75, 2:98, 3:15, 4:59, 5:37, 6:33 | 4,993 |

**These are not proposed correct replacement counts.** They retain the rejected
subset operation merely to diagnose its multiplication. The stale SPEC A-6
description of separate no-property, Bash, C++, and combined contexts has been
corrected. The intended questions preserve the generic base and the complete
branch-qualified composite, including each property's origin. Backward visibility
toward the defining account or namespace trunk remains distinct from applicability
to unrelated branches. The repair therefore changes the generated operation;
it does not cap or split the erroneous million-question workload.
