# Source-authored execution policy evidence

The source `prompts/python_to_c.md` requires retrying a crashed agent once, stopping execution when a phase fails, deadlines of 3,600 seconds for phases one through three, and a shared 7,200-second deadline for phase four. Its instruction to report and continue after a negative validation result remains unchanged. The live conversion retained these requirements as metadata; the runtime previously did not enforce them.

The bounded representation is a step's `execution_policy` object, with only authored `timeout_seconds`, `agent_failure: retry_once_then_fail`, and `phase_failure: stop_execution` fields. No policy is added to other workflows. The library owner mapped the original requirements into the bundled definition and grammar; the original retained model output was not rewritten.

## Runtime behavior

An active phase stores its deadline once. Child calls and parallel runs inherit that scope, and retries keep it. Harness process failures and MCP sampling exceptions consume the same persisted per-assignment retry budget. A returned negative validation answer is ordinary workflow data. Explicit resumption after a crash in a workflow without policy remains explicit; no automatic retry is introduced.

A failed phase stops its active descendant runs and owned workers, retires pending nonce records, preserves completed answers and failed-attempt artifacts, and leaves unrelated runs and their selected mode intact. The phase owner and failing origin retain `status: failed` and `result.failure` with the actual error, origin run/request, phase owner/step, timestamp, and attempt count when applicable. Cancelled siblings retain `status: aborted`. Failed work is excluded from pending handoffs, including exported/imported bundles. Guide and Activity presentation are handled by their respective owners using this stored result.

Deadlines are checked during an owned harness or sampling operation and when an externally managed assignment is resumed, begun, or answered. The actor gateway performs the same check using its server-captured assignment. There is no inferred heartbeat for externally launched workers. A deadline cannot forcibly stop a worker process that Metaform did not launch and does not own.

## Adversarial failures reproduced and repaired

- A first attempt wrote a partial `response.json` before exiting nonzero. The retry could consume that old file after succeeding through stdout. Each new attempt now archives its own previous response before launch. This also covers explicit resumption without a policy.
- Interrupting after the second failure was stored but before terminal failure was saved allowed a third attempt on resume. The persisted failure budget is now checked before launching any attempt.
- A sibling sampling operation without a timeout kept waiting after another child exhausted retries. Policy-managed sampling now observes terminal run state, cancels the operation, and awaits its cleanup.
- A crashed worker left a descendant holding stdout/stderr open, preventing `communicate()` from finishing and blocking failure handling. The harness now notices the direct worker's exit and drains owned pipes during the existing shutdown grace period. An owned process group that still holds them after the grace period is killed, even when its direct parent already exited. The regression uses a real descendant that ignores SIGTERM.
- A phase could fail while its parallel children were being started; stale parent state could then overwrite the failure. Child startup and parallel collection now recheck durable parent state.

The independent verification owner reproduced the first three failures separately and reran those probes successfully after correction. Their retained results are `/tmp/metaform-release-verification-foeisy3a/policy-adversarial-fixed.json`. Their distribution check remains a separate release requirement.

## Verification

`tests/test_execution_policy.py`: **14 passed in 18.38 seconds**. These exercise real failing and sleeping processes, child process cleanup, parallel cancellation, a deadline shared across sequential child assignments, MCP sampling exceptions and cancellation, begin and actor-gateway expiry, failed-run export/pending behavior, negative validation answers, durable retry exhaustion, and explicit no-policy resumption.

The broader lifecycle, harness, MCP, image transport, build cancellation, and service lifecycle rerun passed **134 tests in 86.69 seconds**, retained in [final execution-policy test output](2026-09-11-execution-policy-final-tests.log). Command:

```sh
PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest tests/test_execution_policy.py tests/test_release_lifecycle.py tests/test_intake_continuation.py tests/test_codex_harness.py tests/test_mcp.py tests/test_mcp_artifacts.py tests/test_build_cancellation.py tests/test_service_lifecycle.py -q
```

`git diff --check` passed. Linux/Python 3.13 source checks establish these paths; Windows process-tree cleanup requires execution on a Windows runner.
