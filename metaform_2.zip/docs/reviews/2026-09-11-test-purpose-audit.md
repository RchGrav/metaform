# Test purpose and evidence audit

This audit separates runtime correctness, source semantics, actual inference, and delivery. It is based on inspection of the tests named below and the repair regressions. Counts are execution totals, not quality scores.

| Evidence | What it establishes | What it cannot establish alone |
| --- | --- | --- |
| CLI/reference/onboarding/install tests | Module registration/removal, parsed arguments, usable help, configuration scope, launcher behavior, project/binding selection | A fresh installed artifact or a particular third-party host applying startup instructions |
| MCP/service tests | Protocol exchange, tool visibility, assignment attribution, transport cancellation, accepted-operation ownership and replay | An LLM understanding instructions; unexecuted Windows behavior |
| Role composition, rulebook and managed-prompt migration tests | Exact authored wording/revisions, components/schema delivered, old managed revisions upgraded while authored overrides and issued assignments remain unchanged | Semantic adequacy of a model-produced foundation |
| Foundation/property/namespace/semantic-read tests | Preserved receiving-purpose-provider relationships, recorded Medium/name distinctions, property applicability versus visibility, complete read dependencies | Whether a model inferred the right artifact identity, Type placement or missing requirements |
| Transformation/layer tests | Source immutability, traceable edits/mappings, causal impact, retained original requests, correct regeneration and history | The quality of generated advice or an inferred transformation |
| Workflow/harness/lifecycle tests | Stored assignments, actual subprocess/tool transport, branches/calls/iteration, authored user waits, exact replay/abort, file/symlink/directory handling | Quality of converted procedures when answers come from fixtures |
| Browser tests | Real browser layout, hit testing, navigation, persisted pending state, edit roundtrips and readable selected views | All display sizes, all browsers, or semantic correctness of fixture records |
| Portable/module/packaging tests | Actual archive creation/import, public module lifecycle and state, dependency capture, build applicability | Every dynamic third-party import or every operating system/host |
| Real Codex conversion/intake and independent semantic review | Observed model output from retained actual assignments, checked against the source requirements | Universal model reliability or an untested branch of generated control flow |
| Rebuilt distribution journeys | Behavior of identified installed/wheel/standalone bytes outside source imports | Unexecuted external hosts/platforms or public release authorization |

## Concrete verification defects repaired

- The previous MCP interrupt test closed stdin through `communicate()` before checking exit. That unblocked the reader and masked the user's hang. New cases wait while stdin remains open, and also test a full output pipe and a blocking handler.
- SDK subprocess tests omitted `PYTHONPATH`; the client environment allowlist caused the original editable checkout to run. The repaired tests pass the worktree source path explicitly. Delivery checks clear source imports and identify the installed package separately.
- The History browser test performed another layout action after expanding its controls. That action repaired the geometry before the click assertion. The new direct expand→click case reproduced the actual missed selection.
- A fabricated nonce marker fixture no longer represented a valid binding once stale-marker handling was repaired. Its fallback reached the real default service home. Every test now has an isolated default home, and binding tests construct actual stored assignments. The exact test-started service was stopped; persistent home data was not deleted.
- A literal-template preservation regression caught an overbroad strict-rendering repair. Generated/plain literal instructions and execution templates now have distinct treatment; preview retains its response schema and reports missing inputs.
- An apparent migration failure was caused by placing a new documentation header inside a historical glossary used to reconstruct known prompt revisions. The original bytes were restored and the dated status moved into the adjacent index, without broadening migration hashes or discarding the test.
- The old launcher test created empty pretend executables and compared the resulting command string without executing it. It therefore favored the defect where embedded callers issued their own unrelated script as the worker command. Its replacement runs the exact issued handoff from an empty directory with source import environment removed; real archive invocation remains covered separately.
- Small browser fixtures did not expose repeated full-report polling queuing behind a 35 MB response from actual intake history. The live Foundation run reproduced the stall, and a narrow pending-status operation plus coalesced polling repaired it. That run also exposed semantic navigation hidden during an active workflow, despite the existing pending-banner test passing.
- Independent scrutiny of the delivered shutdown probe showed its blocked-output case could pass after a short error response without ever filling stdout. The artifact check now requires successful protocol responses and observes queued pipe data. Its separate large-response case remains a distinct completeness/Unicode check.

## Redundancy assessment

The repeated managed-prompt fixtures exercise distinct historical revisions and the risk of overwriting authored edits; they should remain. Git/plain-directory, JSON/SQLite and Git/no-Git lifecycle combinations cross separate snapshot, serialization and application paths, so their parametrization is substantive. Direct runtime, MCP, CLI, archive and browser checks intentionally cover different transport boundaries; they are not interchangeable merely because they use the same small fixture.

The test named `test_real_harness_examines_native_purposes_with_scoped_tools` in `tests/test_execution.py` executes a real Python subprocess and tool gateway, but that subprocess writes fixture answers. It supplies transport/context evidence, not live-model semantic evidence. The real source-corpus and intake outputs are retained separately. No test was removed merely to lower the total, and no one-test-per-backlog-row suite was added.

## Retained workfolder flake

The historical report observed `test_changed_engine_context_preserves_installer_advice_and_original_request` once losing its workfolder during a combined run. The same test then passed independently. The first current full source integration run passed that test and the surrounding suites. New lifecycle review also found concrete sibling cleanup, stale binding and symlink/directory defects, each with its own reproduction. These do not prove the cause of the historical disappearance. A focused combined rerun and its result are retained with final verification; absent reproduction is not a diagnosis.

## Integration status

The first full source run had 774 passes and five failures in 225.02 seconds. Each failure was assigned to an owning repair, not dismissed as a test-count issue. Final full-suite, browser, live-inference and rebuilt-artifact results belong in `../release-quality-status.md` and the per-item closure ledger. This audit does not mark the release complete.
