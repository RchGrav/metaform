# Knowledge Tool: base and whole-composite verification

The current Knowledge Tool preserves the caller's instruction and renders a base question plus one question for a complete property-qualified context. Properties remain grouped by their originating components. It does not generate property subsets or separate join, direction, or participant questions.

The explicit fixture selects repository program code and produces exactly:

1. `the top 3 best practices for program code`
2. `the top 3 best practices for repository program code that is part bash installer, and part cxx23 game engine`

The same fixture with `the top 6 creative thinking with foresight imperatives` changes only the instruction prefix. The complete fixture contains six recorded Type bases and three distinct Element composites: nine questions. An Element reuses its recorded Type base. A directly bound Element and the corresponding Type view share their identical composite; names alone are not used to merge identities. The exact fixture, renderings, question schemas, references and dependencies are in [the renderer evidence](2026-09-11-knowledge-tool-preview.json).

The [public replacement proof](2026-09-11-knowledge-tool-invalidation.json) starts a named layer through `knowledge.start`, records answers, and applies `model.transform` to replace the Bash installer and C++23 engine with a recorded JavaScript engine. It retains the original generic program-code answer byte-for-byte, removes the old composite from the destination's active answers, renders the saved instruction against the JavaScript context, and records the new answer in the same composite slot. The original foundation revision and its answers remain unchanged. Generic and JavaScript arrays in this proof are Rich's supplied examples. Other arrays are labeled fixture responses. This proof is not a model-produced intake or conversion-quality evaluation.

Each answer retains its question, context references, generating recipe and input dependencies. Generic Type bases depend on their Type definition. Composite answers depend on their relevant definitions and relationships plus a deterministic property/component membership selector. The stored evidence exposes those dependencies directly. The worker receives the Native functional account once, with each question's matching component, property-origin, EF, receiving entity and OP references.

Focused failure cases also establish:

- Adding a property invalidates the relevant composite even when all formerly read records remain unchanged.
- Adding the first property schedules the first composite questions while retaining existing generic answers.
- Removing the final properties retires obsolete composites without issuing empty inference assignments.
- An exterior receiver does not pool unrelated providers' properties into a sibling's question.
- Soft properties stay local; independently tested eight-property input still produces one base and one whole composite for the selected artifact.
- Older issued Enumerator assignments remain answerable through their captured question/schema records. Regeneration uses the saved instruction with the current contract, retires superseded active answers, and preserves prior generations. A historical layer is rerendered once in its saved scope, rather than once per obsolete join/direction subject.

`tests/test_enumerator.py` retains its historical filename to support the independent deletion fixture imports; runtime and public authoring use `knowledge_tool`, the `knowledge-tool` role and `knowledge.preview`/`knowledge.start`. The relevant renderer, semantic repair, intake, layer reinference and knowledge-layer suite passed **58 tests**. After the final historical scheduling correction, the focused current renderer/semantic selection passed **12 tests**. Separate deletion and historical probes are being retained by the independent lifecycle reviewer. No MGM dataset was converted or edited by this repair lane.
