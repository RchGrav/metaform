# Namespace navigation and Ladybug retirement

Rich reported that the left namespace did not work and that the viewer still
advertised the retired Ladybug integration. These are established repairs.

The live pre-repair browser showed that selecting a namespace updated only the
inspector, and reloading a Type member view left its graph empty. Namespace
selection now browses the selected Type's members, including descendants, while
showing its definition in the inspector. Arrow controls expand children, show
loading feedback, and retry failures. Browser checks exercise mouse/keyboard
selection, rapid toggles, paging, Back, reload, model selection and stale replies.
Revision changes reload the member graph instead of retaining the previous
revision's records; refresh retains all model choices. Visual inspection also
identified inappropriate neighborhood dimming and a vertical layout that left
most members offscreen. The selected member set now uses a readable grid with full visibility, verified
through actual rendered opacity and bounds, separately from loaded-record counts.

Ladybug was still a required dependency, a selectable legacy backend, a service
analysis-copy implementation and an advertised Cypher command. The repair
removes those implementations, command/settings registrations, dependency and
lock entries, and the query console. Viewer settings and network responses use
the active storage backend, so preserved old configuration cannot mislabel a
SQLite service. The development environment dependency was removed as well. The separate Analysis module for blind-spot
work remains. SQLite and JSON storage continue to work. Saved retired database
files are not converted, deleted, or replaced with empty databases. Dedicated
regressions check that opening/adopting an unsupported saved backend preserves
its files and configuration.

The source/backend lanes passed their focused checks; their selections overlap
and are not added into an inflated total. The installed candidate `95347fa5`
passed the CLI/MCP/distribution journey, namespace navigation, the semantic
browser suite and all 11 shutdown cases. Its private environment was created
from scratch using the locked dependencies and contains no Ladybug package.
Raw evidence is retained alongside this report.

## Final delivery

The final wheel and byte-identical standalone archive have SHA256
`95cffc40ce99b37152bfcf1dafdb05b30c4ad61766732c8167d8b38f01331805`.
All 161 packaged source/resource files match current source. Relative to the
installed `95347fa5` distribution/shutdown test candidate, only `viewer.py`
(active-backend reporting) and `static/workbench.js` (storage notice and member
presentation) changed. The 21 viewer tests and both installed namespace/semantic
browser suites passed for these final changes; the unchanged core matrix was
not counted as a second run.

The live server now uses this build on port **44759**. The browser verifies the
actual PongClock Program Code branch: all nine members are undimmed and entirely
inside the canvas, 11 child Types expand, and reload preserves member and direct
scope selections. Served JavaScript bytes equal current source. The query
console and Cypher command are absent, the blind-spot Analysis module remains,
and the browser reported no JavaScript errors. Exactly one persistent Metaform
server was found; retired ports 44863 and 45223 are closed. All five project
registrations, the source archive, and the five PongClock source files remain.
The stored model revision remains unchanged.

[Artifact](final-artifact.json) · [Live browser](live-browser.json) ·
[Visible member grid](namespace-live.png) · [Server ownership](live-ownership.json)


The corrected Native prompt and genre description are included in these builds.
They have not yet produced a newly reviewed intake. Earlier acceptance of the
third PongClock model remains withdrawn; this UI/storage repair does not validate
that model's typology or close the broader repair backlog.
