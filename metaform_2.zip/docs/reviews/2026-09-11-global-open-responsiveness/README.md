# Large-project open and global responsiveness

The first live open of the existing Metaform self-intake project timed out at the
client's 30-second `POST /v1/viewer/open` deadline. The accepted server operation
finished afterward and retained the project in its catalog. This was the new
global owner on port 44759, instance
`93705716-e6e9-4d93-a1c8-246efed3e2a1`, PID 1440058; the project used service
storage, not legacy storage. The [handover record](../2026-09-11-global-live-handover.json)
records its identity and prior-owner migration.

## Cause and changes

The project's 206,790,656-byte knowledge database contained large historical
assignment/model records. Eight managed prompt updates occurred separately,
with observation timestamps from `2026-09-11T10:57:30.338814+00:00` through
`2026-09-11T10:57:55.858884+00:00`. Each update took approximately 3.6–3.8 seconds;
the final commit and initialization overhead exceeded the client's deadline.

Profiling a disposable database copy established that one tiny graph write took
4.125 seconds. Whole-owner export took 1.430 seconds and replacement took 1.993
seconds, including JSON conversion and rewriting historical observations. An
unchanged prompt seed took 0.0098 seconds with fourteen reads and no writes.
This was upgrade work repeated per changed prompt, not a slow write on every
unchanged startup. See the [raw profile](single-write-profile.json).

`prompts.seed` now collects the records already selected by its existing managed
upgrade logic and submits them in one authored/prompts graph write. The same
record normalization is used by ordinary prompt editing. Authored overrides,
rule attachments, descriptions, historical observations and issued assignment
snapshots retain their prior behavior. No storage schema, authored prompt
behavior, output gate, timeout or pending-operation API changed.

The same historical store, reconstructed in a disposable copy with its eight
current prompt records restored to pre-upgrade values, completed all eight
upgrades in **3.672 seconds**, one graph write and one revision increment. The
copy retained older history; only the eight copied post-upgrade observations
were removed to model the pre-upgrade state. The [raw batch result](batched-seed-profile.json)
records the method and an initial artificial reconstruction error that was
corrected before measurement. These measurements concern seeding; they are not
an end-to-end claim about every future project-open duration.

Separately, the viewer held its global project lock throughout initialization,
and its catalog route wrapped the full catalog read in that same lock. Both
could block health, static files and already-open projects. Initialization now
uses a lock for the selected project; the shared lock protects catalog snapshots
and publication only. Concurrent opens of the same project still initialize it
once. The redundant full-catalog wrapper was removed after independent review
reproduced the second blocking path.

## Original-data integrity

All profiling writes targeted `/tmp/metaform-large-seed-profile-zs5zxieb`, a
SQLite backup of the named self-intake database. The original database's SHA-256
before and after both measurements was:

```
492b69e66bfb37efbe3c9788962ee6ef928e3cfe697d4df8d4458df612847036
```

No live restart or project mutation was performed by this repair lane. The
coordinator owns installation of the rebuilt bytes and subsequent handover.

## Executable checks

The retained [global viewer tests](../../../tests/test_global_viewer.py) use real
HTTP requests with event-controlled slow initialization/catalog reads. Both
failed with request timeouts before their respective lock corrections. After
the changes, health, static files and existing-project settings finish while
the slow operation is still blocked; repeated opens of the slow project return
one initialization. The two targeted cases passed in **1.33 seconds**.

The [prompt upgrade regression](../../../tests/test_intake_prompt_upgrade.py)
uses an actual KnowledgeStore. It first reproduced two commits for two managed
upgrades, then verified one commit, preserved authored replacement instructions
and metadata, retained prior observations and the exact previously issued
assignment, and verified that repeating seed causes no write.

The final owned regression command passed **45 tests in 6.99 seconds**:

```sh
PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest -q \
  tests/test_intake_prompt_upgrade.py tests/test_global_viewer.py \
  tests/test_viewer_projects.py tests/test_foundation_migration.py
```

An earlier combined viewer/service/project run passed 66 tests in 23.60 seconds
after the initialization-lock correction and before the catalog-wrapper and
seed-batching deltas. Independent review also exercised a real global child
with another home's ownership lock held: corrected viewer routes answered in
2–4 milliseconds. That probe exposed a separate service attachment lock that
still blocked catalog and other-home graph reads; the service owner is repairing
that path separately. This report does not close that finding or replace final
artifact/integration checks.

[Owned file hashes](owned-file-hashes.json) identify the source and test bytes
checked here. All checks in this report ran on Linux with isolated test runtime
directories.
