# Persistent global service implementation evidence

The user's later global-server instruction supersedes the earlier idle-daemon repair: one persistent server process and port serves this OS user. Storage homes retain their own knowledge databases, credentials, project identities and revision histories. No idle timeout or browser heartbeat controls the server lifetime.

## Ownership and runtime behavior

`service.py` owns the canonical `~/.metaform/runtime` endpoint, instance lock and startup lock. `METAFORM_RUNTIME_DIR` provides explicit isolation for tests. The same threaded Werkzeug listener serves authenticated knowledge RPC and the workbench. Its accepted handlers drain before storage locks are released. The viewer owner moved revision previews onto this listener as well.

Each explicitly attached storage home retains `service/knowledge.sqlite3`, its token and historical store ID. Its endpoint becomes an alias to the same global PID, port and instance. The global owner keeps each home's existing ownership lock. An old per-home owner is stopped only after its authenticated challenge and instance match; the unchanged database is then opened by the global owner. There is no database merge or implicit project adoption.

Owner-created Apps use direct knowledge dispatch through an injected client factory. This avoids self-RPC for project construction and storage operations. CLI clients continue using the existing request envelope, mutation receipts and ambiguous-query behavior. Restart preserves the port unless an explicit replacement port is requested. Responses that cross restart verify the new endpoint before accepting its result.

The child launcher explicitly imports the loaded package/archive. Its startup fingerprint is captured once and reported in endpoint/health metadata. A different client build receives a concrete `restart_required` result rather than silently replacing the global process. The persistent child drops the starting client's project, home, portable-mode, binding and actor-gateway environment; runtime isolation and package/dependency import context remain intact.

Browser-triggered stop and restart acknowledge the request before draining it. Restart reserves the existing global start lock, drains handlers, closes resources, releases store and instance ownership, and starts the replacement through the existing launcher. No separate restart coordinator process is created. Invalid listener arguments are rejected before stopping the current owner.

## Adversarial findings and corrected checks

- The original two-home probe produced two PIDs and ports. Both homes now share the same owner while their store IDs and project lists remain separate.
- The first combined HTTP implementation sent viewer requests through knowledge authentication. Routing was corrected and tested through real project URLs.
- A request crossing an explicit restart received a valid response from the new instance and was incorrectly rejected. The client now verifies the replacement endpoint without repeating an already returned operation.
- A browser `service.stop` request waited for its own draining handler, returning HTTP 400 after 30.026 seconds. Independent reruns now acknowledge `service.stop`, `viewer.stop` and `service.restart` in 0.009, 0.008 and 0.008 seconds. Stops release ownership; restart changes the instance while retaining the port.
- A portable-mode launch contaminated later unrelated service projects. A malformed inherited assignment binding also broke later project opening. Both failures were reproduced, corrected at the persistent-child environment boundary, and independently rechecked together.
- Invalid restart arguments stopped the existing server before reporting the error. Validation now occurs before any lifecycle mutation; the regression verifies the existing instance remains running.

## Retained verification

The integrated global service, existing lifecycle, analysis, intake, MCP, image transport and viewer set passed **87 tests in 62.99 seconds**, recorded in [the integrated log](2026-09-11-global-service-tests.log). That run preceded the final environment-isolation and invalid-restart corrections.

The final focused `tests/test_global_service.py` run passed **14 tests in 8.52 seconds** after those corrections. It includes:

- different storage homes and eight concurrent starters sharing one runtime;
- projectless start/status/restart, persistence despite old saved idle settings, and unchanged storage separation;
- viewer and RPC identity agreement on one listener;
- actual prior-owner migration retaining project registration and receipt revision;
- a copied package launched with `PYTHONPATH` cleared, matching served static bytes and fingerprint;
- public browser stop/restart acknowledgments and accepted viewer-operation draining;
- invocation-environment isolation and non-destructive invalid restart handling.

All checks used isolated temporary runtime directories on Linux/Python 3.13. The coordinating verification lane owns the final full suite, rebuilt distribution and live handover. These source checks do not constitute Windows verification or a claim that every unrelated worker subprocess path is free of lifecycle defects.

## Attachment contention follow-up

The real-server handover review found that waiting for a new home's ownership lock held the global entry lock. This blocked the catalog and a different, already-open home's graph reads. The viewer's separate initialization lock was repaired by its owner; this service defect remained independently reproducible afterward.

Attachment now uses one lock per home for ownership migration and store initialization. The global lock covers entry snapshots and publication only. Duplicate callers recheck the published entry; one deadline covers their attachment wait. Failed catalog publication removes the new alias before releasing storage ownership. Existing-home credential reads happen outside the global lock.

The new regression first failed on a catalog timeout, then passed with two simultaneous projects waiting for the same new home while existing-home catalog and graph reads remained responsive. Both projects registered successfully after release. The independent exact probe observed catalog HTTP 200 in 10 ms and the existing home's graph read in 20 ms while the new home stayed locked; health, static and settings responded in 3–6 ms. Releasing the lock completed the pending project open. The independent code review found no new publication or lock-order race in this scope.

The global-service and existing lifecycle tests then passed **38 tests in 26.16 seconds**; output is retained in [attachment lock verification](2026-09-11-global-attachment-lock-tests.log). `git diff --check` passed. No live server was changed or restarted for this correction.
