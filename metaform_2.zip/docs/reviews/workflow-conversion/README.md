# Seven-source conversion evidence

Each source was submitted as a stored `workflow.convert` assignment to the actual
Codex command harness. The response was submitted to that exact request and
applied through `workflow.apply`. No model output was replaced with a fixture.

Each source directory retains `assignment.json`, unchanged `model-output.json`,
`application.json` and complete `events.json` with the harness response. Packaging
namespaces workflow identifiers and restores the exact bundled source text on
inspection. `packaging.json` records that mapping. `corrections.json` records
subsequent source-preservation and runtime-interface repairs separately from the
original generated response. Independent reviews and their correction checks are
retained alongside these files.

| Source | Procedure behavior exercised by source tests |
| --- | --- |
| dual_agent | Actual user wait, independent evaluator assignments, rejected-plan repair, artifact handoff, measured coverage condition and exact completion output |
| metaprompt | Exact initial question, real clarification continuation, simple path without mandatory experts, conditional fresh creator/reviewer and revision loop |
| multi_agent_orchestrator | Plan/setup user waits, exact approval, direct remaining-findings repair and final output |
| orchestrator | Initialization wait, deferred notice, actual goal wait, architecture/documentation phases, per-module exact PASS repair, integration/staging and satisfaction |
| extractor | Actual clarification, task artifact packet, independent Critic/Evaluator, both-list repeat condition, source permission and interrupted Implementer resumption, final user feedback |
| python_to_c | Three ordered phases of five independent assignments, prior-phase result delivery, shared-context format, three sequential synthesis roles and report-and-continue validation |
| taskeengineplus | Style requeue, positive zero-hint condition, fresh evaluation with code/test artifacts, optional documentation, permission continuation, retry context and complete planned task identities |

`tests/test_workflow_library.py` supplies labeled representative worker/user
answers to these actual converted definitions. Those checks establish executable
control flow and contracts; they do not establish the correctness of future
model-produced implementations. Real artifact-producing workflow execution is
recorded separately by the release verification lane. Host execution requirements
are surfaced in workflow discovery. Missing original source inputs, such as the
Python-to-C external event schema and unspecified detailed role contracts, remain
explicit instead of being invented.

The source and definition revisions in `src/metaform/data/workflows/manifest.json`
identify the currently distributed version. Final release verification must use a
rebuilt artifact containing those revisions.

Final focused source verification passed **81 checks in 43.77 seconds** across
`test_workflow_library.py`, `test_release_lifecycle.py`, `test_execution_policy.py`
and `test_intake_continuation.py`. This includes the compact subtree progress
operation, exact result-reference scope, file mirroring through the assignment
actor, pending-launcher recovery, malformed marker handling and phase policies.
`final-library-integrity.json` records all seven source/definition hashes and
exact original source-byte preservation. The final reference reconciliation uses
the registered `abort` command with its active-operation scope and describes
available host execution separately from missing original inputs.
