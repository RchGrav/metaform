# Independent source-semantic review: TaskEngine+

Reviewed the actual conversion, packaged definition and `prompts/taskeengineplus.md`.
The ten named responsibilities are separate assignments. Pre-Analyst, Analyst,
TechAdvisor and Planner retain their ordered outputs; task granularity is at most
one pure function and dependency artifacts are transferred. Implementer, Critic,
StyleGatekeeper and fresh Evaluator remain distinct. Evaluation preserves all four
authored deviation severities and SUGGESTED_FIX. Documentation is conditional on
the specification requesting it. Retries retain counts and prior-attempt summaries
without an invented limit. Final output carries code, tests, requested documents
and cumulative retry logs.

Concrete defects in the generated executable conditions and templates:

1. `STYLE_PASS: true` with a nonempty PATCH_HINTS list enters evaluation. The
   source's StyleGatekeeper explicitly blocks unresolved hints; that condition
   must use the actual remaining list as well as the summary flag.
2. `ALL_PASSED: true` with a queued, uncompleted planned task goes directly to the
   final deliverable. The source requires every planned task to pass. A summary
   flag alone does not establish the authored condition; even equal list lengths
   would not establish that all distinct planned task identities are complete.
3. Both installation permission questions use `{{ INSTALL_REQUEST }}` although
   their values are nested under IMPLEMENTATION or EVALUATION. The runtime raises
   a missing-input error when either question is reached. Qualified bindings are
   required.

These failures were reproduced using the actual runtime expression evaluator and
prompt renderer, then sent to the implementation owner for correction. There is
no proposal for additional rejection criteria or a generic inference validator.

The installation decision presently returns to the same worker on both answers;
the worker receives the decision in its inputs, but no actual install operation
is bound. Code/test strings and a fresh workfolder do not by themselves execute
tests, materialize dependencies or establish process isolation. The source's
explicit-stop behavior can use the public workflow abort and harness cancellation
facilities; claiming that cancellation is entirely absent would overstate the
remaining limitation. Full actual execution needs the corresponding host
capabilities and evidence, beyond valid assignment structure.

## Correction review

The corrected branch checks actual remaining hints and the Critic's authored
RESULT union, not an invented top-level PATCH_HINTS field. An intermediate repair
and its fixture used that wrong shape; independent review reproduced the resulting
failure to advance a clean attempt, and both were corrected. Exact clean results
now advance; nonempty hints and a truthy `"no"` style flag do not.

Final dispatch checks planned task identities against completed identities and
their actual style/deviation results, queue and current-task state. Duplicate
completed IDs cannot stand in for a missing planned task, and a summary flag does
not override the actual state. Both permission questions now render their nested
requests and return the actual user decision to the requesting role. The source's
conditional documentation and explicit stop remain intact. Ten independent
expression/template cases using the emitted result contracts are retained in
`semantic-correction-verification.json`. Process execution is bound to the
executing host; the checks do not claim a real software task's tests were run.
