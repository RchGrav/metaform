# Independent semantic review: metaprompt

Reviewed `prompts/metaprompt.md`, the actual converter response, and the packaged
definition on 2026-09-11. Packaging namespaces the parent and child workflow
identifiers; the source text remains separately retained.

The exact introductory user question is preserved as an actual waiting step.
Clarification is conditional on materially missing information. The actual user's
answer flows into the brief, and earlier dialogue and requirements are retained.
Specialist creation and review are distinct fresh assignments, with full task,
brief, prerequisite contributions, candidate, and review handoffs. Revision loops
retain disclosed uncertainty instead of requiring unsupported certainty. Final
prompt structure, optional rationale, and the separate delivery note are retained.

Two findings remain:

1. **The clarification branch cannot ask its question.** Actual execution through
   request_topic → refine_request → clarification_route with
   `needs_clarification: true` and `clarification_message: "Which use case?"` raises
   `Missing workflow input: 'clarification_message' is undefined` at
   ask_clarification. Its local assignment inputs do not enter the frame's template
   scope. The current engine can render the recorded brief's qualified field;
   correct that reference and verify the actual user answer reaches update_brief.
2. **Expert delegation becomes mandatory for simple work.** The source's expert
   decomposition and assignment section says "Only if needed". The conversion
   correctly allows an empty specialist plan, then unconditionally launches a fresh
   Prompt Verifier for every generated prompt. Final verification is authored, but
   delegating that verification to another expert in every simple case is an added
   requirement. Preserve verification while honoring the source's conditional
   expert assignment.

The converter separately declares an unresolved capability: desired sandboxed
Python execution has no bound sandbox tool contract. It still creates the Python
specialist and distinguishes generated code from execution evidence. This is an
accurate reported limitation, not proof that the source's execution option works.
The library must retain that qualification until the capability is actually bound.

No retry cap, fixed expert-count cap, or required proof of every uncertain fact was
introduced. This review does not certify model-produced final prompt quality or
runtime branches that have not been exercised.

## Correction review

The correction journal matches the retained raw steps before each change and the
packaged steps afterward. The qualified clarification expression now renders the
actual recorded question. Final draft routing goes directly to delivery when no
experts were used and to fresh verification when expert work exists. Independent
checks are retained in `semantic-correction-verification.json`. Both reported
conversion findings are resolved; the sandbox capability limit remains.

The subsequent recorded host-binding correction makes the Expert Python creator
and reviser execute in the host sandbox only when the recorded brief says execution
is desired, matching the source's optional execution. This represents the operation
and transfers observed evidence through the existing contribution. A real sandbox
computation was not performed by this semantic review.
