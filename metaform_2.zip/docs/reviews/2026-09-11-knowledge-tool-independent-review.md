# Independent Knowledge Tool review

The bounded review found and reproduced missing new-context scheduling, duplicate Type/Element composite questions, and several older-recipe continuation defects. Independent reruns verify the repairs below. No remaining defect was found in these reviewed cases; this is not a claim that the entire release audit is complete.

| Case | Initial observation | Repaired observation |
| --- | --- | --- |
| First property on existing records | Six generic answers remained active; new rendering required composite questions, but no work was scheduled. | Two composite assignments complete, producing eight current answers; all six original generic attachments remain unchanged. |
| Type and directly bound artifact share a composite | With one property-bearing component, full rendering emitted the same composite question for Type `code` and the artifact Element. | Direct binding identifies the artifact alias; no duplicate question is emitted. |
| Prior root-only Enumerator recipe | Twelve old answers were invalidated; the replacement assignment contained no questions. | The saved instruction renders the current generic-plus-whole-composite pair. |
| Explicit regeneration of prior recipe | Twelve old answers remained active alongside nine new answers. | The full 58-answer historical fixture regenerates to nine active current answers, with no old slots active. |
| Automatic regeneration of a full prior recipe | At least seven pending assignments repeated current questions; the obsolete probe was stopped after retaining that evidence. | One assignment contains nine unique current questions. Submission completes with nine active answers and the entire original 58-answer generation unchanged. |

The exact intended selected-artifact pair is preserved: one generic program-code question and one whole repository composite comprising the Bash installer and C++23 game engine. The same structure works with the arbitrary instruction “the top 6 creative thinking with foresight imperatives.” Eight property origins still produce two selected questions, with every origin in the composite; there are no property subsets or standalone join questions.

A soft Bash property remains local to the installer and does not enter the root composite. An exterior customer receiving installer functionality, followed by an internal receiver of that customer, does not acquire the installer or engine property context. Generic Type answers use their definition dependencies; composite answers retain their actual component, relation and property-origin dependencies. The earlier real deletion integration verified that an unaffected generic answer remains unchanged while the altered composite is rerendered from its saved instruction.

Historical probes use the actual prior renderer from `HEAD:src/metaform/enumerator.py` to construct its stored question/slot contract, then submit explicitly labelled fixture answers through the Engine. They establish serialization, mapping, scheduling and publication behavior, not model-produced answer quality. The historical generation was compared before and after current publication and remained equal.

A separate final scope check pins the historical recipe's selector to the artifact: its 12 old answers rerender into one assignment with exactly the two intended current questions. Explicit regeneration leaves two active current answers and zero old active slots. Whole-model historical scope instead produces the nine current questions described above.

The focused Knowledge Tool and deletion suite passed **30 tests, with 11 service cases deselected, in 31.09 seconds**. The final historical single-assignment correction landed afterward and was verified separately through the retained full 58-answer probe and completion check. Service-wide and release integration checks remain with their owners.

The accompanying JSON retains the initial results, duplicate-dispatch evidence, repaired totals, completion observations, exact probe source, and hashes of the reviewed runtime sources. All runtime probes used new temporary projects and explicit legacy JSON storage; no existing project data was changed. This review lane made no edits to the semantic implementation.
