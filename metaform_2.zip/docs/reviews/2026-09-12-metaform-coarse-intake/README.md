# Metaform coarse intake of Metaform itself, 2026-09-12

One Codex execution of `specifications/intake.md` (Digital Archeology, with
step 11 and the subtypes list) against a clean copy of the committed tree at
`20350da`, 954 tracked files, through `intake.drive` with the `codex`
harness. Elapsed 367 s. Three `intake.put` contributions and an empty final
answer; no annotations, no diagnostics, no retries. `workbench.png` is the
explorer on the Defining Element.

## The shape

Nine notable elements, twelve joins, six annealed subtypes. Defining Element
`code.assembler.context`, "context assembler code": Metaform as the thing that
assembles retained understanding into context from which a reasoning task can
proceed.

| Element | name_length | EF |
| --- | ---: | --- |
| `code.assembler.context` (DE) | 2 | Assembles retained understanding into context from which a reasoning task can proceed. |
| `code.analyzer.functional` | 2 | A functional analyzer derives an account of an artifact through the functions of its elements and the purposes of their relationships. |
| `code.resolver.semantic` | 2 | A semantic resolver follows recorded meanings and relationships to determine the context applicable to an addressed subject. |
| `code.store.graph` | 2 | A graph store retains addressable entities and their relationships for subsequent retrieval. |
| `code.dispatcher.command` | 2 | A command dispatcher routes a requested operation to its registered handler within the active command context. |
| `code.engine.workflow` | 2 | A workflow engine advances work through an authored arrangement of steps while retaining the state needed to continue. |
| `code.packager.project` | 2 | A project packager assembles project assets and supporting resources into a transferable working unit. |
| `code.viewer.graph` | 2 | A graph viewer presents entities and their relationships for interactive inspection. |
| `document.prompt` | 1 | A prompt document supplies an instruction that directs a reasoning operation. |

Joins, receiver to provider, with the relation and the type-level observation
(the OP text, which names the modules, is in `foundation.json`):

| Receiver | Provider | Relation | Observation |
| --- | --- | --- | --- |
| assembler.context | analyzer.functional | obtains | A functional analyzer produces an account of functional relationships. |
| assembler.context | store.graph | retrieves | A graph store makes retained entities and relationships retrievable. |
| assembler.context | resolver.semantic | selects | A semantic resolver determines applicable context from recorded meanings and relationships. |
| resolver.semantic | store.graph | consults | A graph store retains relationships between addressable entities. |
| assembler.context | engine.workflow | coordinates | A workflow engine advances work according to an authored arrangement of steps. |
| engine.workflow | document.prompt | issues | A prompt document conveys an instruction for a reasoning operation. |
| analyzer.functional | document.prompt | applies | A prompt document directs a reasoning operation through an instruction. |
| assembler.context | dispatcher.command | exposes | A command dispatcher routes a requested operation to a registered handler. |
| assembler.context | viewer.graph | presents | A graph viewer presents entities and relationships for inspection. |
| viewer.graph | resolver.semantic | resolves | A semantic resolver determines the meaning of an addressed subject. |
| assembler.context | packager.project | transfers | A project packager produces a transferable working unit. |
| packager.project | store.graph | collects | A graph store retains addressable records for subsequent retrieval. |

Annealed subtypes, published inactive beneath their main Type:
`code.engine.workflow.prompt`, `code.engine.workflow.tool`,
`document.prompt.analysis`, `document.prompt.generation`,
`document.prompt.specialization`, `document.prompt.intake`. The same six
addresses appear as the keys of the `combined` dictionaries on the joins that
annealed them, with a relation and an observation each.

## Observed

- The model keyed the combined-away entities by full namespace address on its
  own; the prompt says only "the combined element".
- The third contribution re-sent every join with the observation rewritten to
  describe the provider instead of the receiver; the merge keeps the last
  version of a join with the same receiver, provider and purpose.
- Ten prefix positions carry an empty EF: `code`, `document` and the eight
  single-segment positions beneath `code`.
- Not named: the chassis nonce and menu surface, knowledge layers as their own
  element (folded into the workflow engine's purpose), the semantic data
  files, tests, and the untracked `tempo/`.

## Memories recorded as a test, 2026-09-12

Three session memories were written into this intake's join dictionaries as
memory nodes through a recorded transformation (`memories-model.json`, model
`memories`, revision `45301f52…`, one transformation activity, no
diagnostics). Not yet trusted; the real memory files stay authoritative.

| Join | Memory node | Relation | Observation |
| --- | --- | --- | --- |
| assembler.context to dispatcher.command | `code.dispatcher.command.help` | presents | help shows the menu of the mode the agent is in; the orchestrator and admin menus sit behind `help orchestrate` and `help admin`. |
| assembler.context to engine.workflow | `code.engine.workflow.nonce` | issues | A workflow receives a nonce at registration; an agent nonce is eight characters hashed from it and a salt, recording the agent's assignment. |
| analyzer.functional to document.prompt | `document.prompt.intake.subtypes` | lists | Intake lists annealed subtypes as full addresses; they publish as inactive positions beneath their main Type. |

The write path used is `apply_transformation` with an `update` on the join
record; unit 7 gives memory nodes their own write surface.
