# Semantic repair evidence — 2026-09-11

This records implemented behavior in the release-quality worktree. It is not a
claim that passing runtime tests establish the quality of model-produced inference.
Defect regressions in `tests/test_semantic_repairs.py` reproduced concrete failures
before repair; separate verification checks cover established behavior. The tests exercise public module/Registry operations
where the defect concerns that boundary.

## Implemented behavior

| Backlog work | Result and retained check |
| --- | --- |
| R14/R35, S33 | Completed Native intake can publish through `intake.apply`, including from its captured worker binding. Completion retains submission annotations and publication diagnostics. Replaying the original request returns its own completed result after later work starts. Completion provides `guide.start` only when that capability is installed; installed module guide providers choose the subsequent operation. |
| S16 | `intake.read` returns binary data losslessly as base64 with size, SHA-256, MIME type, supported image dimensions, and an optional description retained as source evidence. Existing text evidence identity is preserved. Installed/portable MCP and SDK sampled worker tool replies deliver an actual image content block, with metadata separately and the original structured data preserved. Actual client callbacks verify exact PNG bytes; an actual model's image interpretation has not been demonstrated. |
| Q26 | Design-stage semantic reads remain dependencies of generated groups and their attachments. Changing a record read during design now identifies the generated attachment in transformation impact. |
| S11 | `model.compare` uses the recorded source-to-destination transformation mapping for both target resolution and attachment impact. Its public arguments expose source and mapping; explicit empty mapping remains an explicit choice. |
| S42 | Repeating clone to the same destination with changed purpose text preserves the original clone activity and purpose. Source identity and content remain unchanged. |
| S40 | Removed layer associations remain inspectable through the public read operation, with removal status, recipes, generations, and history. |
| Q17 | Enumerator naming follows the recorded root `display_name` and Type `length`. It no longer substitutes a hardcoded program-code label. The regression includes recorded root and descendant names. |
| S39 | Layer regeneration accepts the canonical `target` argument and the compatibility `region` alias. Same-model recovery without an explicit target emits only previously missing enumerator fields, preserving their identities and completed attachments. |
| S37 | Blind-spot layer `name` is independent of the full request and defaults to `Blind spots`. |
| Q21 | The supplied property distinction, including `Medium`, survives intake, correction, stored records, source/evidence/reason, and prepared context in optional `property_type`. This adds no subtype enumeration or rejection gate. |
| Q03 (known context) | Intake and Type inspection resolve recorded namespace ancestors even when the parent is not separately referenced by an actual. A stored document base remains available in the document.guide regression. Missing definitions remain diagnostics. |
| Q18 | Enumerator context includes relationships where the selected actual occurs only as a recorded participant. It preserves that participant's recorded role rather than inventing receiver/provider direction. |
| S09 (size and recovery) | Normal enumeration reports exact question/schema byte counts and question/subject counts. `enumerator.preview --summary true` counts all required property subsets without constructing the questions. Every required combination remains in normal generation. |
| S35/S36 | The foundation schema declares the already-supported expansion-opportunity shape. Artifact context remains its declared freeform contract; no unsupported shape restriction was introduced. |
| S71 | An actual Registry `knowledge.get` → `knowledge.explain` journey preserves origin, payload, and dependencies, reports applicability at the originating engine, and explains nonapplicability at an unrelated installer. This is a verification check, not a new semantic behavior. |
| Discovered schema defect | A registered schema without `$schema` no longer breaks unrelated answer annotation. Resolution uses the supported default draft without rewriting the authored schema. |
| Exact response binding | Explicit intake run/request identifiers that contradict a captured worker binding fail before answer recording. Omitted or matching identifiers retain the captured assignment behavior. An unbound answer requires an explicit run identifier instead of silently selecting whichever run owns the current mode. |

The registry worker owns read-command availability and module-driven guide
selection. These semantic repairs supply the relevant manifest flags and providers
without duplicating module-presence logic in completion instructions.

## Recorded measurements and semantic delivery

`2026-09-11-semantic-evidence.json` retains the sample identity, actual public
knowledge-read timings, role-component identities/revisions, and enumeration
measurements. The sample is the historical v1 MGM Native record adapted through
the existing `import_v1` path. It has not been re-intaken or semantically corrected;
its migration diagnostics are reported, not hidden.

For the 47-Type, 58-Element, 101-join sample, public `knowledge.get` took
approximately 0.09–0.12 seconds in an isolated portable installation. The existing
property-explanation cache already recorded reuse. This measurement does not
justify another cache for S41.

Actual v2 preparation delivers the structural-semantics, namespace-authoring, and
aliases components, with their identities and revisions. Concise r1/r2 wording is
present exactly. Historical r3–r5 are not delivered as a duplicate verbatim bundle:
their namespace reuse/length, universal Type description, and Encounter/Function
content is expressed in the current components. The comparison and the exact
supported Medium correction do not establish semantic completeness for every
model-produced intake.

Public summary enumeration of this sample reports **1,198,625 questions**, 408
contexts, 206 subjects, and a maximum of 15 contextual properties, in 12.010 seconds.
No question text was constructed by that summary call. This exposes a substantial
one-assignment capacity problem; it does not demonstrate practical full generation
or completion of that assignment.

## Remaining decisions and limits

- Q03: authoritative universal Description/EF definitions for missing bases or
  intermediate Types must not be invented. The known-parent resolution repair
  does not fill those missing authored definitions.
- X04/S09: changing the specified one-fresh-assignment protocol, splitting work,
  or revising partial-answer semantics remains a decision. No combinations were
  capped. Size reporting and existing missing-field recovery are implemented.
- The outside role receives complete Native functional understanding and all
  record-level evidence. The runtime-generated intake activity supplies identity,
  outputs, and evidence references rather than replaying captured assignment,
  submission, context-read, raw file, and role-prompt bodies into that worker frame.
  All original capture remains in durable history. A live self-intake exposed
  6,424,548 characters of duplicated audit-containing context; the repaired input
  preserves every nonactivity field and 53 source references in 324,971 characters.
  No size cap or truncation of the functional account was introduced.
- MCP transports provide image content to image-capable host callbacks. Actual model
  visual inference and the CLI harness's image handling remain unverified.

## Verification

An integrated semantic run passed **134 tests** across the focused repair,
Foundation intake/models, semantic read, role composition, knowledge layers,
transformation, reinference, blind-spot, namespace, enumerator, and intake
continuation suites. After completion/module-removal, summary, and exact binding
changes, the focused repair, intake continuation, Foundation intake, and enumerator
suites passed **39 tests in 12.15 seconds**. The additional public
`knowledge.explain` verification passed independently.

The four new installed/portable MCP and sampled worker image tests failed on the
text-only transport before its repair. They then passed alongside the four existing
stdio discovery/sampling checks: **8 tests in 10.68 seconds**. Those are transport
tests with fixture host callbacks, not claims about generated image analysis.

Independent review of the lifecycle lane reproduced directory-symlink target
deletion during workfolder apply, missing empty-directory tracking, and stale
marker/nonce project initialization. These findings were sent to the lifecycle
owner with concrete reproducers. The repaired symlink, empty-directory, and marker
paths passed nine independently rerun cases. Stale nonce handling and remaining
lifecycle verification are tracked by that owner.

## Actual-model correction and measured store repair

The actual Native/outside run and its two-record correction are documented in
the independent Native and outside semantic reviews. The reviewed public
transformation preserved the original Native revision and created a separate
variant, retained reasons/evidence, and scheduled one unexecuted outside assignment.
An added handoff descriptor now distinguishes full Native meaning from abbreviated
intake audit records and identifies their retained source. Completed/stored intake
handoffs refresh the executable presentation without changing their request or
saved history. The focused descriptor and stored-handoff regressions passed.

The initial public correction also exposed performance not present in the earlier
MGM read fixture: the actual store retained 65,980,780 characters across 34 current
records and 140,341,384 characters across 43 historical observations. A single
prompt-description write on an exact SQLite backup took 24.812 seconds under
cProfile; 20.327 seconds were duplicate whole-owner copies in `_MemoryGraph`
construction and export. The service already owns its freshly decoded transaction
export. It now transfers that ownership and writes the owned result, preserving
default copy semantics elsewhere. Single-record memory reads also copy only their
selected record instead of exporting the entire graph.

The identical profiled write takes 4.050 seconds after repair. All stored Elements,
joins, participants and observation contents match the earlier operation; only
the new observation's time differs. Original live data was untouched by these
write comparisons. Thirty-five storage, public-contract and model-transformation
tests passed, including rollback and detached-return checks. Fresh actual public
transform replay returned the same variant and pending assignment in 7.663 seconds
and preserved the Native source. The earlier replay used cProfile, so its 10.955
seconds is not a controlled speed comparison. Evidence is retained under
`2026-09-11-live-foundation/native-correction-*performance*` and `*profile*`.
