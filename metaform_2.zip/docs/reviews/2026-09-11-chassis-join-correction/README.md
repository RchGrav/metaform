# Packaged chassis join correction

The shipped chassis account contained 24 `hard dependency` joins and ten Python property joins with the old authored `property_type: Medium` field. The current foundation schema correctly rejected the obsolete role values. The focused chassis discovery test reproduced that failure before correction.

The repaired authored account records the 24 capability requirements as `role: requirement`, `classification: functionality`, `is_soft: false`. Each stated Operative Purpose requires the named provider's capability. Selecting when to request that capability does not make the provider optional within that recorded purpose. The ten Python implementation properties use `role: property`, `classification: language`, `is_soft: false`, retaining their original component origins and transitive meaning. No supportive joins were present in this account.

This correction changes packaged documentation/data only. It does not add a role converter, alter an importer, rewrite a stored project, or change any MGM dataset. The obsolete authored property field was removed. Two current reference sentences now call the records Elements. The account revision was refreshed.

Every Type definition, including the accepted program-code Name and Description, is unchanged. All join identities, endpoints, provider Types, purposes and signals are unchanged. Element/Type evidence, bindings, narrowings, refinements and the functional understanding are unchanged. [Before](before.json), [corrected account](candidate.json), and [per-join reasons and validation](journal.json) are retained.

Direct foundation-schema validation now reports only the two previously documented unresolved document/exterior base EF fields. Those missing authoritative definitions remain explicit; this repair did not invent them. All **five module API tests passed in 2.31 seconds**, including read-only chassis discovery, preservation of selected-project knowledge, and live module-capability discovery.
