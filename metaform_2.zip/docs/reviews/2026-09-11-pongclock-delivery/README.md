# PongClock delivery verification

The wheel and byte-identical standalone archive at SHA256 `334d1251ea559c83d2582cdd80df63d28f9bd85ad249835cc80b8f77ffec44d0` passed all three delivered verification processes on Python 3.13.5. The driver used the fresh installed environment with `-I`, outside the source checkout; standalone processes used `-S` and the bundled runtime. All 161 package source/resource files still matched the archive after these checks.

- [Distribution journey](distribution.log): installed/direct-wheel CLI and MCP, offline viewer/export, and shared-service nested portable continuation.
- [11 shutdown cases](shutdown.log): installed and standalone open-input interruption, EOF, full unread stdout interruption, large Unicode response and ping, interrupted synchronous handler cleanup, plus installed automatic-build cancellation with child termination and build-lock reuse.
- [Six global lifecycle/lock cases](lifecycle.log): projectless startup/restart, viewer HTTP stop/restart acknowledgment without waiting on its own handler, draining an already accepted operation, and keeping existing project reads responsive while another storage home waits on its lock. The [retained runner](check_installed_lifecycle.py) uses installed imports and a different temporary runtime for each independent case.

All runtime directories were explicitly isolated. This lane did not operate on the default/user server. These checks establish delivered machinery; the real Native/Knowledge Tool inferences and their semantic reviews are separate evidence.

[Machine-readable summary](summary.json) · [Build/install provenance](artifact.json)

## Final advice display correction

The final artifact is
`d103e1b859563383d8dcd21221623d9f21baed2c85ae339e988596ce725653b7`.
Its only source/resource difference from the fully checked `334d1251` package
is `static/inspector.js`: generated layer instructions are shown before
property-origin details. The semantic browser suite passed after that change.
The final installed live browser also verifies that generated instructions
appear first and that the displayed root advice equals the stored response.
All 161 packaged source/resource files match current source; the standalone
archive is byte-identical to the wheel. This UI-only delta was not a second run
of the entire earlier distribution/shutdown matrix.

[Final artifact](final-artifact.json) · [Final browser suite](final-browser.log) ·
[Live restart](final-live-restart.json) ·
[Live knowledge retrieval](../2026-09-11-pongclock-intake/retry-3/knowledge/live-browser-retrieval.json)
