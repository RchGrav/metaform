"""Installed-artifact lifecycle probes, copied from focused source regressions.
No source runtime import; each case receives its own temporary runtime/home.
"""
import hashlib,json,os,sys,tempfile,time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from metaform import service
from metaform.util import write_json
import metaform
assert 'site-packages' in metaform.__file__, metaform.__file__
def fail(message): raise AssertionError(message)
pytest=SimpleNamespace(fail=fail)
def wait_file(path,timeout=3):
    deadline=time.monotonic()+timeout
    while not path.exists():
        assert time.monotonic()<deadline,str(path)
        time.sleep(.01)
def test_global_start_status_and_restart_need_no_project_or_storage_home(tmp_path):
    endpoint = service.start_service()
    assert endpoint['pid'] != os.getpid()
    assert endpoint['runtime_dir'] == os.environ['METAFORM_RUNTIME_DIR']
    assert service.service_status()['instance_id'] == endpoint['instance_id']
    restarted = service.restart_service()
    assert restarted['instance_id'] != endpoint['instance_id']
    assert restarted['port'] == endpoint['port']
    assert not (tmp_path / '.metaform').exists()
    assert service.stop_service()['stopped']

def test_public_viewer_lifecycle_returns_before_its_own_handler_is_drained(tmp_path, command):
    import urllib.request
    from metaform.app import App
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'auto_build': False})
    app = App(tmp_path / 'project', home)
    selected = service.open_viewer(app.project, home)
    started = time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(selected['url'] + '/api/semantic/' + command, data=b'{}', headers={'Content-Type': 'application/json'}), timeout=3) as response:
        result = json.load(response)
    assert time.monotonic() - started < 3
    assert result['restarting' if command == 'service.restart' else 'stopping'] is True
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        status = service.service_status()
        if command == 'service.restart':
            if status['ready'] and status['instance_id'] != selected['instance_id']:
                assert status['port'] == selected['port']
                return
        elif not service._owned(service.runtime_directory()):
            assert not status['ready']
            assert not service._owned(home / 'service')
            return
        time.sleep(0.02)
    pytest.fail('The acknowledged lifecycle action did not finish')

def test_explicit_stop_drains_an_already_running_viewer_command(tmp_path):
    import concurrent.futures
    import urllib.request
    from metaform.app import App
    home = tmp_path / 'home'
    write_json(home / 'config.json', {'auto_build': False})
    app = App(tmp_path / 'project', home)
    module = app.root / 'modules/slow-view'
    write_json(module / 'module.json', {'id': 'slow-view', 'name': 'Slow fixture', 'commands': [{'name': 'wait', 'handler': 'handler.py:wait', 'inputSchema': {'type': 'object', 'properties': {'entered': {'type': 'string'}, 'release': {'type': 'string'}}}}]})
    (module / 'handler.py').write_text('import time\nfrom pathlib import Path\ndef wait(app,args,context):\n    Path(args["entered"]).touch()\n    while not Path(args["release"]).exists():time.sleep(.01)\n    return {"finished":True}\n')
    selected = service.open_viewer(app.project, home)
    (entered, release) = (tmp_path / 'entered', tmp_path / 'release')

    def request():
        with urllib.request.urlopen(urllib.request.Request(selected['url'] + '/api/semantic/slow-view.wait', data=json.dumps({'entered': str(entered), 'release': str(release)}).encode(), headers={'Content-Type': 'application/json'}), timeout=5) as response:
            return json.load(response)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        pending = executor.submit(request)
        try:
            wait_file(entered, timeout=3)
            stopping = executor.submit(service.stop_service)
            time.sleep(0.15)
            assert not stopping.done()
        finally:
            release.touch()
        assert pending.result(timeout=3) == {'finished': True}
        assert stopping.result(timeout=3)['stopped']

def test_slow_new_home_does_not_block_existing_reads_and_same_home_opens_serialize(tmp_path):
    import concurrent.futures
    import urllib.request
    from filelock import FileLock
    from metaform.app import App
    home = tmp_path / 'ready-home'
    write_json(home / 'config.json', {'auto_build': False})
    selected = App(tmp_path / 'ready-project', home)
    opened = service.open_viewer(selected.project, home)
    origin = f"http://127.0.0.1:{opened['port']}"
    waiting_home = tmp_path / 'waiting-home'
    write_json(waiting_home / 'config.json', {'auto_build': False})
    directory = waiting_home / 'service'
    directory.mkdir()
    projects = [tmp_path / 'new-a', tmp_path / 'new-b']
    for project in projects:
        project.mkdir()

    def request(url, body=None, timeout=5):
        call = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None, headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(call, timeout=timeout) as response:
            return json.load(response)
    held = FileLock(directory / 'instance.lock')
    held.acquire()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            pending = [executor.submit(request, origin + '/api/projects/open', {'path': str(project), 'home': str(waiting_home)}) for project in projects]
            try:
                for project in projects:
                    wait_file(project / '.metaform/config.json', timeout=3)
                assert all((not future.done() for future in pending))
                catalog = request(origin + '/api/projects', timeout=1)
                assert any((entry['project_id'] == selected.project_id for entry in catalog))
                assert request(opened['url'] + '/api/semantic/graph.get', {'id': 'absent'}, timeout=1)['record'] is None
            finally:
                held.release()
            attached = [future.result(timeout=5) for future in pending]
    finally:
        held.release()
    assert len({entry['project_id'] for entry in attached}) == 2
    records = service.RemoteKnowledge(waiting_home, None).call('project.list', {})
    assert {record['path'] for record in records} == {str(project) for project in projects}
    assert service.ensure_service(waiting_home)['instance_id'] == opened['instance_id']
archive=Path(sys.argv[1]).resolve()
print(json.dumps({'python':sys.version,'executable':sys.executable,'import_origin':metaform.__file__,'artifact_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}),flush=True)
cases=[('projectless-start-restart',test_global_start_status_and_restart_need_no_project_or_storage_home,()),
       *[(command,test_public_viewer_lifecycle_returns_before_its_own_handler_is_drained,(command,)) for command in ['service.stop','viewer.stop','service.restart']],
       ('drain-accepted-viewer-command',test_explicit_stop_drains_an_already_running_viewer_command,()),
       ('slow-home-keeps-existing-project-responsive',test_slow_new_home_does_not_block_existing_reads_and_same_home_opens_serialize,())]
for label,check,arguments in cases:
    with tempfile.TemporaryDirectory(prefix='metaform-delivered-lifecycle-') as temporary,patch.dict(os.environ):
        root=Path(temporary)
        for name in list(os.environ):
            if name.startswith('METAFORM_'):del os.environ[name]
        os.environ.update(METAFORM_RUNTIME_DIR=str(root/'runtime'),METAFORM_HOME=str(root/'unrelated-home'),PYTHONPATH='')
        started=time.monotonic()
        try:
            check(root,*arguments)
            print(json.dumps({'case':label,'status':'passed','elapsed_seconds':round(time.monotonic()-started,3),'runtime':os.environ['METAFORM_RUNTIME_DIR']}),flush=True)
        finally:
            service.stop_service()
print('All 6 installed global lifecycle/lock probes passed.',flush=True)
