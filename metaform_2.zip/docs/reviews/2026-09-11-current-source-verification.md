# Current source verification — 2026-09-11

The complete source run produced **941 passed, 6 failed in 352.18 seconds**. All six failures were then corrected and rechecked: **10 passed in 2.93 seconds**, covering the six cases and the entire module API suite. No unresolved failure remains in this verification scope. This is not a claim that a second complete suite ran.

Three failures were old per-project viewer/service test assumptions after the global lifecycle change. Corrected tests verify the exact global instance/PID, router usability, and absence of project resolution or initialization for service inspection. Two failures were obsolete provenance expectations: authored rule selections now correctly differ from the maintained intake rules. The tests preserve and verify authored rule choices rather than suppressing their provenance.

The remaining failure exposed an actual bundled-resource mismatch: chassis joins retained former role vocabulary after the supplied contract changed. The semantic owner reviewed and corrected the authored chassis classifications and softness. The module API suite now passes while retaining the two explicitly unresolved document/exterior EF annotations. No generated user model was converted or edited for this correction.

All 164 source/build files (source Python, data, static files, templates, packaging files, README and pyproject) had identical hashes before and after the full suite. After that run, the sole packaged-source change was `src/metaform/data/chassis.json`; the bounded recheck above verifies the changed contract. Test expectation corrections are outside that package fingerprint. The root's additional role/provenance batch also passed 28 tests in 4.53 seconds.

Evidence: [full output](2026-09-11-current-source-tests.log), [corrected rechecks](2026-09-11-current-source-corrected-rechecks.log), [role/provenance batch](2026-09-11-current-role-provenance-tests.log), [before/after fingerprints](2026-09-11-current-source-fingerprints.json), [machine-readable summary](2026-09-11-current-source-verification.json), and [chassis correction journal](2026-09-11-chassis-join-correction/).

This lane performed source verification only. Browser and rebuilt-artifact checks are separate evidence; no production/user service lifecycle operation was performed here.
