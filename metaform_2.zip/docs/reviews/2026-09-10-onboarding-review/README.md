# Onboarding review agent outputs, 2026-09-10

Structured outputs of the discovery workflow (10 subsystem readers, 20 verifiers, plus any late arrivals).
Raw JSON for every agent is in `raw/agent-results.json`; full tool transcripts remain in the session directory
`~/.claude/projects/-home-rich-metaform/a64be75f-8f91-4346-8229-ff43750d41f1/subagents/workflows/wf_e8542f44-c12/`.
[merged-issues.md](merged-issues.md) is the hand-merged inventory of every distinct issue with severity, repair and status; [issues.md](issues.md) is the raw list it was built from. The repairs and open defects distilled from these are in [the repair specification](../../repair-spec.md).

| Subsystem | Reader | Runnability verifier | No-overclaim verifier |
| --- | --- | --- | --- |
| [docs-vision](docs-vision.md) | yes | yes | yes |
| [examples-evidence](examples-evidence.md) | yes | yes | yes |
| [intake-foundation](intake-foundation.md) | yes | yes | yes |
| [knowledge-layers](knowledge-layers.md) | yes | yes | yes |
| [mcp-onboarding-install](mcp-onboarding-install.md) | yes | yes | yes |
| [modules-extensibility](modules-extensibility.md) | yes | yes | yes |
| [portable-packaging-service](portable-packaging-service.md) | yes | yes | yes |
| [semantic-reads-transform](semantic-reads-transform.md) | yes | yes | yes |
| [workbench-viewer](workbench-viewer.md) | yes | yes | yes |
| [workflow-engine](workflow-engine.md) | yes | yes | yes |
| [audit:readme-3-readers](audit-readme-3-readers.json) | | | |
| [probe:first-value](probe-first-value.json) | | | |
