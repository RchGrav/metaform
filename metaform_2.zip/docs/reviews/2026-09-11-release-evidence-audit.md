# Exhaustive repair evidence audit — 2026-09-11

This independently reconciles all **84 established entries** (R01–R50, 28 additional S entries, six Q entries) in [the backlog](../repair-backlog.md). It records source evidence and residual demonstration requirements. The final artifact `2432498b…` passed the 44-call customization/continuation journey and the complete Python 3.11/3.13 artifact matrix; [distribution evidence](../release-distribution-evidence.md) records the exact checks and host limits. The current ledger gives each entry one disposition; dated supplements retain the earlier observations and exact verification history.

The original 76 supplemental rows and 28 former questions remain mapped in the backlog. Ten X proposals are separate. No additional gate, blanket schema rejection, arbitrary enumeration cap, or historical-access removal follows from this audit.

## Evidence key

- **CLI:** `tests/test_cli_reference.py`, `tests/test_onboarding.py`, `tests/test_installation.py`, and CLI source evidence in [execution status](../release-quality-status.md).
- **LIFE:** `tests/test_release_lifecycle.py`, execution/continuation/history tests, and [workflow reference](../workflows.md). Independent reviewers reproduced and rechecked data-loss and binding issues.
- **SHUT:** [shutdown/service evidence](2026-09-11-shutdown-service-evidence.md), transport tests and open-stdin subprocess probes.
- **SEM:** [semantic repair report](2026-09-11-semantic-repairs.md), [raw measurements](2026-09-11-semantic-evidence.json), and `tests/test_semantic_repairs.py`. Functional schema checks remain distinct from semantic evaluation.
- **PKG:** [packaging evidence](../release-packaging-evidence.md), `tests/test_release_packaging.py`, and independent source-export probes below.
- **API:** [public module/chassis evidence](../release-module-api-evidence.md) and `tests/test_module_api.py`.
- **UI:** four declared browser suites, `tests/test_review_viewer.py`, [workbench reference](../workbench-navigation.md). Latest additional continuation browser evidence: `/tmp/metaform-semantic-browser-uaC4Qh/pending-continuation.png` (local generated evidence, not committed screenshot).
- **DEMO:** [example inventory](../../examples/README.md), [realignment recipes](../../examples/realignment/README.md), historical sample loader. Executed demo `/tmp/metaform-demo-results-xkotmjys`; capture `/tmp/metaform-demo-capture-MjdqSF`; loaded sample `/tmp/metaform-mgm-sample-0fff31pi`.
- **DOC:** [authority index](../README.md), [CLI/harness guide](../cli-and-harnesses.md), [knowledge/revision guide](../knowledge-and-revisions.md), current README and historical wrappers.
- **LIVE:** all seven actual Codex conversion outputs and independent semantic reviews retained under `workflow-conversion/*/semantic-review.md`; specific corrections and full procedure execution remain distinct. Actual Native intake, outside retry and source-runtime documentation handoff are recorded below.
- **AUDIT:** this review, [test-purpose/flake audit](2026-09-11-test-purpose-audit.md) and [CI applicability review](2026-09-11-ci-review.md).
- **ALL:** applicable evidence above; no aggregate test count substitutes for the required journey.

## Independent packaging and interface probes

An isolated source export was run using the actual archive with `python -S`, empty `PATH`, empty `PYTHONPATH`, and no inherited `METAFORM_*` selection. First `--help`, `system reference`, `system settings`, `skill`, and `guide chassis` returned successfully without creating a sibling project. Then an intentionally missing dependency caused the actual module command to report the precise import error. Help/reference still worked. After that working copy existed, all reference calls preserved a complete SHA-256 file-content snapshot, including its state database.

Export diagnostics named the owning module, missing import, source file, and line. ModuleAPI calls respected disabled `workflow.start`; separately copied config/project descriptors could not mutate runtime settings or identity, and two module namespaces retained independent values. A separate public sharing test executes the module's workflow before and after export/import. These establish concrete boundaries, not Python sandboxing.

The reviewer originally reproduced both first-reference materialization and chassis-reference automatic build. Owners repaired these shared routes using module-owned reference/read metadata. This audit also caught a falsely assumed S71 public-read proof: the older explain test called `read_snapshot` directly; the semantic owner added a passing Registry get→explain check with origin, payload, dependencies and unrelated-target behavior.

## Current 84-entry ledger

This is the current disposition table. **Verified** means the stated implementation/reference behavior has direct checks within the scope described; it does not imply every possible workflow or model answer was tested. **Representative** identifies working mechanisms and concrete demonstrations with broader source-specific execution still unproven. **Host-limited** separates verified transport behavior from unavailable client/application evidence. The two **Open** entries name the enumeration-scope investigation and missing authoritative definitions explicitly.

Source integration is [884 passing Python checks and four browser suites](2026-09-11-final-integration-verification.md), followed by the verified minimal R14 deletion described below. Artifact claims in this table refer to the corrected final SHA-256 `2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027`: the complete two-interpreter matrix, 44-call journey and installed sync-absent UI check passed. [Distribution evidence](../release-distribution-evidence.md) records the exact matrix and source fingerprint. Earlier artifacts remain separately identified below.

| ID | Current disposition | Evidence | Current result and boundary |
| --- | --- | --- | --- |
| R01 | Verified | CLI | Module/command help, typed active-mode commands and readable grouping pass source/reference checks; malformed modules retain usable built-in help with precise diagnostics. |
| R02 | Representative | CLI, DOC | Owning manifests contain command/argument/default/result/lifecycle/settings/example reference. Public artifact journeys execute representative delivered examples; this is not a claim that every possible argument combination was exercised. |
| R03 | Verified | CLI | Fresh no-argument entry is read-only and explains beginning work; existing-project entry reads current guide state and its next operation. Source onboarding and artifact CLI paths are verified. |
| R04 | Verified | CLI, PKG | Reference/installer pre-App paths checked. Independent archive reference fingerprints unchanged before/after materialization, including settings/skill/chassis. |
| R05 | Verified | CLI, UI | Human/JSON modes and readable URL/actions implemented. UI counts actuals separately from Types and infrastructure; active continuation remains displayed after answer. |
| R06 | Verified | CLI, DOC | Module-owned reference and the synchronized CLI/harness guide identify purpose, ownership, contexts and settings. Delivered customization follows the artifact’s own instructions. |
| R07 | Verified | CLI, API | Aliases/bootstrap handlers module-owned; disabled ModuleAPI workflow.start independently denied. Removed module no longer supplies guide action. |
| R08 | Verified | CLI | Actual initialization creates missing scope files; reference initialization stays read-only. Scope persistence covered by settings regressions. |
| R09 | Verified | CLI | Module settings declarations provide typed defaults/descriptions/scope. Reference composition and nested source fields checked. |
| R10 | Verified | CLI, DOC | Effective files/home/project precedence and leaf sources exposed, with active vs pending backend values; portable archive reference checked. |
| R11 | Verified | CLI | Scope-specific recursive writes preserve unrelated settings and project-over-home precedence; original leakage reproduced before fix. |
| R12 | Verified | CLI | Settings refresh on write; backend migration remains explicit and pending startup values are reported. Do not claim all graph settings hot-apply. |
| R13 | Verified | CLI | Stable concierge core plus live module summaries; detail requested through reference. Installed skill stays core only. |
| R14 | Verified | CLI, LIFE, SEM | Module guide providers supply operative continuation; workers receive exact saved assignments. Unconditional central viewer contribution/sync/intake guidance is removed, with sync-absent API/reference/browser proof. Seven converted procedures have independent semantic reviews. |
| R15 | Verified | CLI, SEM | Guide/intake completion respects installed capabilities; removed enumerator/analysis/guide regressions covered. |
| R16 | Host-limited | SHUT, CLI | Concise MCP orientation and dynamic tools/guidance refresh pass installed/portable transport tests. Actual external host instruction application remains unverified where the client is unavailable. |
| R17 | Host-limited | CLI, DOC | Reference distinguishes printing/exporting skills, installation, harness registration and starting work. Actual Codex executes retained live assignments; VS Code/Cursor application is not established by mock registration. |
| R18 | Representative | CLI, SEM, UI | Selection/onboarding, intake publication, layer generation/default selection and incomplete/deleted layer recovery have source checks; actual Native/outside inference and browser reads succeeded. Artifact tests cover representative intake/continuation cycles, not every full human/AI onboarding permutation. |
| R19 | Verified | LIFE, DOC | The seven-entry library is integrated. Discovery/inspection expose identity, purpose, literal source, inputs, revision and working start; artifact inventory checks paired source/definition bytes and hashes. |
| R20 | Verified | DOC, LIFE | Tool/repository reference distinguishes literal prompt import from workflow conversion/application. The seven retained actual conversions and correction journals demonstrate that distinction. |
| R21 | Representative | LIFE, LIVE | All seven actual model outputs have independent source-semantic reviews and corrected definitions with retained mappings/journals. Full execution of every source-specific branch is not claimed. |
| R22 | Representative | LIFE, LIVE | Specialist roles have actual assignment contexts and response routes. The real Orchestrator documentation path executed TechArchitect/DocLibrarian and later reader; remaining corpus-specific role/tool paths have representative runtime evidence. |
| R23 | Representative | LIFE, LIVE | Execution grammar, literal templates, branches/loops/parallel dependencies, recurse inputs, user waits, authored retries/deadlines and terminal cleanup pass source and representative artifact checks. Every complete source procedure was not executed. |
| R24 | Verified | LIFE | Authored user waits persist across next/drive and route explicit answers to subsequent work in actual public artifact calls. Test answers are labeled fixtures; they are not represented as Rich’s input. |
| R25 | Representative | LIFE, LIVE | Literal source/examples/placeholders and stage-specific output contracts are retained in reviewed conversions. Literal-template integration regressions are repaired; exact historical glossary migration is preserved. |
| R26 | Representative | LIFE, PKG, LIVE | Actual source-runtime Orchestrator→TechArchitect→DocLibrarian created Blueprint/index/module files; later actual reader hashes matched their current bytes. Artifact workfolder transfer separately verifies file handoff/apply. The bounded documentation run is not full-corpus execution. |
| R27 | Representative | LIVE | Seven actual conversion outputs were reviewed against operative source meaning and corrected without retaining invented gates. Actual Native/outside semantic findings remain distinguished from functional validity and from the separately approved two-record variant. |
| R28 | Representative | LIVE | All seven actual conversions and independent semantic reports are retained. Representative structural/runtime cases and one actual documentation artifact path passed; full real execution of every branch/tool/evaluator/satisfaction path remains unproven. |
| R29 | Verified | LIVE, DOC | All seven requested source/definition pairs are bundled and registered with workflow grammar and source/definition revision reference. Artifact inventory verifies their actual archived bytes. |
| R30 | Verified | LIFE, PKG | Returned launch commands execute from actual installed/standalone worker folders, including exported/imported continuations without the original home. |
| R31 | Verified | LIFE | Completed ambient marker retired; retained output remains. Explicit completed binding remains replay-safe and is not rebound to later work. |
| R32 | Verified | LIFE, PKG | Terminal nonce and active-export references retire while historical assignments/receipts remain. Source checks cover abort/stale identities; active-work artifact export/import and cleanup preserve independent original state. |
| R33 | Verified | LIFE, SEM, SHUT | Exact explicit/bound attribution, repeated next and receipt replay pass source and actual installed/standalone continuation journeys. |
| R34 | Verified | LIFE | Fresh/retained cleanup, sibling binding protection, abort and replay pass source checks; artifact transfer preserves original source/nonce independence. The historical flake’s cause remains unknown because it did not reproduce. |
| R35 | Verified | UI, SEM, CLI | Assignments, user questions and between-step continuations persist; failed Activity rows show the actual stored cause. Real-data polling starvation is repaired by coalesced narrow status (562 bytes/0.286 seconds measured); actual Native/outside UI and failure browser checks pass. |
| R36 | Verified | LIFE | Git-ignored user content is inside the common artifact boundary independently of knowledge serialization. Source Git/plain-copy cases and actual exported workfolder transfer verify it. |
| R37 | Verified | LIFE | Baseline/diff/apply share the artifact boundary. Reproduced symlink/empty-directory defects are repaired; the artifact journey verifies their transfer and application. |
| R38 | Verified | LIFE | Marker exclusions and exact identity cleanup prevent source/patch contamination; sibling marker retained. |
| R39 | Verified | LIFE | Git tracking is selected by availability independently of knowledge serialization. Artifact transfer starts with Git/JSON knowledge and resumes through the dependency-free file tracker. |
| R40 | Verified | LIFE | Actual source-to-workfolder-to-exported-continuation-to-apply checks preserve ignored/binary content, additions/deletions, renames, symlinks, empty directories and directory modes. |
| R41 | Verified | SHUT | Installed and standalone open-stdin/full-pipe interruption, EOF, complete large Unicode responses and synchronous-handler finalization pass on Linux/Python 3.11 and 3.13. Other host signal behavior is not claimed. |
| R42 | Verified | SHUT, LIFE | Service idle release/restart, active-request drain, abort, resumable interruption, worker/descendant cleanup and sibling isolation have source and artifact evidence. Unsupported host process behavior remains unclaimed. |
| R43 | Verified | PKG, SHUT, CLI | Fresh installed/direct-wheel/dependency-free standalone CLI/MCP, viewer/export, intake/revision, continuation, broken-module reference, shutdown/build cancellation and authored policies have an explicit two-interpreter artifact matrix. |
| R44 | Verified | API, SEM | The independent on-demand chassis functional account is implemented, reviewed and bundled. Missing canonical universal base definitions remain the explicit Q03 limit rather than invented semantics. |
| R45 | Verified | API | The separate account includes live module/workflow/interface reference. Archive-first and existing-copy reference checks preserve project contents and avoid automatic builds. |
| R46 | Verified | API | Public ModuleAPI lifecycle/calls/state/project/config implemented; copied values and disabled calls independently checked. External Python is not a sandbox claim. |
| R47 | Verified | API, LIVE | The delivered chassis example creates a meaningful custom module/workflow; actual begin/answer/replay succeeds, export/import preserves independent state, and removal affects only the copied module. |
| R48 | Verified | ALL | Frozen integration passed 884 Python checks and all four browser suites. The subsequent three-file guidance deletion has 35 focused checks plus a repeated actual absent-module browser/API check; final artifact matrix is separately hash-bound. Representative evidence does not assert universal semantic correctness. |
| R49 | Verified | AUDIT | The completed test-purpose/CI audits identify masking mechanisms and retain useful boundary checks. Frozen-suite hashes/results and the exact later UI deletion delta are retained; historical flake nonreproduction is not assigned an invented cause. |
| R50 | Verified | DOC, AUDIT | Authority index, current guides, examples and historical labels are synchronized. Exact source/test/artifact provenance and remaining limits are recorded separately from historical observations. |
| S08 | Verified | CLI, UI | Registered read-only capability permits browsing during exclusive layer generation; Foundation browser journey verifies real reads alongside pending assignment. |
| S09 | Open investigation | SEM | The current algorithm yields 1,198,625 slots on the archived MGM sample; this is not a validated required workload. The [count audit](2026-09-11-enumerator-count-audit.md) traces 1,048,576 slots to 32 contexts receiving all 15 visible property joins. Actual applicability differs, and [the sample contains previous Latent assessment](2026-09-11-mgm-provenance-audit.md). Resolve property scope/provenance before deciding whether X04 splitting is needed. |
| S10 | Verified | LIFE | Recursion carries root values plus overrides and reports unresolved inputs; blanket running-parent prohibition not added. |
| S11 | Verified | SEM, DOC | Recorded transformation mapping used for impact; CLI source/mapping available; omitted vs explicit empty mapping documented. |
| S12 | Verified | LIFE | Archive baseline modes normalized; unchanged file does not create false first-checkpoint payload. |
| S13 | Verified | PKG, CLI | auto_build setting controls changed-source builds. Independent chassis reference auto-build defect reproduced and corrected; source tests verify no build after reference. |
| S14 | Verified | DEMO | run_demo/capture/serve/grounded_trial use explicit summary and temporary outputs; actual illustrative demo/capture ran without rewriting tracked evidence. |
| S15 | Verified | DEMO | The historical package.sample loader and exact Native/Latent data are bundled; actual standalone calls load it without a checkout. Existing-project preservation and unrelated-state isolation pass focused checks. |
| S16 | Host-limited | SEM | Binary bytes/MIME/dimensions/description retained; installed/portable MCP and Native sampling image content blocks now pass four transport cases. Real image interpretation is separate unproven behavior. |
| S21 | Verified | CLI | Installer preserves preexisting launcher and reports preservation; avoids automatic selected-project backend mutation. |
| S22 | Verified | UI | Direct History layout-expand then click regression added and passed in real browser; prior checkbox refresh could mask coordinate bug. |
| S24 | Verified | DOC | Current authority index and v1 wrappers added. Exact legacy glossary restored after wrapper broke migration; adjacent dated README keeps status without changing historical hashes. |
| S25 | Verified | DEMO | Comparison baseline pinned b7aea90142067185153c974b826b6e609d9f1464; generated inputs written under output, tracked prompts unchanged. |
| S27 | Verified | CLI, PKG | system.version and build provenance expose identity. Artifact verification compares wheel/standalone hash, source fingerprint, 161 package files and all seven workflow revision pairs. |
| S28 | Verified | UI, DOC | Viewer defaults port0 and returns actual usable URL; explicit occupied port still produces actual error. No auto-open feature added. |
| S33 | Verified | SEM, CLI | Expansion discovery target optional; intake.apply publication reachable from own run. Public exact sequence retains annotation/next guide action. |
| S35 | Verified | SEM, DOC | Foundation schema declares expansion opportunities; manual model-expand documented using existing supported route. |
| S36 | Verified | SEM | Artifact context is intentionally declared freeform {}; validating that contract gives no new restrictive shape. Preserve annotation behavior and report this disposition. |
| S37 | Verified | SEM, DOC | Blindspot name is distinct optional input/default; full request is preserved separately. |
| S38 | Verified | DOC, CLI | Built-in knowledge reference and repository guide distinguish omitted selected default, null all, [] none; CLI preserves explicit JSON null. |
| S39 | Verified | SEM | target canonical/region compatibility and missing-coverage regeneration checked; existing completed slot identities preserved. |
| S40 | Verified | SEM | Public inspect retains removed layer recipe/history and explicit removed status. |
| S41 | Verified | SEM | Actual MGM public knowledge reads measured about 0.09–0.12 seconds; no cache was added. A separate actual-store write bottleneck was repaired by removing duplicate detached copies (24.812→4.050 seconds), with history equality, alias isolation and rollback verified. |
| S42 | Verified | SEM, DOC | Clone replay stable despite purpose change; original purpose/activity retained; current rebase behavior documented. |
| S44 | Verified | DOC, SEM | Concrete transform patch includes authored narrowing, map/revision, reason/evidence and Medium before/after context; actual illustrative transform recipe exercised. |
| S48 | Verified | DOC, LIVE | Historical MGM screenshots labeled; genuine new Codex self-intake Foundation now captured with model/revision and actual HTTP reads in 2026-09-11-live-foundation. No fixture substitution. |
| S50 | Verified | UI | Exact Playwright dependency/lock and temporary-output harness declared; four suites passed, plus new continuation browser check passed after fix. |
| S71 | Verified | SEM | Prior explain test bypassed public registry; new Registry get→explain test now verifies payload/origin/dependencies and unrelated-target nonapplicability. |
| Q03 | Open definition | SEM | Recorded known namespace parent resolves for document.guide. Missing universal base EF meanings remain diagnostics; no invented prefix semantics. |
| Q05 | Verified | SEM | Retained exact current component identities and r1/r2 wording plus r3–r5 semantic placement comparison; no duplicate historical rule bundle inserted. |
| Q17 | Verified | SEM | Recorded root display_name/length now govern questions; hardcoded program-code substitution removed, exact instruction retained. |
| Q18 | Verified | SEM | Participant-only join context regression preserves recorded role and branch applicability; ancestor visibility remains unchanged. |
| Q21 | Verified | SEM | Medium optional property_type survives intake, correction records and prepared context; no new closed taxonomy/gate. |
| Q26 | Verified | SEM | Design read dependency reaches generated group/attachment impact; changing design dependency identifies resulting knowledge. |

## Requirements easily lost in broad completion claims

1. **S09 is reopened as a semantic-scope/provenance investigation.** The archived calculation is reproducible, but its property selection and source account are not a validated required workload. Preserve the authored trunk-summary behavior and distinct property origins while resolving that selection. X04 splitting is conditional on a correct workload still requiring it; it is not currently a user decision needed to unblock the repair.
2. **R21–R29 have representative procedure evidence.** Seven real conversions/reviews, actual documentation file handoff, and installed/standalone authored retry/deadline/failure cases passed. Remaining source-specific tool/evaluator/satisfaction branches have not all been executed. R47’s delivered module-building/sharing journey passed on final bytes; that does not establish every possible community module.
3. **R18/R43/R48 have final-artifact evidence with explicit scope.** The corrected final matrix and 44-call transcript retain exact artifact/interpreter identity, isolated project/home, returned worker begin, answer/replay, publication, transfer and shutdown results. Actual Native/outside model inference used the source runtime; it is separately identified and is not relabeled as an installed-artifact inference run.
4. **S48 now has a genuine current Foundation image.** See [the actual capture](2026-09-11-live-foundation/README.md). The historical MGM History image remains historical evidence; fixture/browser validity and semantic correctness remain distinct.
5. **Host evidence remains explicit.** This environment does not establish actual Windows launcher execution or real VS Code/Cursor instruction/sampling application. Mock config/CLI registration checks remain useful source tests with those limits.
6. **S71 requires the public read boundary.** The older direct snapshot test was insufficient; the owner added a passing Registry-based regression. Do not erase this distinction through a test-count claim.
7. **R49 and mapped supplemental 75 have a scoped [audit](2026-09-11-test-purpose-audit.md).** Known masking mechanisms were concretely identified. The historical flake did not reproduce in the inspected run; that does not establish its cause.
8. **Historical acronym:** the repository does not authoritatively expand MGM. Docs identify its actual mesh gateway coordination subject and do not invent a proper-name expansion. This narrow wording uncertainty does not block the working historical loader or current foundation demonstration.

The [CI review](2026-09-11-ci-review.md) separately identifies the retained old failure and the later passing baseline. It is not evidence that this uncommitted release-quality tree has passed remote CI. Protected instructions, source evidence, and existing review artifacts remain preserved.


## Historical candidate artifact supplement — 2026-09-11

Candidate executable/wheel SHA-256 `bea1ca02c6dac0eef04b6e80885f1f340ee70b053f10f60322682b5e90fec549` passed **34 actual public CLI invocations**, using Python 3.13.5 with `-S`, empty `PATH`/`PYTHONPATH`, and isolated project/home state. The module was created from `guide.chassis`'s own bundled example and customized using the public API instructions that same artifact returned. The sequence covered initial reference without project creation, custom module reference, fresh worker handoff, exact returned begin, answer/completion/receipt replay, export/import, independent copied state and module removal, archive help/reference/settings/skill/chassis before and after materialization, and `package sample` without a source checkout. Reference calls preserved complete archived-state file hashes.

[Retained candidate result](2026-09-11-candidate-customization.json) records identity and outcomes. Full calls and output remain under `.test-tmp/release-verification/artifact-journey/candidate-bea1ca02/transcript.json`. Reproduce this artifact journey with `python tools/check_customization.py /path/to/metaform /path/to/fresh-evidence-directory`. The runner imports no Metaform source. This establishes the listed R04/R30/R33/R43/R46/R47/S15 boundaries for this candidate; it does not establish final delivery or all source-corpus semantic behavior. Final library changes require rebuilding and rerunning the relevant artifact checks.


## Historical second-candidate and real-data browser supplement — 2026-09-11

Candidate2 SHA-256 `8423b53541daccab40c0796c64d89408ed96245870f7c173032759ec3acf22e8` passed **44 public invocations** using the same isolated direct-executable journey. [Its result](2026-09-11-candidate2-customization.json) additionally records authored user-wait persistence across next/drive, an explicitly supplied test response, and the resulting worker prompt/completion. This proves transport/continuation mechanics with authored test data; it does not claim an actual person's response or semantic inference evaluation.

The [real new Foundation capture](2026-09-11-live-foundation/README.md) closed the S48 image gap and exposed two further R35/S08 defects: full-activity polling overwhelmed the viewer on the real pending context, and graph.neighbors remained unavailable during an active workflow. The narrow coalesced status endpoint and module-owned navigation metadata were repaired and the actual model view succeeded. These changes postdate earlier browser and artifact checks; final artifact verification must include them.

The first live outside handoff exceeded the host's 1,048,576-character limit at 6,393,107 characters. The approved correction separates runtime audit transcript copies from the complete Native-authored functional account, retains durable history and source identity/revision/description, and removes duplicate account delivery. The repaired measured request was approximately 325k characters. The actual outside retry's outcome remains separately recorded; payload reduction alone does not establish semantic success.


## Historical actual-inference and file-handoff supplement — 2026-09-11

All seven [actual conversion semantic reviews](workflow-conversion/orchestrator/semantic-review.md) now exist under the corresponding corpus folders (metaprompt, multi-agent orchestrator, dual-agent, extractor, orchestrator, Python-to-C and TaskEngine+). Specific source-faithfulness corrections are being reconciled by their owners; complete real execution of every workflow branch is not inferred from those reviews.

Actual Native self-intake published in 778.18 seconds. The corrected outside handoff completed actual Codex inference and published its report in 667.34 seconds, with the original Native foundation unchanged. The [live evidence](2026-09-11-live-foundation/live-execution-evidence.json), [semantic review](2026-09-11-native-semantic-review.md), Native browser captures and outside knowledge read distinguish generated findings/proposals from implemented corrections. No outside finding is automatically a code-change instruction.

The [actual documentation workflow](2026-09-11-document-workflow/README.md) executed the repair source runtime's shipped Orchestrator procedure through its bootstrap, runtime checkpoint, actual user-wait, plan resolution, TechArchitect and DocLibrarian. Six non-user assignments, including the separate final verification reader, used actual Codex. The planning answer is explicitly a test fixture. The architect created the Blueprint; the librarian created the index and single module guide; the subsequent reader's hashes matched all three current files and identified the required version. Original workflow source was persisted verbatim and real progress files were updated. The source procedure was explicitly stopped after this bounded handoff, with files retained. This is R26 real-file evidence from the source runtime; final artifact journeys and full CoderX/evaluator/integration/satisfaction execution remain separate.

## Final source review additions

Activity now displays a failed run's actual persisted `result.failure.message`; failed terminal runs stay out of pending work. An actual `Engine.fail` fixture first reproduced the missing report field, then passed with four pending/continuation checks (five checks total, 0.91 seconds). JavaScript syntax also passed. This change does not invent failure policy or transform an interrupted run into success.

The measured store-write repair received an independent ownership/rollback review. `copy_data=False` is used only for freshly detached SQL exports within the operation; normal `_MemoryGraph` construction and public read/export results retain copy semantics. The write path serializes that owned value directly, and model publication still copies its supplied snapshot. Sixty-two store/contract/foundation/transformation checks passed in 5.79 seconds. An additional isolated probe mutated caller input, unscoped/scoped reads and exports without changing the store; an exception injected after SQL replacement rolled back the graph, revision and receipt, and the same request ID succeeded on retry. [Actual-store backup measurements](2026-09-11-live-foundation/native-correction-store-write-comparison.json) show 24.812 → 4.050 seconds with equivalent stored elements, joins, participants and observations except the fresh observation timestamp. This removes duplicate copies; it adds no cache or history pruning.

The approved two-record Native correction was applied to a separate variant, preserving the original account. [Public replay evidence](2026-09-11-live-foundation/native-correction-runtime-after-performance.json) records the same destination and pending reinference after replay. The new reinference has not been executed; its pending state is not another completed outside review.

## Earlier verified executable journey — 6c1ae3a5

Final executable/wheel SHA-256 **`6c1ae3a51428cd234d6d46d28ff55d49a2fad02680c87aec19880606ca456e81`** passed all **44 actual public invocations** under Python 3.13.5 with `-S`, empty `PATH` and `PYTHONPATH`, and an isolated project/home. The runner imports no Metaform source and uses the final executable's own chassis example and public API instructions. [Summary](verified-candidate-6c1ae3a5/customization.json) and [complete invocation/output transcript](verified-candidate-6c1ae3a5/customization-transcript.json) are retained.

The final run verifies fresh read-only reference, creating a functional module from delivered guidance, actual worker-folder begin/answer/completion/replay, authored user waits across next/drive with an explicit test answer routed to the later worker, portable export/import with independent retained module state, removing the copied module, reference before and after archive materialization without content changes, and loading the bundled historical sample without a checkout. These establish the listed R04/R24/R30/R31/R33/R43/R46/R47/S15 boundaries on final bytes. They do not substitute for actual inference semantic review, every corpus-specific execution branch, actual unavailable host clients, or the unresolved S09 investigation and Q03 definitions.

Reproduction: `python tools/check_customization.py /path/to/metaform /path/to/fresh-evidence-directory`. This final run supersedes the two earlier candidate runs for its stated coverage; historical candidate evidence remains intact.

### Subsequent R14 correction

After that build, a final review reproduced an unconditional sync recommendation in viewer settings while the sync module was absent. The contribution field, its JavaScript assignment and the Activity paragraph were removed. Three analogous unused community guidance fields were also removed; author, repository and module-directory data remain. The [sync-absent browser check](2026-09-11-sync-absent-viewer.json) and [Activity capture](2026-09-11-sync-absent-activity.png) verify the corrected page with no JavaScript errors. Thirty-five viewer/reference checks passed in 14.43 seconds. This source change requires a subsequent artifact build; the `6c1ae3a5…` result above remains valid for its exact earlier bytes and stated journey.


## Corrected final executable journey — 2432498b

The corrected executable/wheel SHA-256 **`2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027`** passed the complete **44-call public journey** again, using Python 3.13.5 with `-S`, empty `PATH`/`PYTHONPATH`, and newly isolated project/home state. The [current summary](2026-09-11-final-customization.json) and [complete current transcript](2026-09-11-final-customization-transcript.json) name these exact bytes. All coverage listed for the earlier journey was repeated; its evidence remains separately archived.

The corrected wheel also passed an actual [sync-absent browser/API/reference check](2026-09-11-final-sync-absent-viewer.json), using its newly installed Python with `-I` and verified `site-packages` import origin. Settings contain no contribution instruction, community data retains only repository/module directories, absent sync reference reports its absence, and the [Activity page](2026-09-11-final-sync-absent-activity.png) preserves author/repository details without JavaScript errors. The complete two-interpreter artifact matrix also passed on these corrected bytes; all eight matrix processes exited zero. Its detailed results and provenance are retained in [distribution evidence](../release-distribution-evidence.md).
