import asyncio,hashlib,json,time,traceback
from pathlib import Path
from metaform.app import App
from metaform.registry import Registry
from metaform.workflow import Engine,import_workflow
from metaform.harness import execute
from metaform.util import write_json
ROOT=Path('.test-tmp/release-verification/live-document-workflow').resolve()
PROJECT=ROOT/'artifact';PROJECT.mkdir(exist_ok=True)
(PROJECT/'README.md').write_text('# Seed exchange documentation fixture\n\nA tiny documentation-only artifact describing a local seed exchange. No application, external service, installation, or dependency is needed. The intended audience is a volunteer receiving and lending seed packets.\n\nThis is an isolated release-verification fixture, not a request from Rich for a new product. Standard Python, shell and file tools are already available.\n')
(PROJECT/'requirements.md').write_text('# Authored test requirements\n\nVersion: fixture-spec-v1-2026-09-11\n\nExplain accepting a labeled seed packet, recording its crop and variety, lending an available packet, and recording the remaining inventory. Keep one small content module. Use Markdown only. Every packet record carries crop, variety, quantity and received date. A packet is available when its recorded quantity is greater than zero.\n')
write_json(PROJECT/'.metaform/config.json',{'knowledge_mode':'portable','auto_build':False})
app=App(PROJECT,PROJECT/'.metaform/home',binding=False,debug=True);registry=Registry(app);engine=Engine(app)
summary={'project':str(PROJECT),'source_workflow':'metaform.library.orchestrator','inference':'Actual Codex harness for every non-user assignment; one explicit test-fixture planning answer','phases':[]}
def save(name,value):write_json(ROOT/name,value)
def files():return {str(p.relative_to(PROJECT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in PROJECT.rglob('*') if p.is_file() and '.metaform' not in p.relative_to(PROJECT).parts and '.git' not in p.relative_to(PROJECT).parts}
async def answer_job(job,label):
 save(label+'.assignment.json',job);before=files();t=time.monotonic();print('EXECUTE',label,job.get('role'),flush=True)
 result=await execute(app,job,'codex');save(label+'.response.json',result)
 if result.get('status')!='answered':raise RuntimeError(result)
 receipt=engine.submit(job['run_id'],job['request_id'],result['answer']);save(label+'.receipt.json',receipt)
 after=files();summary['phases'].append({'label':label,'step':job.get('step'),'role':job.get('role'),'run_id':job['run_id'],'request_id':job['request_id'],'elapsed_seconds':time.monotonic()-t,'created_or_changed':{name:sha for name,sha in after.items() if before.get(name)!=sha}});save('execution.json',summary)
 return result['answer']
async def main():
 run_id=None
 try:
  job=engine.start('metaform.library.orchestrator',{},exclusive=False);run_id=job['run_id'];summary['run_id']=run_id
  counter=0
  while True:
   if job.get('status')=='running':job=engine.next(run_id);continue
   if job.get('status')=='complete':raise RuntimeError('Source workflow ended before documentation evidence')
   counter+=1;label=f'{counter:02d}-'+job.get('step','assignment')
   if job.get('status')=='awaiting_user':
    assert job['step']=='planning',job
    answer={'goal':'Produce a concise documentation-only guide for the tiny supplied seed-exchange artifact. Retain docs/Blueprint.md, an index, and one module guide.','constraints':['Use requirements.md version fixture-spec-v1-2026-09-11 as the artifact requirements.','Markdown only, one small content module, no application or external service.','Existing standard tools are sufficient; this artifact needs no dependency installation.'],'preferences':['Concise language for volunteers.','Keep all output in this isolated fixture project.'],'stop':False}
    save(label+'.assignment.json',job);save(label+'.explicit-test-user-answer.json',{'provenance':'Authored verification input; not an actual answer supplied by Rich.','answer':answer});engine.submit(run_id,job['request_id'],answer)
   else:
    answer=await answer_job(job,label)
    if job.get('step')=='architect':
     assert (PROJECT/'docs/Blueprint.md').is_file();save('blueprint-after-architect.json',{'sha256':files()['docs/Blueprint.md'],'text':(PROJECT/'docs/Blueprint.md').read_text()})
    if job.get('step')=='doc_shard':
     paths=['docs/Blueprint.md',answer['index_path'],*[item['path'] for item in answer['shards']]]
     paths=list(dict.fromkeys(paths));assert all((PROJECT/path).is_file() for path in paths)
     save('documentation-after-librarian.json',{path:{'sha256':files()[path],'text':(PROJECT/path).read_text()} for path in paths})
     break
   job=engine.next(run_id)
  # A separate explicit verification reader checks actual files, not the earlier agents' summaries.
  workflow={'id':'release.actual-file-reader','steps':[{'id':'read-files','role':'DocumentationReader','context':'project','prompt':'Read each supplied path from the actual current filesystem, compute its SHA-256 from the bytes you read, and explain how the Blueprint, index, and module documentation preserve the authored seed-exchange requirements and their version. Return actual file-derived observations, not inferred content from filenames.','inputs':{'paths':{'literal':paths}},'tools':['workflow.files','workflow.read'],'schema':{'type':'object','properties':{'files':{'type':'array','items':{'type':'object','properties':{'path':{'type':'string'},'sha256':{'type':'string'},'observation':{'type':'string'}},'required':['path','sha256','observation']}},'requirements_version':{'type':'string'},'relationships':{'type':'string'}},'required':['files','requirements_version','relationships']}}]}
  import_workflow(app,workflow);reader=engine.start(workflow['id'],{},exclusive=False);answer=await answer_job(reader,'reader')
  current=files();observed={item['path']:item['sha256'] for item in answer['files']};assert set(paths)<=set(observed)
  assert all(observed[path]==current[path] for path in paths),(observed,current)
  assert answer['requirements_version']=='fixture-spec-v1-2026-09-11',answer
  assert engine.next(reader['run_id'])['status']=='complete'
  summary.update(status='passed',reader_actual_file_hashes={path:observed[path] for path in paths},source_workflow_scope='Actual shipped source workflow executed through DocLibrarian. Stopped at this bounded artifact-handoff check; no claim of full build/evaluator/satisfaction completion.',reader_scope='Separate explicitly authored verification reader ran through actual Codex and compared current file hashes.')
 except BaseException as exc:
  summary.update(status='failed',error=type(exc).__name__+': '+str(exc));(ROOT/'traceback.txt').write_text(traceback.format_exc());raise
 finally:
  if run_id:
   summary['source_run_state_before_bounded_stop']=app.load_run(run_id)['status']
   if app.load_run(run_id)['status']=='running':engine.abort(run_id)
  with app.db() as db:rows=db.execute('SELECT kind,created,run_id,body FROM events ORDER BY id').fetchall()
  save('events.json',[dict(row)|{'body':json.loads(row['body'])} for row in rows]);save('execution.json',summary);print(json.dumps(summary,indent=2),flush=True)
asyncio.run(main())
