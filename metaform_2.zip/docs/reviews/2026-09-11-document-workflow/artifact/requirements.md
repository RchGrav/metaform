# Authored test requirements

Version: fixture-spec-v1-2026-09-11

Explain accepting a labeled seed packet, recording its crop and variety, lending an available packet, and recording the remaining inventory. Keep one small content module. Use Markdown only. Every packet record carries crop, variety, quantity and received date. A packet is available when its recorded quantity is greater than zero.
