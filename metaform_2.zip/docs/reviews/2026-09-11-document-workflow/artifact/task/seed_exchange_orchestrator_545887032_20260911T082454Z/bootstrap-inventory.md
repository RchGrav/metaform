# Bootstrap inventory

Scope: `/home/rich/metaform/.worktrees/release-quality/.test-tmp/release-verification/live-document-workflow/artifact`. This is a documentation-only seed-exchange release-verification fixture.

## Existing documents

- `README.md`: describes a local seed exchange for volunteers; no application, external service, installation or dependency is needed.
- `requirements.md`: fixture-spec-v1-2026-09-11; accept a labeled packet, record crop and variety, lend an available packet and record remaining inventory. Every packet record carries crop, variety, quantity and received date. A packet is available when recorded quantity is greater than zero. Keep one small content module and use Markdown only.

No existing `docs/`, `src/`, `claude/commands/` or `.claude/commands/` was present before bootstrap. The local `.agents/` and `.codex/` directories were empty. Supplied instruction files and runtime state were preserved.

## MCP endpoints and workflow tools

No repository MCP server or endpoint configuration was found. The `mcp_endpoints` occurrences in `.metaform/metaform.json` are schema fields, not configured endpoints.

The supplied Metaform CLI exposed `workflow.files` and `workflow.read` through its actor transport. These are CLI tools, not discovered MCP endpoints. Tool discovery succeeded and `workflow.files` returned an empty list. The repository document inventory above comes from direct local file inspection. The supplied `begin 545887032` invocation returned an actor argument error; the no-command discovery invocation succeeded.

## Tool inventory

| Tool | Observed availability | Need and installation result |
| --- | --- | --- |
| Python 3 | `/usr/bin/python3`, runtime 3.10.12 | Used for exact UTF-8 persistence and artifact verification; already present. |
| ripgrep | 15.2.0, supplied by the Codex environment | Used for repository file discovery; already present. |
| Git | `/usr/bin/git`, 2.34.1 | Already present. The artifact's local `.git/` directory is empty; Git resolves to an enclosing repository. No staging or commit was performed during bootstrap. |
| Debian tooling | `/usr/bin/apt-get` and `/usr/bin/dpkg-query`, apt 2.4.14 | Available; no additional Debian package is needed. |
| pip | `pip` and `pip3` absent from PATH; system Python has no pip module | Not needed for this Markdown-only artifact; not installed. |

Needed additions: none. Actually installed: none. Python's standard library, shell and file tools cover the bootstrap work; the project declares no dependencies.

## Created artifacts

- Command name: `seed_exchange_orchestrator_545887032`
- Verbatim source command: `claude/commands/seed_exchange_orchestrator_545887032.md`
- Task directory: `task/seed_exchange_orchestrator_545887032_20260911T082454Z/`
- Live workflow tree: `task/seed_exchange_orchestrator_545887032_20260911T082454Z/workflow-tree.md`
- This inventory: `task/seed_exchange_orchestrator_545887032_20260911T082454Z/bootstrap-inventory.md`

Source SHA-256: `953780a58c8a1aec63768cfbf5db64b9e656fa57575f7c1e207339e47e94c7d0`

## Verification

The command file's UTF-8 bytes equal the request's source_instruction exactly. Its SHA-256 matches the value above. Both task documents exist and are nonempty. The tree records all six source workflow phases, with only bootstrap complete. Original README.md and requirements.md were read without modification. No application build, unit-test suite or linter is configured in this artifact.
