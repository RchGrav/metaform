# Seed exchange volunteer guide

## Accept and record a packet

Accept a labeled seed packet. Create a record for every packet with all four fields:

| Field | What to record |
| --- | --- |
| Crop | The crop named on the packet label. |
| Variety | The variety named on the packet label. |
| Quantity | The quantity received, updated to the remaining quantity after lending. |
| Received date | The date the packet was received. |

## Check availability and lend

A packet is available when its recorded quantity is greater than zero. Check the record and lend an available packet.

## Update remaining inventory

After lending, update the packet's recorded quantity to the amount remaining. Keep crop, variety, quantity, and received date in the record.

Based on the [Blueprint](../Blueprint.md) and [requirements](../../requirements.md), version `fixture-spec-v1-2026-09-11`. This is the sole content module, `seed-exchange`, written in Markdown, with no module or external dependencies.
