# Seed exchange documentation

Concise English documentation for volunteers, based on `requirements.md` version `fixture-spec-v1-2026-09-11`. All documentation uses Markdown.

- [Seed exchange volunteer guide](modules/seed-exchange.md): the single content module, covering packet acceptance, records, availability, lending, and remaining inventory.
- [Blueprint](Blueprint.md): the retained specification, artifact contracts, ordered module map, dependency list, and verification criteria.

Module `seed-exchange` is first and only in build order. It has no prerequisite modules or external dependencies. No application, external service, or installation is needed.
