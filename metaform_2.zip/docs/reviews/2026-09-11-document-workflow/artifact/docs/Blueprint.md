# Seed exchange blueprint

Requirements: `requirements.md`, version `fixture-spec-v1-2026-09-11`.

## Specification

Produce a concise English guide for volunteers accepting and lending seed packets. Use Markdown only, with one small content module, an index as the entry point, and this retained blueprint. No application, external service, installation, or dependency is needed.

The guide explains how to:

1. Accept a labeled seed packet and record its crop and variety.
2. Keep crop, variety, quantity, and received date in every packet record.
3. Identify an available packet by its recorded quantity being greater than zero and lend an available packet.
4. Record the remaining inventory by updating the packet's quantity after lending.

## Artifact contracts

| Artifact | Contract |
| --- | --- |
| `docs/Blueprint.md` | Retain the specification, ordered module map, and dependency list. |
| `docs/index.md` | Serve as the documentation entry point, linking to `Blueprint.md` and `modules/seed-exchange.md`. |
| `docs/modules/seed-exchange.md` | Provide the sole content module: concise volunteer instructions for labeled-packet intake, the four record fields, availability, lending, and remaining inventory. |

The index supplies navigation; the blueprint supplies the specification. All volunteer procedure content belongs in the single module guide. Existing `README.md` and `requirements.md` remain project context; the integration stage can link the README to the index.

## Ordered module map

| Build order | Module ID | Language | Artifact directory | Output | Contract | Module dependencies |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | `seed-exchange` | Markdown | `docs/modules/` | `seed-exchange.md` | Explain accepting a labeled seed packet; record crop, variety, quantity, and received date for every packet; define availability as recorded quantity greater than zero; explain lending an available packet and recording remaining inventory. | None |

There is one build-loop module and no prerequisite module. The documentation stage uses these contracts to create the index and module guide; the build stage completes that same guide at the same path.

## Dependency list

None. The artifact uses Markdown and existing standard file tools only.

## Verification

Check the guide against each procedure and record field above. Confirm the availability rule matches `requirements.md`, both index links resolve, the blueprint is retained, and exactly one content module exists. Read the guide for concise language suitable for volunteers. No application build or unit-test suite applies.
