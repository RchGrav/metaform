# Seed exchange documentation fixture

A tiny documentation-only artifact describing a local seed exchange. No application, external service, installation, or dependency is needed. The intended audience is a volunteer receiving and lending seed packets.

This is an isolated release-verification fixture, not a request from Rich for a new product. Standard Python, shell and file tools are already available.
