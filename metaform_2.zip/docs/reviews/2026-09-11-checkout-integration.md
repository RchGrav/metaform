# Original checkout integration

The reviewed repairs and local distribution are integrated in
`/home/rich/metaform` on the existing `realignment-2026-09-10` branch. HEAD remains
`d264f512ceba89cf3a5152f66cdc60c0e1a06ba4`; changes are uncommitted. The isolated
repair worktree remains available. No public release or global installation was
performed.

The integration compared each original file against the initial snapshot before
copying 397 reviewed source/documentation/evidence files. There were zero
intervening conflicts. It checked each source and destination again while copying.
Starting user edits remain included. Protected instruction files were unchanged;
no files were deleted. The root's final delivery notes and evidence were then
synchronized with the same comparison before replacement.

Only `dist/metaform` and `dist/metaform_chassis-0.2.0-py3-none-any.whl` were replaced.
Both preceding files were verified and retained in
`.worktrees/release-quality-artifacts-before/`. All historical `dist/` directories
remain present.

| Identity | SHA-256 |
| --- | --- |
| Final executable and wheel | `2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027` |
| Integrated source fingerprint | `e593dcbc2d7317fe1b57e79f536065f9461be4fb1c39308792498a8e05d0ecb4` |
| Previous executable and wheel | `24973b0df6614e498feca39f294f71f5b46164f9371a9cb0bb3a383665196ff2` |

The source fingerprint matches the final build/verification provenance. All 161
packaged source files were already checked byte-for-byte by the artifact owner.
The [distribution report](../release-distribution-evidence.md) contains the
complete Python 3.11/3.13 installed/standalone matrix. The [source report](2026-09-11-final-integration-verification.md)
records the 884-test/four-browser frozen run, exact later three-file deletion,
35 focused checks and 22 JavaScript checks.

After copying, the actual original-path executable passed **44 public calls** on
Python **3.10.12**, with `-S`, empty `PATH`/`PYTHONPATH`, and isolated project/home
directories. The test used only delivered reference to construct and customize a
module, execute the exact returned worker handoff, answer/replay, preserve an
authored user wait, export/import independent state, remove the copied module,
and load the historical sample. The transcript retains the actual paths and
responses. User answers in this journey are explicitly fixtures.

Five additional standalone shutdown cases passed on that same Python 3.10.12:
Ctrl-C with stdin open, EOF, Ctrl-C with a measured full stdout pipe, a complete
large Unicode response, and interruption of a synchronous handler with its
`finally` observed. Ctrl-C cases exited 130 in approximately 0.032 seconds; EOF
and the completed response exited 0. This verifies the available Linux/Python
3.10 interpreter; it does not claim a Python 3.10 installed dependency stack or
Windows/client-host behavior.

Retained evidence:

- [Per-file integration record](original-checkout/integration.json)
- [Artifact copy and preservation record](original-checkout/artifacts.json)
- [Original-path journey summary](original-checkout/customization.json)
- [Complete original-path invocation transcript](original-checkout/customization-transcript.json)
- [Python 3.10 shutdown output](2026-09-11-original-python310-shutdown.log)

The original/worktree content comparison for reviewed paths and `git diff --check` passed. Original-only unrelated files were preserved. The
documentation check found no broken relative file links, and the current audit
contains exactly 84 unique work entries. That [audit](2026-09-11-release-evidence-audit.md)
retains 70 verified, nine representative, three host-limited and two open
dispositions. Enumerator capacity and missing canonical base definitions remain
open; full execution of every workflow branch and unavailable hosts remain
unclaimed.

Start the delivered tool from the checkout with `python3 dist/metaform`; use
`python3 dist/metaform --help` for the module-organized reference.
