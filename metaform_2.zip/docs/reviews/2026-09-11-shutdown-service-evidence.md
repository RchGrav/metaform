# Shutdown and service lifecycle repair evidence

Source worktree: `/home/rich/metaform/.worktrees/release-quality`. These are source checks; rebuilt-distribution and independent-review evidence remain required before closing R41/R42/R43.

## Reproduced failures

- Initialized installed SDK MCP, kept stdin open, sent one SIGINT and called `process.wait(timeout=5)` before `communicate`: timed out. The same portable MCP probe timed out. The earlier `communicate`-first regression closed stdin and concealed both blocked readers.
- After initialize, requested a 2 MB schema resource and stopped consuming stdout. Both installed and portable processes remained blocked after SIGINT. A failing `blocked_output` regression confirmed this second cause.
- A service with a short test idle timeout never exited. Two initial regressions failed at `process.wait(timeout=4)`, including the case where another client's accepted mutation had already completed.
- A synchronous module handler sleeping inside MCP delayed the first SIGINT until it returned. Cancelling only the asyncio serving task did not interrupt the handler.
- A real automatic PEP 517 build blocked executor shutdown after SIGINT. Its backend slept for 30 seconds; MCP failed a three-second exit check with stdin still open.
- Removing the project module made MCP discovery index an absent `project.select`, while direct dispatch bypassed registration. Both transports now use the registered command and its declared availability.
- A portable request with an object identifier raised `TypeError: unhashable type: 'dict'` and terminated the process. Invalid identifiers and parameter envelopes now receive protocol errors; malformed cancellation notifications are ignored and a subsequent valid ping succeeds.
- The first installed candidate, using MCP 2.2.0 instead of the source environment's 2.1.1, returned exit 1 after a final initialization notification followed immediately by SIGINT. Its stdin sender attempted to send into a receiver the SDK had already closed, producing `BrokenResourceError` inside an exception group. This was reproduced against the source with the candidate's dependencies before fixing shutdown ordering.

## Implementation and boundaries

Both transports now share cancellable UTF-8 input framing and serialized output writes. Neither stdin reads nor full output pipes leave a blocked executor worker. The SDK receives these streams through its public `stdio_server(stdin=..., stdout=...)` parameters. The CLI and direct server entry return 130 through normal unwinding; the regression also verifies a process cleanup callback runs. Output descriptors and their blocking mode are restored on exit.

The temporary SIGINT handler cancels the tasks of its owned event loop together and unwinds a running synchronous coroutine handler, then restores the previous signal handler. Cancelling producers together with receivers prevents the MCP 2.2.0 shutdown race. When a signal arrives inside an event-loop callback, cancellation is queued until that callback completes: cancelling a Future between its state check and result assignment caused a separately observed `InvalidStateError`. A deterministic regression exercises that exact sequence and verifies normal unwinding and restoration of the previous handler. A real RemoteKnowledge socket call is covered: the interrupted MCP client exits, its handler's `finally` runs, the shared service accepts another client's write, and the already accepted original mutation completes with durable request-ID replay.

Automatic builds share a cancellation event with their executor worker. Source hashing and lock waits poll it; the build owns a separate process group, which is stopped and reaped on cancellation, including its PEP 517 backend child. The build lock is released during normal unwinding. A separate test verifies cancelling a waiter does not release another build's lock. Completed build state is published by the event-loop caller after the worker returns.

The service's `service_idle_timeout` is a home-scoped module setting with a 60-second default and a positive value requirement. The daemon reads its default from the service manifest and observes home configuration changes during idle checks. It counts accepted handlers, waits for them to finish, releases storage ownership, and removes its endpoint file before releasing the ownership lock. Requests transparently restart an idle service. Closing an MCP client does not stop another client's service operation.

The shared test fixture disables automatic package rebuilding only in its temporary home, and every test now receives a temporary `METAFORM_HOME` unless it explicitly overrides it. Teardown visits `service/endpoint.json` files only beneath that test's `tmp_path` and stops those verified instances. It captures the real stop callable before the test can replace the service module.

An earlier broader review test, before this automatic home isolation, created a service in the real home after a stale project marker fell through to default selection. The coordinating agent verified and stopped exactly that test-created service (instance `3e438ec9-4204-413f-8a11-3851f705996a`); persistent home data was left intact. The earlier blanket statement that no real home was touched was incorrect. SDK subprocess tests also initially omitted `PYTHONPATH`, causing the SDK's restricted environment to load the original editable checkout. Those tests now explicitly inherit the worktree path, and the source results below were rerun with that correction.

## Verification

Command:

```sh
PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest tests/test_build_cancellation.py tests/test_release_packaging.py tests/test_mcp.py tests/test_service_lifecycle.py tests/test_service_analysis.py tests/test_project_context.py -q
```

Result before the final three added cases: **94 passed in 58.94s**. Raw output: [shutdown/service test log](2026-09-11-shutdown-service-tests.log). The final malformed-identifier regression passed in 1.40 seconds; the installed/portable accepted-service interruption cases passed in 2.84 seconds. The latter initially missed the service operation because the test community handler tried to access internal knowledge through the new public facade; the fixture was corrected to create its explicit test client. No runtime change was required for that test. `git diff --check` passed after these changes. The integrated suite is recorded separately by its owner.

Coverage includes SDK and portable transports through CLI and direct server entry; initialized stdin-open SIGINT; EOF; full output-pipe interruption; complete large Unicode responses with a concurrent ping; normal process cleanup; shared service reuse; authenticated ownership; accepted-operation draining; idle release with retained knowledge; survival of another client's long accepted operation; and a mutation crossing the exact idle-shutdown boundary, including request-ID replay without a second revision.

After the installed-candidate finding, all MCP tests, automatic-build cancellation tests and both interrupted accepted-service cases ran with the candidate's MCP 2.2.0 dependencies: **30 passed in 31.39s**, recorded in [MCP 2.2.0 shutdown tests](2026-09-11-shutdown-mcp22-tests.log). The additional deterministic Future-callback signal regression passed separately in 0.70 seconds. The rebuilt artifact still requires the distribution owner's repeated direct checks; the first candidate's failed check remains part of the evidence.

The same focused set, including the added callback regression, then passed against the original MCP 2.1.1 source environment: **31 passed in 33.01s**, recorded in [final source shutdown tests](2026-09-11-shutdown-final-source-tests.log). Both dependency runs used AnyIO 4.15.1 and Python 3.13.5.

## Remaining verification limits

Independent CLI checks are retained in [CLI probe results](2026-09-11-cli-independent-probes.json): existing-project help and reference preserve every file byte, malformed configuration still yields help and identifies the broken file, the module reference filter and alias arguments work, removing starting modules removes their recommendations, and `--debug mcp` exits 130 on SIGINT with stdin held open. Starting an existing project without a command uses live runtime reads and can create its model lock file; a fresh starting page and the help/reference routes do not initialize storage.

Python signals can still be deferred by a native extension that does not return control to Python. The executed synchronous-handler and socket tests establish the supported Python paths; they do not demonstrate interruption of every possible third-party native handler. Windows build-process group cancellation also needs a Windows runner.

All executed checks above used Linux and the repository's Python 3.13 environment. Windows input/output handling is implemented but requires a Windows runner for a release claim. Python's standard Windows stdin pipes cannot use `connect_read_pipe`, and `os.set_blocking` gained Windows pipe support in Python 3.12, so older Windows runtimes use the documented pipe APIs. References: [Python platform support](https://docs.python.org/3/library/asyncio-platforms.html), [Python os pipe support](https://docs.python.org/3.12/library/os.html), [PeekNamedPipe](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-peeknamedpipe), [SetNamedPipeHandleState](https://learn.microsoft.com/en-us/windows/win32/api/namedpipeapi/nf-namedpipeapi-setnamedpipehandlestate).

The currently rebuilt distribution still needs the same stdin-open/full-output tests from outside the source tree. The larger R42 assignment-abort/recovery work is owned by the lifecycle lane and is not claimed closed here.

## Independent artifact-probe and service-residue follow-up

The second candidate passed the distribution owner's eleven direct checks using an installed Python 3.13 environment with MCP 2.2.0 and a dependency-free standalone Python 3.11 launcher. Independent review found that the output-pressure probe could accept a schema registration error and then a short error response as evidence of a full pipe. Two controlled fake children demonstrated that false pass. The probe owner corrected both conditions: schema registration must succeed, and Linux `FIONREAD` must equal the actual `F_GETPIPE_SZ` capacity before interruption. Both controlled false cases were independently rejected after correction. The real installed and standalone full-pipe cases then exited 130 with stdin still open, in 0.215 and 0.064 seconds respectively. These candidate checks do not replace the final rebuilt-artifact run.

Six explicitly identified old test service processes survived after pytest retention removed their temporary homes. Their exact command lines and process start times were revalidated before the coordinator-authorized SIGTERM cleanup; all six exited. Public `stop_service` could not authenticate those instances because their deleted test homes had contained the endpoint/token records. This cleanup inspected only the identified test-owned processes. A new service running the current source with its temporary home removed exited normally after 60.09 seconds, with exit 0 and empty stderr, exercising the current idle-default fallback.
