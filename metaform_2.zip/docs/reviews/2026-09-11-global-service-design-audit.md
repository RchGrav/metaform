# One persistent global server: implementation design audit

Status: the user-approved design is implemented in source. Focused lifecycle, project isolation and browser-preview checks are retained in [implementation evidence](2026-09-11-global-service-evidence.md). The coordinator owns the final full-suite, rebuilt-artifact and live-handover checks; this design record does not substitute for them.

## Established requirement

One persistent Metaform server process serves all projects, browser windows and clients. The knowledge RPC owner and workbench HTTP server must be the same process. There is no idle shutdown, heartbeat lifetime, per-project daemon or per-home daemon. Existing project knowledge, revisions, registrations, execution state and configured storage locations are retained.

## Boundaries observed before this repair

- `service.py` starts a detached `ThreadingHTTPServer` per home. It holds `home/service/instance.lock`, authenticates RPC with that home's token, and opens `home/service/knowledge.sqlite3`. The service exits on its configured idle timeout. Its challenge/instance checks and accepted-operation draining already have meaningful subprocess tests.
- `modules/viewer.py` starts a separate detached `python -m metaform.viewer` per project and records the instance in that project's `state['viewer']`. Reuse checks liveness/identity but cannot distinguish the loaded runtime or its assets. Launching by module name can import an unrelated installation.
- `viewer.py` already serves `/projects/<project_id>/...`, including isolated request context and a project chooser. It currently requires one initial `App`, uses that as the default for unscoped routes, and discovers other projects through the selected Apps' homes.
- An installed `App` creates `RemoteKnowledge` in its constructor. An App created inside a combined server therefore needs an explicit in-process knowledge client to avoid self-RPC and startup recursion.
- `KnowledgeStore` already supports many project owners, retains mutation receipts, and uses a connection per thread/transaction. `dispatch_operation` additionally handles the analysis-copy operations; a plain `store.bind()` does not cover those operations.

## Recommended ownership and transport

Use one canonical runtime directory for the operating-system user, independent of project folders and storage-home selection. It owns one start lock, process lock, authenticated identity and endpoint. The production location is `Path.home() / '.metaform' / 'runtime'`. `METAFORM_HOME` continues to select storage/configuration, never an additional server process. Tests set `METAFORM_RUNTIME_DIR` to a temporary directory before any client or subprocess starts, share it across storage homes within that test, and stop only that isolated owner. Their isolated storage homes alone are no longer sufficient isolation.

The process hosts one threaded HTTP listener with both the existing authenticated `/v1/...` knowledge protocol and the existing Flask workbench routes. Reuse Flask/Werkzeug, already a dependency, rather than introduce another transport library. The server must override Werkzeug's `daemon_threads=True`: accepted handlers must drain before store ownership is released, as the current knowledge service does.

The owner opens each explicitly attached storage home's existing database in process. A map of stores is not a map of child daemons. No database merge or knowledge conversion is part of this repair. The owner holds each attached home's existing instance lock as well as its global process lock, so an older executable cannot acquire that storage ownership and start a competing owner while the global process is using it.

Keep the protocol-1 operation envelope and receipt binding unchanged. Each storage home's existing token selects its store at the shared listener. Its `service/endpoint.json` becomes an alias to the same global PID, port and instance, retaining the historical store `service_id`. This supports existing project markers and RemoteKnowledge callers without adding a storage selector to every semantic operation. The canonical runtime endpoint has its own management identity. Health/status report the global instance and loaded runtime fingerprint explicitly; all aliases point to it.

Alternatives rejected for this scope: a single viewer proxying several knowledge daemons violates the process requirement; merging every configured home database introduces data migration and identity reconciliation unrelated to making the server global.

## Project and App interfaces

The server owns a registry of explicitly attached project paths and storage homes, persisted in its runtime directory. It reuses registrations already present in attached stores; it does not search arbitrary directories. Legacy and portable projects can be attached for viewing with their current local storage behavior; attachment does not call `project.adopt` or change their identity.

`App` receives an optional internal knowledge-client factory when created by the owner. Its ordinary CLI/MCP construction keeps using RemoteKnowledge. The in-process factory accepts `(home, project_id)` and returns a client whose `call(operation, arguments, request_id=None)` uses the same `dispatch_operation` and receipt path as HTTP. Project selection propagates that factory. This retains the existing project-scoped App/module surface without process-global selected-project state.

The workbench factory receives the owner/project registry instead of inventing an initial project. Global `/`, health and static routes must work before any project is open. A project URL selects an App only for that request. Project identifiers that collide across storage homes or portable copies retain the existing path-qualified URL disambiguation. Unscoped project operations must not silently choose another window's current project.

`viewer.serve` asks the global owner to attach/open the requested project and returns its `/projects/.../` URL on the shared endpoint. It does not create or record a project-owned process. Existing project viewer records are migration evidence only. `viewer.stop` delegates to the explicit global stop operation and its reference must say that this stops the shared server for all projects.

## Start, reuse, restart and migration

Add discoverable `service.start` and `service.restart` beside status/stop. Service management uses the canonical runtime endpoint and works without initializing a project. Startup keeps the current authenticated challenge and lock discipline, and launches the actual loaded package/archive using an explicit bootstrap, not an ambient `python -m` lookup. A failed or cancelled startup joins its captured child; it does not leave an untracked process.

Compute a deterministic fingerprint over the loaded package's Python, static, templates and bundled module metadata/resources. Capture it once in the process at startup; health and endpoint metadata report that captured identity. Reading mutable source files on each health request would incorrectly make an old process claim new code. Dynamic external module metadata is still discovered through the selected project's Registry.

Same fingerprint and compatible endpoint means reuse. A differing runtime must be reported as requiring `service.restart`; normal clients must not silently oscillate the global server between two installations. Explicit restart acquires the global start lock, authenticates the exact old instance, stops acceptance, drains accepted requests, releases old ownership and starts the requested runtime on the same listener address where available. Existing clients re-read endpoint identity before retrying with the same request ID. The existing ambiguous-result behavior for non-replayable analysis queries remains.

A requested nonzero port or different host cannot create a second listener. Start may choose the endpoint when no owner is running. With a running owner, changing it uses the explicit restart operation and returns the changed global address. The existing service's loopback boundary remains; any change to externally reachable service exposure is outside this repair.

On attachment, detect an old per-home knowledge owner using its current authenticated challenge protocol, ask that exact owner to stop, wait for its accepted operations and lock release, then open the unchanged database and publish the shared endpoint alias. On opening a previously viewed project, retire a recorded old viewer only after matching its known project/instance, ready file and stop marker. Do not signal a PID or touch a different listener merely because a stale file names it. Root's current explicitly identified old-process cleanup remains separate from this implementation.

Explicit stop drains all accepted RPC and viewer requests, removes owned temporary preview reconstructions, releases all store locks and removes only endpoint records belonging to the stopping instance. Revision previews use project-scoped routes on the same listener, with no additional preview server or port. Browser sandboxing preserves authored scripts while separating their origin from workbench APIs; preview assets alone allow cross-origin reads for module imports, and browser mutations with an unrelated or opaque Origin are rejected before opening a project. Stop does not abort durable workflows or clear assignments. All idle-timeout code and its module setting are removed. Browser close does not control server lifetime. A later explicit start or product operation requiring a server can start it under the same singleton discovery rule.

An HTTP request invoking stop or restart receives its acknowledgment before shutdown drains the request. The current owner records restart intent; its existing lifecycle drains, closes resources, releases ownership and starts the replacement. This avoids waiting on the calling handler or creating a separate restart-coordinator process.

## Minimum file changes

| Files | Responsibility |
| --- | --- |
| `src/metaform/service.py` | Canonical global owner/discovery, attached store/token routing, combined HTTP process, start/stop/restart, exact package launch, fingerprint, draining and obsolete-owner migration. |
| `src/metaform/viewer.py` | Project-independent app construction, owner-backed project selection/catalog, existing HTTP routes on the combined listener, preview cleanup. Preserve the newly added static JSON route. |
| `src/metaform/app.py` | Internal knowledge-client factory during registration, construction and project selection; ordinary clients and existing identity/storage behavior remain intact. |
| `src/metaform/modules/viewer.py` | Open a project through the shared owner; remove per-project process startup/state ownership. |
| `src/metaform/modules/project.py` and `data/modules/service.json`, `data/modules/viewer.json` | Explicit global lifecycle commands/reference/bootstrap; remove idle setting; explain shared endpoint and scope. |
| `tests/conftest.py` and subprocess/browser helpers | Isolate the runtime owner before every process; teardown that exact test instance, independent of storage homes. |
| Existing service/viewer lifecycle tests plus `tests/test_global_service.py` | Real two-project/two-home single-instance, persistence, endpoint/migration/reconnect and package-origin regressions. |

No new dependency, knowledge schema migration, module semantic change, model rewrite, global package installation or idle control is needed.

## Required executable evidence

1. Two projects under one home and a third under another home call RPC and open workbench URLs concurrently. All service health, endpoint aliases and viewer health report one PID, port and global instance; project data stays separate.
2. Eight independent starters with distinct project/home inputs converge on that same owner. Closing clients and browser windows leaves it running until explicit stop; an old saved idle setting has no effect.
3. The listener serves real model/layer/neighborhood reads for both project URLs while CLI/MCP writes continue. No per-project or backend child process appears.
4. Replay an accepted mutation across explicit restart/disconnection with the same request ID and verify one revision change. Stop waits for an accepted slow mutation and an accepted viewer request to finish; unrelated pending workflows remain intact.
5. Start from a copied package with PYTHONPATH cleared and a misleading embedding executable. Served static bytes and reported fingerprint must match that actual package. Metadata/asset changes are detected; current builds reuse; an explicit replacement drains and retires the old instance.
6. Retain existing old owner/viewer fixtures with real data. Migrate process ownership, verify the original project IDs, revisions, records and receipts, and verify old owned ports close. Wrong-identity listeners, forged/stale PIDs and another project's marker are untouched.
7. Restart preserves the shared URL when its port is available; an explicit port change produces one replacement server. Service status/stop/restart work without opening a project or binding an assignment.
8. Run existing knowledge contract, accepted-mutation interruption, project context, all browser journeys and delivered installed/archive entry checks against the rebuilt artifact. Report actual operating systems exercised; a Linux run is not Windows proof.

The coordinator confirmed canonical per-operating-system-user scope and explicit restart for a different runtime fingerprint before implementation. Existing storage homes remain independent data owners attached to one process; they do not define additional server lifetimes.
