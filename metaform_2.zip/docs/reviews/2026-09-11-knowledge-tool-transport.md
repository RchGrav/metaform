# Knowledge Tool inference transport

The actual 66-question Pong assignment exceeded Codex's 1,048,576-character input limit before inference: its delivered JSON contained 1,098,606 characters. The excess came in part from repeated applicability proof routes inside each question's property context.

`prompts.inference_payload` now removes only `path` and `visibility_path` from Knowledge Tool property-context entries in its existing deep copy. The stored assignment, recipes, dependencies and proof routes remain unchanged. The worker still receives every question and its schema, exact instruction, subject, selected records, properties, components, relationships, and each property's origin, applicability and visibility result. The complete functional account remains identical and contains the semantic records, signals, Encounter Functions and Operative Purposes referenced by these contexts.

The exact harness serialization of the retained failed assignment now measures **569,076 characters**, a reduction of **529,530**. All **66 questions** remain. The measurement reproduces the reported original **1,098,606** characters exactly. No production limit, question cap, batching, new inference stage or output gate was added. The prompt seed code was not changed.

The new regression first failed on the repeated proof routes, then passed after the five-line projection. It checks each retained relation field and Encounter Function against the delivered functional account, complete question/context selection, untouched stored pending inputs, unchanged assignment, and unrelated-role preservation. The complete focused prompt-composition file passed **14 tests in 1.38 seconds**; `git diff --check` passed.

Independent review of the actual assignment verified all **573 removed route steps** (85 unique): every relation and endpoint remains available, and every recorded reason, signal, scope, role, classification, softness, realization, category and provider Encounter Function matches the unchanged functional account. The review is retained with the Pong assignment as `projection-semantic-review.json`.

The accompanying JSON records the assignment and source hashes, exact before/after counts and verification command. This establishes transport preparation and preservation; the resumed real model execution is recorded separately with the Pong retry evidence.
