# Metaform end-to-end system review — 2026-09-09

## Repair status — 2026-09-09

All 21 findings below have been repaired and independently rechecked. The full
suite now passes 501 tests on both Python 3.11 and 3.13, and fresh installed-wheel
distribution checks pass on both, including service-free portable continuation.
See [current verification](../verification.md#system-review-repairs--2026-09-09)
for the evidence scope. The original review and reproduction evidence below
describe the pre-repair baseline and are retained unchanged.

| Findings | Regression coverage |
| --- | --- |
| R01, R06, R13, R14, R17 | [Runtime](../../tests/test_review_runtime.py) |
| R02, R03, R16 | [Portable archives](../../tests/test_review_portable.py) |
| R04, R09, R10 | [Schemas](../../tests/test_review_schemas.py) |
| R05, R07, R11, R12 | [Intake](../../tests/test_review_intake.py) |
| R08, R15 | [Similarity](../../tests/test_review_similarity.py) |
| R18, R19, R21 | [Images](../../tests/test_review_imagegen.py) |
| R20 | [Viewer](../../tests/test_review_viewer.py) |

## Original review

Metaform has a working development chassis: all **396 existing tests passed locally**, the wheel built, and the installed/direct-wheel/offline distribution checks passed. The system-wide review also reproduced **21 defects** outside that coverage. Several can silently lose knowledge, modify the original project, publish project-local material, or misattribute successful output. These deserve attention before treating the current build as a dependable reference for ordinary project work.

The strongest implementation evidence is for the shared service, ordinary source-separated storage, request receipts, and standard offline continuation. The central semantic outcome—correctly differentiated higher-order reasoning through a prepared Metaform—still lacks a current end-to-end live demonstration. Working transport, storage, and fixture agents establish their covered mechanics; they do not establish that outcome.

The user reported testing only a build that was subsequently reverted. This review therefore established the current state independently and covered older code alongside the latest service change. No runtime source, authored prompt, semantic definition, or configuration was repaired.

## Baseline and evidence

| Item | Reviewed state |
| --- | --- |
| Repository revision | [55a8bda72f7851eb697a0ce42fda9beb1e2cd06d](https://github.com/RchGrav/metaform/commit/55a8bda72f7851eb697a0ce42fda9beb1e2cd06d) |
| Runtime code change immediately before it | [4c814641770b8cce4c2a6efa328455bef3ab4326](https://github.com/RchGrav/metaform/commit/4c814641770b8cce4c2a6efa328455bef3ab4326), shared knowledge service and independent portable projects |
| Source acquisition | Authenticated GitHub connector; 185 text files matched their Git blob hashes before and after review. Direct Git cloning lacked credentials. Six historical PNG examples were inventoried but not visually re-reviewed. |
| Local environment | Linux, Python 3.12.14, locked source dependencies; MCP 2.1.1 and Ladybug 0.20.2 |
| Installed-wheel environment | Fresh environment; permitted dependency ranges resolved MCP 2.2.0 and Ladybug 0.20.3; distribution checks passed there |
| Existing CI | [Current revision run](https://github.com/RchGrav/metaform/actions/runs/34313102216): Python 3.11 and 3.13 jobs both succeeded, including source tests, build, and installed-wheel checks |
| User runtime state | No user's installed executable, existing project database, provider credentials, or retained run state was supplied. Findings below use isolated review projects. The precise tested-and-reverted build was not identified. |
| Source integrity | All 185 source text hashes still matched the reviewed commit after execution. Added files are this review and its evidence. |

Fresh execution:

- `uv sync --frozen`: succeeded.
- `uv run --frozen pytest -q`: **396 passed in 78.64 seconds**. [Log](2026-09-09-system-review-evidence/pytest.log).
- `uv run --frozen python tools/build_distribution.py`: wheel and standalone archive built. [Log](2026-09-09-system-review-evidence/build.log).
- Fresh wheel installation followed by `python tools/check_distribution.py`: installed CLI/MCP, direct-wheel CLI/MCP, offline GUI/export, shared-service reuse, analytical copy, and service-free portable continuation checks passed. [Log](2026-09-09-system-review-evidence/distribution.log).
- The additional probes below reproduced the defects against the unchanged source. They use explicit fixtures and injected provider responses; the parallel-workfolder case launches a real fixture harness subprocess.
- The running viewer served its page and seven inspected API routes successfully over HTTP. A controlled viewer termination exposed the stale-startup defect below. [Log](2026-09-09-system-review-evidence/viewer.log).
- Cloud browser navigation to the local viewer was blocked with `ERR_BLOCKED_BY_CLIENT`. Visual, mobile, and accessibility behavior was not certified by this review.

Reproduction commands, logs, source manifest, and detailed findings are in the [evidence index](2026-09-09-system-review-evidence/README.md).

## Findings, ordered by consequence

P1 means a concrete integrity or execution-boundary failure with significant consequences. P2 means a material correctness, availability, or supported-workflow defect. P3 means a narrower recovery defect. These priorities describe the observed failures; they do not introduce runtime acceptance rules.

| ID | Priority | Finding and observed consequence | Evidence |
| --- | --- | --- | --- |
| R01 | P1 | **Parallel child work bypasses the parent's development workfolder.** A real child harness changed the original `target.txt`; the parent completed with an empty diff. | [Runtime details §1](2026-09-09-system-review-evidence/runtime-details.md), `workflow.py:352`; [output](2026-09-09-system-review-evidence/runtime.log) |
| R02 | P1 | **Archive import can write outside its extraction destination.** A symlink member followed by a regular member at the same path overwrote an external scratch sentinel during import, without executing the archive. | [Portable details](2026-09-09-system-review-evidence/portable-details.md), `portable.py:447–453`; [output](2026-09-09-system-review-evidence/portable-import.log) |
| R03 | P1 | **Git-origin export ignores nested history exclusions.** With `history_exclude: ["private/*.txt"]`, the current scan excluded the file but its full bytes still shipped under `origin/private/omit.txt`. | [Portable details](2026-09-09-system-review-evidence/portable-details.md), `history.py:117`; [output](2026-09-09-system-review-evidence/portable-history.log) |
| R04 | P1 | **Global sync exports project-private schemas.** A private-only schema entered the global export, and a project-local same-ID schema replaced the exported global definition. No remote sync push was performed. | [Portable details](2026-09-09-system-review-evidence/portable-details.md), `modules/sync.py:20–25`; [output](2026-09-09-system-review-evidence/global-sync.log) |
| R05 | P1 | **Reusing completed inference silently drops distinct joins.** Two different returned join IDs shared their original `authored_id`; intake rewrote both into one focal ID, retaining only one relationship. | [Semantic details S1](2026-09-09-system-review-evidence/semantic-details.md), `intake.py:57–76`; [output](2026-09-09-system-review-evidence/semantic.log) |
| R06 | P1 | **Workflow binding does not consistently retain the issued assignment.** Direct bound workflow calls read and answered a sibling run. An old binding/nonce returned the next assignment after its own answer. The actor-gateway overrides do not cover these direct routing paths. | [Runtime details §2](2026-09-09-system-review-evidence/runtime-details.md), `modules/workflow.py:56–64`, `continuation.py:104`; [output](2026-09-09-system-review-evidence/runtime.log) |
| R07 | P2 | **Project OPs can bypass proof preparation through schema prose.** A clean Type record received the exact project-specific receiving relationship in `inputs.schema.description` on its fresh Latent assignment. This is demonstrated input contamination; no live-model copying is claimed. | [Semantic details S2](2026-09-09-system-review-evidence/semantic-details.md), `intake.py:213–216`; [output](2026-09-09-system-review-evidence/semantic.log) |
| R08 | P2 | **Similarity conflates distinct owner-qualified joins.** Native and Latent references to different owners' same-named joins became `11`; qualification was removed and a spurious Element was emitted for the join reference. | [Service details](2026-09-09-system-review-evidence/service-details.md), `similarity.py:9,17–18`; [output](2026-09-09-system-review-evidence/service.log) |
| R09 | P2 | **Connecting another legacy project reverts shared schema edits.** After changing a service schema from string to number, adopting another project from the unchanged home silently restored string. | [Service details](2026-09-09-system-review-evidence/service-details.md), `knowledge.py:533–534`; [output](2026-09-09-system-review-evidence/service.log) |
| R10 | P2 | **Successful adoption omits project-local schema registrations.** A schema retained in the legacy project's `.metaform/schemas.json` became unavailable through the connected project's schema API. The original file survived. | [Service details](2026-09-09-system-review-evidence/service-details.md), `knowledge.py:533–535`; [output](2026-09-09-system-review-evidence/service.log) |
| R11 | P2 | **Fresh built-in prompts teach the superseded merged-graph model.** Native, Proof, and Latent assignments all contained the obsolete glossary sentence; none contained the current independent-graphs/structural-similarity explanation. | [Semantic details S3](2026-09-09-system-review-evidence/semantic-details.md), `glossary.md:20`, `prompts.py:46–60`; [output](2026-09-09-system-review-evidence/semantic.log) |
| R12 | P2 | **An incomplete dependency referenced only by a join is not scheduled.** Intake completed A→B with an empty queue while globally admitted B still had no completed inference. A's focal completion is valid; the missing B assignment is the defect. | [Semantic details S4](2026-09-09-system-review-evidence/semantic-details.md), `intake.py:391–392`; [output](2026-09-09-system-review-evidence/semantic.log) |
| R13 | P2 | **A back transition into foreach skips the new pass.** After answering “repeat,” execution returned to the decision step without issuing the item work because the old iteration index survived. | [Runtime details §3](2026-09-09-system-review-evidence/runtime-details.md), `workflow.py:370`; [output](2026-09-09-system-review-evidence/runtime.log) |
| R14 | P2 | **An in-flight MCP answer fails after another module takes control.** A valid workflow response was rejected as `Unknown command: workflow.answer` after intake became active. The captured answer was dispatched through the current unbound router. | [Runtime details §4](2026-09-09-system-review-evidence/runtime-details.md), `mcp_server.py:247`; [output](2026-09-09-system-review-evidence/runtime.log) |
| R15 | P2 | **Small divergent reified graphs can make similarity excessively slow.** Eleven joins per source took 30.05 seconds in the initial fixture and 26.74 seconds in the primary-reviewer repeat. Equivalent-leaf permutations dominate the matcher; cost depends on structure and order, not simply graph size. | [Service details](2026-09-09-system-review-evidence/service-details.md), `similarity.py:112–140`; [bounded repeat](2026-09-09-system-review-evidence/similarity-cost.log) |
| R16 | P2 | **Absolute internal module symlinks break after export.** All handler bytes were bundled and export reported no unresolved items, but the imported handler still pointed into the unavailable source directory. | [Portable details](2026-09-09-system-review-evidence/portable-details.md), `portable.py:95–97`; [output](2026-09-09-system-review-evidence/portable-history.log) |
| R17 | P2 | **Portable workfolder application cannot replace a directory with a file.** Applying the reviewed change raised `IsADirectoryError`; the inverse file-to-directory control passed. | [Runtime details §5](2026-09-09-system-review-evidence/runtime-details.md), `workfolders.py:274`; [output](2026-09-09-system-review-evidence/runtime.log) |
| R18 | P2 | **Image generation can report success with an old or unrelated image.** Injected successful process responses caused an ancient stdout-mentioned PNG, an untouched recent output, and another session's image to be accepted. | [Image details](2026-09-09-system-review-evidence/imagegen-details.md), `modules/_imagegen.py:389–402`; [output](2026-09-09-system-review-evidence/imagegen.log) |
| R19 | P2 | **Latent image operations use the project instead of the assignment workfolder.** Real intake/batch routing prepared output in the project and failed to find an input that existed in the assigned folder. | [Image details](2026-09-09-system-review-evidence/imagegen-details.md), `modules/imagegen.py:20–25`; [output](2026-09-09-system-review-evidence/imagegen.log) |
| R20 | P2 | **Viewer startup returns a dead URL after a crash.** The healthy server served all inspected routes; after controlled termination, another serve call returned its stale ready-file URL and connection was refused. | `modules/viewer.py:9–11`; [probe](2026-09-09-system-review-evidence/viewer_probe.py), [output](2026-09-09-system-review-evidence/viewer.log) |
| R21 | P3 | **Failed image-provider readiness remains cached after remediation.** Status reported ready after a healthy probe, but generation continued to raise the previous missing-dependency error in the same process. | [Image details](2026-09-09-system-review-evidence/imagegen-details.md), `modules/_imagegen.py:197–203,714–716`; [output](2026-09-09-system-review-evidence/imagegen.log) |

Detailed reports preserve source expectations, reproduction steps, causes, consequences, and repair directions. Several failures share an important pattern: the lower-level component works, but an adapter loses the context needed to use it correctly. Examples include a parent's workfolder disappearing at a parallel branch, qualified identity disappearing during similarity, and project schema scope disappearing during global export.

R20's repair direction is to verify the viewer's actual liveness before reusing its saved endpoint, recover stale discovery state after a confirmed dead instance, and retain ordinary reuse for a live viewer. The new knowledge service already has substantial liveness coverage; the older viewer startup path remains separate.

## Areas of focus

1. **Protect the work and the retained knowledge from demonstrated integrity failures.** Address R01–R06 first. Preserve workfolder context across parallel execution, make archive writes respect the extraction boundary, apply exclusions consistently to Git origin, export actual global schema ownership, preserve already-qualified reused join identities, and bind workflow operations to their issued assignment. Each has a small reproducible witness already saved.

2. **Make semantic preparation and graph comparison agree with the maintained contract.** Correct the active obsolete source in R11 and account for stored built-in revisions through the established migration mechanism. Address R07's schema-context route, R12's dependency scheduling, and R08's qualified comparison. These affect what later inference is asked to understand and what knowledge it can reuse. R05 also belongs in this group because lost relationships change that starting understanding.

3. **Complete the migration and execution paths users will encounter.** R09/R10 need schema-aware adoption with owner preservation and the feature's existing source/conflict policy. R13/R14 need per-execution loop state and captured assignment dispatch. R16/R17 need ordinary portable module relocation and directory/file transformations to work. R20 needs viewer restart recovery.

4. **Resolve the measured performance and output-attribution problems.** R15 calls for avoiding equivalent mapping permutations while retaining exact structural comparison. R18/R19 require generation results and file paths to remain attributable to the actual invocation and assigned folder. R21 needs readiness refresh to affect the state used for generation.

5. **Then obtain a current semantic end-to-end demonstration.** Work through SPEC A-5–A-8 with actual model-produced results: branch-scoped Encounter propagation, one general instruction producing differentiated Type reasoning, preservation of authored specialization behavior, and refactor/porting guidance through the represented relationships. Retain effective prompts, rules, schemas, assignments, answers, resulting records, and subsequent use. These demonstrations would answer a different question from the passing fixture suite.

The last group is an evidence need for the product's central purpose. It is not a proposal to add a runtime gate or redefine the open-ended operation surface.

## Whole-system coverage

| Area | Review and observed state | Remaining limit or follow-up |
| --- | --- | --- |
| Authority, primers, semantic rules, worked explanations | Compared canonical definitions, source provenance, active role text, rulebook and status; exposed R07/R11 | No earlier conversations retrieved; broader contextual OP contents remain a recorded open question |
| Native intake, proof, Latent preparation | Traced effective assignments, snapshots, correction and preparation; existing handoff tests pass | R07/R11/R12; no new live Native/Latent model trial |
| Global completion and reuse | Reviewed ownership, focal completion, dependency lookup and project import; receipt tests pass | R05 and R12 |
| Graphs, backends, joins, similarity | Reviewed SQLite/JSON/Ladybug source behavior, reified traversal, owner qualification and scale cases | R08/R15; large-corpus ordinary mutation cost remains a documented limitation |
| Shared service and transactions | Real lifecycle, competing starts, request receipts, response-loss recovery and analytical-copy checks pass | R09/R10; no claim of exhaustive crash testing or multi-host operation |
| Project selection and migration | Reviewed registration, moves/copies, session/tab context, adoption and source preservation | Schema migration failures; new browser interaction could not be completed |
| CLI, manifests and drop-in modules | Reviewed discovery, routing, takeover, raw input and always-available command integration | R06/R19 and offline module link failure |
| Prompts, rules, schemas and specialization | Reviewed seeds, effective registries, snapshots, workflow conversion and preserved authored text | Active semantic drift, schema ownership/context; no live specialization quality result |
| Workflow engine and continuation | Reviewed conditions, back edges, nested/parallel calls, receipts and exact context | R01/R06/R13/R14 |
| Harnesses and actor bridge | Real fixture subprocess and CLI/MCP transports exercised | No configured authenticated live Codex/provider harness supplied |
| Workfolders and retained changes | Standard creation/report/apply tests pass; real parallel child and JSON transformation probes performed | R01/R17/R19 |
| Workbench and activity | Reviewed routes, project prefixes, source edits and JS; live page/API HTTP checks pass | R20; no fresh visual/mobile/accessibility certification |
| History, export, import and portable runtime | Standard selected closure, historical dependencies, offline nested continuation and re-export pass | R02/R03/R16/R17 |
| Packaging, installation, CI and global sync | Fresh wheel/standalone and installed checks pass; current remote CI verified; local-only sync export inspected | R04; no remote contribution push, package publication or Windows execution |
| Image generation | Reviewed integrated and standalone code, provider probing, routing, output discovery and error paths; injected probes reproduced R18/R19/R21 | No paid generation, real provider authentication or image-quality test |
| Standalone prompt collection and examples | Inventoried and distinguished maintenance/future-workflow prompts from active bundled inference inputs | Their presence does not imply runtime adoption; historical PNGs not visually re-reviewed |

## Known unfinished work and meaningful unknowns

The current work record already identifies intake/schema/storage reconciliation, leaf-alias resolution and address reservation, Parametric address reservation, missing Alias/Dependency rulebook content, and the descendant Description example. Source inspection is consistent with those remaining areas. Their presence should guide planned work alongside the new defects.

The missing inner `ed` field alone is not evidence of lost descriptions: `entity_desc` already carries ED. Focal inference completion is not supposed to certify every dependency; R12 concerns scheduling the missing dependency's own assignment. Structural `11` is not confidence or truth; R08 concerns incorrectly reporting structural agreement between different qualified targets. These distinctions materially change what a correct repair should do.

The [subsequent clarification](../semantics/artifacts-and-functional-intake.md)
settles contextual OPs as the actual project's receiving purposes. Some
prompt/workflow presentation choices remain open. The older discussion handoff describes a pre-service checkpoint; the later accepted shared-service specification settles its feature decisions. Historical alternatives or unanswered older design notes were not treated as current implementation defects.

This review did not establish live model quality, inference savings, omission reduction, or general refactoring/porting quality. It also did not determine whether any user's existing stored graph or project has already been affected by these defects.

## What is already useful

The source-separated storage, transaction receipts, independently retained prompt revisions, ordinary project selection, indexed selected export, and service-free nested continuation provide a substantial basis for completing the system. Their tests exercise real files, databases, subprocesses, HTTP and MCP rather than only mocked return values.

A useful next build would preserve that working base while resolving the concrete loss, routing, and semantic-input defects. The saved probes provide focused witnesses for those changes, and the semantic acceptance scenarios provide the next evidence needed for Metaform's intended higher-order use.
