# Global workbench and preview evidence

The source workbench now uses the persistent global service's process and port.
This report records focused checks during that change. The final integrated
Python/browser run and rebuilt distribution are separate coordinator checks.

## Corrected behavior

- Opening project URLs uses a request-local App and preserves project/store
  identity. Global landing, health and static routes work before any project is
  selected. Project operations without a selected URL return a clear error.
- Apps created inside the server use the owner's direct knowledge-client factory
  for construction, registration and project selection. The focused test rejects
  attempts to start a nested service or use RemoteKnowledge there.
- Explicitly opened legacy/portable project paths survive server reconstruction
  through the runtime catalog. They keep their existing stores and model data.
- Viewer launch returns the shared PID, port and instance. A stale per-project
  viewer is retired only through its matching ready/stop identity; an unrelated
  HTTP listener and its files remain untouched.
- Revision previews share the workbench listener. Their reconstructed folders
  remain separate by project/version, and stopping one project's previews does
  not stop another project's previews. Global close removes owned temporary
  reconstructions.
- A malformed inherited assignment value no longer affects an App explicitly
  constructed with `binding=False`.

## Reproduced defects resolved during review

The first project URL without a trailing slash returned HTTP 400 before Flask
could apply its redirect. The request boundary now permits that routing redirect;
both URL forms reach the selected project.

The first same-port preview let sandboxed authored JavaScript issue a no-cors POST
to `preview/stop`: the request returned HTTP 200 and removed the preview. Browser
mutation requests now reject an opaque or unrelated Origin before project
selection. Requests from the actual workbench origin remain usable, and clients
without a browser Origin retain their ordinary API behavior.

The sandbox initially blocked authored ES-module imports because its opaque
origin could not read preview assets. Only preview file/listing responses now
allow those reads. Workbench APIs have no corresponding CORS permission.

## Focused verification

All checks used temporary projects/homes and explicit temporary
`METAFORM_RUNTIME_DIR` values on Linux. No live viewer was stopped by these tests.

| Checks | Observed result | Scope limit |
| --- | --- | --- |
| Global CLI, onboarding, installation and review-viewer set | 62 passed in 21.98 seconds | Preceded final preview and owner-aware lifecycle corrections. |
| `tests/test_global_viewer.py`, `tests/test_viewer_projects.py`, and the static-version preview test in `tests/test_next_version.py` | 20 passed in 5.27 seconds | Includes final preview headers and explicit-binding correction; does not replace real browser evidence. |
| `tests/test_execution.py::test_local_viewer_starts_and_stops_without_blocking_router` | 1 passed in 0.57 seconds | Updates the old per-project ID expectation; verifies shared service PID/instance, exact stop, readiness and continued router use. |
| `tests/test_project_context.py::test_service_inspection_uuid_selector_does_not_start_service` | 2 passed in 0.07 seconds | Updates old home-scoped mocks; verifies argumentless global status/stop, no project resolution and no home creation. |

An independent actual Chromium probe verified all of the following together:
authored inline JavaScript ran; a nested ES-module import returned `42`; the
preview had an opaque (`null`) origin; a workbench API read was blocked; a
text/plain graph mutation created no record; opaque-origin `preview/stop`
returned HTTP 403 and the preview remained available; legitimate workbench-origin
stop returned HTTP 200. The reviewer stopped that probe's isolated global owner
afterward.

The [global service evidence](2026-09-11-global-service-evidence.md) covers
multi-home ownership, startup/restart, exact package origin, accepted-operation
draining and invocation-environment isolation. Windows behavior and rebuilt
artifact delivery are not established by these Linux source checks.
