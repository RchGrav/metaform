# Actual v2 Foundation capture — 2026-09-11

These images show the published Native foundation produced by an actual Codex
intake of the isolated Metaform source snapshot. This is a new v2 account, not the
historical MGM sample or an illustrative fixture. No semantic graph was replaced
or manually corrected for the screenshots.

![Actual Metaform Native foundation](foundation.png)

[Connection inspector](foundation-connections.png) and
[browser requests, model/revision and inspected records](browser-evidence.json)
retain the view's identity. The pending outside assignment is visible above the
workbench; browsing succeeded while that workflow remained active. The wider
neighborhood uses panning or Fit all; the inspector preserves readable actual
and Type descriptions.

The model is `model:212a50ef20fc4417a1c7fdcd59bdf302` in project
`507e6759-7c6c-4a87-8b2d-50b33b40bb82`, revision
`59f6f8698977831419670f7aacf60aa75e475742266ddcab519858c9412e97d5`.
The live assignment, execution timing, immutable source-file hash manifest and
original generated records remain under
`.test-tmp/release-verification/live-self-intake`.

The capture uncovered two integration defects missed by small fixtures. Polling
full activity cost 12.873 seconds and serialized 29,196,610 bytes of events plus
6,562,461 bytes of worker context every five seconds, starving the serial viewer.
The dedicated handoff-status response measured 562 bytes in 0.286 seconds and
coalesces in-flight polls. Full stored worker instructions and explicit activity
remain available. Once this was corrected, active workflow mode still hid
`graph.neighbors`; the owning module metadata now makes semantic navigation
available while preserving bound workers' declared tool limits. The retained
[failure image](failure.png) records that second observed failure. A subsequent
real browser run completed model, namespace, layer, element and neighborhood
reads with HTTP 200 and no page errors.

These images establish the actual generated account can be inspected. They do
not certify every semantic judgment in that account. The first outside handoff
exceeded the host input limit. The actual retry then completed in 667.34 seconds,
published its report layer, and preserved the Native foundation unchanged.
[Execution metadata](outside-execution.json), [actual model response](outside-response.json)
and [publication result](outside-completion.json) retain that evidence. The eight
findings distinguish omissions from the functional representation, investigation
questions and implementation claims; they are not eight newly proven code bugs.

The [Native functional account](native-functional-account.json),
[source-file hash manifest](source-manifest.json) and
[combined execution record](live-execution-evidence.json) are retained beside
these images. The full raw runtime capture and original failed assignment remain
in the isolated execution directory identified by that record.


The actual outside retry then completed and published eight scoped findings in
667.34 seconds, with the original Native foundation unchanged. The
[outside findings view](outside-report-findings.png) and
[its exact browser reads](outside-findings-browser-evidence.json) retain the
completed report through `knowledge.get` on that original revision. The earlier
[outside knowledge overview](outside-report.png) shows inherited property rows
before scrolling to the generated report. The report's proposals remain
interpretive findings, not automatic implementation instructions.
