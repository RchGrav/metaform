# Metaform CI and fork setup

The repository is currently private while Metaform is tested and refined. CI
produces artifacts in the repository that runs it. Publication to a package
index, releases, or a public site is a separate operation.

## What the workflow does

`.github/workflows/wheel.yml` runs on pushes, pull requests, and manual dispatch.
It uses the current repository's checkout and locked dependencies. Both Python
3.11 and 3.13 run the source tests, build the wheel and extensionless archive,
and verify the installed package. The release check also creates an empty
Python environment to exercise the portable CLI/MCP, GUI, and export round trip.
Additional delivered-process checks exercise Ctrl-C with stdin still open,
blocked output and active handler/build cleanup; a whole-artifact workfolder
transfer and apply; and module customization, sharing and user-wait continuation
using the executable's own reference. Malformed custom module declarations are
also exercised through installed and standalone help/reference paths. Authored
retry/deadline checks verify failure recovery, unchanged negative answers and
one deadline across sequential phase workers. These checks use the fresh installed
interpreter, separate disposable project homes, and cleared source import paths.

The retained [CI diagnosis](reviews/2026-09-11-ci-review.md) distinguishes the
earlier installed-wheel check's obsolete assignment contract from product
failures. [Distribution evidence](release-distribution-evidence.md) records the
locally exercised artifact hashes; a local pass does not claim a remote run.

Each Python job uploads `dist/*.whl` and `dist/metaform` to its run artifacts.
There are no Metaform-specific secrets to copy into a fork. The workflow has
`contents: read` permissions and uses the standard artifact upload action.

## Activate a fork

GitHub workflows are disabled in newly forked repositories by default.
The owner can enable them in the fork's Actions tab or use the packaged helper:

```sh
gh auth login
metaform package ci --repository YOUR_ACCOUNT/metaform
```

From the fork's checkout, `metaform package ci` resolves its `origin` remote.
It does not use GitHub CLI's inferred upstream repository. Explicit repository
arguments also accept GitHub URLs. To build another branch:

```sh
metaform package ci --repository YOUR_ACCOUNT/metaform --ref work/semantics
```

The command reads the selected repository, reads its `wheel.yml` workflow,
enables that workflow if disabled, and sends a workflow dispatch for the selected
ref. Without `--ref`, it uses that repository's default branch. Its result
contains the repository, visibility, ref, and build/workflow URL. GitHub API
errors are returned as errors; requesting a build is distinct from the build
succeeding.

An agent can call the same handler through MCP:

```json
{"command":"package.ci","arguments":{"repository":"YOUR_ACCOUNT/metaform"}}
```

That is the `metaform` routing tool's input. Clients exposing individual tools
can call `package.ci` with the inner arguments directly.

## GitHub requirements

The workflow file must be present on the repository's default branch for manual
dispatch. During development, pushing a branch containing the workflow can run
its push-triggered CI before that branch is merged.

The GitHub CLI uses the owner's existing authentication. Fine-grained credentials
need **Actions: write** for workflow activation and dispatch; classic credentials
need the `repo` scope for private repositories. Organization and repository
Actions policies still apply. An Actions policy that disables the feature must
be addressed in the repository or organization settings by an authorized owner.

Private-fork pull requests also depend on the parent repository's fork workflow
policy. A build running in the fork and a pull-request build running in its
parent are distinct runs. The helper activates the selected repository's
workflow; it leaves the parent's policies to its owner.

## References

- [Events and forked repositories](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows)
- [Enable and dispatch workflows through the API](https://docs.github.com/en/rest/actions/workflows)
- [Manual runs and the default branch requirement](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)
- [Repository Actions settings and private forks](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository)
