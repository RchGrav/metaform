# Name

For constructing the Namespace and extracting the Element's proper name.

This rule was developed with Rich and accepted on 2026-09-09. It replaces the
separately authored Element Name with Namespace plus `length`. Version 2 records use Namespace plus `length`; historical `en` fields remain
available through the version 1 adapter. See the
[source discussion](../../semantics/names-receivers-and-variants.md#namespace-construction-and-recoverable-names).

## Concise form

The Namespace narrows in specificity as it extends. Use the Type’s most common universal name, expressed as a singular proper noun, and reverse its words into period-separated components.

Locate the position in the existing Namespace that speaks to the Element at its most general specificity. This position may occur within a more specific path. Reuse the components through that position, then append the remaining modifier components that identify the Element in its full specificity.

Record the number of words in the full name as `length`, including reused components. Extract the proper name by reversing the final `length` Namespace components and joining them with spaces.

## Expansion

### Worked example: reuse the general position

For example, given `code.system.driver.video` (**Video Driver**), placing
**Network Driver** locates `code.system.driver` as the appropriate shared position:

```text
code.system.driver
├── video      length: 2 → Video Driver
└── network    length: 2 → Network Driver
```

The semantic placement determines where the new modifier attaches. For Network
Driver, `length` counts both `driver` and `network`, even though `driver` was
already present.

## Earlier supplied rule and trunk example

The following source wording is retained verbatim as history for earlier
runtime seeds and records:

> The most basic universal name as a singular proper noun which places itself comfortably into the definitions of its children

Supplied `code` trunk:

```yaml
code:
  name: program code
  description: a set of precise instructions that tells a computer how to perform a task or process data
```

[Settled functional typology and encounter context](../../semantics/functional_typology.md)

The maintained roots and exterior naming exception retain explicit display labels.
