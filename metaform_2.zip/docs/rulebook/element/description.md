# Description

For defining the shared meaning of a Type in the Namespace.

The [artifact-intake clarification](../../semantics/artifacts-and-functional-intake.md)
distinguishes this Type definition from the Native description of an actual
artifact. Native descriptions explain that artifact's specific functions,
subjects, context, and receiving purposes. The supplied universal Type wording
below remains available for classification.

## Concise form

Define the Type with the most basic universal statement that uses ancestral proper nouns in reverse namespace order in a semantically proper statement, without naming or defining its child Encounters or Functions. The Type's description remains universal; the actual Element's description carries its particular account.

## Expansion

### Worked example

Supplied `code` trunk:

```yaml
code:
  name: program code
  description: a set of precise instructions that tells a computer how to perform a task or process data
```

[Settled functional typology and encounter context](../../semantics/functional_typology.md)
