# Rule seed sources

[The rule seed](../../src/metaform/data/rulebook.json) contains five records in
the [proposed rule format](format.md). `r1` through `r5` are neutral references;
they do not establish rule categories or a prefix taxonomy. Each record contains
actual rule content. Provenance belongs here, outside the inference context.

## Concise wording

| Record | Exact source | Status |
| --- | --- | --- |
| `r1` | [Name, Concise form](element/name.md#concise-form) | Accepted Namespace construction, reuse and reverse-name/length mechanism, copied verbatim in the current seed. |
| `r2` | [Description, Concise form](element/description.md#concise-form) | Realignment package grammar repair preserves ancestral proper nouns, reverse namespace order, universal Type meaning and exclusion of child definitions. Actual descriptions retain the particular account. |
| `r3` | [Functional typology, Leaf variants and transitive encounter](../semantics/functional_typology.md#leaf-variants-and-transitive-encounter) | Rich's complete transitive-linking statement, copied verbatim, including “effects”. |
| `r4` | [Inference Metaform Rules, Strict Typology](../semantics/inference_metaform_rules.md#strict-typology) | Maintained Type-qualification sentence, copied verbatim. |

| `r5` | [Namespace characters](../semantics/functional_typology.md#namespace-characters-and-dispatcher-correction) | Rich’s concise alphanumeric statement, copied verbatim. |

## Priming and examples

The [accepted Name rule](element/name.md#concise-form) specifies Namespace
construction and extraction through `length`. The current seed uses that accepted wording. Historical root examples retain
their explicit display labels.

Purposes and connecting explanations are assistant-authored expressions of the
sources below. They do not replace the established concise wording. Examples
and their reasoning remain available for refinement with Rich.

- **`r1`:** The accepted `code` Name and Description are the supplied worked
  example in [element/name.md](element/name.md). Its program-code interpretation
  is settled in [functional_typology.md, The code trunk](../semantics/functional_typology.md#the-code-trunk).
  The rejected Name `C++ program code` and its reason are an assistant-derived
  narrow counterexample: the Name would place the child encounter into the
  identity of the core function. This is not a historical rejected record.
- **`r2`:** The accepted trunk example is supplied in
  [element/description.md](element/description.md). The rejected version appending
  “including C++” is an assistant-derived counterexample to the exact rule's
  exclusion of child names and definitions. It is not a historical rejected
  Description. The context concerning backwards reading reflects Rich's
  clarification in the current conversation that the check operates within the
  definition; fluency alone is insufficient. The seed intentionally does not
  invent an accepted full child Description to demonstrate ancestral naming.
- **`r3`:** The first three paragraphs of context reproduce Rich's statements
  from [functional_typology.md](../semantics/functional_typology.md), including
  their spelling. The accepted `code.cpp` example follows that source.
  `code.cpp.cxx23`, the functional-branch explanation, and the rejected permanent
  role and reversed-relation examples express Rich's subsequent clarification
  in the current conversation: code is the trunk, cpp is the encounter when it
  is the leaf, and cxx23 is the encounter when it is the leaf attached to cpp.
  The example sentences and reasons are assistant-authored from that
  clarification. The supplied standards table is encounter context; its release
  descriptions are not treated as universal Element Descriptions.
- **`r4`:** Accepted and rejected paths come from
  [inference_metaform_rules.md](../semantics/inference_metaform_rules.md),
  specifically Programming Language, Interpret the Path, Not the Word, Encoding
  Names Are Not Banned, and HTML. Reasons preserve those distinctions, with
  “program code” reflecting Rich's settled trunk Name. The older Programming
  Language explanation also says “`code` refers to types of languages”; that
  characterization is not imported into the seed because the later settled
  [code trunk statement](../semantics/functional_typology.md#the-code-trunk)
  establishes program code. Its rejection of `code.language.cpp` as a taxonomy
  space filler remains applicable and is preserved.

- **`r3` and `r5`, dispatcher correction:** Rich supplied
  `code.dispatcher.command` as the correction to the inferred
  `code.command_dispatcher`, then confirmed alphanumeric components. The
  function/encounter explanation and example reasons are assistant-authored
  applications of that correction. The distinction between Namespace
  components and human-readable Element Names follows the established
  **program code** Name. Existing authored rules and prompt attachments are
  preserved on startup; the example project's rule attachments are explicitly
  updated for this review.

- **`r1`, comprehensive parent:** The handler and dispatcher examples apply
  Rich's explanation that the namespace must hold all handlers under their
  function, and that the rules aim to enforce determinism. Their context and
  reasons are assistant-authored applications of the existing Name rule. The
  runtime seed now uses the accepted Name wording linked above. Alphanumeric `commanddispatcher`
  is rejected for structural collapse, not for its characters.
