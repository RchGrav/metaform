# Rule format under development

Current design, 2026-09-07. The discussed shape now has a working schema
(`metaform:semantic-rule`) and [seed data](../../src/metaform/data/rulebook.json).
Its descriptions and examples remain available for refinement with Rich.

## Established meaning

Rich clarified the concise component:

> consise is NOT the complete semantic rule, its the concisely accurate rule that is accurate and concise but should be reinforced with examples and explanations

The expansion reinforces the concise rule with freeform context and accepted
and rejected examples with reasons. First exposure primes latent understanding;
later use in that context can rely on the concise rule with confidence.

Field descriptions use descriptive wording such as “The rule stated,” not
imperatives such as “State the rule.” This distinguishes schema descriptions
from imperative content carried by actual rule records.

Rules are reasoning building blocks. The Element Name and Description rules do
not define the format of a rule record.

## Proposed field descriptions

The values here describe the fields. They are not seed-record contents.

```json
{
  "rule_code": "The rule’s unique reference, expressed using lowercase letters and digits.",
  "purpose": "The reasoning purpose served by the rule and the context in which it applies.",
  "concise": "The rule stated accurately and concisely.",
  "priming": {
    "context": "Extra freeform context clarifying the concise rule’s meaning on first exposure, including nuance, reasoning, and distinctions supporting accurate interpretation and application.",
    "examples": [
      {
        "example": "An accepted example.",
        "assessment": "accepted",
        "reason": "The reasoning establishing how the example satisfies the rule."
      },
      {
        "example": "A rejected example.",
        "assessment": "rejected",
        "reason": "The reasoning identifying where the example fails the rule and why."
      }
    ]
  }
}
```

`priming` and `context` were proposed as clearer names for `expansion` and
`explanation`. `rule_code` and `purpose` were proposed in response to Rich's
preference for a rule code and purpose over a complex applicability structure.

## Identifier direction

Rich proposed letters followed by digits, potentially expressing a rule type
and index. The interpretation offered was `^[a-z]+[0-9]+$`, requiring both parts.
The schema uses that pattern. The meanings of prefixes and index allocation
have not been established. The initial `r1` through `r4` references do not assign
a prefix taxonomy.

## Working seed data

The reviewable seed-data file contains Name, Description, function/encounter,
and Type-qualification rules. The settled Name and Description
sentences are available verbatim in their rulebook entries. The function/encounter
source statements and supplied examples are in
[Functional typology and encounter](../semantics/functional_typology.md).
Any newly composed concise sentence or example reasoning needs to remain
distinguishable from Rich's established source wording during review.

The schema is registered alongside the existing schemas. Seeds are inserted
only when their rule IDs are absent, preserving edits. The runtime's
`metaform:rule` schema describes executable transition expressions;
`metaform:semantic-rule` describes this reasoning-rule format.

[Rulebook](README.md)
