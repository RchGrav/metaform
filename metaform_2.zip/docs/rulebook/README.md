# Rulebook

Rules attach to a task, or a process to complete a task. Each rule has a concise
rule and an expansion. The concise rule is the rule stated accurately and
concisely. The expansion conveys nuance, useful supporting explanation, and
accepted and rejected examples with reasons.

First exposure presents both to prime latent understanding so that later in the
same context the concise version can be used with confidence. The expansion
provides additional material alongside the concise rule.

The [rule format](format.md) records the field descriptions and identifier
direction. The [seed data](../../src/metaform/data/rulebook.json) contains actual
rules and priming material; [seed provenance](seed-sources.md) distinguishes
exact supplied statements from derived explanations and counterexamples.

Rules load as authored records under `rule:<rule_code>` using
`metaform:semantic-rule`. Startup adds missing seeds and preserves edited rules.

```sh
metaform rulebook get --rule-code r3
metaform rulebook prepare --rule-codes '["r3"]'
metaform rulebook put --rule @rule.json
```

Preparation includes priming by default. `--concise-only` requests concise
material for a context that has already received the priming. Automatic
assignment preparation always includes priming because a later workflow step
does not establish that the receiving agent shares an earlier context.

Prompt records and workflow steps can reference rules with
`"rule_codes": ["r1", "r2"]`. Prepared assignments contain exact rule content and
revisions in `rules`. Workflow frames retain these snapshots so later edits do
not silently change a running frame. Current v2 intake receives the exact
structural-semantics, namespace-authoring and aliases components selected by
`data/roles/composition.json`; its managed prompt has no default `rule_codes`.
Historical v1 preparation uses `r1` through `r5`. A rulebook array and a role
component are distinct delivery paths; an empty array does not mean the v2
assignment lacks semantic instructions. Existing authored prompt text is retained.

## Completing the Element schema

| Rule | Source |
| --- | --- |
| Name | [Name rule](element/name.md) |
| Description | [Description rule](element/description.md) |

The Name rule now records the wording developed with Rich and accepted on
2026-09-09: construct the Namespace at the appropriate semantic specificity and
use `length` to recover the proper name. The Video Driver / Network Driver
example illustrates reuse of a shared general position. The runtime `r1` seed
still uses the earlier formula; its wording and the supplied `code` / Program
Code example are preserved in the Name document's historical section.

The Description formula remains Richard Graver's supplied wording, preserved
verbatim. The [functional typology and encounter clarification](../semantics/functional_typology.md)
records the earlier trunk decision and supplied C++ examples. Trunk-name
reconciliation under the new extraction method remains part of the
[implementation work](../../feature-briefs/native-metaform-variants-implementation-plan.md).

The Element schema's `notes` field is freeform context shaping inference, not a
change log.

### Further rules to discuss

Aliases and Dependencies are additional rules for completing the Element schema.
Their existing source material is available in
[Aliases](../semantics/inference_metaform_rules.md#aliases) and the
[typological process](../../src/metaform/data/semantics/metaform-intake.source.md#part-2--the-typological-process).

The rule governing how rules are authored and presented—the “rule rule”—is also
for discussion.

[Semantic source rules](../semantics/README.md)
