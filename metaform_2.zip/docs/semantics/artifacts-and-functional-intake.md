# Artifacts, their functions, and contextual intake

Rich clarified this account on 2026-09-10. It supersedes the earlier framing
that made generic Artifact Type knowledge the description of everything in a
project. The [specification](../SPEC.md) carries the current contract.

The record-shape and intake-sequence examples in this dated account describe
the earlier implementation. Current intake begins with the artifact's exterior
Receiving Entity and its Operative Purpose, then identifies the Defining Element.
V2 separates actuals, Types and bindings and publishes one Native foundation;
see [knowledge and revisions](../knowledge-and-revisions.md) for its public flow.

## Artifacts and Types

Artifact Types remain useful for organizing the Namespace. The Native Metaform
describes the actual artifacts, their functions, and their specific receiving
purposes. The classification supplies a place for that understanding; it does
not replace the understanding with a generic account of the Type.

Native can first describe the actual system as a freeform diagram, account, or
structured content in the graph's `understanding` field, then describe the
Type structure that organizes it. This gives the system's actual understanding
room to take the form that explains it well.

An actual Element has its own identity and the open `metaform:actual-element`
shape. Its `entity_json_obj.description` holds its freeform detail, and
`type_ids` references the applicable Type namespaces. Several Types can
contribute to one actual Element's presentation; their definitions merge into
that same record's view. Type memberships do not create OP joins or additional
visual nodes. Separate actual things retain their own identities even when
they share a Type.

A Type retains the `metaform:element` shape, its Namespace address as its ID,
and its universal Description and single EF. Namespace placement and naming
are unchanged: specificity narrows along the path, and reversing its final
`length` terms recovers the Type's name. A Type can carry a model-authored
`svg` shape for its presentation. Types organize the actual records without
replacing their descriptions with the Type-level analysis template.

The input may be software, contracts, a story, photographs, resale materials,
or a collection containing several projects. Intake considers folder structure,
how material is stored in relation to other material, and whether an item is an
asset of another artifact or a standalone artifact.

## The Native walk

First identify the Defining Element, then its Receiving Entity and that
entity's Operative Purpose. Its loss would change what the artifact is. Its EF
summarizes the combined result the artifact provides, without making medium,
encoding, genre, or style its defining function.

Name the actual properties and hard requirements. Each receiving Element has
an OP for the EF supplied by a linked Element. Follow those relationships
recursively to describe the artifact through function and property. Roles live
in those meetings, on the joins belonging to the receiving entity's OP.

Property transitivity is settled: effects extend forward through named,
more-specific Elements in the applicable branch and backward toward the DE or
trunk. Bash on the installer and C++ on the game engine are both visible at
`code`, with their respective relationships intact.

## Exterior and external

Rich's boundary clarification:

> we can keep exterior to mean not part of the project, and external to mean its external to the funtionality but in the repo

**Exterior** means not part of the project. **External** means outside the
functionality being examined but still within the repository. Control or
ownership does not determine this distinction. An entity may supply an EF or
receive the artifact's EF; exterior does not mean only a customer or recipient.

The five trunks are `code`, `document`, `media`, `data`, and `exterior`.
Environment, person, group, system, and framework were offered as tentative
exterior subgroups. The external distinction does not introduce another trunk.

## Photographs and surrounding context

Infer the photograph's meaning from its visible contents and available context.
Related photographs, their folders, and similarly named files in a camera's
sequence can explain an occasion or relationship that one image alone does not.
A wedding-photo folder followed by photographs of a couple in Paris can support
an interpretation of the collection's occasion. The Native account can describe
that inferred context even without an explicit user-supplied purpose.

In Rich's couple-at-the-Eiffel-Tower example, the couple is the photograph's
Defining Element and the Eiffel Tower is a **Supportive Element**. In a portrait,
the person is defining. A scenery photograph can also have a salient subject,
such as a hawk or a donkey being led along an incline. The scenery classification
does not replace the particular subject and circumstances of the photograph.

A poor scene with loose coupling to the subject is not a Supportive Element
merely because it appears in the photograph. The
[used-product examples](../../media.photo.product.used/bad_results/explanation.md)
illustrate the distinction: the original red-fabric setting contributes little
context about the device, while the map and compass or the hand and trail
connect the scene to the subject's presentation. A plain lightbox can support
inspection through clear presentation. These are observations about the
supplied examples, not a fixed list of acceptable settings.

The intended artifact in that example is the used-product photograph itself,
with the particular device as its subject. The failed schematic and
documentation-card outputs changed the kind of artifact instead of improving
the photograph. The successful directions improve the subject's presentation
for resale while retaining its identity.

Rich suggested organizing a Grand Canyon image at `media.photo.scenery`, with
relationships describing its occasion, subject, and environment, for example
`ext.occasion.vacation`, `media.photo.subject`, and `ext.environment.arizona`.
A date or season may contribute to that account. These are contextual examples;
descriptions should differentiate the actual images. The importance of medium
depends on how it changes the reasoning required.

## Parametric and Notable

Parametric is an array of a Type's tunables. It acknowledges those items and
reserves their names against being minted as Namespace Elements. A Parametric
adjustment does not by itself constitute acceptance.

Notable is retired as a separate category. An OP already explains why an
Element participates; its Element and joins express that relevance.

## Native understanding and latent reasoning

The Native Metaform is the project's Inference Metaform. Latent reasoning can
be invoked on that understanding at any time. The latent agent receives the
complete Native structure and its descriptions, including the Elements, joins,
receiving entities, and OPs. It reasons from outside the implementation frame,
without examining the repository's code or becoming involved in its particulars.

The latent agent can agree with the functional account, disagree with it, or
identify missing relationships and requirements through its independent
reasoning. These describe the reasoning it performs; they do not prescribe a
new result schema or replace the structural similarity operation. Global reuse
is separate from the primary purpose of understanding the project.

## Historical implementation status — 2026-09-10

The following records the earlier v1 runtime. New v2 intake publishes one Native
foundation and invokes outside analysis on request as attached knowledge. The
`metaform:actual-element`/`type_ids` examples above describe preserved v1 storage;
v2 uses actual records and separate Type bindings. See [current work](../current-work.md).

Intake constructs Native understanding and then supplies it as one
complete graph to a fresh Latent assignment. `intake.examine` repeats the
examination against saved Native understanding. The existing graph representation
retains source attribution; ordinary intake stores its Latent results locally.

The opening role instruction precedes the particular task:

> You are about to be given a task that will involve you reasoning directly against your latent space, so please preserve this context throughout this process.

MCP carries this in its system-prompt channel. Codex carries it in the supported
developer instruction channel before the user task; this does not replace
Codex's system instructions. The complete Native account is the material being
examined under that initial outside-reasoning role. This is the intended
behavioral separation, not a claim of literally removing contextual influence.
