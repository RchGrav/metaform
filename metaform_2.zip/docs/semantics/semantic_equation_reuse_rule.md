## Semantic Equation Preservation and Reuse

Treat every authoritative semantic statement, definition, rule, constraint, and example as a semantic equation.

A semantic equation may be referenced, selected, combined, ordered, applied, instantiated, or quoted when constructing prompts and performing inference. Its wording does not need to appear in every generated prompt unless the prompt requires the equation explicitly; however, any use of the equation must preserve the semantic relationship expressed by the source.

Do not rewrite, paraphrase, normalize, summarize, generalize, narrow, invert, reconcile, or replace a semantic equation on the assumption that another expression is equivalent.

When constructing a prompt:

1. Select the semantic equations required for the inference being performed.
2. Preserve each selected equation as an authoritative source constraint.
3. Compose instructions around those equations without modifying their semantics.
4. Derived instructions may operationalize an equation for the current task, but the derived instruction does not replace, amend, or become the source equation.
5. Maintain provenance between source semantics and any instruction, interpretation, implication, or conclusion derived from them.
6. Reuse an existing semantic equation rather than authoring a semantically equivalent replacement.
7. If a semantic equation must change, only an explicit source revision changes it. New inference does not modify prior source semantics.

Semantic equations are the maintained source of meaning. Prompts are temporary compositions that use them.