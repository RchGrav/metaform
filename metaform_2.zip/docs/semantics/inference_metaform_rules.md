# Inference Metaform Rules

## Metaform

A **Metaform** is a single-layer non-manifold mesh of type knowledge shaped to orient inference toward the expertise through which something is understood and acted upon.

## Latent Metaform

A **Latent Metaform** is a metaform representing the global, foundational form of expertise derived from the AI’s core parameters, free from immediate environmental influence. It serves as the baseline structural anchor.

## Contextual Metaform

A **Contextual Metaform** is the structural form of understanding that emerges when the AI operates *within* a specific project, environment, or prompt constraints. It contains the localized insights—and the accompanying blind spots—of that situational bubble.

## Inference Metaform

An **Inference Metaform** is the combination of the **Latent Metaform** and **Contextual Metaform** into a single non-manifold mesh of type knowledge.

---

# Metaform Typology

## Strict Typology

The namespace is a **strict typology**.

It does not follow a:

```text
domain.class
```

structure and it is not fixed length.

**Domain and class do not exist. Type and subtype do exist.**

Every section of the base, trunk, branches, and leaf must be interpretable as a type.

The base is a type.  
Every part of the trunk is a type.  
Every part of a branch is a type.  
The leaf is a type.

For:

```text
a.b.c
```

each part must qualify as a type:

```text
a
a.b
a.b.c
```

**To be a type, it must describe an encounter or a function, never an encoding.**

Full inference amortization by the archeologist must involve walking back from the leaf to the trunk and ensuring that each part of the chain is speaking to a specific type sprung from its parent.

A namespace component does not exist as a space filler to ensure alignment in a taxonomy namespace.

---

## Type Qualification

To be a **type**, it must describe an **encounter** or a **function**, never an **encoding**.

This qualification applies at every level of the namespace.

The word alone does not establish whether it qualifies. The meaning expressed by the path does.

---

## Singular Type Naming

The namespace is singular only.

```text
document     <- valid
documents    <- not valid
```

We are speaking to the singular type.

Namespace nouns are singular in form and proper.

The namespace names the singular type of **function or encounter**, never the singular deliverable work piece.

The type is singular in form and names a group in function.

---

## Function and Encounter

Types are either **function** or **encounter**.

An **encounter** speaks to a variant of something that has the same function.

Genre, style, and language are types of encounters.

### Game Genre

```text
code.game.platformer          <- valid
code.game.genre               <- not valid
code.game.genre.platformer    <- not valid
```

`platformer` is a genre of `code.game`. It carries the function of `code.game` as a specific genre with its own encounter.

`genre` is not the type.

The type is:

```text
code.game.platformer
```

---

## Programming Language

```text
code.cpp                <- valid
code.language.cpp       <- not valid
```

`cpp` is the encounter of `code`. It carries the function of computer code as a specific language with its own encounter.

The latter evokes a domain/class taxonomy.

`code.language` does not qualify because `code` refers to types of languages. `language` in the namespace is evoking class: a space filler to ensure alignment in the taxonomy namespace.

The Metaform Typology does not concern itself with that structure.

The type is:

```text
code.cpp
```

not:

```text
code.language.cpp
```

---

## Type and Subtype

While domain and class do not exist, the concepts of **type** and **subtype** do exist.

C++ is not a subtype of C because it is treated as its own language.

```text
code.c        <- valid
code.cpp      <- valid
code.c.cpp    <- not valid
```

---

## Interpret the Path, Not the Word

A namespace component is not interpreted by its word in isolation.

What matters is what the path is speaking to.

The same word can participate in different paths with different meaning.

The qualification remains:

> To be a type, it must describe an encounter or a function, never an encoding.

For example:

```text
document.word            <- not valid
```

speaks to the **Word document**, not to the program named Word.

The fact that `word` is also the name of a program is not the reason the path does not qualify.

The Word document remains an encoding or format distinction and does not describe an encounter or a function.

---

## Encoding Is Not Expressed

Format is neither a type nor a style. It is an encoding.

The Metaform Typology does not carry encoding in the namespace.

```text
jpg    <- encoding
png    <- encoding
```

Markdown is not a type of document. It is an encoding or format.

Word documents remain an encoding.

HTML under `document` speaks to the way written content is encoded.

Therefore:

```text
document.word            <- not valid
document.html            <- not valid when speaking to document encoding
```

These paths do not qualify as types because they describe encoding rather than encounter or function.

---

## Encoding Names Are Not Banned

Encoding names are not banned from the namespace.

The rule is not:

```text
jpg = not valid
png = not valid
```

The rule is:

> To be a type, it must describe an encounter or a function, never an encoding.

If the function is encoder or decoder, an encoding name can be used because in that form it is a **function**.

Examples:

```text
code.converter.image     <- valid
code.encoder.jpg         <- valid
code.encoder.png         <- valid
```

These paths describe functions.

`jpg` and `png` are encodings, but the paths are not expressing the encoding as the type.

---

## HTML

HTML demonstrates why the word itself cannot determine the type.

Placed under `document`:

```text
document.html            <- not valid
```

HTML speaks to the way written content is encoded.

The typology does not deal with encoding, only function and encounter.

Placed under `code`:

```text
code.html                <- valid
```

HTML can be valid because HTML is technically considered a language. People learn HTML as a language.

In that form it describes an encounter.

---

## Embedded Code

HTML can contain JavaScript.

Word documents can contain interactive code.

That does not make the document itself code.

Word documents remain an encoding.

HTML under `document` can speak to document encoding while HTML under `code` can speak to HTML as a language.

---

# Aliases

Aliases are required semantic runs of the namespace.

They must be preserved because they teach the distinction between the type and alternate names for that type.

All **metatype records** contain an `aliases` array. The purpose of this array is to prevent duplicates and ease searching.

## C

```text
code.c
code.c.c11
code.c.11                <- alias
```

## C++

```text
code.cpp
code.cc                  <- alias
code.cxx                 <- alias
code.cplusplus           <- alias
```

## C++11

```text
code.cpp.cxx11
code.cpp.cpp11           <- alias
code.cpp.11              <- alias
```

The alias forms do not replace or restructure the typology represented by the primary path.

## Intake clarification — 2026-09-08

Rich's supplied clarification:

> you also need the alias array, for the leaf (last word in the schema)   the most basic universal aliases that would likely be searched last part of the name space in alphanumric only, the purpose is to eliminate double entry and ease searching the name space they block those aliases from being used by other elements

> yes names can be reused they only reserve them at that specific address

---

# Required Semantic Runs

These examples are semantic equations for inference, not disposable illustrations.

## Strict Typology

```text
code.cpp                         <- valid
code.language.cpp                <- not valid
```

## Genre Encounter

```text
code.game.platformer             <- valid
code.game.genre                  <- not valid
code.game.genre.platformer       <- not valid
```

## Document Encoding

```text
document.word                    <- not valid
```

## Context Changes What the Path Expresses

```text
document.html                    <- not valid when speaking to document encoding
code.html                        <- valid when speaking to HTML as a language
```

## Encodings

```text
jpg                              <- encoding
png                              <- encoding
```

Encoding itself does not qualify as a type.

## Encoding Name Used in a Function

```text
code.converter.image             <- valid
code.encoder.jpg                 <- valid
code.encoder.png                 <- valid
```

## C Aliases

```text
code.c
code.c.c11
code.c.11                        <- alias
```

## C++ Aliases

```text
code.cpp
code.cc                          <- alias
code.cxx                         <- alias
code.cplusplus                   <- alias
```

## C++11 Aliases

```text
code.cpp.cxx11
code.cpp.cpp11                   <- alias
code.cpp.11                      <- alias
```

---

# Archeologist Rule

For a proposed namespace path, walk backward from the leaf to the trunk.

At every point in the chain, ensure that each part is speaking to a specific type sprung from its parent.

At every point, the type must qualify by describing:

```text
encounter
```

or:

```text
function
```

never:

```text
encoding
```

Do not impose:

```text
domain.class.type
```

Do not impose fixed path length.

Do not insert class terms to make a taxonomy align.

Do not determine validity from the isolated word.

Interpret what the path is speaking to and determine whether it describes an encounter or a function, never an encoding.

The namespace is a strict typology.

---

# Element

**Element** as a term speaks to a type.

Its further role in the general organization remains to be defined.