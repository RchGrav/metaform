# Names, receiving purposes, and Native Metaform variants

This records Rich's 2026-09-09 design discussion. Quoted statements retain the
supplied wording. The [canonical specification](../SPEC.md) incorporates the
agreed behavior; the [feature specification](../../feature-briefs/native-metaform-variants-specification.md)
and [implementation plan](../../feature-briefs/native-metaform-variants-implementation-plan.md)
separate that behavior from current implementation and remaining design choices.

The [2026-09-10 clarification](artifacts-and-functional-intake.md) updates the
boundary, actual-artifact framing, and Parametric/Notable account below.
Earlier quotations remain a record of the discussion.

## Namespace construction and recoverable names

Rich established that Namespace components are singular and proposed recovering
the common name through reversal:

> I think with the spaces it might possibly add confusion in edge cases, that being said, we could make the namespace rule to require the most common universal name to be reversed with periods and then attaches where its most appropriate

> and then add a field called length to say how many words it was

> and if what you are adding into the namespace is network driver and code.system.driver  exists you put network length 2

> This is essentially what we are doing but it also defines a method to extract the proper name from the namespace

Rich refined the placement method:

> You can add into that (if not already stated) the name space narrows in specificity locate the part in the namespace that speaks to its most general specificity, then append the modifier that identifies the element in its full specificity

> you might even want to add video to the end of driver to illustrate it isnt about just appending

The resulting [Name rule](../rulebook/element/name.md#concise-form), including
the sibling Video Driver / Network Driver example, was accepted with:

> thats a perfect rule I think

The rule replaces a separately authored Element Name with a name derived from
the Namespace and `length`. It counts all components belonging to the name,
including components reused from existing ancestry. Reconciliation of older
records and trunk names is implementation work; it has not been performed by
this documentation update.

## Exterior and the DE's upstream receiving purpose

Rich identified the upstream Receiving Entity and its OP as crucial project
understanding and a critical intake step, then proposed:

> it should probably be a record type just for that purpose that attaches to the defining element

> I think we should make another trunk type for this called exterior, which can have person, group, project   something like that inside of it

At this point in the discussion, he described `exterior` as:

> we need something that can mean system or project, because that is certainly an influence on interneal decision makingh its just not under our control, and the best word I can find that reasons on that is exterior

> the receiving entity for the defining element

> its not subject to the same read backwards requirement because its describing our authoritative boundary, but its something the artifact must satisfy

The receiving-purpose record retains the receiver and its OP for the DE's EF.
Its attachment to the DE preserves the OP's ownership by the receiver.
The subsequent clarification defines exterior as not part of the project and
external as outside the examined functionality but still within the repository.
An exterior entity can provide an EF as well as receive one.

Earlier exploration considered whether group covered person. Environment,
person, group, system, and framework were subsequently offered as tentative
exterior subgroups. Exterior remains lightly defined and exempt from the
reverse-reading requirement; `group.player` can naturally read as Player Group.

## Typing belongs to the receiver's OP relationship

After discussing Defining, Notable, Parametric, and Stylistic, Rich corrected
the proposed placement of those classifications on Element records:

> These are types of operative purposes for the receiver..      when code.game has an operative purpose for code.cpp that operative purpose is a property, of type medium, not a dependency, a dependency is like how code.game needs code.game.rules

This places the use expressed by a relationship on the receiver's OP join.
The subsequent clarification retires Notable as a separate category and defines
Parametric as a Type's tunables array, reserving its names against Namespace
Elements. Tuning alone does not constitute acceptance.

| Receiver | Element providing the EF | OP relationship | Type supplied |
| --- | --- | --- | --- |
| `code.game` | `code.cpp` | Property | Medium |
| `code.game` | `code.game.rules` | Dependency | Unspecified |

Rich also established general placement and relational use:

> and also names should be linked at their lowest possible general think and then link other parts of the namespace in and tyhose joins are what define how the thing its linking is used.

The Type is placed at its most general accurate position; OP joins express how
the receiver uses the linked Elements' EFs. The examples above preserve the
addresses used to explain the relationships. They do not settle the common
name or `length` of every example Type.

## Native understanding, comparison, and variants

Rich first described a porting template as a difference from the Native Metaform:

> right, so if the task is to port the project then you could create a template metaform from the native metaform which is like a diff.. and the diff metaform replaces code.cpp with code.javascript for instance

> Maybe like a varient of a base metaform

He then settled the operative model:

> So it can just make a clone of the native metaform..     the native metaform is what represents the project understanding ...   you can ask for it to evaluate the objects in latent space and joins to see if they are non issues or oversights, but if they are oversights that process should update the native metaform

Native refers here to the project understanding called the Contextual Metaform
in the canonical specification. A comparison operation reasons about latent
Elements and joins. When it identifies an oversight, it updates that Native
understanding. Both source perspectives remain independently available.

A variant is a clone of the Native Metaform. For the porting example, the variant
changes the game's Property / Medium relationship from `code.cpp` to
`code.javascript`.

## Regenerating affected understanding

Rich described what the changed relationship does to its reasoning:

> right which would detach any of the reasoning connected to code.cpp and code.game, but then the system would take the prompts that gave birth to that knowledge and ask them again

The subsequent explanation was accepted before Rich requested documentation:

> yes we need this in the docs and specs there is a spec writing prompt in prompts metaform if you want to follow that

The agreed operation detaches reasoning derived from the replaced relationship
in the variant, reissues its originating prompts against the changed semantic
context, and attaches the newly produced knowledge to the variant. Retaining
the producing prompt and the semantic relationships on which that knowledge
depends is necessary to carry out this operation. The concrete record layout
and dependency tracing remain to be designed.
