# Functional typology and encounter

Settled with Rich on 2026-09-07. The statements and encounter table below are
preserved from that conversation. They establish the context for the rulebook's
`code` example.

## Structure and encounter

> we are at our core a functional typology with encounter encoded in it..  When placing things in the metaform we need structure by using function and then extend it by linking the encounter.

## The code trunk

> code is program code settled..  its the function

The Name of `code` is **program code**. This supersedes the earlier
`programming language` Name in the handoff's trunk example. The discussion of
broadening `code` to collect other meanings of the word did not establish a new
trunk or new branches.

> code.cpp this is an encounter of code as a function...

The maintained [Programming Language rule](inference_metaform_rules.md#programming-language)
and [Aliases](inference_metaform_rules.md#aliases) provide the namespace examples.
`code.language.*` remains a bad inference.

## Leaf variants and transitive encounter

Rich's clarification:

> code.cpp is an encounter because its a leaf varient of its core function code

The direction in `code.cpp.cxx26` was made explicit:

> cxx26 is the encounter of code.cpp

The core function remains `code`.

> Metaforms deal with linking to core functions, encounters are realized by linking them into the graph as a transitive that effects all nodes back to the core function (its trunk) and forward through its branches.

## Encounters of code.cpp

Rich's supplied table uses namespaces and aliases relative to `code.cpp`.
Descriptions are reproduced as supplied.

| Namespace | Aliases | Description |
|---|---|---|
| cxx26 | 26, cpp26 | A forthcoming standard that is actively being drafted by the ISO committee, aiming to introduce contract programming, structural reflection, and linear algebra libraries. |
| cxx23 | 23, cpp23 | A refined modern standard that prioritizes developer convenience by introducing standard library modules (import std) and dedicated formatting utilities (std::print). |
| cxx20 | 20, cpp20 | A massive, transformative upgrade to the language that radically changed how developers write software through the introduction of Concepts, Coroutines, and Ranges. |
| cxx17 | 17, cpp17 | A mid-sized enhancement package that polished the language by standardizing filesystem access (std::filesystem), unpacking syntax (structured bindings), and type-safe unions (std::variant). |
| cxx14 | 14, cpp14 | A deliberate, stabilization-focused release that acted as a bug-fix and refinement cycle to patch omissions left behind by the prior major overhaul. |
| cxx11 | 11, cpp11 | A revolutionary milestone that completely redefined the ecosystem into "Modern C++" by introducing game-changing features like move semantics, smart pointers, and type inference via auto. |

> That table is a table of encounters of code.cpp as a function.

## Use in the rulebook

The example seeds understanding of the rules and demonstrates their application.
Its reasoning belongs in the expansion alongside the concise rule. Notes shape
inference; they are not a change log.

[Rulebook](../rulebook/README.md)

## Namespace characters and dispatcher correction

Rich's subsequent corrections:

> we shouldnt have underscores in names...

> if its a dispatcher make ity code.dispatcher.command

> we only allow alphanumeric

The corrected path has `code` as its core function, `dispatcher` as its
functional branch, and `command` as the leaf encounter of `code.dispatcher`.
Each Namespace component is alphanumeric; periods link those components.
This concerns Namespace components, distinct from human-readable Element Names
such as **program code**. It does not restore the historical alphabetic-only
restriction, since the established `cxx23` encounter contains digits.

## Comprehensive functions and deterministic construction

Rich explained why the naming rule preserves single-word Type levels:

> I mean thats why I made the rule that way so that the name space could be comprehensive and hold all handlers under that node

> this has a lot of reasons one it try to enforce determinism

The worked handler path is `code.handler.command`. The handler function is
comprehensive across its encounters; command specializes that function. The
same reasoning establishes `code.dispatcher.command`. Joining the words as
`commanddispatcher` would satisfy the character restriction while preserving
the structural collapse. These distinctions belong in the priming of the
existing Name rule, not in a new naming taxonomy.
