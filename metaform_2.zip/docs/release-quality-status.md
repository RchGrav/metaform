# Release-quality execution status

The user authorized implementation of all established repair work and adversarial scrutiny on 2026-09-11. This log records actual execution; the complete work inventory is in `repair-backlog.md` and the task plan is in `superpowers/plans/2026-09-11-release-quality-repairs.md`.

## Current repair and intake verification

**Latest correction:** Rich rejected the PongClock defining `code.clock.pong`
Type as genre in place of core function and requested low granularity. Prior
semantic acceptance of that model is withdrawn. The completed knowledge run
establishes execution/provenance only. Native prompt corrections are included in the current rebuilt distribution;
a new semantically reviewed intake has not yet established the corrected result.

The namespace and Ladybug follow-up is recorded in
[the current repair evidence](reviews/2026-09-11-namespace-and-storage/README.md).
Namespace selection now navigates to Type members and restores that view after
refresh; rendered-member visibility is verified separately from record counts.
Ladybug backend/Cypher/analysis-copy implementations, command/config registration,
and dependency/lock entries are removed. The separate blind-spot Analysis module
remains. The viewer reports active storage rather than preserved old settings.

The earlier candidate below is superseded by further user-identified defects.
Its test counts do not establish completion of these repairs or correctness of
the generated model. Current work is in the original `/home/rich/metaform`
checkout; the execution worktree is no longer the source of current changes.

- The public **Knowledge Tool** replaces Enumerator. Its intended workload is
  a generic node context and that node's complete applicable property composite,
  with the user's instruction retained for later reinference. There is no
  property power set or isolated-join inference. Current source has literal
  preview/generation controls and verified per-context dependency repair, including
  property addition, removal and changed meaning. A real PongClock generation completed after input-duplication repair: 66
  answers containing 198 instructions, with all attachment origins/dependencies
  matching the preview. The live browser retrieves them in the named layer.
- Fresh joins use `property` or `requirement`, the supplied `classification`
  catalog, and `is_soft` for non-transitive properties or optional requirements.
  The viewer uses declared classifications and their supplied colors. It labels
  particular records Elements. Old stored records are not converted to disguise
  their original meaning.
- The explicitly authorized flawed MGM intake records were removed with a
  targeted recovery export. Source files, settings, project registration, and
  history were preserved and their hashes checked. MGM itself was not deleted.
- Selected-record deletion now previews its structural and knowledge effects,
  preserves revision history, and supports reinference of affected attachments.
  Its focused source evidence is in
  [the deletion report](reviews/2026-09-11-selected-record-deletion.md).
- One persistent global server is running on port 44759 for shared RPC and
  workbench ownership across storage homes. Both identified old viewers were
  stopped using their verified instance markers; the old home service was
  drained and attached without changing its stored record counts or service ID.
  Slow project/home initialization no longer blocks unrelated routes, and
  managed prompt upgrades use one write. The rebuilt candidate passed installed CLI/MCP, 11 shutdown and six global
  lifecycle checks and now serves the same port. All 161 packaged files match
  the current source; live inspection found one persistent Metaform server. There is
  no idle shutdown requirement.
- Three actual Native trials used the supplied `pongclock.zip`. The first
  exposed missing managed rules/property coverage; the second generated
  synthetic property records. Their original evidence remains unchanged. The
  third completed with 14 Elements, 36 Types and 61 joins, reusing real Element
  identities for their property encounters. Independent semantic review and the
  live browser verify the principal account and declared relationship rendering.
  All five source files retain their original hashes. See the
  [PongClock trial report](reviews/2026-09-11-pongclock-intake/README.md).

These are established corrections, not new product decisions. Authoritative
shared base definitions (Q03) remain a separate unresolved definition item.
No new release-quality completion claim is made here.

## Earlier candidate baseline

- Original workspace: `/home/rich/metaform`, dirty source at HEAD `d264f51`.
- Execution worktree: `/home/rich/metaform/.worktrees/release-quality`, branch `repair/release-quality`.
- Original dirty diff, 21 untracked docs/test files, and governing instructions carried into the worktree. Original workspace preserved.
- Starting hashes/patch retained as `.worktrees/release-quality-start.json` and `.worktrees/release-quality-start.patch` in the original workspace.
- Existing dist hash: `24973b0df6614e498feca39f294f71f5b46164f9371a9cb0bb3a383665196ff2`; it predates the uncommitted source repairs.

## Earlier candidate integration evidence

The CLI, settings, module reference/guidance, shutdown, lifecycle, semantic access,
workbench, packaging, public module API and on-demand chassis account are
integrated into `/home/rich/metaform`, with the verified wheel and standalone
archive in `dist/`. All seven source prompts now have actual
model-produced conversions, independent source-semantic reviews, correction
journals and bundled executable definitions. Authored retry/deadline execution
and compact workflow progress have targeted source evidence. The final frozen
source run passed **884 Python tests** and **all four browser suites**, with
163 source/data/build hashes unchanged during execution. A subsequent three-file
cleanup removes remaining unconditional Sync/intake recommendations from the
viewer; its focused absent-module API/browser checks are recorded separately in
the [integration report](reviews/2026-09-11-final-integration-verification.md).
The corrected artifact also passed the complete installed/standalone verification
matrix on Python 3.11 and 3.13, the 44-call public customization journey and the
installed-wheel Sync-absent browser check. The original checkout's relocated
archive then passed the same 44 public calls using the available Python 3.10.12.
Its five standalone shutdown cases also passed, including Ctrl-C while stdin
remained open and while stdout was full; each interrupted process exited 130
in approximately 0.032 seconds. [Checkout delivery evidence](reviews/2026-09-11-checkout-integration.md)
records the copies, hashes, preservation checks and exact invocation logs.

All 397 reviewed source/documentation/evidence changes were copied after checking
that the original files had not changed since the starting snapshot. Earlier user
edits and protected instructions remain intact. The old two distribution files
are backed up; existing historical `dist/` directories remain. No commit, push,
global installation or public release was performed. This is a verified local
candidate with the evidence limits and two open entries below, not an assertion
that every release criterion has been resolved.

The [per-entry audit](reviews/2026-09-11-release-evidence-audit.md) retains all 84
established work entries. [Distribution evidence](release-distribution-evidence.md)
identifies each rebuilt candidate and its observed results. Fresh Python 3.11
and 3.13 installed checks, actual interrupted processes, portable workfolder
transfer and public customization have delivered-candidate evidence. Final wheel
and standalone SHA-256:
`2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027`.
Source fingerprint:
`e593dcbc2d7317fe1b57e79f536065f9461be4fb1c39308792498a8e05d0ecb4`.
All 161 packaged source files match the verified source bytes.

The current audit has **70 verified entries, nine with representative execution
evidence, three limited by unavailable host/model evidence, and two open
enumeration-investigation/definition entries**. These are evidence dispositions, not 84 claims of
universal correctness. The separate ten X proposal groups are not silently added
to this release's requirements.

An actual Native self-intake completed and its unchanged foundation is
[inspectable in the workbench](reviews/2026-09-11-live-foundation/README.md).
Its [semantic review](reviews/2026-09-11-native-semantic-review.md) records two
generated-record issues separately from runtime defects. The first outside
assignment exceeded the host limit because runtime audit bodies and the account
were duplicated. The actual retry completed in 667.34 seconds, published the
outside report, and preserved the complete Native foundation unchanged. A
[converted documentation workflow](reviews/2026-09-11-document-workflow/README.md)
also passed actual file production and later specialist reads, with independently
verified file hashes. Its bounded run does not claim execution of every later
source branch.

Applying a reviewed two-record semantic correction to a separate model preserved
the original and scheduled the appropriate outside reinference. It also exposed
duplicate full-history copies in storage writes. The same retained-store backup
write, measured with the same profiler, improved from 24.812 to 4.050 seconds;
history and record equivalence were checked. Independent review passed 62
storage/contract/foundation/transformation checks and verified input/read copy
isolation, transaction rollback and exact-request retry after an injected failure.

The earlier S09 disposition was premature. The 1,198,625 figure is the current
algorithm's output count on an archived MGM sample, not a validated required
workload. The [count audit](reviews/2026-09-11-enumerator-count-audit.md) finds
that 32 contexts around an exterior operator receive all 15 visible property
joins, contributing 1,048,576 slots by themselves. Visibility and actual
applicability differ; the existing authored trunk-summary case must also be
preserved when repairing selection. The [sample provenance audit](reviews/2026-09-11-mgm-provenance-audit.md)
records previous Latent assessment inside all 58 supposedly Native actual records.
S09 is an open semantic-scope/provenance investigation. Splitting assignments
(X04) is only a conditional proposal after the correct workload is established;
it is not currently a required user decision. Q03 still needs authoritative
shared base definitions and retains explicit diagnostics instead of fabricated
meanings.
Later sections preserve dated implementation observations and failures;
their earlier counts are not current completion totals.

## Checks during implementation

- Before packaging changes, 44 existing portable/dependency tests passed in 30.75 seconds in the isolated worktree: `tests/test_review_portable.py`, `tests/test_knowledge_dependencies.py`, `tests/test_portable_knowledge.py`. This is a regression baseline, not delivery proof.
- Independent backlog audit found all 50 R entries, 76 supplemental entries, and 28 former questions present exactly once, with 28 additional S work entries and six additional Q entries. Ten proposal groups remain separate.

## Scope decisions

- The bundled product concierge skill is within the user's explicitly requested R13–R16 repair. Its starting content is preserved in the original workspace and baseline patch. Revise that asset rather than introducing a second hardcoded bootstrap; protected host/repository collaboration instructions remain untouched.

## Task 3 source implementation evidence

- Retained assignment completion retires the matching marker and active nonce lookup while receipts and begin/assignment/answer events remain available. Cleanup compares project/run/request identity before touching a marker; a sibling binding is retained. Old completed markers are ignored when their recorded run state establishes completion.
- Whole-artifact snapshots include Git-ignored files for Git and plain-directory sources, independently of JSON/SQLite knowledge selection. Git supplies the baseline and binary diff when available; the common apply path verifies affected source entries before copying changes. The no-Git fallback uses the same artifact boundary. `.agentid`, `.metaform`, and Git bookkeeping stay outside changes. Legacy workfolders recover baseline metadata from their Git archive.
- Git history baselines normalize archive modes; unchanged files no longer become full first-checkpoint copies. Export dispatch selection excludes terminal runs and answered requests without deleting historical run state. Intake's synthetic lifecycle name is no longer mistaken for an imported workflow dependency.
- Running recursion inherits root-frame values plus explicit overrides. Missing Jinja values produce an explicit input error. `workflow.list` and `workflow.inspect` expose installed procedures; unbound answers require an explicit run ID. A CLI drive lacking MCP sampling reports that it did not execute.
- Authored `kind: user` steps persist as `awaiting_user` through the existing engine and receipt mechanism. Drive returns these for actual user interaction. The converter receives this primitive plus the complete implemented expression operators and assignment fields; workflow reference updated.
- Regression evidence: the initial eight data-integrity cases failed before changes; six recursion/user/discovery cases also failed before those changes. Expanded focused cases and existing runtime regressions passed **40 tests in 11.19s**. A broader run passed **126/128** execution/continuation/history/portable/project-context cases; the two failures were the CLI relocated-ID path and the now-obsolete completed-intake exception expectation, both reported to their owning lanes. These are source checks, not rebuilt-distribution closure.

## Source slices and independent review now in progress

These results are source evidence, not a declaration that the distribution or every backlog item is complete.

- CLI/settings/onboarding: 44 targeted checks passed before the next integration fixes. Module-owned guide handlers, read-only reference context, nested help, scope-safe settings and launcher preservation are implemented. Backend setting lifecycle and portable archive help are under review.
- Shutdown/service: 51 targeted transport/service/analysis checks passed. New adversarial probes reproduced both open-stdin and full-stdout Ctrl-C hangs; the shared streams now cancel normally. Idle release/restart, long active requests and exact replay across the idle boundary are covered. See `reviews/2026-09-11-shutdown-service-evidence.md`.
- Lifecycle: whole-artifact copy/diff/apply, retired ambient identity, durable historical receipts, sibling protection, recursion, user waits and workflow discovery have source regressions. Nested workflows within iteration are being exercised against real source procedures. The semantic worker is independently reviewing this lane.
- Semantics: 134 relevant checks passed, including 13 new public-operation/semantic regressions. Causal design dependencies, recorded relocation impact, Medium preservation, binary evidence, known parent recovery, participant context and layer recovery are covered. Real MGM read-cost findings are retained in `reviews/2026-09-11-semantic-evidence.json`; no additional cache was justified. Completion guidance is being reconciled with live module discovery.
- Workbench/examples: 25 viewer Python tests and four browser suites passed. The direct layout-toggle/click regression, persistent pending state through tab changes/reload/abort, fresh temporary demos and historical sample loader were exercised. Documentation synchronization is in progress.
- Packaging: six new packaging checks, 13 portable-review checks and 31 portable/dependency checks passed. Explicit source builds, changed-hash auto-build controls and nonblocking missing-module-import diagnostics are retained in `release-packaging-evidence.md`.
- Built-in reference: every current command now has argument descriptions, result descriptions and examples in its owning manifest. Mechanical schema checking found and corrected inconsistent example shapes and the missing nullable layer declaration. Handler/example accuracy and rendered usability still require independent review.
- Public customization: the public module facade and separate, on-demand chassis functional account are being implemented. Real corpus conversion has begun through the installed Codex harness, with stored assignments and raw generated outputs retained.

The shutdown worker independently reviews CLI/settings/reference. The CLI worker reviews shutdown/service and then the completed workbench slice. The semantic worker reviews assignment/workfolder/workflow lifecycle. Authors resolve substantive findings and reviewers verify the correction. A full source-suite integration run is in progress; rebuilding and exercising the distributed artifact remain required.

### CLI, reference, settings, and onboarding source repair evidence

The CLI lane reproduced help creating `.metaform`, home settings absorbing project overrides, active-mode help being swallowed as raw input, stale module guidance, and installer launcher overwrite before changing their shared paths. Source repairs now provide module-grouped help, read-only configuration/reference discovery, a no-argument starting page, module-owned aliases/bootstrap handlers, typed active-mode commands, readable terminal output with explicit JSON output, and concise dynamically discovered orientation. Installed skills contain the stable core; current module details come from the runtime. Module guide providers own intake, Best Practices generation/recovery, and layer selection.

Configuration defaults come from module declarations. Actual initialization creates missing scope files; updates recursively preserve unrelated settings, retain project-over-home precedence, and refresh the active application. Reference reports setting owners/defaults, file paths, effective values, nested sources, and actual versus pending graph-backend values. Existing graph backend migration remains the explicit `graph backend` operation; a generic settings write does not claim that open graphs have migrated.

Adversarial review found and repaired a real `--module` parser namespace collision, module-removal references on the starting page, parameterless alias parsers, wrong exit status for `--debug mcp`, and SQLite sidecars created by nominally read-only help. Broken configuration now leaves built-in help readable and reports the actual file. MCP project-selection registration bypass was returned to the transport owner and repaired there. MCP subprocess tests now explicitly import this worktree, rather than accidentally exercising the original editable installation.

Latest focused source results: `tests/test_cli_reference.py` 14 passed (2.39s); the preceding combined CLI/onboarding/installation run passed 35 tests (7.88s). These are source evidence, not distribution closure. Cross-lane source test results and rebuilt-artifact evidence are tracked separately. No public push or release was performed.

## Integration findings retained

The first complete source-suite integration run recorded **774 passes and five failures in 225.02 seconds** (`.test-tmp/release-verification/source-suite.log`). This ran while cross-lane edits were still being integrated. Failures were treated as work: literal generated instructions must not be reinterpreted as templates; prompt preview must retain its schema and missing-input diagnostics; historical glossary labeling must not change managed-prompt migration identity. The glossary labeling regression was subsequently corrected and its 13 migration checks passed.

Adversarial review additionally reproduced symlink replacement deleting files through the old target, omitted empty directories, stale nonces initializing missing projects, contradictory explicit assignment IDs being silently ignored, pending continuation disappearing after answer submission, archived reference creating a working copy, and reference triggering automatic builds. These remain tracked with their owners until independently verified.

Test isolation also needed correction: SDK subprocesses must explicitly receive the worktree source path, and every test now receives a temporary default `METAFORM_HOME`. One outdated marker fixture reached `/home/rich/.metaform` and started service instance `3e438ec9-4204-413f-8a11-3851f705996a` (PID 734039). The exact verified instance was stopped through the public service shutdown operation. Existing persistent home data was not deleted; no claim that all earlier tests left the real service home untouched is made.

## Lifecycle and real source-conversion review follow-through

Independent review reproduced and repaired symlink replacement deleting the old
link target, missing empty directories in workfolder snapshots and portable source
reconstruction, stale nonce indexes recreating missing projects, and malformed
ambient markers preventing CLI reference. Exact pending assignment identity is
checked before binding. The actual artifact verification lane then passed the
installed Git-workfolder → exported Python 3.11 portable copy → answer → apply
journey with ignored/binary files, links, permissions, rename/deletion and empty
directories.

Completed request dispatch files now move to project outputs after their executor
stops, while historical answers and receipts remain inspectable. Real subprocess
checks cover a receipt arriving before executor exit. Hand-offs use the loaded
Metaform installation rather than an embedding application's `sys.argv[0]`.
Existing pending assignments refresh only their returned launcher text; their
nonce, request, prompt and stored history stay intact. Four old tests that merely
asserted launcher strings built from fake caller paths were replaced by actual
empty-folder subprocess execution and distributed-artifact checks.

All seven root source prompts have actual Codex-produced conversion evidence in
`reviews/workflow-conversion/`, including stored assignments, unchanged outputs,
application receipts, and complete events. Packaging corrections are recorded
separately. Independent source review caught invalid template paths, truthy user
approval, a redundant coverage summary overriding measured coverage, omitted
remaining findings, an invented integration evaluator phase, and scheduler
completion despite missing planned task identities. The corrected procedures have
source-driven branch, specialist, iteration, artifact-context and user-wait
checks. One corrective test initially used the wrong Critic output shape; review
caught that proof gap and both the predicate and fixture now use the generated
`RESULT` contract.

The installed `workflow reference` command and the converter use one packaged
grammar. It includes the existing operators and assignment fields plus the
source-required `map`/`all` collection predicates and explicit authored phase
policies. Retry/deadline implementation and final distribution verification are
tracked by their respective owners. Host execution requirements and truly absent
source contracts remain visible in discovery. Actual model-produced artifact
execution is separate evidence; fixture-driven workflow runs are not presented as
proof that every external operation or generated implementation succeeded.
