# Serena: server and deployment reference

Reviewed the upstream implementation on 2026-09-07. These are reference notes
for discussion, not additional Metaform requirements.

Metaform's CLI remains sufficient to operate the system. Rich currently
envisions MCP as an optional way to browse the knowledge graph. The browsing
surface itself, and any role beyond it, remain to be discussed.

| Pattern observed in Serena | Relevance to Metaform |
| --- | --- |
| The installed `serena` executable provides both ordinary commands and `start-mcp-server`. | One installed tool can expose optional MCP without making it the only entry point. |
| Explicit client setup handlers register the installed command with supported clients. Initialisation reports detected clients and their setup commands. | Installation and MCP registration can be separate, understandable actions. |
| MCP supplies an initial connection prompt and tools derived from the active context. | A reference for discussing how graph-browsing tools could explain themselves; no additional workflow exposure is implied. |
| In stdio mode, the client starts the server and server teardown calls the agent's cleanup. For HTTP connections, disconnecting a client leaves the agent active. | Process ownership and the lifetime of a connection are distinct decisions. |
| The dashboard serves Flask in a daemon thread attached to an agent instance, binds locally by default, chooses an available port, and exposes a heartbeat. | A running web interface can report the state of the process it belongs to. |
| Agent state is published to dashboard listeners before the dashboard starts accepting requests. | The initial screen can describe actual state immediately. |
| Dashboard enablement and opening a browser are separate settings. | Running a server does not require launching a browser. Metaform already has the requested no-auto-open behaviour. |

The implementation is visible in Serena's
[CLI](https://github.com/oraios/serena/blob/main/src/serena/cli.py),
[client setup handlers](https://github.com/oraios/serena/blob/main/src/serena/config/client_setup.py),
[MCP factory and lifetime handler](https://github.com/oraios/serena/blob/main/src/serena/mcp.py),
[agent initialisation and cleanup](https://github.com/oraios/serena/blob/main/src/serena/agent.py),
and [dashboard](https://github.com/oraios/serena/blob/main/src/serena/dashboard.py).

## Project scope

Serena's normal MCP agent maintains one active project at a time. Its
[running guide](https://github.com/oraios/serena/blob/main/docs/02-usage/020_running.md)
explains that sharing a running HTTP instance among clients is appropriate
when they work on the same project.

There is also a separate
[ProjectServer](https://github.com/oraios/serena/blob/main/src/serena/project_server.py).
It serves read-only project queries, loads registered projects on demand,
caches them, and holds a lock while executing against its temporarily selected
project. This is distinct from the dashboard and from a general multi-project
editing service.

For Metaform, the useful design question is where project selection belongs
and which process owns ongoing work. Choosing that requires discussion; the
presence of a web server alone does not answer it.

## Deployment

Serena's [installation guide](https://github.com/oraios/serena/blob/main/docs/02-usage/010_installation.md)
uses a user-installed Python tool. Its running guide also documents source,
container, and HTTP options. The explicit installed-command registration is
the most directly relevant pattern to Metaform's user-local installation.
Metaform's offline, self-contained archive remains a separate existing
requirement when considering those options.
