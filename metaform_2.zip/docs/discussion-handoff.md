# Metaform discussion handoff

This note collects Rich's recent clarifications for an external agent helping
organize what needs to be conveyed back into Metaform's development. It records
understanding that had not yet been fully integrated into the specification or
runtime at the pushed checkpoint `7eab035`. It is a conversation handoff, not a
second specification or an instruction to implement the exploratory design.

Read the [specification](SPEC.md) for established definitions and the
[current work](current-work.md) for implementation status. Where the recent
clarifications below expose a mismatch, that mismatch needs reconciliation;
existing code and passing tests do not settle semantic intent.

## The purpose of the form

The graph expresses the system at the **Type level** because the Type level
speaks in the language of expertise. It represents functional Elements,
their relationships, and their purposes. That understanding supports reasoning
about the project and possible realizations beyond its present implementation.

Rich explains the name as **meta**, as in meta prompting, and **form**, as in
the form of the project. Prompts can address the represented form and its
information, allowing compact instructions to become precise project-specific
imperatives. The intended benefits are to eliminate hallucination, save
inference for higher-level reasoning, and make work specific enough that it
is not skipped. These are product aims, not demonstrated guarantees.

## Native and Latent Experts

The agreed names are **Native Expert** and **Latent Expert**. **Defining
Element** is the correct established term; the earlier substitution of
Intrinsic Element was a mistake. The existing definitions of Defining,
Notable, Parametric, and Stylistic Elements retain their operative meaning.

The Native Expert works within the frame of the project to identify its
Defining Element and the functional Elements it uses. These include Elements
realized within the project and those supplied by a framework it uses.

Rich's clarification extends beyond the wording of Element descriptions:

> “it speaks the structure of the project itself, its speaks about the
> functional elements on a more abstracted level”

The representation speaks to those Elements' own purposes, including locally
understood purposes. Files, source symbols, written functions, and descriptions
of the code itself do not belong at this level. The project provides evidence
for understanding its functional structure.

This distinction matters: project-local meaning can be expressed through
functional Types and their relationships. Rich corrected an earlier blanket
claim that nothing could speak to the project, then clarified the abstract
level at which it must do so. The precise representation of local Operative
Purposes still needs reconciliation with the current intake and handoff
implementation; the functional level itself has been clarified.

The Latent Expert develops independent Type-level understanding without the
Native project's OP relationships supplying its answer. Native and Latent
views support examination of bias and blind spots. Rich chose these expert
names partly to avoid the connotation of naming one expert “biased.”

## How authored prompts use Metaform

Project-resolved prompts depend on how they were authored before processing.
They refer to Metaform's structure and the information it contains to target
the work. Their authored operation determines how that information makes the
resulting imperatives specific to the project.

This clarification corrected the assistant's introduction of file and code
references into the explanation of Native intake. Project resolution does
not establish a requirement to place those references in the Native form.

Rich described these uses:

- Consider the Metaform object by object, including prompts concerning purpose.
- Produce checklists for points in the project, supporting inspection and remedy.
- Use Native and Latent views to expose and evaluate bias and blind spots.
- Support refactoring, deeper organization and analysis, and solving code issues.
- Evaluate a plan before implementation by comparing the shape it describes
  with the understanding available through Latent inference.

The opportunity is to collect reusable prompts applicable to both the resolved
project form and the independently inferred form. Rich described the potential
as a “universal improvement engine.” These examples communicate the intended
range of operations; they are not a closed catalog.

The assistant proposed distinguishing a prompt's instruction kind from how
it addresses the form: its subjects, relationships, perspectives, and required
information. That is a design suggestion awaiting discussion, not an agreed
schema. The last question about a formal prompt-resolution contract was not
answered before the repository checkpoint was requested.

## Prompt organization and workflow imports

Rich wants a solid GUI organization for prompts, including **intake prompts,
rule prompts, imperative prompts, and workflows**, with schemas developed
for them. The system should support importing workflows and working with
prompts processed into project-specific instructions.

The kinds, schema fields, relationships between source and processed prompts,
and GUI arrangement have not been finalized. Rich explicitly presented this
as a goal to understand before implementation. The newly added `prompts/`
collection was included in the repository push; its presence does not mean
these organization and processing capabilities have been implemented.

## Global knowledge, local data, and portability

Rich's stated direction is:

- **Global** is a system-level database.
- **Local** carries a project's own data. Its physical storage may also be
  system-level; project ownership and storage location are separate concerns.
- A project's Metaform can be exported portably, used on any harness, and
  reimported into the local project.
- Metaform maintains its own diffs independently of the project, with those
  diffs tied to project commits.

During intake, the Native Expert should use objects already available globally
when their Namespace addresses match. Missing objects are defined and proofed
and become part of the global database. Matching addresses should refer to
the corresponding established Type objects; local work uses those Types and
extends for what is missing.

An unanswered detail is what **extending** means in each case: adding missing
related or descendant Elements, enriching an existing global Type definition,
or both. No mutation, conflict-resolution, storage, or export schema has been
agreed from this discussion. The existing independently observable Native and
Latent graphs also need to be reconciled with this more explicit account of
shared global Type objects.

## Improving the workflows themselves

Rich sees a further opportunity if Metaform represents its own form and
understands its own rules: the provenance being collected could help identify
new ideas for improving the workflows. This connects the project's semantic
representation, reusable prompting, and observed work to improvement of the
system itself. The mechanism for proposing, evaluating, and adopting those
improvements remains exploratory.

## Implementation boundary at the checkpoint

The pushed checkpoint includes the Native/Latent Expert rename, Type-level
Element-description guidance, independently readable graph perspectives,
structural similarity, workflow specialization fixes, prompt migrations, and
Rich's prompt collection. The full suite passed **250 tests**, and the wheel
built successfully before the push.

The current Type proof step returns Contextual corrections separately from
prepared Latent inputs. It preserves Contextual records while preparing inputs
without Native OP relationships. A comparison favored the combined proof and
preparation call for preservation of semantic fields in the tested cases.
That comparison preceded the later clarifications above and does not establish
that the current separation expresses the final intended model. No subsequent
handoff redesign was implemented during the discussion.

The broader prompt organization, storage, portability, and workflow-improvement
discussion has not been implemented. Some underlying capabilities already
exist; the discussion does not certify them against these clarified goals.

## Working with this understanding

Semantic precision is central to the work. Preserve established terms,
definitions, and formulas; keep Rich's statements distinguishable from
assistant interpretations and suggestions. Clarify consequential ambiguities
in conversation before turning them into implementation decisions.

Rich wants the build corrected and the documentation surface kept tight.
This handoff was explicitly requested to help the external agent collect
critical understanding. Finalized decisions should be integrated into the
existing authoritative docs, avoiding a chain of alternate specifications
and deviation reports.

Rich's collaboration instructions are separate from behavior authored into
Metaform prompts. A correction to the assistant is not permission to invent
prompt requirements, gates, blacklists, whitelists, or an inverted version of
the behavior Rich asked to remove.
