# Workbench calls and speed record

Recorded 2026-09-11 for Unit 1 of the [workbench brief](workbench-brief.md).
The page was driven by a headless browser against the MGM sample published as
a foundation (58 Elements, 47 Types, 101 joins, legacy storage) plus the
browser fixture's knowledge layers. Server time is measured inside the viewer
by the new `/api/trace` endpoint, which lists every call the page made with
its server time and payload size. Open the endpoint on any running workbench
to see the same record for your own session.

## What the page asks for

| Moment | Calls | Server time | Payload | Notes |
| --- | --- | --- | --- | --- |
| Open | 9 | 282 ms | 275 KB | `system.modules` is 75 KB and `graph.neighbors` 93 KB; `model.discover` is the slowest single call at 91 ms |
| Click a neighboring card | 2 | 47 ms | 64 KB | `element.inspect` then `graph.neighbors` |
| Switch inspector section | 2 → 1 | 53 ms → 29 ms | 64 KB → 37 KB | The page re-requested `element.inspect` on every section switch; it now reuses the envelope it already holds |
| Knowledge section | 2 → 1 | 101 ms → 30 ms | 49 KB → 22 KB | Each explanation hashed the whole snapshot; explanations and their traversal context are now cached per revision |
| Resize the window | 0 | | | |
| Toggle a panel | 0 | | | |

The open calls in order: `/api/projects`, `/api/settings`, `/api/pending`,
`system.modules`, `model.discover`, `namespace.browse`, `layer.list`,
`element.inspect`, `graph.neighbors`. The pending poll repeats every five
seconds while the tab is visible and costs 25 ms on this sample.

## What moved on its own, before and after

| Moment | Before | After |
| --- | --- | --- |
| Click a neighboring card | Fresh layout, zoom reset to 75% or 100%, every shared card moved | The clicked card stays where it was, zoom unchanged, the view pans only as far as needed to show the new cards |
| Resize the window | Zoom changed (100% → 93%) and the view re-centered | Nothing moves |
| Toggle a panel | Handled by the same resize path | Nothing moves |
| Wheel zoom | Sensitivity 0.22 | Cytoscape's default |
| Panel width sliders | Two 40 px range inputs that redrew per pixel | Removed |

## Where the time goes on the server

`model.read` indexes a published revision once and keeps the last eight
(`models._indexed_revision`); the SQL backend already did this, the legacy
and portable backends re-indexed on every read. `explain_applicability` keys
its cache on the revision identity plus a digest of any overlaid layer and
knowledge collections instead of the JSON of the whole snapshot, and builds
its traversal context once per revision. In-process, a first `knowledge.get`
on the Defining Element went from 85 ms to 33 ms; repeated calls on the same
revision are cache hits.

## How to reproduce

The measurement fixture lives in the session scratchpad, not the repository:
it serves the sample with `tests/semantic_browser_data.add_semantic_cases`
and drives the page with Playwright, reading `/api/trace?clear=1` after each
step and comparing node positions, zoom, and pan across steps. The browser
tests under `tests/*.cjs` exercise the same page and pass with these changes.
