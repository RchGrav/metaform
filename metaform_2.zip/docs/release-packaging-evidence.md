# Packaging repair evidence — 2026-09-11

Source work in `/home/rich/metaform/.worktrees/release-quality` was followed by the final rebuilt-artifact checks in [release-distribution-evidence.md](release-distribution-evidence.md). The exact final wheel/standalone hash is `2432498b246f3ef69131e36e5eddc12eb592e80c47fbab7f7e41351324a53027`; no public release was performed. The source investigation below records how this slice was repaired.

## Implemented

- **S13 / R09–R10:** Packaging declares the existing `auto_build: true` default in its module settings. Its reference explains the selected-source checks, changed-hash trigger, explicit false switch, and portable override. The default behavior was preserved. Distribution checks explicitly disable automatic builds in their temporary homes; there is no test-detection behavior in production.
- **Supplemental 52 / R02:** Build errors retain backend diagnostics and name the explicit source route. `package.build --source` remains usable while an ordinary artifact is selected. Build results include the resolved source directory.
- **Supplemental 53/55 / R02, R26, R43:** Packaging reference and exported `START-HERE.txt` explain archive destinations, sibling working copies, import parent/history behavior, portable JSON/SQLite state, external-tool requirements, continuation, and re-export.
- **Supplemental 53 / R26, R43:** Export inspects captured community-module Python sources and dotted handlers for imports absent from the archive/standard library. Findings use the existing nonblocking `unresolved` result. The archive and import result retain them. Flat manifests sharing a directory do not acquire another module's findings. Inspection does not execute module code or reject export; optional imports can remain unused, and dynamic imports still need runtime demonstration.

## Verification

The initial five-case packaging run reproduced two failures: build errors omitted the explicit-source route, and a module with an unbundled import exported with no diagnostic. Three existing behaviors passed: a real explicit-source wheel build, changed-hash/false-switch automatic building through `Registry.after_call`, and public import's active handoff republication. A subsequent ownership test reproduced and corrected cross-module attribution for a flat manifest.

Initial targeted results:

```text
tests/test_release_packaging.py: 6 passed in 2.89s
tests/test_review_portable.py: 13 passed as part of the earlier 18-case run
tests/test_knowledge_dependencies.py + tests/test_portable_knowledge.py: 31 passed in 24.49s
py_compile: packaging.py, portable.py, check_distribution.py passed
```

The build fixtures use a local PEP 517 backend to produce real small wheels without network access or building this checkout's distribution. The automatic-build check observes one build for unchanged source, another after a source edit, and no build while disabled. Existing portable suites exercise captured files, schemas, shared/project boundaries, copied modules, symlinks, continuation, and re-export. All projects/homes are temporary; no service was launched against a real user home.

## Delivered integration

`tools/check_distribution.py` and the additional delivered-entrypoint probes now pass against the final rebuilt artifact on Python 3.11 and 3.13, with the matrix and retained outputs linked above. This establishes the tested delivery journeys, not every external operation in an offline environment. Module imports created dynamically cannot be established by static export inspection.

The first-use exported-archive reference defect was subsequently reproduced and repaired. Help, `system.reference`, `system.settings`, `skill`, and `guide.chassis` read archived module/knowledge declarations without materializing the sibling project; an already-materialized archive uses its current working copy's reference. Custom module help and custom workflow discovery remain available. Module-owned reference/read-only declarations prevent these requests from automatically rebuilding the selected source. The ordinary wheel's reference routing belongs to the CLI lane.

Shared flat manifests now capture separate raw, guidance, and bootstrap handler files as executable dependencies, alongside command handlers. A real export/import regression reproduced missing guidance/raw code before this correction and now exercises both after sharing.

Final combined source check:

```sh
PYTHONPATH=$PWD/src /home/rich/metaform/.venv/bin/python -m pytest -q \
  tests/test_module_api.py tests/test_release_packaging.py \
  tests/test_review_portable.py tests/test_onboarding.py \
  tests/test_knowledge_dependencies.py tests/test_portable_knowledge.py
```

**71 passed in 47.98 seconds.** The independent runtime reviewer also verified that all five archive reference paths preserve complete file-content hashes after a working copy exists, and that unbundled-import diagnostics survive export while metadata reference remains usable. The final artifact matrix separately verifies cancellation of a real automatic build, child termination and build-lock reuse on both installed Python versions.
