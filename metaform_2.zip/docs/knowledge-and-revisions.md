# Knowledge, outside reports and revisions

A model revision preserves its actual Elements, Types, bindings, narrowing and
refinement records, and receiver-owned OP joins. Generated knowledge is attached
through separately identified layers. `model discover` returns the model and
revision references accepted by semantic reads; pass a model explicitly when
several are available.

## Selecting attached knowledge

`knowledge.get`, `type.inspect` and `model.ground` distinguish these requests:

| `layers` input | Meaning |
| --- | --- |
| Omitted | Use the model's selected default layer, when set; otherwise include all active layers. |
| `null` | Include all active layers, overriding the selected default for this read. |
| `[]` | Include no generated layer attachments. Structural foundation properties and relationships remain available. |
| Array of layer references/IDs | Include the specified active layers. |

The JSON distinction is preserved in MCP/read-operation arguments. The CLI
accepts `--layers '[]'` for no generated attachments and `--layers null` for
all active layers. Omitting the flag uses the default-selection behavior. `layer select` changes
the model default, while an individual read's layer argument does not.

`analysis blindspots --name "Blind spots"` creates a named outside report from
the complete recorded Native account and selected region. Its name is separate
from its request text. The outside role remains outside implementation access;
its findings attach as knowledge. Applying a proposed structural correction is
an explicit revision operation.

The outside assignment carries the complete Native-authored functional account,
including Types, actual Elements, bindings, joins, narrowings, understanding and
record evidence. Runtime audit transcripts (captured assignments, submission
wrappers and raw implementation-file/tool-read bodies) are retained in durable
history instead of duplicated into that account. Source identity, revision and
description remain available. This distinction was repaired after the actual
self-intake handoff exceeded the host input limit; it preserves the Native
account while separating its runtime capture history.

`layer inspect` retains access to a removed layer's recipe and generation history
with `layer_context.removed: true`. `layer regenerate` accepts `target` for a
selected semantic region (`region` remains a compatibility alias). Regenerating
an incomplete Knowledge Tool generation at the same revision resumes its missing
coverage without repeating completed slots. Base functional knowledge and whole
property-qualified composites retain their separate attachment origins.

## Intake completion and evidence

A completed Native assignment is recorded before publication. The returned
receipt points to `intake.apply`; call that operation to publish the foundation
and inspect the resulting annotations and diagnostics. The normal coordinator
also follows the action returned by `guide.start`. A completed worker binding
continues to identify its original request; it does not silently select new work.

`intake.read` returns UTF-8 text when available. For binary artifacts it returns
base64 bytes, media type, byte size and SHA-256; supported image formats also
include dimensions. An optional description is retained as source evidence.
Image-capable MCP hosts also receive typed image content with those exact bytes,
including during sampled Native work. Other binaries retain their structured
evidence. The transport checks establish delivery; actual visual reasoning is
separate model evidence. Schema annotations remain visible.

## A concrete transformation patch

The [realignment demo](../examples/realignment/README.md) produces a complete
`transformation-request.json` with current owner/model/revision references. It
changes only the engine's medium binding and its receiver-owned property join
from C++ to JavaScript, retaining the shell installer. Its two update operations
each carry a reason. The scoped mapping records `meaning_preserved: false` and
the engine target, so unrelated uses of the source Type are not rewritten.

The fixture's [foundation source](../examples/realignment/sources/software-foundation.json)
already authors the function/encounter narrowing relationships for its Types.
The patch reuses those Types and retains their narrowings; it does not infer
missing parent-child meaning from dotted names. If a new patch introduces a
Type or relocation, include the corresponding authored narrowing records and
inspect resulting diagnostics.

Run `examples/realignment/run_demo.py` and use its printed output directory.
The retained [example patch](../examples/realignment/evidence/round-trip/transformation-request.json)
illustrates the fields but contains references to its original run. To make a
second variant from a newly generated demo, change the new patch's `id` and
`destination_model`, save it alongside the new results, and invoke:

```sh
metaform --project /path/from/summary/scratch/software/artifact model transform --patch @/path/to/new-patch.json
```

Inspect the returned destination revision and affected-layer jobs before
continuing their exact assignments. `model compare` accepts an explicit `source`
and `mapping`; when mapping is omitted it resolves the destination's recorded
transformation mapping. An explicit empty array means no mapping. A repeated
clone of the same canonical source and destination reuses its activity and
original purpose instead of creating a different clone because the supplied
purpose wording changed.

Nonconflicting changes can rebase onto the current destination revision. A
conflicting record retains the competing content and the submitted change for
inspection. Revisions, the operation's reason/evidence and the mapping retain
the correction's provenance; a successful patch application alone does not
certify that the authored semantic change was appropriate.
