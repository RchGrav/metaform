# Workbench cleanup

This document records the completed cleanup of misleading presentation and
additions outside the agreed design. [SPEC](SPEC.md) defines intended semantic
behavior; [current work](current-work.md) tracks remaining work and sequencing.
The interface and server questions below remain open.

## What changed

- Removed the Doors module, its commands, GUI, and special continuation/export
  handling. Doors was an example of previous work.
- Stopped importing example workflows when an App opens. The two examples are
  retained under `examples/workflows/` for explicit use.
- Removed automatic browser and preview-tab opening. Starting a viewer or
  preview returns links.
- The initial graph selects records with contextual or latent provenance and
  their joins. Referenced participants, including joins on joins, remain
  connected. A project with no intake records displays an empty state.
- Supplied prompts, workflow definitions, and recorded responses remain
  inspectable in the prompt/workflow views and **All stored records**. They no
  longer appear as inferred project knowledge merely because they share its
  database. Authored and other sources have a neutral graph colour.
- The viewer identifies the selected project by name and full path. Project
  storage and shared global storage are labelled separately.

Existing saved records are preserved. The graph selection is a view over their
recorded provenance, not a change to intake acceptance or semantic rules.

## Retained capabilities and their purpose

| Capability | Requirement it serves | Current implementation |
| --- | --- | --- |
| CLI and loadable modules | Harness-independent chassis with a scoped command surface | The command router and module handlers remain. The existing MCP router also dispatches these handlers; its broader exposure needs discussion. |
| Contextual intake and independent latent inference | Collect project knowledge and latent type knowledge, keeping the source of each contribution | Intake assignments and answers are persisted; latent inference authors its own global joins without receiving project joins. |
| Graph inspection and editable prompts | Refine semantic wording and inspect the resulting knowledge | Records, relationships, prompts, and saved responses are accessible. The default graph now distinguishes intake data from supporting records. |
| Workflow conversion and execution | Turn a written process into stored, executable steps | Builder assignments, JSON definitions, conditions, loops, and continuations exist. The GUI currently exposes these through forms. |
| Versions and portable exports | Preserve work and provenance, including outside Git repositories and in offline execution | Checkpoints, reconstruction, export, re-import, and static previews remain. |
| Image generation, packaging, and CI | Work with images and distribute the tooling and its data | The imagegen module, wheel/standalone build, and fork-compatible CI remain. |
| Activity and data browsing | Inspect WIP, history, statistics, and dumps | The existing activity view and CLI/MCP data commands remain. |

## Design work still to discuss

The role currently envisioned for MCP is browsing the knowledge graph. The
browsing interface and any scope beyond it remain to be discussed. The current
implementation exposes broader module commands through MCP; retaining that
code during cleanup does not settle the intended MCP surface.

The desired workflow view is a named workflow that opens into its steps and
the prompts used by those steps. The current JSON form does not yet provide
that presentation. The built-in intake procedure also needs to be made
understandable through that view.

Saving an answer and note currently records an observation; it does not run an
agreed workflow-level evaluation. The labels now describe what is saved.

The viewer currently opens for one selected project per server process.
Separate projects can run separate viewers and share global knowledge. This
cleanup does not choose a new project-switching or shared-server model.

The cleanup left semantic source documents and authored base prompts unchanged.
The maintained Aliases section is now bundled verbatim and supplied to intake.
An explicit `semantic_sources.aliases` configuration selects an alternative
authored source.

[Serena reference notes](serena-reference.md) record relevant server and MCP
deployment patterns for that discussion. No Serena implementation is adopted
by this cleanup.
