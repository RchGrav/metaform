def enter(api, arguments, context):
    api.enter()
    return {"module": "example", "bailout": "abort"}


def raw(api, tokens, context):
    return {"tokens": tokens, "bailout": "abort"}
