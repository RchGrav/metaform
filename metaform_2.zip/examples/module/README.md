# Building and sharing a module

Read `metaform guide chassis` for the chassis's functional Metaform and complete customization procedures. Read `metaform system reference` for the installed public operations and each module's own command, argument, settings, output, and example reference.

Copy this folder into the selected project's `.metaform/modules/example`, the configured home directory's `modules/example`, or a directory named by `module_paths`. Then run `metaform example --help`, followed by `metaform example enter`. The example enters raw mode, echoes supplied words, and leaves through `metaform abort`. Discovery reads installed manifests dynamically.

Each external Python handler receives `ModuleAPI` as its first argument. A synchronous handler can return directly; an asynchronous handler can await public operations:

```python
async def inspect(api, arguments, context):
    api.set("visits", api.get("visits", 0) + 1)
    return await api.call("model.inspect", arguments)
```

`api.call(command, arguments=None)` invokes an enabled registered operation with the current harness context. Use it for semantic reads/writes and `workflow.import`, `workflow.start`, `workflow.answer`, and `workflow.next`. The chassis renders assignments and owns their nonce, run/request identity, workfolders, receipts, and cleanup. Return the supplied handoff to the concierge. Module handlers do not need the database or graph implementation.

`api.get` and `api.set` retain values under this module's namespace in the selected project. `api.project` and `api.config` return copies of the selected project descriptor and effective settings. Persist settings changes through `system.configure`; changing the returned dictionary does not persist them. `api.enter()` and `api.leave()` use the chassis's mode lifecycle. This is a supported integration interface, not a Python security sandbox.

The module manifest supports:

| Field | Meaning |
| --- | --- |
| `id`, `name`, `description` | Unique module identity and its user-facing purpose. |
| `commands` | Each operation's `name`, `handler`, `description`, and `inputSchema`; handlers can be `handler.py:function` or package-qualified callables. |
| Command `returns`, `context`, `examples` | Returned values, lifecycle/working context, and examples containing `arguments` and `description`. |
| Command `outputSchema`, `resourceKind` | Structured output contract and MCP resource classification when supplied. |
| Command `always_available`, `hidden_when` | Availability across command modes and the existing expression-based visibility rule. |
| Command `read_only`, `reference_only` | Read-only operations skip automatic source builds. Reference-only metadata operations also work before project initialization. |
| Command `aliases`, `binding_available` | CLI aliases and an operation explicitly usable in its module's assignment context. |
| Command `bootstrap_handler` | Optional synchronous `handler(argv, project_selector)` for a CLI operation that must run before project initialization. It receives the module/command argument vector and must parse its own remaining arguments. |
| Command `ready_guidance` | Reminder contributed to ready-state guidance only while its owning command is available. |
| `settings` | Setting name → JSON Schema shape, including `type`, `default`, `description` and optional `scope` (`home` or `project`). Nested values merge by key; arrays/scalars replace. |
| Setting `lifecycle`, `apply_command` | Describes startup-only configuration and the public operation for an explicit component change, such as backend migration. Effective configured values and active runtime values are reported separately. |
| `guidance` | Detailed operating guidance returned with this module's reference. |
| `guide_handler`, `guide_priority` | Optional synchronous `handler(api, state, plan=None)` and ordering for module-owned next-action recommendations. |
| `raw_handler`, `disable_argparse` | Optional module-owned raw input handling after `api.enter()`. |
| `portable.files` | Relative runtime file/directory dependencies to capture in a project export. |
| `portable.knowledge_refs` | Owned knowledge dependencies required by the module. |

A self-contained folder uses `module.json`; flat JSON manifests are also discovered in module roots. Relative Python imports stay within the installed module package. Include required runtime assets and knowledge references; export reports unresolved resources/imports without treating a static import scan as proof of execution.

Share the folder itself or a portable project that includes it. Verify the same operation after installing/importing it into another temporary project. Removing the installed folder removes its command declarations; durable project results and historical assignments keep their own lifecycle.
