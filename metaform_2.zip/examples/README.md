# Metaform examples

Examples have different purposes. A runnable fixture demonstrates its recorded
mechanics; a retained live response records what a model actually produced.
Neither becomes a new semantic rule merely by appearing here.

| Example | Purpose and use |
| --- | --- |
| [Realignment lifecycle](realignment/README.md) | No-model demonstration using authored responses, software and non-code foundations, requested layers, a scoped variant, reinference and CLI/MCP/GUI parity. Scripts default to new temporary output directories. |
| [Historical MGM intake](intake/mgm-main/README.md) | Preserved real v1 Native/Latent graphs, understanding and History screenshot. `metaform package sample` creates an isolated portable project without a source checkout or inference; `load_sample.py` delegates to it. |
| [Conditional review](workflows/conditional_review.json) | Executable review → optional revision → review loop, followed by a recorded result; requires `inputs.element`. |
| [Earlier review recipe](review.json) | Another executable review/revise loop with OP-specific source wording and depth/focal selection. It is retained intentionally, not an unexplained output file. Requires `inputs.element`. |
| [Per-Element prompts](workflows/element_prompts.json) | Historical example of `foreach`, selected graph context, schema annotations and saved learning output; requires `inputs.objects`, an array of objects with `id`. Its particular latent-object instruction is an example, not the default intake or Enumerator contract. |
| [Command harness configuration](harness-config.json) | Shape of a configured external command and response-file placeholder; replace the executable with the actual harness. |
| [Community module](module/README.md) | Module registration, handler interface, module-owned raw input and built-in reference. |

Import a workflow through `metaform workflow import --path /absolute/path/to/file.json`,
then use `workflow start` with its ID and input object. Use `--no-exclusive` when
coordinating independent runs. Keep the returned run/request identity through
answer and next operations; [the workflow reference](../docs/workflows.md)
explains the exact execution contract. These JSON workflows already contain
executable steps and do not need natural-language conversion.

The two review examples completed their review/record path in isolated source
checks. The per-Element example completed one object through its foreach
transition and saved output. Those checks used authored answers, not a live
model or actual edits to an external project. The revise branch expresses the
authored loop; its execution quality remains the assigned agent's work.

## Retained live evidence

The completed matched comparison arms are in
[non-code retry](realignment/evidence/live-comparison-retry/noncode/),
[multi-Type](realignment/evidence/live-comparison-multitype/multitype/), and
[MGM archived account](realignment/evidence/live-comparison-mgm/mgm-archive/).
The [combined review](realignment/evidence/live-comparison/review.md) explains
their input scopes and mixed findings. The original failed attempt is preserved
in `realignment/evidence/live-comparison/`; it is not the completed non-code run.
The [grounded-task review](realignment/evidence/live-grounded-task/review.md)
records a separate fresh task over the illustrative model and its knowledge.

The comparison script pins its archived baseline commit and writes generated
source selections and results under its output directory. No example run writes
back to a tracked source or evidence directory by default. Browser screenshots
and fixture workspaces are temporary unless an output destination is explicitly
provided.
