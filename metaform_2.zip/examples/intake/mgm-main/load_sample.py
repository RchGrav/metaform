#!/usr/bin/env python3
"""Load the bundled historical MGM example; equivalent to metaform package sample."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'src'))
from metaform.modules.package import sample


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination', type=Path, help='A new project directory; defaults to a temporary directory.')
    print(json.dumps(sample(None, vars(parser.parse_args()), None), indent=2))


if __name__ == '__main__':
    main()
