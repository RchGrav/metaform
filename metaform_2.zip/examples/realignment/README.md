# Realignment demonstration

This directory retains a reproducible lifecycle witness and a separate live prompt comparison. The lifecycle responses are authored fixtures submitted through the real intake and workflow APIs. The live comparison retains unedited Codex responses and execution events. Existing completed comparisons are in [non-code](evidence/live-comparison-retry/noncode/), [multi-Type](evidence/live-comparison-multitype/multitype/), and [MGM account](evidence/live-comparison-mgm/mgm-archive/); see the [combined review](evidence/live-comparison/review.md). The original failed non-code attempt remains in `evidence/live-comparison/`.

Run the lifecycle from the repository root:

```sh
.venv/bin/python examples/realignment/run_demo.py
node examples/realignment/capture_demo.cjs /path/from/demo/output/summary.json
```

`run_demo.py` creates fresh temporary application and result directories and prints their paths, including `output`, which contains `summary.json`. Pass that summary to `capture_demo.cjs`; it serves the corresponding workspace and writes screenshots and exact HTTP requests to another temporary directory. Supply `--output /path/to/results` to the Python scripts or a second positional directory to the capture script to retain a chosen output location. Retained evidence in this repository is never the default destination. To explore the generated workspace, run `.venv/bin/python examples/realignment/serve_demo.py --summary /path/to/summary.json`. If its temporary workspace was removed, run the demo again.

The software artifact is an explicitly illustrative connectivity coordinator. Its engine has evaluator and interface-adapter facets while retaining one actual identity. The engine uses C++; its installer uses shell. The non-code artifact is the accompanying trail-camera maintenance guide. Their source texts and authored structural contributions are under `sources/`.

The round trip exercises:

1. Version 2 incremental intake with exact source evidence and one completed foundation.
2. Namespace browsing and an engine property explanation, including the non-applicability of the installer's shell property.
3. Requested engine, installer, and maintenance-guide knowledge layers.
4. Identical canonical results through a real CLI subprocess, portable MCP dispatch, and the GUI HTTP endpoint.
5. A source-preserving variant replacing only the engine's medium binding and property meeting with JavaScript.
6. The automatically scheduled engine-layer reinference, preserving its original request and the installer's existing guidance.
7. Task grounding and a submitted specialization that names the engine's evaluator/adapter purposes and retained installer.

See `evidence/round-trip/summary.json`, `transport-parity.json`, `destination/transport-parity.json`, `transformation-result.json`, and the source/destination screenshots. Every lifecycle assignment and response is retained alongside those results. The fixture assertions establish the exercised behavior; they do not establish the quality of an unobserved model response or claim that implementation files have been ported.

## Live matched comparison

```sh
.venv/bin/python examples/realignment/compare_prompts.py
```

This runs one baseline/focused pair per artifact through `metaform.harness.execute` and the installed Codex CLI. Each arm gets the same source bytes. The baseline reconstructs the Native/full-glossary prompt and rule snapshots at `b7aea90142067185153c974b826b6e609d9f1464`, the commit recorded by the retained comparison; the focused arm uses the current version 2 composition. Each arm retains its real output contract and incremental intake tools. Outputs are collected from both saved contributions and the final answer.

A newly created task-owned `/tmp/metaform-live-*` directory holds each source and its isolated runtime. Project instruction files are not copied into those artifacts. Existing global Codex defaults remain in effect; exact isolation from those defaults is not claimed. The scripts retain available token usage, commands, elapsed time, raw responses, and schema annotations. Missing or failed inference is recorded as such.

The MGM comparison uses the archived Native understanding and five exact actual records from `examples/intake/mgm-main/native.json`. Each run saves its generated source selection and hash under its result directory at `sources/mgm-archived-account.json`, leaving the tracked source unchanged. This is reinference from a recorded account, not a fresh MGM implementation-source intake. The other two artifacts are the local maintenance guide and multi-Type coordinator text.

A single matched pair supports an artifact-specific observation. Prompt length, Type counts, schema validity, and fluent wording do not by themselves demonstrate semantic improvement. Review receiver-purpose pairing, Type/actual separation, multi-Type facets, local property scope, unsupported additions, and practical orientation in the retained outputs.

## Fresh grounded task

After the lifecycle demo, run `.venv/bin/python examples/realignment/run_grounded_trial.py --summary /path/to/summary.json` for a fresh task-agent orientation and JavaScript realization plan using the demonstrated model and its attached knowledge. `evidence/live-grounded-task/review.md` reviews the actual response, exact semantic references, scope, and implementation-evidence limits. The retained witnessed response is live; the lifecycle response remains an explicitly authored fixture.

## Browser dependencies

Run `npm ci` and `npx playwright install chromium` before browser captures or `npm run test:browser`. The lockfile pins the Playwright build used for these checks. `PYTHON` can select the Python executable; set `PYTHONPATH` to this checkout’s `src` when running from a worktree. Browser checks print their temporary evidence directories and clean up their fixture servers.
