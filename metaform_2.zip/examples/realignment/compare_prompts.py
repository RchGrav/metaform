#!/usr/bin/env python3
"""Run one matched live Codex pair per explicitly supplied local artifact."""
from __future__ import annotations

import argparse
import asyncio
import copy
import json
import hashlib
from pathlib import Path
import subprocess
import tempfile
import time
import traceback

from run_demo import HERE, ROOT, isolated_app, save
from metaform import harness, prompts, rulebook
from metaform.intake import Intake
from metaform.models import capture_model


BASELINE_COMMIT = 'b7aea90142067185153c974b826b6e609d9f1464'


def git_text(path):
    return subprocess.check_output(['git', 'show', BASELINE_COMMIT + ':' + path], cwd=ROOT, text=True)


def sources(output):
    archive = ROOT / 'examples/intake/mgm-main/native.json'
    raw = json.loads(archive.read_text())
    ids = ['mgm:project', 'mgm:sentry', 'mgm:dnsresponders', 'mgm:dnsbench', 'mgm:users']
    selected = {'source': 'examples/intake/mgm-main/native.json', 'source_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                'coverage': 'Archived Native account plus these five exact actual records. No MGM implementation files were inspected.',
                'understanding': raw['understanding'], 'actual_records': {id: raw['elements'][id] for id in ids}}
    selected_path = output / 'sources/mgm-archived-account.json'
    save(selected_path, selected)
    return {'noncode': HERE / 'sources/maintenance-guide.txt', 'multitype': HERE / 'sources/multi-type-coordinator.txt', 'mgm-archive': selected_path}


def events(app, run):
    with app.db() as db:
        return [{'kind': row['kind'], 'created': row['created'], 'body': json.loads(row['body'])}
                for row in db.execute('SELECT kind,created,body FROM events WHERE run_id=? ORDER BY id', (run,))]


def metrics(retained, event_rows):
    usage, commands = [], []
    for event in event_rows:
        if event['kind'] != 'debug.harness.response':
            continue
        for line in event['body'].get('stdout', '').splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if item.get('type') == 'turn.completed':
                usage.append(item.get('usage', {}))
            if item.get('item', {}).get('type') == 'command_execution':

                if item['item'].get('status') != 'in_progress':
                    commands.append(item['item'])
    records = retained.get('elements', {}) if isinstance(retained, dict) else {}
    if retained.get('schema_version') == '2' or 'types' in retained:
        types, actuals, joins = retained.get('types', {}), records, retained.get('joins', [])
    else:
        types = {k: r for k, r in records.items() if r.get('entity_schema') == 'metaform:element'}
        actuals = {k: r for k, r in records.items() if r.get('entity_schema') == 'metaform:actual-element'}
        joins = retained.get('joins', [])
    return {'reported_usage': usage, 'recorded_command_count': len(commands), 'commands': commands,
            'type_count': len(types), 'actual_count': len(actuals), 'join_count': len(joins),
            'semantic_quality': 'Requires the accompanying artifact-specific review; counts are descriptive, not a quality score.'}


async def trial(artifact, variant, source, output, timeout):
    folder = Path(tempfile.mkdtemp(prefix='metaform-live-' + artifact + '-' + variant + '-'))
    app = isolated_app(folder)
    local_source = app.project / source.name
    local_source.write_bytes(source.read_bytes())
    if variant == 'baseline':
        baseline = '\n\n'.join(git_text('src/metaform/data/semantics/' + name) for name in ['native.md', 'glossary.md'])
        prompts.put(app, {'id': 'prompt:metaform.intake.native', 'name': 'Archived baseline Native', 'text': baseline, 'rule_codes': ['r1', 'r2', 'r3', 'r4', 'r5']})
        for rule in json.loads(git_text('src/metaform/data/rulebook.json')):
            rulebook.put(app, rule)
        job = Intake(app)._start('native', contract_version='1')
    else:
        job = Intake(app).start()
    # Both arms receive the same complete, named source evidence. Runtime jobs
    # retain their own versioned schemas and supported incremental intake tools.
    job['inputs']['source_evidence'] = {'path': source.name, 'text': source.read_text(), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'scope': 'Only the supplied artifact is the intake source; its original evidence status is retained.'}
    if artifact == 'mgm-archive':
        job['inputs']['evidence_status'] = 'This is reinference from an archived Native account, not a fresh intake of MGM implementation source.'
    job['workfolder'] = str(app.project)
    assert '<MetaformFoundation>' not in job['prompt']
    run = app.load_run(job['run_id'])
    run['pending'] = job
    if 'assignment_snapshot' in run:
        run['assignment_snapshot'] = copy.deepcopy(job)
    app.save_run(run)
    out = output / artifact / variant
    save(out / 'assignment.json', job)
    metadata = {'artifact': artifact, 'arm': variant, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'harness': 'metaform.harness.execute(codex)', 'codex_version': subprocess.check_output(['codex', '--version'], text=True).strip(),
                'baseline_commit': BASELINE_COMMIT,
                'workspace': str(app.project), 'prompt_characters': len(job['prompt']),
                'context_limitations': 'Fresh task-owned /tmp folder contains only the copied source artifact and runtime-created .metaform state. Parent project instructions are not copied. Existing global Codex defaults are not inspected or modified; exact bias isolation is not claimed.'}
    start = time.monotonic()
    print('START', artifact, variant, flush=True)
    try:
        async with asyncio.timeout(timeout):
            response = await harness.execute(app, job, 'codex')
        save(out / 'harness-response.json', response)
        if response['status'] == 'answered':
            receipt = Intake(app).submit(job['run_id'], job['request_id'], response['answer'])
            save(out / 'receipt.json', receipt)
            if variant == 'focused':
                completed = Intake(app).next(job['run_id'])
                retained = capture_model(app, completed['model'])
            else:
                retained = Intake(app)._native_snapshot()
            save(out / 'collected-result.json', retained)
            metadata['status'] = 'answered'
        else:
            retained = {}
            metadata['status'] = response['status']
    except Exception as error:
        retained = {}
        metadata.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        (out / 'traceback.txt').write_text(traceback.format_exc())
    # Preserve incremental output even when collection or inference is interrupted.
    saved_run = app.load_run(job['run_id'])
    save(out / 'retained-run.json', saved_run)
    if variant == 'focused':
        partial = saved_run.get('contributions', {})
    else:
        partial = Intake(app)._native_snapshot()
    save(out / 'retained-contributions.json', partial)
    if not retained:
        retained = partial
    rows = events(app, job['run_id'])
    for row in rows:
        if row['kind'] == 'debug.harness.request':
            save(out / 'rendered-request.json', row['body'])
    metadata['elapsed_seconds'] = round(time.monotonic() - start, 3)
    rows = events(app, job['run_id'])
    save(out / 'execution-events.json', rows)
    metadata['metrics'] = metrics(retained, rows)
    save(out / 'execution.json', metadata)
    print('END', artifact, variant, metadata['status'], metadata['elapsed_seconds'], flush=True)
    return metadata


async def run(args):
    output = (args.output or Path(tempfile.mkdtemp(prefix='metaform-comparison-results-'))).resolve()
    print('Results: ' + str(output), flush=True)
    selected = sources(output)
    results = []
    for name in args.artifacts:
        pair = await asyncio.gather(*(trial(name, arm, selected[name], output, args.timeout) for arm in ('baseline', 'focused')))
        results.extend(pair)
        save(output / 'summary.json', {'trials': results, 'interpretation': 'One matched pair per artifact; review raw collected outputs and semantic findings. No aggregate quality claim follows from counts, token use, or a schema pass.'})
        if all(item['status'] == 'failed' for item in pair):
            print('Both arms failed; retaining execution evidence before further attempts.', flush=True)
            break


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifacts', nargs='+', default=['noncode', 'multitype', 'mgm-archive'], choices=['noncode', 'multitype', 'mgm-archive'])
    parser.add_argument('--output', type=Path, help='Result directory; defaults to a new temporary directory.')
    parser.add_argument('--timeout', type=int, default=480)
    asyncio.run(run(parser.parse_args()))
