#!/usr/bin/env python3
"""Run a fresh task agent against the demonstrated model and narrative source."""
import argparse
import asyncio
import copy
import json
from pathlib import Path
import shutil
import tempfile
import time
import traceback

from run_demo import HERE, save
from compare_prompts import events, metrics
from metaform.app import App
from metaform import harness
from metaform.modules import workflow
from metaform.workflow import Engine


async def run(args):
    summary = json.loads(args.summary.read_text())
    original = Path(summary['scratch']) / 'software'
    if not (original / 'artifact').is_dir():
        raise ValueError('The demo workspace no longer exists. Run run_demo.py and supply its new summary.json.')
    app = App(original / 'artifact', original / 'runtime', debug=True, binding=False)
    target = {'owner': 'project:' + summary['source']['project'], 'kind': 'element', 'id': 'demo:engine'}
    task = ('Orient a developer to this explicitly illustrative coordinator model: state its principal result, exterior receiver, artifact boundary, and one receiving-entity/operative-purpose/provider-Type meeting. '
            'Then prepare a concrete plan for the proposed JavaScript engine realization while preserving its evaluator and adapter purposes and retaining the shell installer. '
            'Identify the actual Elements and joins affected, use applicable knowledge with its layer and generation provenance, and describe what implementation evidence the developer would need next. '
            'The supplied artifact is a narrative fixture, not an implementation-source tree; the destination model represents the proposed variant. Return this orientation and plan as the grounded instruction.')
    job = workflow.lexicalize(app, {'model': summary['destination'], 'target': target, 'prompt': task}, None)
    folder = Path(tempfile.mkdtemp(prefix='metaform-live-grounded-'))
    source = HERE / 'sources/multi-type-coordinator.txt'
    shutil.copyfile(source, folder / source.name)
    job['workfolder'] = str(folder)
    job['inputs']['source_evidence'] = {'path': source.name, 'text': source.read_text(), 'scope': 'Illustrative narrative fixture; no implementation files are supplied.'}
    job['inputs']['source_model'] = summary['source']
    job['inputs']['destination_model'] = summary['destination']
    assert '<MetaformFoundation>' not in job['prompt']
    run = app.load_run(job['run_id']); run['pending'] = copy.deepcopy(job); app.save_run(run)
    out = (args.output or Path(tempfile.mkdtemp(prefix='metaform-grounded-results-'))).resolve()
    print('Results: ' + str(out), flush=True)
    save(out / 'assignment.json', job)
    metadata = {'harness': 'metaform.harness.execute(codex)', 'workspace': str(folder), 'source': str(source.relative_to(HERE)), 'scope': 'Fresh task agent, narrative fixture and real shared model/knowledge reads; no implementation source.', 'context_limitations': 'Existing global Codex defaults remain in effect; exact bias isolation is not claimed.', 'timeout_seconds': 480}
    started = time.monotonic()
    try:
        async with asyncio.timeout(480):
            response = await harness.execute(app, job, 'codex')
        save(out / 'harness-response.json', response)
        metadata['status'] = response['status']
        if response['status'] == 'answered':
            save(out / 'receipt.json', Engine(app).submit(job['run_id'], job['request_id'], response['answer']))
            save(out / 'completion.json', Engine(app).next(job['run_id']))
    except Exception as error:
        metadata.update(status='failed', error=type(error).__name__ + ': ' + str(error))
        (out / 'traceback.txt').write_text(traceback.format_exc())
    rows = events(app, job['run_id'])
    save(out / 'execution-events.json', rows)
    for row in rows:
        if row['kind'] == 'debug.harness.request':
            save(out / 'rendered-request.json', row['body'])
    metadata['elapsed_seconds'] = round(time.monotonic() - started, 3)
    metadata['metrics'] = metrics({}, rows)
    save(out / 'execution.json', metadata)
    print(json.dumps({k: v for k, v in metadata.items() if k != 'metrics'}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, required=True, help='summary.json from a current run_demo.py workspace.')
    parser.add_argument('--output', type=Path, help='Result directory; defaults to a new temporary directory.')
    asyncio.run(run(parser.parse_args()))
