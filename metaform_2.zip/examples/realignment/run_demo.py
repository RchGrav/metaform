#!/usr/bin/env python3
"""Replay an authored fixture through real Metaform lifecycle and read transports."""
from __future__ import annotations

import argparse
import asyncio
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'src'))
from metaform.app import App
from metaform.cli import run_parser
from metaform.intake import Intake
from metaform.layers import active_attachments, create_layer, inspect_layer
from metaform.models import capture_model
from metaform.modules import intake as intake_module
from metaform.modules import workflow as workflow_module
from metaform.portable_mcp import dispatch
from metaform.read_model import read_model
from metaform.registry import Registry
from metaform.transform import apply_transformation
from metaform.viewer import create_app
from metaform.workflow import Engine

HERE = Path(__file__).resolve().parent


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def isolated_app(directory):
    project, home = directory / 'artifact', directory / 'runtime'
    (project / '.metaform').mkdir(parents=True)
    # Existing application state selects the isolated local backend; no user
    # configuration or installed service is changed by this demonstration.
    (project / '.metaform' / 'state.sqlite3').touch()
    return App(project, home, debug=True, binding=False)


def qualified(snapshot, owner):
    result = copy.deepcopy(snapshot)
    def visit(value):
        if isinstance(value, dict):
            if 'owner' in value:
                value['owner'] = owner
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    visit(result)
    return result


def software(app):
    owner = 'project:' + app.project_id
    s = qualified(json.loads((HERE / 'sources/software-foundation.json').read_text()), owner)
    ref = lambda kind, id: {'owner': owner, 'kind': kind, 'id': id}
    s['types']['code.adapter'] = {'owner': owner, 'id': 'code.adapter', 'description': 'An adapter mediates between interfaces.', 'ef': 'Translate between interfaces.', 'length': 1, 'aliases': []}
    s['narrowings'].append({'owner': owner, 'id': 'narrowing:adapter', 'parent': ref('type', 'code'), 'child': ref('type', 'code.adapter'), 'category': 'function', 'reason': 'Narrows executable operations to interface mediation.'})
    s['bindings'].append({'owner': owner, 'id': 'binding:engine:adapter', 'element': ref('element', 'demo:engine'), 'type': ref('type', 'code.adapter'), 'realization': 'Adapts observation records to the coordinator result interface.'})
    s['joins'].append({'owner': owner, 'id': 'join:project-adaptation', 'receiver': ref('element', 'demo:project'), 'provider': ref('element', 'demo:engine'), 'provider_type': ref('type', 'code.adapter'), 'purpose': 'Consume results through a consistent interface.', 'role': 'hard dependency'})
    s['elements']['demo:engine']['description'] += ' The same module adapts observation records to the coordinator result interface.'
    return {k: v for k, v in s.items() if k not in ('model', 'schema_version')}


def ingest(app, contribution, source, out):
    shutil.copyfile(source, app.project / source.name)
    job = Intake(app).start()
    save(out / 'intake-assignment.json', job)
    evidence = intake_module.read(app, {'run_id': job['run_id'], 'path': source.name}, None)
    save(out / 'intake-evidence.json', evidence)
    save(out / 'intake-contribution.json', contribution)
    Intake(app).put(job['run_id'], contribution, job['request_id'])
    receipt = Intake(app).submit(job['run_id'], job['request_id'], {})
    completed = Intake(app).next(job['run_id'])
    assert completed['status'] == 'complete'
    save(out / 'intake-completion.json', {'receipt': receipt, 'result': completed})
    foundation = capture_model(app, completed['model'])
    assert not foundation['diagnostics'], foundation['diagnostics']
    save(out / 'foundation.json', foundation)
    return completed['model']


def layer(app, model, subject, request, payload, out):
    job = create_layer(app, request, target=subject, model=model)
    save(out / 'design-assignment.json', job)
    schema = {'$id': 'urn:metaform:example:guidance:1', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'object', 'required': ['account'], 'properties': {'account': {'type': 'string'}}}
    design = {'name': request, 'description': request, 'schema_ref': schema['$id'], 'schema': schema, 'selector': {'kind': 'target', 'target': subject}, 'groups': [{'subjects': [subject], 'purpose': request}]}
    save(out / 'design-response.json', design)
    Engine(app).submit(job['run_id'], job['request_id'], design)
    job = Engine(app).next(job['run_id'])
    save(out / 'generation-assignment.json', job)
    answer = {'attachments': [{'subject': subject, 'payload': {'account': payload}, 'schema_ref': schema['$id'], 'slot': 'guidance', 'applicability': {'scope': {'kind': 'target', 'target': subject}, 'reason': request}}]}
    save(out / 'generation-response.json', answer)
    Engine(app).submit(job['run_id'], job['request_id'], answer)
    done = Engine(app).next(job['run_id'])
    save(out / 'generation-completion.json', done)
    return done['layer']


def parity(app, model, target, out):
    args = {'model': model, 'target': target}
    expected = read_model(app, 'element.inspect', args)
    parser = run_parser(Registry(app), ['element', 'inspect', '--model', json.dumps(model), '--target', json.dumps(target)])
    env = os.environ | {'METAFORM_HOME': str(app.home), 'PYTHONPATH': str(ROOT / 'src')}
    process = subprocess.run([sys.executable, '-m', 'metaform', '--project', str(app.project), 'element', 'inspect', '--model', json.dumps(model), '--target', json.dumps(target)], cwd=ROOT, env=env, text=True, capture_output=True)
    assert process.returncode == 0, process.stderr
    cli = json.loads(process.stdout)
    mcp = asyncio.run(dispatch(app, Registry(app), 'tools/call', {'name': 'element.inspect', 'arguments': args}))['structuredContent']
    response = create_app(app).test_client().post('/api/semantic/element.inspect', json=args)
    assert response.status_code == 200, response.get_data(as_text=True)
    for value in (parser, cli, mcp, response.json):
        assert value == expected
    save(out / 'transport-parity.json', {'arguments': args, 'cli_argv': process.args, 'shared': expected, 'cli': cli, 'mcp_structured_content': mcp, 'gui_http': response.json, 'equal': True})


def run(output):
    scratch = Path(tempfile.mkdtemp(prefix='realignment-demo-'))
    app = isolated_app(scratch / 'software')
    owner = 'project:' + app.project_id
    ref = lambda kind, id: {'owner': owner, 'kind': kind, 'id': id}
    source = ingest(app, software(app), HERE / 'sources/multi-type-coordinator.txt', output / 'software')
    before = capture_model(app, source)
    engine, installer = ref('element', 'demo:engine'), ref('element', 'demo:installer')
    browse = read_model(app, 'namespace.browse', {'model': source, 'target': ref('type', 'code')})
    save(output / 'namespace.json', browse)
    property = read_model(app, 'knowledge.explain', {'model': source, 'target': engine, 'knowledge': ref('join', 'join:engine-medium')})
    explanation = next(item['explanation'] for item in property['records'] if 'explanation' in item)
    assert explanation['applies'] and explanation['claim']['value'] == 'code.cpp'
    save(output / 'property-explanation.json', property)
    shell = read_model(app, 'knowledge.explain', {'model': source, 'target': engine, 'knowledge': ref('join', 'join:installer-medium')})
    assert not next(item['explanation'] for item in shell['records'] if 'explanation' in item)['applies']
    save(output / 'sibling-property-explanation.json', shell)
    request = 'Explain implementation practices for this engine. Preserve {{ literal }} in the original request.'
    engine_layer = layer(app, source, engine, request, 'Preserve ownership of C++ observation objects across evaluation and adaptation.', output / 'engine-layer')
    installer_layer = layer(app, source, installer, 'Explain deployment practices for this installer.', 'Keep shell provisioning steps tied to the deployment environment.', output / 'installer-layer')
    assert capture_model(app, source) == before
    source_advice = active_attachments(app, source)
    parity(app, source, engine, output)
    binding = next(b for b in before['bindings'] if b['id'] == 'binding:demo:engine:medium')
    meeting = next(j for j in before['joins'] if j['id'] == 'join:engine-medium')
    javascript = ref('type', 'code.javascript')
    patch = {'id': 'demo:javascript-engine', 'source': source, 'destination_model': 'javascript-variant', 'purpose': 'Represent a JavaScript engine while retaining evaluator and adapter purposes and the shell installer.', 'operations': [
        {'op': 'update', 'target': ref('binding', binding['id']), 'record': binding | {'type': javascript, 'realization': 'The proposed engine uses JavaScript.'}, 'reason': 'Replace this engine realization.'},
        {'op': 'update', 'target': ref('join', meeting['id']), 'record': meeting | {'provider': javascript, 'provider_type': javascript}, 'reason': 'Replace this receiver-specific medium.'}],
        'mapping': [{'from': ref('type', 'code.cpp'), 'to': javascript, 'meaning_preserved': False, 'scope': {'kind': 'target', 'target': engine}, 'reason': 'Engine-local realization replacement.'}]}
    save(output / 'transformation-request.json', patch)
    transformed = apply_transformation(app, patch)
    save(output / 'transformation-result.json', transformed)
    destination = transformed['model']
    assert capture_model(app, source) == before
    assert active_attachments(app, source) == source_advice
    decisions = {d['layer']['id']: d['action'] for d in transformed['impact']['decisions']}
    assert decisions[engine_layer['id']] == 'regenerate', decisions
    assert decisions[installer_layer['id']] == 'preserve', decisions
    jobs = transformed.get('reinference', [])
    assert jobs, 'model.transform must schedule affected-layer reinference'
    for index, entry in enumerate(jobs):
        job = entry.get('job', entry)
        if 'request_id' not in job:
            job = Engine(app).next(job['run_id'])
        save(output / f'reinference-{index}-assignment.json', job)
        assert job['inputs']['request'] == request
        answer = {'attachments': [{'subject': engine, 'schema_ref': 'urn:metaform:example:guidance:1', 'slot': 'guidance', 'payload': {'account': 'Keep evaluation results and adapted observations consistent across JavaScript asynchronous boundaries.'}, 'applicability': {'scope': {'kind': 'target', 'target': engine}, 'reason': request}}]}
        save(output / f'reinference-{index}-response.json', answer)
        Engine(app).submit(job['run_id'], job['request_id'], answer)
        save(output / f'reinference-{index}-completion.json', Engine(app).next(job['run_id']))
    assert inspect_layer(app, engine_layer, destination)['recipe']['request'] == request
    final_foundation = capture_model(app, destination)
    engine_types = {b['type']['id'] for b in final_foundation['bindings'] if b['element'] == engine}
    assert engine_types == {'code.evaluator.connectivity', 'code.adapter', 'code.javascript'}
    assert {b['type']['id'] for b in final_foundation['bindings'] if b['element'] == installer} == {'code.installer', 'code.shell'}
    for identifier in ('join:project-evaluation', 'join:project-adaptation'):
        assert next(j for j in final_foundation['joins'] if j['id'] == identifier) == next(j for j in before['joins'] if j['id'] == identifier)
    current_advice = active_attachments(app, destination)
    assert next(i for i in current_advice if i['layer'] == installer_layer)['payload'] == next(i for i in source_advice if i['layer'] == installer_layer)['payload']
    assert 'asynchronous' in next(i for i in current_advice if i['layer'] == engine_layer)['payload']['account']
    save(output / 'destination-foundation.json', final_foundation)
    save(output / 'destination-attachments.json', current_advice)
    parity(app, destination, engine, output / 'destination')
    task = 'Plan the engine realization change while preserving connectivity evaluation and interface adaptation; retain the shell installer.'
    grounding = read_model(app, 'model.ground', {'model': destination, 'target': engine, 'task': task})
    save(output / 'grounded-context.json', grounding)
    job = workflow_module.lexicalize(app, {'model': destination, 'target': engine, 'prompt': task}, None)
    save(output / 'grounded-task-assignment.json', job)
    answer = {'instruction': 'Change demo:engine to its proposed code.javascript realization while preserving code.evaluator.connectivity and code.adapter facets. Keep join:project-evaluation paired with its connectivity purpose and join:project-adaptation paired with its interface purpose. Preserve demo:installer and its code.shell medium. Use the destination engine guidance about asynchronous result consistency.', 'model': destination, 'targets': [engine, installer]}
    save(output / 'grounded-task-response.json', answer)
    Engine(app).submit(job['run_id'], job['request_id'], answer)
    save(output / 'grounded-task-completion.json', Engine(app).next(job['run_id']))
    noncode = isolated_app(scratch / 'noncode')
    n = qualified(json.loads((HERE / 'sources/non-code-foundation.json').read_text()), 'project:' + noncode.project_id)
    n['elements']['guide:project']['description'] = (HERE / 'sources/maintenance-guide.txt').read_text()
    nsource = ingest(noncode, {k: v for k, v in n.items() if k not in ('model', 'schema_version')}, HERE / 'sources/maintenance-guide.txt', output / 'noncode')
    layer(noncode, nsource, n['artifact'], 'Explain reader support for this maintenance guide.', 'Keep the field-log observations linked to the maintenance visit and inspection sequence.', output / 'noncode-layer')
    summary = {'status': 'passed', 'response_origin': 'authored deterministic fixture responses; no live model used in this lifecycle witness', 'scratch': str(scratch), 'source': source, 'destination': destination, 'noncode': nsource, 'checks': ['one-foundation v2 intake', 'multi-Type provider facets', 'namespace browse', 'property explanation and sibling isolation', 'requested software and non-code layers', 'CLI/MCP/GUI exact parity', 'source-preserving scoped variant', 'scheduled affected-layer reinference', 'installer advice preservation', 'exact original request', 'grounded task assignment and response'], 'live_comparison': 'Separate compare_prompts.py run and evidence.'}
    summary['output'] = str(output)
    save(output / 'summary.json', summary)
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='Result directory; defaults to a new temporary directory.')
    args = parser.parse_args()
    run((args.output or Path(tempfile.mkdtemp(prefix='metaform-demo-results-'))).resolve())
