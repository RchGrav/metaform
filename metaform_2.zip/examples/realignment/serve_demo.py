#!/usr/bin/env python3
"""Serve a retained demonstration workspace for the browser walkthrough."""
import argparse
import json
from pathlib import Path
from run_demo import App
from metaform.viewer import create_app
from werkzeug.serving import make_server

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--summary', type=Path, required=True, help='summary.json from a run_demo.py run whose scratch workspace still exists.')
args = parser.parse_args()
scratch = Path(json.loads(args.summary.read_text())['scratch']) / 'software'
if not (scratch / 'artifact').is_dir():
    parser.error('The saved workspace no longer exists. Run run_demo.py and use its new summary.json.')
app = App(scratch / 'artifact', scratch / 'runtime', binding=False)
server = make_server('127.0.0.1', 0, create_app(app))
print(f'http://127.0.0.1:{server.server_port}', flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
