// Capture the actual semantic workbench at the retained source/destination refs.
const {chromium}=require('playwright');
const {spawn}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path'),os=require('node:os');
(async()=>{
 const summaryPath=process.argv[2];if(!summaryPath)throw Error('Usage: node examples/realignment/capture_demo.cjs <summary.json> [output-directory]');
 const out=process.argv[3]||fs.mkdtempSync(path.join(os.tmpdir(),'metaform-demo-capture-'));fs.mkdirSync(out,{recursive:true});
 const summary=JSON.parse(fs.readFileSync(summaryPath,'utf8'));
 const child=spawn(process.env.PYTHON||'.venv/bin/python',['examples/realignment/serve_demo.py','--summary',summaryPath],{stdio:['ignore','pipe','pipe']});
 let browser;const diagnostics=[];child.stderr.on('data',c=>diagnostics.push(String(c)));
 try{
  const url=await new Promise((resolve,reject)=>{child.stdout.once('data',c=>resolve(String(c).trim()));child.once('exit',c=>reject(Error('viewer exited '+c)));});
  browser=await chromium.launch({headless:true});const page=await browser.newPage({viewport:{width:1600,height:1000},reducedMotion:'reduce'});
  const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE ERROR',e.message);});
  const reads=[];page.on('response',async response=>{if(response.url().includes('/api/semantic/')){try{reads.push({operation:response.url().split('/').pop(),request:response.request().postDataJSON(),response:await response.json()});}catch{}}});
  await page.goto(url);await page.waitForFunction(()=>typeof semanticWorkbench!=='undefined'&&semanticWorkbench?.initialized);
  const target={owner:'project:'+summary.source.project,kind:'element',id:'demo:engine'};
  for(const [name,model] of [['source',summary.source],['destination',summary.destination]]){
   await page.evaluate(async ({model,target})=>{await semanticWorkbench.changeModel(model);await semanticWorkbench.open(target,{push:false});},{model,target});
   await page.screenshot({path:out+'/gui-'+name+'-engine.png',fullPage:true});
   await page.evaluate(async()=>await semanticWorkbench.inspect(semanticWorkbench.state.target,'knowledge'));
   await page.screenshot({path:out+'/gui-'+name+'-knowledge.png',fullPage:true});
   await page.getByRole('button',{name:'Explain origin and path'}).first().click();
   await page.locator('dialog.semantic-explanation[open]').waitFor();
   await page.screenshot({path:out+'/gui-'+name+'-property-explanation.png',fullPage:true});
   await page.getByRole('button',{name:'Close explanation',exact:true}).click();
  }
  fs.writeFileSync(out+'/gui-walkthrough.json',JSON.stringify({source:summary.source,destination:summary.destination,target,reads,page_errors:errors},null,2));
  if(errors.length)throw Error(errors.join('\n'));
  console.log('Browser evidence: '+out);
  console.log('Captured source/destination engine and knowledge with exact semantic HTTP requests.');
 }finally{if(browser)await browser.close();child.kill('SIGTERM');}
})().catch(e=>{console.error(e);process.exitCode=1});
