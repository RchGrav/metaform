# Why These Results Failed

The bad run did not first settle what the artifact was. It treated the uploaded
image as source material that could become another kind of visual object. The
intended artifact was the photograph itself.

That mistake redirected the work toward a schematic and a documentation card.
Those outputs are coherent, but they do not improve the original photograph.

The run also failed to state the invariant: the exact device was the subject
and needed to remain unchanged. Without that statement, the process had no
clear boundary around identity.

Finally, the run did not grade the photograph's own elements before choosing a
change. It therefore missed the useful evidence:

- scale and depth cues were absent;
- the setting was weak;
- small inscriptions were hard to read;
- the overhead vantage was flat;
- attention was not directed;
- the captured moment was uninformative.

The good results address those weaknesses through different settings,
vantages, moments, depth models, and lighting while keeping the subject fixed.

The lesson is simple: identify the artifact, identify its elements, state what
must not change, grade the elements, and use that ranking as the basis for the
revision.
