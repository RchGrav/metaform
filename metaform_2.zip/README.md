# Metaform

**Make the project part of the prompt.**

Metaform records what a project actually is in a form AI agents can
reason from on every later task. An intake agent walks the artifact and writes
down its actual parts, what each part is for, who receives its result and why,
organized under a strict functional Type namespace. That record is the
project's **Inference Metaform**. Afterwards, any agent connected to Metaform
starts a task from that recorded understanding instead of rebuilding it from
the raw files. The artifact can be a codebase, one project inside a repository
that holds several, a folder of photographs, a contract, or a story.

This is **Richard Graver's approach to inference amortization**: invest in
understanding up front, retain it in a form agents can use, and give subsequent
reasoning a better place to begin. The goal is more inference available for
design, judgment, problem solving, and creative work, and less spent repeatedly
reconstructing what the project is.

**Private development preview.** Version 0.2 is a development build. The
[verification record](docs/verification.md) distinguishes source tests, browser
journeys, live inference evidence, and delivered-artifact checks. Release-quality
repairs are tracked in the [reconciled backlog](docs/repair-backlog.md).
No measured inference saving is claimed, and a generated Inference Metaform is
evidence to examine, not a verified reference answer.

[See it run in five minutes](#see-it-run-in-five-minutes) ·
[Install](#install) ·
[Onboard your own project](#onboard-your-own-project) ·
[What you can do](#what-you-can-do) ·
[How it works](#how-it-works) ·
[Documentation](#documentation)

## Why this is different from a codebase summary

A summary or an embedding index tells an agent what text is nearby. An
Inference Metaform tells it what things are for. Four properties of the record
make that possible:

- **Relationships are records, not arrows.** Every join carries the receiving
  Element, that receiver's Operative Purpose, the providing Element, the Type
  whose Encounter Function is being received, and the role the join plays for
  the receiver: hard dependency, property, or supportive. An agent asking "what
  breaks if I change this" reads purposes, not adjacency.
- **The namespace is a functional typology.** Types live at dotted addresses
  under five bases (`code`, `document`, `media`, `data`, `exterior`) where every
  prefix is itself a meaningful Type. A Type's common name reads backward from
  the leaf using its recorded `length`: with length 2,
  `code.system.driver.network` is a Network Driver. The Defining Element's
  function is independent of encoding, medium, genre and style; those are
  recorded as properties.
- **Properties travel with their branch.** Bash on the installer and C++ on the
  engine are both visible when reasoning at `code`, and each applies only down
  its own branch. Metaform can explain, for any Element, why a property does or
  does not apply to it.
- **Knowledge attaches without rewriting the foundation.** One instruction
  is applied to the base functional understanding and each distinct whole
  property-qualified composite, then saved as a named, browsable layer.
  An unchanged generic answer remains reusable when a changed composite is reinferred. An outside-in
  review by an agent that sees the recorded account but not the code attaches
  as a report. A variant that swaps one relationship regenerates only the
  knowledge that depended on it.

## See it run in five minutes

This path needs no model key. It replays authored fixture answers through the
real intake, layer, variant, reinference and read APIs, so what you see is the
runtime's actual behavior on a small illustrative artifact: a connectivity
coordinator with a C++ engine and a shell installer, plus a trail-camera
maintenance guide as a non-code artifact.

Requires Python 3.11 or newer and [uv](https://docs.astral.sh/uv/).

```sh
git clone https://github.com/RchGrav/metaform.git
cd metaform
uv sync --frozen
.venv/bin/python examples/realignment/run_demo.py --output /tmp/metaform-demo
```

It finishes in a few seconds and prints a summary whose `status` is `passed`.
Then open the result in the workbench:

```sh
.venv/bin/python examples/realignment/serve_demo.py --summary /tmp/metaform-demo/summary.json
```

Open the printed URL. In the Graph view, click the engine. The inspector shows
its Type bindings, its joins with their purposes and signals, and its relation
to the Defining Element. Switch the model to `javascript-variant` to see the
same engine after its medium was swapped from C++ to JavaScript, with the
source model untouched.

What to read in `/tmp/metaform-demo`:

| File | What it shows |
| --- | --- |
| `property-explanation.json` | Why the engine has the C++ property: `applies: true`, with the origin and the path it travelled. |
| `sibling-property-explanation.json` | The same engine asked about the installer's shell property: `applies: false`. Properties do not leak across branches. |
| `engine-layer/`, `installer-layer/`, `noncode-layer/` | Requested knowledge layers for the engine, the installer and the maintenance guide, each with the exact assignment and answer. |
| `transformation-result.json` | The variant's impact report: regenerate the engine layer, preserve the installer layer. |
| `reinference-0-assignment.json` | The engine layer's original request reissued against the JavaScript context. |
| `grounded-task-assignment.json` | What a task prompt looks like once it is grounded in the model: it names actual Elements, joins and Types instead of describing them. |
| `transport-parity.json` | The same read returning identical results through the CLI, MCP and the workbench API. |

The lifecycle answers are authored fixtures. They establish the mechanics, not
the quality of any model's output.

### See a real project

`examples/intake/mgm-main/` is a completed intake of a real mesh gateway
project, saved as generated: 58 actual Elements, 47 Types and 101 joins in
`native.json`, with the agent's overall account and diagram in its
`understanding` field. Start at `elements["mgm:project"]`, the Defining
Element, and follow its joins. The screenshot below is the workbench's
**History / Compare** view, reached from the header of the explorer, showing one of its Elements.

![The workbench showing the Upstream DNS responders Element of the MGM sample, its Type, and its hard-dependency joins with purposes and signals](examples/intake/mgm-main/viewer.png)

Load its original graphs without inference using:

```sh
metaform package sample
```

The installed package includes the retained sample. The loader prints a portable project path and its browse command. Open
the **History / Compare** link in the workbench header. The sample was produced by an earlier two-pass runtime; its
[README](examples/intake/mgm-main/README.md) records the provenance.

A [current v2 Foundation capture](docs/reviews/2026-09-11-live-foundation/README.md)
shows an actual new Metaform self-intake, with its model/revision and browser
requests retained. This demonstrates the view; semantic review of the generated
account remains a separate check.

## Discover the installed tool

```sh
metaform
metaform --help
metaform system reference --module intake
metaform system settings
```

A fresh launch explains how to begin; an existing project reports its current
state and next action. Use `metaform <module> --help` for its commands and
`metaform <module> <command> --help` for arguments and examples. The same entry
points work as `python dist/metaform ...` when running a rebuilt archive.
[CLI and harnesses](docs/cli-and-harnesses.md) covers output, settings scopes and
client project selection.

## Install

Requires **Python 3.11 or newer**. From a checkout:

```sh
uv tool install --refresh .
metaform install
```

`uv tool install` selects a suitable Python even when the system interpreter is
older; `--refresh` makes it build from the checkout instead of reusing a cached
wheel of the same version. `python -m pip install .` also works with a 3.11+
interpreter.

`metaform install` creates a missing `metaform` launcher in `~/.local/bin`,
preserves an existing launcher (including a uv-managed one), detects
Codex, Claude Code, Gemini CLI, Cursor and VS Code, and asks which to
configure. For each harness you choose it registers the MCP server connection
and writes the Metaform skill where that harness discovers skills
(`~/.claude/skills`, `~/.codex/skills`, `gemini skills install`). It always
writes the skill to `~/.agents/skills/metaform/SKILL.md`, the cross-client
convention other harnesses read. Configuration files Metaform touches are
backed up first; other servers are retained. Without a terminal, pass the
harnesses explicitly:

```sh
metaform install --harness claude --harness codex
```

Restart or reconnect the harness afterwards. After pulling new commits,
reinstall so the launcher matches the checkout:

```sh
uv tool install --reinstall --refresh .
```

Two things to know about the runtime:

- Help, reference, settings inspection and installer setup do not register a
  project. Commands that open a new project register its selected folder and
  use the user-local knowledge service. Run
  commands from the project folder, or pass `--project /path/to/project`.
  `metaform service status` and `metaform service stop` manage the service.
- `metaform browse` starts the workbench on an available local port. Open the
  returned URL. `--human` selects readable CLI output; `--json` retains structured
  results. Metaform does not launch a browser.

For a harness Metaform does not detect, add this stdio server (the surrounding
format depends on the harness):

```json
{
  "command": "metaform",
  "args": ["mcp"],
  "env": {"METAFORM_PROJECT": "/path/to/your/project"}
}
```

A registered connection uses the launcher's absolute path, so `metaform` need
not be on PATH for it. On newer negotiated MCP protocols, a compact tool list includes the `metaform`
router and directly exposed commands; older protocols list each visible command.
The exact inventory follows registered modules. Ctrl-c stops `metaform mcp` when you run it by
hand; a harness normally owns that process.

## Onboard your own project

Open the project in your harness and say:

> Use Metaform to intake this project.

The MCP server instructs your agent at connection time: it sends the concierge
guidance and the project's current onboarding stage. `guide.start` returns the
applicable next action; module reference supplies operative instructions on
demand. Your agent
selects the project, starts the workbench and tells you its URL, then runs
intake. Intake is delegated to a fresh agent bound to the assignment by a
nonce; you do not manage nonces or answer files. Intake is a model run: the
retained live runs on small sources took two to five minutes and reported
160k to 556k input tokens each, most of it cached context. Start from an existing
repository or supply a plan for a design you intend to build; with a plan,
intake describes the intended design, and the plan is preserved as context.

Setup is complete when three things exist: the Inference Metaform, a **Best
Practices** knowledge layer generated over every recorded Element, join and
applicable property, and that layer selected as the model's default. Then:

> Always follow all best practices when working on this project.

The agent retrieves the recorded advice that applies to the Elements it is
touching and works from it. Other things to ask for:

> Show me the Inference Metaform.

> Use creative thinking with foresight to make the top 6 imperatives.
> Save them in a layer called Creative Imperatives.

> Run the blind-spot detector.

The second creates a layer with **Knowledge Tool**. Your instruction is preserved
for a reusable base question and a question about each complete property-qualified
composite, keeping properties with their originating components. Joins supply the
functional context rather than separate questions. The answers and their individual
dependencies form a browsable layer; changing a composite reruns the saved instruction
for that context while retaining unchanged generic knowledge.
The third asks an agent that receives the complete recorded account but
never opens the repository to say where it agrees, disagrees or sees omissions;
the result attaches as a report layer and changes nothing until you apply a
correction. The skill instructs incoming agents to run it periodically.

### From the terminal

With an installed, authenticated Codex CLI, the same onboarding runs without
an MCP host:

```sh
cd /path/to/your/project
metaform intake start
metaform drive codex
metaform knowledge start --request "Write 3 best practices" --name "Best Practices"
metaform drive codex
metaform layer select --layer '<layer id returned by generation>'
metaform guide start
```

Starting an exclusive assignment selects that module's mode. Help and reference
remain available, registered commands retain their argument syntax, and
unavailable commands report an error. Use `--no-exclusive` on `workflow start`
for independent runs and retain the returned run/request IDs. `metaform abort`
leaves the active mode. Other command harnesses need an adapter configured in
`~/.metaform/config.json`; see [the example](examples/harness-config.json).
Commands that take `--model` want the JSON object returned by
`metaform model discover`; it can be omitted when the project has one model.

## What you can do

| Capability | What you get | Where |
| --- | --- | --- |
| **Intake** | One immutable foundation revision from a repository, a plan, or a non-code artifact: actual Elements with freeform descriptions, the Types that organize them, and joins carrying receiver, purpose, provider, provider Type and role. Contributions save incrementally; a run resumes after interruption. | `intake.*`, `guide.start` |
| **Knowledge layers** | Best Practices by default; any instruction through Knowledge Tool; custom-schema layers; per-model default selection. Each layer keeps its request, prompts, schema and generation history, and can be regenerated or removed alone. | `knowledge.preview`, `knowledge.start`, `layer.*` |
| **Applicable knowledge for a task** | Read what applies at an Element, join or region, with the origin of each record and an explanation of why a property does or does not apply. Reads inside an assignment are pinned to its revision. | `knowledge.get`, `knowledge.explain`, `workflow.knowledge` |
| **Blind-spot report** | Outside-in review of the recorded account without repository access, attached as a report layer. Applying a finding creates a new revision with the reason retained. | `analysis.blindspots`, `model.expand` |
| **Semantic reads** | Browse the namespace, inspect Types and members, actual Elements, complete joins, bounded neighborhoods and grounded task context. The same read returns identical results through CLI, MCP and the workbench. | `namespace`, `type`, `element`, `join`, `model.ground` |
| **Variants and reinference** | Clone a model, replace one relationship (the engine's medium from C++ to JavaScript), and get a destination model whose affected layers are regenerated from their original requests while the source keeps its understanding. | `model.clone`, `model.transform`, `model.impact` |
| **Executable workflows** | Convert a written process into a stored workflow; specialize a general workflow to this project's Elements without changing its authored control flow; run prompt, branch, foreach, call, parallel and tool steps with durable pending assignments and nonce handoffs. | `workflow.*`, workbench Workflows and Prompts |
| **Portable projects** | Export an executable archive that runs the CLI, workbench and MCP on JSON knowledge and local SQLite with no service; checkpoint files without committing; import a returned archive and keep divergent histories. | `package export/import`, `history.*` |
| **Workbench** | An explorer of what the agent sees through MCP: the namespace tree, neighborhood cards named from the namespace, an inspector that flips to the exact envelope of each read, layers, the stage banner, and a console that runs any tool and shows the initialization the agent receives. The earlier editors and History / Compare stay behind the header links. | `metaform browse` |
| **Modules** | Drop a manifest and a Python handler into `~/.metaform/modules/<module>/` or `<project>/.metaform/modules/<module>/` and its commands appear in the CLI, in MCP and in the skill catalog your agent reads. Modules travel with exports. | [module example](examples/module/module.json) |
| **Media** | Image generation and editing through the Codex image tool, for artifacts such as a product photograph whose purpose is resale. | `imagegen.generate` |
| **Self-understanding and customization** | The chassis Native functional account, customization procedures and live module reference; Metaform's checkout can also be selected for a separate self-intake. | `guide.chassis`, [module interface](examples/module/README.md) |

The repaired source supplies the chassis account and public module interface.
Their integrated delivery, the converted source-procedure library and complete
customization/refactoring demonstrations remain separately tracked in the
[release repair status](docs/release-quality-status.md). General refactoring
instructions can be grounded through workflow specialization.

## How it works

Intake starts outside the artifact, with the exterior Receiving Entity that
has an Operative Purpose for it: the player of a game, the buyer of a used
camera, the operator of a gateway. It then finds the **Defining Element**, the
thing whose loss would leave the artifact unable to remain the same Type. The
Defining Element is a representative composite of the artifact, not an
entrypoint, and its identity excludes medium, encoding, genre and style. From
there intake names the Defining Element's properties and hard requirements and
builds joins to the Elements that satisfy them, where the current Element is
the receiver and the joined Element provides the Encounter Function that meets
the receiver's purpose. It recurses until the represented functions and
relationships form a useful orientation, deliberately coarse; depth is added
later, on request, for the region a task needs.

The resulting **Native Metaform** is the project's Inference Metaform. Actual
Elements keep their own identities and freeform descriptions; reusable Types
keep a universal description and a single Encounter Function; bindings connect
the two. Every later operation, from a best-practices question to a grounded
task prompt, resolves against those records.

Terms you will meet:

| Term | Meaning |
| --- | --- |
| **Element** | Anything under examination: a subsystem, a file, a photograph's subject, an outside party. Actual Elements are the project's own things; Types organize them. |
| **Type** and **Namespace** | A Type sits at a dotted address whose every prefix is a Type; its name reads backward from the leaf. `exterior` holds entities outside the project. |
| **Receiving Entity**, **Operative Purpose**, **Encounter Function** | Who or what receives a result, why they receive it, and how the providing Element delivers it. A join binds one of each. |
| **Defining Element** | The Element that makes the artifact what it is. |
| **Join roles** | Hard dependency, property, or supportive, recorded on the join that belongs to the receiver's purpose. A signal describes the way the purpose is satisfied. |
| **Property transitivity** | A property joined at one position is visible toward the trunk and applies down its own branch only. |
| **Knowledge layer** | Separately owned knowledge attached to the foundation: Best Practices, a blind-spot report, or any instruction's answers. |
| **Latent** reasoning | Reasoning on the recorded account from outside the implementation frame, by an agent that receives everything intake built and does not read the code. |

The [specification](docs/SPEC.md) defines the semantic contract and acceptance
scenarios. The [primer](docs/primer/README.md) gives the narrative and a
technical account; its two-pass mechanics are historical, and the specification
is current where they differ.

## Documentation

| Document | Use it for |
| --- | --- |
| [Documentation index](docs/README.md) | Start here for current reference, semantic authority and historical evidence. |
| [Specification](docs/SPEC.md) | Capabilities, semantic contract, acceptance scenarios. |
| [Workflow and semantic operations](docs/workflows.md) | Workflow format, layer and model commands, assignment continuation. |
| [Version guide](docs/next-version.md) | Storage, archives, import rules, installed versus portable runtime. |
| [Architecture and research](docs/architecture.md) | Chassis, MCP orchestration, reified graph, semantic models. |
| [Workbench navigation](docs/workbench-navigation.md) | Graph controls, inspector, layers, revisions. |
| [Semantic sources](docs/semantics/README.md) | The rules, worked examples and Rich's design statements, including the photograph examples. |
| [Realignment demonstration](examples/realignment/README.md) | The demo above, the live prompt comparison and its retained evidence. |
| [Current work](docs/current-work.md) and [Verification](docs/verification.md) | What is implemented, what was tested, and what is not established. |
| [CI guide](docs/ci.md) | Enabling the workflow in a fork. |
| [Reconciled repair backlog](docs/repair-backlog.md) | Established work and narrowly separated proposals, with original review IDs retained. |

## Build, test and CI

```sh
uv sync --frozen
uv run --frozen pytest -q
uv run --frozen python tools/build_distribution.py
```

The build writes a wheel and an extensionless executable archive to `dist/`;
`python dist/metaform browse` runs the archive directly. GitHub Actions tests
Python 3.11 and 3.13, builds both files and checks installed and offline
execution on every push. In a fork, `gh auth login` then
`metaform package ci --repository YOUR_ACCOUNT/metaform` enables and starts
that workflow; see [the CI guide](docs/ci.md).

## Contributing and state

The community opportunity is to make useful understanding reusable: Type
knowledge and global joins, prompts with test results, workflows for
refactoring, porting, analysis and creative work, modules and schemas, and
workbench improvements. The `sync` module exports and pushes reusable global
inference data through the configured Git remote. For now the focus is private
testing, semantic refinement, and examples that demonstrate the approach.

What the evidence supports today is recorded in [verification](docs/verification.md):
fixture-driven mechanics across intake, layers, applicability, variants,
reinference, transport parity and portable execution; six matched live intake
runs whose review declines to rank prompt quality; and one live grounded task
that correctly used recorded Element, join and layer references. Source
attribution is in [NOTICE.md](NOTICE.md).

The SPEC success signal is: “After preparation, a compact type-level instruction
can produce project-specific results that depend on represented semantic
relationships without restating those relationships in the instruction.” Source
checks establish their exercised mechanisms; they are not a measurement of that
semantic outcome across projects.
