"""Exercise whole-artifact handoff, portable transfer and apply using delivered CLIs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--portable-python', default=sys.executable)
    args = parser.parse_args()
    import metaform
    assert 'site-packages' in str(Path(metaform.__file__).resolve()), metaform.__file__
    print(json.dumps({'python': sys.version, 'import_origin': metaform.__file__,
                      'archive_sha256': hashlib.sha256(args.archive.read_bytes()).hexdigest()}), flush=True)
    command = [str(Path(sys.executable).with_name('metaform'))]
    with tempfile.TemporaryDirectory(prefix='metaform-artifact-workfolder-') as temporary:
        root = Path(temporary)
        project, home = root / 'source', root / 'home'
        project.mkdir()
        home.mkdir()
        (home / 'config.json').write_text(json.dumps({'knowledge_mode': 'legacy', 'graph_backend': 'json', 'auto_build': False}))
        environment = {k: v for k, v in os.environ.items() if not k.startswith('METAFORM_')}
        environment.update(PYTHONPATH='', METAFORM_PROJECT=str(project), METAFORM_HOME=str(home), METAFORM_RUNTIME_DIR=str(root / 'installed-runtime'))
        (project / '.gitignore').write_text('*.bin\nignored/\n')
        (project / 'ignored').mkdir()
        (project / 'ignored/input.txt').write_text('initial')
        (project / 'deleted.bin').write_bytes(b'\0delete')
        (project / 'renamed.txt').write_text('rename')
        (project / 'kept-empty').mkdir()
        (project / 'removed-empty').mkdir()
        (project / 'link').symlink_to('ignored/input.txt')
        workflow = root / 'edit.json'
        workflow.write_text(json.dumps({'id': 'artifact-edit', 'steps': [{'id': 'edit', 'prompt': 'Edit the artifact.'}]}))

        def invoke(launcher, *arguments, cwd=root, env=environment):
            result = subprocess.run([*launcher, *arguments], cwd=cwd, env=env, text=True, capture_output=True, timeout=30)
            assert result.returncode == 0, (arguments, result.stderr, result.stdout)
            return json.loads(result.stdout)

        invoke(command, 'workflow', 'import', '--path', str(workflow))
        job = invoke(command, 'workflow', 'start', '--id', 'artifact-edit', '--workfolder', '--no-exclusive')
        folder = Path(job['workfolder'])
        assert (folder / '.git').exists(), 'JSON knowledge must retain Git workfolder tracking'
        assert (folder / 'ignored/input.txt').read_text() == 'initial'
        invoke(shlex.split(job['begin']), cwd=folder)
        assert (folder / '.agentid/nonce').exists()
        (folder / 'ignored/input.txt').write_text('edited')
        (folder / 'added.bin').write_bytes(b'\0\xffadded')
        (folder / 'deleted.bin').unlink()
        (folder / 'renamed.txt').rename(folder / 'new-name.txt')
        (folder / 'removed-empty').rmdir()
        (folder / 'new/empty').mkdir(parents=True)
        (folder / 'kept-empty').chmod(0o700)
        (folder / 'link').unlink()
        (folder / 'link').symlink_to('new-name.txt')
        exported = root / 'transferred'
        bundle = invoke(command, 'package', 'export', '--path', str(exported))
        with zipfile.ZipFile(exported) as archive:
            assert any(name.endswith('new/empty/') for name in archive.namelist())
        offline_env = {k: v for k, v in environment.items() if not k.startswith('METAFORM_')}
        offline_env.update(PATH='', PYTHONPATH='', METAFORM_RUNTIME_DIR=str(root / 'portable-runtime'))
        portable = [args.portable_python, '-S', str(exported)]
        copied = invoke(portable, 'workflow', 'next', '--run-id', job['run_id'], env=offline_env)
        copied_folder = Path(copied['workfolder'])
        assert copied_folder != folder
        assert (copied_folder / 'new/empty').is_dir()
        assert (copied_folder / 'added.bin').read_bytes() == b'\0\xffadded'
        assert (copied_folder / 'link').is_symlink()
        invoke(portable, 'workflow', 'answer', '--run-id', copied['run_id'], '--request-id', copied['request_id'], '--answer', '"done"', env=offline_env)
        assert not (copied_folder / '.agentid/nonce').exists()
        assert (folder / '.agentid/nonce').exists(), 'Completing copied work must preserve original dispatch'
        final = invoke(portable, 'workflow', 'next', '--run-id', copied['run_id'], env=offline_env)
        identifier = final['result']['workfolder']['id']
        report = invoke(portable, 'workfolder', 'diff', '--id', identifier, env=offline_env)
        assert '.agentid' not in report['diff']
        applied = invoke(portable, 'workfolder', 'apply', '--id', identifier, env=offline_env)
        assert applied['applied']
        target = root / bundle['mform_sha_id']
        assert (target / 'ignored/input.txt').read_text() == 'edited'
        assert (target / 'added.bin').read_bytes() == b'\0\xffadded'
        assert not (target / 'deleted.bin').exists()
        assert not (target / 'renamed.txt').exists()
        assert (target / 'new-name.txt').read_text() == 'rename'
        assert (target / 'new/empty').is_dir()
        assert not (target / 'removed-empty').exists()
        assert (target / 'kept-empty').stat().st_mode & 0o777 == 0o700
        assert (target / 'link').readlink() == Path('new-name.txt')
        assert not (target / '.agentid/nonce').exists()
        assert not (project / '.git').exists()
        assert (project / 'ignored/input.txt').read_text() == 'initial'
        print('Delivered Git workfolder → offline portable file tracking → completion → apply passed: ignored/binary/deletion/rename/symlink/empty-directory/mode changes and independent nonce cleanup.')


if __name__ == '__main__':
    main()
