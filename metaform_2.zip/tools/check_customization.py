"""Exercise a built executable using only its own guide/reference and public CLI."""
import hashlib,json,os,shlex,shutil,subprocess,sys,time
from pathlib import Path
artifact=Path(sys.argv[1]).resolve()
root=Path(sys.argv[2]).resolve();root.mkdir(parents=True,exist_ok=True)
env={key:value for key,value in os.environ.items() if not key.startswith('METAFORM_')}
env.update(PYTHONPATH='',PATH='',METAFORM_HOME=str(root/'unrelated-home'),METAFORM_RUNTIME_DIR=str(root/'runtime'))
logs=[]
def invoke(args,cwd=None,project=None,exact=None):
 command=exact or [sys.executable,'-S',str(artifact),'--json',*(['--project',str(project)] if project else []),*args]
 result=subprocess.run(command,cwd=cwd or root,env=env,text=True,capture_output=True,timeout=50)
 record={'argv':command,'cwd':str(cwd or root),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 logs.append(record);(root/'transcript.json').write_text(json.dumps(logs,indent=2))
 assert result.returncode==0,record
 try:return json.loads(result.stdout)
 except json.JSONDecodeError:return result.stdout

def fingerprint(folder):
 return {str(p.relative_to(folder)):hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.rglob('*') if p.is_file()}

def complete(project,job):
 # Execute the exact stored handoff in the actual empty worker directory.
 begin=invoke([],cwd=job['workfolder'],exact=shlex.split(job['begin']))
 assert begin['request_id']==job['request_id']
 args=['workflow','answer','--run-id',job['run_id'],'--request-id',job['request_id'],'--answer',json.dumps('Reviewed the supplied subject.')]
 receipt=invoke(args,cwd=job['workfolder'])
 assert receipt['recorded']
 assert not (Path(job['workfolder'])/'.agentid/nonce').exists()
 result=invoke(['workflow','next','--run-id',job['run_id']],project=project)
 assert result['status']=='complete',result
 replay=invoke(args,project=project);assert replay==receipt
 return result

summary={'artifact':str(artifact),'sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'python':sys.version,'environment':{'PYTHONPATH':'','PATH':'','METAFORM_HOME':env['METAFORM_HOME'],'METAFORM_RUNTIME_DIR':env['METAFORM_RUNTIME_DIR']},'root':str(root)}
try:
 help_text=invoke(['--help']);chassis=invoke(['guide','chassis']);settings=invoke(['system','settings'])
 assert not (root/'.metaform').exists() and not (root/'unrelated-home').exists()
 # Install the module example supplied by the artifact itself, then customize its own counter using the supplied API guide.
 example=chassis['procedures']['build-module']['example']
 project=root/'source-project';module=project/'.metaform/modules/review';module.mkdir(parents=True)
 (project/'.metaform/config.json').write_text(json.dumps({'knowledge_mode':'portable','auto_build':False}))
 for name,value in example.items():(module/name).write_text(json.dumps(value,indent=2) if isinstance(value,dict) else value)
 manifest=json.loads((module/'module.json').read_text());manifest['commands'].append({'name':'visits','handler':'handler.py:visits','description':'Read the module-owned review count.','inputSchema':{'type':'object','properties':{}},'returns':'The count retained by this module in this project.','examples':[{'arguments':{},'description':'Read the retained count.'}]})
 (module/'module.json').write_text(json.dumps(manifest,indent=2))
 handler=(module/'handler.py').read_text().replace('async def start(api, arguments, context):','async def start(api, arguments, context):\n    api.set("visits", api.get("visits", 0) + 1)')
 handler+='\ndef visits(api, arguments, context):\n    return {"count": api.get("visits", 0), "project": api.project["path"]}\n';(module/'handler.py').write_text(handler)
 reference=invoke(['system','reference','--module','review'],project=project);assert 'review.start' in json.dumps(reference)
 job=invoke(['review','start','--subject','the delivered module lifecycle'],project=project)
 assert job['prompt']=='Review the delivered module lifecycle.'
 complete(project,job)
 assert invoke(['review','visits'],project=project)['count']==1
 user_source=root/'user-review.json'
 user_source.write_text(json.dumps({'id':'user-review','steps':[{'id':'choice','kind':'user','prompt':'Which subject should be reviewed?','schema':{'type':'string'},'save_as':'subject'},{'id':'review','prompt':'Review selected subject: {{ subject }}.','context':'fresh'}]}))
 invoke(['workflow','import','--path',str(user_source)],project=project)
 question=invoke(['workflow','start','--id','user-review','--no-exclusive'],project=project)
 assert question['status']=='awaiting_user' and question['prompt']=='Which subject should be reviewed?'
 repeated=invoke(['workflow','next','--run-id',question['run_id']],project=project);assert repeated==question
 driven=invoke(['workflow','drive','--run-id',question['run_id']],project=project);assert driven['status']=='awaiting_user',driven
 invoke(['workflow','answer','--run-id',question['run_id'],'--request-id',question['request_id'],'--answer',json.dumps('the selected interface')],project=project)
 continuation=invoke(['workflow','next','--run-id',question['run_id']],project=project)
 assert continuation['prompt']=='Review selected subject: the selected interface.'
 complete(project,continuation)
 exported=invoke(['package','export','--path',str(root/'shared.pyz')],project=project)
 assert exported['unresolved']==[],exported['unresolved']
 shared=root/'shared.pyz';target=root/exported['mform_sha_id']
 # Archive-first reference reads the exported module and workflow without creating the sibling.
 for args in [['review','--help'],['system','reference'],['system','settings'],['skill'],['guide','chassis']]:
  output=invoke([],exact=[sys.executable,'-S',str(shared),*args]);assert not target.exists()
  if args==['guide','chassis']:assert 'review' in json.dumps(output['workflows'])
 imported=invoke(['package','import','--path',str(shared),'--destination',str(root/'copies')],project=project)
 copy=Path(imported['path']);assert copy!=project
 assert invoke(['review','visits'],project=copy)['count']==1
 second=invoke(['review','start','--subject','the shared portable module'],project=copy);complete(copy,second)
 assert invoke(['review','visits'],project=copy)['count']==2
 assert invoke(['review','visits'],project=project)['count']==1
 shutil.rmtree(copy/'.metaform/modules/review')
 assert 'review.start' not in json.dumps(invoke(['system','reference'],project=copy))
 assert 'review.start' in json.dumps(invoke(['system','reference'],project=project))
 # Use the archive's own project once, then prove repeated reference preserves its file contents.
 invoke([],exact=[sys.executable,'-S',str(shared),'review','visits'])
 before=fingerprint(target)
 for args in [['review','--help'],['system','reference'],['system','settings'],['skill'],['guide','chassis']]:
  invoke([],exact=[sys.executable,'-S',str(shared),*args]);assert fingerprint(target)==before,args
 sample=invoke(['package','sample','--destination',str(root/'historical-sample')])
 assert sample['view']=='History / Compare' and sample['provenance']['files']['native.json']['actual_elements']==58
 summary.update(status='passed',public_calls=len(logs),module_source='guide.chassis bundled example; visits customized from its public API instructions',sample=sample,source_project=str(project),imported_project=str(copy),shared_sha256=hashlib.sha256(shared.read_bytes()).hexdigest(),covered=['fresh reference has no project/home side effects','module example discovery and customization','exact stored begin from worker folder','answer completion receipt replay','portable module/data sharing and state isolation','copy-only removal','archive reference before and after materialization','packaged historical sample without source checkout','authored user wait remains pending across next/drive and routes explicit test response to subsequent worker'])
except BaseException as exc:
 summary.update(status='failed',error=type(exc).__name__+': '+str(exc));raise
finally:
 (root/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
