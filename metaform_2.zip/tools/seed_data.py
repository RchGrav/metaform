"""Generate the shipped command descriptors and starter schema registry."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "src/metaform/data"
ROOT.mkdir(parents=True, exist_ok=True)


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


def field(kind="string", **kwargs):
    return {"type": kind, **kwargs}


def cmd(name, handler, description, properties=None, required=None, always=False):
    return {
        "name": name,
        "handler": "metaform.modules." + handler,
        "description": description,
        "inputSchema": {
            "type": "object",
            "properties": properties or {},
            "required": required or [],
        },
        "always_available": always,
    }


def module(name, commands, raw=None):
    doc = {"id": name, "commands": commands}
    if raw:
        doc["raw_handler"] = "metaform.modules." + raw
        doc["disable_argparse"] = True
    save(ROOT / "modules" / (name + ".json"), doc)


run = {"run_id": field()}
answer = run | {"request_id": field(), "answer": {}}
drive = run | {"harness": field(default="mcp"), "steps": field("integer")}
module(
    "intake",
    [
        cmd(
            "start",
            "intake:start",
            "Start contextual intake, Type proof, and independent global inference.",
        ),
        cmd(
            "next",
            "intake:next",
            "Receive the next independent intake assignment.",
            run | {"request_id": field()},
        ),
        cmd(
            "batch",
            "intake:batch",
            "Receive independent per-Type assignments for dispatch to separate subagents.",
            run | {"limit": field("integer", minimum=1)},
        ),
        cmd(
            "answer",
            "intake:answer",
            "Record the structured answer and its source.",
            answer,
            ["answer"],
        ),
        cmd(
            "search",
            "intake:search",
            "Search local/global Types during contextual intake or global Types during Archaeology.",
            {"query": field(default="*")},
        ),
        dict(
            cmd(
                "files",
                "intake:files",
                "List project files for the contextual intake pass.",
                run,
            ),
            hidden_when={"!=": [{"var": "run.stage"}, "native"]},
        ),
        dict(
            cmd(
                "read",
                "intake:read",
                "Read a project text file during contextual intake.",
                run | {"path": field()},
                ["path"],
            ),
            hidden_when={"!=": [{"var": "run.stage"}, "native"]},
        ),
        cmd(
            "get",
            "intake:get",
            "Read a candidate Type object without joins.",
            run | {"id": field()},
            ["id"],
        ),
        cmd(
            "inference",
            "intake:inference",
            "Retrieve a Type's completed global dependency structure for inference reuse.",
            run | {"id": field()},
            ["id"],
        ),
        cmd(
            "put",
            "intake:put",
            "Author objects and joins in the active intake perspective.",
            run | {"graph": field("object"), "request_id": field()},
            ["graph"],
        ),
        cmd(
            "drive",
            "intake:drive",
            "Run intake with one fresh assignment per Type and concurrent independent global inference.",
            drive | {"concurrency": field("integer", minimum=1, default=4)},
        ),
    ],
    "intake:raw",
)
module(
    "workflow",
    [
        cmd(
            "import",
            "workflow:import_file",
            "Import JSON control flow or an exact prose prompt.",
            {"path": field()},
            ["path"],
        ),
        cmd(
            "start",
            "workflow:start",
            "Start a graph-backed workflow.",
            {
                "id": field(),
                "inputs": field("object"),
                "exclusive": field("boolean", default=True),
                "workfolder": field("boolean", default=False),
            },
            ["id"],
        ),
        cmd(
            "next",
            "workflow:next",
            "Return the pending assignment or take one structural transition.",
            run,
        ),
        cmd(
            "answer",
            "workflow:answer",
            "Record an answer with schema annotations.",
            answer,
            ["answer"],
        ),
        cmd(
            "drive",
            "workflow:drive",
            "Drive conditional, nested, or repeated work through a harness.",
            drive,
        ),
        cmd(
            "recurse",
            "workflow:recurse",
            "Start a related development run from prior results.",
            run | {"inputs": field("object")},
        ),
        cmd(
            "lexicalize",
            "workflow:lexicalize",
            "Commission graph-grounded specialization while retaining the source instruction.",
            {"focal": field(), "prompt": field(), "depth": field("integer", default=1)},
            ["focal", "prompt"],
        ),
        cmd(
            "files", "workflow:files", "List files in the workflow's working copy.", run
        ),
        cmd(
            "read",
            "workflow:read",
            "Read a text file in the workflow's working copy.",
            run | {"path": field()},
            ["path"],
        ),
        cmd(
            "specialize",
            "workflow:specialize",
            "Specialize a workflow against a selected graph while retaining its source.",
            {"id": field(), "focal": field(), "depth": field("integer")},
            ["id", "focal"],
        ),
        cmd(
            "apply",
            "workflow:apply",
            "Import a completed specialization as a separately traceable workflow.",
            run | {"id": field()},
            ["run_id"],
        ),
        cmd(
            "search",
            "workflow:search",
            "Search graph objects inside a workflow.",
            {"query": field(default="*"), "layer": field()},
        ),
        cmd(
            "get",
            "workflow:get",
            "Inspect a workflow's selected graph object and its joins.",
            {"id": field()},
            ["id"],
        ),
        cmd(
            "put",
            "workflow:put",
            "Store workflow-produced graph data.",
            {
                "graph": field("object"),
                "layer": field(default="results"),
                "source": field(default="workflow"),
            },
            ["graph"],
        ),
    ],
    "workflow:raw",
)
module(
    "graph",
    [
        cmd(
            "search",
            "graph:search",
            "Browse Namespace, aliases, descriptions, and arbitrary data layers.",
            {"query": field(default="*"), "layer": field()},
        ),
        cmd(
            "get",
            "graph:get",
            "Inspect a record, incident joins, and provenance.",
            {"id": field(), "global": field("boolean")},
            ["id"],
        ),
        cmd(
            "browse",
            "graph:browse",
            "Walk the hypergraph with cycle-safe assembly.",
            {
                "id": field(),
                "depth": field("integer"),
                "scope": field(),
                "category": field(),
            },
            ["id"],
        ),
        cmd(
            "put",
            "graph:put",
            "Store schema-specific objects and reified joins.",
            {
                "graph": field("object"),
                "source": field(default="native"),
                "layer": field(default="elements"),
            },
            ["graph"],
        ),
        cmd(
            "dump",
            "graph:dump",
            "Export the graph as independently addressable objects and joins.",
            {"global": field("boolean"), "path": field()},
        ),
        cmd(
            "clean",
            "graph:clean",
            "Rebuild derived merges and inspect relational integrity.",
        ),
        cmd("stats", "graph:stats", "Report local and global graph counts."),
    ],
)
module(
    "system",
    [
        cmd("status", "system:status", "Inspect the current project and routing mode."),
        cmd(
            "modules",
            "system:modules",
            "Discover commands without importing their implementations.",
        ),
        cmd(
            "configure",
            "system:configure",
            "Update chassis and harness configuration.",
            {"settings": field("object")},
            ["settings"],
        ),
        cmd(
            "debug",
            "system:debug",
            "Capture full interactions visible to the chassis.",
            {"enabled": field("boolean", default=True)},
        ),
        cmd("traces", "system:traces", "Read interaction traces and run events.", run),
        cmd(
            "forms",
            "system:forms",
            "List the available schema purposes; additional forms and layers are open-ended.",
        ),
    ],
)
module(
    "schema",
    [
        cmd("list", "system:schema_list", "Browse independently addressable schemas."),
        cmd(
            "add",
            "system:schema_add",
            "Register an additional JSON Schema.",
            {"schema": field("object")},
            ["schema"],
        ),
    ],
)
rulebook_commands = [
    cmd(
        "get",
        "rulebook:get",
        "Inspect a semantic rule and its priming material.",
        {"rule_code": field()},
        ["rule_code"],
    ),
    cmd(
        "put",
        "rulebook:put",
        "Save a semantic rule as authored reasoning data.",
        {"rule": field("object")},
        ["rule"],
    ),
    cmd(
        "prepare",
        "rulebook:prepare",
        "Prepare exact rule revisions, including priming unless concise-only use is explicitly requested for an already-primed context.",
        {
            "rule_codes": field("array", items=field()),
            "concise_only": field("boolean", default=False),
        },
        ["rule_codes"],
    ),
]
for command in rulebook_commands:
    command.pop("always_available")
module("rulebook", rulebook_commands)
module(
    "workfolder",
    [
        cmd(
            "create",
            "system:folder_create",
            "Create a Git-tracked working copy, including from a non-repository folder.",
            {"source": field(), "empty": field("boolean")},
        ),
        cmd(
            "diff",
            "system:folder_diff",
            "Inspect all tracked and newly created changes with git diff.",
            {"id": field()},
            ["id"],
        ),
        cmd(
            "apply",
            "system:folder_apply",
            "Apply a workfolder diff to its source, checking for conflicts first.",
            {"id": field()},
            ["id"],
        ),
        cmd(
            "cleanup",
            "system:folder_clean",
            "Record the diff and remove a managed workfolder.",
            {"id": field()},
            ["id"],
        ),
    ],
)
module(
    "imagegen",
    [
        cmd(
            "generate",
            "imagegen:invoke",
            "Generate or edit an image using the existing Codex image tool.",
            {
                "prompt": field(),
                "output": field(),
                "image": field(),
                "dry_run": field("boolean"),
            },
            ["prompt"],
            True,
        )
    ],
)
module(
    "package",
    [
        cmd(
            "build",
            "package:build",
            "Build a wheel containing the current code, schemas, and packaged graph data.",
            {"source": field()},
        )
    ],
)
module(
    "sync",
    [
        cmd(
            "export",
            "sync:export",
            "Export global objects and global joins as Git-mergeable files.",
            {"repository": field()},
        ),
        cmd(
            "merge",
            "sync:merge",
            "Commit global updates, merge the remote branch, and push to GitHub.",
            {
                "repository": field(),
                "remote": field(default="origin"),
                "branch": field(default="main"),
                "message": field(),
            },
        ),
    ],
)
module(
    "viewer",
    [
        cmd(
            "serve",
            "viewer:serve",
            "Open the Flask observatory for stats, WIP, reports, and dumps.",
            {
                "host": field(default="127.0.0.1"),
                "port": field("integer", default=5077),
            },
        ),
        cmd("stop", "viewer:stop", "Stop the chassis-managed local viewer."),
        cmd("report", "viewer:report", "Read stats, WIP, and activity via CLI or MCP."),
    ],
)

forms = [
    (
        "element",
        "Elements",
        "Type-level EN, ED, EF, aliases, and compact element anatomy",
        {
            "en": field(),
            "ef": field(),
            "aliases": field("array", items=field()),
            "parametric_elements": field("array"),
            "notes": field(
                description="Freeform context shaping inference about the Element, including reasoning that clarifies its meaning and relationships."
            ),
        },
    ),
    (
        "join",
        "Reified relationships",
        "Participants, roles, purposes, conditions, and join logic",
        {
            "object_id": field(),
            "element_id": field(),
            "type": field(),
            "join_scope": field(),
            "purpose": {},
            "join_logic": {},
            "participants": field("array", items=field("object", properties={
                "ref": field(description="The ID of the participating Element or reified join."),
                "role": field(description="The participant's role in this relationship."),
            })),
        },
    ),
    (
        "workflow",
        "Workflows",
        "Executable prompts, branches, loops, and nested procedures",
        {
            "id": field(),
            "intent": field(),
            "start": field(),
            "steps": field("array", items=field("object")),
        },
    ),
    (
        "prompt",
        "Prompts",
        "Delexicalized source, specialized instruction, and inference references",
        {
            "source": {},
            "specialized": {},
            "intent": field(),
            "references": field("array", items=field()),
            "rule_codes": field(
                "array",
                description="References to the semantic rules applicable to this prompt or step.",
                items=field(),
            ),
        },
    ),
    (
        "rule",
        "Rules",
        "Serializable expressions referenced by graph transitions",
        {"expression": {}, "purpose": field()},
    ),
    (
        "evidence",
        "Evidence",
        "Observations and artifacts supporting graph assertions",
        {
            "observation": {},
            "artifact": field(),
            "references": field("array", items=field()),
        },
    ),
    (
        "provenance",
        "Provenance",
        "Authorship, context, derivation, and source attribution",
        {
            "source": field(),
            "agent": field(),
            "derived_from": field("array", items=field()),
            "created": field(),
        },
    ),
    (
        "learning",
        "Learning",
        "Reusable best practices, imperative prompts, and foresight",
        {
            "purpose_prompts": field("array", items=field()),
            "creative_foresight": field("array", items=field()),
            "best_practices": field("array", items=field()),
        },
    ),
    (
        "report",
        "Reports",
        "Run outcomes, comparisons, evaluations, and work in progress",
        {"run_id": field(), "observations": field("array"), "result": {}},
    ),
    (
        "artifact",
        "Artifacts",
        "References to code, documents, media, or data produced or examined",
        {
            "path": field(),
            "media_type": field(),
            "hash": field(),
            "description": field(),
        },
    ),
    (
        "semantic-rule",
        "Semantic rules",
        "Concise reasoning rules with context and accepted/rejected examples for priming",
        {
            "rule_code": field(
                description="The rule’s unique reference, with lowercase letters followed by a numeric index.",
                pattern="^[a-z]+[0-9]+$",
            ),
            "purpose": field(
                description="The reasoning purpose served by the rule and the context in which it applies."
            ),
            "concise": field(description="The rule stated accurately and concisely."),
            "priming": field(
                "object",
                description="The material reinforcing understanding of the concise rule on first exposure.",
                properties={
                    "context": field(
                        description="Extra freeform context clarifying the concise rule’s meaning on first exposure, including nuance, reasoning, and distinctions supporting accurate interpretation and application."
                    ),
                    "examples": field(
                        "array",
                        description="Accepted and rejected examples with reasons.",
                        items=field(
                            "object",
                            properties={
                                "example": field(description="The example being examined."),
                                "assessment": field(
                                    description="The example’s acceptance or rejection under the rule.",
                                    enum=["accepted", "rejected"],
                                ),
                                "reason": field(
                                    description="The reasoning establishing how the example satisfies the rule or where it fails and why."
                                ),
                            },
                            required=["example", "assessment", "reason"],
                        ),
                    ),
                },
                required=["context", "examples"],
            ),
        },
    ),
]
registry = {}
for key, title, purpose, props in forms:
    registry["metaform:" + key] = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "metaform:" + key,
        "title": title,
        "description": purpose,
        "type": "object",
        "properties": props,
    }
registry["metaform:element-table-entry"] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "metaform:element-table-entry",
    "type": "object",
    "properties": {
        "entity_desc": field(),
        "entity_schema": field(),
        "entity_json_obj": field("object"),
    },
    "required": ["entity_desc", "entity_schema", "entity_json_obj"],
}
registry["metaform:graph"] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "metaform:graph",
    "type": "object",
    "properties": {
        "elements": {
            "type": "object",
            "additionalProperties": {"$ref": "metaform:element-table-entry"},
        },
        "joins": {"type": "array", "items": {"$ref": "metaform:join"}},
        "archaeology": {
            "type": "array",
            "description": "Namespace IDs of Type records requested for independent Archaeology.",
            "items": field(),
        },
    },
    "required": ["elements", "joins"],
}
registry["metaform:merged-join"] = dict(
    registry["metaform:join"], **{"$id": "metaform:merged-join"}
)
registry["metaform:step"] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "metaform:step",
    "type": "object",
    "properties": {
        "id": field(),
        "kind": field(),
        "prompt": field(),
        "intent": field(),
        "schema": {},
        "transitions": field("array"),
        "rule_codes": field(
            "array",
            description="References to the semantic rules applicable to this prompt or step.",
            items=field(),
        ),
    },
}
registry["metaform:semantic-rule"].update(
    description="Reasoning rules with concise wording and first-exposure priming.",
    required=["rule_code", "purpose", "concise", "priming"],
)
save(ROOT / "schemas.json", registry)
save(
    ROOT / "forms.json",
    [{"schema": "metaform:" + k, "name": n, "purpose": p} for k, n, p, _ in forms],
)
save(
    ROOT.parents[2] / "examples/workflows/element_prompts.json",
    {
        "id": "metaform.element_prompts",
        "intent": "Analyze the selected latent objects valid for the project and author element-specific instructions.",
        "steps": [
            {
                "id": "per_element",
                "kind": "foreach",
                "items": {"var": "inputs.objects"},
                "focal": "{{ item.id }}",
                "prompt": "Analyze this latent object for the project. Create 5 imperative prompts for its purpose, 3 creative thinking prompts with foresight, and 3 best practices. Speak directly to the Element and its relationships.",
                "inputs": {"element": {"var": "item"}},
                "schema": "metaform:learning",
                "save_as": "element_prompts",
                "output": {
                    "id": "data.learning.{{ item.id }}",
                    "subject": "{{ item.id }}",
                    "layer": "learning",
                    "schema": "metaform:learning",
                },
            }
        ],
    },
)
save(
    ROOT.parents[2] / "examples/workflows/conditional_review.json",
    {
        "id": "metaform.conditional_review",
        "intent": "Review a selected Element, revise if requested, and record the result.",
        "steps": [
            {
                "id": "review",
                "prompt": "Review {{ inputs.element }}. State whether another revision is needed and describe the work.",
                "schema": {
                    "type": "object",
                    "properties": {
                        "revise": {"type": "boolean"},
                        "work": {"type": "string"},
                    },
                },
                "save_as": "review",
                "transitions": [
                    {"when": {"var": "steps.review.revise"}, "to": "revise"},
                    {"to": "record"},
                ],
            },
            {
                "id": "revise",
                "prompt": "Perform the requested revision for {{ inputs.element }}: {{ review.work }}",
                "next": "review",
            },
            {
                "id": "record",
                "prompt": "Describe the completed work on {{ inputs.element }}.",
                "save_as": "result",
                "next": None,
            },
        ],
    },
)
print(
    "Generated module descriptors, starter forms plus structural schemas, and two example workflows"
)
