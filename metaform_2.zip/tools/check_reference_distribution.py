"""Verify malformed custom declarations cannot disable delivered help/reference."""
import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def manifests():
    cases = {'invalid_json': ('{"id":', 'JSON'), 'array_root': ([], 'root'),
             'missing_handler': ({'id': 'broken', 'commands': [{'name': 'run'}]}, 'handler')}
    base = {'id': 'broken', 'commands': [{'name': 'run', 'handler': 'missing.py:run'}]}
    for name, level, key, value, field in [
        ('properties_array', 'command', 'inputSchema', {'properties': []}, 'properties'),
        ('property_scalar', 'command', 'inputSchema', {'properties': {'count': 3}}, 'count'),
        ('required_scalar', 'command', 'inputSchema', {'properties': {'count': {'type': 'integer'}}, 'required': 3}, 'required'),
        ('aliases_scalar', 'command', 'aliases', 3, 'aliases'),
        ('aliases_objects', 'command', 'aliases', [{}], 'aliases'),
        ('aliases_collision', 'command', 'aliases', ['mcp'], 'aliases'),
        ('settings_array', 'module', 'settings', [], 'settings'),
        ('settings_scalar', 'module', 'settings', {'feature': True}, 'settings.feature'),
        ('setting_description_array', 'module', 'settings', {'feature': {'description': [], 'default': True}}, 'description'),
    ]:
        document = copy.deepcopy(base)
        (document['commands'][0] if level == 'command' else document)[key] = value
        cases[name] = document, field
    # A declaration can be read without importing its implementation.
    cases['missing_implementation'] = base, None
    return cases


def check(command, root, source=None):
    results = []
    for name, (document, field) in manifests().items():
        folder = root / name
        project, home = folder / 'project', folder / 'home'
        module = project / '.metaform/modules/broken'
        module.mkdir(parents=True)
        home.mkdir()
        manifest = module / 'module.json'
        manifest.write_text(document if isinstance(document, str) else json.dumps(document))
        (home / 'config.json').write_text(json.dumps({'auto_build': False, 'knowledge_mode': 'legacy'}))
        environment = {key: value for key, value in os.environ.items() if not key.startswith('METAFORM_')}
        environment.update(PYTHONPATH=source or '', METAFORM_PROJECT=str(project), METAFORM_HOME=str(home), METAFORM_RUNTIME_DIR=str(folder / 'runtime'))
        snapshot = lambda: {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
                            for path in folder.rglob('*') if path.is_file()}
        before = snapshot()
        for arguments in [['--help'], ['install', '--help'], ['system', 'reference'], ['workflow', 'reference']]:
            process = subprocess.run([*command, *arguments], cwd=project, env=environment,
                                     text=True, capture_output=True, timeout=15)
            result = {'case': name, 'arguments': arguments, 'exit': process.returncode,
                      'stderr': process.stderr, 'unchanged': snapshot() == before}
            results.append(result)
            assert process.returncode == 0, result
            assert result['unchanged'], result
            if field:
                assert str(manifest) in process.stderr and field in process.stderr, result
            if arguments == ['system', 'reference']:
                reference = json.loads(process.stdout)
                assert 'workflow.reference' in json.dumps(reference['modules'])
                if field:
                    assert str(manifest) in json.dumps(reference['diagnostics'])
                    assert not any(item['id'] == 'broken' for item in reference['modules'])
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--portable-python', default=sys.executable)
    args = parser.parse_args()
    import metaform
    assert 'site-packages' in str(Path(metaform.__file__).resolve()), metaform.__file__
    print(json.dumps({'python': sys.version, 'import_origin': metaform.__file__,
                      'sha256': hashlib.sha256(args.archive.read_bytes()).hexdigest()}), flush=True)
    with tempfile.TemporaryDirectory(prefix='metaform-artifact-reference-') as temporary:
        root = Path(temporary)
        for label, command in [('installed', [str(Path(sys.executable).with_name('metaform'))]),
                               ('standalone', [args.portable_python, '-S', str(args.archive.resolve())])]:
            result = check(command, root / label)
            print(json.dumps({'entrypoint': command, 'passed_routes': len(result),
                              'all_file_hashes_unchanged': all(row['unchanged'] for row in result)}), flush=True)


if __name__ == '__main__':
    main()
