"""Check authored retry/deadline behavior through installed and standalone CLIs."""
import argparse
import hashlib
import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import tempfile


def check(command, root, portable=False):
    project, home = root / 'project', root / 'home'
    project.mkdir(parents=True)
    home.mkdir()
    worker, log, child_log = root / 'worker.py', root / 'attempts.jsonl', root / 'children.jsonl'
    worker.write_text('''import json,subprocess,sys,time
from pathlib import Path
job=json.load(sys.stdin); values=job['inputs']; case=values['case']; log=Path(values['log'])
with log.open('a') as stream:stream.write(json.dumps({'case':case})+'\\n')
count=sum(json.loads(line)['case']==case for line in log.read_text().splitlines())
if case=='stubborn':
    child=subprocess.Popen([sys.executable,'-c','import signal,time;signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(30)'])
    with Path(values['child_log']).open('a') as stream:stream.write(str(child.pid)+'\\n')
    sys.stderr.write('worker failed while descendant owns pipes')
    sys.exit(9)
if case in ('automatic','manual') and count==1:
    Path(sys.argv[1]).write_text('"failed attempt artifact"')
    sys.stderr.write('intentional first attempt failure')
    sys.exit(9)
if case=='parallel-crash':
    while not Path(values['wait_for']).exists():time.sleep(.005)
    sys.stderr.write('parallel worker failed')
    sys.exit(9)
if values.get('started'):Path(values['started']).touch()
time.sleep(values.get('sleep',0))
if values.get('finished'):Path(values['finished']).touch()
print(json.dumps({'case':case,'validation_passed':False}))
''')
    settings = {'knowledge_mode': 'portable' if portable else 'legacy', 'auto_build': False,
                'harnesses': {'fixture': {'command': [sys.executable, str(worker), '{response_file}']}}}
    configuration = project / '.metaform/config.json' if portable else home / 'config.json'
    configuration.parent.mkdir(parents=True, exist_ok=True)
    configuration.write_text(json.dumps(settings))
    environment = {key: value for key, value in os.environ.items() if not key.startswith('METAFORM_')}
    environment.update(PYTHONPATH='', METAFORM_HOME=str(home), METAFORM_PROJECT=str(project), METAFORM_RUNTIME_DIR=str(root / 'runtime'))

    def invoke(*arguments, expected=0):
        process = subprocess.run([*command, *arguments], cwd=root, env=environment,
                                 text=True, capture_output=True, timeout=15)
        assert process.returncode == expected, (arguments, process.returncode, process.stdout, process.stderr)
        return json.loads(process.stdout) if expected == 0 else process.stderr

    def step(identifier, case, **values):
        return {'id': identifier, 'prompt': 'Perform the fixture operation.', 'inputs': {
            key: {'literal': value} for key, value in {'log': str(log), 'case': case, **values}.items()}}

    def start(document):
        path = root / (document['id'] + '.json')
        path.write_text(json.dumps(document))
        invoke('workflow', 'import', '--path', str(path))
        return invoke('workflow', 'start', '--id', document['id'], '--no-exclusive')

    policy = {'agent_failure': 'retry_once_then_fail', 'phase_failure': 'stop_execution'}
    automatic = start({'id': 'automatic', 'steps': [
        step('work', 'automatic') | {'execution_policy': policy}, step('continue', 'negative-continuation')]})
    result = invoke('workflow', 'drive', '--run-id', automatic['run_id'], '--harness', 'fixture')
    assert result['status'] == 'complete'
    assert result['result']['steps']['work'] == {'case': 'automatic', 'validation_passed': False}
    assert result['result']['steps']['continue']['case'] == 'negative-continuation'
    manual = start({'id': 'manual', 'steps': [step('work', 'manual')]})
    failure = invoke('workflow', 'drive', '--run-id', manual['run_id'], '--harness', 'fixture', expected=1)
    assert 'Harness exited 9' in failure
    pending = invoke('workflow', 'next', '--run-id', manual['run_id'])
    assert pending['request_id'] == manual['request_id']
    result = invoke('workflow', 'drive', '--run-id', manual['run_id'], '--harness', 'fixture')
    assert result['status'] == 'complete'
    assert result['result']['steps']['work'] == {'case': 'manual', 'validation_passed': False}
    stubborn = start({'id': 'stubborn', 'steps': [step('work', 'stubborn', child_log=str(child_log)) | {
        'execution_policy': policy}]})
    result = invoke('workflow', 'drive', '--run-id', stubborn['run_id'], '--harness', 'fixture')
    assert result['status'] == 'failed' and result['result']['failure']['attempts'] == 2
    children = [int(line) for line in child_log.read_text().splitlines()]
    assert len(children) == 2
    for pid in children:
        proc = Path('/proc') / str(pid) / 'stat'
        assert not proc.exists() or proc.read_text().split()[2] == 'Z', pid
    unrelated = start({'id': 'unrelated', 'steps': [step('work', 'unrelated')]})
    started = root / 'parallel-started'
    parallel = start({'id': 'parallel', 'steps': [{'id': 'phase', 'kind': 'parallel',
        'execution_policy': policy, 'branches': [
            {'id': 'sleeping', 'steps': [step('sleep', 'parallel-sleep', sleep=30, started=str(started))]},
            {'id': 'crashing', 'steps': [step('crash', 'parallel-crash', wait_for=str(started))]},
        ]}]})
    running = [subprocess.Popen([*command, 'workflow', 'drive', '--run-id', child['run_id'], '--harness', 'fixture'],
        cwd=root, env=environment, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        for child in parallel['parallel']]
    try:
        responses = []
        for process in running:
            stdout, stderr = process.communicate(timeout=15)
            assert process.returncode == 0, (stdout, stderr)
            responses.append(json.loads(stdout))
        assert {response['status'] for response in responses} <= {'failed', 'aborted'}
        assert invoke('workflow', 'next', '--run-id', parallel['run_id'])['status'] == 'failed'
        assert invoke('workflow', 'next', '--run-id', unrelated['run_id'])['request_id'] == unrelated['request_id']
    finally:
        for process in running:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
                try:
                    process.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.communicate(timeout=5)
    first, second = root / 'first-finished', root / 'second-finished'
    deadline = start({'id': 'deadline', 'steps': [{'id': 'phase', 'kind': 'call', 'workflow': 'sequential',
        'execution_policy': policy | {'timeout_seconds': 3}}, step('later', 'later-phase')],
        'workflows': [{'id': 'sequential', 'steps': [step('first', 'first', sleep=.2, finished=str(first)),
            step('second', 'second', sleep=30, finished=str(second))]}]})
    result = invoke('workflow', 'drive', '--run-id', deadline['run_id'], '--harness', 'fixture')
    assert result['status'] == 'failed' and result['result']['failure']['kind'] == 'phase_timeout'
    assert first.exists() and not second.exists()
    cases = [json.loads(line)['case'] for line in log.read_text().splitlines()]
    assert cases.count('automatic') == 2 and cases.count('manual') == 2
    assert cases.count('stubborn') == 2
    assert cases.count('parallel-sleep') == 1 and cases.count('parallel-crash') == 2
    assert cases.count('first') == cases.count('second') == 1
    assert 'later-phase' not in cases
    return {'status': 'passed', 'entrypoint': command, 'fixture_worker_python': sys.executable,
            'worker_attempts': cases, 'checks': ['authored retry', 'negative answer continuation',
            'absent-policy failure remains resumable', 'manual retry discards stale response',
            'failed worker descendants cannot retain pipes', 'parallel failure stops owned siblings only',
            'one deadline across sequential children', 'later phase not launched']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--portable-python', default=sys.executable)
    args = parser.parse_args()
    import metaform
    assert 'site-packages' in str(Path(metaform.__file__).resolve()), metaform.__file__
    print(json.dumps({'python': sys.version, 'import_origin': metaform.__file__,
                      'archive_sha256': hashlib.sha256(args.archive.read_bytes()).hexdigest()}), flush=True)
    with tempfile.TemporaryDirectory(prefix='metaform-artifact-policy-') as temporary:
        root = Path(temporary)
        for label, command, portable in [('installed', [str(Path(sys.executable).with_name('metaform'))], False),
                                        ('standalone', [args.portable_python, '-S', str(args.archive.resolve())], True)]:
            print(json.dumps(check(command, root / label, portable)), flush=True)


if __name__ == '__main__':
    main()
