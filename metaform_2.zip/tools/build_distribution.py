"""The release build includes the portable runtime and its license notices."""

from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
import os
from unittest.mock import patch

from metaform.app import App
from metaform.packaging import build
from metaform.service import stop_service

if __name__ == "__main__":
    repository = Path(__file__).resolve().parents[1]
    with TemporaryDirectory() as temporary, patch.dict(os.environ):
        os.environ["METAFORM_RUNTIME_DIR"] = str(Path(temporary) / "runtime")
        home = Path(temporary) / "home"
        try:
            app = App(Path(temporary) / "project", home)
            wheel = Path(build(app, repository)["wheel"])
            shutil.copyfile(wheel, wheel.parent / "metaform")
            print(wheel)
        finally:
            stop_service(home)
