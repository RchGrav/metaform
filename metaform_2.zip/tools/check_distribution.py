"""Exercise installed entrypoints and direct wheel execution outside the source tree."""

import asyncio
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
import venv
import zipfile
from pathlib import Path
from unittest.mock import patch

from mcp import Client
from mcp.client.stdio import StdioServerParameters
from metaform.util import write_json


def check_forms(forms):
    expected = {
        "element", "join", "workflow", "prompt", "rule", "evidence",
        "provenance", "learning", "report", "artifact", "semantic-rule",
    }
    assert {"metaform:" + name for name in expected} <= {
        form["schema"] for form in forms
    }


def check_inventory(wheel):
    sources = {'dual_agent', 'extractor', 'metaprompt', 'multi_agent_orchestrator',
               'orchestrator', 'python_to_c', 'taskeengineplus'}
    with zipfile.ZipFile(wheel) as archive:
        names = set(archive.namelist())
        assert {'metaform/data/chassis.json', 'metaform/data/workflows/grammar.json',
                'metaform/data/samples/mgm/native.json', 'metaform/data/samples/mgm/latent.json',
                'metaform/data/samples/mgm/manifest.json'} <= names
        assert {'metaform/data/workflows/sources/' + name + '.md' for name in sources} <= names
        manifest = json.loads(archive.read('metaform/data/workflows/manifest.json'))
        assert {item['id'] for item in manifest} == {'metaform.library.' + name for name in sources}
        for item in manifest:
            source = archive.read('metaform/data/workflows/' + item['source'])
            assert hashlib.sha256(source).hexdigest() == item['source_revision']
            definition_bytes = archive.read('metaform/data/workflows/' + item['definition'])
            assert hashlib.sha256(definition_bytes).hexdigest() == item['workflow_revision']
            definition = json.loads(definition_bytes)
            assert definition['id'] == item['id']


def check_rulebook(invoke):
    rule = invoke("rulebook", "get", "--rule-code", "r1")
    assert rule["rule_code"] == "r1"
    assert "Extract the proper name by reversing the final `length` Namespace components" in rule["concise"]
    assert {example["assessment"] for example in rule["priming"]["examples"]} == {
        "accepted", "rejected"
    }
    prepared = invoke("rulebook", "prepare", "--rule-codes", '["r1"]')
    assert len(prepared) == 1
    assert prepared[0]["content"] == rule
    assert prepared[0]["revision"]
    concise = invoke(
        "rulebook", "prepare", "--rule-codes", '["r1"]', "--concise-only"
    )
    assert concise[0]["content"] == {
        key: value for key, value in rule.items() if key != "priming"
    }
    assert concise[0]["revision"] == prepared[0]["revision"]


def check_intake(invoke):
    """Exercise packaged one-foundation intake and revision-addressed inspection."""
    for _ in range(2):
        native = invoke("intake", "start")
        assert native["role"] == "native_expert"
        assert native["contract_version"] == "2"
        owner = native["inputs"]["artifact_context"]["owner"]
        artifact = {"owner": owner, "kind": "element", "id": "fixture:guide"}
        type_ref = {"owner": owner, "kind": "type", "id": "document.guide"}
        graph = {
            "artifact": artifact,
            "understanding": "A maintenance guide for this machine.",
            "types": {"document.guide": {
                "id": "document.guide", "owner": owner,
                "description": "A guide provides procedural understanding.",
                "ef": "Provide procedural understanding", "length": 1, "aliases": []}},
            "elements": {"fixture:guide": {
                "id": "fixture:guide", "owner": owner, "name": "Maintenance guide",
                "description": "Instructions for maintaining this machine.", "artifact": artifact}},
            "bindings": [{"id": "fixture:guide-type", "owner": owner,
                          "element": artifact, "type": type_ref}],
            "narrowings": [], "refinements": [], "joins": [],
        }
        invoke("intake", "answer", "--answer", json.dumps(graph), "--run-id", native["run_id"], "--request-id", native["request_id"])
        completed = invoke("intake", "next", "--run-id", native["run_id"])
        assert completed["status"] == "complete"
        assert completed["model"]["revision"]
        inspected = invoke("element", "inspect", "--model", json.dumps(completed["model"]),
                           "--target", "fixture:guide")
        assert inspected["resolved_target"] == artifact
        assert any(item["value"].get("description") == graph["elements"]["fixture:guide"]["description"]
                   for item in inspected["records"])


async def check_mcp(command, arguments, environment):
    async with Client(
        StdioServerParameters(command=command, args=arguments, env=environment)
    ) as client:
        names = {tool.name for tool in (await client.list_tools()).tools}
        assert "abort" in names and "imagegen.generate" in names
        response = (
            await client.call_tool("metaform", {"command": "system.forms"})
            if "metaform" in names
            else await client.call_tool("system.forms", {})
        )
        assert not response.is_error
        content = response.structured_content
        check_forms(content["result"] if isinstance(content, dict) else content)


def check_offline(wheel, root):
    """Use an empty Python environment so installed dependencies cannot mask omissions."""
    environment_path = root / "empty-python"
    venv.EnvBuilder(with_pip=False, symlinks=os.name != "nt").create(environment_path)
    python = environment_path / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    archive = root / "metaform"
    shutil.copyfile(wheel, archive)
    environment = {k: v for k, v in os.environ.items() if not k.startswith("METAFORM_")}
    environment.update(
        METAFORM_PROJECT=str(root / "offline-project"),
        METAFORM_HOME=str(root / "offline-home"),
        METAFORM_RUNTIME_DIR=str(root / "offline-runtime"),
        PYTHONPATH="",
        PATH="",
    )
    write_json(Path(environment["METAFORM_HOME"]) / "config.json", {"auto_build": False})

    def invoke(path, *arguments):
        result = subprocess.run(
            [str(python), "-S", str(path), *arguments],
            cwd=root,
            env=environment,
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0, result.stderr or result.stdout
        return json.loads(result.stdout)

    def check_viewer(path):
        viewer = invoke(path, "viewer", "serve", "--port", "0")
        try:
            for route in ("/", "/static/workbench.js", "/api/network"):
                url = urllib.parse.urljoin(viewer["url"], route) if route.startswith("/static/") else viewer["url"] + route
                with urllib.request.urlopen(url, timeout=5) as response:
                    assert response.status == 200
                    assert response.read()
        finally:
            invoke(path, "viewer", "stop")

    check_rulebook(lambda *arguments: invoke(archive, *arguments))
    check_intake(lambda *arguments: invoke(archive, *arguments))
    check_viewer(archive)
    asyncio.run(check_mcp(str(python), ["-S", str(archive), "mcp"], environment))
    exported = root / "returned-metaform"
    invoke(archive, "package", "export", "--path", str(exported))
    with zipfile.ZipFile(exported) as package:
        assert any("license" in name.lower() for name in package.namelist())
        assert any(name.endswith(".dist-info/METADATA") and "werkzeug" in name for name in package.namelist())
        assert "START-HERE.txt" in package.namelist()
        assert "unresolved" in json.loads(package.read("metaform_bundle.json"))
    check_rulebook(lambda *arguments: invoke(exported, *arguments))
    check_viewer(exported)


def main():
    repository = Path(__file__).resolve().parents[1]
    command = str(
        Path(sys.executable).with_name(
            "metaform.exe" if os.name == "nt" else "metaform"
        )
    )
    wheel = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else sorted(
        (repository / "dist").glob("*.whl"), key=lambda p: p.stat().st_mtime
    )[-1]
    import metaform
    origin = Path(metaform.__file__).resolve()
    assert not origin.is_relative_to(repository / "src"), origin
    print(json.dumps({"python": sys.version, "executable": sys.executable,
                      "import_origin": str(origin), "wheel": str(wheel),
                      "sha256": hashlib.sha256(wheel.read_bytes()).hexdigest()}), flush=True)
    check_inventory(wheel)
    with tempfile.TemporaryDirectory(prefix="metaform-installed-") as temporary, patch.dict(os.environ):
        os.environ["METAFORM_RUNTIME_DIR"] = str(Path(temporary) / "installed-runtime")
        environment = dict(
            os.environ,
            METAFORM_PROJECT=str(Path(temporary) / "project"),
            METAFORM_HOME=str(Path(temporary) / "home"),
            PYTHONPATH="",
        )
        write_json(Path(environment["METAFORM_HOME"]) / "config.json", {"auto_build": False})
        def invoke(*arguments):
            result = subprocess.run(
                [command, *arguments],
                cwd=temporary,
                env=environment,
                capture_output=True,
                text=True,
                timeout=30,
            )
            assert result.returncode == 0, result.stderr or result.stdout
            return json.loads(result.stdout)

        from metaform.service import stop_service
        try:
            grammar = invoke("workflow", "reference")["grammar"]
            assert "user" in grammar and "assignment" in grammar
            invoke("guide", "chassis")
            invoke("system", "settings")
            assert not Path(environment["METAFORM_PROJECT"]).exists()
            check_forms(invoke("system", "forms"))
            check_rulebook(invoke)
            check_intake(invoke)
            result = subprocess.run(
                [sys.executable, str(wheel), "schema", "list"],
                cwd=temporary,
                env=environment,
                check=True,
                capture_output=True,
                text=True,
            )
            assert "metaform:learning" in json.loads(result.stdout)
            asyncio.run(check_mcp(command, ["mcp"], environment))
            asyncio.run(check_mcp(sys.executable, [str(wheel), "mcp"], environment))
            check_offline(wheel, Path(temporary))
            check_shared_portable(Path(temporary))
        finally:
            stop_service(Path(environment["METAFORM_HOME"]))
    print(
        "Installed CLI/MCP, direct-wheel CLI/MCP, offline GUI/export, and shared-service portable continuation passed."
    )


def check_shared_portable(root):
    with patch.dict(os.environ, {"METAFORM_RUNTIME_DIR": str(root / "shared-runtime")}):
        _check_shared_portable(root)


def _check_shared_portable(root):
    """Continue a shared-service project's nested workflow with only its archive."""
    from metaform.app import App
    from metaform import portable
    from metaform.service import ensure_service, stop_service
    from metaform.workflow import Engine, import_workflow

    home = root / "shared-home"
    write_json(home / "config.json", {"auto_build": False})
    try:
        a = App(root / "shared-A", home, binding=False)
        first_instance = ensure_service(home)["instance_id"]
        b = App(root / "shared-B", home, binding=False)
        assert ensure_service(home)["instance_id"] == first_instance
        record = lambda name: {"entity_desc": name, "entity_schema": "metaform:element", "entity_json_obj": {"en": name}}
        a.graph.put({"elements": {"X": record("local X")}})
        a.global_graph.put({"elements": {name: record(name) for name in ("X", "Y", "Q", "U")},
                            "joins": [{"object_id": "X", "element_id": "Y", "type": "uses"}]}, "archaeology")
        b.graph.put({"joins": [{"object_id": "X", "element_id": "Q", "type": "uses"}]})
        import_workflow(a, {"id": "child", "steps": [{"id": "inspect", "prompt": "Inspect X", "focal": "X"}]})
        import_workflow(a, {"id": "parent", "steps": [
            {"id": "child", "kind": "call", "workflow": "child"},
            {"id": "finish", "prompt": "Finish inspection"}]})
        engine = Engine(a)
        job = engine.start("parent", exclusive=False)
        while job["status"] == "running":
            job = engine.next(job["run_id"])
        archive = root / "shared-portable"
        portable.export(a, archive)
        with zipfile.ZipFile(archive) as package:
            graph = json.loads(package.read("knowledge/global.json"))
            assert {"X", "Y"} <= graph["elements"].keys()
            assert not {"Q", "U"} & graph["elements"].keys()
    finally:
        stop_service(home)
    home.rename(root / "unavailable-shared-home")
    python = root / "empty-python" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    environment = {key: value for key, value in os.environ.items() if not key.startswith("METAFORM_")}
    environment.update(PATH="", PYTHONPATH="", METAFORM_RUNTIME_DIR=str(root / "shared-offline-runtime"))

    def invoke(path, *arguments):
        result = subprocess.run([str(python), "-S", str(path), *arguments], cwd=root,
                                env=environment, capture_output=True, text=True, timeout=30)
        assert result.returncode == 0, result.stderr or result.stdout
        return json.loads(result.stdout)

    assert invoke(archive, "graph", "get", "--id", "Y", "--global")["record"]["entity_desc"] == "Y"
    invoke(archive, "workflow", "answer", "--run-id", job["run_id"],
           "--request-id", job["request_id"], "--answer", '"inspected"')
    following = invoke(archive, "workflow", "next", "--run-id", job["run_id"])
    while following["status"] == "running":
        following = invoke(archive, "workflow", "next", "--run-id", job["run_id"])
    assert following["prompt"] == "Finish inspection", following
    returned = root / "shared-returned"
    invoke(archive, "package", "export", "--path", str(returned))
    resumed = invoke(returned, "workflow", "next", "--run-id", job["run_id"])
    assert resumed["request_id"] == following["request_id"]


if __name__ == "__main__":
    main()
