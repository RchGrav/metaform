"""Probe actual installed/standalone MCP process shutdown in disposable projects.

Run with an installed-wheel interpreter, never the editable source environment:
  installed/bin/python tools/check_distribution_shutdown.py path/to/metaform
An optional --portable-python supplies the supported lower-bound interpreter.
"""
import argparse
import array
import fcntl
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import tempfile
import termios
import time
from unittest.mock import patch


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


def ready(process):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout, selectors.EVENT_READ)
        assert selector.select(timeout=10), 'MCP did not answer'


def send(process, value):
    process.stdin.write(json.dumps({'jsonrpc': '2.0', **value}) + '\n')
    process.stdin.flush()


def await_file(path, process):
    deadline = time.monotonic() + 10
    while not path.exists():
        assert process.poll() is None, process.stderr.read()
        assert time.monotonic() < deadline, str(path)
        time.sleep(0.02)


def await_blocked_output(process):
    """A short JSON-RPC error must not masquerade as a filled output pipe."""
    deadline = time.monotonic() + 5
    capacity = fcntl.fcntl(process.stdout.fileno(), fcntl.F_GETPIPE_SZ)
    while True:
        available = array.array('i', [0])
        fcntl.ioctl(process.stdout.fileno(), termios.FIONREAD, available, True)
        if available[0] >= capacity:
            return
        assert process.poll() is None
        assert time.monotonic() < deadline, f'Only {available[0]} unread stdout bytes; no demonstrated backpressure'
        time.sleep(0.01)


def check(command, root, ending):
    project, home = root / 'project', root / 'home'
    project.mkdir(parents=True)
    write_json(home / 'config.json', {'knowledge_mode': 'legacy', 'auto_build': ending == 'build'})
    write_json(home / 'schemas.json', {'urn:large': {'$id': 'urn:large', '$schema': 'https://json-schema.org/draft/2020-12/schema', 'type': 'string', 'description': 'é日本語 🧭' * 100000}})
    module = project / '.metaform/modules/blocking'
    if ending == 'handler':
        write_json(module / 'module.json', {'id': 'blocking', 'commands': [{'name': 'wait', 'handler': 'worker.py:wait'}]})
        (module / 'worker.py').write_text('''from pathlib import Path
import time
from unittest.mock import patch
def wait(api, args, context):
    Path(__file__).with_name('accepted').touch()
    try:
        time.sleep(30)
    finally:
        Path(__file__).with_name('unwound').touch()
''')
    if ending == 'build':
        (project / 'src/metaform').mkdir(parents=True)
        (project / 'src/metaform/__init__.py').write_text('')
        (project / 'README.md').write_text('Actual cancellable build fixture')
        (project / 'pyproject.toml').write_text('[build-system]\nrequires=[]\nbuild-backend="fixture_backend"\nbackend-path=["."]\n')
        (project / 'fixture_backend.py').write_text('''from pathlib import Path
import os, time
def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    Path('build-started').write_text(str(os.getpid()))
    time.sleep(30)
    raise RuntimeError('Cancellation failed to stop the backend')
''')
    environment = {key: value for key, value in os.environ.items() if not key.startswith('METAFORM_')}
    environment.update(PYTHONPATH='', METAFORM_HOME=str(home), METAFORM_PROJECT=str(project), METAFORM_RUNTIME_DIR=str(root / 'runtime'))
    process = subprocess.Popen([*command, 'mcp'], cwd=project, env=environment,
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    try:
        send(process, {'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-11-25', 'capabilities': {}, 'clientInfo': {'name': 'artifact-shutdown', 'version': '1'}}})
        ready(process)
        assert json.loads(process.stdout.readline())['id'] == 1
        send(process, {'method': 'notifications/initialized'})
        if ending in {'blocked_output', 'large_response'}:
            send(process, {'id': 4, 'method': 'tools/call', 'params': {'name': 'schema.add', 'arguments': {
                'schema': {'$id': 'urn:large', '$schema': 'https://json-schema.org/draft/2020-12/schema',
                           'type': 'string', 'description': 'é日本語 🧭' * 100000}}}})
            ready(process)
            registration = json.loads(process.stdout.readline())
            assert registration['id'] == 4 and not registration.get('error'), registration
            assert not registration['result'].get('isError'), registration
            send(process, {'id': 2, 'method': 'resources/read', 'params': {'uri': 'metaform://schema/urn:large'}})
            ready(process)
            if ending == 'blocked_output':
                await_blocked_output(process)
        elif ending in {'handler', 'build'}:
            send(process, {'id': 2, 'method': 'tools/call', 'params': {
                'name': 'blocking.wait' if ending == 'handler' else 'system.debug',
                'arguments': {} if ending == 'handler' else {'enabled': True}}})
            await_file(module / 'accepted' if ending == 'handler' else project / 'build-started', process)
        if ending == 'large_response':
            send(process, {'id': 3, 'method': 'ping'})
            replies = [json.loads(process.stdout.readline()), json.loads(process.stdout.readline())]
            assert all('result' in reply for reply in replies), replies
            replies = {reply['id']: reply['result'] for reply in replies}
            assert json.loads(replies[2]['contents'][0]['text'])['description'] == 'é日本語 🧭' * 100000
            assert replies[3] == {}
        started = time.monotonic()
        if ending in {'eof', 'large_response'}:
            process.stdin.close()
            process.stdin = None
            expected = 0
        else:
            process.send_signal(signal.SIGINT)
            expected = 130
        actual = process.wait(timeout=5)
        assert actual == expected, (command, ending, actual, process.stderr.read())
        if expected == 130:
            assert not process.stdin.closed
        stderr = process.stderr.read()
        assert 'Traceback' not in stderr, stderr
        if ending == 'handler':
            assert (module / 'unwound').exists()
        if ending == 'build':
            pid = int((project / 'build-started').read_text())
            # A reaped child or a terminated zombie cannot continue the build.
            proc = Path('/proc') / str(pid) / 'stat'
            assert not proc.exists() or proc.read_text().split()[2] == 'Z', pid
            from metaform.app import App
            from metaform.locking import lock
            with patch.dict(os.environ, {'METAFORM_RUNTIME_DIR': environment['METAFORM_RUNTIME_DIR']}):
                app = App(project, home, binding=False)
                assert app.get('built_hash') is None
                claim = lock(app, 'build')
                claim.acquire(timeout=0)
                claim.release()
        print(json.dumps({'entrypoint': command, 'case': ending, 'exit': expected, 'shutdown_seconds': round(time.monotonic()-started, 3)}), flush=True)
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
        process.communicate(timeout=5)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--portable-python', default=sys.executable)
    args = parser.parse_args()
    import metaform
    assert 'site-packages' in str(Path(metaform.__file__).resolve()), metaform.__file__
    print(json.dumps({'python': sys.version, 'import_origin': metaform.__file__}), flush=True)
    commands = {'installed': [str(Path(sys.executable).with_name('metaform'))],
                'standalone': [args.portable_python, '-S', str(args.archive.resolve())]}
    with tempfile.TemporaryDirectory(prefix='metaform-artifact-shutdown-') as temporary:
        root = Path(temporary)
        for entrypoint, command in commands.items():
            for ending in ['interrupt', 'eof', 'blocked_output', 'large_response', 'handler']:
                check(command, root / entrypoint / ending, ending)
        # The installed interpreter supplies the build frontend to the real subprocess.
        check(commands['installed'], root / 'installed/build', 'build')
        # Standalone portable operation disables automatic source builds by design.


if __name__ == '__main__':
    main()
