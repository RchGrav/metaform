"""Purposeful structural expansion through the existing workflow lifecycle."""
from __future__ import annotations

import copy

from .locking import snapshot_locked
from .models import capture_model, ref_key, records
from .util import digest


def _region(app, snapshot, target, purpose):
    from .read_model import read_model
    selectors = target.get('targets') if isinstance(target, dict) else None
    if selectors is None:
        return read_model(app, 'model.ground', {'model': snapshot['model'], 'target': target, 'task': purpose})
    regions = [read_model(app, 'model.ground', {'model': snapshot['model'], 'target': ref,
                'task': purpose, 'depth': target.get('depth', 1), 'limit': target.get('limit', 50)}) for ref in selectors]
    return {'model': snapshot['model'], 'selector': copy.deepcopy(target), 'regions': regions,
            'dependencies': [dep for region in regions for dep in region.get('dependencies', [])],
            'diagnostics': [item for region in regions for item in region.get('diagnostics', [])],
            'coverage': {'complete': all(region.get('coverage', {}).get('complete', False) for region in regions)}}


@snapshot_locked
def start_expansion(app, model, target, purpose):
    from .prompts import compose_role
    from .workflow import Engine, import_workflow
    snapshot = capture_model(app, model)
    region = _region(app, snapshot, target, purpose)
    identifier = 'expansion:' + app.identifier()
    evidence = []
    for selected in region.get('regions', [region]):
        for record in selected.get('records', []):
            evidence.extend(copy.deepcopy(record.get('value', {}).get('evidence', [])))
    prepared = compose_role(app, 'expand', {'model': snapshot['model'], 'target': copy.deepcopy(target),
        'purpose': purpose, 'region': region, 'evidence_handles': evidence})
    prepared['tool_bindings'] = {'model.ground / graph.neighbors': 'workflow.ground',
        'model.search': 'workflow.search', 'type.inspect / element.inspect / join.inspect': 'workflow.get'}
    config = {'id': identifier, 'owner': 'project:' + app.project_id, 'source': snapshot['model'],
              'target': copy.deepcopy(region.get('resolved_target') or target), 'requested_target': copy.deepcopy(target),
              'purpose': purpose, 'dependencies': region.get('dependencies', []),
              'role_snapshot': prepared}
    step = {'id': 'expand', 'role': 'expand', 'prompt': prepared['prompt'], 'schema': prepared['schema'],
            'role_snapshot': prepared, 'context': 'project',
            'inputs': {key: {'literal': value} for key, value in prepared['inputs'].items()},
            'tools': ['workflow.ground', 'workflow.search', 'workflow.get', 'workflow.files', 'workflow.read']}
    import_workflow(app, {'id': identifier, 'intent': purpose, 'steps': [step], 'expansion_job': config})
    return Engine(app).start(identifier)


def prepare_assignment(app, run, job, step):
    config = copy.deepcopy(run['stack'][0]['definition']['expansion_job'])
    run['expansion_job'] = config
    run['contract_version'] = '2'
    job.update(copy.deepcopy(step['role_snapshot']))
    job.update(expansion={'owner': config['owner'], 'kind': 'expansion', 'id': config['id']},
               model=config['source'], dependencies=copy.deepcopy(config['dependencies']))
    config['assignment'] = copy.deepcopy(job)
    config['state'] = 'pending'


def _conflicts(app, source, patch):
    from .transform import compare_snapshots, patch_snapshot
    before = capture_model(app, source)
    current = capture_model(app, {'project': source['project'], 'model': source['model']})
    intended = patch_snapshot(before, patch.get('operations', []))
    original = {ref_key({'owner': row['owner'], 'kind': kind, 'id': row['id']}): row for _, _, kind, row in records(before)}
    present = {ref_key({'owner': row['owner'], 'kind': kind, 'id': row['id']}): row for _, _, kind, row in records(current)}
    return [{'target': change['target'], 'before': change['before'], 'proposed': change['after'],
             'current': present.get(ref_key(change['target']))}
            for change in compare_snapshots(before, intended)
            if original.get(ref_key(change['target'])) != present.get(ref_key(change['target']))]


def record_answer(app, run, job, answer, annotations):
    from .knowledge import KnowledgeError
    from .transform import apply_transformation
    config = run['expansion_job']
    dependencies = {digest(item): item for item in [*config['dependencies'], *run.get('context_dependencies', [])]}
    config['dependencies'] = list(dependencies.values())
    config['semantic_reads'] = copy.deepcopy(run.get('semantic_reads', []))
    config.setdefault('contributions', []).append({'request_id': job['request_id'], 'answer': copy.deepcopy(answer),
                                                 'annotations': copy.deepcopy(annotations)})
    if not isinstance(answer, dict):
        config.update(state='incomplete', diagnostics=[{'code': 'invalid_patch', 'message': 'Expansion answer is not a structural patch.'}])
        run['status'] = 'incomplete'
        return
    patch = copy.deepcopy(answer)
    # Assignment metadata belongs to the runtime; the original answer stays above.
    patch.update(id=config['id'], source=config['source'], destination_model=config['source']['model'], purpose=config['purpose'])
    patch['expansion'] = {'id': config['id'], 'owner': config['owner'], 'target': config['target'],
        'purpose': config['purpose'], 'run_id': run['id'], 'state': 'complete',
        'source': config['source'], 'dependencies': config['dependencies'],
        'semantic_reads': copy.deepcopy(config['semantic_reads']),
        'prompt': {'id': job['prompt_ref'], 'revision': job['prompt_revision'], 'text': job['source_prompt']},
        'rendered_assignment': {'prompt': job['prompt'], 'inputs': copy.deepcopy(job['inputs']), 'schema': copy.deepcopy(job['schema'])},
        'answer': copy.deepcopy(answer), 'annotations': copy.deepcopy(annotations)}
    try:
        result = apply_transformation(app, patch)
    except (KeyError, TypeError, ValueError, KnowledgeError) as error:
        try:
            conflicts = _conflicts(app, config['source'], patch)
        except (KeyError, TypeError, ValueError):
            conflicts = []
        config.update(state='conflict' if conflicts else 'incomplete',
                      diagnostics=[{'code': 'revision_conflict' if conflicts else 'invalid_patch', 'message': str(error), 'records': conflicts}])
        run['status'] = config['state']
        return
    config.update(state='complete', publication=result)


def completion(app, run, result):
    config = run.get('expansion_job')
    if not config:
        return result
    output = result | {'contract_version': '2', 'expansion': {'owner': config['owner'], 'kind': 'expansion', 'id': config['id']},
                       'expansion_state': config['state']}
    if config.get('publication'):
        output.update(config['publication'])
    if config.get('diagnostics'):
        output['diagnostics'] = copy.deepcopy(config['diagnostics'])
    return output
