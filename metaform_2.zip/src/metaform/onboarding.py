"""Packaged host guidance and a read-only view of the selected project's stage."""
import json
from importlib.resources import files
from pathlib import Path


def skill_text(app=None, include_catalog=True):
    """The base introduction; with the catalog, the skill page: every loaded module and every available workflow."""
    core = (files("metaform") / "data" / "skills" / "metaform" / "SKILL.md").read_text(encoding="utf-8")
    if not include_catalog:
        return core.rstrip("\n") + "\n"
    from .app import App

    app = app or App.reference()
    developing = developing_metaform(app)
    return "\n\n".join([part for part in (developing.rstrip("\n"), core.rstrip("\n"), catalog(registered_modules(app), compact=True), workflow_catalog(app)) if part]) + "\n"


def workflow_catalog(app):
    """The workflows that can be started here: bundled, shared and this project's own."""
    from .modules.workflow import catalog as workflows

    lines = ["## Available workflows", "", "Start one with `metaform workflow start --id <id>`; read it with `metaform workflow inspect --id <id>`."]
    for entry in workflows(app, {}, None)["workflows"]:
        lines.append("- `%s` (%s): %s" % (entry["id"], entry["scope"], entry.get("intent") or ""))
    return "\n".join(lines)


def registered_modules(app=None, reference=False):
    from .app import App
    from .registry import Registry

    app = app or App.reference()
    registry = Registry(app)
    commands = registry.discover() if reference else registry.visible()
    modules = {}
    for command in sorted(commands.values(), key=lambda command: command.key):
        manifest = command.manifest
        module = modules.setdefault(command.module, {
            "id": command.module, "name": manifest.get("name") or manifest.get("title") or command.module,
            "description": manifest.get("description", ""), "guidance": manifest.get("guidance", ""),
            "commands": [],
        })
        entry = {"name": command.key, "description": command.description, "inputSchema": command.schema}
        if reference:
            metadata = next(item for item in manifest["commands"] if item["name"] == command.name)
            entry.update({key: metadata[key] for key in ("examples", "returns", "context", "aliases", "outputSchema", "read_only", "reference_only") if key in metadata})
            entry["availability"] = "all modes" if command.always_available else "module mode or router"
            module["settings"] = manifest.get("settings", {})
        module["commands"].append(entry)
    return list(modules.values())


def catalog(modules, compact=False):
    lines = ["## Registered abilities", "", "Read a module's reference with `metaform <module> --help`."]
    for module in modules:
        lines += ["", "### " + module["name"], module["description"]]
        if compact:
            lines.append("Reference: `metaform " + module["id"] + " --help`.")
        else:
            if module["guidance"]:
                lines += ["", module["guidance"]]
            lines += ["- `%s`: %s" % (command["name"], command["description"]) for command in module["commands"]]
    return "\n".join(lines)


def guide_state(app, plan=None, model=None):
    from .layers import list_layers, selected_layer
    from .models import resolve_model
    from .read_model import read_model
    from .registry import Registry

    registry = Registry(app)
    available = registry.visible()
    project = app.project_context()
    mode = project["mode"]
    run = app.load_run(mode["run_id"]) if mode and mode.get("run_id") else None
    models = read_model(app, "model.discover")["models"]
    layers = [layer for item in models for layer in list_layers(app, item["model"])]
    missing = object()
    configured = [item["model"] for item in models
                  if app.get("layer-selection:" + item["model"]["model"], missing) is not missing]
    selected_model = resolve_model(app, model) if model is not None else (
        configured[0] if len(configured) == 1 else models[0]["model"] if len(models) == 1 else None)
    result = {
        "project": project, "status": "ready" if models else "needs_project_input", "mode": mode,
        "run": run, "models": models, "model": selected_model, "layers": layers,
        "selected_layer": selected_layer(app, selected_model) if selected_model else None,
        "modules": [{key: module[key] for key in ("id", "name", "description", "commands")}
                    for module in registered_modules(app)],
        "guidance": "Select an available module to begin or continue the user's work.", "next": None,
    }
    if run and run["status"] == "running":
        result.update(status="in_progress", guidance="Resume the current assignment and follow its returned continuation.")
        pending = run.get("pending") or {}
        if pending.get("status") == "awaiting_user":
            result.update(status="awaiting_user", guidance="Ask the user the pending question and carry their response through its returned continuation.",
                          user_input={key: pending[key] for key in ("prompt", "schema", "run_id", "request_id") if key in pending})
        key = mode["module"] + ".next"
        if key in available:
            result["next"] = {"command": key, "arguments": {"run_id": run["id"]}}
        else:
            result["guidance"] = "The current run's module is unavailable. Restore that module to resume this run."
    elif run and run["status"] == "failed":
        result.update(status="failed", result=run.get("result"),
                      guidance="The selected run failed. Its recorded result describes the failure.")
    elif mode and run is None:
        result.update(status="in_progress")
    elif models and selected_model is None:
        result.update(status="needs_model_selection", guidance="Choose the model relevant to this work, then request guidance for that model.")
    else:
        providers = {}
        for command in available.values():
            if command.manifest.get("guide_handler"):
                providers[command.module] = command
        for command in sorted(providers.values(), key=lambda item: (item.manifest.get("guide_priority", 100), item.module)):
            from dataclasses import replace
            from .module_api import handler_context
            provider = replace(command, handler=command.manifest["guide_handler"])
            recommendation = registry.load(provider)(handler_context(app, provider), result, plan=plan)
            if recommendation:
                action = recommendation.get("next")
                if action and action["command"] not in available:
                    continue
                result.update(recommendation)
                break
    if result["status"] == "ready" and selected_model:
        from .change_report import report
        result["changes"] = report(app, selected_model)
        result["recommendations"] = [{"command": command.key, "guidance": entry["ready_guidance"]}
                                     for command in available.values() for entry in command.manifest["commands"]
                                     if entry["name"] == command.name and entry.get("ready_guidance")]
    if "workflow.list" in available:
        listing = registry.load(available["workflow.list"])(app, {}, None)
        result["workflows"] = listing
    run = result["run"]
    result["run"] = {key: run[key] for key in ("id", "workflow", "kind", "status", "stage") if key in run} if run else None
    if app.module_errors:
        result["diagnostics"] = app.module_errors
    return result


def developing_metaform(app):
    """The selected project is Metaform's own repository: hand the agent the repository's dev index."""
    project = getattr(app, "project", None)
    if project is None:
        return ""
    project = Path(project)
    pyproject = project / "pyproject.toml"
    index = project / ".agents" / "skills" / "metaform-dev" / "SKILL.md"
    if not (pyproject.is_file() and index.is_file() and (project / "src" / "metaform" / "cli.py").is_file()):
        return ""
    if 'name = "metaform-chassis"' not in pyproject.read_text(encoding="utf-8"):
        return ""
    body = index.read_text(encoding="utf-8")
    body = body.split("---", 2)[2] if body.startswith("---") else body
    return "# You are actively developing Metaform in its own repository\n" + body.strip() + "\n"


def instructions(app):
    from .util import dumps

    if app.binding:
        from .continuation import pending_assignment
        return dumps(pending_assignment(app, app.binding["run_id"], app.binding["request_id"]))
    state = guide_state(app)
    state["modules"] = [{key: module[key] for key in ("id", "name", "description")} for module in state["modules"]]
    developing = developing_metaform(app)
    return (developing + "\n" if developing else "") + skill_text(app, include_catalog=False) + "\n\n" + dumps(state)
