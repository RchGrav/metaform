"""Knowledge generation on immutable foundations, using workflow assignments and receipts."""
from __future__ import annotations

import copy

from . import schemas
from .locking import snapshot_locked
from .models import capture_model, resolve_model, records, ref_key
from .namespace import resolve_target
from .util import digest

STATE_SCHEMA = 'urn:metaform:schema:layer-state:2'
REPORT_SCHEMA = 'urn:metaform:schema:blindspot-report:2'


def _ref(owner, kind, identifier):
    return {'owner': owner, 'kind': kind, 'id': identifier}


def _identifier(layer):
    return layer['id'] if isinstance(layer, dict) else layer


def _load(app, layer):
    if isinstance(layer, dict) and layer.get('owner', 'project:' + app.project_id) != 'project:' + app.project_id:
        raise ValueError('The layer reference belongs to another owner')
    record = app.graph.get('layer-state:' + _identifier(layer))
    if record is None:
        raise ValueError('Unknown knowledge layer: ' + _identifier(layer))
    return copy.deepcopy(record['entity_json_obj'])


def _save(app, state):
    layer = state['layer']
    if STATE_SCHEMA not in schemas.registry(app):
        schemas.register(app, {
            '$schema': 'https://json-schema.org/draft/2020-12/schema', '$id': STATE_SCHEMA,
            'type': 'object', 'required': ['layer', 'generations', 'associations', 'latest'],
            'properties': {
                'layer': {'$ref': 'urn:metaform:schema:layer:2#/$defs/Layer'},
                'generations': {'type': 'object', 'additionalProperties': {'$ref': 'urn:metaform:schema:layer:2'}},
                'associations': {'type': 'object'}, 'latest': {'type': 'string'}}}, owner=layer['owner'])
    app.graph.put({'elements': {'layer-state:' + layer['id']: {
        'entity_schema': STATE_SCHEMA, 'entity_desc': layer['name'],
        'entity_json_obj': state}}, 'joins': []}, source='layer', layer='knowledge-layers')


def _states(app):
    return [record['entity_json_obj'] for record in app.graph.search('*', layer='knowledge-layers')
            if record.get('entity_schema') == STATE_SCHEMA]


def _model_key(model):
    return digest(model)


def list_layers(app, model=None):
    model = resolve_model(app, model)
    result = []
    for state in _states(app):
        association = state.get('associations', {}).get(_model_key(model))
        if association:
            bundle = state['generations'][association['generation']['id']]
            result.append(copy.deepcopy(bundle['layer']) | {
                'generation': association['generation'], 'model': model,
                'coverage': bundle['generation'].get('coverage', {}),
                'state': bundle['generation']['state']})
    return sorted(result, key=lambda item: item['id'])


def selected_layer(app, model=None):
    model = resolve_model(app, model)
    selected = app.get('layer-selection:' + model['model'])
    if selected and any(layer['id'] == selected['id'] and layer['owner'] == selected['owner']
                        for layer in list_layers(app, model)):
        return selected
    return None


@snapshot_locked
def select_layer(app, layer, model=None):
    model = resolve_model(app, model)
    selected = None
    if layer is not None:
        value = _load(app, layer)['layer']
        if not any(item['id'] == value['id'] for item in list_layers(app, model)):
            raise ValueError('The layer is not active in this model revision')
        selected = _ref(value['owner'], 'layer', value['id'])
    app.set('layer-selection:' + model['model'], selected)
    return {'model': model, 'selected_layer': selected}


def inspect_layer(app, target, model=None):
    state = _load(app, target)
    model = resolve_model(app, model)
    association = state.get('associations', {}).get(_model_key(model))
    removed = state.get('removed_associations', {}).get(_model_key(model))
    generation_id = (target.get('generation', {}) if isinstance(target, dict) else {}).get('id')
    generation_id = generation_id or (target.get('revision') if isinstance(target, dict) else None)
    generation_id = generation_id or (association or removed or {}).get('generation', {}).get('id') or state['latest']
    result = copy.deepcopy(state['generations'][generation_id])
    result['association'] = copy.deepcopy(association)
    result['removed'] = removed is not None
    result['history'] = [copy.deepcopy(bundle['generation']) for bundle in state['generations'].values()]
    return result


def active_attachments(app, model=None, layers=None):
    model = resolve_model(app, model)
    selected = {_identifier(layer) for layer in layers} if layers is not None else None
    result = []
    for state in _states(app):
        if selected is not None and state['layer']['id'] not in selected:
            continue
        association = state.get('associations', {}).get(_model_key(model))
        if not association:
            continue
        active_ids = {ref['id'] for ref in association['attachments']}
        for bundle in state['generations'].values():
            result.extend(copy.deepcopy(item) | {'freshness': item.get('freshness', 'current')}
                          | copy.deepcopy(association.get('views', {}).get(item['id'], {}))
                          for item in bundle['attachments'] if item['id'] in active_ids)
    return result


@snapshot_locked
def remove_layer(app, layer, model=None):
    model = resolve_model(app, model)
    state = _load(app, layer)
    removed = state.get('associations', {}).pop(_model_key(model), None)
    if removed is not None:
        state.setdefault('removed_associations', {})[_model_key(model)] = removed
    _save(app, state)
    return {'layer': _ref(state['layer']['owner'], 'layer', state['layer']['id']),
            'model': model, 'removed': removed is not None}


def _context(app, snapshot, target=None):
    if target is not None:
        from .read_model import read_model
        region = read_model(app, 'model.ground', {'model': snapshot['model'], 'target': target})
        return region, copy.deepcopy(region['dependencies'])
    selected = []
    dependencies = []
    for _, _, kind, value in records(snapshot):
        ref = _ref(value['owner'], kind, value['id'])
        selected.append(ref)
        dependencies.append({'kind': 'record', 'target': ref, 'fields': ['*'],
                             'fingerprint': digest(value), 'reason': 'Supplied coarse functional account.'})
    selector = {'kind': 'model', 'description': 'Complete coarse functional account.'}
    dependencies.append({'kind': 'selector', 'selector': selector, 'resolved_targets': selected,
                         'fingerprint': digest(selected), 'reason': 'Coarse account membership, including absent relationships.'})
    dependencies.append({'kind': 'record', 'target': _ref('project:' + snapshot['model']['project'], 'model', snapshot['model']['model']),
                         'fields': ['artifact', 'understanding'],
                         'fingerprint': digest({k: snapshot.get(k) for k in ('artifact', 'understanding')}),
                         'reason': 'Supplied artifact identity and functional understanding.'})
    return copy.deepcopy(snapshot), dependencies


def _step(app, identifier, role, inputs):
    from .prompts import compose_role
    prepared = compose_role(app, role, inputs)
    return {'id': identifier, 'role': role, 'prompt': prepared['prompt'],
            'schema': prepared['schema'], 'context': 'fresh',
            'tools': ['workflow.search', 'workflow.get', 'workflow.ground', 'workflow.knowledge', 'workflow.explain'],
            'inputs': {key: {'literal': value} for key, value in prepared['inputs'].items()},
            'role_snapshot': prepared}


def _start(app, request, target, model, role, previous=None, *, run_key=None, impact_context=None, exclusive=True, name=None, missing_fields=None):
    from .workflow import Engine, import_workflow
    if role == 'enumerator':
        role = 'knowledge-tool'
    generation_id = 'generation:' + (digest(run_key) if run_key is not None else app.identifier())
    if run_key is not None and previous:
        retained = _load(app, previous['layer'])['generations'].get(generation_id)
        if retained:
            definition = retained['generation']['workflow_definition']
            if app.graph.get('workflow:' + definition['id']) is None:
                import_workflow(app, definition)
            return Engine(app).start(definition['id'], exclusive=exclusive, run_id=retained['generation']['run_id'])
    snapshot = capture_model(app, model)
    owner = 'project:' + app.project_id
    subject = resolve_target(snapshot, target)['ref'] if target is not None else snapshot['artifact']
    region, dependencies = _context(app, snapshot, target)
    selector = {'kind': 'neighbors', 'target': subject, 'depth': 1} if target is not None else {'kind': 'model'}
    if previous:
        from .transform import selector_targets
        selector = copy.deepcopy((previous.get('association') or {}).get('selector', previous['recipe']['selector']))
        selected = selector_targets(snapshot, selector)
        if selected is not None:
            dependencies.append({'kind': 'selector', 'selector': selector, 'resolved_targets': selected,
                                 'fingerprint': digest(selected), 'reason': 'The recorded layer target selection in this revision.'})
    layer_id = previous['layer']['id'] if previous else 'layer:' + app.identifier()
    recipe_id = 'recipe:' + app.identifier()
    base_inputs = {'request': request, 'model': snapshot['model']}
    enumeration = None
    if role == 'knowledge-tool':
        from .knowledge_tool import render
        enumeration = render(snapshot, request, subject if target is not None else None)
        historical_questions = previous and previous['recipe']['role'] == 'enumerator'
        if impact_context is not None and not historical_questions:
            affected = {decision['target']['id'] for decision in impact_context['decisions']}
            slots = {attachment['slot'] for bundle in _load(app, previous['layer'])['generations'].values()
                     for attachment in bundle['attachments'] if attachment['id'] in affected}
            slots.update(impact_context.get('new_slots', []))
            enumeration['entries'] = [entry for entry in enumeration['entries'] if entry['slot'] in slots]
            if not enumeration['entries']:
                return None
        if missing_fields is not None and not historical_questions:
            fields_by_slot = {entry['slot']: entry['field'] for entry in previous['recipe'].get('question_contexts', previous['recipe'].get('enumeration', []))
                              if entry['field'] in missing_fields}
            enumeration['entries'] = [entry | {'field': fields_by_slot[entry['slot']]}
                                      for entry in enumeration['entries'] if entry['slot'] in fields_by_slot]
        enumeration['questions'] = {entry['field']: entry['question'] for entry in enumeration['entries']}
        enumeration['schema'] = enumeration['schema'] | {
            '$id': 'urn:metaform:knowledge-tool-output:' + digest(enumeration['questions']),
            'properties': {field: {'type': 'array', 'items': {'type': 'string'}} for field in enumeration['questions']},
            'required': list(enumeration['questions'])}
        from .knowledge_tool import statistics
        from .models import functional_account
        enumeration['statistics'] = statistics(enumeration)
        inputs = base_inputs | {'questions': enumeration['questions'],
            'contexts': {entry['field']: {field: entry[field] for field in
                         ('subject', 'context', 'records', 'properties', 'components', 'relationships', 'property_context')}
                         for entry in enumeration['entries']},
            'functional_account': functional_account(snapshot)}
    elif role == 'blindspots':
        # The outside assignment always retains the complete Native account.
        from .models import functional_account
        _, full_dependencies = _context(app, snapshot)
        dependencies = full_dependencies + dependencies if target is not None else dependencies
        outside_region = region if target is not None else {'model': snapshot['model'], 'target': subject}
        inputs = base_inputs | {'coarse_account': functional_account(snapshot), 'region': outside_region,
                                'coarse_account_contract': {
                                    'format': 'native-functional-projection',
                                    'source_model': snapshot['model'],
                                    'preserved': 'All Native functional records, understanding and record evidence; intake audit bodies are represented by retained references.',
                                    'omitted_intake_audit_fields': ['inputs', 'source_evidence[].text', 'source_evidence[].data', 'components[].text', 'prompt.text'],
                                    'retained_activities': [{'owner': activity['owner'], 'id': activity['id']}
                                                            for activity in snapshot.get('activities', []) if activity.get('kind') == 'intake'],
                                    'resolution': 'Match each activity owner and id in activities of the retained immutable foundation at source_model. That full revision retains the original inputs, evidence and text snapshots; this projection is not full foundation interchange.',
                                    'diagnostics_scope': 'coarse_account.diagnostics describes the retained full foundation, not validation of this functional projection.'},
                                'source_coverage': snapshot.get('coverage', snapshot.get('diagnostics', []))}
    elif previous:
        inputs = base_inputs | {'subjects': [subject] if target is not None else (previous.get('association') or {}).get('resolved_targets', previous['recipe'].get('resolved_targets', [subject])),
            'context': region, 'payload_schema': previous['recipe']['schema_snapshots'].get(previous['layer']['schema_ref'], {}),
            'generation': _ref(owner, 'generation', generation_id)}
        inputs['context'] = copy.deepcopy(inputs['context'])
        inputs['context']['transformation_mapping'] = copy.deepcopy((previous.get('association') or {}).get('mapping', []))
    else:
        inputs = base_inputs | {'region': region, 'available_schemas': schemas.registry(app)}
    if previous and role == 'blindspots':
        inputs['region'] = copy.deepcopy(inputs['region'])
        inputs['region']['transformation_mapping'] = copy.deepcopy((previous.get('association') or {}).get('mapping', []))
    if impact_context and enumeration is None:
        context_key = 'region' if role == 'blindspots' else 'context'
        inputs[context_key] = copy.deepcopy(inputs[context_key])
        inputs[context_key]['impact'] = copy.deepcopy(impact_context)
    step = _step(app, 'generate' if role != 'layer-design' else 'design', role, inputs)
    step['context_dependencies'] = [] if enumeration is not None else copy.deepcopy(dependencies)
    prepared = step['role_snapshot']
    if enumeration is not None:
        step['tools'] = []
        prepared['schema'] = copy.deepcopy(enumeration['schema'])
        prepared['schema_ref'] = enumeration['schema']['$id']
        prepared['output_schema'] = copy.deepcopy(enumeration['schema'])
        prepared['output_schema_revision'] = digest(enumeration['schema'])
        step.update(prompt=prepared['prompt'], schema=prepared['schema'])
    schema_ref = previous['layer']['schema_ref'] if previous else REPORT_SCHEMA if role == 'blindspots' else prepared['schema_ref']
    if enumeration is not None:
        from .knowledge_tool import ARRAY_SCHEMA
        schema_ref = ARRAY_SCHEMA
    layer = copy.deepcopy(previous['layer']) if previous else {
        'id': layer_id, 'owner': owner, 'name': name or request, 'description': request,
        'schema_ref': schema_ref, 'selector': selector}
    if enumeration is not None:
        layer['schema_ref'] = schema_ref
    layer['recipe_ref'] = _ref(owner, 'recipe', recipe_id)
    recipe = {'id': recipe_id, 'owner': owner, 'request': request,
        'source_prompt': {'id': prepared['prompt_ref'], 'revision': prepared['prompt_revision'], 'text': prepared['source_prompt']},
        'components': prepared['components'], 'schema_snapshots': {prepared['schema_ref']: prepared['schema'],
            prepared['schema_ref'].split('#', 1)[0]: prepared['output_schema']},
        'selector': selector, 'source_model': snapshot['model'], 'dependencies': dependencies,
        'rendered_assignments': [], 'resolved_targets': inputs.get('subjects', [subject]),
        'execution': {'metadata_availability': 'Harness metadata is recorded when supplied by the executor.'},
        'role': role, 'context_snapshot': region}
    if enumeration is not None:
        recipe['question_contexts'] = copy.deepcopy(enumeration['entries'])
        recipe['knowledge_statistics'] = copy.deepcopy(enumeration['statistics'])
        recipe['resolved_targets'] = list({ref_key(entry['subject']): entry['subject'] for entry in enumeration['entries']}.values())
        recipe['schema_snapshots'][schema_ref] = schemas.bundled(app, schema_ref)
    if previous:
        recipe['schema_snapshots'].update(copy.deepcopy(previous['recipe']['schema_snapshots']))
        recipe['previous_recipe'] = _ref(owner, 'recipe', previous['recipe']['id'])
        if enumeration is not None and historical_questions:
            recipe['supersedes_attachments'] = [
                _ref(item['owner'], 'knowledge', item['id']) for item in previous['attachments']
                if target is None or ref_key(item['subject']) == ref_key(subject)]
    generation = {'id': generation_id, 'owner': owner, 'layer': _ref(owner, 'layer', layer_id),
        'recipe': _ref(owner, 'recipe', recipe_id), 'model': snapshot['model'], 'state': 'pending',
        'assignments': [], 'coverage': {'completed': 0, 'pending': 1}}
    if previous:
        generation['previous'] = _ref(owner, 'generation', previous['generation']['id'])
    workflow_id = 'layer-workflow:' + generation_id
    definition = {'id': workflow_id, 'intent': request, 'steps': [step],
                  'layer_job': {'layer': layer_id, 'generation': generation_id}}
    generation['run_id'] = 'layer-run:' + generation_id
    generation['workflow_definition'] = copy.deepcopy(definition)
    if run_key is not None:
        generation['reinference_key'] = copy.deepcopy(run_key)
        generation['impact'] = copy.deepcopy(impact_context)
    bundle = {'layer': layer, 'recipe': recipe, 'generation': generation, 'attachments': []}
    state = _load(app, layer_id) if previous else {'layer': layer, 'generations': {}, 'associations': {}}
    state['generations'][generation_id] = bundle
    state['latest'] = generation_id
    state['layer'] = layer
    _save(app, state)
    import_workflow(app, definition)
    return Engine(app).start(workflow_id, exclusive=exclusive, run_id=generation['run_id'])


@snapshot_locked
def create_layer(app, request: str, target=None, model=None):
    return _start(app, request, target, model, 'layer-design')


@snapshot_locked
def blindspots(app, request='Examine this artifact for blind spots.', target=None, model=None, name='Blind spots'):
    return _start(app, request, target, model, 'blindspots', name=name)


@snapshot_locked
def regenerate_layer(app, layer: dict, model: dict, target=None):
    previous = inspect_layer(app, layer, model)
    role = previous['recipe']['role'] if previous['recipe']['role'] in ('blindspots', 'knowledge-tool', 'enumerator') else 'layer-generate'
    missing_fields = None
    if (target is None and role in ('knowledge-tool', 'enumerator') and previous['generation']['model'] == resolve_model(app, model)
            and previous.get('association')):
        missing_fields = previous['generation'].get('coverage', {}).get('missing') or None
    if target is None:
        target = (previous.get('association') or {}).get('selector', previous['recipe']['selector']).get('target')
    return _start(app, previous['recipe']['request'], target, model, role, previous, missing_fields=missing_fields)


def prepare_assignment(app, run, job, step):
    """Engine hook: capture the exact issued role and persist its generation state."""
    config = run['stack'][0]['definition'].get('layer_job')
    if not config:
        return
    run['layer_job'] = config
    run['contract_version'] = '2'
    state = _load(app, config['layer'])
    bundle = state['generations'][config['generation']]
    prepared = copy.deepcopy(step['role_snapshot'])
    # Do not interpret authored request/component text as a Jinja template.
    job.update(prepared)
    job['dependencies'] = copy.deepcopy(step.get('context_dependencies', bundle['recipe']['dependencies']))
    job.update(model=copy.deepcopy(bundle['generation']['model']), layer=bundle['generation']['layer'], generation=_ref(bundle['layer']['owner'], 'generation', config['generation']))
    statistics_field = 'knowledge_statistics' if 'knowledge_statistics' in bundle['recipe'] else 'enumeration_statistics'
    if statistics_field in bundle['recipe']:
        job[statistics_field] = copy.deepcopy(bundle['recipe'][statistics_field])
    assignment = {'id': job['request_id'], 'revision': digest(job['prompt']),
                  'text': job['prompt'], 'inputs': copy.deepcopy(job['inputs']), 'schema': copy.deepcopy(job['schema']),
                  'source_prompt': prepared['source_prompt'], 'prompt_ref': prepared['prompt_ref'],
                  'components': copy.deepcopy(prepared['components']), 'composition': copy.deepcopy(prepared['composition']),
                  'dependencies': copy.deepcopy(job['dependencies'])}
    bundle['recipe']['rendered_assignments'].append(assignment)
    bundle['recipe']['schema_snapshots'][prepared['schema_ref']] = copy.deepcopy(prepared['schema'])
    bundle['generation']['assignments'].append({'request_id': job['request_id'], 'step': job['step'],
        'subjects': copy.deepcopy(job['inputs'].get('subjects', [])), 'state': 'pending'})
    bundle['generation']['state'] = 'partial' if bundle['attachments'] else 'running'
    bundle['generation']['activity'] = _ref(bundle['layer']['owner'], 'activity', run['id'])
    bundle['generation']['run_id'] = run['id']
    state['associations'].setdefault(_model_key(bundle['generation']['model']), {
        'model': bundle['generation']['model'], 'generation': job['generation'], 'attachments': []})
    state['associations'][_model_key(bundle['generation']['model'])]['generation'] = job['generation']
    state.get('removed_associations', {}).pop(_model_key(bundle['generation']['model']), None)
    _save(app, state)


def _slot(item):
    return (ref_key(item.get('subject', {})), item.get('slot', item.get('schema_ref')))


def _retain_context_reads(bundle, run, job):
    reads = [read for read in run.get('semantic_reads', []) if read.get('request_id') == job['request_id']]
    retained = {digest(read): read for read in bundle['recipe'].get('context_reads', [])}
    retained.update({digest(read): copy.deepcopy(read) for read in reads})
    bundle['recipe']['context_reads'] = list(retained.values())
    dependencies = {digest(item): item for item in job.get('dependencies', [])}
    for read in reads:
        dependencies.update({digest(item): copy.deepcopy(item) for item in read['result']['dependencies']})
    recipe_dependencies = {digest(item): item for item in bundle['recipe']['dependencies']}
    recipe_dependencies.update(dependencies)
    bundle['recipe']['dependencies'] = list(recipe_dependencies.values())
    return list(dependencies.values())


def _publish(app, run, contributions, dependencies=None):
    config = run['layer_job']
    state = _load(app, config['layer'])
    bundle = state['generations'][config['generation']]
    if run.get('pending'):
        dependencies = _retain_context_reads(bundle, run, run['pending'])
    generation, recipe, layer = (bundle[key] for key in ('generation', 'recipe', 'layer'))
    association = state['associations'][_model_key(generation['model'])]
    superseded = {ref['id'] for ref in recipe.get('supersedes_attachments', [])}
    association['attachments'] = [ref for ref in association['attachments'] if ref['id'] not in superseded]
    created = []
    candidates = contributions.get('attachments', [])
    for contribution in candidates if isinstance(candidates, list) else []:
        if not isinstance(contribution, dict):
            continue
        item = copy.deepcopy(contribution)
        identity = digest({'subject': item.get('subject'), 'slot': item.get('slot', item.get('schema_ref')), 'id': item.get('id')})[:24]
        item.update(id=generation['id'] + ':attachment:' + identity, owner=layer['owner'],
                    layer=generation['layer'], generation=_ref(layer['owner'], 'generation', generation['id']),
                    dependencies=copy.deepcopy(dependencies if dependencies is not None else recipe['dependencies']) + copy.deepcopy(item.get('premises', [])))
        item['annotations'] = schemas.annotations(app, item.get('schema_ref'), item.get('payload'))
        # Active generated slots are replaced; authored revisions remain separately addressable.
        replaced = set()
        for old_bundle in state['generations'].values():
            for old in old_bundle['attachments']:
                authored = old.get('authored') or old.get('provenance', {}).get('source') == 'authored'
                if _slot(old) == _slot(item) and not authored:
                    replaced.add(old['id'])
        association['attachments'] = [ref for ref in association['attachments'] if ref['id'] not in replaced]
        association['attachments'].append(_ref(layer['owner'], 'knowledge', item['id']))
        bundle['attachments'] = [old for old in bundle['attachments'] if old['id'] != item['id']]
        bundle['attachments'].append(item)
        created.append(_ref(layer['owner'], 'knowledge', item['id']))
    generation['state'] = 'partial'
    _save(app, state)
    return {'run_id': run['id'], 'layer': generation['layer'], 'generation': _ref(layer['owner'], 'generation', generation['id']),
            'attachments': created, 'recorded': True}


@snapshot_locked
def publish_generation(app, run_id: str, contributions: dict):
    run = app.load_run(run_id)
    return _publish(app, run, contributions, (run.get('pending') or {}).get('dependencies'))


def record_answer(app, run, job, answer, annotations):
    """Engine hook after its normal receipt/step processing, before saving the run."""
    if not run.get('layer_job'):
        return
    config = run['layer_job']
    state = _load(app, config['layer'])
    bundle = state['generations'][config['generation']]
    job['dependencies'] = _retain_context_reads(bundle, run, job)
    bundle['generation'].setdefault('outputs', {})[job['request_id']] = {'answer': copy.deepcopy(answer), 'annotations': annotations}
    for assignment in bundle['generation']['assignments']:
        if assignment['request_id'] == job['request_id']:
            assignment.update(state='complete', annotations=annotations)
    if job['role'] == 'layer-design' and isinstance(answer, dict):
        for key in ('name', 'description', 'schema_ref', 'selector'):
            if key in answer:
                bundle['layer'][key] = copy.deepcopy(answer[key])
        if isinstance(answer.get('schema'), dict) and answer['schema'].get('$id'):
            try:
                schemas.register(app, answer['schema'], owner=bundle['layer']['owner'])
            except Exception as exc:
                bundle['generation'].setdefault('diagnostics', []).append({'message': str(exc), 'schema': answer['schema']})
            bundle['recipe']['schema_snapshots'][answer['schema']['$id']] = copy.deepcopy(answer['schema'])
        bundle['recipe']['plan'] = copy.deepcopy(answer)
        bundle['recipe']['selector'] = copy.deepcopy(answer.get('selector', bundle['recipe']['selector']))
        candidates = answer.get('groups', [])
        groups = [group for group in candidates if isinstance(group, dict)] if isinstance(candidates, list) else []
        bundle['recipe']['resolved_targets'] = [subject for group in groups for subject in (group.get('subjects') or []) if isinstance(subject, dict)]
        dependency = {'kind': 'selector', 'selector': bundle['recipe']['selector'],
            'resolved_targets': bundle['recipe']['resolved_targets'], 'fingerprint': digest(bundle['recipe']['resolved_targets']),
            'reason': 'Semantic grouping selected by the layer design from the supplied context.'}
        bundle['recipe']['dependencies'].append(dependency)
        frame = run['stack'][-1]
        steps = []
        snapshot = capture_model(app, bundle['generation']['model'])
        for index, group in enumerate(groups):
            contexts, group_dependencies = [], copy.deepcopy(job['dependencies'])
            for subject in (group.get('subjects') or []):
                region, supplied = _context(app, snapshot, subject)
                contexts.append(region)
                group_dependencies.extend(supplied)
            group_dependencies.append(copy.deepcopy(dependency))
            inputs = {'request': bundle['recipe']['request'], 'model': bundle['generation']['model'],
                'subjects': group.get('subjects', []), 'context': {'regions': contexts, 'generation_group': group},
                'payload_schema': answer.get('schema') or schemas.registry(app).get(answer.get('schema_ref'), {}),
                'generation': _ref(bundle['layer']['owner'], 'generation', bundle['generation']['id'])}
            inputs['context'] = copy.deepcopy(inputs['context'])
            inputs['context']['generation_group'] = group
            step = _step(app, 'generate-' + str(index), 'layer-generate', inputs)
            step['context_dependencies'] = group_dependencies
            steps.append(step)
            bundle['recipe']['dependencies'].extend(group_dependencies)
        frame['definition']['steps'].extend(steps)
        frame['step'] = steps[0]['id'] if steps else None
        bundle['generation']['coverage'] = {'completed': 0, 'pending': len(steps)}
        state['layer'] = copy.deepcopy(bundle['layer'])
        _save(app, state)
    else:
        _save(app, state)
        if job['role'] == 'blindspots':
            scope = bundle['recipe']['selector']
            subject = scope.get('target') or job['inputs']['coarse_account']['artifact']
            contribution = {'subject': subject, 'schema_ref': REPORT_SCHEMA, 'payload': copy.deepcopy(answer),
                'slot': 'report', 'applicability': {'scope': scope, 'reason': bundle['recipe']['request']},
                'target_index': [{'target': finding['target'], 'locator': '/findings/' + str(i)}
                                 for i, finding in enumerate(answer.get('findings') or []) if isinstance(finding, dict) and 'target' in finding] if isinstance(answer, dict) else []}
            _publish(app, run, {'attachments': [contribution]}, job.get('dependencies'))
        elif job['role'] in ('knowledge-tool', 'enumerator') and isinstance(answer, dict):
            from .knowledge_tool import ARRAY_SCHEMA
            contributions = []
            for entry in bundle['recipe'].get('question_contexts', bundle['recipe'].get('enumeration', [])):
                if entry['field'] not in answer:
                    continue
                universal = entry['subject']['kind'] == 'type' and entry['context'] == 'node' and not entry['properties']
                contributions.append({'subject': entry['subject'], 'slot': entry['slot'],
                    'schema_ref': bundle['layer']['schema_ref'] if job['role'] == 'enumerator' else ARRAY_SCHEMA,
                    'payload': copy.deepcopy(answer[entry['field']]),
                    'question': entry['question'],
                    'enumeration' if job['role'] == 'enumerator' else 'question_context': copy.deepcopy(entry),
                    'premises': copy.deepcopy(entry.get('dependencies', job.get('dependencies', []))),
                    'applicability': {'scope': {'kind': 'target' if universal else 'direct', 'target': entry['subject']},
                                      'reason': entry['question']}})
            _publish(app, run, {'attachments': contributions}, job.get('dependencies'))
        elif isinstance(answer, dict):
            _publish(app, run, answer, job.get('dependencies'))
    state = _load(app, config['layer'])
    generation = state['generations'][config['generation']]['generation']
    pending = len([step for step in run['stack'][-1]['definition']['steps'] if step['id'] not in run['stack'][-1]['steps']])
    generation['coverage'] = {'completed': len(generation.get('outputs', {})), 'pending': pending}
    if job['role'] in ('knowledge-tool', 'enumerator'):
        expected = bundle['recipe'].get('question_contexts', bundle['recipe'].get('enumeration', []))
        saved = {_slot(item) for item in state['generations'][config['generation']]['attachments']}
        missing = [entry['field'] for entry in expected if (ref_key(entry['subject']), entry['slot']) not in saved]
        generation['coverage'] = {'completed': len(expected) - len(missing), 'pending': len(missing), 'missing': missing}
        generation['state'] = 'partial' if missing else 'complete'
    else:
        generation['state'] = 'complete' if pending == 0 else 'partial'
    _save(app, state)


def completion(app, run, result):
    if not run.get('layer_job'):
        return result
    state = _load(app, run['layer_job']['layer'])
    bundle = state['generations'][run['layer_job']['generation']]
    if bundle['recipe']['role'] == 'knowledge-tool':
        result = result | {'attachments': [_ref(item['owner'], 'knowledge', item['id']) for item in bundle['attachments']]}
    return result | {'contract_version': '2', 'layer': bundle['generation']['layer'],
                     'generation': _ref(bundle['layer']['owner'], 'generation', bundle['generation']['id']),
                     'coverage': bundle['generation']['coverage']}


def _relocated(value, mapping):
    """Project structured references through explicit mappings, preserving prose."""
    if isinstance(value, list):
        return [_relocated(item, mapping) for item in value]
    if not isinstance(value, dict):
        return value
    if all(key in value for key in ('owner', 'kind', 'id')):
        for move in mapping:
            if move.get('meaning_preserved') and ref_key(value) == ref_key(move.get('from', {})):
                return copy.deepcopy(move['to'])
    return {key: _relocated(item, mapping) for key, item in value.items()}


@snapshot_locked
def associate_destination(app, source, destination, decisions, mapping, selector_changes=()):
    """Carry selected knowledge views onto a destination without changing source generations."""
    source = resolve_model(app, source)
    destination = resolve_model(app, destination)
    indexed = {ref_key(item['target']): item for item in decisions}
    associated = []
    for state in _states(app):
        prior = state['associations'].get(_model_key(source))
        if prior is None:
            continue
        transfer = digest({'source': source, 'destination': destination, 'decisions': decisions, 'mapping': mapping})
        existing = state['associations'].get(_model_key(destination), {})
        if existing.get('transfer') == transfer:
            associated.append(_ref(state['layer']['owner'], 'layer', state['layer']['id']))
            continue
        association = {'model': destination, 'generation': copy.deepcopy(existing.get('generation', prior['generation'])),
            'transfer': transfer,
            'attachments': [], 'views': {}, 'inactive_attachments': [], 'impact': [],
            'mapping': copy.deepcopy(mapping)}
        bundle = state['generations'][prior['generation']['id']]
        selection = _destination_selection(bundle['recipe'] | {
            'selector': prior.get('selector', bundle['recipe']['selector']),
            'resolved_targets': prior.get('resolved_targets', bundle['recipe'].get('resolved_targets', []))}, mapping)
        for change in selector_changes:
            if ref_key(change['layer']) == (state['layer']['owner'], 'layer', state['layer']['id']):
                selection.update(selector=copy.deepcopy(change['destination_selector']),
                                 resolved_targets=copy.deepcopy(change['resolved_targets']))
        association.update(selection)
        for reference in prior['attachments']:
            decision = indexed.get(ref_key(reference), {'target': reference, 'action': 'preserve', 'reasons': []})
            association['impact'].append(copy.deepcopy(decision))
            action = decision['action']
            if action in ('invalidate', 'regenerate', 'reconsider'):
                association['inactive_attachments'].append(copy.deepcopy(reference))
                continue
            association['attachments'].append(copy.deepcopy(reference))
            view = copy.deepcopy(prior.get('views', {}).get(reference['id'], {}))
            if action == 'relocate':
                original = next(item for generation in state['generations'].values()
                                for item in generation['attachments'] if item['id'] == reference['id'])
                effective = copy.deepcopy(original) | view
                view.update({key: _relocated(effective[key], mapping)
                             for key in ('subject', 'applicability', 'target_index', 'dependencies') if key in effective})
                view['relocation'] = {'source_model': source, 'destination_model': destination, 'mapping': copy.deepcopy(mapping)}
            view['freshness'] = 'current'
            association['views'][reference['id']] = view
        source_ids = {ref['id'] for ref in prior['attachments']}
        association['attachments'].extend(copy.deepcopy(ref) for ref in existing.get('attachments', []) if ref['id'] not in source_ids)
        association['views'].update({identifier: copy.deepcopy(view) for identifier, view in existing.get('views', {}).items() if identifier not in source_ids})
        state['associations'][_model_key(destination)] = association
        _save(app, state)
        associated.append(_ref(state['layer']['owner'], 'layer', state['layer']['id']))
    return {'source': source, 'destination': destination, 'layers': associated}


def attachment_records(app, model=None, include_history=False):
    """Read active records, optionally including retained generations for this revision."""
    model = resolve_model(app, model)
    active = active_attachments(app, model)
    if not include_history:
        return active
    seen = {item['id'] for item in active}
    for state in _states(app):
        association = state['associations'].get(_model_key(model), {})
        associated = {ref['id'] for ref in association.get('inactive_attachments', [])}
        for bundle in state['generations'].values():
            for item in bundle['attachments']:
                if item['id'] not in seen and (bundle['generation']['model'] == model or item['id'] in associated):
                    active.append(copy.deepcopy(item) | {'freshness': 'historical'})
                    seen.add(item['id'])
    return active


def get_attachment(app, target, model=None):
    identifier = _identifier(target)
    for item in attachment_records(app, model, include_history=True):
        if item['id'] == identifier and (not isinstance(target, dict) or target.get('owner', item['owner']) == item['owner']):
            return item
    raise ValueError('Unknown knowledge attachment for this model revision: ' + identifier)


def _selection_refs(value, mapping):
    if isinstance(value, list):
        return [_selection_refs(item, mapping) for item in value]
    if not isinstance(value, dict):
        return value
    if all(key in value for key in ('owner', 'kind', 'id')):
        for item in mapping:
            if ref_key(value) == ref_key(item['from']):
                return copy.deepcopy(item['to'])
    return {key: _selection_refs(item, mapping) for key, item in value.items()}


def _destination_selection(recipe, mapping):
    selector = copy.deepcopy(recipe['selector'])
    targets = copy.deepcopy(recipe.get('resolved_targets', []))
    diagnostics = []
    for item in mapping:
        scope = item.get('scope')
        if not scope:
            selector = _selection_refs(selector, [item])
            targets = _selection_refs(targets, [item])
            continue
        selected = [selector['target']] if selector.get('target') else selector.get('targets', [])
        scope_targets = [scope['target']] if scope.get('target') else scope.get('targets', [])
        if any(ref_key(target) == ref_key(item['from']) for target in selected):
            # The old reusable Type's local replacement is examined in its declared region.
            selector = copy.deepcopy(scope)
            targets = _selection_refs(targets, [item])
        elif any(ref_key(target) == ref_key(region) for target in selected for region in scope_targets):
            targets = _selection_refs(targets, [item])
        elif selector.get('kind') != 'model' and not selected:
            diagnostics.append({'selector': selector, 'mapping': item,
                                'message': 'The custom selector needs a recorded interpretation in the destination.'})
    return {'selector': selector, 'resolved_targets': targets, 'diagnostics': diagnostics}


@snapshot_locked
def schedule_reinference(app, source, destination, decisions, mapping, transformation_id, selector_changes=()):
    """Issue independent Engine jobs for affected layer subjects, recovering exact jobs on retry."""
    source, destination = resolve_model(app, source), resolve_model(app, destination)
    groups = {}
    for decision in decisions:
        if decision['action'] not in ('regenerate', 'reconsider') or not decision.get('layer'):
            continue
        attachment = get_attachment(app, decision['target'], source)
        if attachment.get('authored') or attachment.get('provenance', {}).get('source') == 'authored':
            continue
        layer, subject = decision['layer'], decision.get('subject', attachment['subject'])
        group = groups.setdefault((ref_key(layer), ref_key(subject)), {'layer': layer, 'subject': subject, 'generation': attachment['generation'], 'decisions': []})
        group['decisions'].append(decision)
    for change in selector_changes:
        for subject in change['added']:
            group = groups.setdefault((ref_key(change['layer']), ref_key(subject)), {
                'layer': change['layer'], 'subject': subject, 'generation': change['generation'], 'decisions': []})
            group.setdefault('selector_changes', []).append(change)
    from .knowledge_tool import render
    snapshots = None
    for layer in list_layers(app, source):
        previous = inspect_layer(app, layer, source)
        if previous['recipe']['role'] != 'knowledge-tool':
            continue
        if snapshots is None:
            snapshots = capture_model(app, source), capture_model(app, destination)
        selector = (previous.get('association') or {}).get('selector', previous['recipe']['selector'])
        target = selector.get('target')
        selection = _destination_selection({'selector': selector, 'resolved_targets': []}, mapping)
        request = previous['recipe']['request']
        original_slots = {entry['slot'] for entry in render(snapshots[0], request, target)['entries']}
        for entry in render(snapshots[1], request, selection['selector'].get('target'))['entries']:
            if entry['slot'] in original_slots:
                continue
            layer_ref = _ref(layer['owner'], 'layer', layer['id'])
            group = groups.setdefault((ref_key(layer_ref), ref_key(entry['subject'])), {
                'layer': layer_ref, 'subject': entry['subject'], 'generation': layer['generation'], 'decisions': []})
            group.setdefault('new_slots', []).append(entry['slot'])
    jobs = []
    historical_layers = set()
    for group in groups.values():
        previous = inspect_layer(app, group['layer'] | {'generation': group['generation']}, destination)
        selection = _destination_selection({'selector': {'kind': 'neighbors', 'target': group['subject'], 'depth': 1},
                                            'resolved_targets': [group['subject']]}, mapping)
        target = selection['selector'].get('target', group['subject'])
        role = previous['recipe']['role'] if previous['recipe']['role'] in ('blindspots', 'knowledge-tool', 'enumerator') else 'layer-generate'
        if role == 'enumerator':
            layer_key = ref_key(group['layer'])
            if layer_key in historical_layers:
                continue
            historical_layers.add(layer_key)
            selector = (previous.get('association') or {}).get('selector', previous['recipe']['selector'])
            target = _destination_selection({'selector': selector, 'resolved_targets': []}, mapping)['selector'].get('target')
        run_key = {'transformation': transformation_id, 'source': source, 'destination': destination,
                   'layer': group['layer'], 'subject': target if role == 'enumerator' else group['subject']}
        job = _start(app, previous['recipe']['request'], target, destination, role, previous,
            run_key=run_key, impact_context={'decisions': group['decisions'], 'mapping': mapping,
                                            'new_slots': group.get('new_slots', []),
                                            'selection_diagnostics': selection['diagnostics'],
                                            'selector_changes': group.get('selector_changes', [])}, exclusive=False)
        if job is not None:
            jobs.append(job)
    return jobs
