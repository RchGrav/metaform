from metaform.cli import main

raise SystemExit(main())
