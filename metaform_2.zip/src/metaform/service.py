"""One persistent authenticated server for this user's stores and workbench."""
from __future__ import annotations

import argparse
import hmac
import http.client
import hashlib
import importlib.resources
from functools import lru_cache
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import tempfile
import threading
import time
import traceback
from urllib.parse import parse_qs, urlsplit
import uuid

from filelock import FileLock, Timeout
from werkzeug.serving import ThreadedWSGIServer, WSGIRequestHandler

from .util import dumps, python_environment, read_json, write_json


class ServiceError(RuntimeError):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details or {}


def _directory(home):
    return Path(home).expanduser().resolve() / "service"


def runtime_directory():
    return Path(os.environ.get("METAFORM_RUNTIME_DIR", Path.home() / ".metaform" / "runtime")).expanduser().resolve()


@lru_cache(maxsize=1)
def runtime_fingerprint():
    digest = hashlib.sha256()
    def visit(root, prefix=""):
        for entry in sorted(root.iterdir(), key=lambda item: item.name):
            relative = prefix + entry.name
            if entry.name == "__pycache__" or entry.name.endswith(".pyc"):
                continue
            if entry.is_dir():
                visit(entry, relative + "/")
            else:
                digest.update(relative.encode())
                digest.update(entry.read_bytes())
    visit(importlib.resources.files("metaform"))
    return digest.hexdigest()


def _unavailable(directory):
    return ServiceError("service_unavailable", f"Knowledge service unavailable; see {directory / 'service.log'}", {"log": str(directory / "service.log")})


def _request(endpoint, token, method, path, body=None, timeout=2):
    connection = http.client.HTTPConnection("127.0.0.1", endpoint["port"], timeout=timeout)
    try:
        headers = {"Authorization": f"Bearer {token}"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        connection.request(method, path, body=body.encode("utf-8") if isinstance(body, str) else body, headers=headers)
        response = connection.getresponse()
        return response.status, json.loads(response.read())
    finally:
        connection.close()


def _probe(directory, timeout=2):
    try:
        endpoint = read_json(directory / "endpoint.json")
        if not isinstance(endpoint, dict) or endpoint.get("host") != "127.0.0.1" or endpoint.get("protocol") != 1:
            return None
        token = (directory / "token").read_text().strip()
        if not token:
            return None
        challenge = secrets.token_urlsafe(24)
        status, reply = _request(endpoint, token, "GET", f"/v1/health?challenge={challenge}", timeout=timeout)
        expected = {"product": "metaform-knowledge", "protocol": 1, "service_id": endpoint["service_id"], "instance_id": endpoint["instance_id"], "ready": True, "challenge": challenge}
        if status == 200 and isinstance(reply, dict) and all(reply.get(key) == value for key, value in expected.items()):
            return endpoint
    except (OSError, ValueError, KeyError, TypeError, http.client.HTTPException):
        pass
    return None


def _owned(directory):
    lock = FileLock(directory / "instance.lock")
    try:
        lock.acquire(timeout=0)
    except Timeout:
        return True
    lock.release()
    return False


def _spawn_service(home, directory, host="127.0.0.1", port=0):
    package = str(Path(__file__).parent.parent)
    bootstrap = ("import sys;sys.path.insert(0," + repr(package) + ");"
                 "sys.path.insert(1," + repr(package + "/_portable") + ");"
                 "from metaform.util import archive_metadata;archive_metadata();"
                 "from metaform.service import main;main()")
    arguments = ["--host", host, "--port", str(port)]
    if home is not None:
        arguments += ["--home", str(home)]
    environment = python_environment()
    for name in ("METAFORM_PROJECT", "METAFORM_HOME", "METAFORM_PORTABLE", "METAFORM_BINDING",
                 "METAFORM_GATEWAY", "METAFORM_GATEWAY_TOKEN"):
        environment.pop(name, None)
    with (directory / "service.log").open("ab") as log:
        return subprocess.Popen(
            [sys.executable, "-P", "-c", bootstrap, *arguments],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            start_new_session=True, close_fds=True, env=environment,
        )


def _current(endpoint):
    if endpoint.get("runtime_fingerprint") != runtime_fingerprint():
        raise ServiceError("restart_required", "The global server is running a different Metaform build. Run metaform service restart to replace it.",
                           {"running": endpoint.get("runtime_fingerprint"), "requested": runtime_fingerprint(), "endpoint": endpoint})
    return endpoint


def _start_locked(home, directory, deadline, host, port):
    spawned = None
    published = False
    try:
        while time.monotonic() < deadline:
            endpoint = _probe(directory, min(2, max(.001, deadline - time.monotonic())))
            if endpoint:
                published = True
                _current(endpoint)
                if endpoint["host"] != host or port and endpoint["port"] != port:
                    raise ServiceError("restart_required", "The global server already has a different listener address. Use service restart to change it.", {"endpoint": endpoint})
                return endpoint
            if spawned is not None and spawned.poll() is not None:
                raise _unavailable(directory)
            if spawned is None and not _owned(directory):
                spawned = _spawn_service(home, directory, host, port)
            time.sleep(min(.05, max(0, deadline - time.monotonic())))
        raise _unavailable(directory)
    finally:
        if spawned is not None and not published:
            if spawned.poll() is None:
                spawned.terminate()
                try:
                    spawned.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    spawned.kill()
            spawned.wait()


def _validate_listener(host, port):
    if host not in {None, "127.0.0.1"}:
        raise ValueError("The global Metaform server listens on 127.0.0.1")
    if port is not None and (type(port) is not int or not 0 <= port <= 65535):
        raise ValueError("The global listener port must be an integer from 0 to 65535")


def start_service(home=None, timeout=30, host="127.0.0.1", port=0):
    _validate_listener(host, port)
    directory = runtime_directory()
    deadline = time.monotonic() + timeout
    endpoint = _probe(directory, min(2, timeout))
    if endpoint:
        _current(endpoint)
        if not port or endpoint["port"] == port:
            return endpoint
        raise ServiceError("restart_required", "Use service restart to change the global listener port.", {"endpoint": endpoint})
    directory.mkdir(parents=True, exist_ok=True)
    start_lock = FileLock(directory / "start.lock")
    try:
        start_lock.acquire(timeout=max(0, deadline-time.monotonic()), poll_interval=0.05)
    except Timeout:
        raise _unavailable(directory) from None
    try:
        return _start_locked(home, directory, deadline, host, port)
    finally:
        start_lock.release()


def ensure_service(home, timeout=30):
    deadline = time.monotonic() + timeout
    endpoint = start_service(home, timeout=timeout)
    directory = _directory(home)
    attached = _probe(directory, min(2, max(.001, deadline-time.monotonic())))
    if attached and attached["instance_id"] == endpoint["instance_id"]:
        return attached
    token = (runtime_directory() / "token").read_text().strip()
    status, reply = _request(endpoint, token, "POST", "/v1/attach", dumps({"home": str(Path(home).expanduser().resolve()),
        "timeout": max(.001, deadline-time.monotonic())}), timeout=max(.001, deadline-time.monotonic()))
    if status != 200:
        error = reply.get("error", {})
        raise ServiceError(error.get("code", "service_unavailable"), error.get("message", "Storage home could not attach"), error.get("details"))
    return reply


def service_status(home=None, timeout=2):
    directory = runtime_directory()
    endpoint = _probe(directory, timeout)
    return {"ready": bool(endpoint), **(endpoint or {}), "log": str(directory / "service.log"),
            "restart_required": bool(endpoint and endpoint.get("runtime_fingerprint") != runtime_fingerprint())}


def _stop_exact(directory, endpoint, deadline):
    token = (directory / "token").read_text().strip()
    status, reply = _request(endpoint, token, "POST", "/v1/stop", dumps({"instance_id": endpoint["instance_id"]}), timeout=max(.001, deadline-time.monotonic()))
    if status != 200:
        raise _unavailable(directory)
    while time.monotonic() < deadline:
        if not _owned(directory):
            return {"stopped": True, "instance_id": endpoint["instance_id"]}
        time.sleep(.02)
    raise _unavailable(directory)


def stop_service(home=None, timeout=30):
    """Stop only a freshly verified instance; never signal a recorded PID."""
    directory = runtime_directory()
    deadline = time.monotonic() + timeout
    endpoint = _probe(directory, min(2, timeout))
    if not endpoint:
        return {"stopped": False, "ready": False, "log": str(directory / "service.log")}
    try:
        return _stop_exact(directory, endpoint, deadline)
    except (OSError, ValueError, http.client.HTTPException):
        raise _unavailable(directory) from None


def restart_service(home=None, timeout=30, host=None, port=None):
    _validate_listener(host, port)
    directory = runtime_directory()
    directory.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + timeout
    with FileLock(directory / "start.lock", timeout=timeout):
        previous = _probe(directory, min(2, timeout))
        if previous:
            _stop_exact(directory, previous, deadline)
        selected_host = host or (previous or {}).get("host", "127.0.0.1")
        return _start_locked(home, directory, deadline, selected_host, port if port is not None else (previous or {}).get("port", 0))


def open_viewer(project, home, host="127.0.0.1", port=0):
    endpoint = start_service(host=host, port=port)
    token = (runtime_directory() / "token").read_text().strip()
    status, reply = _request(endpoint, token, "POST", "/v1/viewer/open", dumps({"path": str(Path(project).resolve()), "home": str(Path(home).resolve())}), timeout=30)
    if status != 200:
        error = reply.get("error", {})
        raise ServiceError(error.get("code", "viewer_unavailable"), error.get("message", "Project could not open"), error.get("details"))
    return _viewer_result(reply, endpoint)


def forget_projects(home, path=None, missing=False):
    """Forget a registered project by folder, or every one whose folder is gone, through the running service."""
    ensure_service(home)
    endpoint = start_service()
    token = (runtime_directory() / "token").read_text().strip()
    status, reply = _request(endpoint, token, "POST", "/v1/viewer/forget",
                             dumps({"path": path, "missing": bool(missing)}), timeout=30)
    if status != 200:
        error = reply.get("error", {})
        raise ServiceError(error.get("code", "service_unavailable"), error.get("message", "Project could not be forgotten"), error.get("details"))
    return reply


def _viewer_result(reply, endpoint):
    return reply | {"url": (f"http://{endpoint['host']}:{endpoint['port']}" + reply["url"]).rstrip("/"), "port": endpoint["port"],
                    "pid": endpoint["pid"], "instance_id": endpoint["instance_id"], "runtime_fingerprint": endpoint["runtime_fingerprint"]}


class RemoteKnowledge:
    def __init__(self, home, project_id):
        self.home = Path(home).expanduser().resolve()
        self.project_id = project_id
        self.revision = None

    def call(self, operation, arguments, request_id=None):
        envelope = {"protocol": 1, "request_id": request_id or str(uuid.uuid4()), "project_id": self.project_id, "operation": operation, "arguments": arguments}
        body = dumps(envelope)
        directory = _directory(self.home)
        for attempt in range(2):
            endpoint = ensure_service(self.home)
            token = (directory / "token").read_text().strip()
            try:
                status, reply = _request(endpoint, token, "POST", "/v1/operations", body, timeout=30)
            except (OSError, ValueError, http.client.HTTPException):
                if attempt == 0:
                    continue
                raise _unavailable(directory) from None
            if not isinstance(reply, dict) or reply.get("protocol") != 1 or reply.get("request_id") != envelope["request_id"] or reply.get("project_id") != self.project_id:
                raise ServiceError("invalid_response", "Knowledge service returned an invalid operation envelope")
            if status != 200:
                error = reply.get("error", {})
                from .knowledge import KnowledgeError
                raise KnowledgeError(error.get("code", "service_error"), error.get("message", "Knowledge operation failed"), error.get("details"))
            if reply.get("service_id") != endpoint["service_id"] or reply.get("instance_id") != endpoint["instance_id"]:
                current = _probe(directory)
                if not current or any(reply.get(key) != current[key] for key in ("service_id", "instance_id")):
                    raise ServiceError("invalid_response", "Knowledge service identity changed during request")
            self.revision = reply["revision"]
            return reply["result"]


def dispatch_operation(store, envelope):
    """Shared SQLite operation dispatch for local and HTTP clients."""
    return store.call(envelope["project_id"], envelope["operation"], envelope["arguments"], request_id=envelope["request_id"])


def _credential(directory):
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "token"
    token = path.read_text().strip() if path.exists() else ""
    if not token:
        token = secrets.token_urlsafe(48)
        descriptor, temporary = tempfile.mkstemp(prefix="token.", dir=directory)
        try:
            with os.fdopen(descriptor, "w") as stream:
                stream.write(token)
            os.replace(temporary, path)
        finally:
            Path(temporary).unlink(missing_ok=True)
    path.chmod(0o600)
    return token


class LocalKnowledge:
    def __init__(self, owner, home, project_id):
        self.owner, self.home, self.project_id = owner, Path(home).resolve(), project_id
        self.revision = None

    def call(self, operation, arguments, request_id=None):
        entry = self.owner.attach(self.home)
        envelope = {"protocol": 1, "project_id": self.project_id, "operation": operation,
                    "arguments": arguments, "request_id": request_id or str(uuid.uuid4())}
        result = dispatch_operation(entry["store"], envelope)
        self.revision = entry["store"].revision
        return result


class GlobalOwner:
    def __init__(self, directory):
        self.directory = directory
        self.token = _credential(directory)
        identity = read_json(directory / "identity.json")
        if identity is None:
            identity = {"service_id": str(uuid.uuid4())}
            write_json(directory / "identity.json", identity)
        self.identity = {"service_id": identity["service_id"], "instance_id": str(uuid.uuid4())}
        self.fingerprint = runtime_fingerprint()
        self.entries = {}
        self.entry_lock = threading.RLock()
        self.attachment_locks = {}
        self.stopping = threading.Event()
        self.lifecycle_lock = threading.Lock()
        self.restart = None
        self.restart_lock = FileLock(directory / "start.lock", thread_local=False)
        self.server = None
        self.application = None

    @property
    def endpoint(self):
        return {**self.identity, "protocol": 1, "host": "127.0.0.1", "port": self.server.server_port,
                "pid": os.getpid(), "runtime_dir": str(self.directory), "runtime_fingerprint": self.fingerprint}

    def attach(self, home, timeout=30):
        from .knowledge import KnowledgeStore
        home = Path(home).expanduser().resolve()
        directory = _directory(home)
        deadline = time.monotonic() + timeout
        with self.entry_lock:
            entry = self.entries.get(home)
            attaching = self.attachment_locks.setdefault(home, threading.Lock()) if entry is None else None
        if entry is None:
            if not attaching.acquire(timeout=max(0, deadline-time.monotonic())):
                raise _unavailable(directory)
            try:
                with self.entry_lock:
                    entry = self.entries.get(home)
                if entry is None:
                    if self.stopping.is_set():
                        raise ServiceError("service_unavailable", "The global server is stopping")
                    directory.mkdir(parents=True, exist_ok=True)
                    if _owned(directory):
                        previous = _probe(directory, min(2, max(.001, deadline-time.monotonic())))
                        if previous and previous["instance_id"] != self.identity["instance_id"]:
                            _stop_exact(directory, previous, deadline)
                    lock = FileLock(directory / "instance.lock", thread_local=False)
                    try:
                        lock.acquire(timeout=max(0, deadline-time.monotonic()), poll_interval=.02)
                    except Timeout:
                        raise _unavailable(directory) from None
                    try:
                        token = _credential(directory)
                        identity = read_json(directory / "identity.json")
                        if identity is None:
                            identity = {"service_id": str(uuid.uuid4())}
                            write_json(directory / "identity.json", identity)
                        store = KnowledgeStore(directory / "knowledge.sqlite3")
                        entry = {"home": home, "store": store, "lock": lock, "token": token,
                                 "identity": {"service_id": identity["service_id"], "instance_id": self.identity["instance_id"]}}
                        with self.entry_lock:
                            write_json(directory / "endpoint.json", self.endpoint | entry["identity"])
                            try:
                                write_json(self.directory / "homes.json", [str(item) for item in [*self.entries, home]])
                            except BaseException:
                                (directory / "endpoint.json").unlink(missing_ok=True)
                                raise
                            self.entries[home] = entry
                    except BaseException:
                        lock.release()
                        raise
            finally:
                attaching.release()
        if (directory / "token").read_text().strip() != entry["token"]:
            raise _unavailable(directory)
        return entry

    def knowledge_client(self, home, project_id):
        return LocalKnowledge(self, home, project_id)

    def project_records(self):
        with self.entry_lock:
            entries = list(self.entries.values())
        return [record | {"home": str(entry["home"])} for entry in entries
                for record in entry["store"].call(None, "project.list", {})]

    def forget_project(self, path):
        """Drop a registration from every attached home; the folder and its knowledge stay."""
        with self.entry_lock:
            entries = list(self.entries.values())
        forgotten = []
        for entry in entries:
            forgotten.extend(entry["store"].call(None, "project.forget", {"path": path})["forgotten"])
        return forgotten

    def request_stop(self):
        with self.lifecycle_lock:
            if not self.stopping.is_set():
                self.stopping.set()
                threading.Thread(target=self.server.shutdown, daemon=True).start()
        return {"stopping": True, "instance_id": self.identity["instance_id"]}

    def request_restart(self, host="127.0.0.1", port=None):
        _validate_listener(host, port)
        with self.lifecycle_lock:
            if self.stopping.is_set():
                raise ServiceError("service_unavailable", "The global server is already stopping")
            try:
                self.restart_lock.acquire(timeout=0)
            except Timeout:
                raise ServiceError("service_unavailable", "Another global start or restart is already underway") from None
            self.restart = {"host": host or "127.0.0.1", "port": self.server.server_port if port is None else port}
            self.stopping.set()
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        return {"restarting": True, "instance_id": self.identity["instance_id"], **self.restart}

    def open_viewer(self, project, home, host="127.0.0.1", port=0):
        endpoint = self.endpoint
        if host != endpoint["host"] or port and port != endpoint["port"]:
            raise ServiceError("restart_required", "Use service restart to change the global listener address.", {"endpoint": endpoint})
        result = self.application.extensions["metaform_open_project"](str(project), str(home))
        return _viewer_result(result, endpoint)

    def close(self):
        if self.application is not None:
            cleanup = self.application.extensions.get("metaform_close")
            if cleanup:
                cleanup()
        for home, entry in list(self.entries.items()):
            try:
                if hasattr(entry["store"], "close"):
                    entry["store"].close()
                endpoint = _directory(home) / "endpoint.json"
                if (read_json(endpoint) or {}).get("instance_id") == self.identity["instance_id"]:
                    endpoint.unlink(missing_ok=True)
            finally:
                entry["lock"].release()


class KnowledgeServer(ThreadedWSGIServer):
    # Closing the listener drains accepted RPC and viewer handlers first.
    daemon_threads = False
    block_on_close = True

    def __init__(self, owner, application, host, port):
        self.owner = owner
        self.stopping = owner.stopping
        super().__init__(host, port, application, handler=KnowledgeHandler)


class KnowledgeHandler(WSGIRequestHandler):
    # Bound socket inactivity; executing an accepted operation has no time limit.
    timeout = 2

    def run_wsgi(self):
        if urlsplit(self.path).path.startswith("/v1/"):
            if self.command == "GET":
                self.do_GET()
            elif self.command == "POST":
                self.do_POST()
            else:
                self._reply(405, {"error": {"code": "method_not_allowed"}})
        else:
            super().run_wsgi()

    def log_request(self, *args):
        pass

    def _reply(self, status, value):
        body = dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _authenticated(self):
        supplied = self.headers.get("Authorization", "")
        owner = self.server.owner
        self.entry = None
        if hmac.compare_digest(supplied, f"Bearer {owner.token}"):
            self.identity = owner.identity
            return True
        with owner.entry_lock:
            for entry in owner.entries.values():
                if hmac.compare_digest(supplied, f"Bearer {entry['token']}"):
                    self.entry, self.identity = entry, entry["identity"]
                    return True
        self._reply(401, {"error": {"code": "unauthorized", "message": "Invalid service credential", "details": {}}})
        return False

    def do_GET(self):
        if not urlsplit(self.path).path.startswith("/v1/"):
            return super().run_wsgi()
        if not self._authenticated():
            return
        parsed = urlsplit(self.path)
        if parsed.path != "/v1/health":
            self._reply(404, {"error": {"code": "not_found"}})
            return
        challenge = parse_qs(parsed.query).get("challenge", [None])[0]
        self._reply(200, {"product": "metaform-knowledge", "protocol": 1, **self.server.owner.endpoint, **self.identity,
                         "ready": not self.server.stopping.is_set(), "challenge": challenge})

    def do_POST(self):
        if not urlsplit(self.path).path.startswith("/v1/"):
            return super().run_wsgi()
        if not self._authenticated():
            return
        envelope = {}
        try:
            try:
                body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
            except TimeoutError:
                self.close_connection = True
                return
            envelope = json.loads(body)
            if not isinstance(envelope, dict):
                raise ValueError("Operation envelope must be an object")
            if self.path == "/v1/stop":
                if envelope.get("instance_id") != self.server.owner.identity["instance_id"]:
                    raise ValueError("Service instance does not match")
                self._reply(200, self.server.owner.request_stop())
                return
            if self.path in {"/v1/attach", "/v1/viewer/open", "/v1/viewer/forget"}:
                if self.entry is not None:
                    raise ServiceError("unauthorized", "Global management requires the runtime credential")
                if self.path == "/v1/attach":
                    entry = self.server.owner.attach(envelope["home"], min(30, max(.001, envelope.get("timeout", 30))))
                    result = self.server.owner.endpoint | entry["identity"]
                elif self.path == "/v1/viewer/forget":
                    result = self.server.owner.application.extensions["metaform_forget_projects"](envelope.get("path"), envelope.get("missing", False))
                else:
                    result = self.server.owner.application.extensions["metaform_open_project"](envelope["path"], envelope["home"])
                self._reply(200, result)
                return
            if self.path != "/v1/operations":
                self._reply(404, {"error": {"code": "not_found"}})
                return
            if envelope.get("protocol") != 1 or not isinstance(envelope.get("request_id"), str) or not envelope["request_id"] or "project_id" not in envelope or not isinstance(envelope.get("operation"), str) or not isinstance(envelope.get("arguments"), dict):
                raise ValueError("Invalid operation envelope")
            if self.server.stopping.is_set():
                raise ServiceError("service_unavailable", "Knowledge service is stopping")
            if self.entry is None:
                raise ServiceError("invalid_request", "Knowledge operations require an attached storage-home credential")
            store = self.entry["store"]
            result = dispatch_operation(store, envelope)
            self._reply(200, {"protocol": 1, "request_id": envelope["request_id"], "project_id": envelope["project_id"], **self.identity, "revision": store.revision, "result": result})
        except Exception as error:
            from .knowledge import KnowledgeError
            if isinstance(error, (KnowledgeError, ServiceError)):
                code, message, details = error.code, str(error), error.details or {}
            elif isinstance(error, (ValueError, KeyError, TypeError)):
                code, message, details = "invalid_request", str(error), {}
            else:
                traceback.print_exc()
                code, message, details = "internal_error", "Knowledge operation failed", {}
            self._reply(400 if code != "internal_error" else 500, {"protocol": 1, "request_id": envelope.get("request_id") if isinstance(envelope, dict) else None, "project_id": envelope.get("project_id") if isinstance(envelope, dict) else None, "error": {"code": code, "message": message, "details": details}})


def serve(home=None, host="127.0.0.1", port=0):
    from .viewer import create_app
    import signal

    directory = runtime_directory()
    directory.mkdir(parents=True, exist_ok=True)
    lock = FileLock(directory / "instance.lock")
    try:
        lock.acquire(timeout=0)
    except Timeout:
        return
    owner = None
    server = None
    previous_handlers = {}
    try:
        owner = GlobalOwner(directory)
        application = create_app(None, owner.identity["instance_id"], owner=owner)
        owner.application = application
        server = KnowledgeServer(owner, application, host, port)
        owner.server = server
        homes = read_json(directory / "homes.json", [])
        if home is not None:
            homes.append(str(Path(home).expanduser().resolve()))
        for selected in dict.fromkeys(homes):
            if Path(selected).exists() or home is not None and Path(selected) == Path(home).expanduser().resolve():
                owner.attach(selected)
        write_json(directory / "endpoint.json", owner.endpoint)

        def stop(signum, frame):
            owner.stopping.set()
            threading.Thread(target=server.shutdown, daemon=True).start()

        if threading.current_thread() is threading.main_thread():
            for signum in (signal.SIGINT, signal.SIGTERM):
                previous_handlers[signum] = signal.signal(signum, stop)
        server.serve_forever(poll_interval=.05)
    finally:
        try:
            if server is not None:
                server.server_close()
            if owner is not None:
                owner.close()
        finally:
            for signum, handler in previous_handlers.items():
                signal.signal(signum, handler)
            if owner is not None:
                endpoint = directory / "endpoint.json"
                if (read_json(endpoint) or {}).get("instance_id") == owner.identity["instance_id"]:
                    endpoint.unlink(missing_ok=True)
            lock.release()
    if owner is not None and owner.restart is not None:
        try:
            runtime_fingerprint.cache_clear()
            _start_locked(None, directory, time.monotonic() + 30, **owner.restart)
        finally:
            owner.restart_lock.release()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--home")
    parser.add_argument("--host", default="127.0.0.1", choices=["127.0.0.1"])
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    serve(args.home, args.host, args.port)


if __name__ == "__main__":
    main()
