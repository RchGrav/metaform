from __future__ import annotations

import os
import json
import sqlite3
import uuid
from contextlib import contextmanager
from functools import cached_property
from pathlib import Path

from .util import digest, dumps, now, read_json, write_json
from .locking import snapshot_locked


def read_configuration(path, errors=None):
    try:
        value = read_json(path, {})
        if not isinstance(value, dict):
            raise ValueError("settings must be a JSON object")
        return value
    except (ValueError, OSError) as error:
        message = f"Cannot read configuration {path}: {error}"
        if errors is None:
            raise ValueError(message) from error
        errors.append(message)
        return {}


def merge_settings(base, updates):
    """Merge settings objects while preserving sibling module/harness values."""
    result = dict(base)
    for key, value in updates.items():
        result[key] = merge_settings(result[key], value) if isinstance(result.get(key), dict) and isinstance(value, dict) else value
    return result


def project_path(selector, home=None, knowledge_client=None):
    """Resolve an explicit directory or registered UUID without opening a project."""
    value = str(selector)
    try:
        uuid.UUID(value)
    except ValueError:
        return Path(selector).expanduser().resolve()
    from .service import RemoteKnowledge
    selected_home = Path(home or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").resolve()
    client = (knowledge_client or RemoteKnowledge)(selected_home, None)
    record = client.call("project.get", {"project_id": value})
    return Path(record["path"]).resolve()


class App:
    """Project-scoped services shared by all transports and modules."""

    def __init__(self, project=None, home=None, debug=False, binding=None, knowledge_client=None):
        from .continuation import marker
        from .util import archive_metadata
        import json

        archive_metadata()
        self.invocation = Path.cwd().resolve()
        inherited = json.loads(os.environ["METAFORM_BINDING"]) if binding is None and os.environ.get("METAFORM_BINDING") else None
        self.binding = None if binding is False else binding or inherited or marker(home=home) or (marker(project, home=home) if project is not None else None)
        if self.binding:
            project = self.binding["project"]
            home = self.binding["home"]
        selected = project or os.environ.get("METAFORM_PROJECT") or self.invocation
        self._knowledge_client_factory = knowledge_client
        self.project = project_path(selected, home, knowledge_client)
        self.root = self.project / ".metaform"
        self.project_name = self.project.name
        project_config = read_configuration(self.root / "config.json")
        identity = read_json(self.root / "project.json", {})
        portable = (
            identity.get("knowledge_mode") == "portable"
            or project_config.get("knowledge_mode") == "portable"
            or (self.root / "bundle.json").exists()
            or bool(os.environ.get("METAFORM_PORTABLE"))
        )
        previous = any((self.root / name).exists() for name in (
            "state.sqlite3", "metaform.kg", "metaform.json", "metaform.lbdb", "config.json",
        ))
        self.home = (self.root / "home") if portable else Path(
            home or identity.get("service_home") or os.environ.get("METAFORM_HOME")
            or Path.home() / ".metaform"
        ).resolve()
        self.config = merge_settings(read_configuration(self.home / "config.json"), project_config)
        self.knowledge_mode = "portable" if portable else identity.get(
            "knowledge_mode", project_config.get(
                "knowledge_mode", "legacy" if previous else self.config.get("knowledge_mode", "service")
            )
        )
        self.config["knowledge_mode"] = self.knowledge_mode
        if portable:
            self.config.update(graph_backend="json", auto_build=False)
        self.copy_id = identity.get("copy_id")
        self.project_id = identity.get("project_id") or (identity.get("origin_project_id") if portable else None)
        self.project_id = self.project_id or uuid.uuid5(uuid.NAMESPACE_URL, str(self.project)).hex
        self.root.mkdir(parents=True, exist_ok=True)
        self.home.mkdir(parents=True, exist_ok=True)
        self.refresh_config()
        if not (self.home / "config.json").exists():
            from .registry import Registry
            write_json(self.home / "config.json", Registry(self).defaults())
        if not (self.root / "config.json").exists():
            write_json(self.root / "config.json", {})
        if self.knowledge_mode == "service":
            from .service import RemoteKnowledge, ensure_service

            if knowledge_client is None:
                ensure_service(self.home)
            client = knowledge_client or RemoteKnowledge
            remote = client(self.home, identity.get("project_id"))
            if identity.get("project_id"):
                registration = remote.call("project.get", {"project_id": identity["project_id"]})
                if Path(registration["path"]).resolve() != self.project:
                    raise ValueError("Project location mismatch; use project relocate or project connect --new")
            else:
                registration = remote.call("project.register", {"path": str(self.project), "name": self.project.name})
                write_json(self.root / "project.json", {
                    "format": "metaform-project/1", "project_id": registration["project_id"],
                    "knowledge_mode": "service", "service_home": str(self.home),
                })
            self.project_id = registration["project_id"]
            self.project_name = registration.get("name", self.project.name)
            self.knowledge = client(self.home, self.project_id)
        self.debug = debug or self.config.get("debug", False)
        self.db_path = self.root / "state.sqlite3"
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, workflow TEXT NOT NULL,
                    status TEXT NOT NULL, body TEXT NOT NULL, updated TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, run_id TEXT,
                    kind TEXT NOT NULL, body TEXT NOT NULL, created TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS workfolders(id TEXT PRIMARY KEY, path TEXT NOT NULL,
                    body TEXT NOT NULL);
            """)
        self.debug = self.debug or self.get("debug", False)
        self.seed()

    @classmethod
    def reference(cls, project=None, home=None):
        """Resolve module/configuration reference without creating state or services."""
        app = cls.__new__(cls)
        app.invocation = Path.cwd().resolve()
        app.config_errors = []
        selector = project or os.environ.get("METAFORM_PROJECT") or app.invocation
        try:
            uuid.UUID(str(selector))
        except ValueError:
            app.project = Path(selector).expanduser().resolve()
        else:
            selected_home = Path(home or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").expanduser().resolve()
            database = selected_home / "service" / "knowledge.sqlite3"
            if not database.exists():
                raise ValueError(f"Unknown registered project: {selector}")
            with app.reference_db(database) as connection:
                row = connection.execute("SELECT path FROM projects WHERE project_id=?", (str(selector),)).fetchone()
            if row is None:
                raise ValueError(f"Unknown registered project: {selector}")
            app.project = Path(row[0]).resolve()
        app.root = app.project / ".metaform"
        identity = read_json(app.root / "project.json", {})
        project_config = read_configuration(app.root / "config.json", app.config_errors)
        portable = (identity.get("knowledge_mode") == "portable" or project_config.get("knowledge_mode") == "portable"
                    or (app.root / "bundle.json").exists() or bool(os.environ.get("METAFORM_PORTABLE")))
        app.home = app.root / "home" if portable else Path(home or identity.get("service_home")
            or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").expanduser().resolve()
        app.config = merge_settings(read_configuration(app.home / "config.json", app.config_errors), project_config)
        app.knowledge_mode = "portable" if portable else identity.get("knowledge_mode", app.config.get("knowledge_mode", "service"))
        app.project_id = identity.get("project_id") or uuid.uuid5(uuid.NAMESPACE_URL, str(app.project)).hex
        app.project_name = app.project.name
        app.binding = None
        app.db_path = app.root / "state.sqlite3"
        app._reference_only = True
        app.refresh_config()
        return app

    def refresh_config(self):
        """Recompute effective settings from module defaults and each persistent scope."""
        from .registry import Registry

        errors = self.config_errors if getattr(self, "_reference_only", False) else None
        home = read_configuration(self.home / "config.json", errors)
        project = read_configuration(self.root / "config.json", errors)
        self.config = merge_settings(home, project)
        defaults = Registry(self).defaults()
        self.config = merge_settings(merge_settings(defaults, home), project)
        self.config_sources = {key: "default" for key in defaults}
        self.config_sources.update({key: "home" for key in home})
        self.config_sources.update({key: "project" for key in project})
        if self.config.get("knowledge_mode") != self.knowledge_mode:
            self.config["knowledge_mode"] = self.knowledge_mode
            self.config_sources["knowledge_mode"] = "project identity"
        if self.knowledge_mode == "portable":
            self.config.update(graph_backend="json", auto_build=False)
            self.config_sources.update(graph_backend="portable", auto_build="portable")
        if hasattr(self, "db_path") and self.db_path.exists():
            active_debug = self.get("debug")
            if active_debug is not None:
                self.config["debug"] = active_debug
                self.config_sources["debug"] = "project state"
        self.debug = bool(self.config.get("debug", False))
        return self.config

    def configuration(self):
        from .registry import Registry
        errors = self.config_errors if getattr(self, "_reference_only", False) else None
        home = read_configuration(self.home / "config.json", errors)
        project = read_configuration(self.root / "config.json", errors)

        def sources(value, home_value, project_value, fallback):
            if isinstance(value, dict):
                home_value = home_value if isinstance(home_value, dict) else {}
                project_value = project_value if isinstance(project_value, dict) else {}
                return {key: sources(item, home_value.get(key), project_value.get(key),
                                     "project" if key in project_value else "home" if key in home_value else "default")
                        for key, item in value.items()}
            return fallback

        active = dict(self.config)
        if self.knowledge_mode == "service":
            active["graph_backend"] = "sqlite"
        elif self.knowledge_mode == "portable":
            active["graph_backend"] = "json"
        elif hasattr(self, "_opened_graph_backend"):
            active["graph_backend"] = self._opened_graph_backend
        pending = {key: {"configured": value, "active": active.get(key)}
                   for key, value in self.config.items() if active.get(key) != value}
        return {"paths": {"home": str(self.home / "config.json"), "project": str(self.root / "config.json")},
                "active": active, "pending": pending,
                "settings": Registry(self).settings(),
                "effective": {key: {"value": value, "source": self.config_sources.get(key, "runtime"),
                                    **({"sources": sources(value, home.get(key), project.get(key), "default")}
                                       if isinstance(value, dict) else {})}
                              for key, value in self.config.items()}}

    def seed(self):
        import importlib.resources
        import json

        data = importlib.resources.files("metaform") / "data"
        from .prompts import seed

        seed(self)
        from .rulebook import seed as seed_rules

        seed_rules(self)
        if self.knowledge_mode == "portable":
            return
        from .coarse import bases
        missing = {identifier: {"entity_desc": record["description"], "entity_schema": "metaform:element",
                                "entity_json_obj": {"ef": record["ef"], "length": record["length"], "aliases": record["aliases"]}}
                   for identifier, record in bases().items() if not self.global_graph.get(identifier)}
        if missing:
            self.global_graph.put({"elements": missing}, "authored")
        global_data = data / "global"
        if (global_data / "index.json").is_file():
            index = json.loads((global_data / "index.json").read_text())
            package_hash = digest(index)
            marker = self.home / "inference" / "packaged.json"
            changed = read_json(marker, {}).get("hash") != package_hash
            for identifier in index.get("schemas", []):
                if changed or self.knowledge.call("schema.get", {"owner": "global", "id": identifier}) is None:
                    schema = json.loads((global_data / "schemas" / (digest(identifier) + ".json")).read_text())
                    self.knowledge.call("schema.put", {"owner": "global", "schema": schema})
            if changed:
                elements, observations, joins = {}, [], []
                for identifier in index["elements"]:
                    record = json.loads(
                        (
                            global_data / "elements" / (digest(identifier) + ".json")
                        ).read_text()
                    )
                    elements[identifier] = record["record"]
                    observations.extend(record.get("observations", []))
                for identifier in index["joins"]:
                    joins.append(
                        json.loads(
                            (
                                global_data / "joins" / (digest(identifier) + ".json")
                            ).read_text()
                        )
                    )
                self.global_graph.put(
                    {
                        "elements": elements,
                        "joins": joins,
                        "observations": observations,
                    },
                    "packaged",
                )
                write_json(marker, {"hash": package_hash})

    @contextmanager
    def db(self):
        connection = sqlite3.connect(self.db_path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        try:
            with connection:
                yield connection
        finally:
            connection.close()

    @cached_property
    def graph(self):
        if self.knowledge_mode == "service":
            from .knowledge import BoundGraph
            return BoundGraph(self.knowledge, "project:" + self.project_id)
        from .backends import open_graph, graph_suffix

        backend = self.config.get("graph_backend", "sqlite")
        self._opened_graph_backend = backend
        suffix = graph_suffix(backend)
        graph = open_graph(self.root / ("metaform" + suffix), backend)
        graph.owner = "project:" + self.project_id
        graph.knowledge_snapshot = lambda: self.knowledge.read_snapshot()
        return graph

    @cached_property
    def global_graph(self):
        if self.knowledge_mode == "service":
            from .knowledge import BoundGraph
            return BoundGraph(self.knowledge, "global")
        from .backends import open_graph, graph_suffix

        backend = self.config.get("graph_backend", "sqlite")
        self._opened_graph_backend = backend
        suffix = graph_suffix(backend)
        graph = open_graph(self.home / "inference" / ("metaform" + suffix), backend)
        graph.owner = "global"
        graph.knowledge_snapshot = lambda: self.knowledge.read_snapshot()
        return graph

    @property
    def knowledge(self):
        if self.knowledge_mode == "service":
            return self._knowledge
        from .knowledge import LocalKnowledge
        existing = self.__dict__.get("_knowledge")
        if existing is not None and existing.graphs.get("project:" + self.project_id) is self.graph and existing.graphs.get("global") is self.global_graph:
            return existing
        manifest = read_json(self.root / "knowledge-manifest.json", {})
        captured_schemas = None
        if self.knowledge_mode == "portable" and "schemas" in manifest:
            captured_schemas = {}
            for record in manifest["schemas"]:
                captured_schemas.setdefault(record["owner"], {})[record["id"]] = record["body"]
        self._knowledge = LocalKnowledge(self.project_id, self.graph, self.global_graph,
                                         schemas=captured_schemas,
                                         archive_dependencies=read_json(self.root / "archive-dependencies.json", []))
        return self._knowledge

    @knowledge.setter
    def knowledge(self, value):
        self._knowledge = value

    def select_project(self, selector):
        if self.binding:
            raise ValueError("Project selection cannot change a bound assignment")
        home = self.home
        if self.knowledge_mode == "portable":
            home = Path(getattr(self, "_selection_home", None)
                        or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").expanduser().resolve()
            if home == self.home:
                home = Path.home() / ".metaform"
        client = getattr(self, "_knowledge_client_factory", None)
        project = project_path(selector, home, client)
        identity = read_json(project / ".metaform" / "project.json", {})
        selected = App(project, identity.get("service_home") or home, binding=False,
                       knowledge_client=client)
        if getattr(self, "_service_owner", None) is not None:
            selected._service_owner = self._service_owner
        selected._selection_home = home
        return selected

    def project_context(self):
        return {
            "project_id": self.project_id, "name": self.project_name,
            "path": str(self.project), "knowledge_mode": self.knowledge_mode,
            "assignment": self.binding, "mode": self.get("mode"),
        }

    @contextmanager
    def reference_db(self, database=None):
        import shutil
        import tempfile

        database = database or self.db_path
        wal = Path(str(database) + "-wal")
        if wal.exists():
            with tempfile.TemporaryDirectory(prefix="metaform-reference-") as directory:
                snapshot = Path(directory) / "state.sqlite3"
                shutil.copyfile(database, snapshot)
                try:
                    shutil.copyfile(wal, Path(str(snapshot) + "-wal"))
                except FileNotFoundError:
                    pass
                connection = sqlite3.connect(snapshot.as_uri() + "?mode=ro", uri=True)
                try:
                    yield connection
                finally:
                    connection.close()
        else:
            connection = sqlite3.connect(database.as_uri() + "?mode=ro&immutable=1", uri=True)
            try:
                yield connection
            finally:
                connection.close()

    def get(self, key, default=None):
        import json

        if key == "mode" and self.binding:
            return {"module": self.binding["module"], "run_id": self.binding["run_id"]}

        if getattr(self, "_reference_only", False):
            if not self.db_path.exists():
                return default
            with self.reference_db() as connection:
                try:
                    row = connection.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
                except sqlite3.OperationalError:
                    return default
        else:
            with self.db() as db:
                row = db.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    @snapshot_locked
    def set(self, key, value):
        with self.db() as db:
            db.execute(
                "INSERT INTO state VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, dumps(value)),
            )

    @snapshot_locked
    def event(self, kind, value, run_id=None):
        with self.db() as db:
            db.execute(
                "INSERT INTO events(run_id,kind,body,created) VALUES(?,?,?,?)",
                (run_id, kind, dumps(value), now()),
            )

    def trace(self, kind, value, run_id=None):
        if self.debug and not getattr(self, "_reference_only", False):
            self.event("debug." + kind, value, run_id)

    def enter(self, module, run_id=None):
        if self.binding:
            return
        self.set("mode", {"module": module, "run_id": run_id})

    def leave(self):
        if self.binding:
            return
        self.set("mode", None)

    def abort(self):
        mode = self.get("mode")
        if mode and mode.get("run_id"):
            from .workflow import Engine

            aborted = Engine(self).abort(mode["run_id"])
            # The executing harness observes this persisted status and terminates
            # its own process; abort never signals an unverified operating-system PID.
            from .workfolders import cleanup_aborted

            for run in aborted:
                cleanup_aborted(self, run)
        if self.binding:
            from .continuation import marker
            from . import bindings

            local = marker(home=self.home)
            if local and local["nonce"] == self.binding["nonce"]:
                bindings.clear(local["folder"], homes=[self.home])
            self.binding = None
        self.leave()
        self.event("abort", mode)
        return {"aborted": mode, "mode": "router"}

    @snapshot_locked
    def save_run(self, body):
        body.setdefault(
            "origin", {"invocation": str(self.invocation), "target": str(self.project)}
        )
        with self.db() as db:
            db.execute(
                "INSERT INTO runs VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status, body=excluded.body, updated=excluded.updated",
                (body["id"], body["workflow"], body["status"], dumps(body), now()),
            )

    def load_run(self, run_id):
        import json

        if getattr(self, "_reference_only", False):
            with self.reference_db() as connection:
                row = connection.execute("SELECT body FROM runs WHERE id=?", (run_id,)).fetchone()
        else:
            with self.db() as db:
                row = db.execute("SELECT body FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            raise ValueError(f"Unknown run: {run_id}")
        return json.loads(row[0])

    def identifier(self):
        return uuid.uuid4().hex
