"""Activate the packaged CI workflow in the caller's GitHub repository."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from urllib.parse import urlsplit

from .workfolders import git


def repository_name(app, value=None):
    if not value:
        value = git(app.project, "remote", "get-url", "origin").strip()
    value = value.strip().rstrip("/")
    if value.startswith("git@github.com:"):
        value = value.removeprefix("git@github.com:")
    elif "://" in value:
        address = urlsplit(value)
        if address.hostname != "github.com":
            raise ValueError("CI setup needs a GitHub repository in OWNER/REPO form.")
        value = address.path.strip("/")
    value = value.removesuffix(".git")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", value):
        raise ValueError("Pass --repository OWNER/REPO or run inside its GitHub checkout.")
    return value


def setup(app, arguments):
    executable = shutil.which("gh")
    if executable is None:
        raise ValueError("CI setup uses GitHub CLI. Install gh and run gh auth login, then repeat this command.")
    repository = repository_name(app, arguments.get("repository"))

    def api(endpoint, method="GET", body=None):
        command = [
            executable, "api", "--hostname", "github.com", "--method", method,
            "-H", "Accept: application/vnd.github+json",
            "-H", "X-GitHub-Api-Version: 2026-03-10", endpoint,
        ]
        if body is not None:
            command.extend(["--input", "-"])
        result = subprocess.run(
            command,
            input=json.dumps(body) if body is not None else None,
            cwd=app.project,
            env={**os.environ, "GH_PROMPT_DISABLED": "1"},
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode:
            raise ValueError(result.stderr.strip() or result.stdout.strip())
        return json.loads(result.stdout) if result.stdout.strip() else {}

    metadata = api("repos/" + repository)
    repository = metadata["full_name"]
    endpoint = "repos/" + repository + "/actions/workflows/wheel.yml"
    workflow = api(endpoint)
    if workflow["state"] != "active":
        api(endpoint + "/enable", "PUT")
    ref = arguments.get("ref") or metadata["default_branch"]
    dispatch = api(endpoint + "/dispatches", "POST", {"ref": ref})
    result = {
        "repository": repository,
        "private": metadata["private"],
        "workflow": "wheel.yml",
        "enabled": True,
        "ref": ref,
        "build_requested": True,
        "url": dispatch.get("html_url") or "https://github.com/" + repository + "/actions/workflows/wheel.yml",
    }
    if dispatch.get("workflow_run_id"):
        result["run_id"] = dispatch["workflow_run_id"]
    app.event("ci.dispatch", result)
    return result
