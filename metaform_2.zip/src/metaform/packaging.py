from __future__ import annotations

import hashlib
import os
import signal
import subprocess
import sys
import time
from pathlib import Path


class BuildCancelled(Exception):
    pass


def _check_cancelled(cancel):
    if cancel is not None and cancel.is_set():
        raise BuildCancelled


def source_hash(project, cancel=None):
    digest = hashlib.sha256()
    paths = [
        project / "pyproject.toml",
        project / "README.md",
        *sorted((project / "packaging").rglob("*")),
        *sorted((project / "src").rglob("*")),
    ]
    for path in paths:
        _check_cancelled(cancel)
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            digest.update(str(path.relative_to(project)).encode())
            with path.open("rb") as source:
                while chunk := source.read(65536):
                    _check_cancelled(cancel)
                    digest.update(chunk)
    return digest.hexdigest()


def _stop_build(process):
    """Stop the owned build group, including its PEP 517 backend subprocess."""
    if os.name == "nt":
        process.send_signal(signal.CTRL_BREAK_EVENT)
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        process.communicate(timeout=1)
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
        else:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.communicate()


def build(app, source=None, cancel=None):
    source = Path(source or app.project).expanduser().resolve()
    _check_cancelled(cancel)
    process = subprocess.Popen(
        [sys.executable, "-m", "build", "--wheel", "--no-isolation", str(source)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        start_new_session=os.name != "nt",
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
    )
    try:
        while True:
            _check_cancelled(cancel)
            try:
                stdout, stderr = process.communicate(timeout=0.05)
                break
            except subprocess.TimeoutExpired:
                continue
        _check_cancelled(cancel)
    except BaseException:
        _stop_build(process)
        raise
    app.trace(
        "build",
        {"stdout": stdout, "stderr": stderr, "exit": process.returncode},
    )
    if process.returncode:
        raise ValueError(
            f"Build failed for source {source}. Select a Python source project "
            "with package build --source <directory>; the selected artifact need not be that project.\n"
            + (stderr or stdout)
        )
    wheels = sorted((source / "dist").glob("*.whl"), key=lambda p: p.stat().st_mtime)
    bundle_runtime(wheels[-1], cancel)
    fingerprint = source_hash(source, cancel)
    if cancel is None:
        app.set("built_hash", fingerprint)
    return {"wheel": str(wheels[-1]), "source": str(source), "source_hash": fingerprint}


def bundle_runtime(wheel, cancel=None):
    import base64
    import csv
    import importlib.metadata
    import importlib.resources
    import io
    import os
    import tempfile
    import zipfile
    from .portable import add_tree, add_wheel

    fd, temporary = tempfile.mkstemp(dir=wheel.parent, prefix="runtime-")
    os.close(fd)
    try:
        with (
            zipfile.ZipFile(wheel) as old,
            zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as out,
        ):
            record_name = next(
                n for n in old.namelist() if n.endswith(".dist-info/RECORD")
            )
            for name in old.namelist():
                _check_cancelled(cancel)
                if name != record_name and not name.startswith("_portable/"):
                    out.writestr(name, old.read(name))
            for package in (
                "filelock",
                "jinja2",
                "markupsafe",
                "flask",
                "werkzeug",
                "click",
                "itsdangerous",
                "blinker",
            ):
                _check_cancelled(cancel)
                add_tree(
                    out,
                    importlib.resources.files(package),
                    "_portable/" + package + "/",
                )
                dist = importlib.metadata.distribution(package)
                for file in dist.files or []:
                    _check_cancelled(cancel)
                    if "license" in str(file).lower() or str(file).endswith(("METADATA", "RECORD")):
                        item = dist.locate_file(file)
                        if (
                            item.is_file()
                            and "_portable/" + str(file) not in out.namelist()
                        ):
                            out.writestr("_portable/" + str(file), item.read_bytes())
        with zipfile.ZipFile(temporary, "a") as out:
            stream = io.StringIO()
            writer = csv.writer(stream, lineterminator="\n")
            for name in out.namelist():
                _check_cancelled(cancel)
                data = out.read(name)
                encoded = (
                    base64.urlsafe_b64encode(hashlib.sha256(data).digest())
                    .decode()
                    .rstrip("=")
                )
                writer.writerow([name, "sha256=" + encoded, len(data)])
            writer.writerow([record_name, "", ""])
            out.writestr(record_name, stream.getvalue())
        _check_cancelled(cancel)
        os.replace(temporary, wheel)
    finally:
        Path(temporary).unlink(missing_ok=True)


def auto_build(app, cancel=None):
    if (
        app.config.get("auto_build", True)
        and (app.project / "pyproject.toml").is_file()
        and (app.project / "src" / "metaform").is_dir()
    ):
        from .locking import lock

        from filelock import Timeout
        claim = lock(app, "build")
        deadline = time.monotonic() + claim.timeout
        while True:
            _check_cancelled(cancel)
            try:
                claim.acquire(timeout=0)
                break
            except Timeout:
                if time.monotonic() >= deadline:
                    raise
                if cancel is not None:
                    cancel.wait(0.05)
                else:
                    time.sleep(0.05)
        try:
            if app.get("built_hash") != source_hash(app.project, cancel):
                return build(app, cancel=cancel)
        finally:
            claim.release()
    return None
