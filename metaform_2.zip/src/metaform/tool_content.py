"""Represent artifact results for hosts that consume MCP content blocks."""

from .util import dumps


def content_blocks(result):
    if (isinstance(result, dict) and result.get('encoding') == 'base64'
            and isinstance(result.get('data'), str)
            and str(result.get('mime_type', '')).startswith('image/')):
        metadata = {key: value for key, value in result.items() if key != 'data'}
        return [
            {'type': 'text', 'text': dumps(metadata)},
            {'type': 'image', 'data': result['data'], 'mimeType': result['mime_type']},
        ]
    return [{'type': 'text', 'text': dumps(result)}]
