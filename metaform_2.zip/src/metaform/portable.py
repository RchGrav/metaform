"""Executable, offline project exports. Native database features remain installed features."""

from __future__ import annotations

import copy
import ast
import stat
import uuid
import importlib.resources
import json
import os
import hashlib
import io
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from pathlib import Path

from . import history
from .util import digest, now, read_json, write_json


def state_dump(app):
    with app.db() as db:
        return {
            table: [dict(r) for r in db.execute("SELECT * FROM " + table)]
            for table in ("state", "runs", "events", "workfolders")
        }


def add_tree(archive, tree, prefix, excludes=()):
    if prefix in excludes:
        return
    # ZIP import needs directory entries to discover namespace packages such as
    # flask.sansio, which deliberately has no __init__.py.
    if prefix and prefix not in archive.namelist():
        archive.writestr(prefix, b"")
    for item in tree.iterdir():
        if item.name == "__pycache__":
            continue
        if item.is_dir():
            add_tree(archive, item, prefix + item.name + "/", excludes)
        elif not item.name.endswith((".pyc", ".so", ".pyd", ".dll")):
            archive.writestr(prefix + item.name, item.read_bytes())


def add_wheel(archive, wheel, prefix):
    """Unpack a wheel's members into the archive under prefix, metadata included."""
    import io

    present = set(archive.namelist())
    with zipfile.ZipFile(io.BytesIO(wheel.read_bytes())) as source:
        for member in source.namelist():
            if member.endswith("/") or prefix + member in present:
                continue
            archive.writestr(prefix + member, source.read(member))


def remap_path(value, mappings):
    if not isinstance(value, str):
        return value
    for source, destination in sorted(mappings, key=lambda pair: len(pair[0]), reverse=True):
        if value == source:
            return destination
        if value.startswith(source.rstrip("/") + "/"):
            return destination.rstrip("/") + value[len(source.rstrip("/")):]
    return value


def relocate_run(body, mappings, normalize=False):
    """Relocate executable fields; prompt text, answers and evidence stay authored."""
    body = copy.deepcopy(body)

    def job(record):
        if not isinstance(record, dict):
            return
        for field in ("workfolder", "project", "home", "base_dir", "folder"):
            if field in record:
                record[field] = remap_path(record[field], mappings)
        for field in ("gateway", "gateway_token", "pid"):
            record.pop(field, None)
        if normalize:
            record.pop("nonce", None)
            record.pop("begin", None)

    job(body)
    job(body.get("pending"))
    for assignment in body.get("assignments", {}).values():
        job(assignment)
    for frame in body.get("stack", []):
        job(frame)
        definition = frame.get("definition", {})
        job(definition)
    return body


def captured_tree(archive, folder, prefix, excludes=(), checks=None, module_links=None, directories=False):
    """Capture ordinary files once and detect a changing source during the copy."""
    folder = Path(folder)
    from .workfolders import scan_artifact

    scan = scan_artifact if directories else history.scan
    before = scan(folder, excludes)
    resolved_folder = folder.resolve() if module_links is not None else None
    changed = set()
    for name, info in before.items():
        path = folder / name
        member = zipfile.ZipInfo(prefix + name + ("/" if info.get("directory") else ""))
        kind = stat.S_IFDIR if info.get("directory") else stat.S_IFLNK if "symlink" in info else stat.S_IFREG
        member.external_attr = (info["mode"] | kind) << 16
        if info.get("directory"):
            content = b""
        elif "symlink" in info:
            link = info["symlink"]
            if module_links is not None:
                target = path.resolve()
                relative = target.relative_to(resolved_folder).as_posix() if target.is_relative_to(resolved_folder) else None
                if relative is not None and (relative in before or any(entry.startswith(relative + "/") for entry in before)):
                    link = os.path.relpath(target, path.parent)
                else:
                    module_links.append({"path": str(path), "target": str(target), "reason": "unresolved_symlink_target"})
            content = link.encode()
        else:
            try:
                content = path.read_bytes()
            except FileNotFoundError:
                changed.add(name)
                continue
            if hashlib.sha256(content).hexdigest() != info["sha256"]:
                changed.add(name)
        archive.writestr(member, content)
        if checks is not None:
            checks[path] = info
    after = scan(folder, excludes)
    changed.update(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    if changed:
        raise ValueError("Files changed during export: " + ", ".join(str(folder / name) for name in sorted(changed)))


def captured_file(archive, path, member, checks):
    path = Path(path)
    content = path.read_bytes()
    checks[path] = {"sha256": hashlib.sha256(content).hexdigest(), "mode": stat.S_IMODE(path.stat().st_mode)}
    info = zipfile.ZipInfo(member)
    info.external_attr = (stat.S_IFREG | checks[path]["mode"]) << 16
    archive.writestr(info, content)


def verify_captured_files(checks):
    changed = []
    for path, expected in checks.items():
        try:
            if expected.get("directory"):
                actual = {"directory": path.is_dir(), "mode": stat.S_IMODE(path.stat().st_mode)}
            elif "symlink" in expected:
                actual = {"mode": stat.S_IMODE(path.lstat().st_mode)}
                if path.is_symlink():
                    actual["symlink"] = os.readlink(path)
            else:
                actual = {"mode": stat.S_IMODE(path.stat().st_mode), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        except FileNotFoundError:
            actual = None
        if actual != expected:
            changed.append(str(path))
    if changed:
        raise ValueError("Files changed during export: " + ", ".join(sorted(changed)))


def _selected_assignments(app, state):
    jobs = {}
    for row in state["runs"]:
        run = json.loads(row["body"])
        if run["status"] != "running":
            continue
        for job in [run.get("pending"), *run.get("assignments", {}).values()]:
            if job and job.get("request_id") and job["request_id"] not in run.get("receipts", {}):
                jobs[(row["id"], job["request_id"])] = job
    records = {}
    directories = {app.home / "assignments", Path(app.config.get("assignment_home", app.home)) / "assignments"}
    for directory in directories:
        if not directory.is_dir():
            continue
        for path in sorted(directory.glob("*.json")):
            record = read_json(path)
            same_project = record.get("project") == str(app.project)
            if record.get("project_id") is not None:
                same_project = same_project and record["project_id"] == getattr(app, "project_id", None)
            if same_project and (record.get("run_id"), record.get("request_id")) in jobs:
                records[path.name] = record
    # A pending nonce remains usable if an override index was removed meanwhile.
    for (run_id, request_id), job in jobs.items():
        if job.get("nonce"):
            records.setdefault(str(job["nonce"]) + ".json", {
                "nonce": job["nonce"], "project": str(app.project), "home": str(app.home),
                "module": job.get("module", "workflow"), "run_id": run_id,
                "request_id": request_id, "created": job.get("created", now()),
            })
    return records


def _capture_workfolders(app, archive, state):
    for row in state["workfolders"]:
        body = json.loads(row["body"])
        identifier = row["id"]
        if body.get("backend") != "files":
            result = subprocess.run(["git", "-C", body["path"], "archive", body["baseline"] + "^{tree}"], capture_output=True, check=True)
            files = {name: info for name, info in body.get("files", {}).items() if info.get("directory")}
            with tarfile.open(fileobj=io.BytesIO(result.stdout), mode="r:") as tar:
                for item in tar.getmembers():
                    if item.isfile():
                        content = tar.extractfile(item).read()
                        files[item.name] = {"sha256": hashlib.sha256(content).hexdigest(), "mode": 0o755 if item.mode & 0o111 else 0o644}
                        archive.writestr("workfolder-baselines/" + identifier + "/" + item.name, content)
                    elif item.issym():
                        files[item.name] = {"symlink": item.linkname, "mode": item.mode}
                    elif item.isdir():
                        files.setdefault(item.name.rstrip("/"), {"directory": True, "mode": 0o755})
            body.update(backend="files", files=files, git_permissions=True)
            row["body"] = json.dumps(body)
        else:
            baseline = app.home / "workfolder-baselines" / identifier
            if baseline.exists():
                captured_tree(archive, baseline, "workfolder-baselines/" + identifier + "/", directories=True)
        folder = Path(body["path"])
        if folder.exists():
            captured_tree(archive, folder, "workfolders/" + identifier + "/", (".git",), directories=True)


def _module_handlers(manifest):
    handlers = [entry["handler"] for entry in manifest.get("commands", [])]
    handlers.extend(manifest[key] for key in ("raw_handler", "guide_handler") if manifest.get(key))
    handlers.extend(entry["bootstrap_handler"] for entry in manifest.get("commands", []) if entry.get("bootstrap_handler"))
    return {handler.split(":", 1)[0] for handler in handlers}


def _capture_modules(app, archive, selected, checks):
    project = app.root / "modules"
    if project.is_dir():
        captured_tree(archive, project, "modules/project/", ("__pycache__",), checks, module_links=selected["unresolved"])
    for module in selected["modules"]:
        folder = Path(module["directory"])
        local = folder.is_relative_to(project)
        dedicated = (folder / "module.json").is_file()
        if local:
            materialized = Path(".metaform") / folder.relative_to(app.root)
        else:
            prefix = "modules/global/" + module["id"] + "/"
            materialized = Path(".metaform/home/modules") / module["id"]
            if dedicated:
                captured_tree(archive, folder, prefix, ("__pycache__",), checks, module_links=selected["unresolved"])
            else:
                # A flat shared manifest does not own its surrounding module store.
                archive.writestr(prefix + "module.json", json.dumps(module["manifest"]))
                handlers = _module_handlers(module["manifest"])
                if (folder / "__init__.py").exists():
                    handlers.add("__init__.py")
                for handler in handlers:
                    if handler.endswith(".py"):
                        captured_file(archive, history.safe_path(folder, handler), prefix + handler, checks)
        for resource in module["files"]:
            path = Path(resource)
            if (local and path.is_relative_to(project)) or (dedicated and path.is_relative_to(folder)):
                continue
            destination = os.path.normpath(str(materialized / os.path.relpath(path, folder)))
            if destination.startswith("../") or os.path.isabs(destination):
                selected["unresolved"].append({"module": module["id"], "path": str(path), "reason": "outside_portable_project"})
                continue
            if destination.startswith(".metaform/home/"):
                member = "home-assets/" + destination[len(".metaform/home/"):]
            elif destination.startswith(".metaform/"):
                member = "project-assets/" + destination[len(".metaform/"):]
            else:
                member = "project-files/" + destination
            if path.is_dir():
                captured_tree(archive, path, member + "/", checks=checks)
            elif member not in archive.namelist():
                captured_file(archive, path, member, checks)
    _module_import_diagnostics(archive, selected, project)


def _module_import_diagnostics(archive, selected, project):
    """Report statically named imports absent from the offline archive, without executing modules."""
    members = set(archive.namelist())

    def bundled(path):
        return path + ".py" in members or any(name.startswith(path + "/") for name in members)

    for module in selected["modules"]:
        folder = Path(module["directory"])
        relative = folder.relative_to(project).parts if folder.is_relative_to(project) else None
        prefix = "modules/project/" + "/".join(relative) if relative is not None else "modules/global/" + module["id"]
        prefix = prefix.rstrip("/") + "/"
        handlers = _module_handlers(module["manifest"])
        owned = {prefix + handler for handler in handlers if handler.endswith(".py")}
        owned.add(prefix + "__init__.py")
        for resource in module["files"]:
            resource = Path(resource)
            if resource.is_relative_to(folder):
                declared = prefix + resource.relative_to(folder).as_posix()
                owned.update(name for name in members if name == declared or name.startswith(declared + "/"))
        dedicated = (folder / "module.json").is_file()
        for handler in sorted(handlers):
            if (not handler.endswith(".py") and handler.split(".")[0] not in sys.stdlib_module_names
                    and not bundled(handler.replace(".", "/"))):
                selected["unresolved"].append({"module": module["id"], "import": handler,
                    "reason": "unbundled_python_handler"})
        for name in sorted(members):
            if not name.startswith(prefix) or not name.endswith(".py"):
                continue
            if not dedicated and name not in owned:
                continue
            if stat.S_ISLNK(archive.getinfo(name).external_attr >> 16):
                continue
            try:
                tree = ast.parse(archive.read(name), filename=name)
            except (SyntaxError, UnicodeError) as exc:
                selected["unresolved"].append({"module": module["id"], "path": name,
                    "reason": "python_imports_uninspected", "detail": str(exc)})
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports = [(alias.name, alias.name.replace(".", "/")) for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.module:
                    if node.level:
                        base = Path(name).parent
                        for _ in range(node.level - 1):
                            base = base.parent
                        imports = [("." * node.level + node.module, (base / node.module.replace(".", "/")).as_posix())]
                    else:
                        imports = [(node.module, node.module.replace(".", "/"))]
                else:
                    continue
                for imported, path in imports:
                    if not imported.startswith(".") and imported.split(".")[0] in sys.stdlib_module_names:
                        continue
                    if not bundled(path):
                        selected["unresolved"].append({"module": module["id"], "import": imported,
                            "path": name, "line": node.lineno, "reason": "unbundled_python_import"})


def _capture_file_prompts(app, archive, closure, state):
    """Capture actual future file reads while retaining authored record bodies."""
    resources, captured = {}, {}
    previous = read_json(app.home / "resources.json", {})
    elements = closure["global"]["elements"] | closure["project"]["elements"]
    requests = []

    def definition_files(definition, frozen=False, inherited_base=None):
        base = definition.get("base_dir", inherited_base or app.project)
        for step in definition.get("steps", []):
            prompt = step.get("prompt", "")
            if not frozen and step.get("prompt_ref") in elements:
                prompt = elements[step["prompt_ref"]]["entity_json_obj"].get("text", prompt)
            if isinstance(prompt, str) and prompt.startswith("file:"):
                requests.append((base, prompt, digest(definition)))
            for branch in step.get("branches", []):
                if isinstance(branch, dict) and "steps" in branch:
                    definition_files(branch, frozen, base)

    for row in state["runs"]:
        run = json.loads(row["body"])
        for frame in run.get("stack", []):
            if "definition" in frame:
                definition_files(frame["definition"], frozen=True)
    for graph in (closure["project"], closure["global"]):
        for identifier, record in graph["elements"].items():
            data = record["entity_json_obj"]
            if record["entity_schema"] == "metaform:workflow":
                definition = copy.deepcopy(data)
                members = [join["element_id"] for join in graph["joins"]
                           if join.get("type") == "workflow_step" and join.get("object_id") == identifier]
                if members:
                    definition["steps"] = [graph["elements"][member]["entity_json_obj"]
                                           for member in members if member in graph["elements"]]
                definition_files(definition)
            elif record["entity_schema"] == "metaform:prompt":
                text = data.get("text", "")
                if isinstance(text, str) and text.startswith("file:"):
                    requests.append((data.get("base_dir", app.project), text, digest(data)))
    for base, prompt, revision in requests:
        original = str((Path(base) / prompt[5:]).resolve())
        if original in resources:
            continue
        path = app.home / previous[original] if original in previous else Path(original)
        if not path.is_file():
            closure.setdefault("unresolved", []).append({"reason": "missing_runtime_asset", "path": original})
            continue
        destination = "resources/workflows/" + revision + "/" + digest(original) + path.suffix
        content = path.read_bytes()
        captured[path] = hashlib.sha256(content).hexdigest()
        archive.writestr(destination, content)
        resources[original] = destination
    changed = [str(path) for path, expected in captured.items()
               if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected]
    if changed:
        raise ValueError("Files changed during export: " + ", ".join(sorted(changed)))
    return resources


def export(app, path):
    import importlib.metadata
    from .locking import snapshot_lock

    destination = Path(path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_relative_to(app.project) and not destination.is_relative_to(app.root):
        raise ValueError("Write the export outside the target project or inside its .metaform folder so it does not archive itself.")
    fd, temporary = tempfile.mkstemp(dir=destination.parent, prefix="metaform-export-")
    os.close(fd)
    try:
        # Capture into an uncompressed staging archive; compress only after locks release.
        with tempfile.TemporaryFile() as staging:
            with zipfile.ZipFile(staging, "w", zipfile.ZIP_STORED) as archive:
                archive.writestr("__main__.py", "from metaform.portable import main\nraise SystemExit(main())\n")
                add_tree(archive, importlib.resources.files("metaform"), "metaform/", excludes={"metaform/data/global/"})
                for package in ("filelock", "jinja2", "markupsafe", "flask", "werkzeug", "click", "itsdangerous", "blinker"):
                    add_tree(archive, importlib.resources.files(package), package + "/")
                    distribution = importlib.metadata.distribution(package)
                    for file in distribution.files or []:
                        if "license" in str(file).lower() or str(file).endswith(("METADATA", "RECORD")):
                            source = distribution.locate_file(file)
                            if source.is_file() and str(file) not in archive.namelist():
                                archive.writestr(str(file), source.read_bytes())
                with snapshot_lock(app):
                    state = state_dump(app)
                    captured = history.capture_knowledge(app, state)
                    closure = captured["closure"]
                    manifest = history.initialize(app)
                    before = history.scan(app.project, history.exclusions(app))
                    saved = {p: {k: v for k, v in r.items() if k != "stored"} for p, r in history.files_at(manifest, manifest["head"]).items()}
                    last_digest = manifest["versions"].get(manifest["head"], {}).get("knowledge_digest")
                    if before != saved or last_digest != captured["digest"]:
                        history.checkpoint(app, "Export checkpoint", captured=captured)
                        manifest = history.initialize(app)
                    archive.writestr("history/manifest.json", json.dumps(manifest, ensure_ascii=False))
                    for prefix in ("origin", "versions"):
                        folder = history.root(app) / prefix
                        if folder.exists():
                            captured_tree(archive, folder, prefix + "/")
                    _capture_workfolders(app, archive, state)
                    file_checks = {}
                    _capture_modules(app, archive, captured["modules"], file_checks)
                    resources = _capture_file_prompts(app, archive, closure, state)
                    for scope in ("project", "global"):
                        archive.writestr("knowledge/" + scope + ".json", json.dumps(closure[scope], ensure_ascii=False))
                    archive.writestr("knowledge/schemas.json", json.dumps({entry["id"]: entry["body"] for entry in sorted(closure.get("schemas", []), key=lambda entry: entry["owner"] != "global")}, ensure_ascii=False))
                    archive.writestr("knowledge/archive-dependencies.json", json.dumps(closure.get("archive_dependencies", []), ensure_ascii=False))
                    archive.writestr("knowledge/resources.json", json.dumps(resources, ensure_ascii=False))
                    archive.writestr("knowledge/manifest.json", json.dumps({key: value for key, value in closure.items() if key not in {"project", "global", "archive_dependencies"}}, ensure_ascii=False))
                    archive.writestr("continuation/state.json", json.dumps(state, ensure_ascii=False))
                    for name, record in _selected_assignments(app, state).items():
                        archive.writestr("continuation/assignments/" + name, json.dumps(record))
                    from . import bindings as folder_bindings
                    archive.writestr("continuation/bindings.json",
                                     json.dumps(folder_bindings.rows(str(app.project), homes=[app.home])))
                    if (app.root / "outputs").exists():
                        captured_tree(archive, app.root / "outputs", "outputs/", directories=True)
                    after = history.scan(app.project, history.exclusions(app))
                    if before != after:
                        changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
                        raise ValueError("Files changed during export: " + ", ".join(changed))
                    verify_captured_files(file_checks)
                    from .workfolders import scan_artifact, artifact_exclusions

                    project_directories = {name: info for name, info in
                        scan_artifact(app.project, artifact_exclusions(app, app.project)).items()
                        if info.get("directory")}
                    bundle = {
                        "format": "metaform-export/2", "manifest": manifest, "created": now(),
                        "source_project": str(app.project), "source_home": str(app.home),
                        "project_directories": project_directories,
                        "origin_project_id": getattr(app, "project_id", None),
                        "source_revision": closure.get("revision"), "knowledge_digest": captured["digest"],
                        "selected_modules": [module["id"] for module in captured["modules"]["modules"]],
                        "unresolved": closure.get("unresolved", []) + captured["modules"]["unresolved"],
                    }
                    archive.writestr("metaform_bundle.json", json.dumps(bundle, ensure_ascii=False))
                archive.writestr("START-HERE.txt", """Metaform by Richard Graver

Begin or resume: python <this-file>
Module reference: python <this-file> --help
Packaging reference: python <this-file> package --help
Open the web interface: python <this-file> web
Begin a supplied worker assignment: python <this-file> begin <nonce>

The first execution creates a working project beside this archive, named by its
mform_sha_id. Later commands reuse that copy and its recorded continuation.
Keep the archive beside its working copy when continuing the same operation.
origin/ and versions/ inside the archive retain extractable artifact history.

Export again: python <this-file> package export --path <new-file>
Without --path, export writes .metaform/exports/metaform in the working project.
An explicit export path belongs outside the artifact or inside its .metaform
directory. Export captures the selected project, required shared knowledge,
module files, recorded history, outputs, and workflow continuation.

Import into another parent: python <this-file> package import --path <archive> --destination <parent>
Import creates a portable project under <parent>/<mform_sha_id>; it does not
merge that copy into the registered source project. An existing divergent copy
receives a separate suffix. The command returns active worker handoffs.

Python 3.11+ and the offline Python runtime packages are sufficient for portable
knowledge, CLI, MCP, and the workbench. Knowledge is JSON with local SQLite
execution state; no knowledge service or MCP SDK is bundled.
Operations using Git, builds, GitHub, image generation, or a host harness still
need their external tools. Automatic source rebuilding is disabled in copies.

The export result and metaform_bundle.json list unresolved references and
statically named module imports that were not bundled. An optional import may
never be used; dynamic imports require a runtime demonstration. Module authors
can include local dependencies through relative imports and portable.files.
""")
            staging.seek(0)
            with zipfile.ZipFile(staging) as source, zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED) as archive:
                for item in source.infolist():
                    content = source.read(item)
                    item.compress_type = zipfile.ZIP_DEFLATED
                    archive.writestr(item, content)
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return {"path": str(destination), "mform_sha_id": manifest["mform_sha_id"], "bytes": destination.stat().st_size, "unresolved": closure.get("unresolved", []) + captured["modules"]["unresolved"]}


def read_bundle(path):
    with zipfile.ZipFile(path) as archive:
        return json.loads(archive.read("metaform_bundle.json"))


def import_bundle(path, destination=None, replace_inclusive=True):
    from .app import App

    bundle = read_bundle(path)
    incoming = bundle["manifest"]
    parent = Path(destination or Path(path).resolve().parent).resolve()
    target = parent / incoming["mform_sha_id"]
    parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        local_app = App(target, target / ".metaform" / "home", binding=False)
        local = history.initialize(local_app)
        saved = {
            p: {k: v for k, v in r.items() if k != "stored"}
            for p, r in history.files_at(local, local["head"]).items()
        }
        last_entry = local["versions"].get(local["head"], {})
        last_digest = last_entry.get("knowledge_digest")
        if history.scan(
            target, history.exclusions(local_app)
        ) != saved or last_digest != history.knowledge_digest(local_app, version=last_entry.get("knowledge_digest_version", 1)):
            history.checkpoint(local_app, "Local continuation before import")
            local = history.initialize(local_app)
        if not replace_inclusive or not history.inclusive(local, incoming):
            suffix = incoming["suffix"] + 1
            while (parent / (incoming["origin_sha256"] + f"_{suffix:04x}")).exists():
                suffix += 1
            if suffix > 65535:
                raise ValueError("The 16-bit suffix space is exhausted for this origin")
            incoming = dict(
                incoming,
                suffix=suffix,
                mform_sha_id=incoming["origin_sha256"] + f"_{suffix:04x}",
                mform_id=incoming["origin_sha256"][:12] + f"{suffix:04x}",
            )
            target = parent / incoming["mform_sha_id"]
    staging = Path(tempfile.mkdtemp(dir=parent, prefix="metaform-import-"))
    try:
        with zipfile.ZipFile(path) as archive:
            pending_symlinks = []
            extracted = {}
            mappings = {
                "history/": staging / ".metaform" / "history",
                "origin/": staging / ".metaform" / "history" / "origin",
                "versions/": staging / ".metaform" / "history" / "versions",
                "modules/project/": staging / ".metaform" / "modules",
                "modules/global/": staging / ".metaform" / "home" / "modules",
                "workfolders/": staging / ".metaform" / "home" / "workfolders",
                "workfolder-baselines/": staging
                / ".metaform"
                / "home"
                / "workfolder-baselines",
                "outputs/": staging / ".metaform" / "outputs",
                "resources/": staging / ".metaform" / "home" / "resources",
                "home-assets/": staging / ".metaform" / "home",
                "project-assets/": staging / ".metaform",
                "project-files/": staging,
            }
            for item in archive.infolist():
                for prefix, dest in mappings.items():
                    if item.filename.startswith(prefix):
                        relative = dest.relative_to(staging) / item.filename[len(prefix) :]
                        output = history.safe_path(staging, relative)
                        if item.is_dir():
                            output.mkdir(parents=True, exist_ok=True)
                            mode = item.external_attr >> 16
                            if mode & 0o777:
                                output.chmod(mode & 0o777)
                            continue
                        output.parent.mkdir(parents=True, exist_ok=True)
                        mode = item.external_attr >> 16
                        is_link = stat.S_ISLNK(mode)
                        if output in extracted and (is_link or extracted[output]):
                            raise ValueError(f"Archive symlink collides with another member: {item.filename}")
                        extracted[output] = is_link
                        if is_link:
                            # Keep links inactive until extraction and reconstruction finish.
                            pending_symlinks.append((output, archive.read(item).decode()))
                        else:
                            output.write_bytes(archive.read(item))
                            if mode & 0o777:
                                output.chmod(mode & 0o777)
            write_json(staging / ".metaform" / "history" / "manifest.json", incoming)
            root_path = staging / ".metaform"
            home_path = root_path / "home"
            write_json(root_path / "config.json", {"knowledge_mode": "portable", "graph_backend": "json", "auto_build": False, "portable_modules": bundle.get("selected_modules", [])})
            write_json(root_path / "project.json", {
                "format": "metaform-project/1", "knowledge_mode": "portable",
                "project_id": bundle.get("origin_project_id") or "local",
                "origin_project_id": bundle.get("origin_project_id"), "copy_id": uuid.uuid4().hex,
            })
            # Raw files precede bootstrap: import neither manufactures source observations
            # nor briefly loads an ambient corpus before replacing it.
            write_json(root_path / "metaform.json", json.loads(archive.read("knowledge/project.json")))
            write_json(home_path / "inference" / "metaform.json", json.loads(archive.read("knowledge/global.json")))
            write_json(home_path / "schemas.json", json.loads(archive.read("knowledge/schemas.json")))
            for member, output, default in [
                ("knowledge/archive-dependencies.json", root_path / "archive-dependencies.json", []),
                ("knowledge/manifest.json", root_path / "knowledge-manifest.json", {}),
                ("knowledge/resources.json", home_path / "resources.json", {}),
            ]:
                write_json(output, json.loads(archive.read(member)) if member in archive.namelist() else default)
            if bundle["format"] == "metaform-export/2":
                schema_entries = read_json(root_path / "knowledge-manifest.json", {}).get("schemas", [])
                write_json(home_path / "schemas.json", {entry["id"]: entry["body"] for entry in schema_entries if entry["owner"] == "global"})
                write_json(root_path / "schemas.json", {entry["id"]: entry["body"] for entry in schema_entries if entry["owner"] != "global"})
            app = App(staging, home_path, binding=False)
            mappings = [(bundle["source_home"], str(target / ".metaform" / "home")),
                        (bundle["source_project"], str(target))]
            state = json.loads(archive.read("continuation/state.json"))
            with app.db() as db:
                for table, rows in state.items():
                    columns_in_table = {
                        row[1]
                        for row in db.execute(
                            'PRAGMA table_info("' + table.replace('"', '""') + '")'
                        )
                    }
                    if table not in {"state", "runs", "events", "workfolders"}:
                        raise ValueError("Unknown continuation table: " + table)
                    for row in rows:
                        if table == "state" and (
                            row["key"] in {"viewer", "built_hash", "mode"}
                            or row["key"].startswith(("executing:", "gateway:"))
                        ):
                            continue
                        columns = list(row)
                        if not set(columns).issubset(columns_in_table):
                            raise ValueError("Unknown continuation columns")
                        if table == "workfolders":
                            record = json.loads(row["body"])
                            record["path"] = str(
                                target
                                / ".metaform"
                                / "home"
                                / "workfolders"
                                / row["id"]
                            )
                            record["source"] = remap_path(record.get("source"), [(bundle["source_project"], str(target))])
                            row = dict(
                                row, path=record["path"], body=json.dumps(record)
                            )
                        if table == "runs":
                            record = relocate_run(json.loads(row["body"]), mappings)
                            row = dict(row, body=json.dumps(record))
                        db.execute(
                            "INSERT OR REPLACE INTO "
                            + table
                            + "("
                            + ",".join(columns)
                            + ") VALUES("
                            + ",".join("?" for _ in columns)
                            + ")",
                            [row[k] for k in columns],
                        )
            for item in archive.namelist():
                if item.startswith("continuation/assignments/") and item.endswith(
                    ".json"
                ):
                    record = json.loads(archive.read(item))
                    record.update(
                        project=str(target), home=str(target / ".metaform" / "home")
                    )
                    write_json(app.home / "assignments" / Path(item).name, record)
            if "continuation/bindings.json" in archive.namelist():
                from . import bindings as folder_bindings
                for row in json.loads(archive.read("continuation/bindings.json")):
                    body = dict(row["body"], project=str(target), home=str(target / ".metaform" / "home"))
                    folder_bindings.record(remap_path(row["folder"], mappings), body, home=home_path,
                                           created=row.get("created"), updated=row.get("updated"))
            resources = read_json(home_path / "resources.json", {})
            resources.update({remap_path(source, mappings): relative for source, relative in list(resources.items())})
            write_json(home_path / "resources.json", resources)
            history.reconstruct(app, incoming["head"], staging, pending_symlinks=pending_symlinks)
            for name, info in bundle.get("project_directories", {}).items():
                output = history.safe_path(staging, name)
                output.mkdir(parents=True, exist_ok=True)
                output.chmod(info["mode"])
            write_json(
                app.root / "bundle.json",
                {
                    "source_archive": str(Path(path).resolve()),
                    "bundle_hash": digest(bundle),
                    "mform_sha_id": incoming["mform_sha_id"],
                },
            )
            for output, link in pending_symlinks:
                history.safe_path(staging, output.relative_to(staging))
                if output.exists() or output.is_symlink():
                    raise ValueError(f"Archive symlink collides with a materialized path: {output.relative_to(staging)}")
                output.symlink_to(link)
        if target.exists():
            backup = Path(tempfile.mkdtemp(dir=parent, prefix="metaform-replaced-"))
            backup.rmdir()
            os.replace(target, backup)
            try:
                os.replace(staging, target)
            except BaseException:
                os.replace(backup, target)
                raise
            shutil.rmtree(backup)
        else:
            os.replace(staging, target)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return {
        "path": str(target),
        "mform_sha_id": incoming["mform_sha_id"],
        "mform_id": incoming["mform_id"],
        "unresolved": bundle.get("unresolved", []),
    }


def _archive_reference(archive, target, argv):
    """Read archived module declarations without materializing its working project."""
    from .app import App
    from .cli import install_parser, main as cli_main, print_result, run_parser
    from .registry import Registry

    arguments = list(argv)
    human = sys.stdout.isatty()
    while arguments and arguments[0] in {"--json", "--human"}:
        human = arguments.pop(0) == "--human"
    help_requested = any(argument in {"--help", "-h"} for argument in arguments) or arguments[:1] == ["help"]
    if arguments[:1] == ["--project"] or (arguments and arguments[0].startswith("--project=")):
        return cli_main(argv) if help_requested else None
    if arguments[:1] == ["install"] and help_requested:
        install_parser().parse_args(argv[1:])
        return 0
    with tempfile.TemporaryDirectory(prefix="metaform-reference-") as temporary:
        roots = [Path(temporary) / "global", Path(temporary) / "project"]
        with zipfile.ZipFile(archive) as bundle:
            graphs = {scope: json.loads(bundle.read("knowledge/" + scope + ".json"))
                      for scope in ("global", "project")}
            for prefix, root in zip(("modules/global/", "modules/project/"), roots):
                for member in bundle.namelist():
                    if member.startswith(prefix) and member.endswith(".json"):
                        output = history.safe_path(root, member[len(prefix):])
                        output.parent.mkdir(parents=True, exist_ok=True)
                        output.write_bytes(bundle.read(member))
        reference = App.reference(project=target, home=target / ".metaform" / "home")
        reference._module_reference_paths = roots
        reference._reference_graphs = graphs
        reference.knowledge_mode = "portable"
        reference.refresh_config()
        registry = Registry(reference)
        if arguments == ["skill"]:
            from .onboarding import skill_text
            print(skill_text(reference), end="")
            return 0
        command = registry.discover().get(".".join(arguments[:2])) if len(arguments) >= 2 else None
        if not (help_requested or command and command.reference_only
                or len(arguments) == 1 and arguments[0] in registry.manifests()):
            return None
        result = run_parser(registry, arguments[1:] + ["--help"] if arguments[:1] == ["help"] else arguments,
                            reference=True)
        if result is not None:
            print_result(result, human)
    return 0


def main():
    archive = Path(sys.argv[0]).resolve()
    bundle = read_bundle(archive)
    target = archive.parent / bundle["manifest"]["mform_sha_id"]
    argv = sys.argv[1:]
    marker = target / ".metaform" / "bundle.json"
    bundle_hash = digest(bundle)
    if read_json(marker, {}).get("bundle_hash") != bundle_hash:
        # Import may have forked this archive beside another copy of its origin.
        # Reuse that durable copy so each command continues the same run.
        for candidate in sorted(archive.parent.glob(bundle["manifest"]["origin_sha256"] + "_????")):
            if read_json(candidate / ".metaform" / "bundle.json", {}).get("bundle_hash") == bundle_hash:
                target = candidate
                break
        else:
            reference_result = _archive_reference(archive, target, argv)
            if reference_result is not None:
                return reference_result
            target = Path(import_bundle(archive)["path"])
    os.environ["METAFORM_PROJECT"] = str(target)
    os.environ["METAFORM_HOME"] = str(target / ".metaform" / "home")
    from .cli import main as cli_main

    return cli_main()
