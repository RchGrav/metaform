"""Owner-qualified knowledge operations shared by service and portable clients."""
from __future__ import annotations

import copy
from dataclasses import dataclass


class KnowledgeError(ValueError):
    def __init__(self, code, message, details=None):
        super().__init__(message)
        self.code = code
        self.details = details


@dataclass(frozen=True, order=True)
class RecordKey:
    owner: str
    kind: str
    id: str


def reference_fields(join):
    for field in ("object_id", "element_id"):
        if join.get(field):
            reference = {"field": field, "ref": join[field]}
            if field in join.get("reference_owners", {}):
                reference["owner"] = join["reference_owners"][field]
            yield reference
    for index, participant in enumerate(join.get("participants", [])):
        if participant.get("ref") is not None:
            yield dict(participant, field=f"participants[{index}].ref")


class KnowledgeSnapshot:
    def __init__(self, revision, partitions, schemas=None):
        self.revision = revision
        self.partitions = copy.deepcopy(partitions)
        self.schemas = copy.deepcopy(schemas or {})
        self._joins = {owner: {j["id"]: j for j in graph.get("joins", [])}
                       for owner, graph in self.partitions.items()}

    def record(self, key):
        if key.kind == "element":
            value = self.partitions.get(key.owner, {}).get("elements", {}).get(key.id)
        elif key.kind == "join":
            value = self._joins.get(key.owner, {}).get(key.id)
        elif key.kind == "schema":
            value = self.schemas.get(key.owner, {}).get(key.id)
        else:
            value = None
        return copy.deepcopy(value)

    def roots(self, owner):
        graph = self.partitions.get(owner, {})
        return ([RecordKey(owner, "element", i) for i in graph.get("elements", {})]
                + [RecordKey(owner, "join", j["id"]) for j in graph.get("joins", [])
                   if j.get("join_scope") != "merged"])

    def resolve(self, reference, author_owner):
        ref = {"ref": reference} if isinstance(reference, str) else reference
        owners = [ref["owner"]] if ref.get("owner") else [author_owner]
        if not ref.get("owner") and author_owner != "global":
            owners.append("global")
        kinds = [ref["kind"]] if ref.get("kind") else ["element", "join"]
        for owner in owners:
            for kind in kinds:
                key = RecordKey(owner, kind, ref["ref"])
                if self.record(key) is not None:
                    return [key]
        return [RecordKey(owner, kinds[0], ref["ref"]) for owner in owners]

    def incident_element(self, address, owners):
        return [RecordKey(owner, "join", join["id"])
                for owner in sorted(owners) for join in self._joins.get(owner, {}).values()
                if any(ref["ref"] == address and
                       (not ref.get("owner") or ref["owner"] in owners)
                       for ref in reference_fields(join))]

    def incident_join(self, key, owners):
        return [RecordKey(owner, "join", join["id"])
                for owner in sorted(owners) for join in self._joins.get(owner, {}).values()
                if any(key in self.resolve(ref, owner) for ref in reference_fields(join))]

    def source_observations(self, key):
        return [o for o in self.owner_observations(key.owner) if o["element_id"] == key.id]

    def owner_observations(self, owner):
        return copy.deepcopy(self.partitions.get(owner, {}).get("observations", []))


import json
import sqlite3
import threading
import uuid
from contextlib import ExitStack, contextmanager
from pathlib import Path

from .backends import JSONGraph, normalized, replaced_scope
from .graph import Graph, is_type_definition, join_participants, renamed_elements, scoped_export, scoped_join_references, type_ids, type_members
from .util import digest, dumps, now, read_json, write_json


def builtin_schemas():
    from .schemas import builtins
    return builtins()


GRAPH_READS = {"get", "search", "joins", "provenance", "export", "stats", "assemble", "similarity"}
GRAPH_WRITES = {"put", "import", "replace_scope", "rename_elements", "delete_joins", "clean", "merge_perspectives"}


def project_owner(project_id):
    return "project:" + project_id


class BoundGraph:
    def __init__(self, knowledge, owner):
        self.knowledge = knowledge
        self.owner = owner

    def _call(self, method, **arguments):
        return self.knowledge.call("graph." + method, dict(arguments, owner=self.owner))

    def get(self, identifier, scope=None):
        return self._call("get", id=identifier, scope=scope)

    def put(self, graph, source="native", layer="elements"):
        return self._call("put", graph=graph, source=source, layer=layer)

    def replace_scope(self, graph, source, layer="elements"):
        return self._call("replace_scope", graph=graph, source=source, layer=layer)

    def import_raw(self, graph):
        return self._call("import", graph=graph)

    def export(self, scope=None):
        return self._call("export", scope=scope)

    def search(self, query="*", layer=None, scope=None):
        return self._call("search", query=query, layer=layer, scope=scope)

    def joins(self, identifier=None, scope=None, category=None):
        return self._call("joins", identifier=identifier, scope=scope, category=category)

    def provenance(self, identifier):
        return self._call("provenance", identifier=identifier)

    def assemble(self, focal, depth=None, scope=None, category=None):
        return self._call("assemble", focal=focal, depth=depth, scope=scope, category=category)

    def rename_elements(self, mapping):
        return self._call("rename_elements", mapping=mapping)

    def delete_joins(self, object_id=None, category=None, scope=None):
        return self._call("delete_joins", object_id=object_id, category=category, scope=scope)

    def stats(self):
        return self._call("stats")

    def similarity(self):
        return self._call("similarity")

    def merge_perspectives(self):
        return self._call("merge_perspectives")

    def clean(self):
        return self._call("clean")


def _graph_call(graph, method, arguments):
    arguments = dict(arguments)
    if "id" in arguments:
        arguments["identifier"] = arguments.pop("id")
    if method == "import":
        return graph.import_raw(arguments["graph"])
    return getattr(graph, method)(**arguments)


class _MemoryGraph(JSONGraph):
    """Reuse backend-independent graph behavior inside a store transaction."""
    def __init__(self, data, owner=None, *, copy_data=True):
        self.owner = owner
        self.data = copy.deepcopy(data) if copy_data else data

    def get(self, identifier, scope=None):
        if scope is not None:
            return super().get(identifier, scope)
        record = self.data['elements'].get(identifier)
        return copy.deepcopy({key: record[key] for key in
                              ('entity_desc', 'entity_schema', 'entity_json_obj')}) if record else None

    def export(self, scope=None):
        return scoped_export(copy.deepcopy(self.data), scope)

    def put(self, graph, source="native", layer="elements", *, _raw=False):
        if not _raw and source in {"native", "archaeology"}:
            graph = scoped_join_references(graph, source, self.joins(scope=source), self.owner)
        incoming = copy.deepcopy(graph) if _raw else normalized(graph, source, layer)
        self.data["elements"].update(incoming.get("elements", {}))
        for field in ("joins", "observations"):
            rows = {row["id"]: row for row in self.data[field]}
            for row in incoming.get(field, []):
                old = rows.get(row["id"])
                if field != "observations" or old is None or row["created"] > old["created"]:
                    rows[row["id"]] = row
            self.data[field] = sorted(rows.values(), key=lambda row: row["id"])
        return {"elements": len(incoming.get("elements", {})), "joins": len(incoming.get("joins", []))}

    def rename_elements(self, mapping):
        self.data, result = renamed_elements(self.data, mapping, self.owner)
        return result

    def replace_scope(self, graph, source, layer="elements"):
        self.data, result = replaced_scope(self.data, graph, source, layer, self.owner)
        return result

    def delete_joins(self, object_id=None, category=None, scope=None):
        self.data["joins"] = [j for j in self.data["joins"] if not (
            (object_id is None or j.get("object_id") == object_id)
            and (category is None or j["type"] == category)
            and (scope is None or j.get("join_scope") == scope))]


class LocalKnowledge:
    def __init__(self, project_id, project_graph, global_graph, schemas=None, archive_dependencies=None):
        self.project_id = project_id
        self.graphs = {project_owner(project_id): project_graph, "global": global_graph}
        for owner, graph in self.graphs.items():
            graph.owner = owner
            graph.knowledge_snapshot = self.read_snapshot
        self._schema_defaults = copy.deepcopy(schemas or {})
        self.schemas = copy.deepcopy(self._schema_defaults)
        self.schema_paths = {}
        for owner, graph in self.graphs.items():
            if hasattr(graph, "path"):
                self.schema_paths[owner] = (graph.path.parent.parent if owner == "global" else graph.path.parent) / "schemas.json"
                self.schemas[owner] = self.schemas.get(owner, {}) | read_json(self.schema_paths[owner], {})
        self.archive_dependencies = archive_dependencies or []

    def _owner(self, owner):
        owner = owner or project_owner(self.project_id)
        if owner not in self.graphs:
            raise KnowledgeError("invalid_owner", "Owner does not belong to this project", {"owner": owner})
        return owner

    def call(self, operation, arguments, request_id=None):
        arguments = dict(arguments)
        if operation in {"model.capture", "model.resolve", "model.read", "model.list", "model.publish"}:
            from filelock import FileLock
            from .models import model_operation
            graph = self.graphs[project_owner(self.project_id)]
            with FileLock(str(graph.path) + ".model.lock", timeout=30):
                return model_operation(graph, self.project_id, operation, arguments, self.graphs["global"])
        if operation.startswith("inference."):
            from filelock import FileLock
            graph = self.graphs["global"]
            with FileLock(str(graph.path) + ".intake.lock", timeout=30):
                return inference_operation(self, self.project_id, operation, arguments, self.archive_dependencies)
        if operation.startswith("graph."):
            method = operation.removeprefix("graph.")
            if method not in GRAPH_READS | GRAPH_WRITES:
                raise KnowledgeError("unknown_operation", "Unknown operation: " + operation)
            if method == "search" and "owners" in arguments:
                owners = [self._owner(o) for o in arguments.pop("owners")]
                return [dict(row, owner=owner) for owner in owners
                        for row in _graph_call(self.graphs[owner], method, arguments)]
            owner = self._owner(arguments.pop("owner", None))
            return _graph_call(self.graphs[owner], method, arguments)
        if operation in {"schema.get", "schema.put", "schema.list"}:
            owner = self._owner(arguments.pop("owner", None))
            records = self._refresh_schemas(owner)
            if operation == "schema.list":
                return copy.deepcopy(records)
            if operation == "schema.get":
                return copy.deepcopy(records.get(arguments["id"]))
            schema = arguments["schema"]
            if owner in self.schema_paths:
                from filelock import FileLock
                path = self.schema_paths[owner]
                with FileLock(str(path) + ".lock"):
                    stored = read_json(path, {})
                    stored[schema["$id"]] = copy.deepcopy(schema)
                    write_json(path, stored)
                    records.update(stored)
            records[schema["$id"]] = copy.deepcopy(schema)
            return schema
        if operation == "knowledge.assemble":
            return assemble_knowledge(self.read_snapshot(), self.project_id, **arguments)
        if operation == "knowledge.snapshot":
            from .knowledge_export import project_closure
            capture = self.read_snapshot()
            capture["runtime_assets"] = arguments.get("runtime_assets", {})
            return project_closure(capture, self.project_id, arguments.get("execution_roots", []))
        raise KnowledgeError("unknown_operation", "Unknown operation: " + operation)

    def _refresh_schemas(self, owner):
        if owner in self.schema_paths:
            self.schemas[owner] = self._schema_defaults.get(owner, {}) | read_json(self.schema_paths[owner], {})
        return self.schemas.setdefault(owner, {})

    def read_snapshot(self):
        from filelock import FileLock
        with ExitStack() as locks:
            paths = sorted({str(graph.path) + ".lock" for graph in self.graphs.values() if type(graph) is JSONGraph}
                           | {str(path) + ".lock" for path in self.schema_paths.values()})
            for path in paths:
                locks.enter_context(FileLock(path, timeout=30))
            for owner in self.graphs:
                self._refresh_schemas(owner)
            return {"revision": None, "partitions": {owner: graph.export() for owner, graph in self.graphs.items()},
                    "schemas": copy.deepcopy(self.schemas) | {"global": builtin_schemas() | self.schemas.get("global", {})},
                    "archive_dependencies": copy.deepcopy(self.archive_dependencies)}


class _BoundKnowledge:
    def __init__(self, store, project_id):
        self.store, self.project_id = store, project_id

    def call(self, operation, arguments, request_id=None):
        return self.store.call(self.project_id, operation, arguments, request_id)


class _SqlModelReader:
    """Read revision journal rows without reconstructing the project graph."""
    def __init__(self, db, owner, store):
        self.db, self.owner, self.store = db, owner, store

    def has(self, identifier):
        return self.db.execute("SELECT 1 FROM elements WHERE owner=? AND id=?", (self.owner, identifier)).fetchone() is not None

    def get(self, identifier):
        from collections import OrderedDict
        cache = getattr(self.store, "_model_revision_cache", None)
        if cache is None:
            cache = self.store._model_revision_cache = OrderedDict()
        cache_key = (self.owner, identifier)
        if identifier.startswith("model-revision:") and cache_key in cache:
            cache.move_to_end(cache_key)
            return cache[cache_key]
        row = self.db.execute("SELECT entity_schema,entity_json_obj FROM elements WHERE owner=? AND id=?", (self.owner, identifier)).fetchone()
        if row is None:
            return None
        record = {"entity_schema": row["entity_schema"], "entity_json_obj": json.loads(row["entity_json_obj"])}
        if identifier.startswith("model-revision:"):
            from .namespace import IndexedSnapshot
            indexed = IndexedSnapshot(record["entity_json_obj"]["snapshot"])
            model = indexed.get("model", {})
            indexed.revision_key = (model.get("project"), model.get("model"), model.get("revision"))
            record["entity_json_obj"]["snapshot"] = indexed
            cache[cache_key] = record
            while len(cache) > 8:
                cache.popitem(last=False)
        return record

    def export(self):
        from .models import HEAD_SCHEMA
        return {"elements": {row["id"]: {"entity_schema": HEAD_SCHEMA, "entity_json_obj": json.loads(row["entity_json_obj"])}
            for row in self.db.execute("SELECT id,entity_json_obj FROM elements WHERE owner=? AND entity_schema=? ORDER BY id", (self.owner, HEAD_SCHEMA))}}


class KnowledgeStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        with self.transaction() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS projects(project_id TEXT PRIMARY KEY, name TEXT NOT NULL,
                    path TEXT NOT NULL UNIQUE, created TEXT NOT NULL, updated TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS elements(owner TEXT NOT NULL,id TEXT NOT NULL,entity_desc TEXT NOT NULL,
                    entity_schema TEXT NOT NULL,entity_json_obj TEXT NOT NULL,layer TEXT NOT NULL,PRIMARY KEY(owner,id));
                CREATE TABLE IF NOT EXISTS joins(owner TEXT NOT NULL,id TEXT NOT NULL,object_id TEXT NOT NULL,
                    element_id TEXT NOT NULL,type TEXT NOT NULL,join_scope TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(owner,id));
                CREATE TABLE IF NOT EXISTS participants(owner TEXT NOT NULL,join_id TEXT NOT NULL,ordinal INTEGER NOT NULL,
                    role TEXT NOT NULL,ref TEXT,value TEXT,PRIMARY KEY(owner,join_id,ordinal),
                    FOREIGN KEY(owner,join_id) REFERENCES joins(owner,id) ON DELETE CASCADE);
                CREATE TABLE IF NOT EXISTS observations(owner TEXT NOT NULL,id TEXT NOT NULL,element_id TEXT NOT NULL,
                    source TEXT NOT NULL,record TEXT NOT NULL,created TEXT NOT NULL,PRIMARY KEY(owner,id),
                    FOREIGN KEY(owner,element_id) REFERENCES elements(owner,id) ON DELETE CASCADE);
                CREATE TABLE IF NOT EXISTS schemas(owner TEXT NOT NULL,id TEXT NOT NULL,body TEXT NOT NULL,PRIMARY KEY(owner,id));
                CREATE TABLE IF NOT EXISTS receipts(project_context TEXT NOT NULL,request_id TEXT NOT NULL,body_hash TEXT NOT NULL,
                    result TEXT NOT NULL,PRIMARY KEY(project_context,request_id));
                CREATE TABLE IF NOT EXISTS revision(id INTEGER PRIMARY KEY CHECK(id=1),value INTEGER NOT NULL);
                INSERT OR IGNORE INTO revision VALUES(1,0);
                CREATE TABLE IF NOT EXISTS imports(source_home TEXT NOT NULL,source_digest TEXT NOT NULL,
                    PRIMARY KEY(source_home,source_digest));
                CREATE INDEX IF NOT EXISTS element_schema ON elements(owner,entity_schema,id);
                CREATE INDEX IF NOT EXISTS element_layer ON elements(owner,layer,id);
                CREATE INDEX IF NOT EXISTS join_source ON joins(owner,object_id,type,join_scope);
                CREATE INDEX IF NOT EXISTS join_target ON joins(owner,element_id,type,join_scope);
                CREATE INDEX IF NOT EXISTS participant_ref ON participants(owner,ref);
                CREATE INDEX IF NOT EXISTS observation_source ON observations(owner,element_id,source);
            """)

    @contextmanager
    def transaction(self, write=True):
        existing = getattr(self._local, "connection", None)
        if existing is not None:
            yield existing
            return
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
        self._local.connection = db
        self._local.after_commit = []
        callbacks = []
        try:
            yield db
            db.commit()
            callbacks = self._local.after_commit
        except BaseException:
            db.rollback()
            raise
        finally:
            self._local.connection = None
            db.close()
        for callback in callbacks:
            callback()

    @property
    def revision(self):
        with self.transaction(False) as db:
            return db.execute("SELECT value FROM revision WHERE id=1").fetchone()[0]

    def bind(self, project_id):
        return _BoundKnowledge(self, project_id)

    def _project(self, db, project_id):
        row = db.execute("SELECT * FROM projects WHERE project_id=?", (project_id,)).fetchone()
        if row is None:
            raise KnowledgeError("unknown_project", "Unknown project: " + str(project_id))
        return dict(row)

    def _owner(self, project_id, owner):
        owner = owner or (project_owner(project_id) if project_id else "global")
        if owner != "global" and (project_id is None or owner != project_owner(project_id)):
            raise KnowledgeError("invalid_owner", "Owner does not belong to this project", {"owner": owner})
        return owner

    def _export(self, db, owner):
        return {"elements": {row["id"]: {"entity_desc": row["entity_desc"], "entity_schema": row["entity_schema"],
                    "entity_json_obj": json.loads(row["entity_json_obj"]), "layer": row["layer"]}
                    for row in db.execute("SELECT * FROM elements WHERE owner=? ORDER BY id", (owner,))},
                "joins": [json.loads(row[0]) for row in db.execute("SELECT body FROM joins WHERE owner=? ORDER BY id", (owner,))],
                "observations": [{key: row[key] for key in ("id", "element_id", "source", "created")} | {"record": json.loads(row["record"])}
                    for row in db.execute("SELECT * FROM observations WHERE owner=? ORDER BY id", (owner,))]}

    def _replace(self, db, owner, graph):
        db.execute("DELETE FROM joins WHERE owner=?", (owner,))
        db.execute("DELETE FROM elements WHERE owner=?", (owner,))
        db.executemany("INSERT INTO elements VALUES(?,?,?,?,?,?)", [
            (owner, identifier, r["entity_desc"], r["entity_schema"], dumps(r["entity_json_obj"]), r.get("layer", "elements"))
            for identifier, r in graph["elements"].items()])
        for join in graph["joins"]:
            db.execute("INSERT INTO joins VALUES(?,?,?,?,?,?,?)", (owner, join["id"], join.get("object_id", ""),
                join.get("element_id", ""), join["type"], join["join_scope"], dumps(join)))
            db.executemany("INSERT INTO participants VALUES(?,?,?,?,?,?)", [
                (owner, join["id"], i, p.get("role", ""), p.get("ref"), dumps(p.get("value")))
                for i, p in enumerate(join_participants(join))])
        db.executemany("INSERT INTO observations VALUES(?,?,?,?,?,?)", [
            (owner, o["id"], o["element_id"], o["source"], dumps(o["record"]), o["created"]) for o in graph["observations"]])

    def call(self, project_id, operation, arguments, request_id=None):
        mutation = operation in {"model.publish", "project.register", "project.relocate", "project.forget", "project.clear", "project.adopt", "schema.put", "inference.contribute", "inference.commit", "inference.promote"} or operation.removeprefix("graph.") in GRAPH_WRITES
        with self.transaction(mutation) as db:
            if project_id is not None:
                self._project(db, project_id)
            context = project_id or "global-administration"
            body_hash = digest([context, operation, arguments])
            if mutation and request_id is not None:
                receipt = db.execute("SELECT * FROM receipts WHERE project_context=? AND request_id=?", (context, request_id)).fetchone()
                if receipt:
                    if receipt["body_hash"] != body_hash:
                        raise KnowledgeError("request_id_conflict", "request_id was used with a different request")
                    result = json.loads(receipt["result"])
                    if operation == "project.adopt":
                        self._adoption_marker(result, arguments["path"], arguments["home"])
                    return result
            result = self._dispatch(db, project_id, operation, dict(arguments))
            if mutation:
                db.execute("UPDATE revision SET value=value+1 WHERE id=1")
                if request_id is not None:
                    db.execute("INSERT INTO receipts VALUES(?,?,?,?)", (context, request_id, body_hash, dumps(result)))
            return result

    def _dispatch(self, db, project_id, operation, arguments):
        if operation in {"model.capture", "model.resolve", "model.read", "model.list", "model.publish"}:
            from .models import model_operation
            owner = self._owner(project_id, project_owner(project_id))
            graph = _MemoryGraph(self._export(db, owner), owner, copy_data=False) if operation == "model.publish" else _SqlModelReader(db, owner, self)
            global_graph = _MemoryGraph(self._export(db, "global"), "global", copy_data=False) if operation == "model.publish" else None
            result = model_operation(graph, project_id, operation, arguments, global_graph)
            if operation == "model.publish":
                self._replace(db, owner, graph.data)
            return result
        if operation.startswith("inference."):
            return inference_operation(self.bind(project_id), project_id, operation, arguments)
        if operation == "project.adopt":
            return self.adopt(arguments["path"], arguments["home"], arguments.get("name"), arguments.get("new_copy", False))
        if operation == "project.register":
            path = str(Path(arguments["path"]).resolve())
            row = db.execute("SELECT * FROM projects WHERE path=?", (path,)).fetchone()
            if row:
                return dict(row)
            identifier, timestamp = str(uuid.uuid4()), now()
            db.execute("INSERT INTO projects VALUES(?,?,?,?,?)", (identifier, arguments.get("name") or Path(path).name, path, timestamp, timestamp))
            return self._project(db, identifier)
        if operation == "project.list":
            return [dict(row) for row in db.execute("SELECT * FROM projects ORDER BY path")]
        if operation == "project.get":
            return self._project(db, arguments.get("project_id", project_id))
        if operation == "project.relocate":
            self._project(db, project_id)
            db.execute("UPDATE projects SET path=?,updated=? WHERE project_id=?", (str(Path(arguments["path"]).resolve()), now(), project_id))
            return self._project(db, project_id)
        if operation == "project.clear":
            from .models import HEAD_SCHEMA
            owner = project_owner(project_id)
            counts = {"models": db.execute("SELECT count(*) FROM elements WHERE owner=? AND entity_schema=?", (owner, HEAD_SCHEMA)).fetchone()[0],
                      "elements": db.execute("SELECT count(*) FROM elements WHERE owner=?", (owner,)).fetchone()[0],
                      "joins": db.execute("SELECT count(*) FROM joins WHERE owner=?", (owner,)).fetchone()[0]}
            for table in ("elements", "joins", "participants", "observations", "schemas"):
                db.execute("DELETE FROM " + table + " WHERE owner=?", (owner,))
            db.execute("DELETE FROM receipts WHERE project_context=?", (project_id,))
            return counts
        if operation == "project.forget":
            target = str(Path(arguments["path"]).expanduser().resolve()) if arguments.get("path") else None
            rows = [dict(row) for row in db.execute("SELECT * FROM projects ORDER BY path")]
            chosen = [row for row in rows if (target is not None and row["path"] == target)
                      or (arguments.get("missing") and not Path(row["path"]).is_dir())]
            for row in chosen:
                db.execute("DELETE FROM projects WHERE project_id=?", (row["project_id"],))
            return {"forgotten": [row["path"] for row in chosen]}
        if operation.startswith("graph."):
            method = operation.removeprefix("graph.")
            if method not in GRAPH_READS | GRAPH_WRITES:
                raise KnowledgeError("unknown_operation", "Unknown operation: " + operation)
            if method == "search" and "owners" in arguments:
                owners = [self._owner(project_id, o) for o in arguments.pop("owners")]
                return [dict(row, owner=owner) for owner in owners
                        for row in _graph_call(_MemoryGraph(self._export(db, owner), owner, copy_data=False), method, arguments)]
            owner = self._owner(project_id, arguments.pop("owner", None))
            if method == "get" and arguments.get("scope") is None:
                row = db.execute("SELECT entity_desc,entity_schema,entity_json_obj FROM elements WHERE owner=? AND id=?", (owner, arguments.get("identifier", arguments.get("id")))).fetchone()
                return {"entity_desc": row["entity_desc"], "entity_schema": row["entity_schema"], "entity_json_obj": json.loads(row["entity_json_obj"])} if row else None
            if method == "search" and arguments.get("layer") and arguments.get("query", "*") == "*" and arguments.get("scope") is None:
                rows = db.execute("SELECT * FROM elements WHERE owner=? AND layer=? ORDER BY id", (owner, arguments["layer"])).fetchall()
                return [{"id": row["id"], "entity_desc": row["entity_desc"], "entity_schema": row["entity_schema"],
                    "entity_json_obj": json.loads(row["entity_json_obj"]), "layer": row["layer"],
                    "sources": [source[0] for source in db.execute("SELECT DISTINCT source FROM observations WHERE owner=? AND element_id=? ORDER BY source", (owner, row["id"]))]} for row in rows]
            graph = _MemoryGraph(self._export(db, owner), owner, copy_data=False)
            if method in {"similarity", "merge_perspectives", "clean"}:
                graph.knowledge_snapshot = lambda: {"revision": None, "partitions": {
                    o: graph.export() if o == owner else self._export(db, o) for o in {owner, "global"}}}
            result = _graph_call(graph, method, arguments)
            if method in GRAPH_WRITES:
                self._replace(db, owner, graph.data)
            return result
        if operation in {"schema.get", "schema.put", "schema.list"}:
            owner = self._owner(project_id, arguments.pop("owner", None))
            if operation == "schema.list":
                return {row["id"]: json.loads(row["body"]) for row in db.execute("SELECT * FROM schemas WHERE owner=? ORDER BY id", (owner,))}
            if operation == "schema.get":
                row = db.execute("SELECT body FROM schemas WHERE owner=? AND id=?", (owner, arguments["id"])).fetchone()
                return json.loads(row[0]) if row else None
            schema = arguments["schema"]
            db.execute("INSERT INTO schemas VALUES(?,?,?) ON CONFLICT(owner,id) DO UPDATE SET body=excluded.body", (owner, schema["$id"], dumps(schema)))
            return schema
        if operation == "knowledge.assemble":
            return assemble_knowledge(self.read_snapshot(project_id), project_id, **arguments)
        if operation == "knowledge.snapshot":
            from .knowledge_export import SqlKnowledgeSnapshot, project_closure
            self._project(db, project_id)
            return project_closure(SqlKnowledgeSnapshot(db, project_id, self.revision, arguments.get("runtime_assets"), {"global": builtin_schemas()}), project_id, arguments.get("execution_roots", []))
        raise KnowledgeError("unknown_operation", "Unknown operation: " + operation)

    def read_snapshot(self, project_id):
        with self.transaction(False) as db:
            self._project(db, project_id)
            owners = [project_owner(project_id), "global"]
            return {"revision": self.revision, "partitions": {owner: self._export(db, owner) for owner in owners},
                    "schemas": {owner: {row["id"]: json.loads(row["body"]) for row in db.execute("SELECT * FROM schemas WHERE owner=? ORDER BY id", (owner,))} for owner in owners}}

    def adopt(self, project, home, name=None, new_copy=False):
        from .backends import open_graph, graph_suffix
        project, home = Path(project).resolve(), Path(home).resolve()
        root = project / ".metaform"
        config = read_json(home / "config.json", {}) | read_json(root / "config.json", {})
        backend = config.get("graph_backend", "sqlite")
        suffix = graph_suffix(backend)
        empty = {"elements": {}, "joins": [], "observations": []}
        def legacy(path):
            return open_graph(path, backend).export() if path.exists() else copy.deepcopy(empty)
        identity = read_json(root / "project.json", {})
        local_data = legacy(root / ("metaform" + suffix))
        global_data = legacy(home / "inference" / ("metaform" + suffix))
        local_schemas = read_json(root / "schemas.json", {})
        global_schemas = read_json(home / "schemas.json", {})
        with self.transaction() as db:
            entry = self.call(None, "project.register", {"path": str(project), "name": name, "new_copy": new_copy})
            owner = project_owner(entry["project_id"])
            if new_copy and identity.get("project_id") and identity["project_id"] != entry["project_id"]:
                previous = self._project(db, identity["project_id"])
                old_owner = project_owner(previous["project_id"])
                local_data = translated_ownership(self._export(db, old_owner), old_owner, owner)
                local_schemas = {row["id"]: translated_ownership(json.loads(row["body"]), old_owner, owner)
                                 for row in db.execute("SELECT id,body FROM schemas WHERE owner=?", (old_owner,))}
                entry["origin_project_id"] = previous["project_id"]
            partitions = {owner: local_data}
            source_digest = digest(global_data)
            if not db.execute("SELECT 1 FROM imports WHERE source_home=? AND source_digest=?", (str(home), source_digest)).fetchone():
                partitions["global"] = global_data
            for selected_owner, incoming in partitions.items():
                current = self._export(db, selected_owner)
                conflicts = []
                for kind in ("elements", "joins", "observations"):
                    old = current[kind] if kind == "elements" else {r["id"]: r for r in current[kind]}
                    rows = incoming[kind] if kind == "elements" else {r["id"]: r for r in incoming[kind]}
                    conflicts.extend({"owner": selected_owner, "kind": kind, "id": identifier, "existing": old[identifier], "incoming": row}
                                     for identifier, row in rows.items() if identifier in old and old[identifier] != row)
                if conflicts:
                    raise KnowledgeError("migration_conflict", "Legacy knowledge conflicts with stored records", conflicts)
                self.call(entry["project_id"], "graph.import", {"owner": selected_owner, "graph": incoming})
                copied = self._export(db, selected_owner)
                for kind in ("elements", "joins", "observations"):
                    actual = copied[kind] if kind == "elements" else {r["id"]: r for r in copied[kind]}
                    rows = incoming[kind] if kind == "elements" else {r["id"]: r for r in incoming[kind]}
                    if any(actual.get(identifier) != row for identifier, row in rows.items()):
                        raise KnowledgeError("migration_verification_failed", "Imported source records did not match", {"owner": selected_owner, "kind": kind})
            db.execute("INSERT OR IGNORE INTO imports VALUES(?,?)", (str(home), source_digest))
            # Keep graph-only import identities valid for previously adopted homes.
            schema_digest = digest(["schemas", global_schemas])
            schema_partitions = {owner: local_schemas}
            if not db.execute("SELECT 1 FROM imports WHERE source_home=? AND source_digest=?", (str(home), schema_digest)).fetchone():
                schema_partitions["global"] = global_schemas
            for selected_owner, incoming in schema_partitions.items():
                current = self.call(entry["project_id"], "schema.list", {"owner": selected_owner})
                conflicts = [{"owner": selected_owner, "kind": "schemas", "id": identifier,
                              "existing": current[identifier], "incoming": schema}
                             for identifier, schema in incoming.items()
                             if identifier in current and current[identifier] != schema]
                if conflicts:
                    raise KnowledgeError("migration_conflict", "Legacy knowledge conflicts with stored records", conflicts)
                for schema in incoming.values():
                    self.call(entry["project_id"], "schema.put", {"owner": selected_owner, "schema": schema})
                copied = self.call(entry["project_id"], "schema.list", {"owner": selected_owner})
                if any(copied.get(identifier) != schema for identifier, schema in incoming.items()):
                    raise KnowledgeError("migration_verification_failed", "Imported source records did not match", {"owner": selected_owner, "kind": "schemas"})
            db.execute("INSERT OR IGNORE INTO imports VALUES(?,?)", (str(home), schema_digest))
            self._adoption_marker(entry, project, home)
        return entry

    def _adoption_marker(self, entry, project, home):
        marker = {"format": "metaform-project/1", "project_id": entry["project_id"],
                  "knowledge_mode": "service", "service_home": str(Path(home).resolve())}
        if entry.get("origin_project_id"):
            marker["origin_project_id"] = entry["origin_project_id"]
        self._local.after_commit.append(lambda: write_json(Path(project).resolve() / ".metaform" / "project.json", marker))


def assemble_knowledge(capture, project_id, focal, depth=None, scope=None, category=None):
    from collections import deque
    from dataclasses import asdict
    from .knowledge_export import DictionarySnapshot
    from .similarity import compare

    full_capture = capture
    capture = copy.deepcopy(capture)
    capture["partitions"] = {owner: scoped_export(graph, scope) for owner, graph in capture["partitions"].items()}
    reader = DictionarySnapshot(capture)
    owner = project_owner(project_id)
    owners = {owner, "global"}
    authored = {o: scoped_export(full_capture["partitions"].get(o, {"elements": {}, "joins": [], "observations": []}), "authored")
                for o in owners}

    def definition(identifier, author_owner):
        for candidate_owner in dict.fromkeys((author_owner, "global")):
            graph = authored[candidate_owner]
            body = graph["elements"].get(identifier)
            if not is_type_definition(body) and candidate_owner == "global":
                graph = full_capture["partitions"].get("global", {})
                body = graph.get("elements", {}).get(identifier)
            if is_type_definition(body):
                observations = [o for o in graph.get("observations", []) if o["element_id"] == identifier
                                and is_type_definition(o["record"])]
                return RecordKey(candidate_owner, "element", identifier), body, observations
        return None

    selected = {o: {"elements": {}, "joins": [], "observations": []} for o in owners}
    focal_keys = reader.resolve(focal, owner)
    focal_definition = None
    if not any(reader.record(key) is not None for key in focal_keys):
        focal_definition = definition(focal, owner)
        if focal_definition:
            focal_keys = [focal_definition[0]]
    queue = deque((key, 0) for key in focal_keys)
    if not any(type_ids(reader.record(key)) or (reader.record(key) or {}).get("entity_schema") == "metaform:actual-element"
               for key in focal_keys):
        for selected_owner in sorted(owners):
            records = reader.partitions.get(selected_owner, {}).get("elements", {})
            queue.extend((RecordKey(selected_owner, "element", identifier), 0)
                         for identifier in type_members(records, focal))
    visited, selected_joins, unresolved = set(), set(), []
    while queue:
        key, distance = queue.popleft()
        if key in visited:
            continue
        visited.add(key)
        body = reader.record(key)
        observations = reader.source_observations(key)
        if body is None and focal_definition and key == focal_definition[0]:
            _, body, observations = focal_definition
        if key.owner not in owners:
            continue
        if key.kind == "element" and body is not None:
            selected[key.owner]["elements"][key.id] = body
            selected[key.owner]["observations"].extend(observations)
        elif body is None:
            unresolved.append({"from": asdict(key), "field": "focal", "ref": key.id, "reason": "missing"})
        if depth is not None and distance >= depth:
            continue
        incident = reader.incident_element(key.id, owners) if key.kind == "element" else reader.incident_join(key, owners)
        if key.kind == "join" and body is not None:
            incident = [key, *incident]
        for joined in incident:
            join = reader.record(joined)
            if joined in selected_joins or join.get("join_scope") == "merged" or (category is not None and join["type"] != category):
                continue
            selected_joins.add(joined)
            selected[joined.owner]["joins"].append(join)
            queue.append((joined, distance + 1))
            for ref in reference_fields(join):
                for target in reader.resolve(ref, joined.owner):
                    if target.owner not in owners:
                        unresolved.append({"from": asdict(joined), "field": ref["field"], "ref": ref["ref"], "requested_owner": target.owner, "reason": "outside_project"})
                    else:
                        queue.append((target, distance + 1))
    for selected_owner, graph in selected.items():
        classifications = dict.fromkeys(type_id for record in graph["elements"].values() for type_id in type_ids(record))
        for type_id in classifications:
            keys = reader.resolve({"ref": type_id, "kind": "element"}, selected_owner)
            fallback = None
            if not any(reader.record(key) is not None for key in keys):
                fallback = definition(type_id, selected_owner)
                if fallback:
                    keys = [fallback[0]]
            for key in keys:
                body = reader.record(key)
                observations = reader.source_observations(key)
                if fallback and key == fallback[0]:
                    _, body, observations = fallback
                if body is not None and key.owner in owners and key.id not in selected[key.owner]["elements"]:
                    selected[key.owner]["elements"][key.id] = body
                    selected[key.owner]["observations"].extend(observations)
    similarity = {o: compare(scoped_export(graph, "native"), scoped_export(graph, "archaeology"),
                            owner=o, resolve=reader.resolve) for o, graph in selected.items()}
    return {"project": selected[owner], "global": selected["global"], "similarity": similarity, "unresolved": unresolved}


def inference_operation(knowledge, project_id, operation, arguments, archive_dependencies=()):
    global_graph = BoundGraph(knowledge, "global")
    local_graph = BoundGraph(knowledge, project_owner(project_id))

    def completions(identifier):
        return [o["record"] for o in global_graph.provenance(identifier) if o["source"] == "archaeology-complete"]

    def read(identifier):
        completed = completions(identifier)
        result = {"id": identifier, "inference_complete": bool(completed), "graph": None}
        snapshots = [record["inference"] for record in completed if "inference" in record]
        if not snapshots:
            return result | {"status": "unresolved_structure" if completed else "incomplete"}
        snapshot = snapshots[-1]
        joins = snapshot["joins"]
        join_ids = {join["id"] for join in joins}
        members = [(None, {"ref": member, "kind": "element", "field": "elements"})
                   for member in sorted(set(snapshot["elements"]) | {identifier})]
        for join in joins:
            members.extend((join["id"], ref) for ref in reference_fields(join))
        elements, unresolved, issues = {}, set(), []
        archived = {RecordKey(r["owner"], r["kind"], r["id"]): r["body"] for r in archive_dependencies}
        for source_join, ref in members:
            member, owner = ref["ref"], ref.get("owner", "global")
            kind = ref.get("kind", "join" if member in join_ids else "element")
            reason = None
            if owner != "global":
                reason = "outside_project"
            elif kind == "join":
                if member not in join_ids and not any(join["id"] == member for join in global_graph.joins(member)) and RecordKey(owner, kind, member) not in archived:
                    reason = "missing"
            elif kind == "element":
                record = global_graph.get(member) or snapshot["elements"].get(member) or archived.get(RecordKey(owner, kind, member))
                if record is None:
                    reason = "missing"
                else:
                    elements[member] = record
            else:
                reason = "missing"
            if reason:
                unresolved.add(member)
                issue = {"from": {"owner": "global", "kind": "join" if source_join else "element", "id": source_join or identifier},
                         "field": ref["field"], "ref": member, "kind": kind, "reason": reason}
                if "owner" in ref:
                    issue["requested_owner"] = owner
                issues.append(issue)
        graph = {"elements": elements, "joins": joins, "unresolved": sorted(unresolved)}
        if issues:
            graph["unresolved_references"] = issues
        return result | {"status": "complete", "graph": graph}

    if operation == "inference.read":
        return read(arguments["id"])
    if operation == "inference.promote":
        elements = {key: record for key, record in arguments["graph"].get("elements", {}).items() if global_graph.get(key) is None}
        return global_graph.put({"elements": elements}, "promoted")
    if operation not in {"inference.contribute", "inference.commit"}:
        raise KnowledgeError("unknown_operation", "Unknown operation: " + operation)
    focal = arguments.get("focal")
    if focal is not None and completions(focal):
        retained = read(focal)
        if operation == "inference.commit" and retained["graph"] is not None:
            local_graph.put(retained["graph"], "archaeology")
        return {"elements": 0, "joins": 0, "reused": True, "inference": retained}
    graph = arguments["snapshot" if operation == "inference.commit" else "graph"]
    if focal is None and graph.get("joins"):
        raise ValueError("Global joins require an active focal Latent Expert assignment")
    contribution = dict(graph, elements={key: record for key, record in graph.get("elements", {}).items() if key == focal or not completions(key)})
    if operation == "inference.contribute":
        return global_graph.put(contribution, "archaeology")
    if focal not in contribution["elements"]:
        raise ValueError("Completing Latent Expert inference requires an authored focal Type record")
    completion = dict(contribution["elements"][focal], inference=graph)
    observation = {"id": digest([focal, "archaeology-complete", completion]), "element_id": focal,
                   "source": "archaeology-complete", "record": completion, "created": now()}
    result = global_graph.put(dict(copy.deepcopy(contribution), observations=[observation]), "archaeology")
    local_graph.put(contribution, "archaeology")
    return result | {"reused": False, "inference": read(focal)}


def translated_ownership(value, previous, selected):
    """Translate structured self references when explicitly creating a new owner."""
    value = copy.deepcopy(value)
    def visit(record):
        if isinstance(record, list):
            for child in record:
                visit(child)
        elif isinstance(record, dict):
            for participant in record.get("participants", []):
                if participant.get("owner") == previous:
                    participant["owner"] = selected
            for field, owner in record.get("reference_owners", {}).items():
                if owner == previous:
                    record["reference_owners"][field] = selected
            for child in record.values():
                visit(child)
    visit(value)
    return value
