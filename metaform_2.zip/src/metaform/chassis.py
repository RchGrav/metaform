"""The chassis's own recorded functional account, separate from project knowledge."""

import json
from importlib.resources import files


async def describe(app):
    from .registry import Registry

    record = json.loads((files("metaform") / "data" / "chassis.json").read_text(encoding="utf-8"))
    registry = Registry(app)
    record["capabilities"] = registry.reference()
    record["workflows"] = (
        await registry.call("workflow.list", internal=True)
        if "workflow.list" in registry.visible() else {"workflows": []}
    )
    return record
