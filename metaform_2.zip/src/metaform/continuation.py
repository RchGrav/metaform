"""A nonce names a stored workflow continuation, independent of its executor."""

from __future__ import annotations

import os
import json
import sqlite3
import secrets
import shlex
import shutil
import sys
from contextlib import closing
from pathlib import Path

from filelock import FileLock

from .util import now, read_json, write_json
from .locking import snapshot_lock, lock, snapshot_locked


def pending_assignment(app, run_id, request_id):
    run = app.load_run(run_id)
    if run.get("kind", "workflow") == "workflow" and run["status"] == "running":
        from .workflow import Engine

        if Engine(app).expired(run):
            raise ValueError("The assignment phase deadline has expired")
    job = (run.get("assignments") or {}).get(request_id)
    if job is None and (run.get("pending") or {}).get("request_id") == request_id:
        job = run["pending"]
    if run["status"] != "running" or request_id in run.get("receipts", {}) or not job or job["request_id"] != request_id:
        raise ValueError("The assignment is no longer pending")
    return present(job)


def launcher():
    """Reach this Metaform installation independently of an embedding caller."""
    archive = getattr(__loader__, "archive", None)
    if archive:
        return shlex.join([sys.executable, str(Path(archive).resolve())])
    package_root = str(Path(__file__).resolve().parent.parent)
    bootstrap = ("import sys;sys.path.insert(0," + repr(package_root)
                 + ");from metaform.cli import main;raise SystemExit(main())")
    return shlex.join([sys.executable, "-c", bootstrap])


def present(job):
    """Refresh installation-specific handoff text without reissuing a request."""
    if job.get("nonce"):
        return job | {"begin": launcher() + " begin " + job["nonce"]}
    return job


def marker(folder=None, home=None):
    """The binding of a folder or its nearest bound ancestor, read from the base db; None when unbound
    or when the record has had no activity for a day (SPEC sections 9 and 13)."""
    from .bindings import lookup

    return lookup(folder, home)


def recorded_assignment(record):
    """Read an index's target without initializing or recreating its project."""
    if not isinstance(record, dict) or not all(
        isinstance(record.get(key), str) and record[key]
        for key in ("project", "home", "module", "run_id", "request_id")
    ):
        return None
    database = Path(record["project"]) / ".metaform" / "state.sqlite3"
    if not database.is_file():
        return None
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='runs'").fetchone():
            return None
        row = db.execute("SELECT body FROM runs WHERE id=?", (record["run_id"],)).fetchone()
    if not row:
        return None
    run = json.loads(row[0])
    request_id = record["request_id"]
    job = (run.get("assignments") or {}).get(request_id) or run.get("pending") or {}
    if (run["status"] != "running" or request_id in run.get("receipts", {})
            or job.get("request_id") != request_id):
        return None
    return job


def workflow_nonce(app, workflow):
    """The nonce a workflow received when it was registered; None for a bundled definition."""
    record = app.graph.get("workflow:" + workflow + ":nonce") or app.global_graph.get("workflow:" + workflow + ":nonce")
    return (record or {}).get("entity_json_obj", {}).get("nonce")


def agent_nonce(seed, taken):
    """Eight characters hashed from the workflow nonce and a random input, unique among issued nonces."""
    import hashlib

    while True:
        salt = secrets.token_hex(8)
        nonce = hashlib.sha256((seed + salt).encode()).hexdigest()[:8]
        if not taken(nonce):
            return nonce, salt


def publish(app, job, module="workflow"):
    run = app.load_run(job["run_id"]) if job.get("run_id") else {}
    stack = run.get("stack") or []
    frame = stack[-1] if stack else {}
    workflow = (frame.get("workflow") or run.get("workflow")) if module == "workflow" else None
    frame_steps = ((frame.get("definition") or {}).get("steps")) if isinstance(frame.get("definition"), dict) else None
    steps = len(frame_steps if frame_steps is not None else app_definition_steps(app, workflow)) if workflow else 0
    delegated = steps > 1 and len(stack) > 1
    if (job.get("context") == "fresh" or delegated) and not job.get("workfolder"):
        from .workfolders import create

        folder = create(app, empty=True)
        job.update(workfolder=folder["path"], workfolder_id=folder["id"])
    directory = Path(app.config.get("assignment_home", app.home)) / "assignments"
    directory.mkdir(parents=True, exist_ok=True)
    with FileLock(directory / "index.lock"):
        nonce = job.get("nonce")
        salt = None
        registered = workflow_nonce(app, workflow) if workflow else None
        if not nonce:
            nonce, salt = agent_nonce(registered or job["run_id"], lambda candidate: (directory / (candidate + ".json")).exists())
        record = {
            "nonce": nonce,
            "project": str(app.project),
            "home": str(app.home),
            "module": module,
            "run_id": job["run_id"],
            "request_id": job["request_id"],
            "workflow": workflow,
            "workflow_nonce": registered,
            "salt": salt,
            "created": now(),
        }
        write_json(directory / (nonce + ".json"), record)
        if directory.parent != app.home:
            write_json(app.home / "assignments" / (nonce + ".json"), record)
    job["nonce"] = nonce
    job["begin"] = launcher() + " begin " + nonce
    return job


def app_definition_steps(app, workflow):
    from .workflow import Engine

    try:
        return Engine(app).definition(workflow).get("steps", [])
    except ValueError:
        return []


def begin(nonce, folder=None, home=None, project=None):
    from .app import App, project_path

    root = Path(home or os.environ.get("METAFORM_HOME", Path.home() / ".metaform"))
    selected = project_path(project, home) if project is not None else None
    if selected is not None:
        identity = read_json(selected / ".metaform" / "project.json", {})
        config = read_json(selected / ".metaform" / "config.json", {})
        if (identity.get("knowledge_mode") == "portable" or config.get("knowledge_mode") == "portable"
                or (selected / ".metaform" / "bundle.json").exists()):
            root = selected / ".metaform" / "home"
        else:
            root = Path(home or identity.get("service_home") or root)
    try:
        record = read_json(root / "assignments" / (str(nonce) + ".json"))
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise ValueError(f"Invalid workflow handoff record: {nonce}") from error
    if record is None:
        start = Path(folder or Path.cwd()).resolve()
        for parent in [start, *start.parents]:
            file = (
                parent / ".metaform" / "home" / "assignments" / (str(nonce) + ".json")
            )
            if file.is_file():
                try:
                    record = read_json(file)
                except (json.JSONDecodeError, UnicodeDecodeError) as error:
                    raise ValueError(f"Invalid workflow handoff record: {nonce}") from error
                break
    if not record:
        raise ValueError(f"Unknown workflow handoff: {nonce}")
    if not recorded_assignment(record):
        raise ValueError("The assignment is no longer pending")
    if selected is not None:
        if selected != Path(record["project"]).resolve():
            raise ValueError("The selected project conflicts with this bound assignment")
    app = App(record["project"], record["home"], binding=False)
    with snapshot_lock(app), lock(app, "run:" + record["run_id"]):
        job = pending_assignment(app, record["run_id"], record["request_id"])
        assigned_folder = job.get("workfolder") if job.get("context") == "fresh" else None
        target = Path(assigned_folder or folder or Path.cwd()).resolve()
        # Save the location before recording the binding so interrupted cleanup
        # can find every dispatch, including handoffs outside managed folders.
        app.event("continuation.begin", record | {"folder": str(target)}, record["run_id"])
        from . import bindings

        target.mkdir(parents=True, exist_ok=True)
        bindings.record(target, record)
        # The nonce arrives once. The harness that received it is this process's parent, and a server the same
        # harness spawns from another folder reads the nonce back through that link.
        bindings.agent(os.getpid(), os.getppid(), target, record["project"], nonce=str(nonce), home=record["home"])
        return job


@snapshot_locked
def retire(app, run, request_id=None):
    """Retire automatic dispatch lookup while preserving run receipts and events."""
    def matches(record):
        return (record.get("project") == str(app.project)
                and record.get("run_id") == run["id"]
                and (request_id is None or record.get("request_id") == request_id))

    from . import bindings

    bindings.clear_matching(matches, homes=[app.home])
    jobs = [run.get("pending"), *run.get("assignments", {}).values()]
    directories = {app.home / "assignments", Path(app.config.get("assignment_home", app.home)) / "assignments"}
    for directory in directories:
        if not directory.is_dir():
            continue
        with FileLock(directory / "index.lock"):
            for path in directory.glob("*.json"):
                if matches(read_json(path, {})):
                    path.unlink(missing_ok=True)
    request_ids = {request_id} if request_id else (
        set(run.get("receipts", {})) | {job["request_id"] for job in jobs if job}
    )
    from .history import safe_path

    for identifier in request_ids:
        if app.get("executing:" + identifier):
            continue
        if run["status"] == "running" and identifier not in run.get("receipts", {}):
            continue
        source = safe_path(app.home / "requests", identifier)
        recorded = read_json(source / "request.json", {})
        if recorded.get("run_id") != run["id"] or recorded.get("request_id") != identifier:
            continue
        destination = safe_path(app.root / "outputs" / "requests", identifier)
        shutil.copytree(source, destination, dirs_exist_ok=True, symlinks=True)
        shutil.rmtree(source)
        app.event("continuation.retired", {"request_id": identifier, "artifacts": str(destination)}, run["id"])


def current(app):
    from .workflow import Engine
    from .intake import Intake

    binding = app.binding
    if binding["module"] == "intake":
        return Intake(app).next(
            binding["run_id"], request_id=binding.get("request_id")
        )
    return Engine(app).next(binding["run_id"], binding.get("request_id"))


def begin_command(app, args, context):
    return begin(args["nonce"], args.get("folder"), app.home)
