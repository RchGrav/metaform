from metaform import rulebook


def get(app, args, context):
    return rulebook.get(app, args["rule_code"])


def put(app, args, context):
    return rulebook.put(app, args["rule"])


def prepare(app, args, context):
    return rulebook.prepare(app, args["rule_codes"], args.get("concise_only", False))
