from metaform.packaging import build as build_wheel


def build(app, args, context):
    return build_wheel(app, args.get("source"))


def ci(app, args, context):
    from metaform.ci import setup

    return setup(app, args)


def export(app, args, context):
    from metaform.portable import export

    return export(app, args.get("path") or app.root / "exports" / "metaform")


def import_bundle(app, args, context):
    from metaform.portable import import_bundle
    from metaform.app import App
    from metaform.continuation import publish
    from metaform.util import write_json

    result = import_bundle(args["path"], args.get("destination"))
    from pathlib import Path

    imported = App(result["path"], Path(result["path"]) / ".metaform" / "home")
    imported.config["assignment_home"] = str(app.home)
    write_json(imported.root / "config.json", imported.config)
    handoffs = []
    with imported.db() as db:
        runs = [r[0] for r in db.execute("SELECT id FROM runs WHERE status='running'")]
    for identifier in runs:
        run = imported.load_run(identifier)
        job = run.get("pending")
        if job:
            job.pop("nonce", None)
            publish(
                imported,
                job,
                job.get("module", "intake" if run.get("stage") else "workflow"),
            )
            imported.save_run(run)
            handoffs.append(
                {"run_id": identifier, "nonce": job["nonce"], "begin": job["begin"]}
            )
    return result | {"handoffs": handoffs}


def sample(app, args, context):
    """Create a separate portable project from the retained historical MGM graphs."""
    import json
    import tempfile
    from importlib.resources import files
    from pathlib import Path
    from metaform.app import App
    from metaform.util import write_json

    destination = Path(args["destination"]).expanduser().resolve() if args.get("destination") else Path(
        tempfile.mkdtemp(prefix="metaform-mgm-sample-"))
    if (destination / ".metaform").exists():
        raise ValueError("The destination already contains a Metaform project. Choose a new directory.")
    write_json(destination / ".metaform/config.json", {"knowledge_mode": "portable", "auto_build": False})
    loaded = App(destination, destination / ".metaform/home", binding=False)
    sources = files("metaform") / "data" / "samples" / "mgm"
    for filename, scope in [("native.json", "native"), ("latent.json", "archaeology")]:
        graph = json.loads((sources / filename).read_text(encoding="utf-8"))
        loaded.graph.put(graph, scope)
        if scope == "native":
            loaded.set("native_context", {key: value for key, value in graph.items() if key not in ("elements", "joins")})
    loaded.graph.merge_perspectives()
    return {"project": str(destination), "sample": "MGM historical v1 Native/Latent intake",
            "view": "History / Compare", "browse": ["metaform", "--project", str(destination), "browse"],
            "stats": loaded.graph.stats(), "provenance": json.loads((sources / "manifest.json").read_text(encoding="utf-8"))}


def sample_bootstrap(argv, selector=None):
    """Load the sample without initializing an unrelated invocation directory."""
    import argparse

    parser = argparse.ArgumentParser(prog="metaform package sample")
    parser.add_argument("--destination")
    return sample(None, vars(parser.parse_args(argv[2:])), None)
