from metaform import history


def checkpoint(app, args, context):
    return history.checkpoint(
        app, args.get("name", ""), args.get("parent"), args.get("provenance")
    )


def list_versions(app, args, context):
    return history.initialize(app)


def diff(app, args, context):
    return history.diff(app, args["version"])


def extract(app, args, context):
    return history.reconstruct(app, args["version"], args["destination"])
