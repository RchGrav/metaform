from metaform import prompts
from metaform.workflow import Engine, import_workflow


def put(app, args, context):
    return prompts.put(app, args["prompt"])


def prepare(app, args, context):
    return prompts.prepare(
        app, args["id"], args.get("inputs"), args.get("focal"), args.get("depth")
    )


def test(app, args, context):
    prepared = args.get("prepared") or prepare(app, args, context)
    return prompts.record_test(app, prepared, args["answer"], args.get("note", ""))


def run(app, args, context):
    identifier = "prompt-test:" + app.identifier()
    prompt = prompts.get(app, args["id"])
    import_workflow(
        app,
        {
            "id": identifier,
            "steps": [
                {
                    "id": "test",
                    "prompt_ref": args["id"],
                    "schema": prompt.get("schema"),
                    "focal": args.get("focal"),
                    "depth": args.get("depth"),
                    "inputs": {
                        k: {"literal": v} for k, v in args.get("inputs", {}).items()
                    },
                }
            ],
        },
    )
    return Engine(app).start(identifier, args.get("inputs"), exclusive=False)
