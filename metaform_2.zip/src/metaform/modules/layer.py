"""Manifest entry points for knowledge layers."""
from metaform import layers
from metaform.workflow import Engine


def list_layers(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, 'layer.list', args)


def inspect(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, 'layer.inspect', args)


def select(app, args, context):
    return layers.select_layer(app, args['layer'], args.get('model'))


def create(app, args, context):
    return layers.create_layer(app, args['request'], args.get('target'), args.get('model'))


def regenerate(app, args, context):
    return layers.regenerate_layer(app, args['layer'], args.get('model'), args.get('target', args.get('region')))


def remove(app, args, context):
    return layers.remove_layer(app, args.get('layer', args.get('target')), args.get('model'))


def publish(app, args, context):
    return layers.publish_generation(app, args['run_id'], args['contributions'])


def guide(app, state, plan=None):
    model = state['model']
    if not model:
        return None
    practices = next((layer for layer in state['layers']
                      if layer['model'] == model and layer['name'] == 'Best Practices' and layer['state'] == 'complete'), None)
    missing = object()
    if practices and app.get('layer-selection:' + model['model'], missing) is missing:
        return {'status': 'needs_layer_selection', 'next': {'command': 'layer.select', 'arguments': {
            'model': model, 'layer': {'owner': practices['owner'], 'kind': 'layer', 'id': practices['id']}}},
                'guidance': "Select the completed Best Practices layer as this model's default knowledge layer."}
    return None
