#!/usr/bin/env python3
"""imagegen: image generation and editing for any agent harness.

Single file. Standard library only. The name is generic on purpose: the CLI/MCP surface, presets, and
idea pool below are not tied to one backend. Today there is exactly one backend - OpenAI's gpt-image-2,
driven through the Codex CLI, which works for anyone with a paid ChatGPT subscription and no
OPENAI_API_KEY - but nothing in the public surface assumes that stays true. A second backend would plug
in beside `probe_codex`/`run_codex_image` without renaming anything a caller depends on.

    imagegen.py status                     probe backend presence and readiness
    imagegen.py guide [SECTION]            agent-facing capability guide
    imagegen.py presets [NAME]             asset-type presets and their prompt scaffolds
    imagegen.py ideas [QUERY]              vocabulary/genre idea pool for prompt-writing
    imagegen.py generate PROMPT -o OUT ... make a new image
    imagegen.py edit IMAGE PROMPT -o OUT   transform an existing image
    imagegen.py mcp                        serve the same operations over MCP stdio

Lineage: the probe and the codex exec submission path come from
tempo/image_generation.py (probe_codex_capability, CodexImagegenAdapter).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

__version__ = "0.1.0"

MINIMUM_CODEX_VERSION = (0, 142, 0)
MINIMUM_NODE_VERSION = (18, 18, 0)
MINIMUM_IMAGE_ATTACHMENT_VERSION = (0, 144, 0)
IMAGE_FLAG_PATTERN = re.compile(r"(^|\s)(-i,\s*)?--image(\s|=|<|$)")
SIZES = ("auto", "1024x1024", "1536x1024", "1024x1536", "2048x2048", "2048x1152",
         "1152x2048", "3840x2160", "2160x3840")
QUALITIES = ("auto", "low", "medium", "high")
INPUT_ROLES = ("edit-target", "reference", "style", "insert")
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp"}


class ImageToolError(Exception):
    """Any failure the caller should see as a message, not a traceback."""


# ---------------------------------------------------------------------------
# Codex presence and readiness
# ---------------------------------------------------------------------------

def codex_home() -> Path:
    return Path(os.environ.get("CODEX_HOME") or (Path.home() / ".codex")).expanduser()


@dataclass(frozen=True)
class CodexStatus:
    installed: bool
    path: str | None
    node_version: str | None
    node_version_supported: bool
    version: str | None
    version_supported: bool
    authenticated: bool
    login_output: str
    exec_available: bool
    image_option_available: bool
    imagegen_skill_available: bool
    generated_images_dir: str
    problems: tuple[str, ...]

    @property
    def ready(self) -> bool:
        return not self.problems

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["ready"] = self.ready
        data["problems"] = list(self.problems)
        return data


def _version_tuple(text: str) -> tuple[int, ...] | None:
    match = re.search(r"(?<!\d)(\d+)\.(\d+)\.(\d+)(?!\d)", text)
    return tuple(int(p) for p in match.groups()) if match else None


def _probe(command: Sequence[str], timeout: int, runner: Callable[..., Any] = subprocess.run) -> tuple[bool, str]:
    try:
        result = runner(list(command), stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return False, ""
    return result.returncode == 0, str(result.stdout or "")


def probe_codex(timeout: int = 10, runner: Callable[..., Any] = subprocess.run) -> CodexStatus:
    """Six checks, converted to Python from the reference buildStatusReport(): nodeOk, codexOk,
    loginOk, fullAutoOk, imageAttachmentOk, imagegenOk. ready is true only when all six pass.

    1. nodeOk           - `node --version` >= MINIMUM_NODE_VERSION (Codex is an npm package; it needs
                           a real Node runtime to exist at all).
    2. codexOk          - `codex --version` >= MINIMUM_CODEX_VERSION, exit 0.
    3. loginOk          - `codex login status` output contains "logged in" (case-insensitive);
                           only checked if codex is available.
    4. fullAutoOk       - `codex exec --full-auto --help` exits 0.
    5. imageAttachmentOk - `codex exec --help` output matches IMAGE_FLAG_PATTERN (`--image`/`-i`) and
                           the codex version is >= MINIMUM_IMAGE_ATTACHMENT_VERSION (0.144+).
    6. imagegenOk       - $CODEX_HOME/skills/.system/imagegen/SKILL.md exists on disk (falls back to
                           ~/.codex when CODEX_HOME is unset, via codex_home()).
    """
    home = codex_home()
    resolved = shutil.which("codex")
    skill = home / "skills" / ".system" / "imagegen" / "SKILL.md"
    problems: list[str] = []

    # 1. nodeOk
    node_resolved = shutil.which("node")
    node_version = None
    node_ok = False
    if not node_resolved:
        problems.append("node is not on PATH. Codex requires Node.js "
                        f"{'.'.join(map(str, MINIMUM_NODE_VERSION))}+.")
    else:
        ok, out = _probe([node_resolved, "--version"], timeout, runner)
        if ok:
            node_version = out.strip() or None
            parsed_node = _version_tuple(out)
            node_ok = parsed_node is not None and parsed_node >= MINIMUM_NODE_VERSION
        if not node_ok:
            problems.append(f"node version {node_version or 'unknown'} is below "
                            f"{'.'.join(map(str, MINIMUM_NODE_VERSION))}. Install a newer Node.js.")

    version = None
    version_ok = auth = exec_ok = image_opt = False
    login_out = ""
    if not resolved:
        problems.append("codex is not on PATH. Install: npm install -g @openai/codex")
    else:
        # 2. codexOk
        parsed = None
        ok, out = _probe([resolved, "--version"], timeout, runner)
        if ok:
            version = out.strip() or None
            parsed = _version_tuple(out)
            version_ok = parsed is not None and parsed >= MINIMUM_CODEX_VERSION
        if not version_ok:
            problems.append(f"codex version {version or 'unknown'} is below "
                            f"{'.'.join(map(str, MINIMUM_CODEX_VERSION))}. Run: npm install -g @openai/codex@latest")
        # 3. loginOk
        ok, login_out = _probe([resolved, "login", "status"], timeout, runner)
        auth = bool(ok and re.search(r"(?<!not )\blogged in\b", login_out.casefold()))
        if not auth:
            problems.append("codex is not logged in. Run: codex login  (a paid ChatGPT plan is required)")
        # 4. fullAutoOk
        exec_ok, _ = _probe([resolved, "exec", "--full-auto", "--help"], timeout, runner)
        if not exec_ok:
            problems.append("codex exec --full-auto is unavailable in this build")
        # 5. imageAttachmentOk - a separate probe of `codex exec --help`, gated on 0.144+
        _, exec_help_out = _probe([resolved, "exec", "--help"], timeout, runner)
        has_image_flag = bool(IMAGE_FLAG_PATTERN.search(exec_help_out))
        image_version_ok = parsed is not None and parsed >= MINIMUM_IMAGE_ATTACHMENT_VERSION
        image_opt = has_image_flag and image_version_ok
        if not image_opt:
            problems.append("codex exec lacks --image support; requires Codex "
                            f"{'.'.join(map(str, MINIMUM_IMAGE_ATTACHMENT_VERSION))}+. "
                            "Run: npm install -g @openai/codex@latest")
    # 6. imagegenOk
    if not skill.is_file():
        problems.append(f"imagegen skill missing at {skill}; upgrade codex or set CODEX_HOME")
    return CodexStatus(
        installed=bool(resolved),
        path=str(Path(resolved).resolve()) if resolved else None,
        node_version=node_version,
        node_version_supported=node_ok,
        version=version,
        version_supported=version_ok,
        authenticated=auth,
        login_output=login_out.strip(),
        exec_available=exec_ok,
        image_option_available=image_opt,
        imagegen_skill_available=skill.is_file(),
        generated_images_dir=str(home / "generated_images"),
        problems=tuple(problems),
    )


_STATUS_CACHE: dict[str, CodexStatus] = {}


def require_codex(refresh: bool = False) -> CodexStatus:
    """Probe once per process; raise with every remediation step if anything is missing."""
    if refresh or "status" not in _STATUS_CACHE:
        _STATUS_CACHE["status"] = probe_codex()
    status = _STATUS_CACHE["status"]
    if not status.ready:
        raise ImageToolError("Codex is not ready for image generation:\n  - " + "\n  - ".join(status.problems))
    return status


# ---------------------------------------------------------------------------
# Job model and prompt construction
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ImageInput:
    path: Path
    role: str  # one of INPUT_ROLES


@dataclass
class ImageJob:
    mode: str                      # "generate" | "edit"
    prompt: str
    output: Path
    preset: str | None = None
    inputs: list[ImageInput] = field(default_factory=list)
    size: str | None = None
    quality: str | None = None
    transparent: bool = False
    text: str | None = None
    style: str | None = None
    constraints: list[str] = field(default_factory=list)
    avoid: list[str] = field(default_factory=list)
    fill: dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        if self.mode not in ("generate", "edit"):
            raise ImageToolError("mode must be generate or edit")
        if not self.prompt.strip():
            raise ImageToolError("prompt must not be empty")
        if self.size and self.size != "auto" and not valid_size(self.size):
            raise ImageToolError(f"size {self.size!r} violates gpt-image-2 rules: edges multiples of 16, "
                                 "max edge 3840, ratio <= 3:1, 655,360..8,294,400 total pixels")
        if self.quality and self.quality not in QUALITIES:
            raise ImageToolError(f"quality must be one of {', '.join(QUALITIES)}")
        if self.preset and self.preset not in PRESETS:
            raise ImageToolError(f"unknown preset {self.preset!r}; run `presets` to list them")
        for item in self.inputs:
            if item.role not in INPUT_ROLES:
                raise ImageToolError(f"input role must be one of {', '.join(INPUT_ROLES)}")
            if not item.path.is_file():
                raise ImageToolError(f"input image does not exist: {item.path}")
            if item.path.resolve() == self.output.resolve():
                raise ImageToolError("output must differ from every input image")
        if self.mode == "edit" and not any(i.role == "edit-target" for i in self.inputs):
            raise ImageToolError("edit needs an edit-target image")
        if self.output.suffix.lower() not in IMAGE_SUFFIXES:
            raise ImageToolError("output must end in .png, .jpg, .jpeg, or .webp")
        if self.transparent and self.output.suffix.lower() not in {".png", ".webp"}:
            raise ImageToolError("transparent output must be .png or .webp")


def valid_size(size: str) -> bool:
    match = re.fullmatch(r"(\d+)x(\d+)", size)
    if not match:
        return False
    w, h = int(match.group(1)), int(match.group(2))
    long_edge, short_edge = max(w, h), min(w, h)
    return (w % 16 == 0 and h % 16 == 0 and long_edge <= 3840 and short_edge > 0
            and long_edge / short_edge <= 3 and 655_360 <= w * h <= 8_294_400)


def _expand(line: str, fill: dict[str, str]) -> str | None:
    """Fill {placeholders}; drop the line if any placeholder has no value."""
    try:
        return line.format(**fill)
    except (KeyError, IndexError):
        return None


def _dedupe(items: list[str]) -> list[str]:
    seen: set[str] = set()
    return [i for i in items if not (i.casefold() in seen or seen.add(i.casefold()))]


def build_prompt(job: ImageJob) -> str:
    """Render the structured spec Codex's imagegen skill expects, prefixed with $imagegen (tempo's template)."""
    preset = PRESETS.get(job.preset or "", {})
    fill = {"prompt": job.prompt.strip(), **job.fill}
    lines = ["$imagegen"]
    if job.mode == "edit":
        lines.append("Edit the attached image. Use the built-in image_gen tool in edit mode.")
    else:
        lines.append("Generate a new image with the built-in image_gen tool.")
    if job.inputs:
        lines.append("Attached images, in order:")
        for i, item in enumerate(job.inputs, 1):
            lines.append(f"  Image {i} ({item.path.name}): {item.role}")
    lines.append("")
    if preset.get("use_case"):
        lines.append(f"Use case: {preset['use_case']}")
    if preset.get("asset_type"):
        lines.append(f"Asset type: {preset['asset_type']}")
    lines.append(f"Primary request: {job.prompt.strip()}")
    for line in preset.get("scaffold", []):
        expanded = _expand(line, fill)
        if expanded and not expanded.startswith("Use case:"):
            lines.append(expanded)
    if job.style:
        lines.append(f"Style/medium: {job.style}")
    if job.text is not None:
        lines.append(f'Text (verbatim): "{job.text}"')
    constraints = _dedupe([_expand(l, fill) or l for l in preset.get("invariants", [])] + job.constraints)
    if constraints:
        lines.append("Constraints: " + "; ".join(constraints))
    avoid = [_expand(l, fill) or l for l in preset.get("avoid", [])] + job.avoid
    has_text = job.text is not None or any(l.startswith("Text (verbatim)") for l in lines)
    if not has_text and not any("text" in a for a in avoid):
        avoid.append("no text unless explicitly requested")
    avoid = _dedupe(avoid)
    if avoid:
        lines.append("Avoid: " + "; ".join(avoid))
    size = job.size or preset.get("default_size")
    quality = job.quality or preset.get("default_quality")
    if size:
        lines.append(f"Requested size: {size}")
    if quality:
        lines.append(f"Requested quality: {quality}")
    if job.transparent:
        lines.append("Output: a real RGBA PNG with a fully transparent background and clean edges; no backdrop, "
                     "no shadow, no floor plane")
    lines.append("")
    lines.append(
        f"Copy the final selected image to the absolute path \"{job.output}\" (create parent directories, "
        f"overwrite if present). Do whatever finishing the request above asks for before saving. Produce exactly "
        f"one finished image unless the request explicitly asks for several; save extras beside it. Do not return "
        f"only analysis, a review, or a prompt. Finish by printing one line per saved file: "
        f"SAVED: <absolute path>, with SAVED: {job.output} last."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Running Codex
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ImageResult:
    output_path: str
    prompt: str
    mode: str
    preset: str | None
    transparent: bool
    elapsed_seconds: float
    codex_output_tail: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _image_file_state(path: Path) -> tuple[int, ...] | None:
    if not path.is_file():
        return None
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def run_codex_image(status: CodexStatus, prompt: str, images: Sequence[Path], output: Path, *,
                    timeout: int = 900, runner: Callable[..., Any] = subprocess.run) -> tuple[Path, str]:
    """Submit through `codex exec` and require a new or changed requested destination."""
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [status.path or "codex", "--disable", "hooks", "exec", "-s", "workspace-write",
               "--skip-git-repo-check", prompt]
    for image in images:
        command += ["--image", str(image)]
    before = _image_file_state(output)
    try:
        result = runner(command, cwd=output.parent, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise ImageToolError(f"Codex image generation timed out after {timeout} seconds") from exc
    except OSError as exc:
        raise ImageToolError(f"Codex could not start: {exc}") from exc
    combined = str(result.stdout or "")
    log = Path(tempfile.gettempdir()) / "codex-imagegen-error.log"
    if result.returncode != 0:
        log.write_text(combined, encoding="utf-8")
        raise ImageToolError(f"Codex exited {result.returncode}. Output written to {log}")

    after = _image_file_state(output)
    if after is None or after == before:
        log.write_text(combined, encoding="utf-8")
        raise ImageToolError(f"Codex finished without an image file. Output written to {log}")
    return output, combined


# ---------------------------------------------------------------------------
# The operation
# ---------------------------------------------------------------------------

def run_job(job: ImageJob, *, timeout: int = 900, dry_run: bool = False, refresh: bool = False) -> ImageResult | str:
    """Validate, build the prompt, run Codex, post-process transparency. dry_run returns the prompt."""
    job.output = job.output.expanduser().resolve()
    if job.preset and PRESETS.get(job.preset, {}).get("transparent") and job.output.suffix.lower() in {".png", ".webp"}:
        job.transparent = True
    job.validate()
    prompt = build_prompt(job)
    if dry_run:
        return prompt
    status = require_codex(refresh)
    started = time.time()
    images = [i.path.resolve() for i in job.inputs]
    _, combined = run_codex_image(status, prompt, images, job.output, timeout=timeout)
    return ImageResult(
        output_path=str(job.output), prompt=prompt, mode=job.mode, preset=job.preset,
        transparent=job.transparent, elapsed_seconds=round(time.time() - started, 1),
        codex_output_tail=combined[-1500:],
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_inputs(args: argparse.Namespace, target: str | None) -> list[ImageInput]:
    inputs: list[ImageInput] = []
    if target:
        inputs.append(ImageInput(Path(target).expanduser(), "edit-target"))
    for flag, role in (("ref", "reference"), ("style_ref", "style"), ("insert", "insert")):
        for path in getattr(args, flag, None) or []:
            inputs.append(ImageInput(Path(path).expanduser(), role))
    return inputs


def _job_from_args(args: argparse.Namespace, mode: str) -> ImageJob:
    fill = {}
    for item in args.set or []:
        if "=" not in item:
            raise ImageToolError(f"--set expects key=value, got {item!r}")
        key, value = item.split("=", 1)
        fill[key.strip()] = value.strip()
    return ImageJob(
        mode=mode, prompt=args.prompt, output=Path(args.out), preset=args.preset,
        inputs=_parse_inputs(args, getattr(args, "image", None)),
        size=args.size, quality=args.quality, transparent=bool(args.transparent),
        text=args.text, style=args.style,
        constraints=args.keep or [], avoid=args.avoid or [], fill=fill,
    )


def _add_job_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("prompt", help="what the finished image should show")
    parser.add_argument("-o", "--out", required=True, help="output path (.png/.jpg/.webp)")
    parser.add_argument("-p", "--preset", choices=sorted(PRESETS), help="asset-type preset; see `presets`")
    parser.add_argument("--size", help="auto or WIDTHxHEIGHT, e.g. 1536x1024")
    parser.add_argument("--quality", choices=QUALITIES)
    parser.add_argument("--style", help="style/medium line, e.g. 'flat vector illustration'")
    parser.add_argument("--text", help="exact text to render verbatim in the image")
    parser.add_argument("--keep", action="append", metavar="RULE", help="invariant to preserve (repeatable)")
    parser.add_argument("--avoid", action="append", metavar="RULE", help="negative constraint (repeatable)")
    parser.add_argument("--ref", action="append", metavar="IMAGE", help="reference image for style/composition")
    parser.add_argument("--style-ref", action="append", metavar="IMAGE", help="style-only reference image")
    parser.add_argument("--insert", action="append", metavar="IMAGE", help="image to composite into the result")
    parser.add_argument("--transparent", action="store_true", help="ask for a transparent-background RGBA PNG")
    parser.add_argument("--set", action="append", metavar="KEY=VALUE", help="fill a preset placeholder")
    parser.add_argument("--timeout", type=int, default=900)
    parser.add_argument("--dry-run", action="store_true", help="print the prompt; do not call Codex")
    parser.add_argument("--refresh", action="store_true", help="re-probe Codex instead of using the cached probe")
    parser.add_argument("--json", action="store_true")


def _cmd_status(args: argparse.Namespace) -> int:
    status = probe_codex()
    _STATUS_CACHE["status"] = status
    if args.json:
        print(json.dumps(status.as_dict(), indent=2))
    else:
        print(f"node:         {status.node_version or '-'}  (supported: {status.node_version_supported})")
        print(f"codex:        {status.path or 'not found'}")
        print(f"version:      {status.version or '-'}  (supported: {status.version_supported})")
        print(f"login:        {status.login_output or '-'}")
        print(f"exec --image: {status.image_option_available}")
        print(f"imagegen:     {status.imagegen_skill_available}")
        print(f"ready:        {status.ready}")
        for problem in status.problems:
            print(f"  ! {problem}")
    return 0 if status.ready else 1


def _cmd_guide(args: argparse.Namespace) -> int:
    print(guide_text(args.section))
    return 0


def _cmd_ideas(args: argparse.Namespace) -> int:
    fill: dict[str, str] = {}
    for item in args.set or []:
        if "=" not in item:
            raise ImageToolError(f"--set expects key=value, got {item!r}")
        key, value = item.split("=", 1)
        fill[key.strip()] = value.strip()
    result = ideas_lookup(args.query, fill=fill or None)
    if args.json or args.query:
        print(json.dumps(result, indent=2))
        return 0
    print("A sample of the range, not a menu: describe whatever the request needs, in whatever")
    print("combination or invention that takes. These exist to widen what you consider asking for -")
    print("write the actual prompt expressively and in concrete detail; nothing here is a stopping point.")
    print("(Scripting instead of an LLM writing the prompt? `ideas <slug> --set key=value` renders that")
    print("genre's template deterministically - see render_idea_template.)\n")
    print("Vocabulary categories (run `ideas <category>` for the term list):")
    for name, count in result["vocabulary_categories"].items():
        print(f"  {name:<28} {count} terms")
    print("\nGenres - proof of what one prompt can produce whole, not a checklist to pick from")
    print("(run `ideas <slug>` for the ask/template):")
    width = max(len(n) for n in result["genres"])
    for name, ask in result["genres"].items():
        print(f"  {name:<{width}}  {ask}")
    return 0


def _cmd_presets(args: argparse.Namespace) -> int:
    if args.name:
        preset = PRESETS.get(args.name)
        if preset is None:
            raise ImageToolError(f"unknown preset {args.name!r}")
        print(json.dumps({args.name: preset}, indent=2))
        return 0
    if args.json:
        print(json.dumps(PRESETS, indent=2))
        return 0
    width = max(len(n) for n in PRESETS)
    for name, preset in PRESETS.items():
        flags = ("edit" if preset["mode"] == "edit" else "gen") + (" alpha" if preset.get("transparent") else "")
        print(f"{name:<{width}}  {flags:<10} {preset.get('notes', '')}")
    return 0


def _cmd_job(args: argparse.Namespace, mode: str) -> int:
    job = _job_from_args(args, mode)
    result = run_job(job, timeout=args.timeout, dry_run=args.dry_run, refresh=args.refresh)
    if isinstance(result, str):
        print(result)
        return 0
    if args.json:
        print(json.dumps(result.as_dict(), indent=2))
    else:
        print(f"saved {result.output_path} ({result.elapsed_seconds}s)")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="imagegen", description=__doc__.split("\n\n")[0],
        epilog="Run `guide` first if you are an agent: it explains every capability and how to prompt it.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    status = sub.add_parser("status", help="probe Codex presence, version, and login (via the codex executable)")
    status.add_argument("--json", action="store_true")
    status.set_defaults(func=_cmd_status)

    guide = sub.add_parser("guide", help="agent-facing guide to the image generation/editing surface")
    guide.add_argument("section", nargs="?", help="print one section by heading keyword")
    guide.set_defaults(func=_cmd_guide)

    presets = sub.add_parser("presets", help="list asset-type presets and their prompt scaffolds")
    presets.add_argument("name", nargs="?")
    presets.add_argument("--json", action="store_true")
    presets.set_defaults(func=_cmd_presets)

    ideas = sub.add_parser("ideas", help="browse the vocabulary/genre idea pool for prompt-writing")
    ideas.add_argument("query", nargs="?", help="a vocabulary category, a genre slug, or a free-text "
                       "keyword; omit to see the index")
    ideas.add_argument("--set", action="append", metavar="KEY=VALUE", help="fill a {placeholder} in one "
                       "genre's template (repeatable); requires query to be an exact genre slug. For "
                       "scripted/automated composition without an LLM in the loop - not required to use "
                       "IDEAS as guidance.")
    ideas.add_argument("--json", action="store_true")
    ideas.set_defaults(func=_cmd_ideas)

    generate = sub.add_parser("generate", help="create a new image from a prompt")
    _add_job_arguments(generate)
    generate.set_defaults(func=lambda a: _cmd_job(a, "generate"))

    edit = sub.add_parser("edit", help="transform an existing image while preserving invariants")
    edit.add_argument("image", help="the image to edit")
    _add_job_arguments(edit)
    edit.set_defaults(func=lambda a: _cmd_job(a, "edit"))

    mcp = sub.add_parser("mcp", help="serve these operations as an MCP server over stdio")
    mcp.set_defaults(func=lambda a: serve_mcp())
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except ImageToolError as exc:
        sys.stderr.write(f"error: {exc}\n")
        return 2


# ---------------------------------------------------------------------------
# MCP server (stdio, newline-delimited JSON-RPC 2.0, no dependencies)
# ---------------------------------------------------------------------------

_JOB_SCHEMA_PROPS: dict[str, Any] = {
    "prompt": {"type": "string", "description": "What the finished image should show. Be concrete: subject, "
               "scene, composition, lighting, materials. Quote any text verbatim in `text`."},
    "output": {"type": "string", "description": "Absolute output path ending in .png, .jpg, or .webp."},
    "preset": {"type": "string", "enum": [], "description": "Asset-type preset from image_presets."},
    "size": {"type": "string", "description": "auto or WIDTHxHEIGHT (multiples of 16, max edge 3840, ratio <= 3:1)."},
    "quality": {"type": "string", "enum": list(QUALITIES)},
    "style": {"type": "string", "description": "Style/medium line, e.g. 'clean product photography'."},
    "text": {"type": "string", "description": "Exact text to render in the image, verbatim."},
    "keep": {"type": "array", "items": {"type": "string"}, "description": "Invariants to preserve."},
    "avoid": {"type": "array", "items": {"type": "string"}, "description": "Negative constraints."},
    "reference_images": {"type": "array", "items": {"type": "string"},
                         "description": "Paths used only for style/composition/subject guidance."},
    "insert_images": {"type": "array", "items": {"type": "string"},
                      "description": "Paths of images to composite into the result."},
    "transparent": {"type": "boolean", "description": "Ask for a transparent-background RGBA PNG."},
    "fill": {"type": "object", "additionalProperties": {"type": "string"},
             "description": "Values for {placeholders} in the preset scaffold."},
    "dry_run": {"type": "boolean", "description": "Return the prompt that would be sent instead of running Codex."},
    "timeout": {"type": "integer"},
}


def _job_from_payload(payload: dict[str, Any], mode: str) -> ImageJob:
    inputs: list[ImageInput] = []
    if mode == "edit":
        if not payload.get("image"):
            raise ImageToolError("image_edit requires `image`")
        inputs.append(ImageInput(Path(str(payload["image"])).expanduser(), "edit-target"))
    for key, role in (("reference_images", "reference"), ("insert_images", "insert")):
        for path in payload.get(key) or []:
            inputs.append(ImageInput(Path(str(path)).expanduser(), role))
    return ImageJob(
        mode=mode, prompt=str(payload.get("prompt", "")), output=Path(str(payload.get("output", ""))),
        preset=payload.get("preset") or None, inputs=inputs, size=payload.get("size"),
        quality=payload.get("quality"), transparent=bool(payload.get("transparent")),
        text=payload.get("text"), style=payload.get("style"), constraints=list(payload.get("keep") or []),
        avoid=list(payload.get("avoid") or []), fill=dict(payload.get("fill") or {}),
    )


def _tool_job(payload: dict[str, Any], mode: str) -> dict[str, Any]:
    job = _job_from_payload(payload, mode)
    result = run_job(job, timeout=int(payload.get("timeout") or 900), dry_run=bool(payload.get("dry_run")))
    if isinstance(result, str):
        return {"dry_run": True, "prompt": result}
    return result.as_dict()


def mcp_tools() -> list[dict[str, Any]]:
    props = json.loads(json.dumps(_JOB_SCHEMA_PROPS))
    props["preset"]["enum"] = sorted(PRESETS)
    edit_props = {"image": {"type": "string", "description": "Path of the image to edit (the edit target)."}, **props}
    return [
        {"name": "image_status", "description": "Check whether Codex is installed, current, and logged in - "
         "all via the codex executable. Call this before the first generation; it lists remediation steps.",
         "inputSchema": {"type": "object", "properties": {"refresh": {"type": "boolean"}}}},
        {"name": "image_guide", "description": "The full agent-facing guide to what OpenAI's image tooling can do "
         "(generate, edit, inpaint, remove/replace objects, relight, composite, style transfer, text replacement, "
         "transparent cutouts) and how to prompt each in detail. Read it once before designing image work.",
         "inputSchema": {"type": "object", "properties": {"section": {"type": "string",
                         "description": "Optional heading keyword to return one section."}}}},
        {"name": "image_presets", "description": "List asset-type presets (ui-element, logo-transparent, hero, "
         "sprite, background-remove, ...) with their prompt scaffolds, placeholders, and defaults.",
         "inputSchema": {"type": "object", "properties": {"name": {"type": "string"}}}},
        {"name": "image_ideas", "description": "Browse a sample of what one gpt-image-2 prompt can produce "
         "whole - not a menu to pick from, but proof of range: full compositions (character turnaround sheets, "
         "exploded diagrams, trading cards, seamless tileable patterns, an isometric diorama boxed in glass, "
         "...) built from a description, not limited to cropping or color-grading an existing photo. Also a "
         "vocabulary sample (camera/optics, lighting, film look, render/illustration style, materials, "
         "composition, color) to stock a description with, not a fixed palette. If a request needs something "
         "none of this names, describe it directly anyway - the system is as expressive as the words you use. "
         "As an LLM caller, treat a genre's `template` as a minimal skeleton, not a form to fill in and stop; "
         "add whatever material, mood, exact wording, and framing detail the actual request calls for. The "
         "`fill` argument is for the other kind of caller - scripted/automated composition with no LLM in the "
         "loop: pass it with a `query` naming an exact genre slug to get that template rendered "
         "deterministically, and skip it entirely when exploring ideas for a prompt you are about to write "
         "yourself. GUIDE and PRESETS still say how to phrase it to Codex. Call with no query for the index, a "
         "category/genre name for that entry in full, or free text to search across both.",
         "inputSchema": {"type": "object", "properties": {
             "query": {"type": "string", "description": "A vocabulary category, a genre slug, or a free-text "
                       "keyword; omit for the index."},
             "fill": {"type": "object", "additionalProperties": {"type": "string"}, "description": "Values for "
                     "{placeholders} in one genre's template - scripted/automated use only. Requires `query` "
                     "to name that exact genre slug."},
         }}},
        {"name": "image_generate", "description": "Create a new image from a prompt (optionally guided by "
         "reference images) and save it to `output`. Use `transparent` for alpha cutouts.",
         "inputSchema": {"type": "object", "properties": props, "required": ["prompt", "output"]}},
        {"name": "image_edit", "description": "Transform an existing image (inpaint, remove or replace objects, "
         "change background or lighting, restyle, replace text, composite inserts) while preserving `keep` "
         "invariants. Saves to `output`, never over the input.",
         "inputSchema": {"type": "object", "properties": edit_props, "required": ["image", "prompt", "output"]}},
    ]


def call_tool(name: str, payload: dict[str, Any]) -> Any:
    if name == "image_status":
        status = probe_codex()
        _STATUS_CACHE["status"] = status
        return status.as_dict()
    if name == "image_guide":
        return guide_text(payload.get("section"))
    if name == "image_presets":
        if payload.get("name"):
            preset = PRESETS.get(str(payload["name"]))
            if preset is None:
                raise ImageToolError(f"unknown preset {payload['name']!r}")
            return {payload["name"]: preset}
        return PRESETS
    if name == "image_ideas":
        return ideas_lookup(payload.get("query") or None, fill=payload.get("fill") or None)
    if name == "image_generate":
        return _tool_job(payload, "generate")
    if name == "image_edit":
        return _tool_job(payload, "edit")
    raise ImageToolError(f"unknown tool {name!r}")


def handle_rpc(message: dict[str, Any]) -> dict[str, Any] | None:
    """Dispatch one JSON-RPC request. Notifications (no id) return None."""
    method = message.get("method")
    msg_id = message.get("id")
    params = message.get("params") or {}
    if method == "notifications/initialized" or msg_id is None and method and method.startswith("notifications/"):
        return None
    try:
        if method == "initialize":
            result: Any = {"protocolVersion": params.get("protocolVersion") or "2025-06-18",
                           "capabilities": {"tools": {}},
                           "serverInfo": {"name": "imagegen", "version": __version__},
                           "instructions": "Call image_guide once, then image_status, then image_generate/"
                                           "image_edit. Browse image_ideas for vocabulary and genre ideas "
                                           "when a request is thin on detail."}
        elif method == "ping":
            result = {}
        elif method == "tools/list":
            result = {"tools": mcp_tools()}
        elif method == "tools/call":
            try:
                value = call_tool(str(params.get("name")), dict(params.get("arguments") or {}))
                text = value if isinstance(value, str) else json.dumps(value, indent=2)
                result = {"content": [{"type": "text", "text": text}], "isError": False}
            except ImageToolError as exc:
                result = {"content": [{"type": "text", "text": f"error: {exc}"}], "isError": True}
        else:
            return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": f"unknown method {method}"}}
    except Exception as exc:  # a server must answer every request
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32603, "message": str(exc)}}
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


def serve_mcp() -> int:
    """Newline-delimited JSON-RPC over stdin/stdout, the MCP stdio transport."""
    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue
        try:
            message = json.loads(raw)
        except json.JSONDecodeError:
            response: dict[str, Any] | None = {"jsonrpc": "2.0", "id": None,
                                               "error": {"code": -32700, "message": "parse error"}}
        else:
            response = handle_rpc(message)
        if response is not None:
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()
    return 0


# ---------------------------------------------------------------------------
# Embedded knowledge: presets and the capability guide
# ---------------------------------------------------------------------------

# IDEAS is a sample of the possibility space, not a menu and not a ceiling. gpt-image-2 generates from a
# description, not from a checklist: if you can put something into words with enough concrete detail, it
# is very likely makeable in one prompt, whether or not it resembles anything below. The genres here are
# existence proofs - a character turnaround sheet, an exploded diagram, a trading card, a seamless
# tileable pattern, a whole isometric diorama boxed in glass, each built whole from a description or from
# references, not a crop or a color grade applied to an existing photo - offered to widen what gets
# imagined, not to narrow it to this list. Nothing below names a chicken piloting a speedboat, spray
# arcing off the bow in the afternoon sun, and that is exactly the point: it is precisely as makeable as
# any genre here, because both are just descriptions. The vocabulary is the same kind of sample: real
# terms practitioners use, meant to stock a description, not a fixed palette to pick from.
#
# Two different callers read this, and they should come away with different instructions:
#
#   - An LLM agent exploring IDEAS for guidance should treat every "ask" and every vocabulary term as
#     inspiration, not a form. Combine these, invent past them, describe whatever the request actually
#     needs in full expressive prose. A genre's "template" is a minimal skeleton showing the *shape* of
#     the ask - GUIDE's "detail is the lever" applies here too: add the material, mood, exact wording, and
#     framing specifics the request calls for. Filling the {placeholders} and stopping there is not the
#     goal; writing past them is.
#   - A script, form, or other non-LLM caller that already has concrete values and wants the exact prompt
#     line back, deterministically, with no model in the loop, can render a genre's "template" mechanically
#     - see `render_idea_template()`. That path exists for automation, not as the ceiling on what an agent
#     may write.
#
# GUIDE and PRESETS remain authoritative on how to phrase a prompt to Codex.
IDEAS: dict[str, Any] = {
    "vocabulary": {
        "camera_optics": [
            "35mm lens", "50mm lens", "85mm portrait lens", "100mm macro lens", "wide-angle lens",
            "fisheye lens", "tilt-shift (miniature effect)", "shallow depth of field", "bokeh",
            "close-up", "medium close-up", "wide shot", "extreme close-up", "eye level", "low angle",
            "high angle", "bird's-eye view", "worm's-eye view", "dutch angle", "over-the-shoulder",
            "establishing shot", "drone aerial photograph", "three-quarter view", "macro detail",
        ],
        "lighting": [
            "three-point lighting", "Rembrandt lighting (triangle of light on the cheek)",
            "butterfly lighting", "split lighting", "clamshell lighting", "rim/kicker light",
            "backlight with a halo rim", "golden hour", "blue hour", "softbox lighting",
            "hard directional light", "chiaroscuro (Caravaggio-style)", "high-key lighting",
            "low-key lighting", "volumetric light / god rays", "practical lights", "neon lighting",
            "bounce/fill light", "diffused overcast light", "specular highlight",
        ],
        "film_photo_look": [
            "Kodak Portra 400 warmth", "Kodak Tri-X 400 black-and-white grain",
            "CineStill 800T halation", "fine natural film grain", "coarse expressive grain",
            "chromatic aberration / color fringing", "vignetting", "light leaks",
            "cross-processed colors", "double exposure", "long-exposure light trails",
            "motion blur streaks", "lens flare", "soft focus", "crushed shadows / lifted blacks",
        ],
        "render_illustration_style": [
            "flat vector", "isometric", "low-poly", "claymation", "papercraft", "risograph",
            "halftone / Ben-Day dots", "screen print", "watercolor", "gouache",
            "ink linework / cross-hatching", "cel shading", "pixel art (8-bit/16-bit)",
            "blueprint / technical drawing", "3D render (ray-traced, physically-based)",
            "Studio Ghibli style", "anime/manga style", "vaporwave", "cyberpunk neon", "art deco",
            "brutalist minimalism", "children's-book watercolor illustration",
        ],
        "materials_surfaces": [
            "subsurface scattering", "anodized aluminum", "brushed steel (fine linear grain)",
            "matte finish", "satin finish", "gloss finish", "knurled grip", "frosted glass",
            "patina / verdigris", "iridescent", "velvet (directional nap)", "ceramic glaze",
            "leather grain", "translucent", "polished chrome specular highlight",
            "weathered / oxidized", "denim twill weave", "linen weave with slubs",
        ],
        "composition": [
            "rule of thirds", "leading lines", "negative space (state which side)", "symmetry",
            "foreground/midground/background layering", "centered with generous padding",
            "safe margins", "three-quarter angle", "off-center placement", "layered depth",
            "square or odd-numbered grid (renders more reliably than a rectangular one for multi-cell sheets)",
        ],
        "color": [
            "jewel tones", "earth tones", "pastel palette", "muted vs. saturated",
            "teal-and-orange cinematic grade", "duotone", "monochrome", "complementary colors",
            "hex-code brand colors (e.g. #05192D)", "split-toning", "limited palette (4-8 colors)",
            "color temperature (warm/cool)",
        ],
    },
    "genres": {
        "character_turnaround_sheet": {
            "tags": ["character", "reference sheet", "animation", "consistency"],
            "ask": "one sheet with front, side or three-quarter, and back full-body views of the same "
                   "character plus a head close-up, identical face, proportions, outfit, and palette in "
                   "every view, neutral studio light, plain backdrop",
            "template": "Composition/framing: three equal-size full-body views (front, left-profile, back) "
                       "in a row plus a small head close-up, warm light-gray backdrop; Constraints: "
                       "identical face, proportions, clothing seams, colors, and accessories in every view",
        },
        "exploded_diagram": {
            "tags": ["technical", "product", "cutaway"],
            "ask": "the object's parts separated along a central axis, hovering in assembly order, with "
                   "clean callout lines to labeled parts",
            "template": "Primary request: exploded-view illustration of {product} with layers separated "
                       "along a vertical axis, three-quarter perspective, pale gray background; "
                       "Constraints: keep the true part count and proportions, invent no components; "
                       "label each layer with a leader line",
        },
        "knolling_flatlay": {
            "tags": ["product", "flat lay", "organized"],
            "ask": "every item of a set laid flat, aligned at right angles, evenly spaced, shot top-down",
            "related_preset": "product-mockup",
            "template": "Primary request: top-down knolling photograph of {item_set} arranged at perfect "
                       "right angles on {surface}; Lighting/mood: soft even overhead light, no harsh shadow",
        },
        "isometric_diorama": {
            "tags": ["isometric", "miniature", "cutaway", "world"],
            "ask": "a room, building, or city block rendered as a small isometric diorama, often cut away "
                   "or boxed in glass walls, camera at a fixed 30-45 degree top-down three-quarter angle",
            "template": "Composition/framing: isometric view from a 45-degree top-down angle with the "
                       "front and left faces equally visible, contained in a diorama box; the right face "
                       "is the broad face closest to camera",
            "notes": "Describe the observer's position and which face is closest (spatial language); "
                     "numeric camera yaw/pitch specs are reported as unreliable.",
        },
        "seamless_tile_pattern": {
            "tags": ["pattern", "texture", "tileable", "repeat"],
            "ask": "a motif that repeats edge-to-edge with no visible seam when tiled",
            "template": "Primary request: seamless tileable repeating pattern of {motif}; Constraints: "
                       "edges must blend smoothly when tiled, no visible seam, consistent density across "
                       "the whole canvas",
            "notes": "State 'seamless', 'tileable', and 'repeating pattern' explicitly - omitting them "
                     "reportedly breaks the effect. Verify by tiling four copies edge to edge.",
        },
        "contact_sheet": {
            "tags": ["photography", "grid", "variations"],
            "ask": "a grid of related but distinct frames of the same subject or session, like a film "
                   "contact sheet",
            "template": "Composition/framing: a {rows}x{cols} grid of equally sized frames, each a "
                       "different {shot_type} of the same subject, consistent lighting and color across "
                       "every frame",
        },
        "magazine_cover": {
            "tags": ["editorial", "masthead", "cover lines"],
            "ask": "a cover layout with masthead, headline, cover lines, and barcode around a portrait "
                   "or hero image",
            "template": 'Text (verbatim): masthead "{TITLE}", headline "{HEADLINE}", cover line '
                       '"{COVER_LINE}"; Constraints: masthead at top spanning the width, headline in '
                       "large bold type, barcode in a bottom corner, one consistent typographic system",
        },
        "trading_card": {
            "tags": ["game", "card", "stat block", "collectible"],
            "ask": "a bordered card with a portrait or art panel, a name plate, and a stat block in a "
                   "consistent frame style",
            "template": "Composition/framing: vertical card, art panel top two-thirds, name plate and "
                       'stat block bottom third, foil-style border; Text (verbatim): name "{NAME}", '
                       'stat labels "{STATS}"',
        },
        "action_figure_packaging": {
            "tags": ["toy", "blister pack", "collectible"],
            "ask": "the subject rendered as a boxed or blister-packed collectible figure with "
                   "accessories in compartments and printed header/subheading text",
            "template": "Primary request: collectible figure of {subject} in blister packaging, "
                       "accessories in side compartments: {accessory_list}; Text (verbatim): header "
                       '"{NAME}", subheading "{SUBHEADING}"; Style/medium: premium toy photography, '
                       "studio lighting, sharp label printing",
        },
        "comic_panel_grid": {
            "tags": ["comic", "storyboard", "sequence", "narrative"],
            "ask": "a fixed grid of equal panels telling a short beat-by-beat sequence, one described "
                   "scene per panel",
            "related_preset": "illustration",
            "template": "Composition/framing: N equal-size panels in a {rows}x{cols} grid; describe each "
                       "panel's action, framing, and mood individually; keep the character design "
                       "identical across every panel",
        },
        "billboard_signage": {
            "tags": ["advertising", "mockup", "exact text", "environment"],
            "ask": "exact rendered text mounted in a real environment as a billboard, sign, or "
                   "poster-in-scene",
            "template": "Primary request: realistic billboard mockup of {subject} on {environment}; Text "
                       '(verbatim, exact, no extra characters): "{TEXT}"; Constraints: text appears '
                       "once, perfectly legible, bold sans-serif, centered",
        },
        "pitch_deck_slide": {
            "tags": ["presentation", "data viz", "slide"],
            "ask": "one clean slide with a title, a chart or diagram, labeled data, and footnotes, in a "
                   "real-deck visual language",
            "template": 'Primary request: one slide titled "{TITLE}" with {chart_type} showing {data}; '
                       "Style/medium: clean sans-serif typography, generous whitespace, muted palette; "
                       "Avoid: clip art, gradients, decorative elements",
        },
        "floor_plan": {
            "tags": ["architecture", "technical", "map"],
            "ask": "a labeled top-down floor plan with room boundaries, approximate dimensions, and "
                   "furniture placement",
            "template": "Primary request: top-down floor plan of {building}; Style/medium: clean "
                       "architectural line drawing, dimension labels, room names; Constraints: "
                       "consistent wall thickness and door/window symbols",
        },
        "blueprint_schematic": {
            "tags": ["technical", "engineering", "annotated"],
            "ask": "a technical schematic in blueprint aesthetic - line art on a dark or aged background "
                   "with dimension lines and labeled callouts",
            "template": "Style/medium: blueprint aesthetic, white/cyan line art on navy background, "
                       'dimension lines, monospaced labels; Text (verbatim): part labels "{LABELS}"',
        },
        "photo_restoration_colorization": {
            "tags": ["restoration", "archival", "colorize", "edit"],
            "ask": "repair damage in an old photo (dust, scratches, fading) and optionally add "
                   "historically plausible color, without changing faces, poses, or composition",
            "related_preset": "upscale-detail",
            "template": "Primary request: restore this photograph - remove dust, scratches, and fading, "
                       "rebuild damaged regions; Constraints: preserve every face, proportion, and the "
                       "original composition exactly; use restrained period-accurate color; keep natural "
                       "film grain",
        },
        "lego_ification": {
            "tags": ["style transfer", "toy", "novelty"],
            "ask": "redraw a scene or subject as LEGO minifigures or brick construction while keeping "
                   "the same subjects and layout",
            "related_preset": "style-transfer",
            "template": "Primary request: render the subjects in Image 1 as LEGO minifigures with blocky "
                       "brick construction; Constraints: keep the same number of subjects, poses, and "
                       "scene layout; Avoid: photorealistic skin, non-brick materials",
        },
        "film_stock_restyle": {
            "tags": ["photo edit", "analog", "nostalgia", "film stock"],
            "ask": "restyle a photo to look shot on a specific named film stock, keeping the subject's "
                   "likeness",
            "related_preset": "relight",
            "template": "Primary request: restyle this photo as a Kodak Portra 400 35mm film photograph; "
                       "Constraints: keep the face and likeness fully recognizable; add fine natural "
                       "film grain, creamy warm skin tones, soft rolling contrast",
        },
        "double_exposure": {
            "tags": ["composite", "artistic", "blend"],
            "ask": "blend a portrait silhouette with a second scene visible inside its outline",
            "related_preset": "composite",
            "template": "Primary request: double-exposure portrait - a profile silhouette of {subject} "
                       "blended with {scene}, the scene visible inside the silhouette only; Style/medium: "
                       "soft blending, consistent warm tone across both layers",
        },
        "mascot_sticker_sheet": {
            "tags": ["mascot", "stickers", "multi-pose", "brand"],
            "ask": "one consistent mascot character shown in several poses or expressions on one sheet, "
                   "each cell die-cut-ready",
            "related_preset": "sticker-cutout",
            "template": "Composition/framing: {N} poses in a balanced grid, each with a thick uniform "
                       "sticker border; Constraints: identical character design, palette, and "
                       "proportions across every pose",
        },
        "package_dieline": {
            "tags": ["packaging", "technical", "unfold"],
            "ask": "a flat unfolded packaging layout (dieline) with front/back/side panels and fold/glue "
                   "indicators - technical line art, not a rendered mockup",
            "template": "Primary request: unfolded dieline layout for {package_type}; Style/medium: sharp "
                       "black line art on white, no textures or shading; Constraints: include fold "
                       "lines, glue flaps, and panel labels",
        },
        "virtual_tryon": {
            "tags": ["fashion", "identity-preserve", "compositing"],
            "ask": "dress a person in supplied garment images while keeping their face, body, and pose "
                   "exactly the same",
            "related_preset": "object-replace",
            "template": "Primary request: dress the person in Image 1 using the garment in Image 2; "
                       "Constraints: do not change face, skin tone, body shape, pose, or identity; fit "
                       "fabric naturally to the existing pose; match lighting and color temperature",
        },
        "holiday_greeting_card": {
            "tags": ["card", "seasonal", "exact text"],
            "ask": "a seasonal illustrated scene with a short verbatim card message",
            "template": "Primary request: {season} greeting card illustration of {scene}; Text (verbatim, "
                       'include only this): "{MESSAGE}"; Style/medium: premium card illustration, warm '
                       "nostalgic mood",
        },
        "before_after_diptych": {
            "tags": ["comparison", "transformation", "split frame"],
            "ask": "one image split into two halves showing the same subject before and after a stated "
                   "change",
            "template": "Composition/framing: single frame split into two equal halves, left half shows "
                       "{before}, right half shows {after}; Constraints: identical camera angle and "
                       "framing on both halves",
        },
    },
}


def guide_text(section: str | None = None) -> str:
    """Return the whole guide, or the first section whose heading contains `section` (case-insensitive)."""
    if not section:
        return GUIDE
    needle = section.casefold()
    parts = re.split(r"(?m)^(?=#{1,3} )", GUIDE)
    matches = [p for p in parts if p.splitlines() and needle in p.splitlines()[0].casefold()]
    if not matches:
        headings = [p.splitlines()[0] for p in parts if p.strip()]
        raise ImageToolError(f"no guide section matching {section!r}. Headings:\n  " + "\n  ".join(headings))
    return "\n".join(m.rstrip() for m in matches)


def render_idea_template(slug: str, fill: dict[str, str]) -> str:
    """Fill one genre's `template` with concrete values and return the exact prompt line - the
    deterministic, no-LLM path through IDEAS. For a script, a form, or another tool that already knows
    what it wants: every {placeholder} named in the template must have a matching key in `fill`, or this
    raises naming the one that is missing, rather than silently dropping text the way PRESETS scaffolds
    do. This is automation plumbing, not a ceiling - an LLM agent writing the prompt itself is expected to
    go past the template's blanks into full concrete detail, not just call this and stop.
    """
    genre = IDEAS["genres"].get(slug)
    if genre is None:
        raise ImageToolError(f"unknown idea genre {slug!r}. Run `ideas` for the index.")
    try:
        return genre["template"].format(**fill)
    except KeyError as exc:
        raise ImageToolError(f"template for {slug!r} needs a value for {{{exc.args[0]}}}") from exc


def ideas_lookup(query: str | None = None, fill: dict[str, str] | None = None) -> Any:
    """Browse IDEAS: a sample of the possibility space, not a menu to choose from and not a ceiling.

    Every genre in here is an existence proof of a shape of thing gpt-image-2 can produce whole in one
    prompt - built from a description, not limited to editing an existing photo. The point of calling
    this is not to pick one; it is to recalibrate what "possible" means before writing a prompt, then
    describe whatever the request actually needs - combining, inventing past, or ignoring everything
    here, freely, in full expressive detail. GUIDE and PRESETS remain authoritative on how to phrase that
    to Codex.

    No query -> a compact index: vocabulary category names with counts, genre names with their one-line
    ask. A query that exactly names a vocabulary category or a genre slug -> that entry in full. Any
    other query -> every vocabulary term and genre that contains it (case-insensitive substring, matched
    against genre slugs, asks, templates, and tags).

    `fill`, if given, must pair with a query that names an exact genre slug: the returned entry gains a
    "rendered" key holding that genre's template filled with these values via `render_idea_template` -
    the deterministic, scripted path, not something an LLM caller needs to reach for.
    """
    if not query:
        if fill:
            raise ImageToolError("fill needs an exact genre slug in `query` to render against")
        return {
            "vocabulary_categories": {k: len(v) for k, v in IDEAS["vocabulary"].items()},
            "genres": {k: v["ask"] for k, v in IDEAS["genres"].items()},
        }
    needle = query.strip().casefold()
    if needle in IDEAS["vocabulary"]:
        if fill:
            raise ImageToolError(f"{needle!r} is a vocabulary category, not a genre - fill only renders "
                                 "a genre's template")
        return {needle: IDEAS["vocabulary"][needle]}
    if needle in IDEAS["genres"]:
        entry = dict(IDEAS["genres"][needle])
        if fill:
            entry["rendered"] = render_idea_template(needle, fill)
        return {needle: entry}
    if fill:
        raise ImageToolError(f"{query!r} is not an exact genre slug - fill only renders a genre's "
                             "template. Run `ideas` with no argument for the index.")
    matches: dict[str, Any] = {}
    for category, terms in IDEAS["vocabulary"].items():
        hits = [t for t in terms if needle in t.casefold()]
        if hits:
            matches.setdefault("vocabulary", {})[category] = hits
    for slug, genre in IDEAS["genres"].items():
        haystack = " ".join([slug, genre.get("ask", ""), genre.get("template", ""),
                             " ".join(genre.get("tags", []))]).casefold()
        if needle in haystack:
            matches.setdefault("genres", {})[slug] = genre
    if not matches:
        raise ImageToolError(f"no idea matching {query!r}. Run `ideas` with no argument for the index.")
    return matches


PRESETS: dict[str, dict[str, Any]] = {
    "ui-element": {
        "use_case": "ui-mockup",
        "mode": "generate",
        "transparent": False,
        "default_size": "1024x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: a single {component} rendered as one shippable product UI element",
            "Asset type: interface component for a {platform} app",
            "Style/medium: realistic product UI, flat modern design system, not concept art",
            "Composition/framing: the component centered on a plain neutral canvas with generous even padding, nothing cropped",
            "Color palette: {palette}",
            "Text (verbatim): {label}",
            "Component state: {state}"
        ],
        "invariants": [
            "exactly one component in frame",
            "crisp one-pixel borders",
            "consistent corner radius across the component",
            "legible typography at small size",
            "render all text verbatim with no extra characters"
        ],
        "avoid": [
            "browser chrome",
            "mouse cursors",
            "device frames",
            "drop-shadow product scenes",
            "logos",
            "watermark"
        ],
        "notes": "Generated UI text is a mockup, not a deliverable - verify glyph by glyph. If the repo already has an SVG or CSS component system, extend that instead of generating a bitmap."
    },
    "ui-mockup": {
        "use_case": "ui-mockup",
        "mode": "generate",
        "transparent": False,
        "default_size": "1536x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: {screen}",
            "Asset type: interface mockup for {product}",
            "Style/medium: {fidelity}",
            "Composition/framing: {layout} with clear hierarchy and realistic spacing",
            "Subject: the screen contains these sections in order - {sections}",
            "Color palette: {palette}",
            "Text (verbatim): {labels}"
        ],
        "invariants": [
            "practical layout over decorative composition",
            "one consistent spacing scale throughout",
            "label every major block"
        ],
        "avoid": [
            "concept-art lighting",
            "stock photography",
            "logos or trademarks",
            "placeholder lorem ipsum",
            "watermark"
        ],
        "notes": "Set fidelity explicitly - 'shippable product UI' and 'low-fi grayscale wireframe' produce completely different assets. Use 1024x1536 for portrait mobile screens."
    },
    "icon": {
        "use_case": "logo-brand",
        "mode": "generate",
        "transparent": True,
        "default_size": "1024x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: one evenly spaced grid of flat line icons",
            "Asset type: UI icon sheet",
            "Subject: the sheet contains these icons - {icon_list}",
            "Composition/framing: {grid} of identical cells, each icon centered with equal margin and consistent optical weight",
            "Style/medium: {stroke_style}",
            "Color palette: {icon_color}",
            "Scene/backdrop: perfectly flat solid #00ff00 chroma-key background for background removal"
        ],
        "invariants": [
            "one shared visual language across every icon",
            "identical stroke width throughout",
            "clear silhouette when reduced to 24 pixels",
            "equal optical weight in every cell",
            "the background must be one uniform color with no shadows, gradients, texture, reflections, floor plane, or lighting variation",
            "keep the subject fully separated from the background with crisp edges and generous padding",
            "do not use the chroma key color anywhere in the subject"
        ],
        "avoid": [
            "gradients",
            "shadows",
            "perspective",
            "varying stroke widths",
            "text labels",
            "cast shadow",
            "contact shadow",
            "reflection",
            "floor plane",
            "gradient background",
            "watermark"
        ],
        "notes": "Generate large and ask Codex to resize each icon to its target size; the model will not render a usable 24px glyph directly. Keep one identical style line across every icon in the set."
    },
    "logo-transparent": {
        "use_case": "logo-brand",
        "mode": "generate",
        "transparent": True,
        "default_size": "1024x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: a {concept} logo mark",
            "Asset type: logo mark for transparent export",
            "Style/medium: {mark_style}",
            "Composition/framing: a single centered mark with a strong silhouette, balanced negative space, and generous padding",
            "Color palette: {palette}",
            "Text (verbatim): {brand}",
            "Scene/backdrop: perfectly flat solid #00ff00 chroma-key background for background removal"
        ],
        "invariants": [
            "strong readable silhouette at small size",
            "balanced negative space",
            "original design only",
            "the background must be one uniform color with no shadows, gradients, texture, reflections, floor plane, or lighting variation",
            "keep the subject fully separated from the background with crisp edges and generous padding",
            "do not use the chroma key color anywhere in the subject"
        ],
        "avoid": [
            "gradients",
            "3D or bevel effects",
            "presentation mockups",
            "existing trademarks",
            "watermark",
            "cast shadow",
            "contact shadow",
            "reflection",
            "floor plane",
            "gradient background",
            "watermark"
        ],
        "notes": "Transparency comes from the chroma-key matte, not from the prompt - ask Codex to run remove_chroma_key.py and report the alpha check. Pick a key colour absent from the mark."
    },
    "sticker-cutout": {
        "use_case": "illustration-story",
        "mode": "generate",
        "transparent": True,
        "default_size": "1024x1024",
        "default_quality": "medium",
        "scaffold": [
            "Primary request: {subject} drawn as a die-cut sticker",
            "Asset type: die-cut sticker",
            "Style/medium: {sticker_style}",
            "Composition/framing: a single subject centered, filling most of the frame, with generous padding at the edges",
            "Materials/textures: a thick uniform outline border running around the entire subject, like die-cut vinyl",
            "Color palette: {palette}",
            "Scene/backdrop: perfectly flat solid #00ff00 chroma-key background for background removal"
        ],
        "invariants": [
            "one continuous unbroken outline around the whole subject",
            "a single connected shape with no floating pieces",
            "the background must be one uniform color with no shadows, gradients, texture, reflections, floor plane, or lighting variation",
            "keep the subject fully separated from the background with crisp edges and generous padding",
            "do not use the chroma key color anywhere in the subject"
        ],
        "avoid": [
            "background scene elements",
            "multiple subjects",
            "thin disconnected details",
            "unrequested text",
            "cast shadow",
            "contact shadow",
            "reflection",
            "floor plane",
            "gradient background",
            "watermark"
        ],
        "notes": "The outline border is what makes the matte clean - it gives remove_chroma_key.py a high-contrast edge to find."
    },
    "hero": {
        "use_case": "product-mockup",
        "mode": "generate",
        "transparent": False,
        "default_size": "2048x1152",
        "default_quality": "high",
        "scaffold": [
            "Primary request: {concept}",
            "Asset type: landing page hero background",
            "Style/medium: {style_medium}",
            "Composition/framing: a wide composition with a large uncluttered region of usable negative space for overlaid headline copy, with focal interest kept out of that region",
            "Lighting/mood: {mood}",
            "Color palette: {palette}"
        ],
        "invariants": [
            "must stay readable underneath a text overlay",
            "low visual noise in the copy region",
            "the focal subject is never cropped"
        ],
        "avoid": [
            "text",
            "logos",
            "busy detail across the whole frame",
            "high-contrast clutter in the copy area",
            "watermark"
        ],
        "notes": "Do not specify left or right placement of the copy region unless the real page layout supports it - the skill's augmentation policy forbids inventing side-specific placement. Use 3840x2160 for 4K, which is flagged experimental above 2560x1440."
    },
    "product-mockup": {
        "use_case": "product-mockup",
        "mode": "generate",
        "transparent": False,
        "default_size": "1536x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: {product}",
            "Asset type: catalog product shot",
            "Scene/backdrop: a clean studio gradient from light gray to white",
            "Composition/framing: centered at a slight three-quarter angle with generous padding, the full product visible",
            "Lighting/mood: softbox lighting with clean specular highlights and a controlled contact shadow",
            "Materials/textures: {material}",
            "Text (verbatim): {label_copy}"
        ],
        "invariants": [
            "accurate product proportions",
            "a clean unbroken silhouette",
            "label text rendered verbatim",
            "a single product in frame"
        ],
        "avoid": [
            "third-party logos or trademarks",
            "unrequested props",
            "harsh clipping highlights",
            "watermark"
        ],
        "notes": "If the product must later be cut out, use sticker-cutout or background-remove instead - a soft contact shadow on a gradient is exactly what defeats chroma-key removal."
    },
    "sprite": {
        "use_case": "stylized-concept",
        "mode": "generate",
        "transparent": True,
        "default_size": "1536x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: an animation cycle sprite sheet for {character}",
            "Subject: the character is performing a {action} cycle, one distinct pose per frame",
            "Asset type: 2D game sprite sheet",
            "Composition/framing: {grid} of equal cells read left to right, the character identical in scale, anchor point, and baseline in every cell, with equal margins",
            "Style/medium: {style_medium}",
            "Color palette: {palette}",
            "Scene/backdrop: perfectly flat solid #00ff00 chroma-key background for background removal"
        ],
        "invariants": [
            "identical character design in every frame - only the pose changes",
            "identical scale, baseline, and horizontal anchor in every cell",
            "consistent palette and outline weight across all frames",
            "the background must be one uniform color with no shadows, gradients, texture, reflections, floor plane, or lighting variation",
            "keep the subject fully separated from the background with crisp edges and generous padding",
            "do not use the chroma key color anywhere in the subject"
        ],
        "avoid": [
            "shadows",
            "ground plane",
            "frame numbers or labels",
            "the character changing size between frames",
            "cast shadow",
            "contact shadow",
            "reflection",
            "floor plane",
            "gradient background",
            "watermark"
        ],
        "notes": "Sprite sheets are the preset most likely to violate the 3:1 long-to-short ratio rule - wrap long strips onto multiple rows. For pixel art prefer hard-key removal via --tolerance over --soft-matte, which is meant for antialiased edges."
    },
    "infographic": {
        "use_case": "infographic-diagram",
        "mode": "generate",
        "transparent": False,
        "default_size": "1024x1536",
        "default_quality": "high",
        "scaffold": [
            "Primary request: {topic}",
            "Asset type: infographic",
            "Subject: the information is organized as a {flow}",
            "Style/medium: a clean vector-like infographic with a consistent icon language and clear callouts and arrows",
            "Composition/framing: {layout} with clear hierarchy and generous whitespace",
            "Text (verbatim): {labels}",
            "Color palette: {palette}"
        ],
        "invariants": [
            "render every label verbatim with no extra or invented words",
            "strong contrast between text and background",
            "no text smaller than the body label size",
            "arrows follow the stated order"
        ],
        "avoid": [
            "clip art",
            "stock photography",
            "decorative clutter",
            "logos or trademarks",
            "watermark"
        ],
        "notes": "Highest text-failure risk of any preset: verify every label character by character. Keep labels short and sparse, and rebuild production typography in a design tool."
    },
    "illustration": {
        "use_case": "illustration-story",
        "mode": "generate",
        "transparent": False,
        "default_size": "1536x1024",
        "default_quality": "medium",
        "scaffold": [
            "Primary request: {concept}",
            "Asset type: narrative illustration",
            "Scene/backdrop: {environment}",
            "Subject: {subject}",
            "Style/medium: {style_medium}",
            "Composition/framing: {layout} with readable action and a clear focal point",
            "Color palette: {palette}"
        ],
        "invariants": [
            "one concrete action per panel or scene",
            "consistent character design across panels"
        ],
        "avoid": [
            "unrequested text",
            "unrequested speech bubbles",
            "characters not named in the request",
            "watermark"
        ],
        "notes": "For a character recurring across images, attach the prior image as an anchor and switch to identity-preserve invariants: do not redesign the character, preserve facial features, proportions, outfit, and palette."
    },
    "photoreal": {
        "use_case": "photorealistic-natural",
        "mode": "generate",
        "transparent": False,
        "default_size": "1536x1024",
        "default_quality": "high",
        "scaffold": [
            "Primary request: a candid photorealistic photo of {subject}",
            "Subject: the subject is {action}",
            "Scene/backdrop: {environment}",
            "Style/medium: photorealistic candid photograph",
            "Composition/framing: {framing}",
            "Lighting/mood: {lighting}",
            "Materials/textures: {texture_detail}"
        ],
        "invariants": [
            "natural color balance",
            "real photographic imperfection retained",
            "anatomically plausible subjects"
        ],
        "avoid": [
            "studio polish",
            "a staged look",
            "heavy retouching",
            "glamorization",
            "watermark"
        ],
        "notes": "Say photorealistic explicitly and name concrete real-world texture such as pores, wrinkles, fabric wear, or material grain - the skill calls this out as the lever for realism. Use photography language for framing."
    },
    "background-remove": {
        "use_case": "background-extraction",
        "mode": "edit",
        "transparent": True,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: place the subject from Image 1, completely unchanged, onto a flat chroma-key background",
            "Scene/backdrop: perfectly flat solid #00ff00 chroma-key background for background removal"
        ],
        "invariants": [
            "change only the background",
            "preserve the subject's exact shape, colors, materials, edge detail, and any label text",
            "keep a crisp silhouette with generous padding",
            "no halos or fringing",
            "no restyling of the subject",
            "the background must be one uniform color with no shadows, gradients, texture, reflections, floor plane, or lighting variation",
            "keep the subject fully separated from the background with crisp edges and generous padding",
            "do not use the chroma key color anywhere in the subject"
        ],
        "avoid": [
            "cast shadow",
            "contact shadow",
            "reflection",
            "floor plane",
            "gradient background",
            "watermark",
            "restyling",
            "cropping the subject"
        ],
        "notes": "This is an edit that produces a keyable image, not a matte - the alpha comes from remove_chroma_key.py afterwards. Hair, fur, feathers, smoke, glass, liquids, translucent or reflective materials, and soft shadows defeat keying - flag them instead of attempting them."
    },
    "background-replace": {
        "use_case": "precise-object-edit",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: replace only the background of Image 1",
            "Scene/backdrop: {new_background}",
            "Lighting/mood: {lighting}"
        ],
        "invariants": [
            "change only the background",
            "keep the subject, its edges, and its pose unchanged",
            "preserve camera angle, framing, and crop",
            "make the subject's lighting direction and color temperature consistent with the new background"
        ],
        "avoid": [
            "restyling the subject",
            "new objects",
            "cutout halos or visible seams",
            "text",
            "watermark"
        ],
        "notes": "If the new backdrop implies different light, set lighting explicitly - otherwise you get a correctly-lit subject pasted into a wrongly-lit scene. Chain with relight rather than asking for both changes in one vague line."
    },
    "object-remove": {
        "use_case": "precise-object-edit",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: remove {target_object} completely and reconstruct what was behind it so it looks like it was never there",
            "Materials/textures: continue the surrounding {material} pattern and perspective across the filled region"
        ],
        "invariants": [
            "change only the region the removed object occupied",
            "preserve camera angle, framing, crop, lighting direction, and shadow placement",
            "preserve every other object and all surrounding surface texture and grain",
            "remove the object's shadow and reflection along with the object"
        ],
        "avoid": [
            "blur patches",
            "cloned artifacts",
            "new objects",
            "text",
            "watermark"
        ],
        "notes": "Naming the shadow and reflection in the invariants is what stops the classic failure - object gone, shadow still there. There are no masks here, so the region is named in words - identify it by what it contains and what surrounds it."
    },
    "object-replace": {
        "use_case": "precise-object-edit",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: replace exactly one object in Image 1 and change nothing else",
            "Subject: the object to replace is {old_object}",
            "Constraints: the replacement is {new_object}",
            "Materials/textures: {material}"
        ],
        "invariants": [
            "change only the named object",
            "keep the replacement at the same position, scale, and orientation as the original",
            "preserve camera angle, scene lighting, floor and contact shadows, and all surrounding objects",
            "give the new object shadows and reflections consistent with the existing light"
        ],
        "avoid": [
            "changing anything outside the named object",
            "restyling the scene",
            "new elements",
            "text",
            "watermark"
        ],
        "notes": "Anchor position, scale, and orientation explicitly or the replacement drifts across the frame. Covers interior swaps and try-on style substitutions."
    },
    "relight": {
        "use_case": "lighting-weather",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: relight the scene in Image 1 and change nothing else",
            "Lighting/mood: {lighting}"
        ],
        "invariants": [
            "change only lighting, shadows, atmosphere, and weather",
            "preserve subject identity, geometry, materials, camera angle, framing, and composition exactly",
            "keep every shadow direction physically consistent with the new key light"
        ],
        "avoid": [
            "new objects",
            "restyling",
            "a color-grade-only result",
            "geometry changes",
            "text",
            "watermark"
        ],
        "notes": "The failure mode is a flat color grade instead of a real relight - name the key light direction and color temperature in lighting, and the invariants force consistent shadows."
    },
    "style-transfer": {
        "use_case": "style-transfer",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the style reference and must not be modified; Image 2 is the content source",
            "Primary request: render the subject and composition of Image 2 in the visual style of Image 1",
            "Style/medium: {style_cues}"
        ],
        "invariants": [
            "adopt Image 1's palette, texture, brushwork, line quality, and level of abstraction",
            "preserve Image 2's subject identity, pose, and spatial layout",
            "add no elements that are not in Image 2"
        ],
        "avoid": [
            "copying objects or characters out of Image 1",
            "changing the content subject",
            "text",
            "watermark"
        ],
        "notes": "gpt-image-2 preserves every attached input at high fidelity, so order costs nothing - but index the images in the prompt so the model knows which is the style and which is the content."
    },
    "text-replace": {
        "use_case": "text-localization",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: replace the existing in-image text with new text and change nothing else",
            "Subject: the text to replace is {old_text}",
            "Text (verbatim): {new_text}"
        ],
        "invariants": [
            "change only the text",
            "preserve layout, typography, font weight, size, letter spacing, color, alignment, and hierarchy",
            "no reflow and no extra words",
            "do not alter logos, icons, or imagery",
            "render the new strings verbatim with no added or dropped characters"
        ],
        "avoid": [
            "new text anywhere else in the image",
            "restyling",
            "layout shifts",
            "watermark"
        ],
        "notes": "Spell uncommon or non-English words letter by letter inside new_text. Verify every replaced string character by character - precise text placement is a documented weak point."
    },
    "composite": {
        "use_case": "compositing",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the base scene and frame of reference; Image 2 is the subject to insert",
            "Primary request: place the subject from Image 2 into the scene of Image 1",
            "Composition/framing: the inserted subject sits {placement}",
            "Lighting/mood: {lighting}"
        ],
        "invariants": [
            "keep Image 1's framing, crop, camera angle, and background unchanged",
            "match the inserted subject's lighting direction, color temperature, contrast, perspective, and scale to Image 1",
            "add a contact shadow consistent with Image 1's key light",
            "preserve the inserted subject's identity and materials"
        ],
        "avoid": [
            "extra elements",
            "duplicated subjects",
            "visible seams or cutout halos",
            "text",
            "watermark"
        ],
        "notes": "Index every input image in the prompt; the tool attaches them in that order. Compositing is the operation most dependent on multi-image attachment, which is inferred from a variadic flag rather than observed end to end."
    },
    "sketch-to-render": {
        "use_case": "sketch-to-render",
        "mode": "edit",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is a line drawing",
            "Primary request: turn the drawing in Image 1 into a finished render",
            "Style/medium: {render_style}",
            "Materials/textures: {material}",
            "Lighting/mood: {lighting}"
        ],
        "invariants": [
            "preserve the layout, proportions, perspective, and every element present in the sketch",
            "add, remove, and reposition nothing",
            "keep the drawing's spatial relationships intact"
        ],
        "avoid": [
            "new objects",
            "new text",
            "reinterpreting the composition",
            "watermark"
        ],
        "notes": "Choose materials and lighting that support the supplied sketch rather than inventing a new scene around it - the common failure is a beautiful render of a different drawing."
    },
    "upscale-detail": {
        "use_case": "precise-object-edit",
        "mode": "edit",
        "transparent": False,
        "default_size": "2048x2048",
        "default_quality": "high",
        "scaffold": [
            "Input images: Image 1 is the edit target",
            "Primary request: re-render Image 1 at higher resolution with finer surface and material detail",
            "Materials/textures: {material}"
        ],
        "invariants": [
            "preserve composition, framing, crop, subject identity, pose, palette, and lighting exactly",
            "add only fine detail already implied by the source",
            "add no new elements and apply no restyling"
        ],
        "avoid": [
            "recomposing",
            "changing colors",
            "adding objects",
            "smoothing away real texture",
            "text",
            "watermark"
        ],
        "notes": "This is a re-render at a larger size, not an upscale - it does not preserve pixels, so compare against the source. For a faithful resample, ask Codex to resize the original instead."
    },
    "variation": {
        "use_case": "stylized-concept",
        "mode": "generate",
        "transparent": False,
        "default_size": "auto",
        "default_quality": "medium",
        "scaffold": [
            "Primary request: {primary_request}",
            "Constraints: produce a variation that differs from the original only in {vary_axis}",
            "Style/medium: {style_medium}",
            "Color palette: {palette}"
        ],
        "invariants": [
            "hold every line of the original spec constant except the one named axis",
            "keep the same style, palette, and intended use as the original"
        ],
        "avoid": [
            "drifting the subject",
            "changing the polish level",
            "adding elements not in the original",
            "watermark"
        ],
        "notes": "Issue one call per variant; this surface produces one image per call. Hold every line of the original spec constant and move exactly one axis, or the variation becomes a different asset."
    }
}

GUIDE = """\
# Codex image generation and editing — agent capability guide

**Almost anything you can picture, this tool can make. The whole job is writing the prompt.**

You were pointed at this tool and told to use it. That is deliberate, and this guide is the whole
briefing — nobody is going to spend an hour explaining the rest to you. Everything you need to know
about what this can do, and how to ask for it, is in here. Read it and you are equipped.

Restyle a photograph. Change what someone is wearing. Build a web button, a wireframe, a logo, an
icon set. Remove an object and rebuild what was behind it. Relight a scene from noon to dusk. Drop a
product into a room with matching shadows. Translate the text inside a poster. Turn a sketch into a
photograph, or a photograph into line art. Cut a subject out onto a transparent background. Draw an
eight-frame sprite sheet, an exploded assembly diagram, a magazine cover, a comic strip, a seamless
tile. None of that needs a plugin, a mask file, or a second tool. It needs a sentence that says
exactly what you want.

You are not calling a parametric API. You are describing a picture to a model that makes exactly what
you describe, then reading back what it made. There are no sliders. **Every dial on this surface is a
word.** The whole skill is knowing which words are dials — and then being specific enough to move them.

If you take one instruction from this guide: **be descriptive.** Vague in, generic out. The model
never refuses for lack of detail; it just picks for you, and it picks the most generic option
available. Detail is not decoration here. It is the entire interface.

This guide is long on purpose. It is the vocabulary, not a procedure. Read sections 0-5 before your
first call; pull the rest by name when you need them.

## 0. How to read this guide

Sections are addressable. `guide recipes`, `guide rules`, `guide lighting`, `guide camera`,
`guide materials`, `guide edit`, `guide prompt`, `guide identity`, `guide text`, `guide genres`,
`guide use-case`, `guide worked`, `guide transparent` each return just that part instead of the whole
thing. A query matching several headings returns all of them, so `guide recipes` gives you every
recipe group at once.

**Always read:** 1 (surface) and 1.1 (rules from live use), 2 (route), 3 (command),
4 (prompt architecture), 5 (preserve contract).
**Pull when relevant:** 6 (photoshop operations), 7 (model defaults to fight), 8 (text), 9 (multi-image),
10 (transparency), 11 (size), 12-18 (detail banks), 19 (genres), 20 (worked prompts),
21 (use-case tips), 22 (recipes).
**Read before you ship:** 23 (pitfalls), 24 (what is unverified).

Claims carry tags: `[observed]` means it happened on this exact path; `[OpenAI]` means OpenAI's own
published prompting guidance for the gpt-image family; `[community]` means practitioners report it and
it is plausible but unconfirmed here; `[untested]` means nobody here has run it. Do not upgrade a tag.

## 1. What this surface is

A prompt, and up to five attached images, go to a Codex session running an image model on a ChatGPT
subscription. The generated file lands in the working directory and Codex reports the path.

Three things follow, and they shape everything else:

- **No parameters exist.** Size, quality, background mode, mask files, fidelity settings — all of the
  API knobs you may have read about elsewhere are unreachable here. If you want an effect, you say it.
- **Each call is a fresh session.** The model cannot see the last turn's output or remember the last
  turn's instructions. Refining means re-attaching the saved file and restating everything.
- **An edit redraws the whole picture.** There is no layer, no selection, no non-destructive step.
  Nothing survives because you forgot to mention it. It survives because you said to keep it.

What the model is genuinely good at `[OpenAI]`: photorealism with believable materials and light,
in-image text rendering, following long detailed instructions, holding a face or product across an
edit, structured multi-panel layouts and diagrams, style transfer from a reference, and applying real
world knowledge (name a place and a date and it will dress the scene accordingly).

### 1.1 Rules that came from live use

Four facts from the person who built and runs this tool, in his words. They are first-hand
observations from real runs, not documentation. Where they conflict with anything else in this guide,
or with general advice you have picked up elsewhere, **these win** `[observed]`.

> "If it's sprite animation, anything more than 8 or less doesn't work well, so for that you need to
> plan images in sets of 8."

Plan every animation as an eight-frame set. For a longer sequence, ask for several eight-frame sheets
rather than one twelve- or sixteen-frame sheet.

> "Providing an image in is context for what comes out; the inbound image is part of the prompt."

Whatever you attach steers style, palette, framing, lighting, and subject whether or not you mention
it. Two consequences: do not attach anything you do not want reflected in the result, and always say
what role each image is playing (§9). An unexplained image is still an instruction, just one you did
not write.

> "Saying 'maintain the identity' is something you need to say if you want the image to come back
> looking proper."

It is not implied by attaching a photograph of a person. The words have to be in the prompt.

> "Do not invent facial features: if there are sunglasses on and the identity of the individual is
> important, leave them in place even if it's not appropriate, because removing them will have ChatGPT
> invent eyes and then it won't look like the same person."

The rule generalises to anything occluding a feature: a mask, a hood, a hat brim, a hand across the
mouth, heavy shadow. **An occluder is protecting you from invention.** The model cannot see what is
behind it, so remove it and the gap gets filled with a stranger wearing the right clothes. When
identity is the point, keep the occluder and say so: `keep the sunglasses exactly as they are; do not
reveal or reconstruct the eyes`.

## 2. Route: generate, edit, or reference

- The user wants an existing image **changed while parts of it are preserved** -> **edit**. Attach the
  target as the first `--image`.
- The user supplied images only for **style, mood, composition, palette, or subject guidance** ->
  **generate with references**. Say in the prompt that they are references, or they get treated as
  things to edit.
- No images, or images you are not attaching -> **generate**.
- Several assets or variants -> describe each one and ask for each one. One file per thing you name.
- The right answer is not a bitmap — an SVG icon matching an existing set, a CSS component, a chart you
  could write in code -> say so and build that instead.

## 3. The command

```
codex --disable hooks exec -s workspace-write --skip-git-repo-check "<prompt>" --image A.png --image B.png
```

Prompt first, positionally. `--image` flags after it. Generation is the same command with no `--image`.
Up to five images. Run it from the directory you want the file in. If you need a specific absolute
path, say so in the prompt.

## 4. Prompt architecture

### 4.1 Prompt order and shape

Write in a consistent order: **background and scene -> subject -> key details -> constraints** `[OpenAI]`.
The model reads a prompt as a stack; the scene sets the world, the subject sets the focus, the details
fix the look, and the constraints fence it in.

For anything with more than one moving part, use **short labeled blocks, not one flowing paragraph**
`[OpenAI]`. A skimmable template beats clever prose. OpenAI's own longest published example prompt is
laid out like a design bible with headings — Visual Appearance, Body Shape, Material Texture, Color
Palette, Facial Features, Movement and Behavior — not as a sentence.

### 4.2 Prompt template: labeled blocks

Drop any line that does not apply. Add lines the template does not have when the job needs them.

```
Use case: <taxonomy slug>
Asset type: <where the asset will be used>
Primary request: <the main ask, one sentence>
Input images: Image 1: <role>; Image 2: <role>
Scene/backdrop: <environment, era, place, weather, time of day>
Subject: <main subject, with the details that make it that subject and not a generic one>
Style/medium: <photo | illustration | 3D render | flat vector | pixel art | and the sub-style>
Composition/framing: <shot size; angle; placement; negative space; what must be fully in frame>
Lighting/mood: <named setup or natural condition + direction + hardness + mood>
Color palette: <named hues, hex codes, or a grade>
Materials/textures: <surface behaviour: finish, grain, wear, translucency>
Text (verbatim): "<exact string>"
Constraints: <what must hold true>
Avoid: <what must not appear>
```

**Use-case slugs.** Generate: `photorealistic-natural`, `product-mockup`, `ui-mockup`,
`infographic-diagram`, `scientific-educational`, `ads-marketing`, `productivity-visual`, `logo-brand`,
`illustration-story`, `stylized-concept`, `historical-scene`. Edit: `text-localization`,
`identity-preserve`, `precise-object-edit`, `lighting-weather`, `background-extraction`,
`style-transfer`, `compositing`, `sketch-to-render`.

### 4.3 Prompt detail: how much to add

**Detail is the lever, and it is the only lever.** Do not ask for a button. Say the label text, the
corner radius, the border weight, the fill and text colour, the state it is in, the surface behind it,
the padding, and what it must not have. Every detail you leave out is one the model picks for you, and
it will pick the most generic option available.

The discipline is not "write more words." It is: for each of scene, subject, style, light, colour,
material, framing, and exclusion, either say something specific or knowingly accept the default.

- If the user's request is already specific, **normalise it into the template and add no creative
  requirements of your own.** A detailed request is a spec, not a starting point.
- If it is thin, augment — but only along these four axes: composition and framing cues; intended-use
  or polish-level hints; practical layout guidance; scene concreteness that supports what was asked.
- **Never add** extra characters, props, or objects that were not implied; brand palettes, slogans, or
  story beats; or arbitrary left/right placement the layout does not support.
- The recipes in §22 and the worked prompts in §20 are fully authored examples. They are not the
  default amount of augmentation to apply to every request. Mining them for vocabulary is right;
  pasting their invented detail onto a user's brief is not.
- Length has a ceiling `[community]`. Specificity helps until the prompt gets so long that no single
  instruction carries weight. Prefer eight precise lines to forty vague ones.
- Do not repeat the same adjective for emphasis `[community]`. The model reads repetition as an
  amplifier and exaggerates. Say "photorealistic" once.

### 4.4 Prompt mode: naming the intended use

Stating the deliverable — "landing page hero", "16px favicon", "app store screenshot", "Series A pitch
deck slide", "e-commerce catalogue shot", "classroom handout" — sets the model's mode and polish level
in one phrase `[OpenAI]`. It is the highest ratio of effect to words in the whole prompt.

The word **photorealistic** is a mode trigger `[OpenAI]`: including it literally engages the model's
photoreal behaviour. So is naming a genre — "documentary photograph", "children's book illustration",
"technical schematic", "premium toy photography".

## 5. Editing: the preserve contract

### 5.1 Editing: the master idiom

> Change only X. Keep everything else the same. `[OpenAI]`

This is the single load-bearing pattern in prompt-driven editing, and OpenAI states it as a rule.
Enumerate the preserve list concretely rather than gesturing at it: subject identity, face, build,
clothing, pose, camera angle, crop, framing, light direction, shadow direction, colours, markings,
text, logos, background, image quality.

Real forms in use, all `[OpenAI]` unless marked:

- `Remove the tree logo from the white t-shirt of the man. Do not change anything else.`
- `Preserve camera angle, room lighting, floor shadows, and surrounding objects. Keep all other aspects
  of the image unchanged.`
- `Change only the background. Keep the subject, pose, and face identical.` `[community]`
- `Keep everything exactly the same, but make the lighting warmer.` `[community]`

Three rules attach to it:

1. **Change one thing per call.** Change two and you cannot tell which one caused the regression.
2. **Repeat the whole preserve list on every iteration.** Constraints do not carry between calls, and
   detail drifts across sequential edits unless restated each time `[OpenAI]`.
3. **Look at the result and check the invariants actually held.** Trust nothing you did not inspect.

`Maintain both identities but adjust stances` is a complete instruction — it names what holds and what
gives. Aim for that compression once you know it works.

### 5.2 Editing: masks in words

There is no mask file on this surface, and even where masks exist for this model family they are
advisory rather than pixel-exact `[OpenAI]` — the model regenerates the frame and uses the mask as
guidance. So the mask is a sentence. Build it in three parts:

1. **Name the region.** `only the sky`; `only the label on the bottle`; `only the area left of the
   doorframe`; `only the white chairs`; `the region the cup occupied`.
2. **Fence it.** `Every pixel outside that region must be identical to the input.`
3. **Forbid the bleed.** `Do not feather, re-light, or recolour anything adjacent to it.`

Say what fills the hole, too. `Reconstruct the wood grain and shadow consistently with the surrounding
surface` beats `remove it` because it tells the model what "behind" looks like.

### 5.3 Editing: identity lock

Identity is the operation most worth over-specifying. It is also the most frequently reported failure
`[community]` — faces come back as, in one user's words, a weird cousin.

The standard block `[OpenAI]`:

```
Do not change her face, facial features, skin tone, body shape, pose, or identity in any way.
Preserve her exact likeness, expression, hairstyle, and proportions.
Replace only the clothing, fitting the garments naturally to her existing pose and body geometry
with realistic fabric behaviour. Match lighting, shadows, and colour temperature to the original photo.
Do not change the background, camera angle, framing, or image quality, and do not add accessories,
text, logos, or watermarks.
```

**Do not let it reconstruct a hidden feature.** This is the failure that ruins a likeness fastest, and
it is the one nobody expects: sunglasses, a mask, a hood, a hand, deep shadow. The model cannot see
what is behind the occluder, so if you ask it to be removed, it invents — and invented eyes are not
that person's eyes. Keep the occluder, say `do not reveal or reconstruct what is hidden`, and accept a
slightly odd photograph over a convincing photograph of someone else. (§1.1)

Stack four things when identity matters:

- an explicit do-not-change-face clause naming features, not just "the face";
- the full preserve list restated every turn;
- a re-anchoring fallback: when drift appears, **re-attach the original image**, not the drifted output;
- for anything spanning more than two or three edits, build a **character reference sheet** first (§19)
  and attach it to every later call.

For products, the same shape: `Preserve product geometry and label legibility exactly.` `[OpenAI]`

### 5.4 Editing: iterating without drift

- Fresh session per call means every constraint is reintroduced or lost.
- Re-attach the saved PNG as `--image` and treat the refinement as a new edit.
- Stop and restart from a clean prompt after about three failed revisions `[community]`; iterating on a
  broken result tends to get worse, not better.
- Style bleeds within a thread `[community]`. On a shared surface, a new conversation resets it; here,
  every call is already fresh, which is a feature.

## 6. Photoshop operations, phrased

One entry per editing verb. **Ask** is the phrasing that works. **Watch** is what goes wrong. All
phrasings are `[OpenAI]` or `[community]`; only the sticker cutout in §10 is `[observed]` here.

**Remove an object.**
Ask: `Remove the [object] from [location]. Reconstruct the affected area from the surrounding detail so
it looks undisturbed. Preserve original lighting, colour tones, depth of field, and texture. Do not
change anything else.`
Watch: unrequested changes elsewhere in frame. The preserve clause is not optional.

**Replace an object.**
Ask: `Replace ONLY the [white chairs] with [chairs made of wood]. Preserve camera angle, room lighting,
floor shadows, and surrounding objects. Keep all other aspects of the image unchanged. Photorealistic
contact shadows and fabric texture.`
Watch: the replacement lands with the wrong scale or a missing contact shadow. Name both.

**Recolour one thing.**
Ask: `Change the colour of the red hat to light blue as velvet. Do not change anything else.`
Watch: the recolour spreads to similar hues elsewhere. Name the object, not the colour.

**Remove a watermark or blemish on a surface.**
Ask: `Remove the [mark] and fill the space with the surrounding pattern and lighting so no trace remains.`

**Background removal / cutout.** See §10.
Ask: `Extract the product from the input image. Output a crisp silhouette with no halos or fringing.
Preserve product geometry and label legibility exactly. Do not add a solid backdrop, checkerboard,
scenery, or shadow.`
Watch: "remove background" over-triggers on white regions *inside* the subject `[community]`. Name the
subject explicitly and specify edge behaviour.

**Background replacement.**
Ask: `Replace the background with [a misty pine forest at dawn]. Keep the person and their clothing,
hair, and shadows exactly as they are. Match the lighting direction and colour temperature already on
the subject.`
Watch: the subject stays lit for the old scene and reads as pasted on. Name the new light direction.

**Relight / change time of day / weather.**
Ask: `Completely re-light this image as golden hour. Light source from the back-left creating long
dramatic shadows and a soft warm rim on the edges. Change only light, shadow, and atmosphere; keep
geometry, framing, crop, subject identity, pose, and all objects unchanged. Do not shift skin tone.`
Short form that works `[OpenAI]`: `Make it look like a winter evening with snowfall.`
Watch: skin tone and background layout shift unless locked.

**Colour grade.**
Ask: `Using the photo I uploaded, apply a teal-and-orange cinematic grade: push shadows toward
teal/cyan, highlights toward warm orange, crush blacks slightly, desaturate midtones while keeping
vibrant accents. Keep skin tones natural. Do not alter the image content.`
Watch: opening with `Using the photo I uploaded` is what keeps it an edit instead of a fresh
generation `[community]`. Also see the warm bias in §7.

**Retouch skin.**
Ask: `Apply subtle natural retouching. Even out skin tone and reduce blemishes and under-eye shadows
while preserving ALL natural skin texture, pores, and freckles. Do not smooth or plasticise.`
Watch: the default is waxy. Forbid it by name, every time.

**Denoise.**
Ask: `Reduce digital noise, compression artefacts, and rough grain. Keep skin texture, hair strands,
fabric detail, and surface texture natural. I want a cleaner image, not a waxy or over-smoothed result.`

**Deblur / sharpen.**
Ask: `Improve focus, edge definition, and visible detail while keeping the result realistic. Reduce
softness and motion blur, but do not over-sharpen or invent fake details.`

**Upscale with detail.**
Ask: `Reconstruct this low-resolution image at high fidelity. Recover lost detail in edges, textures,
and lines. Sharpen without introducing artefacts. No artificial textures or hallucinated details. Keep
original lighting and colour tone.`
Watch: **asking for a bigger version is a re-render, not an upscale.** No pixel of the original is
preserved; the model draws a new picture that resembles the old one at a larger size. People assume
otherwise and are wrong. Faces, text, logos, and fine markings can all come back subtly different.
Never use it where the detail is the evidence, and never on an asset that has to match a previous
version exactly. When you need the same pixels bigger, resize the file instead.

**Restore a damaged photo.**
Ask: `Repair scratches, stains, folds, creases, and dust. Reconstruct damaged areas from the
surrounding detail. Keep the person's identity, expression, and the look of the original era.`

**Colorize a black-and-white photo.**
Ask: `Colorize this photograph using historically accurate and subtle tones for [rural Texas] in the
[1930s]. Natural skin tones, believable clothing colours, balanced lighting. Keep every face, detail,
and the original composition unchanged. Finish with a fine natural grain.`
Watch: the model modernises faces and colours unless told the era.

**Insert an object or person from another image.**
Ask: `Place the [dog] from Image 2 into the setting of Image 1, right next to the woman. Match Image 1's
perspective, scale, light direction, shadow softness, and colour temperature, and add a plausible soft
contact shadow. Use the same style of lighting, composition, and background. Do not change anything else.`
Watch: ask for a **soft contact shadow**, not a drop shadow — a drop shadow is what pasted-on looks like.

**Re-pose or change camera angle.**
Ask: `Shift the camera slightly above eye level at about 15 degrees to create a natural selfie look.
Keep the same face, hairstyle, outfit, and lighting while maintaining realistic proportions.`
Two-image form: `Adjust the pose and camera angle of the character in Image 1 using Image 2 as the
reference for those changes. The character's face, outfit, and background must remain exactly as in
Image 1.`

**Straighten / correct perspective.**
Ask: `Correct the perspective distortion, even out the lighting across the label, remove harsh shadows
and hot spots, and sharpen the text and logo.`

**Replace text inside an image.**
Ask: `Correct only the headline so it reads "SUMMER LAUNCH" exactly, with the same font style, weight,
size, colour, spacing, and position. Change no other text, layout, subject, product, colour, or
background. Every non-text pixel identical to the input.`

**Translate or localise text.**
Ask: `Translate the text in the infographic to Spanish. Do not change any other aspect of the image.`

**Style transfer.**
Ask: `Render the scene in Image 1 in the visual style of Image 2. Keep the subject, composition, camera
angle, and layout from Image 1. Take palette, texture, brushwork, grain, and line quality from Image 2.
No extra elements, no crop change.`
Single-image form `[OpenAI]`: `Use the same style from the input image and generate a man riding a
motorcycle on a white background.`

**Sketch or wireframe to render.**
Ask: `Turn this drawing into a photorealistic image. Preserve the exact layout, proportions, and
perspective. Choose realistic materials and lighting consistent with the sketch intent. Do not add new
elements or text.` Then name the materials you want: `brushed aluminium body, matte rubber grip`.
Watch: clean line work (CAD, wireframes) renders far more faithfully than freehand `[community]`.

**Photo to line art.**
Ask: `Convert this photo into a hand-drawn line illustration. Clean lines, no shading, simplified
forms, thick bold outlines, graphic-novel style, pure black on white.`
Watch: a bare "turn this into a coloring page" gives messy unprintable results `[community]`. Line
weight and shading vocabulary is what makes it usable.

**Photo to flat vector look.**
Ask: `Transform this into a modern flat-vector illustration with clean geometric shapes, minimal smooth
gradients, simplified facial features that stay recognisable, and a solid pastel circular background.`

**Extend the canvas (outpaint).**
Ask: `Extend this image outward on both sides. Keep the main scene unchanged. Preserve the original
lighting, colours, style, and perspective, and add natural background detail so it reads as a wider
version of the same photograph. Do not alter the subject's face, clothing, or the central focus.`
Watch: dimension-exact expansion is not reliable here `[community]`. Expect a plausible wider scene, not
a measured extension.

**Make it tileable.**
Ask: `Seamless tileable repeating pattern. Ensure edges blend smoothly so the tile repeats infinitely
with no visible seam. Macro detail, uniform diffuse lighting, no shadows, no perspective distortion,
clean edges for tiling, top view.`
Watch: the words seamless / tileable / repeating are load-bearing, and even with them the result is not
guaranteed to tile `[community]`. Verify by tiling the output 2x2 and looking at the seams.

## 7. Model defaults you must counteract

These are the biases the model brings when you do not say otherwise. Each one costs you one clause.

- **Warm and beige.** Grades skew warm; skin leans warm; even cool scenes get warm highlights
  `[community]`. For a neutral or cool look, say so: `keep whites neutral, not beige; do not add warmth`.
- **Waxy skin.** Retouching over-smooths by default. Forbid it explicitly (§6).
- **Cinematic overproduction.** Asked for a realistic photo, it produces a movie poster. OpenAI's own
  counter-example `[OpenAI]`: `The image should look like a real photograph someone could have taken,
  not an overly enhanced or cinematic movie-poster image. Everything should feel grounded, authentic,
  and unstyled, as if captured in a real moment. Avoid cinematic lighting, dramatic colour grading, or
  stylised composition.`
- **Invented text.** It adds labels, captions, signage, and watermarks nobody asked for. `Do not add any
  other text` belongs in almost every prompt.
- **Invented detail.** On upscale, denoise, and restore, it fabricates rather than recovers. Ban it by
  name and never rely on it for evidentiary detail.
- **Glamorisation.** Faces get younger and more symmetrical. `No glamorization, no heavy retouching`
  `[OpenAI]`, plus real skin texture in the description.
- **Drift.** Anything not restated moves (§5.4).

Negatives are plain English here. There is no separate negative-prompt field; `no watermark`,
`avoid cinematic lighting`, `no extra text` go in the same prompt as everything else `[OpenAI]`.

## 8. Text inside the image

- **Quote the exact string**, and mark it as exact: `Billboard text (EXACT, verbatim, no extra
  characters): "Fresh and clean"` `[OpenAI]`.
- **Keep it short.** Long copy degrades.
- **Specify typography and placement**: font style, weight, size, colour, alignment, kerning, position
  on canvas. `Typography: bold sans-serif, high contrast, centred, clean kerning.`
- **Say it appears once**: `Ensure text appears once and is perfectly legible.`
- **Spell uncommon words letter by letter** when accuracy matters `[OpenAI]`.
- **Forbid the rest**: `Do not add any other text.`
- **Check every character before shipping.** Generated text is a mockup, not a deliverable. Precise text
  placement and clarity remain a documented weakness `[OpenAI]`, and it degrades badly on tiny, blurred,
  or curved-surface text `[community]`. Finish production typography in a design tool.

Where the layout is dense — infographics, slides, packaging — describe the hierarchy, keep every label
short, and expect to verify each one.

## 9. Multiple reference images

Attach up to five. There is no role parameter; roles live in the prompt and you must supply them.

- **Index every image, matching `--image` order** `[OpenAI]`: `Image 1: product photo, edit target.
  Image 2: style reference. Image 3: object to insert.` The four roles worth naming are edit target,
  style reference, object to insert, and composition/pose reference.
- **Say how they interact**, not just what they are: `apply Image 2's style to Image 1`; `place the
  subject from Image 2 into Image 1`; `keep the product, camera angle, and layout from Image 1, but
  take the palette and brushwork from Image 2`.
- **Use spatial words** when combining: foreground, background, left, right, behind, in front of,
  right next to.
- **Unlabelled images get treated as edit targets.**
- Multi-reference composition is a documented strength — OpenAI's own example builds one gift basket
  from four separate reference photographs `[OpenAI]`.

## 10. Transparent backgrounds and cutouts

Ask for it plainly first. `Make it into a sticker with a transparent background` returned a real RGBA
PNG with a clean die-cut edge, first try `[observed]`. The model generates on a key colour and removes
it itself. Community write-ups claiming the consumer surface cannot produce alpha describe a different
path; on this one it worked.

Strengthen the ask with the language OpenAI uses for isolated subjects `[OpenAI]`:

```
Isolated subject on a fully transparent background. Crisp silhouette, clean alpha edges, no halos or
fringing. Generous even padding. No scenery, solid backdrop, checkerboard, watermark, or unwanted
shadow.
```

For products, `subtle realistic contact shadow in the alpha, no hard cut line` `[OpenAI]` keeps a
cutout from looking like a sticker when you did not want a sticker.

If a transparent request comes back opaque, describe the key colour yourself and remove it after:

```
Render the subject on a perfectly flat solid #00ff00 chroma-key background for background removal. The
background must be one uniform colour with no shadows, gradients, texture, reflections, floor plane, or
lighting variation. Keep the subject fully separated from the background with crisp edges and generous
padding. Do not use #00ff00 anywhere in the subject. No cast shadow, no contact shadow, no reflection,
no watermark.
```

Key colour: `#00ff00` by default, `#ff00ff` for green subjects, never one that appears in the subject.
Then check the result has an alpha channel, transparent corners, and no key-colour fringe. A chroma-key
removal helper ships with the imagegen skill if you need one; ask for the outcome and let the removal
step choose its own means.

Hair, fur, feathers, smoke, glass, liquids, translucent or reflective materials, and soft shadows do not
key cleanly. Say so before generating rather than shipping a fringed matte.

## 11. Size, aspect, and orientation

**State the dimensions you want.** The tool writes them into the prompt as a `Requested size: WIDTHxHEIGHT`
line, and they come back honoured. Every measured run on this path matched what was asked for `[observed]`:

| Requested size line | Canvas returned |
| --- | --- |
| 3072x1024 | 3072x1024 |
| 3840x2160 | 3840x2160 |
| 1024x1024 | 1024x1024 |

Three for three. In the tool owner's words: **"I don't know if it can do that resolution, it's better to
just say dimensions."** Say them, then check what you got.

Use multiples of 16 for both edges. How large it will go is unverified — nothing here has probed the
ceiling, so if you ask for something unusually large, treat the result as needing inspection rather
than assuming it worked.

Earlier revisions of this guide told you the opposite, and then told you that composition wording was
secretly moving the canvas. Both were wrong. The sprite sheets came back at 3:1 and 16:9 because those
sizes were requested, not because the phrase `a row of eight frames` reshaped anything.

**Composition language still matters — it governs the content, not the canvas.** `Wide landscape
composition with open space at the left`; `full body, nothing cropped, generous even padding`; `single
glyph centred on a square canvas`; `a single row of eight frames, equal-width cells`; `subject
positioned at the left third`; `safe margins`. Pair it with the size: the dimensions set the frame, the
composition decides what fills it. Asking for a wide strip without saying what goes in it, or describing
a row of frames without asking for a wide canvas, each get you half of what you wanted.

**Say what size the design must read at, separately from the file size.** `Readable at 24px`, `legible
at thumbnail size`, `reads as a solid silhouette when small` are design constraints and they shape the
drawing. They are not the same instruction as `Requested size: 24x24` — generate large, state the
legibility target, and resize afterwards.

Quality levels are not reachable on this path; signal polish by naming the intended use (§4.4).

## 12. Detail bank: camera and optics

Camera specs are interpreted loosely — use them for look and composition, not physical simulation
`[OpenAI]`. They still steer strongly.

- **Focal length:** 14mm, 16-35mm, 24mm, 35mm, 50mm (normal), 85mm (portrait), 100mm/105mm macro,
  135mm, 200mm and up.
- **Aperture:** f/1.2, f/1.4, f/1.8, f/2, f/2.8, f/5.6, f/8, f/11, f/16.
- **Shot size:** extreme wide, wide, medium, medium close-up, close-up, extreme close-up,
  head-and-shoulders crop, three-quarter view, hero shot, environmental portrait, establishing shot.
- **Angle and height:** eye level, low angle, high angle, bird's-eye, worm's-eye, nadir, oblique 20-45
  degrees, dutch angle, over-the-shoulder, top-down.
- **Specialty:** macro, fisheye, tilt-shift (miniature effect), drone or aerial, anamorphic.
- **Focus:** deep focus, shallow depth of field, bokeh, soft focus, rack focus, subject in focus with
  background falloff.
- **Physical placement, which works better than jargon:** `camera at chest height`, `camera one metre
  from the subject`, `drone at 300 feet`, `observer stands at the front-right corner`.

For isometric work specifically, spatial phrasing beats numeric camera angles `[community]`:
`the observer stands at the front-right corner`, `the right face is the broad face closest to camera`,
`45 degree top-down angle` (or `30 degrees` for a shallower, more dramatic view).

## 13. Detail bank: lighting

Naming a lighting setup is one of the highest-yield details available. Name the **setup**, the
**direction**, the **hardness**, and the **mood**.

- **Named portrait setups:** three-point, Rembrandt (45-degree elevated key, triangle of light on the
  far cheek), butterfly (overhead front, small nose shadow), split, loop, broad, short, clamshell
  (beauty dish plus reflector fill), chiaroscuro (subject emerging from darkness).
- **Roles:** key light, fill light, back light, rim light, kicker, hair light, practical lights,
  bounce, reflector fill, catchlights.
- **Equipment vocabulary:** softbox, octabox, beauty dish, snoot, grid, scrim, tungsten key.
- **Natural conditions:** golden hour, blue hour, overcast diffused, harsh midday sun, north-facing
  window light, dappled light through leaves, moonlight, firelight.
- **Character:** hard shadow edges, soft shadow edges, specular highlights, volumetric light, god rays,
  backlit, side lit, high-key, low-key, colour temperature 3200K-5600K.
- **Direction is a separate word from setup and you must say it:** `from the back-left`, `key from upper
  left`, `warm window light from the left`, `low western sun`.

Naming the light direction is also the mechanism that makes composites blend — it forces the model to
relight the inserted element to match `[community]`.

## 14. Detail bank: film and photographic look

- **Stocks:** Kodak Portra 400 / 800, Kodak Tri-X 400, Kodachrome, Fujifilm Superia 400, CineStill 800T,
  Ilford HP5 Plus, Agfa Vista 200.
- **Artefacts:** film grain (describe the character — fine, organic, coarse, expressive — not a number),
  halation, chromatic aberration, colour fringing at frame edges, vignetting, lens flare, anamorphic
  flare, light leaks, bloom.
- **Processes and exposures:** cross-processed, bleach bypass, split-toning, long exposure, light trails,
  motion blur, double exposure, soft focus.
- **Tonality:** crushed shadows, lifted blacks, luminous highlights, punchy contrast, rolling contrast,
  rich deep blacks, faded washed colour.
- **Framing the whole look:** `shot like a 35mm film photograph`, `authentic analog colour-negative
  aesthetic`, `shot on a manual SLR`, `35mm rangefinder`, `documentary tonality`.

Worked pattern `[community]`: `Transform this into a Kodak Portra 400 35mm film photograph. Keep the
face and likeness fully recognisable, but render creamy warm skin tones, soft pastel highlights, gentle
rolling contrast, and fine natural film grain. Slightly muted greens, warm shadows, and a soft-focus
background with organic 35mm lens character.`

## 15. Detail bank: style and medium

Say the medium, then the sub-style, then the tell that distinguishes it.

- **Vector and flat:** flat vector, flat design, monoline, isometric, low-poly, gradient line art,
  minimalist line art.
- **Hand media:** watercolour, gouache, ink linework with cross-hatching or stippling, charcoal, pastel,
  oil impasto, marker rendering.
- **Print processes:** risograph, halftone with Ben-Day dots, screen print with visible separations,
  letterpress, woodblock / ukiyo-e, lithograph, illuminated manuscript.
- **Physical craft:** claymation with visible fingerprints and tool marks, papercraft, felt or knitted
  toy, marble sculpture, diorama, miniature model.
- **Animation and comics:** cel shading, anime, manga, webtoon, graphic novel, 1930s rubber-hose,
  storybook illustration, children's picture book.
- **Digital and game:** pixel art (8-bit, 16-bit, with a stated palette size), voxel, physically-based
  render, ray-traced, wireframe, holographic UI, glitch art with RGB channel splitting.
- **Technical:** blueprint, technical schematic, exploded assembly drawing, cutaway, patent drawing,
  x-ray view, thermal false-colour.
- **Movements and eras:** art nouveau, art deco, bauhaus, brutalist, mid-century travel poster, pop art,
  vaporwave, cyberpunk, solarpunk, psychedelic.

Naming a living artist is off-limits. Name the movement, the process, or the era instead.

## 16. Detail bank: materials and surfaces

Material words do more work than colour words, because they carry both light behaviour and texture.

- **Finish:** matte, satin, gloss, polished, burnished, brushed with anisotropic sheen, anodized,
  powder-coated, knurled, frosted, sandblasted.
- **Optical behaviour:** subsurface scattering, translucent, iridescent, specular highlights, caustic
  light patterns, retroreflective.
- **Age and wear:** weathered, worn paint edges, oxidised, rusted, patina, verdigris, scuffed, chipped,
  sun-bleached, hand-worn.
- **Textiles:** denim with visible twill weave and slubs, linen with irregular weave, wool knit with
  visible stitches and cable pattern, silk or satin with liquid sheen, velvet with plush directional
  nap, leather grain.
- **Hard goods:** ceramic glaze, board-formed concrete, terrazzo, brushed aluminium, cast iron, walnut
  grain, cork, frosted glass, injection-moulded plastic with a slight parting line.
- **Organic:** weathered skin with visible wrinkles and pores, sun texture, wet fur, dry cracked earth.

Photorealism comes from stating what a surface does to light, not from the word photorealistic alone.
`Real skin texture, worn materials, and everyday detail` `[OpenAI]` is the whole trick in one line.

## 17. Detail bank: composition and framing

- **Classic devices:** rule of thirds, leading lines (name the in-scene element that leads — road,
  fence, staircase, river), symmetry, radial composition, framing within a frame, layering into
  foreground / midground / background.
- **Negative space, with a direction:** `generous negative space on the left for copy`, `quiet upper
  third`, `subject offset right`.
- **Placement instructions:** `logo top-right`, `subject centred`, `subject positioned at the left
  third`, `equal margins on all four sides`.
- **Completeness:** `full body visible, feet included`, `nothing cropped`, `whole outline visible`,
  `safe margins`.
- **Orientation:** square, tall portrait orientation, wide landscape composition, vertical.
- **Multi-element layout:** `a 3-by-2 grid, evenly spaced, identical scale and baseline in every cell`;
  `three panels left to right joined by arrows`; `title across the top`.

Grids with a square or odd shape (3x3) are reported to render more reliably than rectangular ones
`[community]`. Say the cell count, the arrangement, and that cells must be equal size.

## 18. Detail bank: colour and grade

- **Named hues carry more than adjectives:** Prussian blue, ultramarine, vermillion, sapphire, emerald,
  chartreuse, magenta, sepia, verdigris, ochre, oxblood.
- **Hex codes work directly in prompts** `[community]`. Use them for brand colour.
- **Palette shapes:** limited palette of four to eight colours, monochrome, duotone, complementary,
  analogous, jewel tones, earth tones, pastel, muted blues and greys, high-saturation accents on a
  neutral field.
- **Grade language:** teal-and-orange, bleach bypass, split-toned, crushed blacks, lifted blacks,
  desaturated midtones, warm highlights and cool shadows, neutral whites.
- For a set, **repeat the exact palette line verbatim across every asset.** A shared style line is what
  makes a set a set.

## 19. Genres: what you can ask for in one prompt

Each of these is a single-prompt deliverable that people get out of this model family. The point of the
list is that you do not have to invent the format — name it and describe it.

**Reference and consistency sheets.** Character turnaround sheet (front, left profile, back, plus a head
close-up, equal scale, neutral light, identical face and seams in every view). Outfit or wardrobe sheet.
Prop sheet. Colour keys. Generate one, then attach it to every later call and refer to the character by
name instead of re-describing them `[community]`.

**Animation and game assets.** Walk-cycle sprite sheet as an evenly spaced horizontal row with identical
scale and baseline per cell `[observed]` — an 8-frame running cycle on a transparent background, sliced
by dividing the width by eight. Multi-frame spell or attack animation in a 3x3 grid. Isometric tile
sets. Item and icon sheets. Texture atlases. Keyframe sequences.

**Eight frames, always.** Fewer or more does not work well on this surface (§1.1). An eight-cell row
is the unit; chain sheets for longer cycles.

**Ask for geometry you can slice, then measure what came back.** Two eight-frame sheets from this path
were measured cell by cell `[observed]`:

|  | run cycle | kick cycle |
| --- | --- | --- |
| canvas / cell | 3072x1024, cell 384x1024 | 3840x2160, cell 480x2160 |
| baseline spread across 8 cells | 1 px | 151 px |
| subject height spread | 6% | 15% |
| unused vertical room per cell | 50% | 79% |

**First, the good news, and it corrects an earlier version of this section.** In both sheets the
subjects stay inside their own cells — widest right edge was 361 of 384, and 455 of 480. Nothing
bleeds across a boundary. **Width divided by eight gives you eight clean, uncontaminated cells in both
cases.** The kick sheet's problem is not misaligned cells; it is drift and scale variance happening
inside correct cells. That is a different repair: a framing instruction, not a slicing workaround.

**Three things plausibly drove the drift, and they compound:**

1. **The action.** A run keeps feet near a ground line. A kick is a leap, so the subject genuinely
   leaves the ground mid-cycle. The model was drawing the motion it was asked for, not ignoring the
   baseline instruction.
2. **The slack, which was a human choice, not a model behaviour.** Drift tracked unused vertical room
   almost perfectly: 50% slack gave a 1px baseline spread, 79% slack gave 151px. A character that
   nearly fills its cell has nowhere to float. The model did not pick the roomy canvas — 3840x2160 was
   requested (§11). The slack was ordered.
3. **A contradiction in the prompt.** The kick prompt asked for `feet on the same baseline` *and*
   `subject centered in its cell`. In a cell four and a half times taller than wide, those two fight,
   and centring wins. The run prompt did not ask for centring.

**Choose the canvas from the cell shape you want.** For a single row this is arithmetic, not taste:

```
cell aspect = canvas aspect / number of cells
```

- run sheet: 3:1 canvas / 8 cells = 0.375. Cells 384x1024. Locked baseline.
- kick sheet: 1.78:1 canvas / 8 cells = 0.222. Cells 480x2160. 151px of drift.

The documented limits are a 3:1 maximum long-to-short ratio and a 3840px maximum edge. So **an
eight-cell row can never have cells wider than 0.375 aspect** — every cell is at least two and a half
times taller than wide, and that is the best case. Ask for less than 3:1 and it gets worse fast.

The practical consequence: **for an eight-frame row, request a 3:1 canvas and keep the height modest.**
3072x1024 hits the ratio ceiling while staying under the edge limit, and it is the sheet that worked.
3840x2160 cannot reach 3:1 at that height — you would need 6480px of width, past the edge limit — so
asking for a 16:9 canvas and eight cells in a row guarantees slack before the model draws anything.

**Then remove the remaining slack in words**, which works regardless of canvas or action:

```
character fills the full cell height, feet on a common baseline along the bottom edge,
identical scale in every cell, evenly spaced, no gutters, no labels, no border
```

Do not pair that with `centred in its cell` — pick the baseline or pick centring, never both. For
ground-contact cycles (walk, run, idle) expect a clean slice. For airborne actions (jump, kick, leap,
fall, swing) the subject will move vertically no matter what, which is usually correct for animation;
decide whether you want that motion preserved or flattened, and say which.

n=2 on all of this. The mechanism explains both files with one cause, but two files is two files. The
cheap confirming test is to regenerate the kick cycle with the fill-the-cell-height clause added and
nothing else changed, and see whether the baseline spread collapses.

Expect generous empty margin above and below the content band. In the kick sheet the content occupied
roughly y=739 to y=1370 of 2160, so about 70% of the image height was discardable `[observed]`. Trim to
the content, then slice.
Watch: left/right limb confusion is a reported weakness — the model tends to read left and right from
the viewer's side, not the character's `[community]`.

**Stickers and emoji.** Die-cut sticker with a closed unbroken white border. Reaction sticker pack as a
3x2 grid of the same mascot in named poses — waving, thinking, celebrating, surprised — identical shell,
proportions, and palette in every pose. Two-image composites work: a subject from one photo doing
something from another, cut out with a die-cut border `[observed]`.

**Product and packaging.** Product-on-white catalogue shot with the product filling most of the frame.
Lifestyle scene compositing. Ghost mannequin (garment appears filled out by an invisible wearer, inner
collar visible, mannequin removed). Label or artwork wrapped onto a 3D box, bottle, or pouch with
correct perspective. Flat unfolded die-line layout with front, back, side, top, bottom panels, glue
flaps, and fold indicators. Blister-pack collectible with exact packaging text.
Watch: the die-line is visualisation, not a manufacturing file `[community]`.

**Marketing and editorial.** Billboard mockup with exact verbatim copy. Ad campaign image with a tagline
rendered once. Magazine cover with masthead, cover lines, badge, and barcode. Pitch-deck slide with a
TAM/SAM/SOM diagram, believable numbers, a bar chart, and footnotes. Poster. Greeting card with exact
card text. Trading card with a stat block.

**Explanatory graphics.** Infographic with callouts and leader lines. Process or flow diagram with
labelled arrows. Exploded assembly view with layers separated and technical callouts. Cutaway. Cross
section. Blueprint or technical schematic. Floor plan. Map illustration. Classroom handout diagram with
named molecules or parts. Before/after diptych.

**Narrative layouts.** Multi-panel comic strip with per-panel scene descriptions. Storyboard. Contact
sheet. Children's book illustration plus a story-continuation image using the same character.

**Scenes and worlds.** Isometric miniature diorama in a cubic enclosure with two solid back walls, two
transparent glass front walls, and a photorealistic miniature figure inside. Isometric room or city.
Knolling flat-lay with everything aligned at right angles under soft overhead light. Historical scene
by place and date — `Bethel, New York, August 16 1969` gets you Woodstock without the word `[OpenAI]`.

**UI and brand.** App or web UI mockup, optionally placed in a device frame. Icon set sharing one
verbatim style line. Logo with a strong silhouette and balanced negative space on transparent. Favicon.
App store screenshot.

**Photographic transformations.** Film-stock restyle. Double exposure. Long-exposure light trails.
Season or weather change. Restoration and colorization. Line-art or coloring-page conversion.
Flat-vector avatar. Action-figure or scale-figurine treatment of a person or object.

## 20. Worked prompts

Full-length examples. The length and word choice are the payload; read them for calibration, not to
copy verbatim.

**Photorealistic portrait** `[OpenAI]`:
`Create a photorealistic candid photograph of an elderly sailor standing on a small fishing boat. He has
weathered skin with visible wrinkles, pores, and sun texture, and a few faded traditional sailor tattoos
on his arms. He is calmly adjusting a net while his dog sits nearby on the deck. Shot like a 35mm film
photograph, medium close-up at eye level, using a 50mm lens. Soft coastal daylight, shallow depth of
field, subtle film grain, natural colour balance. The image should feel honest and unposed, with real
skin texture, worn materials, and everyday detail. No glamorization, no heavy retouching.`

Note the shape: subject with material detail, then action, then camera, then light, then mood, then two
negatives. Eight clauses, every one of them a dial.

**Transparent logo** `[OpenAI]`:
`Create an original, non-infringing logo for a company called Field and Flour, a local bakery. The logo
should feel warm, simple, and timeless. Use clean vector-like shapes, a strong silhouette, and balanced
negative space. Favour simplicity over detail so it reads clearly at small and large sizes. Flat design,
minimal strokes, no gradients unless essential. Fully transparent background. Deliver a single centred
logo with generous padding, clean alpha edges, and no solid backdrop, scenery, checkerboard, or
watermark.`

**Pitch-deck slide with data** `[OpenAI]`:
`Create one pitch-deck slide titled "Market Opportunity" that feels like a real Series A fundraising
slide. Use a clean white background, modern sans-serif typography like Inter, and a crisp minimal
layout. Include: a TAM/SAM/SOM concentric-circle diagram in muted blues and greys; market sizing numbers
TAM $42B, SAM $8.7B, SOM $340M; a clean bar chart below showing market growth from 2021 to 2026 with a
subtle upward trend; small footnotes reading "Internal analysis"; a logo placeholder bottom-right. Highly
readable text, clear data hierarchy, polished spacing. Avoid clip art, stock photography, gradients,
shadows, decorative elements, or anything generic.`

**Character turnaround sheet** `[community]`:
`Task: generate a production-ready three-view character sheet. Subject: an original adult woman sky
courier with short indigo hair, an amber flight jacket, teal utility trousers, sturdy boots, and a
compact map satchel. Context: animation preproduction reference for keeping her design consistent across
scenes. Style: clean contemporary 2D animation concept art with crisp linework and restrained cel
shading. Composition: one landscape sheet with equal-size full-body front, left-profile, and back views
on a warm light-grey background, plus one small head close-up. Lighting: neutral soft studio light with
no dramatic cast shadows. Constraints: identical face, body proportions, clothing seams, colours, and
accessories in every view; all figures fully visible inside safe margins; no logos, no readable text, no
watermark.`

**Exploded technical illustration** `[community]`:
`Design a crisp exploded-view product illustration of a custom mechanical keyboard named LUMEN K65,
shown in three-quarter perspective on a pale grey background. Separate the layers clearly: keycaps,
switches, plate, PCB, foam, gasket mounts, case top, battery module, rotary knob, and case bottom. Add
clean technical callouts and in-image text reading "LUMEN K65", "Exploded Assembly", "65% Layout",
"Hot-Swap PCB", and "3,200 mAh". Include labels for "PBT Keycaps", "Linear Switch", "Aluminium Plate",
"Poron Foam", "USB-C", and "Encoder Knob".`

**Knolling flat-lay** `[community]`:
`Create a high-angle top-down knolling photograph of a vintage explorer's travel kit. Arranged neatly on
a weathered wooden table are an old brass compass, a folded leather map, a pocket watch, a fountain pen,
and a pair of binoculars. Everything is aligned at perfect right angles. The lighting is soft and
overhead.`

**Isometric miniature diorama** `[community]`:
`A hyper-realistic isometric miniature diorama encased in a cubic enclosure. The cube has two solid back
walls and two transparent glass front walls, creating a perfect cutaway view. The entire scene is
strictly contained within the cube. Inside is [scene] with [key props, furniture, floor texture, and
specific clutter]. A photorealistic miniature person wearing [clothing] stands within it. All elements
have hyper-realistic textures so it reads as a museum-quality miniature model. [Light sources and mood],
creating cinematic depth within the glass enclosure. Clean solid neutral grey background completely
isolating the cube. Macro photograph from a slightly elevated isometric three-quarter view.`

**Identity-locked garment swap** `[OpenAI]`:
`Edit the image to dress the woman using the provided clothing images. Do not change her face, facial
features, skin tone, body shape, pose, or identity in any way. Preserve her exact likeness, expression,
hairstyle, and proportions. Replace only the clothing, fitting the garments naturally to her existing
pose and body geometry with realistic fabric behaviour. Match lighting, shadows, and colour temperature
to the original photo so the outfit integrates photorealistically without looking pasted on. Do not
change the background, camera angle, framing, or image quality, and do not add accessories, text, logos,
or watermarks.`

**Sprite sheet** `[community]`, adapted:
`Create a 16-bit walk-cycle sprite sheet of the person in Image 1, shown as four frames in a horizontal
row. Keep the recognisable outfit and hair across every frame, with crisp square pixels, a 24-colour
palette, consistent proportions, and clear leg and arm positions for each step. Even spacing on a flat
magenta background, clean outlines, retro side-scroller animation-sheet aesthetic.`

**Short edits that need nothing more** `[OpenAI]`:
`Make it look like a winter evening with snowfall.`
`Remove the flower from the man's hand. Do not change anything else.`
`Change the colour of the red hat to light blue as velvet. Do not change anything else.`
`Translate the text in the infographic to Spanish. Do not change any other aspect of the image.`
`Use the same style from the input image and generate a man riding a motorcycle on a white background.`

Length follows the job. A one-clause edit with a preserve tail is complete. A production asset needs
every dial named. Match the prompt to the work, not to a habit.

## 21. Use-case tips by slug

One paragraph per taxonomy slug. These come from the installed imagegen skill and are the fastest way
to raise a mediocre prompt to a competent one: pick your slug, apply its tip, then add detail from the
banks.

**Generate**

- `photorealistic-natural` — Prompt as if a real photograph were captured in the moment. Photography
  language (lens, lighting, framing), real texture, no glamorization, no studio polish unless asked.
- `product-mockup` — Describe the product and its materials. Clean silhouette, label clarity. If
  in-image text is needed, require verbatim rendering and specify the typography.
- `ui-mockup` — **State the target fidelity first**: shippable mockup or low-fi wireframe. Then layout,
  hierarchy, and practical UI elements. Avoid concept-art language entirely; it drags the result toward
  illustration.
- `infographic-diagram` — Define the audience and the layout flow. Label every part explicitly, require
  verbatim text, and forbid tiny type.
- `scientific-educational` — Define audience, lesson objective, required labels, scientific constraints,
  arrow direction, and scan-friendly whitespace.
- `logo-brand` — Simple and scalable. Strong silhouette, balanced negative space, no decorative
  flourishes unless requested. Say it must read at small size.
- `ads-marketing` — Write it like a creative brief: positioning, audience, desired vibe, scene, and the
  exact tagline if text must appear.
- `productivity-visual` — Name the exact artifact (slide, chart, workflow diagram). Define the canvas
  and hierarchy, provide real labels and data, ask for readable typography and polished spacing.
- `illustration-story` — Define the panels or scene beats and keep each action concrete.
- `stylized-concept` — Specify style cues, material finish, and rendering approach (3D, painterly, clay)
  without inventing story elements the user did not ask for.
- `historical-scene` — State the location and date. Constrain clothing, props, and environment to the
  era, and forbid modern objects.

**Edit**

- `text-localization` — Change only the text. Preserve layout, typography, spacing, and hierarchy. No
  extra words, no reflow.
- `identity-preserve` — Lock face, body, pose, hair, and expression. Change only the named elements.
  Match lighting and shadows. Keep occluders (§1.1).
- `precise-object-edit` — Say exactly what to remove or replace. Preserve surrounding texture and
  lighting. **Name the shadow and the reflection too** — removing an object and leaving its shadow is
  the classic tell.
- `lighting-weather` — Change only environmental conditions: light, shadow, atmosphere, precipitation,
  ground wetness. Keep geometry, framing, and identity. Name the key light direction and demand
  physically consistent shadows, or the edit degenerates into a flat colour grade.
- `background-extraction` — Clean cutout, crisp silhouette, generous padding, no shadows, no halos.
  Preserve label text exactly. No restyling.
- `style-transfer` — Name what is preserved (palette, texture, brushwork) and what changes. Add
  `no extra elements` to prevent drift.
- `compositing` — Reference inputs by index, specify what moves where, match lighting, perspective, and
  scale, and keep the base framing unchanged.
- `sketch-to-render` — Preserve layout, proportions, and perspective. Choose materials and lighting that
  support the sketch without adding elements.

## 22. Recipes

Copy the shape, not the invented detail (§4.3). Each is a prompt body; drop lines that do not apply.

### 22.1 Recipes: web and UI

**Web button** (`ui-mockup`)
```
Use case: ui-mockup
Asset type: web UI component
Primary request: a single primary call-to-action button, default state
Style/medium: realistic product UI, flat modern design system, not concept art
Composition/framing: centred on a plain neutral canvas, generous even padding, nothing cropped
Text (verbatim): "Get started"
Constraints: one component only; crisp 1px borders; consistent corner radius; legible at small size
Avoid: browser chrome; cursors; device frames; logos; watermark
```

**App screen** (`ui-mockup`)
```
Use case: ui-mockup
Asset type: mobile app screen
Primary request: home screen for a local farmers market with vendors and daily specials
Style/medium: realistic shippable product UI, not concept art
Composition/framing: clean vertical mobile layout, clear hierarchy, generous spacing
Constraints: practical layout; clear typography; readable labels
Avoid: logos; trademarks; watermark; decorative illustration
```

**Desktop wireframe** (`ui-mockup`)
```
Use case: ui-mockup
Asset type: website wireframe
Primary request: SaaS homepage layout with clear hierarchy
Style/medium: low-fi grayscale wireframe
Subject: top nav; hero with headline and CTA; three feature cards; testimonial strip; pricing preview; footer
Composition/framing: landscape desktop layout
Constraints: label major blocks
Avoid: colour; logos; real photos; watermark
```

**Landing page hero background** (`stylized-concept`)
```
Use case: stylized-concept
Asset type: landing page hero background
Primary request: minimal abstract background with a soft gradient and subtle texture
Style/medium: matte soft-rendered abstract background
Composition/framing: wide composition, large usable negative space at left for page copy
Lighting/mood: gentle studio glow
Color palette: restrained neutral palette
Constraints: keep the left third visually quiet
Avoid: text; logos; watermark; busy detail
```

**UI icon** (`logo-brand`) — repeat the Style/medium line verbatim across every icon in a set. That
shared line is what makes a set a set.
```
Use case: logo-brand
Asset type: UI icon, rendered large
Primary request: a single outline icon of a calendar
Style/medium: flat monoline vector-style icon, uniform stroke weight, rounded caps, on flat white
Composition/framing: single glyph centred, square canvas, even margins on all four sides
Constraints: one icon only; optically uniform strokes; readable when small; stroke-only, no fill
Avoid: gradients; shadows; text; grid guides
```

### 22.2 Recipes: brand

**Transparent logo mark** (`logo-brand`; see §10)
```
Use case: logo-brand
Asset type: transparent PNG mark
Primary request: an abstract mark suggesting a folded paper crane
Style/medium: clean geometric vector-style mark, single solid colour, strong silhouette
Composition/framing: mark centred, generous even padding, nothing touching the edges
Constraints: balanced negative space; reads as a solid silhouette at small size; one colour only;
  fully transparent background, clean alpha edges
Avoid: text; taglines; gradients; bevels; drop shadows; checkerboard; scenery
```

**Wordmark** (`logo-brand`)
```
Use case: logo-brand
Primary request: clean wordmark for a modern studio
Style/medium: vector wordmark, flat colour, minimal
Text (verbatim): "Studio North"
Composition/framing: centred text, even letter spacing
Constraints: render the name exactly once, spelled exactly as given
Avoid: gradients; mockups; 3D; watermark
```

### 22.3 Recipes: people and photographs

**Restyle a photograph** (`style-transfer`) — one of the highest-value operations here.
```
Use case: style-transfer
Input images: Image 1: the photograph to restyle
Primary request: render this photograph as a Kodak Portra 400 35mm film frame
Style/medium: analog colour-negative aesthetic, creamy warm skin tones, soft pastel highlights,
  gentle rolling contrast, fine natural grain, slightly muted greens
Constraints: maintain the identity; keep the face, likeness, pose, composition, and crop exactly;
  change only the look
Avoid: extra elements; changing the crop; reconstructing anything currently hidden
```
Swap the Style/medium line for any bank entry in §15 or §14 — watercolour, risograph, cel shading,
flat vector, claymation, blueprint, ukiyo-e — and the rest of the recipe holds.

**Change clothing** (`identity-preserve`)
```
Use case: identity-preserve
Input images: Image 1: person photo; Image 2..N: garment references
Primary request: replace only the clothing with the provided garments
Constraints: maintain the identity; preserve face, facial features, skin tone, body shape, pose, hair,
  and expression exactly; fit the garments to the existing pose and body geometry with realistic
  drape, folds, and occlusion; match lighting, shadow, and colour temperature to the original;
  keep the background, camera angle, framing, and image quality unchanged
Avoid: accessories; text; logos; watermark; altering anything currently covering the face
```

**Put a person in a new scene** (`identity-preserve`)
```
Use case: identity-preserve
Input images: Image 1: person photo
Primary request: place this person in [scene], [doing what]
Scene/backdrop: [environment, time of day, weather]
Composition/framing: full body visible, feet included, eye level
Lighting/mood: [named condition] with light from [direction]
Constraints: maintain the identity; preserve face, build, hair, and expression; relight the subject to
  match the new scene's light direction and colour temperature; add a plausible contact shadow
Avoid: cinematic grading; glamorization; removing sunglasses or anything else covering the face
```

**Restore and colorize** (`identity-preserve`)
```
Use case: identity-preserve
Input images: Image 1: damaged photograph
Primary request: full archival restoration, then historically accurate colour
Constraints: repair scratches, stains, folds, and dust; reconstruct damaged areas from surrounding
  detail; period-true colours for [place] in the [decade]; natural skin tones; keep every face, detail,
  and the original composition unchanged; finish with a fine natural grain
Avoid: modernising faces; inventing detail that is not recoverable; cropping
```

### 22.4 Recipes: precise photo edits

**Remove an object** (`precise-object-edit`)
```
Use case: precise-object-edit
Input images: Image 1: source photo
Primary request: remove the coffee cup from the desk
Constraints: reconstruct the wood grain and shadow behind it consistently with the surrounding
  surface; remove the object's cast shadow and any reflection along with the object; every other pixel
  identical to Image 1
Avoid: adding a replacement object; blurring the patch; shifting the crop
```

**Replace an object** (`precise-object-edit`)
```
Use case: precise-object-edit
Input images: Image 1: source photo
Primary request: replace only the mug with a small potted plant of similar size
Constraints: preserve the person, desk layout, camera angle, crop, lighting, and colours exactly;
  match the original shadow direction and contact point
Avoid: text; logos; changing anything outside the mug's footprint
```

**Replace the background** (`precise-object-edit`)
```
Use case: precise-object-edit
Input images: Image 1: source photo
Primary request: replace only the background with a misty pine forest at dawn
Constraints: keep the subject, their clothing, hair, edges, scale, position, and crop exactly as in
  Image 1; match the existing lighting direction and colour temperature on the subject
Avoid: text; watermark; re-lighting or restyling the subject; halos at the edges
```

**Relight** (`lighting-weather`)
```
Use case: lighting-weather
Input images: Image 1: source photo
Primary request: change the scene from midday to golden-hour late afternoon
Constraints: change only light, shadow, and atmosphere; key light from the low west creating long
  shadows and a soft warm rim; shadows must fall physically consistently with that direction; keep
  geometry, framing, crop, subject identity, pose, and every object unchanged; do not shift skin tone
Avoid: moving or adding objects; changing the season; flattening this into a colour grade
```

**Translate the text in an image** (`text-localization`)
```
Use case: text-localization
Input images: Image 1: original infographic
Primary request: replace "Bean Hopper", "Grinder", "Brew Group" with "Tolva", "Molino", "Grupo de infusion"
Constraints: change only the text; preserve layout, typography, weight, colour, size, alignment,
  spacing, and hierarchy; every non-text pixel identical to Image 1
Avoid: extra words; reflowing the layout; altering logos or imagery
```

**Composite two images** (`compositing`)
```
Use case: compositing
Input images: Image 1: base scene and edit target; Image 2: object or subject to insert
Primary request: place the subject from Image 2 into the empty corner of Image 1
Constraints: keep the framing, camera angle, walls, floor, and existing objects of Image 1 unchanged;
  match Image 1's perspective, scale, light direction, shadow softness, and colour temperature on the
  inserted element; add a plausible soft contact shadow
Avoid: changing the base scene; duplicating elements; a hard drop shadow
```

**Sketch to render** (`sketch-to-render`)
```
Use case: sketch-to-render
Input images: Image 1: line drawing
Primary request: render the drawing as a photorealistic product photograph
Style/medium: studio product photography, soft neutral backdrop
Materials/textures: brushed aluminium body, matte rubber grip
Constraints: preserve the layout, proportions, perspective, and every part boundary of the sketch;
  add only material, lighting, and surface detail
Avoid: adding parts not in the sketch; changing proportions; text
```

### 22.5 Recipes: game and animation

**Eight-frame sprite sheet** (`stylized-concept`; §1.1, §10)
```
Use case: stylized-concept
Asset type: 2D sprite sheet
Primary request: an eight-frame run cycle of [character], facing right
Style/medium: crisp 2D game sprite, flat cel shading, hard edges, light from upper left
Composition/framing: a single row of exactly eight frames, evenly spaced, identical scale and
  baseline in every cell, no gutters, no labels, no border
Constraints: readable silhouette; identical character design, palette, and proportions in every frame;
  transparent background
Avoid: motion blur; soft shadows; background scenery; captions; frame numbers
```

**Tileable texture** (`stylized-concept`)
```
Use case: stylized-concept
Asset type: tileable game texture
Primary request: worn sandstone blocks
Style/medium: seamless tileable texture, macro detail
Lighting/mood: uniform diffuse lighting, no directional shadow
Constraints: seamless edges that repeat with no visible seam; no perspective distortion; top view
Avoid: focal elements; text; logos; watermark; baked shadows
```

**Character concept** (`stylized-concept`)
```
Use case: stylized-concept
Asset type: game character concept
Primary request: desert scout character with layered travel gear
Subject: long coat, satchel, practical travel clothing, weathered fabric
Style/medium: character render, stylized realism
Composition/framing: neutral hero pose, full body visible, simple backdrop
Avoid: logos; trademarks; watermark; background scenery
```

### 22.6 Recipes: product

**Catalogue shot** (`product-mockup`)
```
Use case: product-mockup
Asset type: catalogue shot
Primary request: a matte black insulated water bottle, three-quarter view
Style/medium: studio product photography, seamless light grey backdrop
Lighting/mood: soft key from upper left, controlled shadows, clean contact shadow
Materials/textures: matte powder-coat finish, brushed steel lid
Constraints: accurate proportions; clean silhouette; full product visible
Avoid: brand names; label text; studio reflections; props; watermark
```

**Product cutout** (`background-extraction`; §10)
```
Use case: background-extraction
Input images: Image 1: product photo
Primary request: isolate the product on a fully transparent background
Constraints: crisp silhouette; clean alpha edges; no halos or fringing; generous padding; preserve
  product geometry and label legibility exactly; subtle realistic contact shadow in the alpha with no
  hard cut line
Avoid: solid backdrop; checkerboard; scenery; restyling; cropping
```

### 22.7 Recipes: editorial and explanatory

**Infographic** (`infographic-diagram`) — check every glyph before shipping.
```
Use case: infographic-diagram
Asset type: explainer graphic for a blog post
Primary request: a three-step diagram of the water cycle
Style/medium: flat vector infographic, limited palette, generous whitespace
Composition/framing: three panels left to right joined by arrows, title across the top
Text (verbatim): "Evaporation", "Condensation", "Precipitation"
Constraints: render all labels verbatim with no extra characters; readable type
Avoid: any other text; dense small print; clip-art clutter
```

**Pitch-deck slide** (`productivity-visual`)
```
Use case: productivity-visual
Asset type: fundraising slide image
Primary request: one slide titled "Market Opportunity"
Style/medium: clean modern deck slide, white background, crisp sans-serif typography
Subject: TAM/SAM/SOM concentric-circle diagram plus a growth bar chart from 2021 to 2026
Composition/framing: landscape slide, clear data hierarchy, polished spacing
Text (verbatim): "Market Opportunity", "TAM: $42B", "SAM: $8.7B", "SOM: $340M"
Constraints: readable labels; believable data
Avoid: clip art; stock photography; decorative clutter; watermark
```

**Die-cut sticker** (`illustration-story`; §10)
```
Use case: illustration-story
Asset type: die-cut sticker with a white border
Primary request: a cartoon red fox curled up asleep
Style/medium: bold-line sticker illustration, flat saturated colour, thick even white die-cut outline
Composition/framing: single subject centred, generous padding, whole outline visible
Constraints: closed unbroken white border around the whole silhouette; flat colour fills;
  transparent background outside the border
Avoid: text; drop shadow; background scenery; gradient shading
```

## 23. Pitfalls

1. **Under-describing, then blaming the model.** It makes what you say. A thin button description gets a
   guessed button. Full detail in, specific thing out. (§4.3)
2. **Not stating the dimensions you need.** The size line is honoured; leaving it out means accepting
   whatever comes back. State the size and the composition together — one sets the frame, the other
   fills it. (§11)
3. **Forgetting the preserve list, or changing two things in one edit.** Unrepeated constraints drift,
   and a two-part edit hides which half regressed. (§5)
4. **Accepting the model's defaults.** Warm beige grade, waxy skin, cinematic overproduction, invented
   captions. Each costs one clause to prevent and a whole re-run to fix. (§7)
5. **Attaching images without naming roles.** Unlabelled references become edit targets. (§9)
6. **Putting the prompt after the `--image` flags.** The prompt is positional and comes first. (§3)
7. **Not checking generated text glyph by glyph.** (§8)
8. **Trusting reconstructed detail.** Upscale and restore invent. Never use them where the detail is
   the evidence. (§6)
9. **Staging a pipeline the model already handles.** Ask for the outcome plainly before building
   scaffolding for it. (§10)
10. **Chroma-keying hair, glass, or smoke.** It will fringe. Warn before generating, not after. (§10)
11. **Generating a bitmap when the repo has an SVG system**, or overwriting an asset instead of writing
    a sibling version like `hero-v2.png`. (§2)
12. **Iterating past three failures.** Restart from a clean prompt instead. (§5.4)
13. **Removing sunglasses, a mask, or anything else covering a face** on an image where the identity
    matters. The model invents what it cannot see and the likeness is gone. (§1.1, §5.3)
14. **Asking for a sprite cycle that is not eight frames.** Chain eight-frame sheets instead. (§1.1)
15. **Attaching an image without saying why it is there.** It steers the output regardless; an
    undescribed attachment is an instruction you did not write. (§1.1, §9)
16. **Pasting a recipe's invented detail onto a user's brief.** The recipes show shape, not licence to
    add props, palettes, or story beats nobody asked for. (§4.3)

## 24. Confidence and what is unverified

Stated as unknown rather than guessed. Do not present any of these as fact.

**Observed on this exact path**, by inspecting the files rather than trusting a report: a two-image
composite sticker (a person driving a boat towing a water-skiing rooster) on a transparent background
with a die-cut border, first try; two eight-frame sprite sheets, a human run cycle at 3072x1024 and a
rooster kick cycle at 3840x2160, both single-row, both real RGBA, identity holding across all eight
cells in each — with the caveats in §19 about baseline and spacing drift; a transparent logo mark;
a plain `transparent background` request returning real RGBA; canvases of 1024x1024, 3072x1024, and
3840x2160.

**Observed across repeated use** and reported by the tool's owner, which is why §1.1 outranks
documentation: eight is the working frame count for sprite animation; an attached image steers the
output whether or not it is described; identity has to be requested in words; and removing an occluder
from a face makes the model invent the feature underneath and lose the likeness.

**Sourced from OpenAI's published prompting guidance** for the gpt-image family: prompt ordering,
labelled blocks, the change-only idiom and the repeat-the-preserve-list rule, identity-lock phrasing,
multi-image indexing, text-rendering practice, transparency phrasing, the model-strengths list, and the
documented weakness on precise text placement. That guidance describes the same model family reached
here, but it is written for the API surface, which has parameters this path does not.

**Sourced from practitioners** and plausible but unconfirmed here: the warm-and-beige default, the waxy
skin default, the three-failure restart heuristic, the repetition-as-amplifier effect, grid-shape
reliability, isometric spatial phrasing beating numeric angles, sprite-sheet limb confusion, tiling
unreliability, and the outpainting dimension limits.

**The detail banks in §12-18 are borrowed vocabulary, not measured behaviour.** They were harvested
from published guidance and practitioner writing. A term reading well on the page is not evidence the
model honours it: nothing here has isolated whether `Rembrandt lighting` beats `dramatic side light`,
or whether naming `Kodak Portra 400` does more than the words `warm muted film`. Use them as a
checklist of dimensions worth specifying, which is their real value, and do not promise a user that a
particular term is a switch. OpenAI's own caution on the narrowest of these is on record: camera specs
`may be interpreted loosely, so use them mainly for high-level look and composition rather than exact
physical simulation`.

**Corrected since the last revision.** A previous version of this guide claimed composition language
reshapes the returned canvas, citing a 3:1 sprite strip as proof. That was wrong. The prompts carried
explicit `Requested size:` lines, and the canvases matched them exactly — the wording had nothing to do
with it. The error was inferring a cause from a correlation while the actual prompts were not in hand.
What is true is simpler and more useful: stated dimensions are honoured (§11).

**Genuinely unknown:**

- Whether naming the intended use measurably changes polish. It is standard advice and reads as true,
  but nothing here isolates it.
- The practical ceiling on attached images. Five is the documented maximum; three or more has been
  reported as flaky elsewhere.
- Why eight frames is the working number, and where the boundary sits. Nobody has run a four-frame or
  a sixteen-frame sheet to see how it fails. §1.1 is a working rule, not a law.
- How large a requested size can go before it stops being honoured. Three sizes up to 3840x2160 came
  back exact; nothing has probed the ceiling.
- Every §6 operation except transparency, cutouts, and the sprite sheets. They are built from
  documented patterns and community reports, not from runs on this path.
"""


if __name__ == "__main__":
    sys.exit(main())
