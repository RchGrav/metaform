"""Knowledge Tool generation, guidance and shared semantic reads."""
from metaform import knowledge_tool


def get(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "knowledge.get", args)


def explain(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "knowledge.explain", args)


def preview(app, args, context):
    return knowledge_tool.preview(app, args['request'], args.get('model'), args.get('summary', False))


def start(app, args, context):
    return knowledge_tool.start(app, args['request'], args.get('name'), args.get('model'))


def guide(app, state, plan=None):
    from metaform.layers import _states, list_layers

    model = state['model']
    if not model or any(layer['name'] == 'Best Practices' and layer['state'] == 'complete'
                        for layer in list_layers(app, model)):
        return None
    previous = [bundle for item in _states(app) for bundle in item['generations'].values()
                if bundle['layer']['name'] == 'Best Practices' and bundle['generation']['model'] == model]
    running = next((run for bundle in previous
                    if (run := app.load_run(bundle['generation']['run_id']))['status'] == 'running'), None)
    if running:
        return {'status': 'in_progress', 'run': running,
                'next': {'command': 'workflow.next', 'arguments': {'run_id': running['id']}},
                'guidance': 'Resume the existing Best Practices generation and follow its returned assignment.'}
    if previous:
        from metaform.registry import Registry
        if 'layer.regenerate' in Registry(app).visible():
            layer = previous[-1]['layer']
            return {'status': 'incomplete_best_practices', 'next': {'command': 'layer.regenerate', 'arguments': {
                'layer': {'owner': layer['owner'], 'kind': 'layer', 'id': layer['id']}, 'model': model}},
                'guidance': 'Resume the unfinished Best Practices coverage in its existing layer.'}
    return {'status': 'needs_best_practices' if not previous else 'incomplete_best_practices',
            'next': {'command': 'knowledge.start', 'arguments': {
                'request': 'Write 3 best practices', 'name': 'Best Practices', 'model': model}},
            'guidance': 'Generate the Best Practices knowledge layer and follow its assignments through completion.' if not previous
            else 'The earlier Best Practices generation did not complete. Start a new generation to finish onboarding.'}
