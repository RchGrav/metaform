"""Manifest adapters for the shared semantic read contract."""


def inspect(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "element.inspect", args)
