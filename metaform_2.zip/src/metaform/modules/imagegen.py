import asyncio
import dataclasses
import subprocess
import time


async def invoke(app, args, context):
    from . import _imagegen

    try:
        return await asyncio.to_thread(generate, app, args)
    except _imagegen.ImageToolError as exc:
        raise ValueError(str(exc)) from exc


def generate(app, args):
    from . import _imagegen
    from pathlib import Path

    folder = app.project
    run_id = args.get("run_id") or (app.get("mode") or {}).get("run_id")
    if run_id:
        run = app.load_run(run_id)
        request_id = args.get("request_id")
        binding = app.binding or {}
        if not request_id and binding.get("run_id") == run_id:
            request_id = binding.get("request_id")
        job = run.get("pending") or {}
        if request_id:
            job = (run.get("assignments") or {}).get(request_id) or (
                job if job.get("request_id") == request_id else {}
            )
        if job.get("workfolder"):
            folder = Path(job["workfolder"])

    mode = args.get("mode", "generate")
    inputs = []
    if args.get("image"):
        inputs.append(
            _imagegen.ImageInput(
                path=(folder / args["image"]).expanduser().resolve(),
                role="edit-target",
            )
        )
        mode = "edit"
    job = _imagegen.ImageJob(
        prompt=args["prompt"],
        output=(folder / args.get("output", "image.png")).expanduser().resolve(),
        mode=mode,
        inputs=inputs,
    )
    job.validate()
    prompt = _imagegen.build_prompt(job)
    if args.get("dry_run", False):
        return {"prompt": prompt, "generated": False}
    status = _imagegen.require_codex(False)
    app.trace(
        "imagegen.request", {"prompt": prompt, "images": [str(i.path) for i in inputs]}
    )

    def runner(command, **kwargs):
        result = subprocess.run(command, **kwargs)
        app.trace(
            "imagegen.process", {"stdout": result.stdout, "exit": result.returncode}
        )
        return result

    started = time.monotonic()
    _, output = _imagegen.run_codex_image(
        status, prompt, [i.path for i in inputs], job.output, runner=runner
    )
    result = _imagegen.ImageResult(
        str(job.output),
        prompt,
        mode,
        None,
        False,
        round(time.monotonic() - started, 1),
        output[-1500:],
    )
    payload = dataclasses.asdict(result) | {"generated": True}
    app.trace("imagegen", payload)
    return payload
