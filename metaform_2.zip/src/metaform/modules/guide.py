"""The user's agent can retrieve guidance without starting an assignment."""
from metaform.onboarding import guide_state, skill_text


def start(app, args, context):
    return guide_state(app, plan=args.get("plan"), model=args.get("model"))


def skill(app, args, context):
    return {"name": "metaform", "text": skill_text(app)}


async def chassis(app, args, context):
    from metaform.chassis import describe

    return await describe(app)
