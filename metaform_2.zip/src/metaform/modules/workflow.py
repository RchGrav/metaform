import json
import importlib.resources
from pathlib import Path

from metaform.workflow import Engine, import_workflow
from metaform.util import input_value
from metaform.locking import assignment_lock
from metaform.prompts import semantic_equations, assemble, grounding_context
from metaform.modules.graph import search as graph_search, get as graph_get, put as put


def _semantic_arguments(app, args):
    binding = app.binding or app.get("mode") or {}
    identifier = (app.binding or {}).get("run_id") or args.get("run_id") or binding.get("run_id")
    run = app.load_run(identifier) if identifier else {}
    job = run.get("pending") or {}
    grounding = run.get("grounding", {})
    model = args.get("model") or job.get("model") or grounding.get("model")
    if model is None:
        return None
    selected = {key: value for key, value in args.items() if key not in {"run_id", "id"}}
    selected["model"] = model
    if args.get("id") is not None:
        selected.setdefault("target", args["id"])
    return selected


def _semantic_read(app, operation, args):
    from metaform.read_model import read_model
    result = read_model(app, operation, _semantic_arguments(app, args) or args)
    binding = app.binding or app.get("mode") or {}
    identifier = (app.binding or {}).get("run_id") or args.get("run_id") or binding.get("run_id")
    if identifier:
        from metaform.locking import snapshot_lock, lock
        from metaform.util import digest
        with snapshot_lock(app), lock(app, "run:" + identifier):
            run = app.load_run(identifier)
            run.setdefault("semantic_reads", []).append({"request_id": (run.get("pending") or {}).get("request_id"), "result": result})
            dependencies = {digest(item): item for item in run.get("context_dependencies", [])}
            dependencies.update({digest(item): item for item in result["dependencies"]})
            run["context_dependencies"] = list(dependencies.values())
            app.save_run(run)
    return result


def search(app, args, context):
    selected = _semantic_arguments(app, args)
    if selected is None:
        return graph_search(app, args, context)
    if selected.get("query", "*") == "*":
        selected["query"] = ""
    return _semantic_read(app, "model.search", {**args, **selected})


def get(app, args, context):
    selected = _semantic_arguments(app, args)
    if selected is None:
        return graph_get(app, args, context)
    read_args = {**args, **selected}
    result = _semantic_read(app, "model.inspect", read_args)
    kind = result.get("resolved_target", {}).get("kind")
    operation = {"type": "type.inspect", "element": "element.inspect", "join": "join.inspect"}.get(kind)
    return _semantic_read(app, operation, read_args) if operation else result


def ground(app, args, context):
    return _semantic_read(app, "model.ground", args)


def knowledge(app, args, context):
    return _semantic_read(app, "knowledge.get", args)


def explain(app, args, context):
    return _semantic_read(app, "knowledge.explain", args)


def import_file(app, args, context):
    text = Path(args["path"]).read_text(encoding="utf-8")
    try:
        document = json.loads(text)
    except json.JSONDecodeError:
        document = text
    if isinstance(document, dict):
        document = dict(document, base_dir=str(Path(args["path"]).resolve().parent))
    return import_workflow(app, document)


def _catalog_records(app):
    if hasattr(app, "_reference_graphs"):
        for scope, graph in app._reference_graphs.items():
            for identifier, record in graph.get("elements", {}).items():
                yield scope, {"id": identifier, **record}
        return
    if not getattr(app, "_reference_only", False):
        for scope, graph in (("global", app.global_graph), ("project", app.graph)):
            for record in graph.search("workflow:*"):
                yield scope, record
        return
    from metaform.util import read_json

    if app.knowledge_mode == "service":
        database = app.home / "service" / "knowledge.sqlite3"
        if database.is_file():
            with app.reference_db(database) as db:
                for owner in ("global", "project:" + app.project_id):
                    for description, body in db.execute(
                        "SELECT entity_desc,entity_json_obj FROM elements WHERE owner=? AND entity_schema='metaform:workflow'", (owner,)
                    ):
                        yield ("global" if owner == "global" else "project"), {
                            "entity_desc": description, "entity_schema": "metaform:workflow", "entity_json_obj": json.loads(body),
                        }
        return
    from metaform.backends import graph_suffix
    backend = app.config.get("graph_backend", "sqlite")
    suffix = graph_suffix(backend)
    for scope, directory in (("global", app.home / "inference"), ("project", app.root)):
        path = directory / ("metaform" + suffix)
        if not path.exists():
            continue
        if backend == "json":
            records = read_json(path, {}).get("elements", {}).values()
        else:
            with app.reference_db(path) as db:
                records = [{"entity_desc": description, "entity_schema": "metaform:workflow", "entity_json_obj": json.loads(body)}
                           for description, body in db.execute(
                               "SELECT entity_desc,entity_json_obj FROM elements WHERE entity_schema='metaform:workflow'")]
        for record in records:
            yield scope, record


def catalog(app, args, context):
    from metaform.workflow_library import entries

    workflows = {}
    for entry in entries():
        identifier = entry["id"]
        workflows[identifier] = {
            "id": identifier, "intent": entry["intent"], "scope": "bundled", "inputs": entry.get("inputs"),
            "source_revision": entry["source_revision"], "workflow_revision": entry["workflow_revision"],
            "unresolved_requirements": entry.get("unresolved_requirements", []),
            "execution_requirements": entry.get("execution_requirements", []),
            "start": {"command": "workflow.start", "arguments": {"id": identifier}},
            "reference": {"command": "workflow.inspect", "arguments": {"id": identifier}},
        }
    for scope, record in _catalog_records(app):
        if record.get("entity_schema") != "metaform:workflow":
            continue
        definition = record["entity_json_obj"]
        identifier = definition["id"]
        workflows[identifier] = {
            "id": identifier, "intent": definition.get("intent", record["entity_desc"]),
            "scope": scope, "inputs": definition.get("inputs"),
            "unresolved_requirements": definition.get("unresolved_requirements", []),
            "execution_requirements": definition.get("execution_requirements", []),
            "start": {"command": "workflow.start", "arguments": {"id": identifier}},
            "reference": {"command": "workflow.inspect", "arguments": {"id": identifier}},
            **({"source_revision": definition["library"]["source_revision"],
                "workflow_revision": definition["library"]["workflow_revision"]} if definition.get("library") else {}),
        }
    return {"workflows": [workflows[key] for key in sorted(workflows)]}


def progress(app, args, context):
    """Read a selected execution subtree, or follow one exact result reference."""
    from metaform.locking import snapshot_lock

    identifier = run_id(app, args)
    with snapshot_lock(app):
        with app.db() as db:
            runs = {run["id"]: run for (body,) in db.execute("SELECT body FROM runs")
                    for run in [json.loads(body)]}
            selected_ids, pending_ids = [], [identifier]
            while pending_ids:
                candidate = pending_ids.pop(0)
                if candidate in selected_ids:
                    continue
                selected_ids.append(candidate)
                pending_ids.extend(key for key, child in runs.items() if child.get("parent") == candidate)
            if args.get("result_request_id"):
                for result_run, body in db.execute(
                    "SELECT run_id,body FROM events WHERE kind='answer' "
                    "AND json_extract(body,'$.request_id')=? ORDER BY rowid DESC",
                    (args["result_request_id"],),
                ):
                    if result_run in selected_ids:
                        return {"run_id": result_run, **json.loads(body)}
                raise ValueError("No recorded answer for that request in the selected subtree")
            root = runs[identifier]
            selected = []
            for identifier in selected_ids:
                run = runs[identifier]
                frames = [{"workflow": frame["workflow"], "current_step": frame["step"],
                           "steps": [{"id": step["id"], "kind": step.get("kind", "prompt"),
                                      "role": step.get("role"), "workflow": step.get("workflow"),
                                      "next": step.get("next"),
                                      "transitions": [edge.get("to") for edge in step.get("transitions", [])]}
                                     for step in frame["definition"]["steps"]],
                           "completed_steps": list(frame["steps"])} for frame in run.get("stack", [])]
                answers = []
                for request_id, step, role in db.execute(
                    "SELECT json_extract(body,'$.request_id'),json_extract(body,'$.step'),json_extract(body,'$.role') "
                    "FROM events WHERE run_id=? AND kind='assignment' ORDER BY rowid", (identifier,),
                ):
                    if request_id in run.get("receipts", {}):
                        answers.append({"request_id": request_id, "step": step, "role": role,
                                        "reference": {"command": "workflow.progress", "arguments": {
                                            "run_id": root["id"], "result_request_id": request_id}}})
                pending = run.get("pending") or {}
                selected.append({"run_id": identifier, "parent": run.get("parent"),
                                 "workflow": run.get("workflow"), "status": run["status"], "frames": frames,
                                 "pending": {key: pending[key] for key in ("request_id", "step", "role", "status") if key in pending},
                                 "answers": answers})
    return {"root_run_id": root["id"], "scope": "selected run and descendants", "runs": selected}


def inspect(app, args, context):
    return Engine(app).definition(args["id"])


def start(app, args, context):
    return Engine(app).start(
        args["id"],
        args.get("inputs", {}),
        exclusive=args.get("exclusive", True),
        workfolder=args.get("workfolder", False),
    )


def project_path(app, args):
    from metaform.workfolders import get

    run = app.load_run(run_id(app, args))
    return (
        Path(get(app, run["workfolder_id"])["path"])
        if run.get("workfolder_id")
        else app.project
    )


def files(app, args, context):
    from metaform.modules.intake import project_files

    return project_files(project_path(app, args), app.home)


def read(app, args, context):
    project = project_path(app, args)
    path = (project / args["path"]).resolve()
    if not path.is_relative_to(project):
        raise ValueError("The file is outside the workflow workfolder")
    return {"path": args["path"], "text": path.read_text(encoding="utf-8")}


def run_id(app, args):
    if app.binding:
        for key in ("run_id", "request_id"):
            if args.get(key) is not None and args[key] != app.binding.get(key):
                raise ValueError(f"Explicit {key} conflicts with the bound assignment")
    return (app.binding or {}).get("run_id") or args.get("run_id") or (app.get("mode") or {})["run_id"]


def next(app, args, context):
    return Engine(app).next(run_id(app, args), (app.binding or {}).get("request_id"))


def answer(app, args, context):
    if not app.binding and not args.get("run_id"):
        raise ValueError("An answer requires an explicit run_id or a nonce-bound assignment")
    identifier = run_id(app, args)
    request = (
        (app.binding or {}).get("request_id") or args.get("request_id")
        or app.load_run(identifier)["pending"]["request_id"]
    )
    return Engine(app).submit(identifier, request, args["answer"])


def recurse(app, args, context):
    return Engine(app).recursive(run_id(app, args), args.get("inputs"))


async def drive(app, args, context):
    from metaform.harness import execute, with_execution_policy
    from metaform.registry import Registry

    engine = Engine(app)
    identifier = run_id(app, args)
    bound_request = (app.binding or {}).get("request_id")
    count = 0
    while args.get("steps") is None or count < args["steps"]:
        job = engine.next(identifier, bound_request)
        if job["status"] in {"awaiting_parallel", "awaiting_user"}:
            return job
        if job["status"] in {"complete", "aborted", "failed"}:
            return job
        if job["status"] == "running":
            count += 1
            import asyncio

            await asyncio.sleep(0)
            continue
        if job["status"] != "awaiting_tool" and args.get("harness", "mcp") == "mcp":
            if context:
                return await with_execution_policy(app, job, lambda: context.sample(job, "workflow.answer"), (Exception,))
            return job | {"execution": {
                "status": "not_started",
                "reason": "The mcp harness needs an AI client's sampling context; this CLI call has none.",
                "next": "Connect a sampling-capable MCP client, select a configured harness with --harness, or begin the nonce and submit the answer.",
            }}
        async with assignment_lock(app, job["request_id"]) as acquired:
            if not acquired:
                return {
                    "run_id": identifier,
                    "request_id": job["request_id"],
                    "status": "executing",
                }
            receipt_key = "execution:" + job["request_id"]
            result = app.get(receipt_key)
            if result is None:
                if job["status"] == "awaiting_tool":
                    result = {
                        "status": "answered",
                        "answer": await Registry(app).call(
                            job["tool"], job["arguments"], context, internal=True
                        ),
                    }
                else:
                    result = await execute(app, job, args["harness"])
                if result["status"] != "answered":
                    return result
                app.set(receipt_key, result)
            receipt = engine.submit(identifier, job["request_id"], result["answer"])
            if bound_request:
                return receipt
        count += 1
    return engine.next(identifier, bound_request)


def _grounded_step(app, document, grounding, source, role):
    """Bind the source task and its common semantic context to the Engine step."""
    import copy
    from metaform import prompts, schemas
    from metaform.util import digest

    step = document["steps"][0]
    values = {key: value["literal"] for key, value in step.get("inputs", {}).items()}
    values.pop("metaform", None)
    values.pop("instruction", None)
    values.pop("source", None)
    values.update(source_instruction=copy.deepcopy(source), model=grounding["model"], region=grounding["region"],
                  applicable_knowledge=[item["ref"] for item in grounding["region"]["records"] if item.get("explanation")],
                  semantic_equations=semantic_equations())
    prepared = prompts.compose_role(app, "ground-and-specialize", values)
    original_prompt = prompts.get(app, step["prompt_ref"])
    data = json.loads((importlib.resources.files("metaform") / "data" / "prompts.json").read_text())
    builtin = {item["id"]: item for item in data}.get(step["prompt_ref"], {})
    source_override = (role != "lexicalize" or original_prompt["text"] != builtin.get("text")
                       or bool(original_prompt.get("rule_codes"))
                       or original_prompt.get("schema") != builtin.get("schema"))
    if source_override:
        original = prompts.snapshot(app, step["prompt_ref"])
        prepared.update(original)
        prepared["provenance"] = {"managed": original_prompt.get("managed"),
                                  "authored_override": original_prompt["text"] != builtin.get("text")}
        prepared["prompt"] = "\n\n".join([original["source_prompt"], *(item["text"] for item in prepared["components"])])
        prepared["schema_ref"] = step["schema"]
        prepared["schema"] = schemas.bundled(app, step["schema"])
        prepared["output_schema"] = schemas.registry(app)[step["schema"]] if isinstance(step["schema"], str) else copy.deepcopy(step["schema"])
        prepared["output_schema_revision"] = digest(prepared["output_schema"])
        prepared["composition"]["definition"] = {"prompt": step["prompt_ref"],
            "components": [item["id"] for item in prepared["components"]], "output_schema": step["schema"], "inputs": list(values)}
        prepared["composition"]["revision"] = digest(prepared["composition"]["definition"])
    prepared.update({key: copy.deepcopy(value) for key, value in grounding.items() if key != "region"})
    step.update(prompt_ref=prepared["prompt_ref"], schema=prepared["schema"], role_snapshot=prepared,
                inputs={key: {"literal": value} for key, value in values.items()},
                tools=["workflow.search", "workflow.get", "workflow.ground", "workflow.knowledge", "workflow.explain"])
    prepared["tool_bindings"] = {"model.search": "workflow.search", "model.ground": "workflow.ground",
                                 "type.inspect / element.inspect / join.inspect": "workflow.get",
                                 "knowledge.get": "workflow.knowledge", "knowledge.explain": "workflow.explain"}
    document.update({key: copy.deepcopy(value) for key, value in grounding.items() if key != "region"})
    document["contract_version"] = "2"
    document["grounding"] = copy.deepcopy(grounding)


def lexicalize(app, args, context):
    grounding = grounding_context(app, args, args["prompt"])
    selected = grounding["region"] if grounding else assemble(app, args["focal"], args.get("depth", 1))
    document = {
        "id": "lexicalize:" + app.identifier(),
        "intent": args["prompt"],
        "source_instruction": args["prompt"],
        "focal": args.get("focal"),
        "steps": [
            {
                "id": "lexicalize",
                "kind": "prompt",
                "role": "lexicalizer",
                "intent": args["prompt"],
                "prompt_ref": "prompt:metaform.workflow.lexicalize",
                "inputs": {
                    "instruction": {"literal": args["prompt"]},
                    "metaform": {"literal": selected},
                    "semantic_equations": {"literal": semantic_equations()},
                },
                "schema": {"type": "string"},
            }
        ],
    }
    if grounding:
        _grounded_step(app, document, grounding, args["prompt"], "lexicalize")
    import_workflow(app, document)
    return Engine(app).start(document["id"])


def specialize(app, args, context):
    source = Engine(app).definition(args["id"])
    grounding = grounding_context(app, args, source.get("intent", ""))
    selected = grounding["region"] if grounding else assemble(app, args["focal"], args.get("depth"))
    document = {
        "id": "specialize:" + app.identifier(),
        "source_workflow": source,
        "focal": args.get("focal"),
        "intent": source.get("intent", ""),
        "steps": [
            {
                "id": "specialize",
                "role": "lexicalizer",
                "prompt_ref": "prompt:metaform.workflow.specialize",
                "inputs": {
                    "source": {"literal": source},
                    "metaform": {"literal": selected},
                    "semantic_equations": {"literal": semantic_equations()},
                },
                "schema": "metaform:workflow",
            }
        ],
    }
    if grounding:
        _grounded_step(app, document, grounding, source, "specialize")
    import_workflow(app, document)
    return Engine(app).start(document["id"])


def execution_grammar():
    path = importlib.resources.files("metaform") / "data" / "workflows" / "grammar.json"
    return json.loads(path.read_text(encoding="utf-8"))


def reference(app, args, context):
    return {"module": "workflow", "grammar": execution_grammar(),
            "guidance": "Import executable JSON with workflow.import, or convert source prose with workflow.convert and apply its completed result with workflow.apply. Discover packaged and imported procedures with workflow.list; workflow.inspect includes source and unresolved authored operations."}


def convert(app, args, context):
    source = args["source"]
    identifier = "convert:" + app.identifier()
    grounding = grounding_context(app, args, source if isinstance(source, str) else source.get("intent", ""))
    document = {
        "id": identifier,
        "source_instruction": source,
        "focal": args.get("focal"),
        "intent": source if isinstance(source, str) else source.get("intent", ""),
        "steps": [
            {
                "id": "convert",
                "prompt_ref": "prompt:metaform.workflow.convert",
                "schema": "metaform:workflow",
                "inputs": {
                    "source": {"literal": source},
                    "semantic_equations": {"literal": semantic_equations()},
                    "metaform": {
                        "literal": grounding["region"] if grounding else (assemble(app, args["focal"])
                        if args.get("focal") else {})
                    },
                    "execution_grammar": {"literal": execution_grammar()},
                },
            }
        ],
    }
    if grounding:
        _grounded_step(app, document, grounding, source, "convert")
    import_workflow(app, document)
    return Engine(app).start(identifier, exclusive=False)


def apply(app, args, context):
    import copy

    run = app.load_run(args["run_id"])
    definition = Engine(app).definition(run["workflow"])
    if run["status"] != "complete":
        raise ValueError("Complete the specialization run before applying its result")
    steps = run["result"]["steps"]
    if "convert" in steps:
        document = copy.deepcopy(steps["convert"])
        source = {"id": run["workflow"], "prompt": definition["source_instruction"]}
        document["id"] = args.get("id") or document.get("id", "converted:" + run["id"])
        document["source_instruction"] = definition["source_instruction"]
    elif "specialize" in steps:
        from metaform.prompts import get as get_prompt

        document = copy.deepcopy(steps["specialize"])
        source = definition["source_workflow"]
        document["id"] = args.get("id") or source["id"] + ":specialized:" + run["id"]
        source_steps = {step["id"]: step for step in source["steps"]}
        source_references = {
            step["prompt_ref"] for step in source["steps"] if step.get("prompt_ref")
        } | {prompt["id"] for prompt in source.get("prompts", [])}
        remapped = {}
        for prompt in document.get("prompts", []):
            reference = prompt["id"]
            if reference in source_references:
                remapped[reference] = "prompt:" + document["id"] + ":" + reference
                prompt["id"] = remapped[reference]
        for step in document["steps"]:
            original = source_steps.get(step["id"], {})
            reference = step.get("prompt_ref")
            if reference in remapped:
                step["prompt_ref"] = remapped[reference]
                continue
            if (
                reference
                and reference == original.get("prompt_ref")
                and "prompt" in step
                and step["prompt"] != original.get("prompt")
            ):
                prompt = copy.deepcopy(get_prompt(app, reference))
                step["prompt_ref"] = "prompt:" + document["id"] + ":" + step["id"]
                prompt.update(id=step["prompt_ref"], text=step["prompt"])
                document.setdefault("prompts", []).append(prompt)
    elif "lexicalize" in steps:
        source = {"id": run["workflow"], "prompt": definition["source_instruction"]}
        document = {
            "id": args.get("id") or run["workflow"] + ":applied",
            "intent": definition["intent"],
            "steps": [
                {
                    "id": "act",
                    "prompt": steps["lexicalize"]["instruction"] if definition.get("contract_version") == "2" and isinstance(steps["lexicalize"], dict) else steps["lexicalize"],
                    "template": False,
                    "focal": definition["focal"],
                }
            ],
        }
    else:
        raise ValueError("This run has no specialization result")
    if definition.get("grounding"):
        document["grounding"] = copy.deepcopy(definition["grounding"])
        document.update({key: copy.deepcopy(definition[key]) for key in ("model", "targets", "context_ref", "context_dependencies")})
        document["source_instruction"] = copy.deepcopy(definition.get("source_instruction", definition.get("source_workflow")))
        document["semantic_reads"] = copy.deepcopy(run.get("semantic_reads", []))
        from metaform.util import digest
        dependencies = {digest(item): item for item in [*document["context_dependencies"], *run.get("context_dependencies", [])]}
        document["context_dependencies"] = list(dependencies.values())
        document["grounding"]["context_dependencies"] = copy.deepcopy(document["context_dependencies"])
        document["grounding"]["context_reads"] = [copy.deepcopy(item["result"]) for item in document["semantic_reads"]]
    result = import_workflow(app, document)
    app.graph.put(
        {
            "elements": {
                "prompt:" + run["id"]: {
                    "entity_desc": document.get("intent", document["id"]),
                    "entity_schema": "metaform:provenance",
                    "entity_json_obj": {
                        "source": source,
                        "specialized": document,
                        "references": [definition["focal"]]
                        if definition.get("focal")
                        else [],
                        "run_id": run["id"],
                    },
                }
            },
            "joins": [
                {
                    "object_id": "workflow:" + document["id"],
                    "element_id": "workflow:" + source["id"],
                    "type": "specialization",
                    "participants": [
                        {"role": "source", "ref": "workflow:" + source["id"]},
                        {"role": "specialized", "ref": "workflow:" + document["id"]},
                        *(
                            [{"role": "subject", "ref": definition["focal"]}]
                            if definition.get("focal")
                            else []
                        ),
                    ],
                }
            ],
        },
        "workflow",
        "provenance",
    )
    return result


async def raw(app, argv, context):
    if argv[:1] == ["call"]:
        if len(argv) < 2:
            raise ValueError("Use call <workflow operation> <JSON or @file>")
        from metaform.registry import Registry

        return await Registry(app).call(
            "workflow." + argv[1], input_value(" ".join(argv[2:])) or {}, context
        )
    if not argv or argv == ["next"]:
        return next(app, {}, context)
    if argv[0] == "drive":
        if len(argv) > 3:
            raise ValueError("Use drive [harness] [steps]")
        return await drive(
            app,
            {
                "harness": argv[1] if len(argv) > 1 else "mcp",
                **({"steps": int(argv[2])} if len(argv) > 2 else {}),
            },
            context,
        )
    if argv[0] in {"get", "search"}:
        return globals()[argv[0]](
            app, {"id" if argv[0] == "get" else "query": " ".join(argv[1:])}, context
        )
    if argv[0] == "put":
        return put(app, {"graph": input_value(" ".join(argv[1:]))}, context)
    if argv[0] == "apply":
        if len(argv) != 2:
            raise ValueError("Use apply <run_id>")
        return apply(app, {"run_id": argv[1]}, context)
    if argv[0] == "answer":
        return answer(app, {"answer": input_value(" ".join(argv[1:]))}, context)
    raise ValueError(f"Unknown workflow input: {' '.join(argv)}. Use workflow --help for commands.")
