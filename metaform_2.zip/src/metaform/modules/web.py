def _retire_legacy_viewer(app, state):
    """Retire only this project's recorded, still-identifiable old viewer."""
    import json
    import time
    import urllib.request
    from pathlib import Path
    from metaform.util import read_json

    if not state or not state.get("id"):
        return
    stem = "viewer-" + state["id"]
    ready, stop = app.root / (stem + ".ready"), app.root / (stem + ".stop")
    if (Path(state.get("ready", "")).resolve() != ready.resolve()
            or Path(state.get("stop", "")).resolve() != stop.resolve()):
        return
    try:
        record = read_json(ready)
        if not record or record.get("url") != state.get("url"):
            return
        with urllib.request.urlopen(state["url"].rstrip("/") + "/api/health", timeout=1) as response:
            health = json.load(response)
        if (health.get("product") != "metaform-viewer"
                or health.get("instance_id") != record.get("instance_id", stem)):
            return
    except (OSError, json.JSONDecodeError):
        return
    stop.touch()
    for _ in range(100):
        if not ready.exists():
            return
        time.sleep(.05)
    raise ValueError("The old project viewer is still stopping: " + str(ready))


DEFAULT_PORT = 8642


def configured_port(app):
    """The one port the web interface listens on: the home's web_port setting, else the default."""
    return int(app.config.get("web_port", DEFAULT_PORT))


def _taken(port):
    import socket

    with socket.socket() as probe:
        probe.settimeout(0.5)
        return probe.connect_ex(("127.0.0.1", port)) == 0


async def start(app, args, context):
    """Start the service on the configured port when it is not up, open this project, return its URL."""
    import asyncio
    from metaform.service import ServiceError, open_viewer, restart_service

    port = configured_port(app)
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        result = owner.open_viewer(app.project, app.home, "127.0.0.1", port)
    else:
        def open_here():
            try:
                return open_viewer(app.project, app.home, "127.0.0.1", port)
            except ServiceError as error:
                if error.code == "restart_required":
                    restart_service(app.home, port=port)
                    return open_viewer(app.project, app.home, "127.0.0.1", port)
                if _taken(port):
                    raise ValueError(
                        f"Port {port} is in use by another program. Set web_port in the home config to a free port: "
                        f"metaform system configure --scope home --settings '{{\"web_port\": <port>}}'") from error
                raise
        result = await asyncio.to_thread(open_here)
    previous = app.get("viewer")
    if previous:
        await asyncio.to_thread(_retire_legacy_viewer, app, previous)
        app.set("viewer", None)
    return result


async def status(app, args, context):
    """Whether the web interface is up, and where."""
    import asyncio
    from metaform.service import service_status

    result = await asyncio.to_thread(service_status, app.home)
    result["configured_port"] = configured_port(app)
    if result.get("ready"):
        result["url"] = f"http://{result['host']}:{result['port']}"
    return result


async def stop(app, args, context):
    import asyncio
    from metaform.service import stop_service

    owner = getattr(app, "_service_owner", None)
    return owner.request_stop() if owner is not None else await asyncio.to_thread(stop_service, app.home)


def report(app, args, context):
    import json

    with app.db() as db:
        runs = [
            dict(r)
            for r in db.execute(
                "SELECT id,workflow,status,updated FROM runs ORDER BY updated DESC"
            )
        ]
        events = [
            dict(r) | {"body": json.loads(r["body"])}
            for r in db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 100")
        ]
    from metaform.models import capture_model, list_models

    for run in runs:
        if run["status"] == "failed":
            run["failure"] = (app.load_run(run["id"]).get("result") or {}).get("failure")
    records = app.graph.export()["elements"]
    actuals = {(record.get("owner", "project:" + app.project_id), identifier)
               for identifier, record in records.items()
               if record.get("entity_schema") == "metaform:actual-element"}
    types = {(record.get("owner", "project:" + app.project_id), identifier)
             for identifier, record in records.items()
             if record.get("entity_schema") == "metaform:element"}
    for model in list_models(app):
        snapshot = capture_model(app, model)
        actuals.update((record["owner"], identifier) for identifier, record in snapshot["elements"].items())
        types.update((record["owner"], identifier) for identifier, record in snapshot["types"].items())
    stats = app.graph.stats() | {"elements": len(actuals), "types": len(types)}
    return {"stats": stats, "runs": runs, "events": events, **_pending(app, runs)}


def _pending(app, runs):
    from metaform.registry import Registry

    available = Registry(app).visible()
    assignments = []
    continuations = []
    for run in runs:
        if run["status"] != "running":
            continue
        state = app.load_run(run["id"])
        jobs = dict(state.get("assignments") or {})
        if state.get("pending"):
            jobs[state["pending"]["request_id"]] = state["pending"]
        assignments.extend(jobs.values())
        if not jobs:
            commands = {receipt["next"] for receipt in (state.get("receipts") or {}).values()
                        if isinstance(receipt.get("next"), str)}
            command = next(iter(commands)) if len(commands) == 1 else None
            if command is None:
                module = state.get("kind") or ("workflow" if state.get("stack") else None)
                command = module + ".next" if module else None
            continuation = {"run_id": run["id"], "workflow": run["workflow"], "status": "Continue required"}
            if isinstance(command, str) and command in available:
                continuation["next"] = {"command": command, "arguments": {"run_id": run["id"]}}
            else:
                continuation["guidance"] = "Open Metaform for this project to inspect the run and its available continuation."
            continuations.append(continuation)
    return {"assignments": assignments, "continuations": continuations}


def pending(app):
    """Poll handoff identity and continuation without graph, event or prompt payloads."""
    with app.db() as db:
        runs = [dict(row) for row in db.execute(
            "SELECT id,workflow,status FROM runs WHERE status='running' ORDER BY updated DESC")]
    result = _pending(app, runs)
    fields = ("request_id", "run_id", "status", "intent", "step", "module", "workfolder", "begin")
    result["assignments"] = [{key: job[key] for key in fields + (
        ("prompt", "schema") if job.get("status") == "awaiting_user" else ()) if key in job}
        for job in result["assignments"]]
    return result
