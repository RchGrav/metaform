"""Manifest adapters for the shared semantic read contract."""


def browse(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "namespace.browse", args)
