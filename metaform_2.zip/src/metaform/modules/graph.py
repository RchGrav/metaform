from metaform.graph import composed_search
from metaform.util import read_json, write_json


def search(app, args, context):
    return composed_search(app, args.get("query", "*"), args.get("layer"), scope=args.get("scope"))


def get(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    scope = args.get("scope")
    return {
        "id": args["id"],
        "record": graph.get(args["id"], scope=scope),
        "provenance": [o for o in graph.provenance(args["id"]) if scope is None or o["source"] == scope],
        "joins": graph.joins(args["id"], scope=scope),
    }


def browse(app, args, context):
    if hasattr(app, "knowledge"):
        return app.knowledge.call("knowledge.assemble", {"focal": args["id"], **{key: args[key] for key in ("depth", "scope", "category") if key in args}})
    return app.graph.assemble(
        args["id"], args.get("depth"), args.get("scope"), args.get("category")
    )


def put(app, args, context):
    return app.graph.put(
        args["graph"], args.get("source", "native"), args.get("layer", "elements")
    )


def dump(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    result = graph.export(scope=args.get("scope"))
    if args.get("path"):
        from pathlib import Path

        write_json(Path(args["path"]), result)
    return result


def clean(app, args, context):
    return app.graph.clean()


def similarity(app, args, context):
    graph = app.global_graph if args.get("global") else app.graph
    return graph.similarity()


def stats(app, args, context):
    return {"project": app.graph.stats(), "global": app.global_graph.stats()}


def backend(app, args, context):
    from metaform.backends import open_graph, graph_suffix

    name = args.get("name")
    if name is not None:
        graph_suffix(name)
    if getattr(app, "knowledge_mode", None) == "service":
        if name and name != "sqlite":
            raise ValueError("Service knowledge uses SQLite; backend migration applies to legacy projects.")
        return {"knowledge_backend": "sqlite"}
    if getattr(app, "knowledge_mode", None) == "portable":
        return {"backend": "json", "message": "Portable knowledge uses JSON."}
    if not name:
        return {"backend": app.config.get("graph_backend", "sqlite")}
    suffix = graph_suffix(name)
    for old, path in [
        (app.graph, app.root),
        (app.global_graph, app.home / "inference"),
    ]:
        target = open_graph(path / ("metaform" + suffix), name)
        target.put(old.export(), "imported")
    app.config["graph_backend"] = name
    project_config = read_json(app.root / "config.json", {})
    project_config["graph_backend"] = name
    write_json(app.root / "config.json", project_config)
    app.config_sources = dict(getattr(app, "config_sources", {}), graph_backend="project")
    app.__dict__.pop("graph", None)
    app.__dict__.pop("global_graph", None)
    return {"backend": name, "stats": app.graph.stats()}


def neighbors(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "graph.neighbors", args)


def traverse(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "graph.traverse", args)
