from pathlib import Path
import json
import shutil

from metaform.util import digest, write_json
from metaform.workfolders import git


def export(app, args, context):
    from metaform.schemas import registry
    import importlib.resources

    target = Path(args.get("repository", app.project)).resolve()
    graph = app.global_graph.export()
    output = target / "src" / "metaform" / "data" / "global"
    expected = {"elements": set(), "joins": set(), "schemas": set()}
    builtin = json.loads(
        (importlib.resources.files("metaform") / "data" / "schemas.json").read_text()
    )
    for identifier, schema in registry(app, owner="global").items():
        if builtin.get(identifier) == schema:
            continue
        filename = digest(identifier) + ".json"
        expected["schemas"].add(filename)
        write_json(output / "schemas" / filename, schema)
    for identifier, record in graph["elements"].items():
        filename = digest(identifier) + ".json"
        expected["elements"].add(filename)
        observations = [
            o for o in graph["observations"] if o["element_id"] == identifier
        ]
        write_json(
            output / "elements" / filename,
            {"id": identifier, "record": record, "observations": observations},
        )
    for join in graph["joins"]:
        filename = digest(join["id"]) + ".json"
        expected["joins"].add(filename)
        write_json(output / "joins" / filename, join)
    for kind, filenames in expected.items():
        for old in (output / kind).glob("*.json"):
            if old.name not in filenames:
                old.unlink()
    write_index(output)
    return {
        "directory": str(output),
        "elements": len(graph["elements"]),
        "joins": len(graph["joins"]),
        "schemas": len(expected["schemas"]),
    }


def write_index(directory):
    records = {
        kind: [
            json.loads(p.read_text()) for p in sorted((directory / kind).glob("*.json"))
        ]
        for kind in ("elements", "joins", "schemas")
    }
    write_json(
        directory / "index.json",
        {
            "elements": sorted(r["id"] for r in records["elements"]),
            "joins": sorted(r["id"] for r in records["joins"]),
            "schemas": sorted(r["$id"] for r in records["schemas"]),
            "content_hash": digest(records),
        },
    )


def merge(app, args, context):
    target = Path(args.get("repository", app.project)).resolve()
    result = export(app, args, context)
    remote, branch = args.get("remote", "origin"), args.get("branch", "main")
    git(target, "fetch", remote, branch)
    sync_key = "global_sync:" + digest([str(target), remote, branch])
    prior = app.get(sync_key) or "HEAD"
    baseline = git(target, "merge-base", prior, "FETCH_HEAD").strip()
    incoming = git(target, "rev-parse", "FETCH_HEAD").strip()
    worktree = app.home / "sync" / app.identifier()
    worktree.parent.mkdir(parents=True, exist_ok=True)
    git(target, "worktree", "add", "--detach", str(worktree), baseline)
    relative = "src/metaform/data/global"
    destination = worktree / relative
    try:
        # Copy only global records. Source-code commits on the working branch
        # are not ancestors of this data-only contribution.
        for kind in ("elements", "joins", "schemas"):
            for file in (Path(result["directory"]) / kind).glob("*.json"):
                (destination / kind).mkdir(parents=True, exist_ok=True)
                shutil.copy2(file, destination / kind / file.name)
        destination.mkdir(parents=True, exist_ok=True)
        if any(p.is_file() for p in destination.rglob("*")):
            git(worktree, "add", "--", relative)
        changed = git(worktree, "diff", "--cached", "--name-only", "--", relative)
        if changed:
            git(
                worktree,
                "commit",
                "-m",
                args.get("message", "Update global metaform inference"),
                "--",
                relative,
            )
        git(worktree, "merge", "--no-edit", incoming)
        write_index(destination)
        git(worktree, "add", "--", relative)
        if git(worktree, "diff", "--cached", "--name-only", "--", relative):
            git(
                worktree,
                "commit",
                "-m",
                "Index merged global metaform data",
                "--",
                relative,
            )
        git(worktree, "push", remote, f"HEAD:{branch}")
        commit = git(worktree, "rev-parse", "HEAD").strip()
        app.set(sync_key, commit)
    except ValueError as exc:
        app.event("sync.conflict", {"worktree": str(worktree), "error": str(exc)})
        raise ValueError(
            f"Global sync stopped: {exc}. The worktree is retained at {worktree}."
        ) from exc
    git(target, "worktree", "remove", str(worktree))
    return result | {
        "pushed": True,
        "remote": remote,
        "branch": branch,
        "commit": commit,
    }
