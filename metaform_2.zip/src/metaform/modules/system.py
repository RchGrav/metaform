import json

from metaform import schemas, workfolders
from metaform.registry import Registry
from metaform.util import read_json, write_json


def status(app, args, context):
    return {
        "project": str(app.project),
        "mode": app.get("mode"),
        "graph": app.graph.stats(),
        "commands": list(Registry(app).visible()),
    }


def whoami(app, args, context):
    """Each agent is its own server process; this is how a server says which one it is."""
    import os

    from metaform import bindings

    ppid = os.getppid()
    nonce = bindings.linked(ppid, app.home)
    return {
        "folder": str(app.invocation),
        "pid": os.getpid(),
        "ppid": ppid,
        "project": str(app.project),
        "project_id": app.project_id,
        "home": str(app.home),
        "nonce": nonce,
        "binding": app.binding or bindings.lookup(app.invocation, app.home),
    }


def modules(app, args, context):
    from metaform.onboarding import registered_modules
    return {"modules": registered_modules(app)}


def reference(app, args, context):
    return Registry(app).reference(args.get("module"), args.get("command"))


def settings(app, args, context):
    app.refresh_config()
    return app.configuration()


def configure(app, args, context):
    scope = args.get("scope", "home")
    if scope not in {"home", "project"}:
        raise ValueError("Configuration scope must be home or project")
    declarations = {key: shape for settings in Registry(app).settings().values() for key, shape in settings.items()}
    from metaform.schemas import check
    findings = check({"type": "object", "properties": declarations}, args["settings"])
    if findings:
        raise ValueError("; ".join(note["message"] for note in findings))
    for key in args["settings"]:
        declared_scope = declarations.get(key, {}).get("scope")
        if declared_scope and scope != declared_scope:
            raise ValueError(f"Setting {key} belongs to {declared_scope} scope")
    path = (app.home if scope == "home" else app.root) / "config.json"
    from metaform.app import merge_settings
    config = merge_settings(read_json(path, {}), args["settings"])
    write_json(path, config)
    if "debug" in args["settings"]:
        app.set("debug", None)
    app.refresh_config()
    return {"configured": config, "scope": scope, "path": str(path), **app.configuration()}


def debug(app, args, context):
    app.set("debug", args.get("enabled", True))
    app.refresh_config()
    return {"debug": app.get("debug")}


def traces(app, args, context):
    with app.db() as db:
        rows = db.execute(
            "SELECT * FROM events WHERE (? IS NULL OR run_id=?) ORDER BY id",
            (args.get("run_id"), args.get("run_id")),
        ).fetchall()
    return [dict(row) | {"body": json.loads(row["body"])} for row in rows]


def schema_list(app, args, context):
    return schemas.registry(app)


def schema_add(app, args, context):
    return schemas.register(app, args["schema"])


def folder_create(app, args, context):
    return workfolders.create(app, args.get("source"), args.get("empty", False))


def folder_diff(app, args, context):
    return workfolders.diff(app, args["id"])


def folder_apply(app, args, context):
    return workfolders.apply(app, args["id"])


def folder_clean(app, args, context):
    return workfolders.cleanup(app, args["id"])


def forms(app, args, context):
    import importlib.resources

    return json.loads(
        (importlib.resources.files("metaform") / "data" / "forms.json").read_text()
    )
