"""Modules are imported only when a discovered command is dispatched."""
