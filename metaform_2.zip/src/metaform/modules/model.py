"""Manifest adapters for the shared semantic read contract."""


def discover(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "model.discover", args)


def search(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "model.search", args)


def ground(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "model.ground", args)


def compare(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "model.compare", args)


def transform(app, args, context):
    from metaform.transform import apply_transformation
    return apply_transformation(app, args['patch'])


def delete(app, args, context):
    from metaform.transform import delete_record
    return delete_record(app, args['model'], args['target'], preview=args.get('preview', True),
                         **({'reason': args['reason']} if 'reason' in args else {}))


def clone(app, args, context):
    from metaform.transform import clone_model
    return clone_model(app, args['source'], args['destination_model'], args.get('purpose', ''))


def impact(app, args, context):
    from metaform.transform import impact
    return impact(app, args['source'], args['destination'], args.get('mapping', []))


def expand(app, args, context):
    from metaform.expansion import start_expansion
    return start_expansion(app, args['model'], args['target'], args['purpose'])


def inspect(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "model.inspect", args)
