"""Manifest adapters for the shared semantic read contract."""


def list_records(app, args, context):
    from metaform.read_model import read_model
    return read_model(app, "expansion.list", args)
