"""Project registration and client-session selection, separate from assignments."""


class ProjectSession:
    def __init__(self, app):
        self.app = app
        self.sampling_apps = {}

    def select(self, selector):
        self.app = self.app.select_project(selector)
        return selected_context(self.app)


def selected_context(app):
    from metaform.onboarding import instructions
    return app.project_context() | {"instructions": instructions(app)}


def current(app, args, context):
    result = app.project_context()
    if app.knowledge_mode == "service":
        from metaform.service import service_status
        result["service"] = service_status(app.home)
    return result


def list_projects(app, args, context):
    if app.knowledge_mode != "service":
        return [app.project_context()]
    return app.knowledge.call("project.list", {})


def select(app, args, context):
    if app.binding:
        raise ValueError("Project selection cannot change a bound assignment")
    if context is not None and hasattr(context, "select_project"):
        return context.select_project(args["project"])
    return selected_context(app.select_project(args["project"]))


def connect(app, args, context):
    from metaform.service import RemoteKnowledge
    result = RemoteKnowledge(app.home, None).call("project.adopt", {
        "path": str(app.project), "home": str(app.home),
        "name": args.get("name"), "new_copy": args.get("new", False),
    })
    if context is not None and hasattr(context, "select_project"):
        context.select_project(str(app.project))
    return result


def clear(app, args, context):
    """Clear this project's Metaform data so intake starts from nothing: its models, runs, layers, assignments and
    bindings go; the folder, its files and its registration stay."""
    import json
    import shutil
    from pathlib import Path
    from metaform import bindings
    from metaform.util import read_json

    if app.binding:
        raise ValueError("Clear is not available inside a delegated assignment; run it from the project's main folder")
    project = str(app.project)
    cleared = {"models": 0, "elements": 0, "joins": 0, "runs": 0, "assignments": 0, "bindings": 0}
    if app.knowledge_mode == "service":
        cleared.update(app.knowledge.call("project.clear", {}))
    else:
        from metaform.models import HEAD_SCHEMA
        data = app.graph.export()
        cleared.update(models=sum(1 for record in data["elements"].values() if record.get("entity_schema") == HEAD_SCHEMA),
                       elements=len(data["elements"]), joins=len(data["joins"]))
        store = getattr(app.graph, "path", None)
        app.__dict__.pop("graph", None)
        app.__dict__.pop("_knowledge", None)
        if store is not None:
            for candidate in (Path(store), Path(str(store) + ".lock"), Path(str(store) + "-wal"), Path(str(store) + "-shm")):
                candidate.unlink(missing_ok=True)
        (app.root / "schemas.json").unlink(missing_ok=True)
    with app.db() as db:
        cleared["runs"] = db.execute("SELECT count(*) FROM runs").fetchone()[0]
        folders = [row[0] for row in db.execute("SELECT path FROM workfolders")]
        for table in ("runs", "events", "workfolders"):
            db.execute("DELETE FROM " + table)
        db.execute("DELETE FROM state WHERE key != 'debug'")
    for folder in folders:
        path = Path(folder)
        if path.is_dir() and path.resolve().is_relative_to(app.home.resolve()):
            shutil.rmtree(path, ignore_errors=True)
    for directory in {Path(app.config.get("assignment_home", app.home)) / "assignments", app.home / "assignments"}:
        for file in (directory.glob("*.json") if directory.is_dir() else []):
            if (read_json(file, {}) or {}).get("project") == project:
                file.unlink()
                cleared["assignments"] += 1
    cleared["bindings"] = len(bindings.rows(project, homes=[app.home]))
    bindings.clear_matching(lambda body: body.get("project") == project, homes=[app.home])
    app.seed()
    return {"project": project, "cleared": cleared}


def forget(app, args, context):
    """Drop a project from the registry and the projects page; its folder and its knowledge stay."""
    if not args.get("path") and not args.get("missing"):
        raise ValueError("Name --path <folder>, or --missing for every project whose folder is gone")
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        return owner.application.extensions["metaform_forget_projects"](args.get("path"), bool(args.get("missing", False)))
    from metaform.service import forget_projects
    return forget_projects(app.home, args.get("path"), bool(args.get("missing", False)))


def relocate(app, args, context):
    return app.knowledge.call("project.relocate", {"path": args["path"]})


def service_status(app, args, context):
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        return owner.endpoint | {"ready": not owner.stopping.is_set(), "restart_required": False}
    from metaform.service import service_status as status
    return status(app.home)


def service_stop(app, args, context):
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        return owner.request_stop()
    from metaform.service import stop_service
    return stop_service(app.home)


def service_start(app, args, context):
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        endpoint = owner.endpoint
        if args.get("host", "127.0.0.1") != endpoint["host"] or args.get("port", 0) not in (0, endpoint["port"]):
            raise ValueError("Use service restart to change the global listener address")
        return endpoint
    from metaform.service import start_service
    return start_service(app.home, **args)


def service_restart(app, args, context):
    owner = getattr(app, "_service_owner", None)
    if owner is not None:
        return owner.request_restart(**args)
    from metaform.service import restart_service
    return restart_service(app.home, **args)


def bootstrap(argv, selector=None):
    """Handle registration repair and service inspection before opening an App."""
    import argparse
    import os
    from pathlib import Path
    from metaform.app import project_path
    from metaform.util import read_json
    from metaform.service import RemoteKnowledge, service_status, stop_service, start_service, restart_service

    selected = selector or os.environ.get("METAFORM_PROJECT") or Path.cwd()
    parser = argparse.ArgumentParser(prog="metaform " + " ".join(argv[:2]))
    if argv[0] == "service":
        if argv[1] in {"start", "restart"}:
            parser.add_argument("--host", default="127.0.0.1")
            parser.add_argument("--port", type=int, default=0 if argv[1] == "start" else None)
        arguments = vars(parser.parse_args(argv[2:]))
        commands = {"status": service_status, "stop": stop_service,
                    "start": start_service, "restart": restart_service}
        return commands[argv[1]](**arguments)
    project = project_path(selected)
    identity = read_json(project / ".metaform" / "project.json", {})
    config = read_json(project / ".metaform" / "config.json", {})
    portable = identity.get("knowledge_mode") == "portable" or config.get("knowledge_mode") == "portable"
    home = project / ".metaform" / "home" if portable else Path(
        identity.get("service_home") or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform")
    if argv[:2] == ["project", "connect"]:
        parser.add_argument("--new", action="store_true")
        parser.add_argument("--name")
        args = parser.parse_args(argv[2:])
        return RemoteKnowledge(home, None).call("project.adopt", {
            "path": str(project), "home": str(home), "name": args.name, "new_copy": args.new,
        })
    if argv[:2] == ["project", "relocate"]:
        parser.add_argument("--path", required=True)
        args = parser.parse_args(argv[2:])
        identifier = identity.get("project_id")
        if identifier is None and selector:
            import uuid
            try:
                identifier = str(uuid.UUID(str(selector)))
            except ValueError:
                pass
        if identifier is None:
            raise ValueError("This project is not registered with the shared service")
        return RemoteKnowledge(home, identifier).call("project.relocate", {"path": args.path})
    parser.parse_args(argv[2:])
    return service_status(home) if argv[1] == "status" else stop_service(home)
