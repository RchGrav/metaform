"""Outside analysis creates attached knowledge through the layer workflow."""
from metaform.layers import blindspots as start_blindspots


def blindspots(app, args, context):
    return start_blindspots(app, args.get('request', 'Examine this artifact for blind spots.'),
                           args.get('target'), args.get('model'), args.get('name', 'Blind spots'))
