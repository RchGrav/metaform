"""Deterministic semantic projections shared by CLI, MCP, GUI and draft intake."""
from __future__ import annotations

import copy
import json
from collections import deque
from urllib.parse import quote

from .namespace import (IndexedSnapshot, browse_namespace, expanded_aliases, fingerprint, index_records, key,
                        member_bindings, member_counts, paginate, records,
                        reference, resolve_target)


def record_uri(model, ref):
    segments = [model["project"], model["model"], model["revision"], ref["kind"], ref["id"]]
    return "metaform://model/" + "/".join(quote(segment, safe="") for segment in segments) + "?owner=" + quote(ref["owner"], safe="")


def _semantic(value):
    if isinstance(value, dict):
        return {k: _semantic(v) for k, v in value.items() if k not in {"presentation", "svg", "timestamp", "created_at", "updated_at"}}
    if isinstance(value, list):
        return [_semantic(v) for v in value]
    return value


def _selector(operation, target, arguments):
    result = {"kind": operation, "parameters": {k: v for k, v in arguments.items() if k not in {"model", "cursor", "limit", "max_chars", "target"}}}
    if target:
        result["target"] = target
    return result


def _participants(join):
    return [r for r in [join.get("receiver"), join.get("provider"),
                       *[p.get("ref") for p in join.get("participants", [])]] if r]


def _incident(join, focal, direction="both", role=None):
    if role and join.get("role") != role:
        return False
    if direction in ("outgoing", "out", "requirements"):
        return key(join.get("receiver", {})) == key(focal)
    if direction in ("incoming", "in", "receivers"):
        return key(join.get("provider", {})) == key(focal)
    return any(key(ref) == key(focal) for ref in _participants(join))


class Projection:
    def __init__(self, snapshot, operation, arguments):
        self.snapshot = snapshot
        self.index = index_records(snapshot)
        self.operation = operation
        self.args = arguments
        self.dependencies = {}
        self.selectors = []
        self.diagnostics = copy.deepcopy(snapshot.get("diagnostics", []))

    def record(self, ref):
        value = self.index.get(key(ref))
        if value is None:
            self.diagnostics.append({"code": "unresolved_reference", "target": ref})
            return None
        actual_ref = reference(ref["kind"], value)
        self.dependencies[key(actual_ref)] = {"kind": "record", "target": actual_ref,
            "fields": ["*"], "fingerprint": fingerprint(_semantic(value)),
            "reason": "Record supplied or used by this semantic projection."}
        return {"ref": actual_ref, "value": copy.deepcopy(value), "uri": record_uri(self.snapshot["model"], actual_ref)}

    def bundle(self, ref, visited=None):
        """Close a semantic join over participants and its explicit provider facet."""
        visited = set() if visited is None else visited
        if key(ref) in visited:
            return []
        visited.add(key(ref))
        item = self.record(ref)
        if item is None:
            return []
        result = [item]
        if ref["kind"] == "join":
            join = item["value"]
            if not join.get("provider_type"):
                self.diagnostics.append({"code": "unresolved_provider_type", "target": ref})
            for child in _participants(join) + ([join["provider_type"]] if join.get("provider_type") else []):
                result.extend(self.bundle(child, visited))
            bindings = self.snapshot.element_bindings.get(key(join.get("provider", {})), []) if isinstance(self.snapshot, IndexedSnapshot) else records(self.snapshot, "binding")
            for binding in bindings:
                if key(binding["element"]) == key(join.get("provider", {})) and key(binding["type"]) == key(join.get("provider_type", {})):
                    result.extend(self.bundle(reference("binding", binding), visited))
        return result

    def envelope(self, units, target=None, *, extra=None, page=True):
        query = {"operation": self.operation, **{k: v for k, v in self.args.items() if k not in {"model", "cursor"}}}
        bound_query = {k: v for k, v in query.items() if k not in {"limit", "max_chars"}}
        bound_query["target"] = target or self.args.get("target")
        selected, selection_coverage = paginate(units, self.snapshot["model"], bound_query,
            self.args.get("cursor"), self.args.get("limit", 50) if page else max(1, len(units)))
        all_keys = {k for unit in units for k in self.unit_keys(unit)}
        supplied = {}
        for unit in selected:
            unit_records = unit.get("records")
            if unit_records is None:
                unit_records = self.bundle(unit["ref"])
                for ref in unit.get("extra_refs", []):
                    unit_records.extend(self.bundle(ref))
                if unit.get("explanation") and unit_records:
                    unit_records[0]["explanation"] = unit["explanation"]
            for item in unit_records:
                supplied.setdefault(key(item["ref"]), item)
        coverage = {**selection_coverage, "returned": len(supplied), "available": len(all_keys),
                    "selection": selection_coverage}
        selected_refs = [u["ref"] for u in sorted(units, key=lambda u: key(u["ref"]))]
        dependency = {"kind": "selector", "selector": _selector(self.operation, target, self.args),
                      "fingerprint": fingerprint(selected_refs), "reason": "Selection membership, including new matches and absence of matches."}
        result = {"model": self.snapshot["model"], "query": query, "records": list(supplied.values()),
                  "coverage": coverage, "dependencies": list(self.dependencies.values()) + self.selectors + [dependency],
                  "diagnostics": self.diagnostics, "related_operations": []}
        if target:
            result["resolved_target"] = target
        if extra:
            result.update(extra)
        return result

    def selection_dependency(self, kind, target, refs, **parameters):
        self.selectors.append({"kind": "selector", "selector": {"kind": kind, "target": target, "parameters": parameters},
            "fingerprint": fingerprint(sorted(refs, key=key)), "reason": "Membership used to compute this projection, including an empty selection."})

    def unit_keys(self, unit):
        if "records" in unit:
            return {key(item["ref"]) for item in unit["records"]}
        seen = set()
        pending = [unit["ref"], *unit.get("extra_refs", [])]
        while pending:
            ref = pending.pop()
            if key(ref) in seen or key(ref) not in self.index:
                continue
            seen.add(key(ref))
            if ref["kind"] == "join":
                join = self.index[key(ref)]
                pending.extend(_participants(join))
                if join.get("provider_type"):
                    pending.append(join["provider_type"])
                bindings = self.snapshot.element_bindings.get(key(join.get("provider", {})), []) if isinstance(self.snapshot, IndexedSnapshot) else records(self.snapshot, "binding")
                pending.extend(reference("binding", b) for b in bindings
                    if key(b["element"]) == key(join.get("provider", {})) and key(b["type"]) == key(join.get("provider_type", {})))
        return seen

    def unit(self, ref, extra_refs=()):
        return {"ref": ref, "extra_refs": list(extra_refs)}


def _knowledge(snapshot, target, layers=None):
    from .properties import explain_applicability
    matches = []
    for kind, value in [("knowledge", v) for v in records(snapshot, "knowledge")] + [("join", v) for v in records(snapshot, "join") if v.get("role") == "property"]:
        if layers is not None and kind == "knowledge" and not any(
            key(value.get("layer", {})) == key(selected) if isinstance(selected, dict)
            else value.get("layer", {}).get("id") == selected for selected in layers):
            continue
        explanation = explain_applicability(snapshot, target, value, records(snapshot, "knowledge"))
        if explanation.get("applies") or explanation.get("visible_here"):
            matches.append((kind, value, explanation))
    return matches


def read_snapshot(snapshot, operation, arguments=None):
    """Read a published foundation or an explicitly revisioned draft snapshot."""
    args = copy.deepcopy(arguments or {})
    p = Projection(snapshot, operation, args)
    target = args.get("target")
    required_kind = {"namespace.browse": "type", "type.inspect": "type", "type.members": "type", "element.inspect": "element", "join.inspect": "join", "layer.inspect": "layer"}.get(operation)
    # A notable element shares its id with its namespace position; the operation says which one it means.
    sought = {"id": target, "kind": required_kind} if isinstance(target, str) and required_kind else target
    resolution = resolve_target(snapshot, sought) if target is not None else {"ref": None, "via": [], "diagnostics": []}
    focal = resolution["ref"]
    p.diagnostics.extend(resolution["diagnostics"])
    extra = {"resolution": {"via": resolution["via"]}}
    if target is not None and not focal:
        return p.envelope([], extra=extra)
    if required_kind and target is not None and (not focal or focal["kind"] != required_kind):
        p.diagnostics.append({"code": "target_kind_mismatch", "expected": required_kind, "target": target})
        return p.envelope([], focal, extra=extra)
    if operation == "namespace.browse":
        result = browse_namespace(snapshot, sought, cursor=args.get("cursor"), limit=args.get("limit", 50))
        p.diagnostics.extend(result["diagnostics"])
        units = []
        for child in result["records"]:
            item = p.record(child["ref"])
            item.update({"narrowings": child["narrowings"], "counts": child["counts"]})
            for narrowing in child["narrowings"]:
                p.record(reference("narrowing", narrowing))
            p.selection_dependency("type.members", child["ref"], [b["element"] for b in member_bindings(snapshot, child["ref"], True)], descendants=True)
            units.append({"ref": child["ref"], "records": [item]})
        saved_cursor = p.args.pop("cursor", None)
        output = p.envelope(units, focal, extra=extra, page=False)
        if saved_cursor:
            p.args["cursor"] = saved_cursor
        output["coverage"] = result["coverage"]
        output["dependencies"][-1]["fingerprint"] = fingerprint(result["selected_refs"])
        return output
    if operation == "model.search":
        query = str(args.get("query", "")).casefold()
        kinds = {args["kind"]} if args.get("kind") else {"type", "element", "join", "layer"}
        refs = [reference(k[1], value) for k, value in p.index.items() if k[1] in kinds and
                (query in json.dumps(value, ensure_ascii=False).casefold() or k[1] == "type" and
                 any(query in alias["address"]["id"].casefold() for alias in expanded_aliases(value)))]
        output = p.envelope([p.unit(ref) for ref in refs], extra=extra)
        output["groups"] = {kind: [item["ref"] for item in output["records"] if item["ref"]["kind"] == kind] for kind in sorted(kinds)}
        return output
    if operation == "type.members":
        bindings = member_bindings(snapshot, focal, args.get("descendants", False))
        members = {}
        for binding in bindings:
            members.setdefault(key(binding["element"]), [binding["element"], []])[1].extend([reference("binding", binding), binding["type"]])
        extra.update({"scope": "including_descendants" if args.get("descendants") else "direct", "counts": member_counts(snapshot, focal)})
        return p.envelope([p.unit(ref, refs) for ref, refs in members.values()], focal, extra=extra)
    if operation == "type.inspect":
        refs = [reference("narrowing", n) for n in records(snapshot, "narrowing") if key(n["child"]) == key(focal)]
        parent = focal['id'].rpartition('.')[0]
        while parent:
            ref = focal | {'id': parent}
            if key(ref) in p.index:
                refs.append(ref)
            else:
                p.diagnostics.append({'code': 'unresolved_namespace_position', 'id': parent,
                    'owner': focal['owner'], 'child': focal})
            parent = parent.rpartition('.')[0]
        clauses = [j for j in records(snapshot, "join") if key(j.get("provider_type", {})) == key(focal)]
        refs.extend(reference("join", j) for j in clauses)
        p.selection_dependency("type.members", focal, [b["element"] for b in member_bindings(snapshot, focal, True)], descendants=True)
        extra.update({"counts": member_counts(snapshot, focal),
            "clauses": [reference("join", j) for j in clauses if j["receiver"]["kind"] == "type"],
            "witnesses": [reference("join", j) for j in clauses if j["receiver"]["kind"] != "type"]})
        knowledge = _knowledge(snapshot, focal, args.get("layers"))
        extra["knowledge_summaries"] = [{"ref": reference(kind, value), "origin_layer": explanation.get("origin_layer"),
            "applies": explanation["applies"], "visible_here": explanation["visible_here"], "path": explanation["path"]}
            for kind, value, explanation in knowledge]
        for kind, value, explanation in knowledge:
            p.record(reference(kind, value))
        p.selection_dependency("knowledge.get", focal, [reference(kind, value) for kind, value, explanation in knowledge])
        return p.envelope([p.unit(focal, refs)], focal, extra=extra, page=False)
    if operation == "element.inspect":
        bindings = [b for b in records(snapshot, "binding") if key(b["element"]) == key(focal)]
        refs = [ref for b in bindings for ref in (reference("binding", b), b["type"])]
        incident = [j for j in records(snapshot, "join") if _incident(j, focal)]
        p.selection_dependency("graph.neighbors", focal, [reference("join", j) for j in incident], direction="both")
        p.selection_dependency("element.bindings", focal, [reference("binding", b) for b in bindings])
        extra.update({"artifact": snapshot["artifact"], "relationship_counts": {
            "incoming": sum(_incident(j, focal, "incoming") for j in incident),
            "outgoing": sum(_incident(j, focal, "outgoing") for j in incident), "total": len(incident)},
            "expansions": [reference("refinement", r) for r in records(snapshot, "refinement") if key(r["parent"]) == key(focal)],
            "layers": [reference("layer", layer) for layer in records(snapshot, "layer")]})
        return p.envelope([p.unit(focal, refs)], focal, extra=extra, page=False)
    if operation in {"join.inspect", "model.inspect"}:
        if not focal:
            p.diagnostics.append({"code": "missing_target"})
            return p.envelope([], extra=extra)
        return p.envelope([p.unit(focal)], focal, extra=extra, page=False)
    if operation in {"graph.neighbors", "graph.traverse", "model.ground"}:
        if operation == "model.ground" and not focal:
            focal = snapshot["artifact"]
            extra["region_selection"] = "defining_element_orientation"
        else:
            extra["region_selection"] = "explicit_target"
        if not focal:
            p.diagnostics.append({"code": "missing_target"})
            return p.envelope([], extra=extra)
        direction = args.get("direction", "both")
        if direction not in {"both", "incoming", "outgoing", "in", "out", "requirements", "receivers"}:
            raise ValueError("Unknown OP traversal direction")
        depth = 1 if operation == "graph.neighbors" else args.get("depth", 1)
        if not isinstance(depth, int) or isinstance(depth, bool) or depth < 0:
            raise ValueError("depth must be a nonnegative integer")
        starts = [focal]
        if operation == "model.ground" and focal["kind"] == "type":
            starts = list({key(b["element"]): b["element"] for b in member_bindings(snapshot, focal, True)}.values())
            extra["region_selection"] = "type_branch_members"
        queue = deque((ref, 0, []) for ref in starts)
        visited = {key(ref) for ref in starts}
        seen_joins = set()
        units = []
        paths = []
        while queue:
            current, distance, path = queue.popleft()
            if distance >= depth:
                continue
            for join in sorted(snapshot.incident.get(key(current), []) if isinstance(snapshot, IndexedSnapshot) else records(snapshot, "join"), key=lambda j: key(reference("join", j))):
                if not _incident(join, current, direction, args.get("role")):
                    continue
                join_ref = reference("join", join)
                step = {"from": current, "join": join_ref, "depth": distance + 1}
                if key(join_ref) not in seen_joins:
                    seen_joins.add(key(join_ref))
                    units.append(p.unit(join_ref))
                    paths.append({"join": join_ref, "path": path + [step], "depth": distance + 1})
                for participant in _participants(join):
                    if key(participant) not in visited:
                        visited.add(key(participant))
                        queue.append((participant, distance + 1, path + [step]))
        if operation == "model.ground":
            for start in starts or [focal]:
                bindings = [b for b in records(snapshot, "binding") if key(b["element"]) == key(start)]
                units.append(p.unit(start, [ref for b in bindings for ref in (reference("binding", b), b["type"])]))
            for kind, value, explanation in _knowledge(snapshot, focal, args.get("layers")):
                origin_ref = reference(kind, value)
                existing = next((unit for unit in units if key(unit["ref"]) == key(origin_ref)), None)
                if existing is None:
                    existing = p.unit(origin_ref)
                    units.append(existing)
                existing["explanation"] = explanation
                existing["extra_refs"].extend(step["relation"] for path in [explanation.get("path", []), explanation.get("visibility_path", [])] for step in path if isinstance(step.get("relation"), dict))
            extra.update({"orientation": snapshot.get("understanding", "") if isinstance(snapshot.get("understanding", ""), str) else json.dumps(snapshot["understanding"], ensure_ascii=False), "artifact": snapshot["artifact"], "selected_region": starts})
        output = p.envelope(units, focal, extra=extra)
        shown = {key(item["ref"]) for item in output["records"]}
        output["paths"] = [path for path in paths if key(path["join"]) in shown]
        output["related_operations"] = [{"operation": {"element": "element.inspect", "type": "type.inspect", "join": "join.inspect"}.get(focal["kind"], "model.inspect"), "target": focal}]
        if operation == "model.ground":
            max_chars = args.get("max_chars", 24000)
            if not isinstance(max_chars, int) or max_chars < 1:
                raise ValueError("max_chars must be a positive integer")
            # Full bodies are indivisible. A reference handle replaces an oversized body.
            omitted = []
            total = 0
            for item in output["records"]:
                size = len(json.dumps(item, ensure_ascii=False))
                if total + size > max_chars:
                    value = item["value"]
                    item["value"] = {"summary": value.get("summary", value.get("name", value["id"])), "body_omitted": True, "full_content": item["uri"]}
                    omitted.append({"ref": item["ref"], "reason": "compact_context_budget", "uri": item["uri"]})
                total += len(json.dumps(item, ensure_ascii=False))
            output["coverage"]["omitted"] = omitted
            if omitted:
                output["coverage"]["complete"] = False
        return output
    if operation in {"knowledge.get", "knowledge.explain"}:
        if not focal:
            return p.envelope([], extra=extra)
        if operation == "knowledge.explain":
            from .properties import explain_applicability
            wanted = resolve_target(snapshot, args.get("knowledge"))
            p.diagnostics.extend(wanted["diagnostics"])
            matches = []
            if wanted["ref"]:
                origin = p.index[key(wanted["ref"])]
                matches = [(wanted["ref"]["kind"], origin, explain_applicability(snapshot, focal, origin, records(snapshot, "knowledge")))]
        else:
            matches = _knowledge(snapshot, focal, args.get("layers"))
        units = []
        for kind, value, explanation in matches:
            unit = p.unit(reference(kind, value))
            unit["explanation"] = explanation
            path_refs = [step["relation"] for path in [explanation.get("path", []), explanation.get("visibility_path", []), *explanation.get("alternative_paths", [])] for step in path if isinstance(step, dict) and isinstance(step.get("relation"), dict)]
            unit["extra_refs"].extend(path_refs)
            p.diagnostics.extend(explanation.get("diagnostics", []))
            units.append(unit)
        return p.envelope(units, focal, extra=extra)
    if operation == "layer.list":
        return p.envelope([p.unit(reference("layer", layer)) for layer in records(snapshot, "layer")], extra=extra)
    if operation == "layer.inspect":
        return p.envelope([p.unit(focal)], focal, extra=extra, page=False)
    if operation == "expansion.list":
        refs = [reference("refinement", r) for r in records(snapshot, "refinement") if not focal or key(r["parent"]) == key(focal)]
        refs.extend(reference("expansion", r) for r in records(snapshot, "expansion") if not focal or key(r.get("target", {})) == key(focal))
        return p.envelope([p.unit(ref) for ref in refs], focal, extra=extra)
    if operation == "model.discover":
        artifact = p.record(snapshot["artifact"])
        return p.envelope([{ "ref": artifact["ref"], "records": [artifact]}] if artifact else [], extra={"models": [{"model": snapshot["model"], "artifact": snapshot["artifact"], "understanding": snapshot.get("understanding"), "entry_targets": [snapshot["artifact"]]}]})
    raise ValueError(f"Unknown semantic read operation: {operation}")


def read_model(app, operation, arguments=None):
    from .models import capture_model, list_models, resolve_model
    args = arguments or {}
    if operation == "model.discover" and not args.get("model"):
        refs = list_models(app)
        if not refs:
            return {"model": None, "models": [], "query": {"operation": operation}, "records": [],
                    "coverage": {"returned": 0, "available": 0, "complete": True, "next_cursor": None},
                    "dependencies": [{"kind": "selector", "selector": {"kind": "model.discover", "parameters": {"project": app.project_id}},
                        "fingerprint": fingerprint([]), "reason": "No published model matched this project."}],
                    "diagnostics": [{"code": "no_foundation"}], "related_operations": []}
        if refs:
            snapshots = [capture_model(app, ref) for ref in refs]
            result = read_snapshot(snapshots[0], operation, args)
            result["models"] = [read_snapshot(snapshot, operation, args)["models"][0] for snapshot in snapshots]
            return result
    if operation not in {"model.discover", "model.compare", "layer.inspect"}:
        model = resolve_model(app, args.get("model"))
        from .layers import active_attachments, list_layers, selected_layer
        selection = None
        if operation == "layer.list" or operation in {"knowledge.get", "type.inspect", "model.ground"} and "layers" not in args:
            selection = selected_layer(app, model)
        if operation in {"knowledge.get", "type.inspect", "model.ground"} and "layers" not in args and selection:
            args = {**args, "layers": [selection]}
        collections = {"layers": list_layers(app, model), "knowledge": active_attachments(app, model, args.get("layers"))}
        explicit_target = args.get("target", {})
        if operation == "model.inspect" and isinstance(explicit_target, dict) and explicit_target.get("kind") == "knowledge":
            from .layers import get_attachment
            attachment = get_attachment(app, explicit_target, model)
            collections["knowledge"] = [attachment]
        result = app.knowledge.call("model.read", {"model": model, "operation": operation, "arguments": args, "collections": collections})
        if operation == "layer.list":
            result["selected_layer"] = selection
        return result
    snapshot = capture_model(app, args.get("source", args.get("model")))
    try:
        from .layers import active_attachments, inspect_layer, list_layers
    except ImportError:
        pass
    else:
        snapshot = {**snapshot, "layers": list_layers(app, snapshot["model"]), "knowledge": active_attachments(app, snapshot["model"], args.get("layers"))}
        if operation == "layer.inspect":
            resolution = resolve_target(snapshot, args.get("target"))
            target = args.get("target")
            if not resolution["ref"] and target is not None and (not isinstance(target, dict) or target.get("kind", "layer") == "layer"):
                try:
                    retained = inspect_layer(app, target, snapshot["model"])
                except ValueError:
                    pass
                else:
                    snapshot["layers"].append(retained['layer'] | {'removed': retained['removed']})
                    resolution = resolve_target(snapshot, target)
            if resolution["ref"]:
                bundle = inspect_layer(app, target if isinstance(target, dict) else resolution["ref"], snapshot["model"])
                result = read_snapshot(snapshot, operation, args)
                result["layer_context"] = bundle
                return result
    if operation == "model.compare":
        destination = capture_model(app, args["destination"])
        from .transform import effective_mapping
        mappings = copy.deepcopy(args.get("mapping"))
        if mappings is None:
            mappings = []
            for activity in destination.get("activities", []):
                transformation = activity.get("transformation", {})
                if transformation.get("source") == snapshot["model"]:
                    mappings.extend(effective_mapping(snapshot, destination, transformation.get("mapping", []), transformation.get("operations", [])))
        from .models import structural_projection
        source_index, destination_index = index_records(structural_projection(snapshot)), index_records(structural_projection(destination))
        changes = []
        for record_key in sorted(source_index.keys() | destination_index.keys()):
            before, after = source_index.get(record_key), destination_index.get(record_key)
            if _semantic(before) != _semantic(after):
                changes.append({"ref": reference(record_key[1], after or before), "before": before, "after": after,
                                "change": "added" if before is None else "removed" if after is None else "changed"})
        p = Projection(snapshot, operation, args)
        focal = None
        scope = {"kind": "foundation"}
        if args.get("target") is not None:
            resolution = resolve_target(snapshot, args["target"])
            if not resolution["ref"]:
                resolution = resolve_target(destination, args["target"])
            focal = resolution["ref"]
            if not focal:
                p.diagnostics.extend(resolution["diagnostics"])
                return p.envelope([], extra={"source": snapshot["model"], "destination": destination["model"], "changes": [], "layer_impact": None})
            selected = {key(focal): focal}
            for mapping in mappings:
                before, after = mapping.get("from", {}), mapping.get("to", {})
                if key(before) in selected or key(after) in selected:
                    if before:
                        selected[key(before)] = before
                    if after:
                        selected[key(after)] = after
            relation_fields = {"binding": ("element", "type"), "join": ("receiver", "provider", "provider_type"),
                               "refinement": ("parent", "child"), "narrowing": ("parent", "child")}
            def incident_change(change):
                if key(change["ref"]) in selected:
                    return True
                kind = change["ref"]["kind"]
                if kind not in relation_fields:
                    return False
                for value in (change["before"], change["after"]):
                    if value is None:
                        continue
                    refs = [value.get(field, {}) for field in relation_fields[kind]]
                    refs.extend(participant.get("ref", {}) for participant in value.get("participants", []))
                    if any(key(ref) in selected for ref in refs):
                        return True
                return False
            changes = [change for change in changes if incident_change(change)]
            scope = {"kind": "record_and_incident_relations", "targets": list(selected.values()), "mapping": mappings}
        units = [{"ref": change["ref"], "records": [{"ref": change["ref"], "value": change}]} for change in changes]
        result = p.envelope(units, focal, extra={"source": snapshot["model"], "destination": destination["model"], "changes": changes,
            "target_scope": scope, "layer_impact": None}, page=False)
        result["coverage"]["unit"] = "structural_changes"
        result["dependencies"][-1]["fingerprint"] = fingerprint(changes)
        try:
            from .transform import impact
            report = impact(app, snapshot["model"], destination["model"], mappings)
            if focal:
                changed_refs = {key(change["ref"]) for change in changes} | set(selected)
                report["decisions"] = [decision for decision in report.get("decisions", [])
                    if key(decision.get("target", {})) in changed_refs or any(key(reason.get("target", {})) in changed_refs for reason in decision.get("reasons", []))]
                report["changes"] = [change for change in report.get("changes", []) if key(change.get("target", {})) in changed_refs]
            result["layer_impact"] = report
        except ImportError:
            result["diagnostics"].append({"code": "layer_impact_unavailable"})
        return result
    return read_snapshot(snapshot, operation, args)
