from __future__ import annotations

import json
import hashlib
import io
import os
import shutil
import stat
import subprocess
import tarfile
from pathlib import Path

from .util import dumps
from .locking import snapshot_locked


BOOKKEEPING = [".git", ".metaform", ".agentid", "**/.git", "**/.metaform", "**/.agentid"]
ARTIFACT_PATHS = [".", *[":(exclude)" + pattern for pattern in BOOKKEEPING]]


def scan_artifact(folder, excludes=()):
    from .history import scan, excluded

    folder = Path(folder)
    entries = scan(folder, excludes)
    for parent, directories, _ in os.walk(folder, followlinks=False):
        directories[:] = [name for name in directories
                          if not excluded((Path(parent) / name).relative_to(folder), excludes)]
        for name in directories:
            path = Path(parent) / name
            if not path.is_symlink():
                entries[path.relative_to(folder).as_posix()] = {
                    "directory": True, "mode": stat.S_IMODE(path.stat().st_mode),
                }
    return entries


def copy_artifact(source, destination, info):
    from .history import copy_entry

    if info.get("directory"):
        destination.mkdir(parents=True, exist_ok=True)
        destination.chmod(info["mode"])
    elif "symlink" in info:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.symlink_to(info["symlink"])
    else:
        copy_entry(source, destination, info)


def artifact_exclusions(app, source):
    patterns = list(BOOKKEEPING)
    if app.home.is_relative_to(source):
        patterns.append(app.home.relative_to(source).as_posix())
    return patterns


def git(path, *args):
    result = subprocess.run(
        ["git", "-C", str(path), *args], text=True, capture_output=True
    )
    if result.returncode:
        raise ValueError(result.stderr.strip() or f"git {' '.join(args)} failed")
    return result.stdout


@snapshot_locked
def create(app, source=None, empty=False):
    if not shutil.which("git"):
        return create_files(app, source, empty)
    identifier = app.identifier()
    target = app.home / "workfolders" / identifier
    target.mkdir(parents=True)
    source = Path(source or app.project).resolve()
    from .history import safe_path

    if not empty:
        for name, info in scan_artifact(source, artifact_exclusions(app, source)).items():
            destination = safe_path(target, name)
            copy_artifact(source / name, destination, info)
    git(target, "init", "-q")
    git(target, "add", "-A", "-f", "--", *ARTIFACT_PATHS)
    git(
        target,
        "-c",
        "user.name=Metaform",
        "-c",
        "user.email=metaform@localhost",
        "commit",
        "--allow-empty",
        "-qm",
        "Workfolder baseline",
    )
    body = {
        "id": identifier,
        "path": str(target),
        "source": None if empty else str(source),
        "baseline": git(target, "rev-parse", "HEAD").strip(),
        "files": scan_artifact(target, BOOKKEEPING),
    }
    with app.db() as db:
        db.execute(
            "INSERT INTO workfolders VALUES(?,?,?)",
            (identifier, str(target), dumps(body)),
        )
    return body


def get(app, identifier):
    with app.db() as db:
        row = db.execute(
            "SELECT body FROM workfolders WHERE id=?", (identifier,)
        ).fetchone()
    if row is None:
        raise ValueError(f"Unknown workfolder {identifier}")
    body = json.loads(row[0])
    if "files" not in body and body.get("backend") != "files":
        from .history import excluded

        result = subprocess.run(["git", "-C", body["path"], "archive", body["baseline"]],
                                capture_output=True, check=True)
        files = {}
        with tarfile.open(fileobj=io.BytesIO(result.stdout)) as archive:
            for entry in archive.getmembers():
                if excluded(entry.name, BOOKKEEPING):
                    continue
                if entry.isfile():
                    files[entry.name] = {"sha256": hashlib.sha256(archive.extractfile(entry).read()).hexdigest(),
                                         "mode": 0o755 if entry.mode & 0o111 else 0o644}
                elif entry.issym():
                    files[entry.name] = {"symlink": entry.linkname, "mode": entry.mode}
                elif entry.isdir():
                    files[entry.name.rstrip("/")] = {"directory": True, "mode": 0o755}
        body.update(files=files, git_permissions=True)
    return body


def comparable(body, info):
    if info is None or not body.get("git_permissions"):
        return info
    return dict(info, mode=info["mode"] & 0o111)


@snapshot_locked
def diff(app, identifier):
    body = get(app, identifier)
    if body.get("backend") == "files":
        return files_diff(app, body)
    path = Path(body["path"])
    git(path, "add", "-A", "-f", "--", *ARTIFACT_PATHS)
    report = {
        "workfolder": identifier,
        "diff": git(path, "diff", "--binary", "--no-ext-diff", body["baseline"], "--", *ARTIFACT_PATHS),
        "status": git(path, "diff", "--name-status", body["baseline"], "--", *ARTIFACT_PATHS),
    }
    before, after = body["files"], scan_artifact(path, BOOKKEEPING)
    report["changes"] = {name: after.get(name) for name in sorted(before.keys() | after.keys())
                         if comparable(body, before.get(name)) != comparable(body, after.get(name))}
    return report


@snapshot_locked
def apply(app, identifier):
    body = get(app, identifier)
    if body["source"] is None:
        raise ValueError("An empty workfolder has no source to apply changes to")
    report = diff(app, identifier)
    return apply_files(app, body, report)


@snapshot_locked
def cleanup_aborted(app, run):
    """Retain shared work until its owning run is aborted and all harnesses stop."""
    with app.db() as db:
        runs = [json.loads(row[0]) for row in db.execute("SELECT body FROM runs")]
    owners = {item["workfolder_id"]: item for item in runs
              if item.get("workfolder_id") and not item.get("workfolder_inherited")}
    active, folders = set(), set()
    for item in runs:
        if item.get("workfolder_id") and any(
            app.get("executing:" + request_id) for request_id in item.get("receipts", {})
        ):
            active.add(item["workfolder_id"])
        jobs = list(item.get("assignments", {}).values())
        if item.get("pending"):
            jobs.append(item["pending"])
        for job in jobs:
            identifier = job.get("workfolder_id") or item.get("workfolder_id")
            if identifier and app.get("executing:" + job["request_id"]):
                active.add(identifier)
            if identifier and item["id"] == run["id"]:
                folders.add(identifier)
    if run.get("workfolder_id"):
        folders.add(run["workfolder_id"])
    for identifier in folders - active:
        if owners.get(identifier, run)["status"] not in {"aborted", "failed"}:
            continue
        with app.db() as db:
            exists = db.execute("SELECT 1 FROM workfolders WHERE id=?", (identifier,)).fetchone()
        if exists:
            cleanup(app, identifier)


@snapshot_locked
def cleanup(app, identifier):
    body = get(app, identifier)
    path = Path(body["path"])
    managed_root = (app.home / "workfolders").resolve()
    if path.resolve().parent != managed_root:
        raise ValueError("Workfolder is outside the chassis-managed directory")
    report = diff(app, identifier)
    from .history import safe_path

    artifacts = app.root / "outputs" / identifier
    files = scan_artifact(path, BOOKKEEPING)
    for name, info in files.items():
        copy_artifact(path / name, safe_path(artifacts, name), info)
    report["artifacts"] = str(artifacts)
    report["files"] = files
    app.event("workfolder.cleanup", report)
    shutil.rmtree(path)
    with app.db() as db:
        db.execute("DELETE FROM workfolders WHERE id=?", (identifier,))
    return {"removed": identifier, "diff_recorded": True}


@snapshot_locked
def create_files(app, source=None, empty=False):
    from .history import safe_path
    from .util import digest

    identifier = app.identifier()
    target = app.home / "workfolders" / identifier
    target.mkdir(parents=True)
    source = Path(source or app.project).resolve()
    baseline = (
        {}
        if empty
        else scan_artifact(
            source,
            artifact_exclusions(app, source),
        )
    )
    base_path = app.home / "workfolder-baselines" / identifier
    for name, info in baseline.items():
        for folder in (target, base_path):
            out = safe_path(folder, name)
            copy_artifact(source / name, out, info)
    body = {
        "id": identifier,
        "path": str(target),
        "source": None if empty else str(source),
        "baseline": digest(baseline),
        "files": baseline,
        "backend": "files",
    }
    with app.db() as db:
        db.execute(
            "INSERT INTO workfolders VALUES(?,?,?)",
            (identifier, str(target), dumps(body)),
        )
    return body


def files_diff(app, body):
    import difflib
    path = Path(body["path"])
    before, after = body["files"], scan_artifact(path, BOOKKEEPING)
    changes = {
        name: after.get(name)
        for name in sorted(before.keys() | after.keys())
        if comparable(body, before.get(name)) != comparable(body, after.get(name))
    }
    lines = []
    baseline = app.home / "workfolder-baselines" / body["id"]
    for name, info in changes.items():
        if (info or {}).get("directory") or before.get(name, {}).get("directory"):
            lines.append("Directory changed: " + name + "\n")
            continue
        try:
            old = (
                (baseline / name).read_text()
                if name in before and "symlink" not in before[name]
                else ""
            )
            new = (path / name).read_text() if info and "symlink" not in info else ""
            if "\0" in old or "\0" in new:
                raise UnicodeError()
            lines.extend(
                difflib.unified_diff(
                    old.splitlines(True), new.splitlines(True), "a/" + name, "b/" + name
                )
            )
        except UnicodeError:
            lines.append("Binary file changed: " + name + "\n")
    return {
        "workfolder": body["id"],
        "diff": "".join(lines),
        "changes": changes,
        "status": "\n".join(
            ("D " if info is None else "M " if name in before else "A ") + name
            for name, info in changes.items()
        ),
    }


@snapshot_locked
def apply_files(app, body, report):
    from .history import safe_path

    source = Path(body["source"])
    existing = scan_artifact(source, artifact_exclusions(app, source))

    affected = set(report["changes"])
    for name, info in report["changes"].items():
        if info is not None or body["files"].get(name, {}).get("directory"):
            affected.update(key for key in existing if key.startswith(name + "/"))
    conflicts = [
        name
        for name in sorted(affected)
        if comparable(body, existing.get(name)) != comparable(body, body["files"].get(name))
    ]
    if conflicts:
        raise ValueError(
            "Source changed since this workfolder began: " + ", ".join(conflicts)
        )
    for name in sorted(report["changes"], key=lambda key: len(Path(key).parts), reverse=True):
        if name not in existing:
            continue
        target = safe_path(source, name)
        if target.is_symlink() or target.is_file():
            target.unlink()
        elif target.is_dir() and not (report["changes"][name] or {}).get("directory"):
            target.rmdir()
    for name, info in report["changes"].items():
        if info is not None:
            target = safe_path(source, name)
            if target.is_dir() and not info.get("directory"):
                for parent, directories, files in os.walk(target, topdown=False):
                    Path(parent).rmdir()
            copy_artifact(Path(body["path"]) / name, target, info)
    app.event("workfolder.applied", report)
    return {
        "applied": bool(report["changes"]),
        "workfolder": body["id"],
        "source": str(source),
    }
