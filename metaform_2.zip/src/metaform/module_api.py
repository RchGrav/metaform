"""Public integration operations for installed modules; storage stays with the chassis."""

import copy
from importlib.resources import files


class ModuleAPI:
    def __init__(self, app, module, context=None):
        self._app = app
        self.module = module
        self._context = context

    @property
    def project(self):
        return copy.deepcopy(self._app.project_context())

    @property
    def config(self):
        return copy.deepcopy(self._app.config)

    async def call(self, command, arguments=None):
        """Invoke an enabled public operation with the current harness context."""
        from .registry import Registry

        return await Registry(self._app).call(command, arguments, self._context, internal=True)

    def get(self, key, default=None):
        return self._app.get("module:" + self.module + ":" + key, default)

    def set(self, key, value):
        self._app.set("module:" + self.module + ":" + key, value)

    def enter(self, module=None, run_id=None):
        """Enter the module's raw mode, optionally associated with a chassis run."""
        self._app.enter(module or self.module, run_id)

    def leave(self):
        self._app.leave()


def handler_context(app, command, context=None):
    builtin = files("metaform") / "data" / "modules"
    if str(command.directory) == str(builtin):
        return app
    return ModuleAPI(app, command.module, context)
