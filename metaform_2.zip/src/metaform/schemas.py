from __future__ import annotations

import importlib.resources
import json
import re

from .util import read_json, write_json


def builtins():
    return json.loads(
        (importlib.resources.files("metaform") / "data" / "schemas.json").read_text()
    )


def registry(app, owner=None):
    from .util import digest

    base = builtins()
    global_data = importlib.resources.files("metaform") / "data" / "global"
    if getattr(app, "knowledge_mode", None) != "portable" and (global_data / "index.json").is_file():
        index = json.loads((global_data / "index.json").read_text())
        for identifier in index.get("schemas", []):
            base[identifier] = json.loads(
                (global_data / "schemas" / (digest(identifier) + ".json")).read_text()
            )
    if getattr(app, "knowledge", None) is not None:
        if owner is not None:
            selected = app.knowledge.call("schema.list", {"owner": owner})
            return base | selected if owner == "global" else selected
        return (base | app.knowledge.call("schema.list", {"owner": "global"})
                | app.knowledge.call("schema.list", {"owner": "project:" + app.project_id}))
    if owner is None or owner == "global":
        return base | read_json(app.home / "schemas.json", {})
    return read_json(app.root / "schemas.json", {})


def register(app, schema, owner="global"):
    from filelock import FileLock

    if not isinstance(schema, dict) or not isinstance(schema.get("$id"), str) or not schema["$id"]:
        raise ValueError("A schema is an object carrying its $id")
    if getattr(app, "knowledge", None) is not None:
        return app.knowledge.call("schema.put", {"owner": owner, "schema": schema})
    with FileLock(app.home / "schemas.lock", timeout=30):
        user = read_json(app.home / "schemas.json", {})
        user[schema["$id"]] = schema
        write_json(app.home / "schemas.json", user)
    return schema


_TYPES = {"object": dict, "array": list, "string": str, "null": type(None), "boolean": bool}


def _is_type(value, name):
    if name == "integer":
        return (isinstance(value, int) and not isinstance(value, bool)) or (isinstance(value, float) and value.is_integer())
    if name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    expected = _TYPES.get(name)
    return expected is not None and isinstance(value, expected)


def _pointer(document, fragment):
    if not fragment.strip("/"):
        return document
    if not fragment.startswith("/"):
        stack = [document]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                if node.get("$anchor") == fragment:
                    return node
                stack.extend(node.values())
            elif isinstance(node, list):
                stack.extend(node)
        return None
    target = document
    for part in fragment.lstrip("/").split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if isinstance(target, list) and part.isdigit():
            target = target[int(part)] if int(part) < len(target) else None
        elif isinstance(target, dict):
            target = target.get(part)
        else:
            return None
        if target is None:
            return None
    return target


def _extras(names):
    listed = ", ".join(repr(name) for name in names)
    return f"Additional properties are not allowed ({listed} {'was' if len(names) == 1 else 'were'} unexpected)"


def check(schema, value, registry=None, root=None, path=()):
    """Findings of value against schema: each carries its path, the keyword that found it, and the message.

    This is the checker of the subset the shipped schemas use. It reports the same findings jsonschema would, with
    the same wording for the common ones; it never raises on an answer. Unknown keywords are annotations."""
    registry = registry or {}
    root = schema if root is None else root
    if schema is True or schema == {}:
        return []
    if schema is False:
        return [{"path": list(path), "code": "false", "message": "False schema does not allow " + repr(value)}]
    if not isinstance(schema, dict):
        return []
    notes = []
    note = lambda code, message: notes.append({"path": list(path), "code": code, "message": message})
    reference = schema.get("$ref")
    if isinstance(reference, str):
        identifier, _, fragment = reference.partition("#")
        document = root if not identifier else registry.get(identifier)
        target = _pointer(document, fragment) if document is not None else None
        if target is None:
            note("$ref", "Schema is not registered: " + reference)
        else:
            notes.extend(check(target, value, registry, document, path))
    kinds = schema.get("type")
    if isinstance(kinds, str):
        kinds = [kinds]
    if isinstance(kinds, list) and not any(_is_type(value, kind) for kind in kinds):
        note("type", f"{value!r} is not of type " + ", ".join(repr(kind) for kind in kinds))
    if "enum" in schema and value not in schema["enum"]:
        note("enum", f"{value!r} is not one of {schema['enum']!r}")
    if "const" in schema and value != schema["const"]:
        note("const", f"{schema['const']!r} was expected")
    if isinstance(value, dict):
        for name in schema.get("required", []):
            if name not in value:
                note("required", f"{name!r} is a required property")
        properties = schema.get("properties", {})
        for name, subschema in properties.items():
            if name in value:
                notes.extend(check(subschema, value[name], registry, root, path + (name,)))
        extra = schema.get("additionalProperties")
        if extra is not None:
            unexpected = [name for name in value if name not in properties]
            if extra is False and unexpected:
                note("additionalProperties", _extras(unexpected))
            elif isinstance(extra, dict):
                for name in unexpected:
                    notes.extend(check(extra, value[name], registry, root, path + (name,)))
    if isinstance(value, list):
        items = schema.get("items")
        if isinstance(items, (dict, bool)):
            for index, item in enumerate(value):
                notes.extend(check(items, item, registry, root, path + (index,)))
        if "minItems" in schema and len(value) < schema["minItems"]:
            note("minItems", f"{value!r} should be non-empty" if schema["minItems"] == 1 else f"{value!r} is too short")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            note("maxItems", f"{value!r} should be empty" if schema["maxItems"] == 0 else f"{value!r} is too long")
    if isinstance(value, str):
        if "pattern" in schema and not re.search(schema["pattern"], value):
            note("pattern", f"{value!r} does not match {schema['pattern']!r}")
        if "minLength" in schema and len(value) < schema["minLength"]:
            note("minLength", f"{value!r} should be non-empty" if schema["minLength"] == 1 else f"{value!r} is too short")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            note("maxLength", f"{value!r} should be empty" if schema["maxLength"] == 0 else f"{value!r} is too long")
    if _is_type(value, "number"):
        if "minimum" in schema and value < schema["minimum"]:
            note("minimum", f"{value!r} is less than the minimum of {schema['minimum']!r}")
        if "maximum" in schema and value > schema["maximum"]:
            note("maximum", f"{value!r} is greater than the maximum of {schema['maximum']!r}")
    for keyword in ("allOf",):
        for subschema in schema.get(keyword, []):
            notes.extend(check(subschema, value, registry, root, path))
    if "anyOf" in schema and not any(not check(subschema, value, registry, root, path) for subschema in schema["anyOf"]):
        note("anyOf", f"{value!r} is not valid under any of the given schemas")
    if "oneOf" in schema:
        matching = [subschema for subschema in schema["oneOf"] if not check(subschema, value, registry, root, path)]
        if not matching:
            note("oneOf", f"{value!r} is not valid under any of the given schemas")
        elif len(matching) > 1:
            note("oneOf", f"{value!r} is valid under each of " + ", ".join(repr(each) for each in matching))
    if "if" in schema:
        branch = "then" if not check(schema["if"], value, registry, root, path) else "else"
        if branch in schema:
            notes.extend(check(schema[branch], value, registry, root, path))
    return notes


def annotations(app, schema, value):
    """Findings of an answer against its schema. Recorded beside the answer; never a rejection."""
    all_schemas = registry(app)
    if isinstance(schema, str):
        if schema in all_schemas:
            schema = all_schemas[schema]
        elif schema.partition("#")[0] in all_schemas:
            schema = {"$ref": schema}
        else:
            return [{"path": [], "code": "$ref", "message": "Schema is not registered: " + schema}]
    if not schema:
        return []
    return check(schema, value, all_schemas)


def bundled(app, schema, owner=None):
    """Carry registered references with a response schema to an external agent."""
    import copy

    all_schemas = registry(app, owner=owner)
    if isinstance(schema, str):
        root = copy.deepcopy(all_schemas[schema]) if schema in all_schemas else {"$ref": schema}
    else:
        root = copy.deepcopy(schema or {})
    definitions = {}

    root_id = root.get("$id")

    def pointer(identifier):
        return "#/$defs/" + identifier.replace("~", "~0").replace("/", "~1")

    def expand(value, document_id=None):
        if isinstance(value, list):
            return [expand(item, document_id) for item in value]
        if not isinstance(value, dict):
            return value
        result = dict(value)
        reference = result.get("$ref")
        if isinstance(reference, str):
            identifier, separator, fragment = reference.partition("#")
            identifier = identifier or document_id
            if identifier == root_id and root_id is not None:
                result["$ref"] = "#" + fragment if separator else "#"
            elif identifier in all_schemas:
                suffix = fragment
                if fragment and not fragment.startswith("/"):
                    def anchor_path(value, path=""):
                        if isinstance(value, dict):
                            if value.get("$anchor") == fragment or value.get("$dynamicAnchor") == fragment:
                                return path
                            children = value.items()
                        elif isinstance(value, list):
                            children = enumerate(value)
                        else:
                            return None
                        for key, child in children:
                            found = anchor_path(child, path + "/" + str(key).replace("~", "~0").replace("/", "~1"))
                            if found is not None:
                                return found
                        return None
                    suffix = anchor_path(all_schemas[identifier])
                    if suffix is None:
                        suffix = "/" + fragment
                result["$ref"] = pointer(identifier) + suffix
                if identifier not in definitions:
                    definitions[identifier] = {}
                    target = copy.deepcopy(all_schemas[identifier])
                    target.pop("$id", None)
                    definitions[identifier] = expand(target, identifier)
        return {k: expand(v, document_id) if k != "$ref" else v for k, v in result.items()}

    root = expand(root, root_id)
    if definitions:
        root["$defs"] = root.get("$defs", {}) | definitions
    return root
