from __future__ import annotations

import asyncio
import json
import os
import signal
import shutil
import subprocess
import sys
import time
from pathlib import Path

from . import schemas, workfolders
from .actor import gateway
from .locking import snapshot_lock
from .util import dumps, write_json, python_environment


def aborted(app, run_id):
    while run_id:
        run = app.load_run(run_id)
        if run["status"] in {"aborted", "failed"}:
            return True
        run_id = run.get("parent")
    return False


class HarnessFailure(ValueError):
    """A launched worker failed, rather than returning an authored answer."""


async def with_execution_policy(app, assignment, operation, failure_types=(HarnessFailure,)):
    scopes = assignment.get("execution_scopes", [])
    if not scopes:
        return await operation()
    from .workflow import Engine

    engine = Engine(app)
    policy = {key: value for scope in scopes for key, value in scope["policy"].items()}
    timed = [scope for scope in scopes if "deadline" in scope]
    deadline = min(timed, key=lambda scope: scope["deadline"]) if timed else None
    while True:
        run = app.load_run(assignment["run_id"])
        if run["status"] != "running":
            return {"run_id": run["id"], "status": run["status"], "result": run.get("result")}
        recorded = run.get("worker_failures", {}).get(assignment["request_id"], [])
        if policy.get("agent_failure") == "retry_once_then_fail" and len(recorded) >= 2:
            return engine.fail(run["id"], {"kind": "worker_failure", "message": recorded[-1]["message"], "attempts": len(recorded)})
        if deadline and time.time() >= deadline["deadline"]:
            return engine.fail(run["id"], {"kind": "phase_timeout", "message": "The authored phase deadline expired."}, deadline)
        work = asyncio.create_task(operation())
        try:
            while not work.done():
                wait = min(.2, max(0, deadline["deadline"] - time.time())) if deadline else .2
                await asyncio.wait({work}, timeout=wait)
                current = app.load_run(run["id"])
                if current["status"] != "running" or deadline and time.time() >= deadline["deadline"]:
                    work.cancel()
                    await asyncio.gather(work, return_exceptions=True)
                    if current["status"] != "running":
                        return {"run_id": current["id"], "status": current["status"], "result": current.get("result")}
                    return engine.fail(run["id"], {"kind": "phase_timeout", "message": "The authored phase deadline expired."}, deadline)
            return work.result()
        except asyncio.CancelledError:
            work.cancel()
            await asyncio.gather(work, return_exceptions=True)
            raise
        except failure_types as error:
            failure = error
        failures = engine.worker_failure(assignment, failure)
        if policy.get("agent_failure") == "retry_once_then_fail" and failures == 1:
            continue
        if policy.get("phase_failure") == "stop_execution" or policy.get("agent_failure") == "retry_once_then_fail":
            return engine.fail(run["id"], {"kind": "worker_failure", "message": str(failure), "attempts": failures})
        raise failure


async def execute(app, assignment, name="command"):
    return await with_execution_policy(app, assignment, lambda: _execute_once(app, assignment, name))


async def _execute_once(app, assignment, name):
    """A new process and explicit assignment for every fresh-context request."""
    config = app.config.get("harnesses", {}).get(name, {})
    folder = Path(assignment.get("workfolder") or app.project)
    owned = None
    if assignment.get("context") == "fresh" and not assignment.get("workfolder"):
        owned = workfolders.create(app, empty=True)
        folder = Path(owned["path"])
    request_file = app.home / "requests" / assignment["request_id"] / "request.json"
    response_file = request_file.with_name("response.json")
    schema_file = request_file.with_name("schema.json")
    write_json(request_file, assignment)
    schema = schemas.bundled(app, assignment.get("schema"))
    write_json(schema_file, schema)
    if name == "codex":
        command = [
            "codex",
            "exec",
            "--json",
            "--skip-git-repo-check",
            "--sandbox",
            "workspace-write",
            "-c",
            "sandbox_workspace_write.network_access=true",
            "--cd",
            str(folder),
            "--output-last-message",
            str(response_file),
        ]
        if assignment.get("system_prompt") is not None:
            # Codex exposes additional instructions in its developer channel.
            command.extend([
                "-c",
                "developer_instructions=" + json.dumps(assignment["system_prompt"], ensure_ascii=False),
            ])
        # Metaform schemas deliberately admit open-ended Type records. Codex's
        # strict output-schema transport rejects those schemas before inference.
        # Keep the exact schema in the assignment instead of narrowing it.
        command.append("-")
    else:
        command = config.get("command")
        if not command:
            if owned:
                workfolders.cleanup(app, owned["id"])
            return {
                "status": "awaiting_harness",
                "assignment": assignment,
                "message": f"Configure harnesses.{name}.command or use the MCP answer loop.",
            }
        substitutions = {
            "request_file": str(request_file),
            "response_file": str(response_file),
            "schema_file": str(schema_file),
            "workfolder": str(folder),
        }
        command = [arg.format_map(substitutions) for arg in command]
    if not shutil.which(command[0]) and not Path(command[0]).is_file():
        if owned:
            workfolders.cleanup(app, owned["id"])
        return {
            "status": "awaiting_harness",
            "assignment": assignment,
            "message": f"Executable unavailable: {command[0]}",
        }
    # The inference payload is explicit and contains no parent conversation.
    from .prompts import inference_payload
    payload = {
        k: v
        for k, v in inference_payload(assignment).items()
        if k not in {"run_id", "request_id", "workfolder"}
    }
    if name == "codex":
        payload.pop("system_prompt", None)
    if (
        payload.get("prompt_ref") in {"prompt:metaform.intake.native", "prompt:metaform.intake.archaeology"}
        and payload.get("source_prompt")
        and payload["source_prompt"] in payload.get("prompt", "")
    ):
        payload.pop("source_prompt")
    payload["schema"] = schema
    if schema:
        payload["response_format"] = "The final answer is a JSON value conforming to the supplied schema."
    payload["tool_transport"] = {
        "command": [sys.executable, "-P", "-m", "metaform", "actor"],
        "arguments": "<command> --arguments <JSON>",
        "discovery": "Invoke without a command to retrieve the assignment's tool schemas.",
    }
    app.trace(
        "harness.request",
        {"command": command, "assignment": payload},
        assignment.get("run_id"),
    )
    try:
        with snapshot_lock(app):
            if aborted(app, assignment["run_id"]):
                return {"status": "aborted", "run_id": assignment["run_id"]}
            if response_file.exists():
                response_file.rename(response_file.with_name("response.previous-" + app.identifier() + ".json"))
            app.set("executing:" + assignment["request_id"], True)
        with gateway(app, assignment) as env:
            try:
                process = await asyncio.create_subprocess_exec(
                    *command,
                    cwd=folder,
                    env=python_environment() | env,
                    stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    start_new_session=os.name != "nt",
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
                )
            except OSError as error:
                raise HarnessFailure(f"Harness could not start: {error}") from error
            communication = asyncio.create_task(
                process.communicate(dumps(payload).encode())
            )
            try:
                while not communication.done():
                    await asyncio.wait({communication}, timeout=0.2)
                    if aborted(app, assignment["run_id"]):
                        await terminate(process, communication)
                        await communication
                        return {"status": "aborted", "run_id": assignment["run_id"]}
                    if process.returncode is not None and not communication.done():
                        await terminate(process, communication)
                stdout, stderr = communication.result()
            except asyncio.CancelledError:
                await terminate(process, communication)
                await communication
                raise
        app.trace(
            "harness.response",
            {
                "stdout": stdout.decode(errors="replace"),
                "stderr": stderr.decode(errors="replace"),
                "exit": process.returncode,
            },
            assignment.get("run_id"),
        )
        if process.returncode:
            raise HarnessFailure(
                f"Harness exited {process.returncode}: "
                f"{stderr.decode(errors='replace') or stdout.decode(errors='replace')}"
            )
        raw = response_file.read_text() if response_file.exists() else stdout.decode()
        try:
            answer = json.loads(raw)
        except json.JSONDecodeError:
            answer = raw
        if (
            assignment.get("role") in {
                "native_expert", "latent_expert", "type_proofreader",
                "autochthonous", "archaeologist",
            }
            and isinstance(answer, dict) and answer.get("status") == "blocked"
        ):
            return {
                "status": "blocked", "run_id": assignment["run_id"],
                "request_id": assignment["request_id"], "answer": answer,
            }
        return {"status": "answered", "answer": answer}
    finally:
        app.set("executing:" + assignment["request_id"], False)
        run = app.load_run(assignment["run_id"])
        if run["status"] in {"aborted", "failed"} or assignment["request_id"] in run.get("receipts", {}):
            from .continuation import retire
            retire(app, run, assignment["request_id"])
        if owned:
            workfolders.cleanup(app, owned["id"])
        elif aborted(app, assignment["run_id"]):
            workfolders.cleanup_aborted(app, app.load_run(assignment["run_id"]))


async def terminate(process, communication):
    if os.name == "nt":
        if process.returncode is not None:
            return
        process.send_signal(signal.CTRL_BREAK_EVENT)
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
    try:
        # The direct worker may already have exited while an owned descendant
        # keeps its output pipes open. Draining those pipes is part of shutdown.
        await asyncio.wait_for(asyncio.shield(communication), timeout=3)
    except TimeoutError:
        if os.name == "nt":
            cleanup = await asyncio.create_subprocess_exec("taskkill", "/PID", str(process.pid), "/T", "/F",
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            await cleanup.wait()
        else:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        await process.wait()
