"""Render base knowledge and whole property-qualified functional composites."""
import json

from .namespace import index_records, key, records, reference
from .properties import explain_applicability
from .util import digest

ARRAY_SCHEMA = 'urn:metaform:schema:knowledge-tool-array:1'


class _Contexts:
    def __init__(self, snapshot):
        self.snapshot = {field: snapshot[field] for field in
                         ('model', 'artifact', 'types', 'elements', 'bindings', 'narrowings', 'refinements', 'joins') if field in snapshot}
        self.index = index_records(self.snapshot)
        self.joins = sorted(records(snapshot, 'join'), key=lambda value: key(reference('join', value)))
        self.properties = [join for join in self.joins if join.get('role') == 'property']
        self.bindings = records(snapshot, 'binding')
        self.cache = {}

    def name(self, ref):
        value = self.index[key(ref)]
        if ref['kind'] != 'type':
            return value.get('name', ref['id'])
        if value.get('display_name'):
            return value['display_name']
        parts = value['id'].split('.')
        start = len(parts) - value.get('length', 1)
        words = []
        for position in reversed(range(max(0, start), len(parts))):
            word = parts[position]
            if position == 0:
                root = self.index.get((ref['owner'], 'type', word), {})
                word = root.get('display_name') or word
            words.append(word)
        return ' '.join(words)

    def outside(self, ref):
        value = self.index.get(key(ref), {})
        if value.get('boundary') == 'exterior':
            return True
        types = [ref] if ref.get('kind') == 'type' else [binding['type'] for binding in self.bindings
                                                       if key(binding['element']) == key(ref)]
        return any(typ['id'].split('.')[0] in ('exterior', 'ext') for typ in types)

    def definitions(self, refs):
        selected = {}
        pending = list(refs)
        while pending:
            ref = pending.pop()
            identity = key(ref)
            if identity in selected or identity not in self.index:
                continue
            selected[identity] = ref
            if ref['kind'] == 'type' and '.' in ref['id']:
                pending.append({'owner': ref['owner'], 'kind': 'type', 'id': ref['id'].rpartition('.')[0]})
        return [selected[identity] for identity in sorted(selected)]

    def describe(self, subject):
        identity = key(subject)
        if identity in self.cache:
            return self.cache[identity]
        selected = []
        explanations = []
        groups = {}
        for prop in self.properties:
            explanation = explain_applicability(self.snapshot, subject, prop, [])
            visible = explanation['visible_here'] and not self.outside(subject)
            visible = visible and not any(self.outside(step.get(endpoint, {}))
                for step in explanation['visibility_path'] for endpoint in ('from', 'to'))
            if not explanation['applies'] and not visible:
                continue
            prop_ref = reference('join', prop)
            selected.append(prop_ref)
            component = subject if explanation['applies'] else prop['receiver']
            group = groups.setdefault(key(component), {'component': component, 'properties': []})
            group['properties'].append(prop_ref)
            explanations.append({'origin': prop_ref, 'applies': explanation['applies'],
                'visible_here': explanation['visible_here'], 'path': explanation['path'],
                'visibility_path': explanation['visibility_path']})
        def property_name(origin):
            prop = self.index[key(origin)]
            provider = prop['provider']
            named = provider if provider['kind'] == 'element' and key(provider) != key(prop['receiver']) else prop['provider_type']
            return self.name(named)

        def phrase(group):
            property_names = list(dict.fromkeys(property_name(origin) for origin in group['properties']))
            return ' and '.join(property_names) + ' ' + self.name(group['component'])
        components = sorted(groups.values(), key=lambda group: (phrase(group), key(group['component'])))
        focal = {key(subject), *(key(group['component']) for group in components)}
        refs = [subject, *selected, *(group['component'] for group in components)]
        relationships = []
        property_origins = {key(origin) for origin in selected}
        for join in self.joins:
            if join.get('role') == 'property' and key(reference('join', join)) not in property_origins:
                continue
            participants = [join['receiver'], join['provider'], *[part['ref'] for part in join.get('participants', []) if 'ref' in part]]
            if any(key(ref) in focal for ref in participants):
                relationships.append(reference('join', join))
                refs.extend([reference('join', join), join['provider_type'], *participants])
        for explanation in explanations:
            refs.extend(step['relation'] for route in ('path', 'visibility_path') for step in explanation[route])
        involved = {key(ref) for ref in refs}
        for binding in self.bindings:
            if key(binding['element']) in involved:
                refs.extend([reference('binding', binding), binding['type']])
        result = {'subject': subject, 'records': self.definitions(refs), 'properties': selected,
                  'components': components, 'relationships': relationships, 'property_context': explanations}
        result['phrases'] = [phrase(group) for group in components]
        self.cache[identity] = result
        return result


def context_projection(snapshot, target):
    """Exact membership of one functional composite, including its property origins."""
    contexts = _Contexts(snapshot)
    if key(target) not in contexts.index:
        return {'subject': target, 'records': [], 'properties': [], 'components': [], 'relationships': []}
    described = contexts.describe(target)
    return {field: described[field] for field in ('subject', 'records', 'properties', 'components', 'relationships')}


def render(snapshot, request, target=None, *, summary=False):
    from .namespace import member_bindings

    contexts = _Contexts(snapshot)
    index = contexts.index
    types = sorted([reference('type', value) for value in records(snapshot, 'type')], key=key)
    elements = sorted([reference('element', value) for value in records(snapshot, 'element')], key=key)
    entries = []
    bases = {}
    for element in elements:
        bound = {key(binding['type']): binding['type'] for binding in contexts.bindings
                 if key(binding['element']) == key(element) and key(binding['type']) in index}
        facets = {key(join['provider_type']) for join in contexts.joins if key(join['provider']) == key(element)}
        bases[key(element)] = [bound[identity] for identity in sorted(bound) if not facets or identity in facets]
        if not bases[key(element)]:
            bases[key(element)] = list(bound.values()) or [element]
    composites = {key(subject): contexts.describe(subject) for subject in [*types, *elements]}
    aliases = {key(subject): [subject] for subject in [*types, *elements]}
    for typ in types:
        described = composites[key(typ)]
        if not described['properties']:
            continue
        members = {key(binding['element']) for binding in member_bindings(snapshot, typ, True)}
        matching = [element for element in elements if key(element) in members
                    and composites[key(element)]['components'] == described['components']]
        direct = {key(binding['element']) for binding in contexts.bindings if key(binding['type']) == key(typ)}
        direct_matches = [element for element in matching if key(element) in direct]
        if direct_matches:
            matching = direct_matches
        if len(matching) == 1:
            aliases[key(matching[0])].append(typ)
            del composites[key(typ)]

    def dependencies(refs, composite=None):
        result = []
        for ref in refs:
            fields = ['description', 'ef', 'length', 'display_name', 'aliases', 'parametric_elements'] if ref['kind'] == 'type' else ['*']
            value = index[key(ref)]
            result.append({'kind': 'record', 'target': ref, 'fields': fields,
                'fingerprint': digest(value if fields == ['*'] else {field: value.get(field) for field in fields}),
                'reason': 'Definition supplied for this question.'})
        if composite is not None:
            projection = {field: composite[field] for field in ('subject', 'records', 'properties', 'components', 'relationships')}
            result.append({'kind': 'selector', 'selector': {'kind': 'knowledge_tool.context', 'target': composite['subject']},
                           'resolved_targets': projection['records'], 'fingerprint': digest(projection),
                           'reason': 'This composite and its recorded property/component membership.'})
        return result

    selected_target = target
    if target is not None and target.get('kind') == 'join' and key(target) in index:
        join = index[key(target)]
        selected_target = join['receiver'] if join.get('role') == 'property' else join['provider']
    target_bases = bases.get(key(selected_target), [selected_target]) if selected_target is not None else []
    for subject in [*types, *[element for element in elements if bases[key(element)] == [element]]]:
        if selected_target is not None and key(subject) not in {key(ref) for ref in target_bases}:
            continue
        refs = contexts.definitions([subject])
        identity = {'subject': subject, 'context': 'node'}
        entries.append(identity | {'slot': 'knowledge-tool:' + digest(identity)[:24], 'properties': [],
            'components': [], 'records': refs, 'relationships': [], 'property_context': [],
            'dependencies': dependencies(refs), 'question': request + ' for ' + contexts.name(subject)})
    for identity in sorted(composites):
        described = composites[identity]
        if not described['properties']:
            continue
        if selected_target is not None and key(selected_target) not in {key(ref) for ref in aliases[identity]}:
            continue
        subject = described['subject']
        if len(described['components']) == 1 and key(described['components'][0]['component']) == key(subject):
            description = described['phrases'][0]
        else:
            description = contexts.name(subject) + ' that is part ' + ', and part '.join(described['phrases'])
        entry_identity = {'subject': subject, 'context': 'composite'}
        entries.append({field: value for field, value in described.items() if field != 'phrases'} | entry_identity | {
            'slot': 'knowledge-tool:' + digest(entry_identity)[:24], 'dependencies': dependencies(described['records'], described),
            'question': request + ' for ' + description})
    questions = {}
    for number, entry in enumerate(entries, 1):
        entry['field'] = f'q{number}_array'
        questions[entry['field']] = entry['question']
    schema = {'$id': 'urn:metaform:knowledge-tool-output:' + digest(questions), 'type': 'object',
              'properties': {field: {'type': 'array', 'items': {'type': 'string'}} for field in questions},
              'required': list(questions)}
    result = {'model': snapshot['model'], 'request': request, 'questions': questions, 'schema': schema, 'entries': entries}
    result['statistics'] = statistics(result)
    if summary:
        return {field: result[field] for field in ('model', 'request', 'statistics')} | {'diagnostics': snapshot.get('diagnostics', [])}
    return result


def statistics(enumeration):
    return {'questions': len(enumeration['questions']),
            'contexts': len(enumeration['entries']),
            'maximum_context_properties': max((len(entry['properties']) for entry in enumeration['entries']), default=0),
            'subjects': len({key(entry['subject']) for entry in enumeration['entries']}),
            'question_bytes': len(json.dumps(enumeration['questions'], ensure_ascii=False).encode('utf-8')),
            'schema_bytes': len(json.dumps(enumeration['schema'], ensure_ascii=False).encode('utf-8'))}


def preview(app, request, model=None, summary=False):
    from .models import capture_model
    return render(capture_model(app, model), request, summary=summary)


def start(app, request, name=None, model=None):
    if name is None:
        return {'status': 'needs_layer_name', 'question': 'What do you want to call this knowledge layer?',
                'request': request, 'model': model}
    from .layers import _start
    from .locking import snapshot_lock
    with snapshot_lock(app):
        return _start(app, request, None, model, 'knowledge-tool', name=name)
