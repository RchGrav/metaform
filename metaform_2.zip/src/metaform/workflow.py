from __future__ import annotations

import copy
import secrets
import time
from pathlib import Path

from jinja2 import Environment, StrictUndefined, UndefinedError

from . import schemas
from .logic import evaluate
from .locking import run_locked, snapshot_locked
from .util import digest, now, read_json


def render(prompt, data):
    try:
        return Environment(undefined=StrictUndefined, autoescape=False).from_string(prompt).render(**data)
    except UndefinedError as error:
        raise ValueError(f"Missing workflow input: {error}") from error


def prompt_file(app, reference, base_dir=None):
    path = (Path(base_dir or app.project) / reference[5:]).resolve()
    captured = read_json(app.home / "resources.json", {}).get(str(path))
    return app.home / captured if captured else path


@snapshot_locked
def import_workflow(app, document):
    if isinstance(document, str):
        document = {
            "id": "import:" + digest(document)[:16],
            "intent": document,
            "start": "prompt",
            "steps": [{"id": "prompt", "kind": "prompt", "prompt": document, "template": False}],
        }
    workflow_id = document["id"]
    from .prompts import put as put_prompt

    for child in document.get("workflows", []):
        if document.get("base_dir") and not child.get("base_dir"):
            child = dict(child, base_dir=document["base_dir"])
        import_workflow(app, child)
    for prompt in document.get("prompts", []):
        put_prompt(app, prompt)
    prefix = f"workflow:{workflow_id}"
    elements = {
        prefix: {
            "entity_desc": document.get("intent", workflow_id),
            "entity_schema": "metaform:workflow",
            "entity_json_obj": copy.deepcopy(document),
        },
        prefix + ":nonce": {
            "entity_desc": "Registration nonce for " + workflow_id,
            "entity_schema": "metaform:workflow-nonce",
            "entity_json_obj": {"workflow": workflow_id, "nonce": secrets.token_hex(8)},
        },
    }
    joins = []

    def attach(identifier, attachments):
        for attachment in attachments:
            subject = {"ref": attachment} if isinstance(attachment, str) else dict(attachment)
            join = {
                "object_id": identifier, "element_id": subject["ref"],
                "type": "workflow_attachment",
                "participants": [{"role": "workflow", "ref": identifier},
                                 dict(subject, role="subject")],
            }
            if subject.get("owner"):
                join["reference_owners"] = {"element_id": subject["owner"]}
            joins.append(join)

    attach(prefix, document.get("attachments", []))
    steps = document["steps"]
    for i, step in enumerate(steps):
        node = f"{prefix}:{step['id']}"
        step = copy.deepcopy(step)
        attach(node, step.get("attachments", []))
        if "prompt" in step and not step.get("prompt_ref"):
            from .prompts import put

            text = step["prompt"]
            if text.startswith("file:"):
                text = prompt_file(app, text, document.get("base_dir")).read_text()
            step["prompt_ref"] = "prompt:" + workflow_id + ":" + step["id"]
            put(
                app,
                {
                    "id": step["prompt_ref"],
                    "name": step.get("intent", step["id"]),
                    "text": text,
                    "schema": step.get("schema"),
                },
            )
        if step.get("prompt_ref"):
            joins.append(
                {
                    "object_id": node,
                    "element_id": step["prompt_ref"],
                    "type": "step_prompt",
                }
            )
        elements[node] = {
            "entity_desc": step.get("intent", step.get("prompt", step["id"])),
            "entity_schema": "metaform:step",
            "entity_json_obj": {
                k: copy.deepcopy(v)
                for k, v in step.items()
                if k not in {"next", "transitions"}
            },
        }
        joins.append(
            {
                "object_id": prefix,
                "element_id": node,
                "type": "workflow_step",
                "order": i,
            }
        )
        transitions = step.get("transitions", [])
        if not transitions and "next" in step:
            transitions = [{"to": step["next"]}]
        for order, transition in enumerate(transitions):
            join = {
                "object_id": node,
                "element_id": f"{prefix}:{transition['to']}"
                if transition.get("to")
                else prefix,
                "type": "transition",
                "order": order,
                "to": transition.get("to"),
                "condition": transition.get("when", True),
            }
            if isinstance(transition.get("rule"), str):
                join["rule"] = transition["rule"]
                join["participants"] = [
                    {"role": "from", "ref": node},
                    {"role": "to", "ref": join["element_id"]},
                    {"role": "condition", "ref": transition["rule"]},
                ]
            joins.append(join)
    # Replace the imported procedure projection, retaining earlier versions as observations.
    members = [
        j["element_id"] for j in app.graph.joins(prefix, category="workflow_step")
    ]
    app.graph.delete_joins(object_id=prefix, category="workflow_step")
    app.graph.delete_joins(object_id=prefix, category="workflow_attachment", scope="authored")
    for member in members:
        app.graph.delete_joins(object_id=member, category="transition")
        app.graph.delete_joins(object_id=member, category="step_prompt")
        app.graph.delete_joins(object_id=member, category="workflow_attachment", scope="authored")
    app.graph.put(
        {"elements": elements, "joins": joins}, source="authored", layer="workflows"
    )
    app.event(
        "workflow.import", {"workflow": workflow_id, "source_hash": digest(document)}
    )
    return {"id": workflow_id, "steps": len(steps), "source_hash": digest(document)}


class Engine:
    def __init__(self, app):
        self.app = app

    def completion(self, run, result):
        if run.get("layer_job"):
            from .layers import completion
            result = completion(self.app, run, result)
        if run.get("expansion_job"):
            from .expansion import completion
            result = completion(self.app, run, result)
        return result

    def definition(self, workflow):
        record = self.app.graph.get(
            "workflow:" + workflow
        ) or self.app.global_graph.get("workflow:" + workflow)
        if not record:
            from .workflow_library import definition

            bundled = definition(workflow)
            if bundled is not None:
                return bundled
            raise ValueError(f"Unknown workflow: {workflow}")
        definition = copy.deepcopy(record["entity_json_obj"])
        graph = (
            self.app.graph
            if self.app.graph.get("workflow:" + workflow)
            else self.app.global_graph
        )
        members = sorted(
            graph.joins("workflow:" + workflow, category="workflow_step"),
            key=lambda j: j.get("order", 0),
        )
        definition["steps"] = []
        if members:
            steps = []
            for member in members:
                step = copy.deepcopy(graph.get(member["element_id"])["entity_json_obj"])
                transitions = sorted(
                    [
                        j
                        for j in graph.joins(
                            member["element_id"], category="transition"
                        )
                        if j["object_id"] == member["element_id"]
                    ],
                    key=lambda j: j.get("order", 0),
                )
                step.pop("next", None)
                step["transitions"] = [
                    {
                        "to": j.get("to"),
                        "when": j.get("condition", True),
                        **({"rule": j["rule"]} if j.get("rule") else {}),
                    }
                    for j in transitions
                ]
                steps.append(step)
            definition["steps"] = steps
        return definition

    def frame(self, workflow, inputs=None):
        definition = copy.deepcopy(self.definition(workflow))
        if not definition.get("steps"):
            raise ValueError("An executable workflow needs at least one step")
        for step in definition["steps"]:
            rule_codes = []
            if step.get("prompt_ref"):
                from .prompts import get

                prompt = get(self.app, step["prompt_ref"])
                step["prompt"] = prompt["text"]
                step["prompt_revision"] = digest(prompt["text"])
                rule_codes.extend(prompt.get("rule_codes", []))
            rule_codes.extend(step.get("rule_codes", []))
            from .rulebook import prepare as prepare_rules

            step["rules"] = prepare_rules(self.app, rule_codes)
            for transition in step.get("transitions", []):
                if transition.get("rule"):
                    rule = self.app.graph.get(
                        transition["rule"]
                    ) or self.app.global_graph.get(transition["rule"])
                    if rule is None:
                        raise ValueError(f"Unresolved rule {transition['rule']}")
                    transition["when"] = copy.deepcopy(
                        rule["entity_json_obj"]["expression"]
                    )
        return {
            "workflow": workflow,
            "definition": definition,
            "step": definition.get("start", definition["steps"][0]["id"]),
            "values": dict(inputs or {}),
            "steps": {},
            "iteration": {},
        }

    @snapshot_locked
    def start(
        self, workflow, inputs=None, parent=None, exclusive=True, workfolder=False,
        workfolder_id=None, run_id=None, execution_scopes=None,
    ):
        from .workflow_library import install

        install(self.app, workflow)
        if run_id is not None:
            with self.app.db() as db:
                existing = db.execute("SELECT workflow FROM runs WHERE id=?", (run_id,)).fetchone()
            if existing:
                if existing[0] != workflow:
                    raise ValueError("The run identity already belongs to another workflow")
                return self.next(run_id)
        run = {
            "id": run_id or self.app.identifier(),
            "workflow": workflow,
            "status": "running",
            "stack": [self.frame(workflow, inputs)],
            "pending": None,
            "receipts": {},
            "parent": parent,
            "created": now(),
        }
        if execution_scopes:
            run["execution_scopes"] = copy.deepcopy(execution_scopes)
        if workfolder:
            from .workfolders import create

            run["workfolder_id"] = create(self.app)["id"]
        elif workfolder_id:
            run["workfolder_id"] = workfolder_id
            run["workfolder_inherited"] = True
        self.app.save_run(run)
        if exclusive:
            self.app.enter("workflow", run["id"])
        return self.next(run["id"])

    def scope(self, frame):
        return {"inputs": frame["values"], "steps": frame["steps"], **frame["values"]}

    def step(self, frame):
        return next(s for s in frame["definition"]["steps"] if s["id"] == frame["step"])

    def successor(self, frame, step):
        # Definitions are snapshotted at start; running work is not silently rewritten.
        for transition in step.get("transitions", []):
            expr = transition.get("when", True)
            if evaluate(expr, self.scope(frame), strict=True):
                return transition.get("to")
        if "next" in step:
            return step["next"]
        index = frame["definition"]["steps"].index(step)
        return (
            frame["definition"]["steps"][index + 1]["id"]
            if index + 1 < len(frame["definition"]["steps"])
            else None
        )

    def finish_step(self, run, answer):
        frame = run["stack"][-1]
        step = self.step(frame)
        frame["steps"][step["id"]] = answer
        if step.get("save_as"):
            frame["values"][step["save_as"]] = answer
        frame["step"] = self.successor(frame, step)
        frame["iteration"].pop(step["id"], None)
        frame.pop("execution_scope", None)
        run["pending"] = None

    def execution_scopes(self, run):
        """Keep authored phase deadlines across child frames, retries and resume."""
        scopes = copy.deepcopy(run.get("execution_scopes", []))
        for frame in run.get("stack", []):
            if frame["step"] is None:
                continue
            policy = self.step(frame).get("execution_policy")
            if policy:
                if "execution_scope" not in frame:
                    scope = {"run_id": run["id"], "step": frame["step"], "policy": copy.deepcopy(policy)}
                    if "timeout_seconds" in policy:
                        scope["deadline"] = time.time() + policy["timeout_seconds"]
                    frame["execution_scope"] = scope
                scopes.append(frame["execution_scope"])
        return scopes

    def expired(self, run):
        if run["status"] != "running":
            return None
        for scope in self.execution_scopes(run):
            if "deadline" in scope and time.time() >= scope["deadline"]:
                return self.fail(run["id"], {"kind": "phase_timeout", "message": "The authored phase deadline expired."}, scope)
        return None

    @snapshot_locked
    def worker_failure(self, assignment, error):
        run = self.app.load_run(assignment["run_id"])
        failures = run.setdefault("worker_failures", {}).setdefault(assignment["request_id"], [])
        failures.append({"at": now(), "message": str(error)})
        self.app.save_run(run)
        self.app.event("workflow.worker_failure", {"request_id": assignment["request_id"], "attempt": len(failures), "message": str(error)}, run["id"])
        response = self.app.home / "requests" / assignment["request_id"] / "response.json"
        if response.exists():
            response.rename(response.with_name(f"response.failed-{len(failures)}.json"))
        return len(failures)

    @snapshot_locked
    def fail(self, run_id, error, scope=None):
        run = self.app.load_run(run_id)
        if run["status"] != "running":
            return {"run_id": run_id, "status": run["status"], "result": run.get("result")}
        if scope is None:
            scopes = self.execution_scopes(run)
            scope = next((item for item in reversed(scopes) if item["policy"].get("phase_failure") == "stop_execution"), None)
        owner = scope["run_id"] if scope else run_id
        failure = dict(error, run_id=run_id, request_id=(run.get("pending") or {}).get("request_id"),
                       phase_run_id=owner, phase=scope["step"] if scope else None, at=now())
        stopped = self._abort_tree(owner)
        for item in stopped:
            if item["id"] in {owner, run_id}:
                item.update(status="failed", result={"failure": failure})
                self.app.save_run(item)
            from .workfolders import cleanup_aborted
            cleanup_aborted(self.app, item)
        if (self.app.get("mode") or {}).get("run_id") in {item["id"] for item in stopped}:
            self.app.leave()
        self.app.event("workflow.failed", failure, owner)
        return {"run_id": run_id, "status": "failed", "result": {"failure": failure}}

    @run_locked
    def next(self, run_id, request_id=None):
        run = self.app.load_run(run_id)
        failure = self.expired(run)
        if failure:
            return failure
        if request_id is not None:
            from .continuation import pending_assignment

            return pending_assignment(self.app, run_id, request_id)
        if run["status"] != "running":
            return self.completion(run, {
                "run_id": run_id,
                "status": run["status"],
                "result": run.get("result"),
            })
        if run["pending"]:
            from .continuation import present
            return present(run["pending"])
        frame = run["stack"][-1]
        if frame["step"] is None:
            result = {"values": frame["values"], "steps": frame["steps"]}
            run["stack"].pop()
            if not run["stack"]:
                if run.get("workfolder_id"):
                    from .workfolders import get, diff

                    result["workfolder"] = get(self.app, run["workfolder_id"])
                    result["changes"] = diff(self.app, run["workfolder_id"])
                run.update(status="complete", result=result)
                if (self.app.get("mode") or {}).get("run_id") == run_id:
                    self.app.leave()
            else:
                parent = run["stack"][-1]
                parent_step = self.step(parent)
                if parent_step.get("kind") == "foreach" and parent_step.get("workflow"):
                    iteration = parent["iteration"][parent_step["id"]]
                    iteration["results"].append(result)
                    iteration["index"] += 1
                else:
                    self.finish_step(run, result)
            self.app.save_run(run)
            return self.completion(run, {
                "run_id": run_id,
                "status": run["status"],
                "result": result,
                "next": "workflow.next" if run["status"] == "running" else None,
            })
        step = self.step(frame)
        scope = self.scope(frame)
        kind = step.get("kind", "prompt")
        if kind == "branch":
            self.finish_step(run, None)
            self.app.save_run(run)
            return {"run_id": run_id, "status": "running", "next": "workflow.next"}
        if kind == "call":
            run["stack"].append(
                self.frame(
                    step["workflow"],
                    {k: evaluate(v, scope) for k, v in step.get("inputs", {}).items()},
                )
            )
            self.app.save_run(run)
            return {"run_id": run_id, "status": "running", "next": "workflow.next"}
        if kind == "parallel":
            group = frame["iteration"].setdefault(step["id"], {"children": []})
            if not group["children"]:
                for branch in step["branches"]:
                    if isinstance(branch, str):
                        branch = {"workflow": branch}
                    if "steps" in branch:
                        branch = dict(branch)
                        branch.setdefault("id", "parallel:" + self.app.identifier())
                        import_workflow(self.app, branch)
                        workflow = branch["id"]
                    else:
                        workflow = branch["workflow"]
                    child = self.start(
                        workflow,
                        {
                            k: evaluate(v, scope)
                            for k, v in branch.get("inputs", {}).items()
                        },
                        parent=run_id,
                        exclusive=False,
                        workfolder_id=run.get("workfolder_id"),
                        execution_scopes=self.execution_scopes(run),
                    )
                    current = self.app.load_run(run_id)
                    if current["status"] != "running":
                        return {"run_id": run_id, "status": current["status"], "result": current.get("result")}
                    group["children"].append(child["run_id"])
                self.app.save_run(run)
            jobs = [self.next(child) for child in group["children"]]
            current = self.app.load_run(run_id)
            if current["status"] != "running":
                return {"run_id": run_id, "status": current["status"], "result": current.get("result")}
            if all(j["status"] == "complete" for j in jobs):
                self.finish_step(run, [j["result"] for j in jobs])
                self.app.save_run(run)
                return {"run_id": run_id, "status": "running", "next": "workflow.next"}
            return {"run_id": run_id, "status": "awaiting_parallel", "parallel": jobs}
        if kind == "foreach":
            iteration = frame["iteration"].setdefault(
                step["id"],
                {"index": 0, "results": [], "items": evaluate(step["items"], scope)},
            )
            if iteration["index"] >= len(iteration["items"]):
                self.finish_step(run, iteration["results"])
                self.app.save_run(run)
                return {"run_id": run_id, "status": "running", "next": "workflow.next"}
            job_values = scope | {
                "item": iteration["items"][iteration["index"]],
                "index": iteration["index"],
            }
            if step.get("workflow"):
                run["stack"].append(self.frame(
                    render(step["workflow"], job_values),
                    {key: evaluate(value, job_values) for key, value in step.get("inputs", {}).items()},
                ))
                self.app.save_run(run)
                return {"run_id": run_id, "status": "running", "next": "workflow.next"}
        else:
            job_values = scope
        selected = {}
        if step.get("focal"):
            focal = render(step["focal"], job_values)
            from .prompts import assemble

            selected = assemble(self.app, focal, step.get("depth", 1))
        prompt = step.get("prompt", "")
        if prompt.startswith("file:"):
            prompt = prompt_file(self.app, prompt, frame["definition"].get("base_dir")).read_text(encoding="utf-8")
        job = {
            "run_id": run_id,
            "request_id": self.app.identifier(),
            "status": {"tool": "awaiting_tool", "user": "awaiting_user"}.get(kind, "awaiting_answer"),
            "step": step["id"],
            "intent": step.get("intent", ""),
            "prompt": (step["role_snapshot"]["prompt"] if step.get("role_snapshot")
                       else render(prompt, job_values) if step.get("template", True) else prompt),
            "source_prompt": step.get("prompt", ""),
            "prompt_ref": step.get("prompt_ref"),
            "prompt_revision": step.get("prompt_revision", digest(prompt)),
            "rules": step.get("rules", []),
            "inputs": {
                k: evaluate(v, job_values) for k, v in step.get("inputs", {}).items()
            },
            "graph": selected,
            "schema": step.get("schema"),
            "role": render(step.get("role", "operator"), job_values),
            "module": step.get("module", "workflow"),
            "context": step.get("context", "project"),
            "requires_answer": step.get("requires_answer", True),
        }
        scopes = self.execution_scopes(run)
        if scopes:
            job["execution_scopes"] = scopes
        if kind == "tool":
            job.update(
                tool=step["tool"],
                arguments={
                    k: evaluate(v, scope) for k, v in step.get("arguments", {}).items()
                },
            )
        job["tools"] = step.get(
            "tools",
            [
                "workflow.search",
                "workflow.get",
                "workflow.put",
                "workflow.files",
                "workflow.read",
            ],
        )
        if run.get("workfolder_id") and job["context"] != "fresh":
            from .workfolders import get

            job["workfolder"] = get(self.app, run["workfolder_id"])["path"]
        if step.get("output"):
            job["output"] = {
                k: render(v, job_values) if isinstance(v, str) else v
                for k, v in step["output"].items()
            }
        from .continuation import publish

        if step.get("role_snapshot"):
            job.update(copy.deepcopy(step["role_snapshot"]))
        if frame["definition"].get("grounding"):
            run["contract_version"] = "2"
            run["grounding"] = copy.deepcopy(frame["definition"]["grounding"])
            job.update({key: copy.deepcopy(value) for key, value in run["grounding"].items() if key != "region"})
            if not step.get("role_snapshot"):
                job["inputs"].setdefault("metaform", copy.deepcopy(run["grounding"]["region"]))
        if frame["definition"].get("layer_job"):
            from .layers import prepare_assignment
            prepare_assignment(self.app, run, job, step)
        if frame["definition"].get("expansion_job"):
            from .expansion import prepare_assignment
            prepare_assignment(self.app, run, job, step)
        publish(self.app, job, job["module"])
        run["pending"] = job
        self.app.save_run(run)
        self.app.event("assignment", job, run_id)
        self.app.trace("assignment", job, run_id)
        return job

    @run_locked
    def submit(self, run_id, request_id, answer):
        run = self.app.load_run(run_id)
        if request_id in run["receipts"]:
            self._cleanup_completed(run, request_id)
            return run["receipts"][request_id]
        if self.expired(run):
            raise ValueError("Run is failed: the authored phase deadline expired")
        if run["status"] != "running":
            raise ValueError(f"Run is {run['status']}")
        job = run["pending"]
        if not job or job["request_id"] != request_id:
            raise ValueError("This response does not name the pending assignment")
        notes = schemas.annotations(self.app, job.get("schema"), answer)
        self.app.event(
            "answer",
            {"request_id": request_id, "answer": answer, "annotations": notes},
            run_id,
        )
        if run["workflow"].startswith("prompt-test:") and job.get("prompt_ref"):
            from .prompts import record_test

            record_test(
                self.app,
                {
                    k: job[k]
                    for k in (
                        "prompt_ref",
                        "prompt_revision",
                        "source_prompt",
                        "prompt",
                        "inputs",
                        "graph",
                        "rules",
                    )
                    if k in job
                },
                answer,
            )
        if job.get("output"):
            output = job["output"]
            record = {
                "entity_desc": output.get("description", job["intent"] or job["step"]),
                "entity_schema": output.get(
                    "schema",
                    job.get("schema")
                    if isinstance(job.get("schema"), str)
                    else "metaform:report",
                ),
                "entity_json_obj": answer
                if isinstance(answer, dict)
                else {"value": answer},
            }
            joins = (
                [
                    {
                        "object_id": output["id"],
                        "element_id": output["subject"],
                        "type": "about",
                        "run_id": run_id,
                    }
                ]
                if output.get("subject")
                else []
            )
            self.app.graph.put(
                {"elements": {output["id"]: record}, "joins": joins},
                "workflow",
                output.get("layer", "results"),
            )
        frame = run["stack"][-1]
        step = self.step(frame)
        if step.get("kind") == "foreach":
            iteration = frame["iteration"][step["id"]]
            iteration["results"].append(answer)
            iteration["index"] += 1
            run["pending"] = None
        else:
            self.finish_step(run, answer)
        if run.get("layer_job"):
            from .layers import record_answer
            record_answer(self.app, run, job, answer, notes)
        if run.get("expansion_job"):
            from .expansion import record_answer
            record_answer(self.app, run, job, answer, notes)
        result = {
            "run_id": run_id,
            "recorded": True,
            "annotations": notes,
            "next": "workflow.next",
        }
        run["receipts"][request_id] = result
        if job.get("workfolder_id"):
            run.setdefault("cleanup_by_request", {})[request_id] = job["workfolder_id"]
        self.app.save_run(run)
        self._cleanup_completed(run, request_id)
        return result

    def _cleanup_completed(self, run, request_id):
        from .continuation import retire

        retire(self.app, run, request_id)
        identifier = run.get("cleanup_by_request", {}).get(request_id)
        if identifier is None:
            return
        from .workfolders import cleanup

        with self.app.db() as db:
            retained = db.execute("SELECT 1 FROM workfolders WHERE id=?", (identifier,)).fetchone()
        if retained is not None:
            cleanup(self.app, identifier)
        del run["cleanup_by_request"][request_id]
        self.app.save_run(run)

    @run_locked
    def abort(self, run_id):
        return self._abort_tree(run_id)

    def _abort_tree(self, run_id):
        import json

        with self.app.db() as db:
            runs = [json.loads(row[0]) for row in db.execute("SELECT body FROM runs")]
        children = {}
        for run in runs:
            children.setdefault(run.get("parent"), []).append(run["id"])
        pending, visited, aborted = [run_id], set(), []
        while pending:
            identifier = pending.pop()
            if identifier in visited:
                continue
            visited.add(identifier)
            pending.extend(children.get(identifier, []))
            run = self.app.load_run(identifier)
            if run["status"] == "running":
                run["status"] = "aborted"
                self.app.save_run(run)
            if run["status"] == "aborted":
                from .continuation import retire

                retire(self.app, run)
                aborted.append(run)
        return aborted

    def recursive(self, run_id, inputs=None):
        parent = self.app.load_run(run_id)
        values = ((parent.get("result") or {}).get("values", {})
                  if not parent.get("stack") else parent["stack"][0]["values"])
        values = copy.deepcopy(values) | (inputs or {})
        return self.start(parent["workflow"], values, parent=run_id)
