'use strict';
/* The explorer shows what the agent sees through the MCP server. Every panel is one read
   and can flip to the exact envelope that read returns. */
const $=id=>document.getElementById(id);
const prefix=document.body.dataset.projectPrefix||'';
const pretty=value=>JSON.stringify(value,null,2);
const el=(tag,text,cls)=>{const node=document.createElement(tag);if(text!=null)node.textContent=text;if(cls)node.className=cls;return node;};
const refKey=ref=>ref?ref.kind+':'+ref.id:'';
const cap=s=>s?s.charAt(0).toUpperCase()+s.slice(1):s;
const hue=text=>{let h=0;for(const ch of String(text))h=(h*31+ch.charCodeAt(0))>>>0;return h%360;};
const stripeColor=id=>`hsl(${hue(id)} 62% 56%)`;

async function api(path,body){
  const response=await fetch(prefix+path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data=await response.json();if(!response.ok)throw Error(data.error||response.statusText);return data;
}
function notice(text){const box=$('notice');box.textContent=text;box.hidden=false;clearTimeout(notice.timer);notice.timer=setTimeout(()=>box.hidden=true,8000);}

/* ---------- state ---------- */
const state={models:[],model:null,artifact:null,focus:null,selected:null,layer:'',layers:[],known:new Map(),scene:null,positions:new Map(),view:{x:0,y:0,k:1}};
function remember(envelope){for(const item of envelope?.records||[])state.known.set(refKey(item.ref),item.value);return envelope;}
function known(ref){return state.known.get(refKey(ref));}
async function read(command,args={}){
  const query={...(state.model?{model:state.model}:{}),...args};
  return remember(await api('/api/semantic/'+command,query));
}
function urlSync(){
  const url=new URL(location.href);const set=(key,value)=>value?url.searchParams.set(key,value):url.searchParams.delete(key);
  set('model',state.model?.model);set('focus',state.focus?refKey(state.focus):'');set('layer',state.layer);history.replaceState(null,'',url);
}

/* ---------- envelope flip: each panel remembers the call that filled it ---------- */
function panelCall(panel,command,args,envelope){
  panel.dataset.command=command;panel._call={command,args,envelope};
  const open=panel.querySelector('.envelope');if(open)renderEnvelope(panel,open);
}
function renderEnvelope(panel,box){
  const call=panel._call;box.replaceChildren();
  if(!call){box.append(el('p','This panel has not made a call yet.','quiet'));return;}
  box.append(el('div',call.command+' '+JSON.stringify(call.args),'call'),el('pre',pretty(call.envelope)));
}
for(const button of document.querySelectorAll('.envelope-toggle')){
  const panel=button.closest('.panel');
  button.onclick=()=>{
    let box=panel.querySelector('.envelope');
    if(box){box.remove();button.setAttribute('aria-pressed','false');return;}
    box=el('div',null,'envelope');renderEnvelope(panel,box);panel.append(box);button.setAttribute('aria-pressed','true');
  };
}
document.addEventListener('keydown',event=>{if(event.key==='Escape')for(const box of document.querySelectorAll('.envelope')){box.remove();box.parentElement?.querySelector('.envelope-toggle')?.setAttribute('aria-pressed','false');}});

/* ---------- names: the namespace name is the name ---------- */
function typeName(type){
  if(!type)return '';
  if(type.display_name)return type.display_name;
  const parts=type.id.split('.'),count=Number.isInteger(type.length)&&type.length>0?type.length:1;
  return parts.slice(-count).reverse().map(cap).join(' ');
}
function bindingsOf(elementRef){
  const out=[];for(const [key,value] of state.known)if(key.startsWith('binding:')&&refKey(value.element)===refKey(elementRef))out.push(value);return out;
}
function elementPresentation(ref,value){
  const bindings=bindingsOf(ref),types=bindings.map(b=>known(b.type)).filter(Boolean);
  const primary=types[0];const title=primary?typeName(primary):value.name||ref.id;
  const subtitle=value.name&&value.name!==title?value.name:'';
  const base=(primary?.id||'').split('.')[0]||'';
  return {title,subtitle,base,exterior:base==='exterior',types};
}
function nameOf(ref){
  const value=known(ref);if(!value)return ref.id;
  if(ref.kind==='type')return typeName(value);
  if(ref.kind==='element')return elementPresentation(ref,value).title;
  if(ref.kind==='layer')return value.name||ref.id;
  if(ref.kind==='join')return 'Join';
  return ref.id;
}
const text=value=>value==null?'':typeof value==='string'?value:Array.isArray(value)?value.map(text).join('; '):typeof value==='object'?Object.entries(value).map(([k,v])=>k.replaceAll('_',' ')+': '+text(v)).join(' · '):String(value);

/* ---------- graph: HTML cards positioned by dagre, arrows without text ---------- */
const canvas=$('canvas'),cardsLayer=$('cards'),edgesLayer=$('edges');
function applyView(){const {x,y,k}=state.view;const transform=`translate(${x}px,${y}px) scale(${k})`;cardsLayer.style.transform=transform;edgesLayer.style.transform=transform;}
function zoomAt(point,factor){
  const k=Math.min(4,Math.max(.15,state.view.k*factor));const ratio=k/state.view.k;
  state.view={k,x:point.x-(point.x-state.view.x)*ratio,y:point.y-(point.y-state.view.y)*ratio};applyView();
}
canvas.addEventListener('wheel',event=>{event.preventDefault();const box=canvas.getBoundingClientRect();zoomAt({x:event.clientX-box.left,y:event.clientY-box.top},Math.pow(1.0015,-event.deltaY));},{passive:false});
let drag=null;
canvas.addEventListener('pointerdown',event=>{if(event.button!==0)return;drag={id:event.pointerId,x:event.clientX,y:event.clientY,view:{...state.view},moved:false};});
canvas.addEventListener('pointermove',event=>{if(!drag)return;const dx=event.clientX-drag.x,dy=event.clientY-drag.y;if(!drag.moved&&Math.abs(dx)+Math.abs(dy)>3){drag.moved=true;canvas.setPointerCapture(drag.id);}if(drag.moved){state.view={...drag.view,x:drag.view.x+dx,y:drag.view.y+dy};applyView();}});
canvas.addEventListener('pointerup',event=>{
  const moved=drag?.moved;drag=null;if(moved)return;
  const card=event.target.closest?.('.card'),edge=event.target.closest?.('path.hit');
  if(card)select(sceneNode(card.dataset.id)?.ref);else if(edge)select(state.scene?.edges.find(e=>e.id===edge.dataset.edge)?.ref);else select(null);
});
const sceneNode=id=>state.scene?.nodes.find(n=>n.id===id);
$('fit').onclick=()=>fit();
// When the canvas changes size, keep the cards in view without re-laying them out.
new ResizeObserver(()=>{if(state.scene)ensureVisible();}).observe(canvas);

function sceneBounds(){
  const nodes=state.scene?.nodes||[];if(!nodes.length)return null;
  let x1=Infinity,y1=Infinity,x2=-Infinity,y2=-Infinity;
  for(const n of nodes){x1=Math.min(x1,n.x);y1=Math.min(y1,n.y);x2=Math.max(x2,n.x+n.w);y2=Math.max(y2,n.y+n.h);}
  return {x1,y1,x2,y2,w:x2-x1,h:y2-y1};
}
function fit(){
  const box=sceneBounds();if(!box)return;const W=canvas.clientWidth,H=canvas.clientHeight,pad=40;
  // Fit the cards, but never below a readable zoom; when they do not fit, center on the focus card.
  const wanted=Math.min(1,(W-2*pad)/box.w,(H-2*pad)/box.h),k=Math.max(.6,wanted);
  const focal=state.scene.nodes.find(n=>n.id===state.scene.focus);
  if(wanted<.6&&focal)state.view={k,x:W/2-(focal.x+focal.w/2)*k,y:H/2-(focal.y+focal.h/2)*k};
  else state.view={k,x:(W-box.w*k)/2-box.x1*k,y:(H-box.h*k)/2-box.y1*k};
  applyView();
}
function ensureVisible(){
  const box=sceneBounds();if(!box)return;const W=canvas.clientWidth,H=canvas.clientHeight,pad=24,{k}=state.view;
  if(box.w*k+2*pad>W||box.h*k+2*pad>H){fit();return;}
  const x1=box.x1*k+state.view.x,y1=box.y1*k+state.view.y,x2=box.x2*k+state.view.x,y2=box.y2*k+state.view.y;
  let dx=0,dy=0;if(x1<pad)dx=pad-x1;else if(x2>W-pad)dx=W-pad-x2;if(y1<pad)dy=pad-y1;else if(y2>H-pad)dy=H-pad-y2;
  if(dx||dy){state.view={...state.view,x:state.view.x+dx,y:state.view.y+dy};applyView();}
}

function buildScene(envelope,focusRef){
  const records=envelope.records||[];
  const elements=records.filter(r=>r.ref.kind==='element'),joins=records.filter(r=>r.ref.kind==='join').map(r=>({ref:r.ref,...r.value}));
  const ids=new Set(elements.map(r=>refKey(r.ref)));
  const nodes=elements.map(r=>{const p=elementPresentation(r.ref,r.value);return {id:refKey(r.ref),ref:r.ref,value:r.value,...p,stripes:[],focus:refKey(r.ref)===refKey(focusRef)};});
  const byId=new Map(nodes.map(n=>[n.id,n]));
  const edges=[];
  for(const join of joins){
    const source=refKey(join.provider),target=refKey(join.receiver);
    if(join.role==='property'&&join.provider?.kind==='type'){
      // A property applies to its receiver: the color goes on the receiving card, not on an arrow.
      const node=byId.get(target);if(node)node.stripes.push({color:stripeColor(join.provider.id),title:typeName(known(join.provider))||join.provider.id,join});
      continue;
    }
    if(ids.has(source)&&ids.has(target)&&source!==target)edges.push({id:refKey(join.ref),ref:join.ref,join,source,target});
  }
  return {nodes,edges,joins,focus:refKey(focusRef)};
}
function renderCards(scene){
  cardsLayer.replaceChildren();
  for(const node of scene.nodes){
    const card=el('div',null,'card'+(node.exterior?' exterior':'')+(node.focus?' focus':''));card.dataset.id=node.id;card.dataset.base=node.base;
    if(refKey(node.ref)===refKey(state.artifact))card.append(el('span','ARTIFACT','badge'));
    card.append(el('div',node.title,'title'));if(node.subtitle)card.append(el('div',node.subtitle,'subtitle'));
    if(node.stripes.length){const stripes=el('div',null,'stripes');for(const s of node.stripes){const i=el('i');i.style.background=s.color;i.title=s.title;stripes.append(i);}card.append(stripes);}
    card.ondblclick=event=>{event.stopPropagation();open(node.ref);};
    cardsLayer.append(card);node.element=card;
  }
  for(const node of scene.nodes){node.w=node.element.offsetWidth;node.h=node.element.offsetHeight;}
}
function layout(scene,anchorId){
  const previous=state.positions;
  const cy=cytoscape({headless:true,styleEnabled:true,style:[{selector:'node',style:{width:'data(w)',height:'data(h)',shape:'rectangle'}}],
    elements:[...scene.nodes.map(n=>({data:{id:n.id,w:n.w,h:n.h}})),...scene.edges.map(e=>({data:{id:e.id,source:e.source,target:e.target}}))]});
  cy.layout({name:'dagre',rankDir:'LR',nodeSep:26,rankSep:120,edgeSep:12,fit:false,animate:false}).run();
  for(const node of scene.nodes){const p=cy.getElementById(node.id).position();node.x=p.x-node.w/2;node.y=p.y-node.h/2;}
  cy.destroy();
  const same=scene.nodes.every(n=>previous.has(n.id))&&previous.size===scene.nodes.length;
  if(same)for(const node of scene.nodes){const p=previous.get(node.id);node.x=p.x;node.y=p.y;}
  else{const old=previous.get(anchorId),node=scene.nodes.find(n=>n.id===anchorId);
    if(old&&node){const dx=old.x-node.x,dy=old.y-node.y;for(const n of scene.nodes){n.x+=dx;n.y+=dy;}}}
  state.positions=new Map(scene.nodes.map(n=>[n.id,{x:n.x,y:n.y}]));
  return !(same||(previous.get(anchorId)&&scene.nodes.some(n=>n.id===anchorId)));
}
function place(scene){
  for(const node of scene.nodes){node.element.style.left=node.x+'px';node.element.style.top=node.y+'px';}
  const byId=new Map(scene.nodes.map(n=>[n.id,n]));
  for(const path of edgesLayer.querySelectorAll('path[data-edge]'))path.remove();
  for(const edge of scene.edges){
    const s=byId.get(edge.source),t=byId.get(edge.target);
    const x1=s.x+s.w,y1=s.y+s.h/2,x2=t.x,y2=t.y+t.h/2,bend=Math.max(40,Math.abs(x2-x1)/2);
    const d=`M${x1} ${y1} C${x1+bend} ${y1} ${x2-bend} ${y2} ${x2} ${y2}`;
    for(const cls of ['hit',edge.join.role.replace(' ','-')]){
      const path=document.createElementNS('http://www.w3.org/2000/svg','path');path.setAttribute('d',d);path.setAttribute('class',cls);path.dataset.edge=edge.id;
      edgesLayer.append(path);
    }
  }
}
function highlight(){
  const key=state.selected?refKey(state.selected):'';
  for(const card of cardsLayer.children)card.classList.toggle('selected',card.dataset.id===key);
  for(const path of edgesLayer.querySelectorAll('path[data-edge]'))if(!path.classList.contains('hit'))path.classList.toggle('selected',path.dataset.edge===key);
}

/* ---------- navigation ---------- */
let opening=0;
async function open(ref,{push=true}={}){
  if(!ref)return;const sequence=++opening;
  try{
    if(ref.kind==='type')return showMembers(ref);
    const envelope=await read('graph.neighbors',{target:ref,limit:80});if(sequence!==opening)return;
    state.focus=envelope.resolved_target||ref;
    const scene=buildScene(envelope,state.focus);renderCards(scene);const fresh=layout(scene,refKey(state.focus));place(scene);state.scene=scene;
    $('graph-title').textContent=nameOf(state.focus);$('graph-count').textContent=`${scene.nodes.length} cards · ${scene.joins.length} joins`;
    panelCall($('graph'),'graph.neighbors',{target:ref,limit:80},envelope);
    if(fresh)fit();else ensureVisible();
    await select(state.focus);urlSync();
  }catch(error){notice(error.message);}
}
async function showMembers(typeRef){
  const args={target:typeRef,descendants:true,limit:80};
  const envelope=await read('type.members',args);
  state.focus=typeRef;
  const scene=buildScene(envelope,null);renderCards(scene);layout(scene,null);place(scene);state.scene=scene;fit();
  $('graph-title').textContent='Members of '+nameOf(typeRef);$('graph-count').textContent=`${scene.nodes.length} cards`;
  panelCall($('graph'),'type.members',args,envelope);
  await select(typeRef);urlSync();
}

/* ---------- inspector ---------- */
let inspecting=0;
async function select(ref){
  state.selected=ref;highlight();const host=$('inspector').querySelector('.panel-body');
  if(!ref){host.replaceChildren(el('p','Click a card or an arrow.','quiet'));$('inspector-title').textContent='Inspector';return;}
  const sequence=++inspecting;
  const operation={element:'element.inspect',type:'type.inspect',join:'join.inspect',layer:'layer.inspect'}[ref.kind];
  try{
    const envelope=await read(operation,{target:ref});if(sequence!==inspecting)return;
    panelCall($('inspector'),operation,{target:ref},envelope);
    const target=envelope.resolved_target||ref,value=known(target);host.replaceChildren();
    $('inspector-title').textContent={element:'Element',type:'Type',join:'Join',layer:'Layer'}[target.kind];
    if(!value){host.append(el('p','Nothing was resolved for this reference.','quiet'));return;}
    ({element:inspectElement,type:inspectType,join:inspectJoin,layer:inspectLayer})[target.kind](host,target,value,envelope);
    if(target.kind==='element'||target.kind==='type')await knowledgeSection(host,target,sequence);
  }catch(error){notice(error.message);}
}
const link=ref=>{const button=el('button',nameOf(ref),'ref');button.onclick=()=>ref.kind==='join'||ref.kind==='layer'?select(ref):open(ref);return button;};
function field(host,label,value){if(value==null||value==='')return;host.append(el('h3',label));host.append(el('p',text(value)));}
function inspectElement(host,ref,value){
  const p=elementPresentation(ref,value);
  host.append(el('h1',p.title));if(p.subtitle)host.append(el('p',p.subtitle,'subtitle'));
  if(p.types.length){host.append(el('h3',p.types.length>1?'Types':'Type'));for(const binding of bindingsOf(ref)){const row=el('p');row.append(link(binding.type));host.append(row);}}
  const d=value.description;
  if(typeof d==='string')field(host,'Description',d);
  else if(d){field(host,'Account',d.account);field(host,'Identity test',d.identity_test);
    if(d.receivers?.length){host.append(el('h3','Receivers'));for(const r of d.receivers){const row=el('p');const target={owner:ref.owner,kind:'element',id:r.ref};row.append(known(target)?link(target):el('span',r.ref));if(r.role)row.append(el('span',' · '+r.role,'quiet'));host.append(row);}}
    field(host,'Notes',d.notes);field(host,'Assessment',d.assessment_status);}
  if(value.summary&&value.summary!==d)field(host,'Summary',value.summary);
  field(host,'Boundary',value.boundary);
  joinsSection(host,ref);
}
function joinsSection(host,ref){
  const joins=state.scene?.joins||[];const key=refKey(ref);
  const receives=joins.filter(j=>refKey(j.receiver)===key),provides=joins.filter(j=>refKey(j.provider)===key);
  const counts=known(ref)?.relationship_counts;
  const render=(title,items,other)=>{if(!items.length)return;host.append(el('h3',title));for(const join of items){const box=el('div',null,'join '+join.role.replace(' ','-'));const head=el('div');
    if(join.role==='property'&&join.provider.kind==='type'){const swatch=el('span',null,'swatch');swatch.style.background=stripeColor(join.provider.id);head.append(swatch);}
    head.append(link(other(join)));if(other(join)===join.provider&&join.provider_type&&join.provider.kind!=='type'&&nameOf(join.provider_type)!==nameOf(join.provider)){head.append(el('span',' as ','quiet'));head.append(link(join.provider_type));}
    box.append(head,el('div',join.role,'role'));if(join.purpose)box.append(el('p',text(join.purpose)));if(join.signal)box.append(el('p',text(join.signal),'quiet'));
    const inspect=el('button','Join','ref');inspect.onclick=()=>select(join.ref);box.append(inspect);host.append(box);}};
  render('Receives through its Operative Purposes',receives,j=>j.provider);render('Provides to',provides,j=>j.receiver);
  const shown=receives.length+provides.length,total=$('inspector')._call?.envelope?.relationship_counts?.total;
  if(total&&total>shown)host.append(el('p',`${total-shown} more joins are outside this neighborhood. Double-click the card to center on it.`,'quiet'));
}
function inspectType(host,ref,value,envelope){
  host.append(el('h1',typeName(value)));host.append(el('p',value.id,'subtitle'));
  field(host,'Encounter Function',value.ef);field(host,'Description',value.description);
  if(value.aliases?.length)field(host,'Aliases',value.aliases.join(', '));
  if(value.parametric_elements?.length)field(host,'Parametric',value.parametric_elements.map(text).join(', '));
  const narrowings=(envelope.records||[]).filter(r=>r.ref.kind==='narrowing').map(r=>r.value);
  const parents=narrowings.filter(n=>refKey(n.child)===refKey(ref)),children=narrowings.filter(n=>refKey(n.parent)===refKey(ref));
  if(parents.length){host.append(el('h3','Narrows'));for(const n of parents)host.append(link(n.parent));}
  if(children.length){host.append(el('h3','Narrowed by'));for(const n of children){const row=el('p');row.append(link(n.child));host.append(row);}}
  const detected=(envelope.records||[]).filter(r=>r.ref.kind==='subtype'&&refKey(r.value.parent||{})===refKey(ref));
  if(detected.length){host.append(el('h3','Detected subtypes, inactive'));for(const item of detected)host.append(el('p',item.ref.id,'quiet'));}
  if(envelope.counts){host.append(el('h3','Members'));const row=el('p',`${envelope.counts.direct} direct · ${envelope.counts.descendant} through narrower Types `);const show=el('button','Show members','ref');show.onclick=()=>showMembers(ref);row.append(show);host.append(row);}
}
function inspectJoin(host,ref,value){
  host.append(el('h1',cap(value.role)));
  host.append(el('h3','Receiving Entity'));host.append(link(value.receiver));
  host.append(el('h3','Provider'));const row=el('p');row.append(link(value.provider));if(value.provider_type&&refKey(value.provider_type)!==refKey(value.provider)){row.append(el('span',' as ','quiet'));row.append(link(value.provider_type));}host.append(row);
  field(host,'Operative Purpose',value.purpose);field(host,'Signal',value.signal);
  for(const participant of value.participants||[]){const p=el('p');p.append(el('span',participant.role+': ','quiet'),link(participant.ref));host.append(p);}
}
function inspectLayer(host,ref,value){
  host.append(el('h1',value.name||ref.id));field(host,'Description',value.description);field(host,'State',value.state);
  if(value.selector?.targets?.length){host.append(el('h3','Subjects'));for(const t of value.selector.targets){const row=el('p');row.append(link(t));host.append(row);}}
  if(value.coverage)field(host,'Coverage',value.coverage);
}
async function knowledgeSection(host,ref,sequence){
  const args={target:ref,layers:state.layer?[state.layer]:null,limit:50};
  const envelope=await read('knowledge.get',args);if(sequence!==inspecting)return;
  const items=(envelope.records||[]).filter(r=>r.ref.kind==='knowledge').map(r=>r.value);
  const section=el('div');section.append(el('h3','Knowledge'+(state.layer?' in the selected layer':'')));
  if(!items.length)section.append(el('p','No knowledge applies here.','quiet'));
  for(const item of items){
    const box=el('div',null,'join');const layer=item.layer?known(item.layer):null;
    box.append(el('div',(layer?.name||'')+(item.slot?' · '+item.slot:''),'role'));
    box.append(el('p',text(item.payload)));if(item.applicability?.reason)box.append(el('p',item.applicability.reason,'quiet'));section.append(box);
  }
  const flip=el('button','{ } knowledge.get','ref');flip.onclick=()=>{panelCall($('inspector'),'knowledge.get',args,envelope);$('inspector').querySelector('.envelope-toggle').click();};section.append(flip);
  host.append(section);
}

/* ---------- namespace tree ---------- */
async function loadTree(){
  const body=$('tree').querySelector('.panel-body');body.replaceChildren();
  const envelope=await read('namespace.browse',{});panelCall($('tree'),'namespace.browse',{},envelope);
  const list=el('ul');body.append(list);
  for(const item of (envelope.records||[]).filter(r=>r.ref.kind==='type'))list.append(treeRow(item.ref,item.value,true));
}
function treeRow(ref,value,base){
  const li=el('li'),row=el('div',null,'row'),twist=el('button','▸','twist'),name=el('button',typeName(value),'name'+(base?' base':''));
  name.title=value.ef||value.description||'';name.onclick=()=>{for(const b of $('tree').querySelectorAll('.name'))b.removeAttribute('aria-current');name.setAttribute('aria-current','true');showMembers(ref);};
  let children=null;
  twist.onclick=async()=>{
    if(children){children.hidden=!children.hidden;twist.textContent=children.hidden?'▸':'▾';return;}
    twist.textContent='…';
    try{const envelope=await read('namespace.browse',{target:ref});children=el('ul');
      const rows=(envelope.records||[]).filter(r=>r.ref.kind==='type'&&refKey(r.ref)!==refKey(ref));
      const inactive=(envelope.records||[]).filter(r=>r.ref.kind==='subtype');
      if(!rows.length&&!inactive.length){twist.classList.add('leaf');twist.textContent='▸';return;}
      for(const item of rows)children.append(treeRow(item.ref,item.value,false));
      for(const item of inactive)children.append(subtypeRow(item.ref,item.value));
      li.append(children);twist.textContent='▾';
    }catch(error){twist.textContent='▸';notice(error.message);}
  };
  row.append(twist,name);li.append(row);return li;
}
function subtypeRow(ref,value){
  const li=el('li'),row=el('div',null,'row'),twist=el('span','·','twist leaf'),name=el('span',typeName({id:ref.id}),'name inactive');
  name.title='Detected subtype, inactive: an annealed address held beneath '+(value.parent?.id||'its main type')+' for memories and addresses.';
  row.append(twist,name);li.append(row);return li;
}

/* ---------- layers, stage, models ---------- */
async function loadLayers(){
  const envelope=await read('layer.list',{});state.layers=(envelope.records||[]).filter(r=>r.ref.kind==='layer');
  const chooser=$('layer');chooser.replaceChildren(new Option('All active layers',''));
  for(const item of state.layers)chooser.append(new Option(item.value.name+(item.value.state&&item.value.state!=='complete'?' · '+item.value.state:''),item.value.id));
  chooser.value=state.layers.some(l=>l.value.id===state.layer)?state.layer:'';state.layer=chooser.value;
}
$('layer').onchange=()=>{state.layer=$('layer').value;urlSync();if(state.selected)select(state.selected);};
async function loadStage(){
  const stage=$('stage');
  try{const envelope=await api('/api/semantic/guide.start',state.model?{model:state.model}:{});panelCall(stage,'guide.start',state.model?{model:state.model}:{},envelope);
    stage.querySelector('.stage-status').textContent=(envelope.status||'').replaceAll('_',' ');
    const guidance=text(envelope.guidance)+(envelope.next?.command?' · next: '+envelope.next.command:'');stage.querySelector('.stage-guidance').textContent=guidance;stage.title=guidance;
  }catch(error){stage.querySelector('.stage-status').textContent='guide.start';stage.querySelector('.stage-guidance').textContent=error.message;}
}
async function loadModels(){
  const envelope=await read('model.discover',{model:undefined});state.models=envelope.models||[];
  const chooser=$('model');chooser.replaceChildren();
  for(const entry of state.models)chooser.append(new Option(entry.model.model+' · '+String(entry.model.revision||'').slice(0,8),entry.model.model));
  const wanted=new URL(location.href).searchParams.get('model');
  const entry=state.models.find(e=>e.model.model===wanted)||state.models[0];
  if(!entry){$('graph-title').textContent='No foundation has been published';$('graph-count').textContent='Run metaform in the project folder to start an intake.';return false;}
  state.model=entry.model;state.artifact=entry.artifact;chooser.value=entry.model.model;return true;
}
$('model').onchange=async()=>{const entry=state.models.find(e=>e.model.model===$('model').value);if(!entry)return;state.model=entry.model;state.artifact=entry.artifact;state.positions=new Map();state.focus=null;await Promise.all([loadTree(),loadLayers(),loadStage()]);await open(state.artifact);};

/* ---------- console ---------- */
let tools=[];
$('show-console').onclick=()=>{const console_=$('console');console_.hidden=!console_.hidden;$('show-console').setAttribute('aria-pressed',String(!console_.hidden));if(!console_.hidden&&!tools.length)loadConsole().catch(error=>notice(error.message));};
$('close-console').onclick=()=>{$('console').hidden=true;$('show-console').setAttribute('aria-pressed','false');};
for(const button of document.querySelectorAll('.console-tabs button[data-tab]'))button.onclick=()=>{
  for(const b of document.querySelectorAll('.console-tabs button[data-tab]'))b.setAttribute('aria-pressed',String(b===button));
  for(const page of document.querySelectorAll('.console-page'))page.hidden=page.dataset.page!==button.dataset.tab;
  if(button.dataset.tab==='calls')loadCalls().catch(error=>notice(error.message));
};
async function loadConsole(){
  const [agent,init]=await Promise.all([api('/api/agent/tools'),api('/api/agent/instructions')]);tools=agent.tools||[];
  const chooser=$('tool');chooser.replaceChildren();for(const tool of tools)chooser.append(new Option(tool.name,tool.name));
  chooser.onchange=()=>{const tool=tools.find(t=>t.name===chooser.value);$('tool-description').textContent=tool?.description||'';$('tool-schema').textContent=pretty(tool?.inputSchema||{});
    const example={};if(state.model&&tool?.inputSchema?.properties?.model)example.model=state.model;if(tool?.inputSchema?.properties?.target&&state.selected)example.target=state.selected;$('tool-args').value=pretty(example);};
  chooser.value=tools.some(t=>t.name==='element.inspect')?'element.inspect':chooser.value;chooser.onchange();
  $('instructions').textContent=init.instructions||'';
  const list=$('tool-list');list.replaceChildren();for(const tool of tools){const row=el('div');row.append(el('b',tool.name),el('span',' '+(tool.description||'')));list.append(row);}
}
$('run-tool').onclick=async()=>{
  let args;try{args=JSON.parse($('tool-args').value||'{}');}catch{notice('Arguments must be JSON.');return;}
  $('tool-result').textContent='…';
  try{const result=await api('/api/semantic/'+$('tool').value,args);remember(result);$('tool-result').textContent=pretty(result);}
  catch(error){$('tool-result').textContent=error.message;}
};
async function loadCalls(){
  const calls=await api('/api/trace');const body=$('call-table').querySelector('tbody');body.replaceChildren();
  for(const call of calls){const row=el('tr');row.append(el('td',call.path.replace('/api/semantic/','')+(call.query?'?'+call.query:'')),el('td',String(call.ms)),el('td',String(call.bytes??'')));body.append(row);}
}

/* ---------- palette ---------- */
(()=>{const chooser=$('palette');let saved='';try{saved=localStorage.getItem('metaform-palette')||'';}catch{}
  const wanted=new URL(location.href).searchParams.get('palette')||saved||'graphite';
  const apply=name=>{document.documentElement.dataset.palette=name;chooser.value=name;try{localStorage.setItem('metaform-palette',name);}catch{}};
  apply(wanted);chooser.onchange=()=>apply(chooser.value);})();

/* ---------- help ---------- */
$('show-help').onclick=()=>{$('help').showModal();$('show-help').setAttribute('aria-pressed','true');};
$('clear-project').onclick=async()=>{if(!confirm("Clear this project's Metaform data? Every model, run and layer of this project goes. The folder and its files stay."))return;try{await api('/api/semantic/project.clear',{});location.reload();}catch(error){notice(error.message);}};
$('close-help').onclick=()=>$('help').close();
$('help').addEventListener('close',()=>$('show-help').setAttribute('aria-pressed','false'));

/* ---------- projects: every project the workbench knows; choosing one opens its page ---------- */
async function loadProjects(){
  const projects=await api('/api/projects'),chooser=$('project');chooser.replaceChildren();
  for(const project of projects){const option=new Option(project.name||project.path,project.url);option.title=project.path;option.selected=String(project.url).replace(/\/$/,'')===prefix;chooser.append(option);}
  chooser.onchange=()=>{location.href=chooser.value;};
}

/* ---------- start ---------- */
(async()=>{
  try{
    await loadProjects();
    const url=new URL(location.href);state.layer=url.searchParams.get('layer')||'';
    if(!await loadModels())return;
    await Promise.all([loadTree(),loadLayers(),loadStage()]);
    const focus=url.searchParams.get('focus');const [kind,...rest]=(focus||'').split(':');
    await open(kind&&rest.length?{owner:state.artifact?.owner,kind,id:rest.join(':')}:state.artifact);
  }catch(error){notice(error.message);}
})();

/* ---------- jobs: any run as its steps; intake as a growing graph ---------- */
const jobs={runs:[],harnesses:[],current:null,events:[],step:null,timer:null,at:0};
for(const button of document.querySelectorAll('.side-tabs button'))button.onclick=()=>showSide(button.dataset.side);
function showSide(side){
  for(const b of document.querySelectorAll('.side-tabs button'))b.setAttribute('aria-pressed',String(b.dataset.side===side));
  for(const body of document.querySelectorAll('#tree .panel-body'))body.hidden=body.dataset.side!==side;
  if(side==='jobs')loadJobs().catch(error=>notice(error.message));
}
const when=iso=>iso?String(iso).replace('T',' ').slice(0,19):'';
async function loadJobs(){
  const data=await api('/api/jobs');jobs.runs=data.runs||[];jobs.harnesses=data.harnesses||[];
  const chooser=$('harness');const chosen=chooser.value;chooser.replaceChildren();
  for(const h of jobs.harnesses){const option=new Option(h.name+(h.available?'':' (not installed)'),h.name);option.disabled=!h.available;chooser.append(option);}
  if(chosen&&jobs.harnesses.some(h=>h.name===chosen))chooser.value=chosen;
  const list=$('job-list');list.replaceChildren();
  if(!jobs.runs.length)list.append(el('li','No runs recorded yet.','quiet'));
  for(const run of jobs.runs){
    const row=el('li');row.dataset.id=run.id;if(run.id===jobs.current?.id)row.setAttribute('aria-current','true');
    const live=run.drive?.status==='running';
    row.append(el('div',run.workflow.replace('metaform.','')+(run.drive?' · '+run.drive.harness:'')),el('div',when(run.updated),'when'),el('span',live?'live':run.status,'status '+(live?'live':run.status)));
    if(run.drive?.error)row.append(el('div',run.drive.error,'quiet'));
    row.onclick=()=>openJob(run.id).catch(error=>notice(error.message));list.append(row);
  }
}
$('start-intake').onclick=async()=>{
  try{const harness=$('harness').value;if(!harness){notice('No harness is available to run the intake.');return;}
    $('start-intake').disabled=true;const started=await api('/api/jobs/intake',{harness});notice('Intake started with '+harness+'.');
    await loadJobs();await openJob(started.run_id);}
  catch(error){notice(error.message);}finally{$('start-intake').disabled=false;}
};
async function openJob(id){
  const [run,events]=await Promise.all([api('/api/run/'+encodeURIComponent(id)),api('/api/run/'+encodeURIComponent(id)+'/events')]);
  const fresh=jobs.current?.id!==id;jobs.current=run;jobs.events=events;
  for(const row of $('job-list').children)row.toggleAttribute('aria-current',row.dataset.id===id);
  renderSteps(fresh);
  clearInterval(jobs.timer);jobs.timer=null;
  const live=run.status==='running'||jobs.runs.find(r=>r.id===id)?.drive?.status==='running';
  if(live)jobs.timer=setInterval(()=>refreshJob(id).catch(()=>{}),3000);
}
async function refreshJob(id){
  if(jobs.current?.id!==id)return;
  const [run,events,list]=await Promise.all([api('/api/run/'+encodeURIComponent(id)),api('/api/run/'+encodeURIComponent(id)+'/events'),api('/api/jobs')]);
  jobs.runs=list.runs||[];
  const grew=(run.submissions||[]).length!==(jobs.current.submissions||[]).length||run.status!==jobs.current.status||events.length!==jobs.events.length;
  jobs.current=run;jobs.events=events;
  if(grew){renderSteps(false);await loadJobs();}
  const entry=jobs.runs.find(r=>r.id===id)?.drive;
  if(run.status!=='running'&&entry?.status!=='running'){clearInterval(jobs.timer);jobs.timer=null;if(run.status==='complete'&&run.result?.model)await publishedFoundation();}
}
// A completed intake published a foundation: let the explorer offer it without a reload.
async function publishedFoundation(){
  const had=state.model;if(!await loadModels())return;
  await Promise.all([loadTree(),loadLayers(),loadStage()]);
  if(!had){notice('The foundation is published. Open the Namespace tab to browse it.');}
}
function isIntake(run){return run.kind==='intake'||run.workflow==='metaform.intake';}
function jobSteps(run){
  const steps=[];
  const assignment=run.assignment_snapshot||run.pending||Object.values(run.assignments||{})[0];
  if(assignment)steps.push({kind:'prompt sent',title:assignment.role||assignment.prompt_ref||'Assignment',assignment});
  if(isIntake(run)){
    (run.context_reads||[]).forEach((envelope,i)=>steps.push({kind:'read',title:'Read '+(i+1)+': '+(envelope.query?.operation||envelope.query?.query||'context')+' · '+(envelope.records||[]).length+' records',envelope}));
    (run.source_evidence||[]).forEach((evidence,i)=>steps.push({kind:'evidence',title:evidence.path||evidence.description||'Evidence '+(i+1),evidence}));
    (run.submissions||[]).forEach((submission,i)=>steps.push({kind:'answer',title:'Submission '+(i+1)+' · '+summarizeContribution(submission.answer),submission,index:i+1}));
  }
  for(const event of jobs.events){if(['assignment','debug.assignment'].includes(event.kind))continue;steps.push({kind:event.kind,title:when(event.created),event});}
  if(run.result)steps.push({kind:'result',title:run.status+(run.result?.model?.revision?' · '+String(run.result.model.revision).slice(0,8):''),result:run.result});
  return steps;
}
function summarizeContribution(answer){
  if(!answer||typeof answer!=='object')return '';
  const parts=[];for(const key of ['types','elements','bindings','joins','narrowings','refinements']){const value=answer[key];const n=Array.isArray(value)?value.length:value&&typeof value==='object'?Object.keys(value).length:0;if(n)parts.push(n+' '+key);}
  return parts.join(', ')||'no records';
}
function renderSteps(fresh){
  const run=jobs.current;$('job-steps').hidden=false;$('job-title').textContent=run.workflow.replace('metaform.','')+' · '+run.status;
  const steps=jobSteps(run);const list=$('step-list');list.replaceChildren();
  steps.forEach((step,i)=>{const row=el('li');row.append(el('div',step.kind,'kind'),el('div',step.title));row.onclick=()=>showStep(step,row);list.append(row);step.row=row;});
  const submissions=(run.submissions||[]).length,scrub=$('scrub');const atEnd=fresh||Number(scrub.value)>=Number(scrub.max);
  scrub.max=submissions;if(atEnd)scrub.value=submissions;scrub.parentElement.hidden=!isIntake(run);
  scrub.oninput=()=>replay(Number(scrub.value));
  if(isIntake(run))replay(Number(scrub.value));
  if(fresh){const first=steps[0];if(first)showStep(first,first.row);}
}
function contributionsUpTo(run,count){
  const draft={types:{},elements:{},bindings:[],joins:[],narrowings:[],refinements:[]};
  const lists={bindings:new Map(),joins:new Map(),narrowings:new Map(),refinements:new Map()};
  for(const submission of (run.submissions||[]).slice(0,count)){
    const answer=submission.expanded||{};
    for(const key of ['types','elements'])for(const [id,value] of Object.entries(answer[key]||{}))draft[key][id]={id,...value};
    for(const key of Object.keys(lists))for(const item of answer[key]||[])lists[key].set(item.id||JSON.stringify(item),item);
    for(const key of ['artifact','understanding'])if(answer[key]!==undefined)draft[key]=answer[key];
  }
  for(const key of Object.keys(lists))draft[key]=[...lists[key].values()];
  return draft;
}
function replay(count){
  const run=jobs.current,draft=contributionsUpTo(run,count),owner=run.model?.project?'project:'+run.model.project:(draft.artifact?.owner||'');
  const ref=(kind,value,id)=>({owner:value.owner||owner,kind,id:value.id||id});
  const records=[];
  for(const [id,value] of Object.entries(draft.types))records.push({ref:ref('type',value,id),value:{...value,id:value.id||id}});
  for(const [id,value] of Object.entries(draft.elements))records.push({ref:ref('element',value,id),value:{...value,id:value.id||id}});
  for(const value of draft.bindings)records.push({ref:ref('binding',value,value.id||'binding:'+records.length),value});
  for(const value of draft.joins)records.push({ref:ref('join',value,value.id||'join:'+records.length),value});
  const envelope={records};remember(envelope);
  const focus=draft.artifact&&draft.artifact.kind?draft.artifact:null;
  const scene=buildScene(envelope,focus);renderCards(scene);const freshLayout=layout(scene,focus?refKey(focus):null);place(scene);state.scene=scene;
  $('graph-title').textContent='Intake replay · after submission '+count+' of '+(run.submissions||[]).length;$('graph-count').textContent=`${scene.nodes.length} cards · ${scene.joins.length} joins`;
  $('scrub-label').textContent='After submission '+count+' of '+(run.submissions||[]).length;
  panelCall($('graph'),'intake contributions',{run_id:run.id,submissions:count},draft);
  if(freshLayout)fit();else ensureVisible();
}
function showStep(step,row){
  for(const other of $('step-list').children)other.removeAttribute('aria-current');row?.setAttribute('aria-current','true');jobs.step=step;
  const host=$('inspector').querySelector('.panel-body');host.replaceChildren();$('inspector-title').textContent=step.kind;
  const run=jobs.current;
  if(step.assignment){
    const a=step.assignment;host.append(el('h1','Prompt sent'));host.append(el('p',(a.prompt_ref||'')+(a.prompt_revision?' · revision '+String(a.prompt_revision).slice(0,8):''),'subtitle'));
    host.append(el('h3','Authored prompt'));const box=el('textarea');box.value=a.source_prompt||a.prompt||'';host.append(box);
    const actions=el('div',null,'actions');const save=el('button','Save prompt'),rerun=el('button','Run again with '+($('harness').value||'the chosen harness'));
    save.onclick=async()=>{try{await api('/api/prompt/'+encodeURIComponent(a.prompt_ref),{text:box.value});notice('Prompt saved. The next intake composes from this text.');}catch(error){notice(error.message);}};
    rerun.onclick=async()=>{try{if(box.value!==(a.source_prompt||a.prompt||''))await api('/api/prompt/'+encodeURIComponent(a.prompt_ref),{text:box.value});const started=await api('/api/jobs/intake',{harness:$('harness').value});notice('New intake started.');await loadJobs();await openJob(started.run_id);}catch(error){notice(error.message);}};
    if(a.prompt_ref)actions.append(save,rerun);host.append(actions);
    for(const component of a.components||[]){const d=el('details');d.append(el('summary',component.id+' · '+String(component.revision).slice(0,8)),el('pre',component.text));host.append(d);}
    if(a.inputs){const d=el('details');d.append(el('summary','Inputs the agent received'),el('pre',pretty(a.inputs)));host.append(d);}
    if(a.schema_ref||a.schema){host.append(el('h3','Answer schema'));host.append(el('p',text(a.schema_ref||a.schema?.$id||'inline')));}
    panelCall($('inspector'),'assignment',{run_id:run.id},a);
  }else if(step.envelope){host.append(el('h1','What the agent read'));host.append(el('pre',pretty(step.envelope)));panelCall($('inspector'),'intake.'+(step.envelope.query?.operation||'read'),step.envelope.query||{},step.envelope);}
  else if(step.evidence){host.append(el('h1',step.evidence.path||'Evidence'));host.append(el('pre',pretty(step.evidence)));panelCall($('inspector'),'intake.read',{path:step.evidence.path},step.evidence);}
  else if(step.submission){host.append(el('h1','Submission '+step.index));host.append(el('p',when(step.submission.created),'subtitle'));$('scrub').value=step.index;replay(step.index);
    if(step.submission.annotations?.length){host.append(el('h3','Annotations'));host.append(el('pre',pretty(step.submission.annotations)));}
    host.append(el('h3','Answer'));host.append(el('pre',pretty(step.submission.answer)));panelCall($('inspector'),'intake.put',{run_id:run.id},step.submission);}
  else if(step.event){host.append(el('h1',step.event.kind));host.append(el('p',when(step.event.created),'subtitle'));host.append(el('pre',pretty(step.event.body)));panelCall($('inspector'),'event '+step.event.kind,{run_id:run.id},step.event.body);}
  else if(step.result){host.append(el('h1','Result'));host.append(el('p',run.status,'subtitle'));host.append(el('pre',pretty(step.result)));
    if((run.diagnostics||[]).length){host.append(el('h3','Diagnostics'));host.append(el('pre',pretty(run.diagnostics)));}
    compareSection(host,run);panelCall($('inspector'),'intake result',{run_id:run.id},step.result);}
}
function runCounts(run){const d=contributionsUpTo(run,(run.submissions||[]).length);return {submissions:(run.submissions||[]).length,types:Object.keys(d.types).length,elements:Object.keys(d.elements).length,bindings:d.bindings.length,joins:d.joins.length,diagnostics:(run.diagnostics||[]).length,status:run.status};}
function compareSection(host,run){
  const others=jobs.runs.filter(r=>r.id!==run.id&&r.workflow==='metaform.intake');if(!others.length)return;
  host.append(el('h3','Compare with another intake'));const chooser=el('select');chooser.append(new Option('Choose a run',''));for(const other of others)chooser.append(new Option(when(other.updated)+' · '+other.status,other.id));host.append(chooser);
  const table=el('table');host.append(table);
  chooser.onchange=async()=>{if(!chooser.value)return;const other=await api('/api/run/'+encodeURIComponent(chooser.value));const a=runCounts(run),b=runCounts(other);table.replaceChildren();
    const head=el('tr');head.append(el('th',''),el('th','This run'),el('th','Other run'));table.append(head);
    for(const key of Object.keys(a)){const row=el('tr');row.append(el('td',key),el('td',String(a[key])),el('td',String(b[key])));table.append(row);}
    const show=el('button','Open the other run','ref');show.onclick=()=>openJob(other.id);host.append(show);};
}
