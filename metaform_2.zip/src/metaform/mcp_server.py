from __future__ import annotations

import asyncio
import os
import copy
import json
import signal
import sys
import threading

try:
    from mcp import types
    from mcp.server import NotificationOptions, Server
    from mcp.server.stdio import stdio_server
except ModuleNotFoundError as exc:
    if exc.name != "mcp":
        raise
    types = None

from . import __version__, schemas
from .app import App
from .continuation import pending_assignment
from .registry import Registry
from .onboarding import instructions
from .util import dumps


class Context:
    def __init__(self, app, request, session=None):
        self.app, self.request, self.project_session = app, request, session

    def select_project(self, selector):
        if self.app.binding:
            raise ValueError("Project selection cannot change a bound assignment")
        if self.project_session is None:
            raise ValueError("Project selection requires a client session")
        return self.project_session.select(selector)

    def remember(self, pending):
        token = self.app.identifier()
        self.app.set("sampling:" + token, pending)
        if self.project_session is not None:
            self.project_session.sampling_apps[token] = self.app
        return token

    def prepare(self, job, answer_command):
        from .prompts import inference_payload

        payload = {
            k: v
            for k, v in inference_payload(job).items()
            if k not in {"run_id", "request_id", "workfolder", "system_prompt"}
        }
        if (
            payload.get("prompt_ref") in {"prompt:metaform.intake.native", "prompt:metaform.intake.archaeology"}
            and payload.get("source_prompt")
            and payload["source_prompt"] in payload.get("prompt", "")
        ):
            payload.pop("source_prompt")
        payload["schema"] = schemas.bundled(self.app, job.get("schema"))
        params = types.CreateMessageRequestParams.model_validate(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": {"type": "text", "text": dumps(payload)},
                    }
                ],
                "includeContext": "none",
                "systemPrompt": job.get("system_prompt"),
                "maxTokens": self.app.config.get("sampling_max_tokens", 8192),
            }
        )
        capabilities = self.request.session.client_capabilities
        sampling = capabilities.sampling if capabilities else None
        if sampling is None:
            return job | {
                "transport": "host_answer_loop",
                "message": "Submit the assignment's answer through its answer command; this client does not advertise sampling.",
            }
        if sampling.tools is not None:
            params.tools = [
                types.Tool.model_validate(c.definition(self.app))
                for c in Registry(self.app).visible().values()
                if c.key in job.get("tools", [])
            ]
        self.app.trace("sampling.request", payload, job["run_id"])
        return {
            "run_id": job["run_id"],
            "request_id": job["request_id"],
            "command": answer_command,
            "params": params.model_dump(mode="json", by_alias=True, exclude_none=True),
        }

    async def sample(self, job, answer_command):
        pending = self.prepare(job, answer_command)
        if "params" not in pending:
            return pending
        return await self.dispatch(pending)

    async def sample_batch(self, jobs, answer_command):
        pending = [self.prepare(job, answer_command) for job in jobs]
        if any("params" not in item for item in pending):
            return {
                "run_id": jobs[0]["run_id"],
                "status": "awaiting_answers",
                "assignments": pending,
            }
        if self.request.protocol_version >= "2026-07-28":
            return self.batch_request({
                "run_id": jobs[0]["run_id"],
                "batch": {item["request_id"]: item for item in pending},
                "results": [],
            })
        results = await asyncio.gather(*(self.dispatch(item) for item in pending))
        return {
            "run_id": jobs[0]["run_id"],
            "recorded": all(result.get("recorded") for result in results),
            "results": results,
        }

    def batch_request(self, pending):
        token = self.remember(pending)
        return types.InputRequiredResult(
            input_requests={
                key: types.CreateMessageRequest(
                    params=types.CreateMessageRequestParams.model_validate(item["params"])
                )
                for key, item in pending["batch"].items()
            },
            request_state=token,
        )

    async def accept_batch(self, pending, responses):
        keys = [key for key in pending["batch"] if key in responses]
        results = await asyncio.gather(*(
            self.accept(pending["batch"][key], responses[key], redispatch=False)
            for key in keys
        ))
        for key, result in zip(keys, results):
            if result is not None:
                pending["results"].append(result)
                del pending["batch"][key]
        if pending["batch"]:
            return self.batch_request(pending)
        return {
            "run_id": pending["run_id"],
            "recorded": all(result.get("recorded") for result in pending["results"]),
            "results": pending["results"],
        }

    async def dispatch(self, pending):
        params = types.CreateMessageRequestParams.model_validate(pending["params"])
        if self.request.protocol_version >= "2026-07-28":
            token = self.remember(pending)
            return types.InputRequiredResult(
                input_requests={"answer": types.CreateMessageRequest(params=params)},
                request_state=token,
            )
        while True:
            result = await self.request.session.create_message(
                params.messages,
                max_tokens=params.max_tokens,
                system_prompt=params.system_prompt,
                include_context="none",
                tools=params.tools,
            )
            response = await self.accept(pending, result)
            if response is not None:
                return response
            params = types.CreateMessageRequestParams.model_validate(pending["params"])

    async def accept(self, pending, result, *, redispatch=True):
        content = (
            result.content if isinstance(result.content, list) else [result.content]
        )
        uses = [item for item in content if isinstance(item, types.ToolUseContent)]
        if not uses:
            return await accept_sample(self.app, pending, result)
        self.app.trace(
            "sampling.response",
            result.model_dump(mode="json", by_alias=True),
            pending["run_id"],
        )
        allowed = {tool["name"] for tool in pending["params"].get("tools", [])}
        replies = []
        for use in uses:
            cache_key = "sampling.tool:" + pending["request_id"] + ":" + use.id
            reply = self.app.get(cache_key)
            if reply is None:
                try:
                    job = pending_assignment(
                        self.app, pending["run_id"], pending["request_id"]
                    )
                    if use.name not in allowed:
                        raise ValueError("Tool was not offered for this assignment")
                    scoped = copy.copy(self.app)
                    scoped.binding = {
                        "module": job.get(
                            "module", (self.app.get("mode") or {}).get("module", "workflow")
                        ),
                        "run_id": pending["run_id"],
                        "request_id": pending["request_id"],
                        "nonce": job.get("nonce"),
                    }
                    value = await Registry(scoped).call(
                        use.name,
                        use.input | {
                            "run_id": pending["run_id"],
                            "request_id": pending["request_id"],
                        },
                    )
                    from .tool_content import content_blocks

                    reply = {
                        "type": "tool_result",
                        "toolUseId": use.id,
                        "content": content_blocks(value),
                    }
                except Exception as exc:
                    reply = {
                        "type": "tool_result",
                        "toolUseId": use.id,
                        "content": [{"type": "text", "text": str(exc)}],
                        "isError": True,
                    }
                self.app.set(cache_key, reply)
            replies.append(reply)
        pending["params"]["messages"].extend(
            [
                {
                    "role": "assistant",
                    "content": [
                        c.model_dump(mode="json", by_alias=True, exclude_none=True)
                        for c in content
                    ],
                },
                {"role": "user", "content": replies},
            ]
        )
        if redispatch and self.request.protocol_version >= "2026-07-28":
            return await self.dispatch(pending)
        return None


def sample_text(result):
    content = result.content if isinstance(result.content, list) else [result.content]
    text = "\n".join(c.text for c in content if hasattr(c, "text"))
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


async def accept_sample(app, pending, result):
    app.trace(
        "sampling.response",
        result.model_dump(mode="json", by_alias=True),
        pending["run_id"],
    )
    args = {k: pending[k] for k in ("run_id", "request_id")} | {
        "answer": sample_text(result)
    }
    scoped = copy.copy(app)
    scoped.binding = {
        "module": pending["command"].split(".", 1)[0],
        "run_id": pending["run_id"],
        "request_id": pending["request_id"],
    }
    return await Registry(scoped).call(pending["command"], args)


def server(app):
    from .modules.project import ProjectSession
    project_session = ProjectSession(app)

    async def list_tools(context, params):
        app = project_session.app
        registry = Registry(app)
        commands = registry.visible()
        tools = [
            types.Tool(
                name="abort",
                description="Leave the active module and return to the router.",
                input_schema={"type": "object", "properties": {}},
            )
        ]
        if context.protocol_version >= "2026-07-28":
            tools.append(
                types.Tool(
                    name="metaform",
                    description="Route to the currently active module. Omit command to discover available commands and their schemas. Supply raw for module-owned CLI-style input.",
                    input_schema={
                        "type": "object",
                        "properties": {
                            "command": {"type": "string"},
                            "arguments": {"type": "object"},
                            "raw": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                )
            )
            commands = {
                key: c for key, c in commands.items() if c.always_available
            }
        tools.extend(
            types.Tool.model_validate(c.definition(app))
            for c in commands.values()
        )
        return types.ListToolsResult(tools=sorted(tools, key=lambda t: t.name))

    async def call_tool(context, params):
        app = project_session.sampling_apps.get(params.request_state, project_session.app) if params.request_state else project_session.app
        registry = Registry(app)
        before = tuple(Registry(project_session.app).visible())
        app.trace("mcp.request", params.model_dump(mode="json", by_alias=True))
        try:
            if params.input_responses and params.request_state:
                pending = app.get("sampling:" + params.request_state)
                if pending is None:
                    raise ValueError("Unknown sampling continuation")
                sampling_context = Context(app, context, project_session)
                if "batch" in pending:
                    result = await sampling_context.accept_batch(
                        pending, params.input_responses
                    )
                else:
                    result = await sampling_context.accept(
                        pending, params.input_responses["answer"]
                    )
            else:
                name, arguments = params.name, params.arguments or {}
                if name == "metaform":
                    if "raw" in arguments:
                        result = await registry.raw(
                            arguments["raw"], Context(app, context, project_session)
                        )
                    elif not arguments.get("command"):
                        result = {
                            "instructions": instructions(app),
                            "mode": app.get("mode"),
                            "commands": [
                                c.definition(app)
                                for c in registry.visible().values()
                            ],
                            "bailout": "abort",
                        }
                    else:
                        result = await registry.call(
                            arguments["command"],
                            arguments.get("arguments"),
                            Context(app, context, project_session),
                        )
                else:
                    result = await registry.call(name, arguments, Context(app, context, project_session))
            if isinstance(result, types.InputRequiredResult):
                return result
            from .tool_content import content_blocks

            response = types.CallToolResult(
                content=content_blocks(result),
                structured_content=result
                if isinstance(result, dict)
                else {"result": result},
            )
        except Exception as exc:
            app.trace("mcp.error", {"error": str(exc)})
            response = types.CallToolResult(
                content=[types.TextContent(type="text", text=str(exc))], is_error=True
            )
        if (
            tuple(Registry(project_session.app).visible()) != before
            and context.protocol_version < "2026-07-28"
        ):
            await context.session.send_tool_list_changed()
        app.trace("mcp.response", response.model_dump(mode="json", by_alias=True))
        return response

    async def list_resources(context, params):
        app = project_session.app
        # During takeover, the owning module controls its data surface as well.
        resources = [
            types.Resource(
                name=key,
                uri="metaform://schema/" + key,
                mime_type="application/schema+json",
            )
            for key in schemas.registry(app)
        ]
        if context.protocol_version < "2026-07-28" and not app.get("mode"):
            resources.extend(
                [
                    types.Resource(
                        name="graph",
                        uri="metaform://graph",
                        mime_type="application/json",
                    ),
                    types.Resource(
                        name="stats",
                        uri="metaform://stats",
                        mime_type="application/json",
                    ),
                ]
            )
        return types.ListResourcesResult(resources=resources)

    async def read_resource(context, params):
        app = project_session.app
        uri = str(params.uri)
        if uri.startswith("metaform://schema/"):
            value = schemas.registry(app)[uri[len("metaform://schema/") :]]
        elif uri.startswith("metaform://model/"):
            from .semantic_resources import read

            value = await read(app, uri)
        elif not app.get("mode") and uri == "metaform://graph":
            value = app.graph.export()
        elif not app.get("mode") and uri == "metaform://stats":
            value = app.graph.stats()
        else:
            raise ValueError("Unknown resource")
        return types.ReadResourceResult(
            contents=[
                types.TextResourceContents(
                    uri=params.uri, mime_type="application/json", text=dumps(value)
                )
            ]
        )

    async def list_resource_templates(context, params):
        from .semantic_resources import templates

        return types.ListResourceTemplatesResult(resource_templates=[
            types.ResourceTemplate.model_validate(item) for item in templates(project_session.app)])

    async def list_prompts(context, params):
        return types.ListPromptsResult(prompts=[types.Prompt(
            name="metaform", description="Guide the user through intake and work with their Inference Metaform."
        )])

    async def get_prompt(context, params):
        from .onboarding import guide_state, skill_text

        if params.name != "metaform":
            raise ValueError("Unknown prompt")
        return types.GetPromptResult(
            description="Metaform concierge guidance and current project state.",
            messages=[
                types.PromptMessage(role="user", content=types.TextContent(type="text", text=skill_text(project_session.app))),
                types.PromptMessage(role="user", content=types.TextContent(type="text", text=dumps(guide_state(project_session.app)))),
            ],
        )

    return Server(
        "metaform",
        version=__version__,
        instructions=instructions(app),
        on_list_tools=list_tools,
        on_call_tool=call_tool,
        on_list_resources=list_resources,
        on_list_resource_templates=list_resource_templates,
        on_read_resource=read_resource,
        on_list_prompts=list_prompts,
        on_get_prompt=get_prompt,
    )


async def serve(app=None):
    app = app or App()
    # Each agent is its own server process; announce this one and the harness that spawned it.
    from . import bindings
    folder_binding = bindings.lookup(app.invocation, app.home) or {}
    bindings.agent(os.getpid(), os.getppid(), app.invocation, app.project,
                   nonce=folder_binding.get("nonce"), home=app.home)
    if types is None:
        from .portable_mcp import serve as portable_serve

        return await portable_serve(app)
    instance = server(app)
    from .portable_mcp import input_lines, output_stream

    with output_stream() as output:
        async with stdio_server(stdin=input_lines(), stdout=output) as (read, write):
            await instance.run(
                read,
                write,
                instance.create_initialization_options(
                    NotificationOptions(tools_changed=True)
                ),
            )


def main(app=None):
    serving = None
    interrupted = False

    def interrupt(signum, frame):
        nonlocal interrupted
        interrupted = True
        if serving is not None:
            loop = serving.get_loop()
            # main owns this fresh event loop. Cancel its producers together
            # with the receiver so a final stdin frame cannot enter a stream
            # that the SDK has already closed during shutdown.
            def cancel_runtime():
                for task in asyncio.all_tasks(loop):
                    task.cancel()

            if asyncio.current_task(loop) is None:
                # A signal can arrive between a Future callback's state check
                # and set_result. Defer cancellation until that callback ends.
                loop.call_soon(cancel_runtime)
                return
            cancel_runtime()
        # Cancellation must also unwind a currently running synchronous handler;
        # cancelling the top-level task alone cannot interrupt its socket/sleep.
        raise asyncio.CancelledError

    async def run():
        nonlocal serving
        serving = asyncio.current_task()
        await serve(app)

    previous = None
    if threading.current_thread() is threading.main_thread():
        previous = signal.signal(signal.SIGINT, interrupt)
    try:
        asyncio.run(run())
    except (KeyboardInterrupt, asyncio.CancelledError) as error:
        if not interrupted and not isinstance(error, KeyboardInterrupt):
            raise
        print("Metaform MCP server stopped.", file=sys.stderr, flush=True)
        return 130
    finally:
        if previous is not None:
            signal.signal(signal.SIGINT, previous)
    return 0


if __name__ == "__main__":
    sys.exit(main())
