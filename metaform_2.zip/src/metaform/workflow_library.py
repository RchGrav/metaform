"""Procedures and their exact source material distributed by the workflow module."""

import copy
import importlib.resources
import json


def entries():
    root = importlib.resources.files("metaform") / "data" / "workflows"
    manifest = root / "manifest.json"
    return json.loads(manifest.read_text(encoding="utf-8")) if manifest.is_file() else []


def definition(identifier):
    entry = next((entry for entry in entries() if entry["id"] == identifier), None)
    if entry is None:
        return None
    root = importlib.resources.files("metaform") / "data" / "workflows"
    document = json.loads((root / entry["definition"]).read_text(encoding="utf-8"))
    document["source_instruction"] = (root / entry["source"]).read_text(encoding="utf-8")
    document["library"] = copy.deepcopy(entry)
    return document


def install(app, identifier):
    from .workflow import import_workflow

    if app.graph.get("workflow:" + identifier) or app.global_graph.get("workflow:" + identifier):
        return
    document = definition(identifier)
    if document is not None:
        import_workflow(app, document)
