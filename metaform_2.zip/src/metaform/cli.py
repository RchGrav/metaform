from __future__ import annotations

import argparse
import asyncio
import json
import os
import shlex
from pathlib import Path
import sys

from .app import App
from .registry import LAUNCHER_COMMANDS, Registry
from .util import input_value


def install_parser():
    parser = argparse.ArgumentParser(prog='metaform install', description='Install Metaform and connect supported AI harnesses.')
    parser.add_argument('destination', nargs='?', help='Launcher directory (default: ~/.local/bin)')
    parser.add_argument('--harness', action='append', choices=['codex', 'claude', 'gemini', 'cursor', 'vscode'],
                        help='Configure this harness; repeat to select several')
    return parser


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    project = None
    human = sys.stdout.isatty()
    json_output = False
    debug = False
    try:
        while argv:
            option = argv[0]
            if option == '--project':
                if len(argv) < 2:
                    raise ValueError('--project requires a path or registered project ID')
                project, argv = argv[1], argv[2:]
            elif option.startswith('--project='):
                project = argv.pop(0).split('=', 1)[1]
            elif option in {'--json', '--human'}:
                human = argv.pop(0) == '--human'
                json_output = not human
            elif option == '--debug':
                argv.pop(0)
                debug = True
            else:
                break
        from .continuation import marker
        binding = json.loads(os.environ['METAFORM_BINDING']) if os.environ.get('METAFORM_BINDING') else marker()
        if project is None and not binding:
            # A subfolder of a registered project belongs to that project; it never becomes one of its own.
            # Walking stops before ~, one level deeper: ~/.metaform is the Metaform home, never a project.
            home_folder = Path.home().resolve()
            for parent in Path.cwd().resolve().parents:
                if parent == home_folder or parent in home_folder.parents:
                    break
                if (parent / '.metaform' / 'state.sqlite3').is_file():
                    project = str(parent)
                    break
        if project and binding:
            from .app import project_path
            if project_path(project, binding['home']) != project_path(binding['project']):
                raise ValueError('The selected project conflicts with this bound assignment')
        if argv[:1] == ['actor']:
            from .actor import main as actor_main
            return actor_main(argv[1:])
        if os.environ.get('METAFORM_GATEWAY'):
            if argv == ['mcp']:
                from .mcp_server import main as mcp_main
                return mcp_main()
            from .actor import main as actor_main
            if argv[:1] == ['begin']:
                if len(argv) != 2:
                    raise ValueError('Usage: metaform begin <nonce>')
                if not binding or argv[1] != binding.get('nonce'):
                    raise ValueError('The nonce conflicts with this bound assignment')
                return actor_main(['begin', '--arguments', json.dumps({'nonce': argv[1]})])
            return actor_main(argv)

        reference = App.reference(project=project or (binding['project'] if binding else None),
                                  home=binding['home'] if binding else None)
        registry = Registry(reference)
        for error in dict.fromkeys([*reference.config_errors, *reference.module_errors]):
            print(error, file=sys.stderr)
        if argv == ['skill']:
            from .onboarding import skill_text
            print(skill_text(reference), end='')
            return 0
        if argv[:1] == ['install'] and any(arg in {'--help', '-h'} for arg in argv):
            install_parser().parse_args(argv[1:])
            return 0
        if argv[:1] == ['done']:
            if not binding:
                print_result({'error': 'done needs a bound assignment: run it from the folder given with begin'}, human)
                return 1
            print_result(done(binding), human)
            return 0
        if binding and (not argv or any(arg in {'--help', '-h'} for arg in argv)):
            starting_page(registry, binding=binding)
            return 0
        if binding:
            # A command run under the binding is activity; help and the page are not.
            from . import bindings
            bindings.touch(binding.get('folder') or Path.cwd(), homes=[binding['home']])
        menu = 'base'
        if argv[:1] == ['help'] and argv[1:2] in (['orchestrate'], ['admin']):
            menu, argv = argv[1], []
        elif not binding and (argv == ['help'] or argv in (['--help'], ['-h'])):
            # help reads; it never opens the project for writing.
            starting_page(registry, menu=menu)
            return 0
        if (any(arg in {'--help', '-h'} for arg in argv) or argv[:1] == ['help']
                or len(argv) == 1 and argv[0] in registry.manifests()):
            result = run_parser(registry, argv[1:] + ['--help'] if argv[:1] == ['help'] else argv, reference=True)
            if result is not None:
                # A bare module word ran its default command; say what it returned, the URL and its port for web.
                print_result(result, human)
            return 0
        reference_command = registry.discover().get('.'.join(argv[:2])) if len(argv) >= 2 else None
        if reference_command and reference_command.reference_only:
            result = run_parser(registry, argv, reference=True)
            print_result(result, human)
            return 0
        if not argv and not reference.db_path.exists():
            if json_output:
                print_result({"project": str(reference.project), "status": "uninitialized",
                              "modules": registry.reference()["modules"],
                              "next": {"command": "guide.start", "arguments": {}} if "guide.start" in registry.discover() else None})
            else:
                starting_page(registry, menu=menu)
            return 0
        startup_command = registry.visible().get('.'.join(argv[:2])) if len(argv) >= 2 else None
        startup = next((entry.get('bootstrap_handler') for entry in startup_command.manifest['commands']
                        if entry['name'] == startup_command.name), None) if startup_command else None
        if not binding and startup:
            from dataclasses import replace
            bootstrap = registry.load(replace(startup_command, handler=startup))
            print_result(bootstrap(argv, project), human)
            return 0
        if argv[:1] == ['begin']:
            from .continuation import begin
            if len(argv) != 2:
                raise ValueError('Usage: metaform begin <nonce>')
            print_result(begin(argv[1], home=binding['home'] if binding else None, project=project), human)
            return 0
        if not binding and argv[:1] == ['install']:
            from .installation import install
            options = install_parser().parse_args(argv[1:])
            result = install(reference, options.destination, options.harness)
            print_result(result, human)
            return 1 if result['mcp']['errors'] else 0
        parsed = {}
        if argv and argv != ['mcp']:
            mode = reference.get('mode')
            typed = len(argv) >= 2 and '.'.join(argv[:2]) in registry.discover()
            if not mode or not registry.disables_argparse() or typed or argv == ['abort']:
                parsed = run_parser(registry, argv, mode=bool(mode), parse_only=True)
        app = App(project=project)
        if debug:
            app.debug = True
            app.set("debug", True)
        registry = Registry(app)
        if argv == ['mcp'] or parsed.get('_cli_module') == 'mcp':
            if parsed.get('_cli_debug'):
                app.debug = True
                app.set('debug', True)
            from .mcp_server import main as mcp_main
            return mcp_main(app)
        if not argv:
            if json_output:
                key = 'guide.start'
                print_result(asyncio.run(registry.call(key)) if key in registry.visible() else registry.reference())
            else:
                starting_page(registry, initialized=True, menu=menu)
            return 0
        mode = app.get('mode')
        discovered = registry.discover()
        typed = len(argv) >= 2 and '.'.join(argv[:2]) in discovered
        alias = any(argv[:1] == [name] for command in discovered.values()
                    for entry in command.manifest['commands'] if entry['name'] == command.name
                    for name in entry.get('aliases', []))
        if mode and registry.disables_argparse() and not typed and not alias and argv != ['abort']:
            result = asyncio.run(registry.raw(argv))
        else:
            result = run_parser(registry, argv, mode=bool(mode))
        if result is not None:
            print_result(result, human)
        return 0
    except KeyboardInterrupt:
        print('Metaform stopped.', file=sys.stderr)
        return 130
    except Exception as exc:
        if 'app' in locals():
            import traceback
            app.trace('cli.error', {'error': str(exc), 'traceback': traceback.format_exc()})
        print(json.dumps({'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


def starting_page(registry, initialized=False, binding=None, menu='base'):
    """The menu of this context: a bound assignment, the project's main folder, or nowhere."""
    if binding:
        return assignment_page(binding)
    import tempfile
    project = registry.app.project
    here = Path.cwd().resolve()
    if here != Path(project).resolve() or here == Path(tempfile.gettempdir()).resolve():
        print('This folder is not the project\'s main folder, so there is no menu here.')
        print('Main menu: run metaform from ' + str(project))
        print('Assignment: metaform begin <nonce> in the folder given for it')
        return
    print('Status')
    print('Project: ' + project.name + ' (' + str(project) + ')')
    full = registry.app
    mode = stored_mode(full)
    if mode and mode.get('run_id'):
        run = full.load_run(mode['run_id']) or {}
        print('Workflow: ' + str(run.get('workflow', mode.get('module'))))
        print('Status: ' + str(run.get('status')))
        print('\nThis workflow')
        from .registry import Registry as _Registry
        for key, command in sorted(_Registry(full).visible().items()):
            print('  metaform ' + key.replace('.', ' ') + '  ' + (command.description or ''))
        print('  metaform abort  Leave this workflow; nothing else activates here until it is finished or aborted')
        return
    stage = 'initialized' if (Path(project) / '.metaform').is_dir() else 'uninitialized'
    state = None
    if initialized and 'guide.start' in registry.visible():
        state = asyncio.run(registry.call('guide.start'))
        stage = state['status'].replace('_', ' ')
    if menu == 'base':
        print('Stage: ' + stage)
        print("\nMetaform records your project's functional understanding and guides work through installed modules.")
        print('\nYour menu')
        print('metaform begin <nonce>  Enter the assignment you were given, in the folder given for it')
        print('metaform done  Finish that assignment and clean up its nonce')
        print('Single-step work: run the command you were given')
        if stage == 'uninitialized':
            if 'guide.start' in registry.discover():
                print('Begin: metaform guide start (initialize this project and show its next action)')
            print('Connect an AI harness: metaform install --help')
            print('\nInstalled modules:')
            for identifier, manifest in sorted(registry.manifests().items()):
                print('  %-14s %s' % (identifier, manifest.get('description', '')))
        print('Orchestrator menu: metaform help orchestrate')
        print('Admin menu: metaform help admin')
        return
    if menu == 'admin':
        print('\nAdmin menu')
        print('This is the menu the user gets. An orchestrating agent takes it by beginning its nonce, and says metaform complete to return to its own menu.')
        print('\nInstalled modules:')
        for identifier, manifest in sorted(registry.manifests().items()):
            print('  %-14s %s' % (identifier, manifest.get('description', '')))
        print('\nRead module help: metaform <module> --help')
        return
    print('Stage: ' + stage)
    print('\nOrchestrating from here')
    print('Provision a harness: metaform install --help')
    print('List workflows: metaform workflow list')
    print('Intake: metaform intake start')
    if state is not None:
        print(state['guidance'])
        if state.get('next'):
            print('Next: ' + command_line(state['next']['command'], state['next']['arguments']))
    elif 'guide.start' in registry.discover():
        print('Begin: metaform guide start (initialize this project and show its next action)')
    print('\nInstalled modules:')
    for identifier, manifest in sorted(registry.manifests().items()):
        print('  %-14s %s' % (identifier, manifest.get('description', '')))
    print('\nRead module help: metaform <module> --help')
    print('Read command arguments: metaform <module> <command> --help')


def done(binding):
    """The agent says it is finished: retire the assignment's delivery and remove the nonce marker."""
    from .app import App
    from .continuation import retire

    app = App(binding['project'], binding['home'], binding=binding)
    run = app.load_run(binding['run_id'])
    retire(app, run, binding.get('request_id'))
    from . import bindings
    bindings.clear(binding.get('folder') or Path.cwd(), homes=[binding['home']])
    app.event('continuation.done', {'nonce': binding['nonce'], 'request_id': binding.get('request_id')}, run['id'])
    return {'status': 'done', 'nonce': binding['nonce'], 'run_id': run['id'], 'request_id': binding.get('request_id')}


def stored_mode(app):
    """Read the active mode without opening the project for writing; help never touches state."""
    import sqlite3
    path = getattr(app, 'db_path', None)
    if not path or not Path(path).is_file():
        return None
    try:
        with sqlite3.connect(f'file:{path}?mode=ro&immutable=1', uri=True) as db:
            row = db.execute("SELECT value FROM state WHERE key='mode'").fetchone()
        return json.loads(row[0]) if row and row[0] else None
    except Exception:
        return None


def assignment_page(binding):
    """Status first, then only the commands this assignment has."""
    from .app import App
    from .continuation import pending_assignment
    from .registry import Registry

    app = App(binding['project'], binding['home'], binding=binding)
    run = app.load_run(binding['run_id'])
    job = pending_assignment(app, binding['run_id'], binding.get('request_id')) or {}
    folder = Path(binding.get('folder') or Path.cwd())
    print('Status')
    print('Project: ' + app.project.name + ' (' + str(app.project) + ')')
    print('Folder: ' + str(folder))
    print('Worktree: ' + ('yes' if (folder / '.git').is_file() else 'no'))
    print('Job id: ' + str(binding['nonce']))
    print('Workflow: ' + str(run.get('workflow', binding['module'])))
    print('Step: ' + str(job.get('step') or binding['module']))
    print('Status: ' + str(job.get('status') or run.get('status')))
    print('\nThis assignment')
    for key, command in sorted(Registry(app).visible().items()):
        print('  metaform ' + key.replace('.', ' ') + '  ' + (command.description or ''))
    print('  metaform done  Finish this assignment and clean up its nonce')


def command_line(key, arguments):
    parts = ['metaform', *key.split('.')]
    for name, value in arguments.items():
        option = '--' + name.replace('_', '-')
        if isinstance(value, bool):
            parts.append(option if value else '--no-' + name.replace('_', '-'))
        else:
            parts += [option, str(value) if isinstance(value, (str, int, float)) else json.dumps(value)]
    return shlex.join(parts)


def run_parser(registry, argv, mode=False, reference=False, parse_only=False):
    parser = argparse.ArgumentParser(prog='metaform', usage='metaform [--project PATH-OR-ID] <module> <command> [arguments]',
                                     description='Discover installed modules, select project work, and follow its returned continuation.',
                                     epilog='Run metaform with no arguments for the starting page. Use <module> --help, then <module> <command> --help.')
    parser.add_argument('--project', dest='_cli_project', help='Select a project path or registered project ID for this invocation')
    parser.add_argument('--json', dest='_cli_json', action='store_true', help='Print complete structured JSON output')
    parser.add_argument('--human', dest='_cli_human', action='store_true', help='Print readable output for a terminal')
    parser.add_argument('--debug', dest='_cli_debug', action='store_true', help='Capture interactions for this project')
    groups = parser.add_subparsers(dest='_cli_module', title='Modules and launcher commands', metavar='<module>')
    for name, description in LAUNCHER_COMMANDS.items():
        launcher = groups.add_parser(name, help=description)
        if name == 'begin':
            launcher.add_argument('nonce', help='Assignment nonce from the runtime handoff')
    commands = registry.discover() if reference else registry.visible()
    parents, module_parsers, defaults = {}, {}, {}
    for command in sorted(commands.values(), key=lambda command: command.key):
        manifest = command.manifest
        if command.module not in parents:
            if manifest.get('default_command'):
                defaults[command.module] = command.module + '.' + manifest['default_command']
            module_parser = groups.add_parser(command.module, help=manifest.get('description', ''),
                                              description=manifest.get('description', ''), prog='metaform ' + command.module,
                                              epilog=module_epilog(manifest), formatter_class=argparse.RawDescriptionHelpFormatter)
            module_parsers[command.module] = module_parser
            parents[command.module] = module_parser.add_subparsers(dest='_cli_operation', title=manifest.get('name', command.module) + ' commands', metavar='<command>')
        entry = next(item for item in manifest['commands'] if item['name'] == command.name)
        sub = parents[command.module].add_parser(command.name, help=command.description, description=command.description, prog='metaform ' + command.module + ' ' + command.name,
                                                epilog=command_epilog(command, entry), formatter_class=argparse.RawDescriptionHelpFormatter)
        sub.set_defaults(_cli_command_key=command.key)
        for name, shape in command.schema.get('properties', {}).items():
            option = '--' + name.replace('_', '-')
            help_text = shape.get('description', '')
            if 'default' in shape:
                help_text += ' (default: ' + json.dumps(shape['default']) + ')'
            kwargs = {'dest': name, 'help': help_text, 'default': shape.get('default', argparse.SUPPRESS)}
            if name in command.schema.get('required', []):
                kwargs['required'] = True
            if shape.get('type') == 'boolean':
                kwargs['action'] = argparse.BooleanOptionalAction
            elif shape.get('type') == 'integer':
                kwargs['type'] = int
            elif shape.get('type') == 'number':
                kwargs['type'] = float
            else:
                kwargs['type'] = str if shape.get('type') == 'string' else input_value
            if shape.get('enum') and shape.get('type') != 'boolean':
                kwargs['choices'] = shape['enum']
            sub.add_argument(option, **kwargs)
        for alias in entry.get('aliases', []):
            shortcut = groups.add_parser(alias, parents=[sub], add_help=False, help=command.description + ' (alias for ' + command.key + ')')
            shortcut.set_defaults(_cli_command_key=command.key)
    args = vars(parser.parse_args(argv))
    if not args.get('_cli_command_key') and defaults.get(args.get('_cli_module')) in commands:
        args['_cli_command_key'] = defaults[args['_cli_module']]
    if parse_only:
        return args
    args.pop("_cli_project", None)
    args.pop("_cli_json", None)
    args.pop("_cli_human", None)
    if args.pop('_cli_debug', False):
        if reference:
            raise ValueError('--debug changes project state; omit it when reading reference')
        registry.app.debug = True
        registry.app.set('debug', True)
    if args.get('_cli_module') == 'mcp':
        from .mcp_server import main as mcp_main
        return mcp_main(registry.app)
    if args.get('_cli_module') == 'abort':
        return registry.app.abort()
    key = args.pop('_cli_command_key', None)
    if not key:
        module_parsers.get(args.get('_cli_module'), parser).print_help()
        return None
    args.pop('_cli_module', None)
    args.pop('_cli_operation', None)
    if reference:
        from .module_api import handler_context
        import inspect
        result = registry.load(commands[key])(handler_context(registry.app, commands[key]), args, None)
        return asyncio.run(result) if inspect.isawaitable(result) else result
    return asyncio.run(registry.call(key, args))


def module_epilog(manifest):
    lines = [manifest.get('guidance', '')]
    if manifest.get('settings'):
        lines += ['', 'Settings (metaform system configure --scope home|project --settings JSON):']
        for name, shape in manifest['settings'].items():
            lines.append('  ' + name + ': ' + shape.get('description', '') +
                         (' Default: ' + json.dumps(shape['default']) if 'default' in shape else ''))
            details = {key: shape[key] for key in ('type', 'scope', 'minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'enum') if key in shape}
            if details:
                lines.append('    ' + '; '.join(key + ': ' + (value if isinstance(value, str) else json.dumps(value))
                                              for key, value in details.items()))
    lines += ['', 'Use metaform ' + manifest['id'] + ' <command> --help for arguments, results and examples.']
    return '\n'.join(lines)


def command_epilog(command, entry):
    lines = ['Owner: ' + command.module]
    if entry.get('context'):
        lines.append('Context: ' + entry['context'])
    if entry.get('returns'):
        lines += ['', 'Result: ' + entry['returns']]
    if entry.get('examples'):
        lines += ['', 'Examples:']
        for example in entry['examples']:
            if example.get('description'):
                lines.append('  ' + example['description'])
            lines.append('  ' + command_line(command.key, example.get('arguments', {})))
    return '\n'.join(lines)


def print_result(value, human=False, indent=0):
    if not human:
        print(json.dumps(value, ensure_ascii=False, indent=2, default=str))
        return
    prefix = ' ' * indent
    if isinstance(value, dict):
        for key, item in value.items():
            if key == 'url' and isinstance(item, str):
                print(item)
            elif key == 'next' and isinstance(item, dict) and item.get('command'):
                print(prefix + 'Next: ' + command_line(item['command'], item.get('arguments', {})))
            elif isinstance(item, (dict, list)):
                print(prefix + key.replace('_', ' ').capitalize() + ':')
                print_result(item, True, indent + 2)
            else:
                print(prefix + key.replace('_', ' ').capitalize() + ': ' + str(item))
    elif isinstance(value, list):
        for item in value:
            print_result(item, True, indent)
    else:
        print(prefix + str(value))
