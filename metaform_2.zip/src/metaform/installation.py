from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


def install(app, destination=None, harnesses=None):
    bindir = Path(destination or Path.home() / ".local" / "bin").expanduser().resolve()
    bindir.mkdir(parents=True, exist_ok=True)
    executable = bindir / "metaform"
    archive = Path(sys.argv[0]).resolve()
    if archive.is_file() and zipfile.is_zipfile(archive):
        package = app.home / "tool" / "metaform"
        package.parent.mkdir(parents=True, exist_ok=True)
        if archive != package:
            shutil.copyfile(archive, package)
        launcher = (
            "import runpy,sys\nsys.argv[0]="
            + repr(str(package))
            + "\nrunpy.run_path(sys.argv[0],run_name='__main__')\n"
        )
    else:
        launcher = "from metaform.cli import main\nraise SystemExit(main())\n"
    preserved = executable.exists() or executable.is_symlink()
    if not preserved:
        executable.write_text("#!" + sys.executable + "\n" + launcher)
        executable.chmod(0o755)
    if os.name == "nt" and not executable.with_suffix(".cmd").exists():
        executable.with_suffix(".cmd").write_text(
            '@"' + sys.executable + '" "' + str(executable) + '" %*\n'
        )
    mcp = setup_harnesses(str(executable), harnesses)
    return {
        "command": str(executable),
        "launcher": {"preserved": preserved, "message": "Existing launcher retained; upgrade it with its owning installer." if preserved else "Created launcher for this installation."},
        "mcp": mcp,
        "skills": install_skills(app.home, mcp["configured"], mcp["detected"]),
        "backend": app.config.get("graph_backend", "sqlite"),
        "modules": [str(app.home / "modules"), str(app.root / "modules")],
        "message": "Metaform works best when reusable Inference Metaform data can be contributed upstream. Use the workbench to inspect it and sync to publish it. You can target Metaform itself and build custom modules.",
    }


def detect_harnesses():
    home = Path.home()
    candidates = [
        ("codex", "Codex", "codex", Path(os.environ.get("CODEX_HOME", home / ".codex")) / "config.toml"),
        ("claude", "Claude Code", "claude", Path(os.environ.get("CLAUDE_CONFIG_DIR", home)) / ".claude.json"),
        ("gemini", "Gemini CLI", "gemini", home / ".gemini" / "settings.json"),
        ("cursor", "Cursor", "cursor", home / ".cursor" / "mcp.json"),
        ("vscode", "VS Code", "code", None),
    ]
    found = []
    for identifier, name, binary, config in candidates:
        executable = shutil.which(binary)
        if executable or (identifier == "cursor" and config.parent.is_dir()):
            found.append({"id": identifier, "name": name, "executable": executable,
                          "config": str(config) if config else None})
    return found


def setup_harnesses(command, selected=None):
    detected = detect_harnesses()
    result = {"detected": detected, "configured": [], "backups": [], "errors": []}
    if selected is None and sys.stdin.isatty() and detected:
        print("\nConfigure Metaform for which harnesses?", file=sys.stderr)
        for number, harness in enumerate(detected, 1):
            print(f"  {number}. {harness['name']}", file=sys.stderr)
        while True:
            print("Numbers separated by commas, 'all', or Enter to skip: ", end="", file=sys.stderr, flush=True)
            try:
                answer = input().strip().lower()
            except (EOFError, KeyboardInterrupt):
                print(file=sys.stderr)
                answer = ""
            if not answer:
                selected = []
                break
            if answer == "all":
                selected = [item["id"] for item in detected]
                break
            try:
                numbers = [int(value) for value in answer.replace(",", " ").split()]
                if not numbers or any(number < 1 or number > len(detected) for number in numbers):
                    raise ValueError
                selected = [detected[number - 1]["id"] for number in numbers]
                break
            except ValueError:
                print("Choose from the numbers shown.", file=sys.stderr)
    if selected is None:
        result["message"] = (
            "Choose a detected harness with metaform install --harness <id>, or run metaform install in a terminal."
            if detected else "No supported harnesses detected. Run metaform install again after installing a supported harness."
        )
    for identifier in dict.fromkeys(selected or []):
        harness = next((item for item in detected if item["id"] == identifier), None)
        if harness is None:
            result["errors"].append({"id": identifier, "error": "Harness not detected."})
            continue
        try:
            config = Path(harness["config"]) if harness["config"] else None
            server = ({"command": sys.executable, "args": [command, "mcp"]}
                      if os.name == "nt" else {"command": command, "args": ["mcp"]})
            if identifier == "cursor":
                data = json.loads(config.read_text(encoding="utf-8")) if config.exists() else {}
                data.setdefault("mcpServers", {})["metaform"] = server
            if config and config.is_file():
                with tempfile.NamedTemporaryFile(dir=config.parent, prefix=config.name + ".metaform-", suffix=".bak", delete=False) as backup:
                    backup.write(config.read_bytes())
                result["backups"].append(backup.name)
            if identifier == "cursor":
                config.parent.mkdir(parents=True, exist_ok=True)
                config.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            else:
                launch = [server["command"], *server["args"]]
                arguments = {
                    "codex": ["mcp", "add", "metaform", "--", *launch],
                    "claude": ["mcp", "add", "--transport", "stdio", "--scope", "user", "metaform", "--", *launch],
                    "gemini": ["mcp", "add", "--scope", "user", "metaform", *launch],
                    "vscode": ["--add-mcp", json.dumps({"name": "metaform", **server})],
                }[identifier]
                completed = subprocess.run([harness["executable"], *arguments], capture_output=True, text=True)
                if completed.returncode:
                    raise ValueError(completed.stderr.strip() or completed.stdout.strip() or "MCP registration failed.")
            result["configured"].append(identifier)
        except (OSError, ValueError, TypeError, AttributeError) as error:
            result["errors"].append({"id": identifier, "error": str(error)})
    if result["configured"]:
        result["message"] = "Metaform is registered. Reconnect MCP or restart the selected harness to load its onboarding instructions."
    return result


def skill_directories(home):
    """Where the packaged Metaform skill is written: Metaform's own copy and the cross-client convention."""
    return {"metaform": home / "skills", "agents": Path.home() / ".agents" / "skills"}


def install_skills(home, configured, detected):
    """Write the Metaform skill where the configured harnesses discover skills."""
    from .onboarding import skill_text

    text = skill_text(include_catalog=False)
    result = {"registered": {}, "errors": []}
    targets = dict(skill_directories(home))
    for identifier in configured:
        if identifier == "claude":
            targets["claude"] = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude")) / "skills"
        elif identifier == "codex":
            targets["codex"] = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex")) / "skills"
    for identifier, directory in targets.items():
        try:
            folder = directory / "metaform"
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "SKILL.md").write_text(text, encoding="utf-8")
            result["registered"][identifier] = str(folder / "SKILL.md")
        except OSError as error:
            result["errors"].append({"id": identifier, "error": str(error)})
    if "gemini" in configured and "metaform" in result["registered"]:
        harness = next((item for item in detected if item["id"] == "gemini"), None)
        try:
            completed = subprocess.run(
                [harness["executable"], "skills", "install", str(Path(result["registered"]["metaform"]).parent),
                 "--scope", "user", "--consent"], capture_output=True, text=True)
            if completed.returncode:
                raise ValueError(completed.stderr.strip() or completed.stdout.strip() or "Skill installation failed.")
            result["registered"]["gemini"] = "gemini skills install"
        except (OSError, ValueError, TypeError) as error:
            result["errors"].append({"id": "gemini", "error": str(error)})
    result["file"] = result["registered"].get("metaform")
    return result
