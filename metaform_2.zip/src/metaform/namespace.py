"""Owner-qualified targets and the canonical namespace projection."""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
from collections import ChainMap, defaultdict
from difflib import get_close_matches

COLLECTIONS = {
    "type": "types", "element": "elements", "binding": "bindings",
    "narrowing": "narrowings", "refinement": "refinements", "join": "joins", "subtype": "subtypes",
    "layer": "layers", "knowledge": "knowledge", "recipe": "recipes",
    "activity": "activities", "expansion": "expansions", "source_snapshot": "source_snapshots",
}


def key(ref):
    return (ref.get("owner"), ref.get("kind"), ref.get("id"))


def reference(kind, value):
    ref = {"owner": value["owner"], "kind": kind, "id": value["id"]}
    if value.get("revision"):
        ref["revision"] = value["revision"]
    return ref


def records(snapshot, kind):
    if isinstance(snapshot, IndexedSnapshot):
        return snapshot.by_kind.get(kind, [])
    values = snapshot.get(COLLECTIONS[kind], [])
    values = list(values.values()) if isinstance(values, dict) else values
    if kind == "source_snapshot":
        values = [{"owner": "project:" + snapshot["model"]["project"], **value} for value in values]
    if kind == "expansion":
        from .util import digest
        values = [*values, *[{**opportunity, "id": "opportunity:" + digest([snapshot["model"], opportunity.get("target"), opportunity.get("question")]),
                            "owner": "project:" + snapshot["model"]["project"], "state": "opportunity"}
                           for opportunity in snapshot.get("expansion_opportunities", [])]]
    return values


def index_records(snapshot):
    if isinstance(snapshot, IndexedSnapshot):
        return snapshot.record_index
    return {key(reference(kind, value)): value
            for kind in COLLECTIONS for value in records(snapshot, kind)}


def expanded_aliases(record):
    """Expand authored leaf aliases at their own parent; keep full prior addresses."""
    if not isinstance(record.get("id"), str) or not isinstance(record.get("owner"), str):
        return []
    aliases = record.get("aliases", [])
    if not isinstance(aliases, list):
        return []
    source = reference("type", record)
    parent = record["id"].rpartition(".")[0]
    return [{"kind": "alias", "source": source, "name": alias,
             "address": {"owner": record["owner"], "kind": "type",
                         "id": alias if "." in alias or not parent else parent + "." + alias},
             "path": ["aliases", position]}
            for position, alias in enumerate(aliases) if isinstance(alias, str)]


def namespace_reservations(snapshot):
    """Address claims are scoped to the Type owner and canonical namespace."""
    cached = getattr(snapshot, "reservations", None)
    if cached is not None:
        return cached
    result = defaultdict(list)
    for record in records(snapshot, "type"):
        if not isinstance(record.get("id"), str) or not isinstance(record.get("owner"), str):
            continue
        claims = expanded_aliases(record)
        parameters = record.get("parametric_elements", [])
        parameters = parameters if isinstance(parameters, list) else []
        claims.extend({"kind": "parametric", "source": reference("type", record), "name": name,
                       "address": {"owner": record["owner"], "kind": "type", "id": record["id"] + "." + name},
                       "path": ["parametric_elements", position]}
                      for position, name in enumerate(parameters) if isinstance(name, str))
        for claim in claims:
            result[key(claim["address"])].append(claim)
    for record in records(snapshot, "subtype"):
        if not isinstance(record.get("id"), str) or not isinstance(record.get("owner"), str):
            continue
        claim = {"kind": "subtype", "source": reference("subtype", record), "name": record["id"].rpartition(".")[2],
                 "address": {"owner": record["owner"], "kind": "type", "id": record["id"]}, "path": []}
        result[key(claim["address"])].append(claim)
    return result


def namespace_reservation_diagnostics(snapshot):
    """Keep competing draft records inspectable and identify their exact claims."""
    cached = getattr(snapshot, "reservation_diagnostics", None)
    if cached is not None:
        return cached
    index = index_records(snapshot)
    diagnostics = []
    for address, claims in namespace_reservations(snapshot).items():
        entry = index.get(address)
        competing_entry = entry is not None and any(claim["kind"] == "parametric" or key(claim["source"]) != address for claim in claims)
        competing_claims = len({(claim["kind"], key(claim["source"])) for claim in claims}) > 1
        if competing_entry or competing_claims:
            diagnostic = {"code": "reserved_namespace_collision", "address": claims[0]["address"],
                          "reservations": claims,
                          "message": "Competing namespace entries claim an address reserved by an authored alias or Parametric name."}
            if entry is not None:
                diagnostic["entry"] = reference("type", entry)
            diagnostics.append(diagnostic)
    return diagnostics


class IndexedSnapshot(dict):
    """Rebuildable in-memory indexes for an immutable published revision."""
    def __init__(self, snapshot):
        super().__init__(snapshot)
        self.by_kind = {kind: records(snapshot, kind) for kind in COLLECTIONS}
        self.record_index = {key(reference(kind, value)): value for kind, values in self.by_kind.items() for value in values}
        self.by_id = defaultdict(list)
        for record_key, value in self.record_index.items():
            self.by_id[record_key[2]].append((record_key, value))
        self.reservations = namespace_reservations(self)
        self.reservation_diagnostics = namespace_reservation_diagnostics(self)
        self.aliases = defaultdict(list)
        for record in self.by_kind["type"]:
            for alias in expanded_aliases(record):
                for spelling in dict.fromkeys((alias["name"], alias["address"]["id"])):
                    self.aliases[(record["owner"], "type", spelling)].append(record)
        self.incident = defaultdict(list)
        self.element_bindings = defaultdict(list)
        self.type_bindings = defaultdict(list)
        for binding in self.by_kind['binding']:
            self.element_bindings[key(binding['element'])].append(binding)
            self.type_bindings[key(binding['type'])].append(binding)
        for join in self.by_kind['join']:
            refs = [join.get('receiver', {}), join.get('provider', {}), *[p.get('ref', {}) for p in join.get('participants', [])]]
            for record_key in {key(ref) for ref in refs}:
                self.incident[record_key].append(join)

    def with_collections(self, collections):
        result = dict.__new__(IndexedSnapshot)
        dict.__init__(result, self)
        result.update(collections)
        result.__dict__.update(self.__dict__)
        from .util import digest
        base_key = getattr(self, 'revision_key', None)
        result.revision_key = (base_key, digest(collections)) if base_key and collections else base_key
        result.by_kind = dict(self.by_kind)
        overlay = {}
        for kind, collection in COLLECTIONS.items():
            if collection in collections:
                values = collections[collection]
                values = list(values.values()) if isinstance(values, dict) else values
                result.by_kind[kind] = values
                overlay.update({key(reference(kind, value)): value for value in values})
        result.record_index = ChainMap(overlay, self.record_index)
        overlay_ids = defaultdict(list)
        for record_key, value in overlay.items():
            overlay_ids[record_key[2]].append((record_key, value))
        result.by_id = ChainMap({identifier: entries + [(k, v) for k, v in self.by_id.get(identifier, []) if k not in overlay]
                                for identifier, entries in overlay_ids.items()}, self.by_id)
        return result


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def paginate(items, model, query, cursor=None, limit=50, *, sort_key=None):
    """A stable key cursor is valid only for exactly this revision and selection."""
    if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
        raise ValueError("limit must be a positive integer")
    sort_key = sort_key or (lambda item: key(item["ref"]))
    ordered = sorted(items, key=sort_key)
    token = fingerprint({"model": model, "query": query})
    after = None
    if cursor:
        try:
            decoded = json.loads(base64.urlsafe_b64decode(cursor.encode()).decode())
            if decoded["query"] != token:
                raise ValueError("Cursor belongs to a different model revision or query")
            after = tuple(decoded["after"])
        except (KeyError, TypeError, UnicodeError, json.JSONDecodeError, binascii.Error) as exc:
            raise ValueError("Invalid semantic read cursor") from exc
    remaining = [item for item in ordered if after is None or tuple(sort_key(item)) > after]
    page = remaining[:limit]
    more = len(remaining) > len(page)
    next_cursor = None
    if more:
        next_cursor = base64.urlsafe_b64encode(json.dumps({"query": token, "after": sort_key(page[-1])}, separators=(",", ":")).encode()).decode()
    return page, {"returned": len(page), "available": len(items), "complete": not more, "next_cursor": next_cursor}


def type_name(value):
    """Read the maintained universal name backward from its final components."""
    return value.get("display_name") or " ".join(reversed(value["id"].split(".")[-value.get("length", 1):]))


def resolve_target(snapshot, target):
    index = index_records(snapshot)
    explicit = target if isinstance(target, dict) else {}
    spelling = explicit.get("id") if explicit else target
    kind = explicit.get("kind")
    owner = explicit.get("owner")
    if owner and kind and (owner, kind, spelling) in index:
        available = [((owner, kind, spelling), index[(owner, kind, spelling)])]
    elif isinstance(snapshot, IndexedSnapshot) and snapshot.by_id.get(spelling):
        available = snapshot.by_id[spelling]
    else:
        available = index.items()
    candidates = [(k, v) for k, v in available
                  if (not kind or k[1] == kind) and (not owner or k[0] == owner)]
    exact = [(k, v) for k, v in candidates if k[2] == spelling]
    method = "canonical"
    aliases_used = {}
    if not exact:
        alias_candidates = [(k, v) for k, v in index.items() if (not kind or k[1] == kind) and (not owner or k[0] == owner)]
        for record_key, value in alias_candidates:
            aliases = expanded_aliases(value) if record_key[1] == "type" else []
            match = next((alias for alias in aliases if spelling in (alias["name"], alias["address"]["id"])), None)
            if match or spelling in value.get("aliases", []):
                exact.append((record_key, value))
                if match:
                    aliases_used[record_key] = match
        method = "alias"
    if not exact:
        exact = [(k, v) for k, v in candidates if isinstance(spelling, str) and any(isinstance(label, str) and spelling.casefold() == label.casefold() for label in (v.get("name"), type_name(v) if k[1] == "type" else v.get("display_name")))]
        method = "label"
    if not owner and method != "label":
        local = [(k, v) for k, v in exact if k[0] == "project:" + snapshot["model"]["project"]]
        if local:
            exact = local
        else:
            exact = [(k, v) for k, v in exact if k[0] == "global"]
    if len(exact) == 1:
        k, value = exact[0]
        ref = reference(k[1], value)
        if explicit.get("revision") and explicit["revision"] != ref.get("revision", snapshot["model"]["revision"]):
            return {"ref": None, "via": [], "diagnostics": [{"code": "record_revision_mismatch", "target": target}]}
        via = {"kind": method, "from": target, "to": ref}
        addressed = (ref["owner"], ref["kind"], spelling)
        if k in aliases_used:
            via.update(authored_alias=aliases_used[k]["name"], address=aliases_used[k]["address"])
            addressed = key(aliases_used[k]["address"])
        diagnostics = [diagnostic for diagnostic in namespace_reservation_diagnostics(snapshot) if key(diagnostic["address"]) == addressed]
        return {"ref": ref, "via": [via], "diagnostics": diagnostics}
    if exact:
        diagnostic = {"code": "ambiguous_target", "target": target,
                      "candidates": [{"ref": reference(k[1], v), "name": v.get("name", v.get("display_name")), "description": v.get("description")} for k, v in exact]}
    else:
        nearby = get_close_matches(str(spelling), [k[2] for k, _ in candidates], n=5, cutoff=.3)
        diagnostic = {"code": "unresolved_target", "target": target,
                      "candidates": [reference(k[1], v) for k, v in candidates if k[2] in nearby]}
    diagnostics = [diagnostic]
    if not exact and kind in (None, "type"):
        selected_owner = owner or "project:" + snapshot["model"]["project"]
        claims = namespace_reservations(snapshot).get((selected_owner, "type", spelling), [])
        if not claims and owner is None:
            claims = namespace_reservations(snapshot).get(("global", "type", spelling), [])
        if any(claim["kind"] == "parametric" for claim in claims):
            diagnostics.append({"code": "reserved_parametric_address", "target": target,
                                "reservations": [claim for claim in claims if claim["kind"] == "parametric"]})
    return {"ref": None, "via": [], "diagnostics": diagnostics}


def branch_types(snapshot, target, descendants=False):
    """Membership beneath an address; applicability is a separate semantic read."""
    selected = {key(reference("type", value)) for value in records(snapshot, "type")
                if value["owner"] == target["owner"] and (value["id"] == target["id"] or
                   descendants and value["id"].startswith(target["id"] + "."))}
    if descendants:
        pending = list(selected)
        known = index_records(snapshot)
        while pending:
            current = pending.pop()
            for narrowing in records(snapshot, "narrowing"):
                child, parent = narrowing["child"], narrowing["parent"]
                if key(parent) == current and child["id"].rpartition(".")[0] == parent["id"] and key(child) in known and key(child) not in selected:
                    selected.add(key(child))
                    pending.append(key(child))
    return selected


def member_bindings(snapshot, target, descendants=False):
    selected = branch_types(snapshot, target, descendants)
    if isinstance(snapshot, IndexedSnapshot):
        return [b for record_key in selected for b in snapshot.type_bindings.get(record_key, [])]
    return [b for b in records(snapshot, "binding") if key(b["type"]) in selected]


def member_counts(snapshot, target):
    direct = {key(b["element"]) for b in member_bindings(snapshot, target)}
    entire = {key(b["element"]) for b in member_bindings(snapshot, target, True)}
    return {"direct": len(direct), "descendant": len(entire - direct), "including_descendants": len(entire)}


def browse_namespace(snapshot, target=None, *, cursor=None, limit=50):
    resolution = resolve_target(snapshot, target) if target is not None else {"ref": None, "via": [], "diagnostics": []}
    focal = resolution["ref"]
    result = {"model": snapshot["model"], "resolved_target": focal, "via": resolution["via"],
              "diagnostics": list(resolution["diagnostics"]) + namespace_reservation_diagnostics(snapshot)}
    children = []
    if target is None or focal and focal["kind"] == "type":
        for value in records(snapshot, "type"):
            parent = value["id"].rpartition(".")[0]
            if (target is None and parent) or (focal and parent != focal["id"]):
                continue
            ref = reference("type", value)
            placements = [n for n in records(snapshot, "narrowing") if key(n["child"]) == key(ref)]
            if focal:
                placements = [n for n in placements if key(n["parent"]) == key(focal)]
                if not placements and value["owner"] != focal["owner"]:
                    continue
                if not placements:
                    result["diagnostics"].append({"code": "unresolved_narrowing", "target": ref, "parent": focal})
            children.append({"ref": ref, "value": value, "narrowings": placements, "counts": member_counts(snapshot, ref)})
        if focal:
            for value in records(snapshot, "subtype"):
                if value.get("parent") and key(value["parent"]) == key(focal):
                    children.append({"ref": reference("subtype", value), "value": value, "narrowings": [],
                                     "counts": {"direct": 0, "descendant": 0, "including_descendants": 0}})
    elif focal:
        result["diagnostics"].append({"code": "target_kind_mismatch", "expected": "type", "target": focal})
    # Imported gaps remain diagnostics, never synthetic valid Types.
    index = index_records(snapshot)
    placed = {key(n["child"]): n["parent"] for n in records(snapshot, "narrowing")}
    for value in records(snapshot, "type"):
        parent = value["id"].rpartition(".")[0]
        if not parent or (value["owner"], "type", parent) in index:
            continue
        through = placed.get(key(reference("type", value)))
        if through and through.get("id") == parent and key(through) in index:
            continue
        result["diagnostics"].append({"code": "unresolved_namespace_position", "id": parent, "owner": value["owner"], "child": reference("type", value)})
    query = {"operation": "namespace.browse", "target": focal or target}
    result["records"], result["coverage"] = paginate(children, snapshot["model"], query, cursor, limit)
    result["selected_refs"] = [item["ref"] for item in sorted(children, key=lambda item: key(item["ref"]))]
    return result
