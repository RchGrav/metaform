"""Structural correspondence between independently authored source graphs."""

from collections import Counter

from .util import digest, dumps


def _shape(join, reference):
    result = {"type": join["type"]}
    participants = join.get("participants")
    if participants is None:
        participants = [
            {"role": role, "ref": join[field],
             **({"owner": join["reference_owners"][field]} if field in join.get("reference_owners", {}) else {})}
            for field, role in (("object_id", "receiver"), ("element_id", "ef_owner"))
            if field in join
        ]
    result["participants"] = sorted(
        ({**({"role": p["role"]} if "role" in p else {}),
          **({"ref": reference(p)} if "ref" in p else {})} for p in participants),
        key=dumps,
    )
    for field, role in (("object_id", "receiver"), ("element_id", "ef_owner")):
        if field in join:
            projected = [p for p in participants if p.get("role") == role and p.get("ref") == join[field]]
            ref = dict(projected[0]) if len(projected) == 1 else {"ref": join[field]}
            if field in join.get("reference_owners", {}):
                ref["owner"] = join["reference_owners"][field]
            result[field] = reference(ref)
        refs = [p["ref"] for p in result["participants"] if p.get("role") == role and p.get("ref") is not None]
        if field not in result and len(refs) == 1:
            result[field] = refs[0]
    return result


def _references(shape):
    return {
        *(shape[key] for key in ("object_id", "element_id") if key in shape),
        *(p["ref"] for p in shape["participants"] if "ref" in p),
    } - {None}


def _correspondence(native, latent):
    """Find a consistent one-to-one correspondence, including cyclic join refs."""
    def signature(shape, joins):
        def ref(value):
            return ["join"] if value in joins else ["node", value]

        return dumps({
            **{field: ref(shape[field]) for field in ("object_id", "element_id") if field in shape},
            "type": shape["type"],
            "participants": sorted(
                (dict(p, ref=ref(p["ref"])) if "ref" in p else p for p in shape["participants"]),
                key=dumps,
            ),
        })

    native_signatures = {identifier: signature(shape, native) for identifier, shape in native.items()}
    latent_signatures = {identifier: signature(shape, latent) for identifier, shape in latent.items()}

    candidates = {}
    for identifier in sorted(latent):
        candidates.setdefault(latent_signatures[identifier], []).append(identifier)

    incoming = {identifier: [] for identifier in latent}
    for identifier, shape in latent.items():
        for field in ("object_id", "element_id"):
            if shape.get(field) in incoming:
                incoming[shape[field]].append(dumps([identifier, field]))
        for participant in shape["participants"]:
            if participant.get("ref") in incoming:
                incoming[participant["ref"]].append(dumps([
                    identifier, {key: value for key, value in participant.items() if key != "ref"},
                ]))
    # Swapping these targets leaves every outgoing edge and incoming role unchanged.
    # Only such exact twins can share a branch in the maximum correspondence search.
    twins = {identifier: dumps([shape, sorted(incoming[identifier])])
             for identifier, shape in latent.items()}

    def match(left, right, initial):
        alternatives = [(dict(initial), [("reference", left, right)])]
        while alternatives:
            mapping, pending = alternatives.pop()
            inverse = {value: key for key, value in mapping.items()}
            while pending:
                kind, left, right = pending.pop()
                if kind == "participants":
                    if not left:
                        continue
                    first, rest = left[0], left[1:]
                    choices, tried = [], set()
                    for index, candidate in enumerate(right):
                        key = dumps(candidate)
                        if key in tried:
                            continue
                        tried.add(key)
                        if first.keys() != candidate.keys() or first.get("role") != candidate.get("role"):
                            continue
                        tasks = [("participants", rest, right[:index] + right[index + 1:])]
                        if "ref" in first:
                            a, b = first["ref"], candidate["ref"]
                            if a in native or b in latent:
                                if a not in native or b not in latent or native_signatures[a] != latent_signatures[b]:
                                    continue
                            elif a != b:
                                continue
                            tasks.append(("reference", a, b))
                        choices.append(tasks)
                    if not choices:
                        break
                    for tasks in reversed(choices[1:]):
                        alternatives.append((dict(mapping), pending + tasks))
                    pending.extend(choices[0])
                    continue
                if left not in native and right not in latent:
                    if left != right:
                        break
                    continue
                if left not in native or right not in latent:
                    break
                if left in mapping:
                    if mapping[left] != right:
                        break
                    continue
                if right in inverse or native_signatures[left] != latent_signatures[right]:
                    break
                mapping[left] = right
                inverse[right] = left
                a, b = native[left], latent[right]
                pending.append(("participants", a["participants"], b["participants"]))
                pending.extend(("reference", a[field], b[field]) for field in ("element_id", "object_id") if field in a)
            else:
                yield mapping

    def extensions(remaining, mapping):
        left, rest = remaining[0], remaining[1:]
        available = set(remaining) | mapping.keys()
        used, tried = set(mapping.values()), set()
        for right in candidates.get(native_signatures[left], []):
            if right in used or twins[right] in tried:
                continue
            tried.add(twins[right])
            for option in match(left, right, mapping):
                if not option.keys() - available:
                    yield rest, option
        yield rest, mapping

    best = {}
    maximum = sum((Counter(native_signatures.values()) & Counter(latent_signatures.values())).values())
    order = sorted(native, key=lambda identifier: (
        len(candidates.get(native_signatures[identifier], [])),
        -len(_references(native[identifier]) & native.keys()), identifier,
    ))
    branches = [iter([(order, {})])]
    while branches:
        try:
            remaining, mapping = next(branches[-1])
        except StopIteration:
            branches.pop()
            continue
        if len(mapping) > len(best):
            best = mapping
        if len(best) == maximum:
            return best
        remaining = [identifier for identifier in remaining if identifier not in mapping]
        native_counts = Counter(native_signatures[identifier] for identifier in remaining)
        used = set(mapping.values())
        latent_counts = Counter(value for identifier, value in latent_signatures.items() if identifier not in used)
        upper_bound = len(mapping) + sum((native_counts & latent_counts).values())
        if upper_bound > len(best):
            branches.append(extensions(remaining, mapping))
    return best


def compare(contextual, latent, *, owner=None, resolve=None):
    graphs = {"native": contextual, "archaeology": latent}
    if resolve is None:
        from .knowledge import KnowledgeSnapshot
        resolve = KnowledgeSnapshot(0, {owner: {
            "elements": contextual["elements"] | latent["elements"],
            "joins": contextual["joins"] + latent["joins"],
        }}).resolve

    def reference(ref):
        if ref["ref"] is None:
            return None
        key = resolve(ref, owner)[0]
        # Elements correspond by semantic address; reified joins by qualified identity.
        return (key.kind, key.owner if key.kind != "element" else None, key.id)

    shapes = {
        scope: {("join", owner, join["id"]): _shape(join, reference) for join in graph["joins"]}
        for scope, graph in graphs.items()
    }
    membership = lambda sources: ("1" if "archaeology" in sources else "0") + ("1" if "native" in sources else "0")
    nodes = {}
    for scope, graph in graphs.items():
        identifiers = set(graph["elements"])
        for shape in shapes[scope].values():
            identifiers.update(ref[2] for ref in _references(shape) if ref[0] == "element")
        for identifier in identifiers:
            nodes.setdefault(identifier, {})[scope] = [identifier]
    pairs = _correspondence(shapes["native"], shapes["archaeology"])
    records = []
    for identifier in sorted(shapes["native"]):
        sources = {"native": [identifier[2]]}
        if identifier in pairs:
            sources["archaeology"] = [pairs[identifier][2]]
        records.append(("native", identifier, sources))
    paired = set(pairs.values())
    records.extend(
        ("archaeology", identifier, {"archaeology": [identifier[2]]})
        for identifier in sorted(shapes["archaeology"]) if identifier not in paired
    )
    references = {
        (scope, ("join", owner, identifier)): "similarity:" + digest(sources)
        for _, _, sources in records for scope, identifiers in sources.items() for identifier in identifiers
    }
    joins = []
    for scope, identifier, sources in records:
        def rendered(ref):
            if ref is None:
                return {"ref": None}
            if (scope, ref) in references:
                return {"ref": references[scope, ref]}
            kind, target_owner, target = ref
            return {"ref": target, **({"kind": kind} if kind != "element" else {}),
                    **({"owner": target_owner} if target_owner is not None else {})}

        shape = shapes[scope][identifier]
        result = {"id": references[scope, identifier], "type": shape["type"],
                  "membership": membership(sources), "sources": sources,
                  "schema_id": "metaform:merged-join"}
        for field in ("object_id", "element_id"):
            if field in shape:
                ref = rendered(shape[field])
                result[field] = ref["ref"]
                if "owner" in ref:
                    result.setdefault("reference_owners", {})[field] = ref["owner"]
        result["participants"] = [
            dict(p, **rendered(p["ref"])) if "ref" in p else dict(p)
            for p in shape["participants"]
        ]
        joins.append(result)
    return {
        "elements": {identifier: {"membership": membership(sources), "sources": sources}
                     for identifier, sources in sorted(nodes.items())},
        "joins": sorted(joins, key=lambda join: join["id"]),
    }
