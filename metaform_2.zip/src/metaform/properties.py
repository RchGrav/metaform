"""Origin-preserving property applicability over a foundation revision.

Forward routes use Type bindings/narrowing, scoped Element refinement, or
explicit OP context. Backward summaries never become forward origins.
"""
from collections import OrderedDict, defaultdict, deque
from copy import deepcopy
from functools import lru_cache
import json


_COLLECTIONS = {'types': 'type', 'elements': 'element', 'bindings': 'binding',
                'narrowings': 'narrowing', 'refinements': 'refinement', 'joins': 'join'}


def _key(ref):
    return tuple(ref.get(k) for k in ('owner', 'kind', 'id'))


def _ref(record, kind=None):
    result = {k: record[k] for k in ('owner', 'id') if k in record}
    result['kind'] = kind or record.get('kind')
    if 'revision' in record:
        result['revision'] = record['revision']
    return result


def _same(left, right):
    return _key(left) == _key(right) and (not left.get('revision') or not right.get('revision') or left['revision'] == right['revision'])


def _layer_records(records):
    for record in records:
        if 'attachments' in record and isinstance(record.get('generation'), dict):
            yield _ref(record['generation'], 'generation'), record['generation']
            for attachment in record['attachments']:
                yield _ref(attachment, 'knowledge'), attachment
        else:
            kind = 'knowledge' if 'subject' in record else record.get('kind', 'generation')
            yield _ref(record, kind), record


class _Context:
    def __init__(self, snapshot, layer_records):
        self.snapshot = snapshot
        self.records = {}
        self.down = defaultdict(list)
        self.up = defaultdict(list)
        self.bindings = defaultdict(list)
        self.classifications = defaultdict(list)
        self.refinements = defaultdict(list)
        self.coarse = defaultdict(list)
        self.receivers = defaultdict(list)
        self.diagnostics = []
        for collection, kind in _COLLECTIONS.items():
            records = snapshot.get(collection, [])
            for record in records.values() if isinstance(records, dict) else records:
                self.records[_key(_ref(record, kind))] = record
        for reference, record in _layer_records(layer_records):
            self.records[_key(reference)] = record
        for record in snapshot.get('narrowings', []):
            if not record.get('reason'):
                self.diagnostics.append({'code': 'unresolved_narrowing', 'ref': _ref(record, 'narrowing')})
                continue
            if self.get(record.get('parent', {})) and self.get(record.get('child', {})):
                self.down[_key(record['parent'])].append(record)
                self.up[_key(record['child'])].append(record)
        for record in snapshot.get('bindings', []):
            if self.get(record.get('element', {})) and self.get(record.get('type', {})):
                self.bindings[_key(record['type'])].append(record)
                self.classifications[_key(record['element'])].append(record)
        for record in snapshot.get('refinements', []):
            if record.get('reason') and self.get(record.get('parent', {})) and self.get(record.get('child', {})):
                self.refinements[_key(record['parent'])].append(record)
                self.coarse[_key(record['child'])].append(record)
        for record in snapshot.get('joins', []):
            self.receivers[_key(record.get('provider', {}))].append(record)
        self._narrowing_cycles()

    def get(self, reference):
        record = self.records.get(_key(reference))
        if record and reference.get('revision') and reference['revision'] != record.get('revision'):
            return None
        return record

    def _narrowing_cycles(self):
        finished = set()
        for start in list(self.down):
            if start in finished:
                continue
            stack = [(start, iter(self.down[start]))]
            positions = {start: 0}
            edges = []
            while stack:
                current, children = stack[-1]
                edge = next(children, None)
                if edge is None:
                    stack.pop()
                    positions.pop(current)
                    finished.add(current)
                    if edges:
                        edges.pop()
                    continue
                child = _key(edge['child'])
                if child in positions:
                    cycle = edges[positions[child]:] + [edge]
                    self.diagnostics.append({'code': 'narrowing_cycle',
                                             'relations': [_ref(e, 'narrowing') for e in cycle],
                                             'path': [cycle[0]['parent']] + [e['child'] for e in cycle]})
                elif child not in finished:
                    positions[child] = len(stack)
                    edges.append(edge)
                    stack.append((child, iter(self.down[child])))

    def step(self, relation, kind, label, start, end):
        result = {'relation': _ref(relation, kind), 'step': label, 'from': start, 'to': end,
                  'reason': relation.get('reason', relation.get('purpose', label))}
        if kind == 'join':
            for field in ('receiver', 'provider', 'provider_type', 'purpose', 'role', 'signal', 'join_logic', 'scope', 'participants'):
                if field in relation:
                    result[field] = relation[field]
            provider_type = self.get(relation.get('provider_type', {}))
            result['ef'] = provider_type.get('ef') if provider_type else None
        return result

    def visibility_edges(self, current):
        # These edges are only consumed by the backward projection.
        for binding in self.classifications[_key(current)]:
            yield binding['type'], self.step(binding, 'binding', 'Type visibility', current, binding['type'])
        for edge in self.up[_key(current)]:
            yield edge['parent'], self.step(edge, 'narrowing', 'ancestor visibility', current, edge['parent'])
        for edge in self.coarse[_key(current)]:
            yield edge['parent'], self.step(edge, 'refinement', 'coarse account visibility', current, edge['parent'])
        if _same(current, self.snapshot.get('artifact', {})):
            return
        for join in self.receivers[_key(current)]:
            receiver = join.get('receiver', {})
            if receiver.get('kind') == 'element' and self.get(receiver):
                yield receiver, self.step(join, 'join', 'receiving account visibility', current, receiver)


def _walk(start, target, edges, initial=()):
    """Keep a representative path plus alternative predecessor references.

    Origin and scope are fixed for each walk; the visited current reference
    therefore completes the (origin, current, scope) visitation key.
    """
    queue = deque([(start, list(initial))])
    visited = {_key(start)}
    found = list(initial) if _same(start, target) else None
    alternatives = []
    while queue:
        current, path = queue.popleft()
        for destination, step in edges(current):
            candidate = path + [step]
            if _same(destination, target):
                if found is None:
                    found = candidate
                elif candidate != found:
                    alternatives.append([s['relation'] for s in candidate])
            if _key(destination) not in visited:
                visited.add(_key(destination))
                queue.append((destination, candidate))
    return found, alternatives


def _scope_options(scope):
    return {**scope.get('parameters', {}), **scope}


def _freshness(record, context):
    if 'freshness' in record:
        return record['freshness']
    if not record.get('generation'):
        return None
    generation = context.get(record['generation'])
    if not generation:
        return 'unknown'
    return 'current' if generation.get('model') == context.snapshot.get('model') else 'unknown'


def _explain(snapshot, subject, origin, layer_records, context=None):
    context = context or _Context(snapshot, layer_records)
    is_record = 'subject' in origin or 'receiver' in origin
    origin_ref = _ref(origin, 'knowledge' if 'subject' in origin else 'join') if is_record else origin
    record = origin if is_record else context.get(origin_ref)
    result = {'model': snapshot.get('model'), 'subject': subject, 'origin': origin_ref,
              'origin_layer': None, 'generation': None, 'freshness': None,
              'applies': False, 'visible_here': False, 'claim': None, 'scope': {},
              'path': [], 'visibility_path': [], 'alternative_paths': [],
              'source_refs': [], 'qualifications': [], 'payload_locators': [],
              'diagnostics': list(context.diagnostics), 'explanation': ''}
    if not context.get(subject):
        result['diagnostics'].append({'code': 'unresolved_subject', 'ref': subject})
        return result
    if record is None:
        result['diagnostics'].append({'code': 'unresolved_origin', 'ref': origin_ref})
        return result
    origin_ref = _ref(record, origin_ref['kind'])
    result['origin'] = origin_ref
    attachment = 'subject' in record
    anchor = record.get('subject') if attachment else record.get('receiver')
    if not anchor or not context.get(anchor):
        result['diagnostics'].append({'code': 'unresolved_origin_subject', 'ref': anchor})
        return result
    descriptor = record.get('applicability', {}) if attachment else {}
    scope = descriptor.get('scope', {}) if attachment else record.get('scope', {})
    options = _scope_options(scope)
    local_only = options.get('kind') == 'direct' if attachment else record.get('is_soft', False)
    result.update(origin_layer=record.get('layer'), generation=record.get('generation'),
                  freshness=_freshness(record, context), scope=scope,
                  source_refs=record.get('evidence', record.get('source_refs', [])),
                  qualifications=record.get('qualifications', descriptor.get('qualifications', [])))
    initial = []
    if attachment:
        result['claim'] = record.get('payload')
    elif record.get('role') == 'property':
        if not context.get(record.get('provider_type', {})) or not context.get(record.get('provider', {})) or not record.get('purpose'):
            result['diagnostics'].append({'code': 'unresolved_property_meeting', 'ref': origin_ref})
            return result
        result['claim'] = record.get('claim', {'name': record['purpose'], 'value': record['provider_type']['id'], 'provider_type': record['provider_type']})
        initial = [context.step(record, 'join', 'property meeting', record['provider'], anchor)]
    else:
        result['diagnostics'].append({'code': 'not_property_origin', 'ref': origin_ref})
        return result

    named_targets = options.get('targets', [])
    descendants = options.get('descendants', anchor.get('kind') == 'type')
    relation_refs = descriptor.get('relation_refs', [])
    declared_joins = []
    for reference in relation_refs:
        relation = context.get(reference)
        if relation is None:
            result['diagnostics'].append({'code': 'unresolved_relation', 'ref': reference})
        elif reference.get('kind') == 'join':
            declared_joins.append(relation)

    def forward_edges(current):
        if local_only:
            return
        if current.get('kind') == 'type' and anchor.get('kind') == 'type':
            if descendants:
                for edge in context.down[_key(current)]:
                    yield edge['child'], context.step(edge, 'narrowing', 'Type narrowing', current, edge['child'])
            for binding in context.bindings[_key(current)]:
                yield binding['element'], context.step(binding, 'binding', 'Type binding', current, binding['element'])
        if anchor.get('kind') == 'element' and (descendants or named_targets):
            for edge in context.refinements[_key(current)]:
                yield edge['child'], context.step(edge, 'refinement', 'Element refinement', current, edge['child'])
        # A declared context names a meeting; it is never a license to BFS OPs.
        for join in declared_joins:
            join_ref = _ref(join, 'join')
            participants = [join.get('receiver', {}), join.get('provider', {})]
            participants += [p['ref'] for p in join.get('participants', []) if 'ref' in p]
            if not (_same(current, anchor) and (_same(anchor, join_ref) or any(_same(anchor, p) for p in participants))):
                continue
            targets = named_targets or ([options['target']] if options.get('target', {}).get('kind') != 'join' and options.get('kind') not in ('neighbors', 'graph.neighbors', 'graph.traverse') and options.get('target') else participants + [join_ref])
            for destination in participants + [join_ref]:
                if not _same(destination, current) and context.get(destination) and any(_same(destination, t) for t in targets):
                    yield destination, context.step(join, 'join', 'declared OP context', current, destination)

    path, alternatives = _walk(anchor, subject, forward_edges, initial)
    scope_targets = named_targets or ([options['target']] if options.get('target') else [])
    if scope_targets and not local_only and not _same(anchor, subject):
        def scope_edges(current):
            if current.get('kind') == 'type':
                if descendants:
                    for edge in context.down[_key(current)]:
                        yield edge['child'], context.step(edge, 'narrowing', 'Type narrowing', current, edge['child'])
                for binding in context.bindings[_key(current)]:
                    yield binding['element'], context.step(binding, 'binding', 'Type binding', current, binding['element'])
            elif current.get('kind') == 'element' and options.get('descendants', False):
                for edge in context.refinements[_key(current)]:
                    yield edge['child'], context.step(edge, 'refinement', 'Element refinement', current, edge['child'])
            if options.get('kind') in ('neighbors', 'graph.neighbors', 'graph.traverse'):
                yield from forward_edges(current)
        if not any(_walk(target, subject, scope_edges)[0] is not None for target in scope_targets):
            path = None
    locators = [entry['locator'] for entry in record.get('target_index', []) if _same(entry.get('target', {}), subject)]
    if locators and (not local_only or _same(anchor, subject)):
        result['payload_locators'] = locators
        path = []
        result['explanation'] = 'The report explicitly addresses this target at the recorded payload locator.'
    if _same(subject, origin_ref):
        path = []
    result['applies'] = path is not None
    result['path'] = path or []
    result['alternative_paths'] = alternatives
    if not result['applies'] and not local_only:
        visibility, _ = _walk(anchor, subject, context.visibility_edges, initial)
        result['visible_here'] = visibility is not None
        result['visibility_path'] = visibility or []
    elif result['applies']:
        result['visible_here'] = True
    freshness = result['freshness']
    freshness_state = freshness.get('state', freshness.get('status')) if isinstance(freshness, dict) else freshness
    if freshness_state in ('stale', 'invalid', 'invalidated', 'orphaned', 'reconsider'):
        result['applies'] = False
        result['diagnostics'].append({'code': 'knowledge_not_current', 'freshness': freshness})
    if not result['explanation']:
        if result['applies']:
            result['explanation'] = descriptor.get('reason') or ('The receiver receives this property through its own OP meeting.' if initial else 'The knowledge applies through its recorded subject and semantic relationships.')
        elif result['visible_here']:
            result['explanation'] = 'The origin is visible in this account; its original scope is retained.'
        else:
            result['explanation'] = 'No recorded applicability or backward visibility path connects this origin to the subject.'
            result['diagnostics'].append({'code': 'no_applicability_path', 'origin': origin_ref, 'subject': subject})
    return result


@lru_cache(maxsize=128)
def _cached_explanation(snapshot_json, subject_json, origin_json, layers_json):
    return _explain(json.loads(snapshot_json), json.loads(subject_json), json.loads(origin_json), json.loads(layers_json))


def explain_applicability(snapshot: dict, subject: dict, origin: dict, layer_records: list) -> dict:
    """Explain one qualified property-join or knowledge origin at ``subject``.

    ``origin`` may be a qualified Ref or the attachment/property-join record.
    ``layer_records`` accepts flat attachments/generations or interchange layer
    bundles. Memoization includes the immutable model and all supplied record,
    selector, applicability, and generation values; edited inputs cannot reuse
    an explanation keyed only by a target spelling. A published revision is
    keyed by its revision identity, since its content is a digest, and its
    traversal context is built once per revision. Results are detached copies.
    """
    encode = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'))
    revision_key = getattr(snapshot, 'revision_key', None)
    if revision_key is None:
        return deepcopy(_cached_explanation(*(encode(value) for value in (snapshot, subject, origin, layer_records))))
    layers_key = 'snapshot' if layer_records is getattr(snapshot, 'by_kind', {}).get('knowledge') else encode(layer_records)
    context = _remember(_CONTEXTS, (revision_key, layers_key), lambda: _Context(snapshot, layer_records), 16)
    key = (revision_key, layers_key, encode(subject), encode(origin))
    return deepcopy(_remember(_EXPLANATIONS, key, lambda: _explain(snapshot, subject, origin, layer_records, context), 4096))


_CONTEXTS = OrderedDict()
_EXPLANATIONS = OrderedDict()


def _remember(cache, key, build, limit):
    value = cache.get(key)
    if value is None:
        value = cache[key] = build()
        while len(cache) > limit:
            cache.popitem(last=False)
    else:
        cache.move_to_end(key)
    return value
