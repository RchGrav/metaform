"""Dependency-free stdio MCP for exported work; inference uses the host answer loop.

Implements tools, resources, and prompts from the 2025-11-25 specification. Installed
use retains the SDK transport, including sampling and newer protocol features.
"""

from __future__ import annotations

import asyncio
import json
import os
import select
import stat
import sys
from contextlib import contextmanager

from . import __version__, schemas
from .registry import Registry
from .onboarding import instructions, skill_text
from .util import dumps


def _read_input(fd):
    """Read available bytes only; a partial JSON line must remain cancellable."""
    if os.name != "nt":
        return os.read(fd, 65536) if select.select([fd], [], [], 0)[0] else None

    # Standard Windows pipes are not overlapped handles, so asyncio's pipe
    # transports cannot read them. Peek before reading instead of blocking a
    # thread that the event loop would have to join during shutdown.
    import ctypes
    import msvcrt
    from ctypes import wintypes

    if os.isatty(fd):
        if not msvcrt.kbhit():
            return None
        character = msvcrt.getwch()
        if character == "\x1a":
            return b""
        return ("\n" if character == "\r" else character).encode("utf-8")
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = wintypes.HANDLE(msvcrt.get_osfhandle(fd))
    if kernel.GetFileType(handle) != 3:  # FILE_TYPE_PIPE
        return os.read(fd, 65536)
    available = wintypes.DWORD()
    if not kernel.PeekNamedPipe(handle, None, 0, None, ctypes.byref(available), None):
        error = ctypes.get_last_error()
        if error in (109, 233):  # Broken or disconnected pipe is EOF.
            return b""
        raise ctypes.WinError(error)
    return os.read(fd, min(65536, available.value)) if available.value else None


async def input_lines(stream=None):
    """UTF-8 stdio framing shared by the portable and installed transports."""
    fd = (stream or sys.stdin).fileno()
    pending = bytearray()
    while True:
        chunk = _read_input(fd)
        if chunk is None:
            await asyncio.sleep(0.01)
            continue
        if not chunk:
            if pending:
                yield pending.decode("utf-8", errors="replace")
            return
        pending.extend(chunk)
        while (end := pending.find(b"\n")) >= 0:
            line = pending[:end + 1]
            del pending[:end + 1]
            yield line.decode("utf-8", errors="replace")
            await asyncio.sleep(0)


def _pipe_blocking(fd, blocking=None):
    if os.name == "nt" and not stat.S_ISFIFO(os.fstat(fd).st_mode):
        return True
    if os.name != "nt" or sys.version_info >= (3, 12):
        if blocking is None:
            return os.get_blocking(fd)
        os.set_blocking(fd, blocking)
        return
    import ctypes
    import msvcrt
    from ctypes import wintypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    handle = wintypes.HANDLE(msvcrt.get_osfhandle(fd))
    if kernel.GetFileType(handle) != 3:
        return True
    mode = wintypes.DWORD()
    if not kernel.GetNamedPipeHandleStateW(handle, ctypes.byref(mode), None, None, None, None, 0):
        raise ctypes.WinError(ctypes.get_last_error())
    if blocking is None:
        return not bool(mode.value & 1)
    mode.value = mode.value & ~1 if blocking else mode.value | 1
    if not kernel.SetNamedPipeHandleState(handle, ctypes.byref(mode), None, None):
        raise ctypes.WinError(ctypes.get_last_error())


class Output:
    def __init__(self, fd):
        self.fd = fd
        self.lock = asyncio.Lock()

    async def write(self, text):
        async with self.lock:
            pending = memoryview(text.encode("utf-8"))
            while pending:
                try:
                    written = os.write(self.fd, pending)
                except BlockingIOError:
                    written = 0
                pending = pending[written:]
                if pending:
                    await asyncio.sleep(0.01)

    async def flush(self):
        pass  # Writes go directly to the pipe, without a buffered worker thread.


@contextmanager
def output_stream():
    """Own the wire while keeping incidental handler output on stderr."""
    sys.stdout.flush()
    destination = sys.stdout.fileno()
    saved = os.dup(destination)
    try:
        blocking = _pipe_blocking(saved)
        try:
            _pipe_blocking(saved, False)
            os.dup2(sys.stderr.fileno(), destination)
            yield Output(saved)
        finally:
            try:
                sys.stdout.flush()
            finally:
                os.dup2(saved, destination)
                _pipe_blocking(saved, blocking)
    finally:
        os.close(saved)


class Context:
    def __init__(self, app=None, session=None):
        self.app, self.session = app, session

    def select_project(self, selector):
        if self.app is None or self.app.binding or self.session is None:
            raise ValueError("Project selection requires an unbound client session")
        return self.session.select(selector)

    async def sample(self, job, answer_command):
        return job | {
            "transport": "host_answer_loop",
            "answer_command": answer_command,
            "message": "Execute this assignment with the host model, submit its answer, then request the next step.",
        }


def tool_list(registry):
    commands = registry.visible()
    return {
        "tools": [
            {
                "name": "abort",
                "description": "Leave the active module and return to the router.",
                "inputSchema": {"type": "object", "properties": {}},
            },
            {
                "name": "metaform",
                "description": "Discover the current module's commands or execute its command or raw input.",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "command": {"type": "string"},
                        "arguments": {"type": "object"},
                        "raw": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            *[
                c.definition(registry.app)
                for c in commands.values()
            ],
        ]
    }


async def dispatch(app, registry, method, params, context=None):
    context = context or Context(app)
    if method == "initialize":
        return {
            "protocolVersion": "2025-11-25",
            "capabilities": {"tools": {"listChanged": True}, "resources": {}, "prompts": {}},
            "serverInfo": {"name": "metaform", "version": __version__},
            "instructions": instructions(app),
        }
    if method == "ping":
        return {}
    if method == "prompts/list":
        return {"prompts": [{"name": "metaform", "description": "Guide the user through intake and work with their Inference Metaform."}]}
    if method == "prompts/get":
        from .onboarding import guide_state

        if params["name"] != "metaform":
            raise ValueError("Unknown prompt")
        return {
            "description": "Metaform concierge guidance and current project state.",
            "messages": [
                {"role": "user", "content": {"type": "text", "text": skill_text(app)}},
                {"role": "user", "content": {"type": "text", "text": dumps(guide_state(app))}},
            ],
        }
    if method == "tools/list":
        return tool_list(registry)
    if method == "tools/call":
        try:
            name, arguments = params["name"], params.get("arguments") or {}
            if name == "metaform":
                if "raw" in arguments:
                    result = await registry.raw(arguments["raw"], context)
                elif arguments.get("command"):
                    result = await registry.call(
                        arguments["command"], arguments.get("arguments"), context
                    )
                else:
                    result = {
                        "instructions": instructions(app),
                        "mode": app.get("mode"),
                        "commands": tool_list(registry)["tools"][2:],
                        "bailout": "abort",
                    }
            else:
                result = await registry.call(name, arguments, context)
            from .tool_content import content_blocks

            return {
                "content": content_blocks(result),
                "structuredContent": result if isinstance(result, dict) else {"result": result},
                "isError": False,
            }
        except Exception as exc:
            return {"content": [{"type": "text", "text": str(exc)}], "isError": True}
    if method == "resources/list":
        resources = [
            {"name": name, "uri": "metaform://schema/" + name, "mimeType": "application/schema+json"}
            for name in schemas.registry(app)
        ]
        if not app.get("mode"):
            resources.extend(
                {"name": name, "uri": "metaform://" + name, "mimeType": "application/json"}
                for name in ("graph", "stats")
            )
        return {"resources": resources}
    if method == "resources/templates/list":
        from .semantic_resources import templates

        return {"resourceTemplates": templates(app)}
    if method == "resources/read":
        uri = params["uri"]
        if uri.startswith("metaform://schema/"):
            value = schemas.registry(app)[uri[len("metaform://schema/"):]]
        elif uri.startswith("metaform://model/"):
            from .semantic_resources import read

            value = await read(app, uri)
        elif not app.get("mode") and uri == "metaform://graph":
            value = app.graph.export()
        elif not app.get("mode") and uri == "metaform://stats":
            value = app.graph.stats()
        else:
            raise ValueError("Unknown resource")
        return {"contents": [{"uri": uri, "mimeType": "application/json", "text": dumps(value)}]}
    raise LookupError("Method not found: " + method)


async def serve(app):
    with output_stream() as output:
        await _serve(app, output)


async def _serve(app, output):
    from .modules.project import ProjectSession
    session = ProjectSession(app)
    requests = {}

    async def write(message):
        await output.write(dumps({"jsonrpc": "2.0", **message}) + "\n")

    async def respond(message, app):
        registry = Registry(app)
        before = tuple(Registry(session.app).visible())
        app.trace("mcp.request", message)
        try:
            result = await dispatch(app, registry, message["method"], message.get("params") or {}, Context(app, session))
            response = {"id": message["id"], "result": result}
        except Exception as exc:
            response = {
                "id": message["id"],
                "error": {"code": -32601 if isinstance(exc, LookupError) and not isinstance(exc, KeyError) else -32602, "message": str(exc)},
            }
        app.trace("mcp.response", response)
        await write(response)
        if before != tuple(Registry(session.app).visible()):
            await write({"method": "notifications/tools/list_changed"})

    try:
        async for line in input_lines():
            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                await write({"id": None, "error": {"code": -32700, "message": "Invalid JSON"}})
                continue
            if not isinstance(message, dict) or message.get("jsonrpc") != "2.0" or not isinstance(message.get("method"), str):
                await write({"id": None, "error": {"code": -32600, "message": "Invalid request"}})
                continue
            if "id" in message and type(message["id"]) not in (str, int):
                await write({"id": None, "error": {"code": -32600, "message": "Invalid request identifier"}})
                continue
            if "params" in message and not isinstance(message["params"], dict):
                if "id" in message:
                    await write({"id": message["id"], "error": {"code": -32602, "message": "Parameters must be an object"}})
                continue
            if "id" not in message:
                if message["method"] == "notifications/cancelled":
                    identifier = message.get("params", {}).get("requestId")
                    task = requests.get(identifier) if type(identifier) in (str, int) else None
                    if task:
                        task.cancel()
                continue
            identifier = message["id"]
            task = asyncio.create_task(respond(message, session.app))
            requests[identifier] = task
            task.add_done_callback(lambda _, key=identifier: requests.pop(key, None))
    finally:
        pending = list(requests.values())
        for task in pending:
            task.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
