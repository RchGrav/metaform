"""Read-only source-file comparison against an intake's recorded baseline."""

import hashlib
import os
import stat

from .knowledge import KnowledgeError
from .models import capture_model
from .util import now


FORMULA = '100 * (added + modified + deleted) / union of baseline and current source paths; 0 when the union is empty.'


def source_files(app):
    from .modules.intake import project_files

    files = {}
    for name in project_files(app.project, app.home):
        path = app.project / name
        try:
            mode = path.lstat().st_mode
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(mode):
            files[name] = {'kind': 'symlink', 'target': os.readlink(path)}
        elif stat.S_ISREG(mode):
            hasher = hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    hasher.update(chunk)
            files[name] = {'kind': 'file', 'sha256': hasher.hexdigest()}
    return files


def capture(app, run_id, planned=False):
    return {'id': run_id, 'captured_at': now(), 'status': 'planned' if planned else 'available',
            'files': {} if planned else source_files(app)}


def report(app, model=None):
    result = {'status': 'unavailable', 'model': model, 'baseline': None,
              'added': None, 'modified': None, 'deleted': None, 'total_compared_paths': None,
              'baseline_file_count': None, 'current_file_count': None,
              'net_growth_files': None, 'net_growth_percentage': None,
              'percentage': None, 'formula': FORMULA,
              'growth_formula': '100 * (current_file_count - baseline_file_count) / baseline_file_count; unavailable when the baseline is empty.',
              'message': 'No source baseline was recorded for this Inference Metaform.'}
    try:
        snapshot = capture_model(app, model)
    except KnowledgeError as exc:
        if exc.code not in {'model_not_found', 'ambiguous_model'}:
            raise
        result['message'] = str(exc)
        return result
    result['model'] = snapshot['model']
    baseline = next((item['source_baseline']
                     for activity in reversed(snapshot.get('activities', []))
                     for item in reversed(activity.get('inputs', []))
                     if isinstance(item, dict) and 'source_baseline' in item), None)
    if baseline is None:
        return result
    result['baseline'] = {key: baseline[key] for key in ('id', 'captured_at')}
    if baseline['status'] == 'planned':
        result.update(status='planned', message='This intake describes a plan; no repository source baseline was captured.')
        return result
    before, after = baseline['files'], source_files(app)
    added = len(after.keys() - before.keys())
    deleted = len(before.keys() - after.keys())
    modified = sum(before[name] != after[name] for name in before.keys() & after.keys())
    total = len(before.keys() | after.keys())
    percentage = 100 * (added + modified + deleted) / total if total else 0
    result.update(status='available', added=added, modified=modified, deleted=deleted,
                  total_compared_paths=total, percentage=percentage,
                  baseline_file_count=len(before), current_file_count=len(after),
                  net_growth_files=len(after) - len(before),
                  net_growth_percentage=100 * (len(after) - len(before)) / len(before) if before else None)
    result.pop('message')
    return result
