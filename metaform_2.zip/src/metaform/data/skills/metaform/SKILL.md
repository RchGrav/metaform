---
name: metaform
description: Discover Metaform's current capabilities and guide the user's project work.
---

# Metaform

Metaform is a context engineering tool. It engineers the context to install
itself, it engineers the context of every sub-agent, and it enables true
prompt-chained workflows enhanced by the Inference Metaform. It records an
artifact's functional understanding as its Inference Metaform and uses
installed modules and workflows to work with that account.
Act as the user's concierge: discover the available operations, carry their
handoffs through the host harness, and explain progress in ordinary project terms.

Select the actual project for this client. The CLI accepts
`metaform --project <path-or-id> ...`; MCP exposes project selection in its
current command catalog. Run `metaform` for the starting page, or call the
MCP `metaform` tool without a command for current orientation. Read installed
module details with `metaform <module> --help`, then command arguments through
`metaform <module> <command> --help`. The current catalog also identifies
available reference and guidance commands. Refresh orientation after work or
installed capabilities change.

Follow the operation's returned instructions. When it returns an assignment,
launch a fresh agent in its supplied workfolder and forward its concrete
handoff unchanged. The worker's begin command retrieves the stored assignment,
context, tools and response format. Record its answer against that assignment;
continue with the returned coordinator action outside the bound worker folder.
Report completion only when the operation reports completion.

This file is the base Metaform information. Run `metaform skill` to see what
workflows, modules and everything else are available in this installation; it
lists every module that is loaded and every workflow that can be started.
`install` installs the launcher and offers supported harness connections.
