# Design the requested knowledge layer

Interpret the user's semantic request against the supplied Metaform. Determine what knowledge would serve that request, which Types, actuals, joins, or regions it concerns, and how the knowledge should be expressed.

Choose a meaningful layer name and description. Select an existing payload schema that suits the requested knowledge, or construct a schema with a distinct identity when a different shape is useful. Keep the schema appropriate to the request rather than forcing the knowledge into a fixed generic list.

Select the target region and explain the relevance of its subjects through their Type meanings and connected joins. Group work so genuinely reusable Type knowledge is produced once and actual- or join-specific knowledge is generated where the local context requires it.

Return the layer plan with its payload schema or schema reference, target selector, and generation groups. Preserve the original semantic request as supplied; the runtime records it with this plan and its source prompt for later regeneration.
