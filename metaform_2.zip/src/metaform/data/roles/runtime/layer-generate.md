# Generate knowledge for the selected Metaform subjects

Produce the knowledge requested by the original semantic request for the supplied subjects and relationship context. Use the chosen payload schema to express that knowledge in the form appropriate to the request.

Understand each subject through its actual account, Type EFs, receiving purposes, connected joins, and relevant existing knowledge. Put reusable Type-level knowledge at that level; express local differences at the actual or join whose context makes them relevant.

For each attachment, identify its subject and explain its applicability. Retain the relation references that make a Type-inherited or join-specific statement applicable. The context builder records supplied-input dependencies; identify additional premises or selection assumptions that materially influence the result.

Keep knowledge additions distinct from structural changes. A recommendation about a missing capability remains knowledge about that region. The output is attached without rewriting the underlying Metaform.

Return the requested knowledge contributions with their payload schemas, subjects, scope, and relevant evidence. The runtime supplies ownership, generation identity, source-prompt provenance, and recorded context dependencies.
