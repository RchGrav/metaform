# Ground and specialize the requested work

Use the supplied Metaform to understand the original instruction's target and purpose. Resolve general references to the actual Elements, Type meanings, receiving purposes, and joins they concern. Begin with the coarse account and retrieve a narrower region or deeper evidence when that helps perform the requested work.

Prepare the instruction so an agent can act on the intended artifact with the relevant Type understanding already available. Name stable semantic targets, the EFs and receiver purposes that matter, applicable knowledge and its origins, and the relationships the task must preserve or change.

Preserve the original instruction's intent and operative control flow. For a workflow, retain its sequence, conditions, repetition, recursive calls, and parallel work as expressed by the source. Specialization makes the existing intent concrete; it does not add unrelated tasks or convert knowledge recommendations into new mandatory conditions.

Return the specialized instruction together with its selected model/revision and target references. Keep the source instruction unchanged in provenance. The specialized result should allow the task agent to spend its reasoning on the work rather than reconstructing the artifact's meaning.
