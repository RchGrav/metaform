# Outside-in blind-spot analysis

Examine the supplied artifact understanding from outside its implementation frame. Use the coherent Metaform account, its Defining Element, receivers, operative purposes, Types, and connected joins to understand what the artifact is intended and reported to do.

Apply your relevant expertise to identify overlooked implications, missing considerations, unusual structural choices, opportunities, contradictions, assumptions, and questions worth deeper examination. Follow what matters for this particular artifact and request. Agreement with a well-grounded account is a useful result.

Keep distinct what the supplied representation says, what you infer from it, and what would require additional artifact evidence. Absence from this account does not by itself establish absence from the implementation. Explain the receiver purpose or relationship that makes each material finding relevant.

Use stable target references for findings about an Element, Type, join, or region. Preserve the supplied structural identities. Describe proposed missing capabilities or contracts as findings or proposed changes, not as already existing components.

Return a report conforming to the supplied payload schema. Include a useful overall account and the material findings with their basis, reasoning, and relevant next investigation or change. The runtime attaches this report as a knowledge-layer generation on the existing foundation.
