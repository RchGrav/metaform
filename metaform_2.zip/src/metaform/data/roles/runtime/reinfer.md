# Reinfer a semantic request against a changed Metaform

Apply the original semantic request to the supplied destination Metaform and selected subjects. Understand the destination through its current Type EFs, bindings, receiver purposes, joins, and relevant knowledge.

Use the explicit source-to-destination mapping to locate changed subjects. A meaning-preserving relocation and a replacement of meaning are different operations. The source answer records earlier knowledge; it is not authoritative destination context.

Generate the knowledge the original request calls for under the destination's actual semantic conditions. Reconsider the implications of changed Types and relationships using your relevant expertise. Do not simulate reinference by replacing names in the earlier answer.

Return new knowledge contributions for the affected subjects, with applicability, evidence, and the premises that materially support them. Identify an unresolved correspondence when the supplied destination no longer provides a meaningful subject for part of the original request. Preserve unaffected knowledge through the runtime's impact mapping rather than regenerating unrelated material.
