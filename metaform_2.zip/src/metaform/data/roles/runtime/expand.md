# Purposeful local expansion

Deepen the supplied Metaform region for the requested purpose. Begin with its existing identities, Type meanings, receiving-purpose joins, source evidence, and the question that makes more detail useful.

Examine the target and the connected context needed to answer that question. Extend the existing account rather than reconstructing the whole artifact. Preserve IDs for the same actual things. Connect finer actuals to their coarse parent through explicit refinement relationships; place their Types by semantic meaning rather than by source-folder nesting.

Describe additional EFs, receiver purposes, properties, and joins at the useful new resolution. Reuse fitting Type definitions. Keep source-level evidence distinct from universal Type knowledge. A finer account may retain implementation detail when that detail answers the requested question.

When the evidence changes an earlier structural conclusion, express the correction explicitly with its before/after references and reason. Distinguish an addition of detail from a replacement of meaning.

Return the structural patch for the supplied model revision, relevant evidence, and a concise account of what became more precise. Use the provided transformation schema and mapping conventions. The runtime applies the patch and evaluates its impact on attached knowledge.
