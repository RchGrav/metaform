# Structural semantics for artifact authoring

An artifact is the thing being understood. Its Defining Element is the representative composite whose combined result makes it that kind of thing. Begin with that result. The Defining Element expresses the function independently of its properties; represent all properties through their joins.

A Type supplies a reusable universal description and one Encounter Function. An actual Element is a particular thing in the artifact's account. An actual can participate in several Types while retaining one identity. Its Type bindings record which Types it participates in; how each Type is realized there is deep intake, not the base shape. The Type describes the artifact-level functionality or encounter, never the source methods, classes, file paths, document sections, or image regions that carry it.

Preserve the relationship `C(T) = { (r_i AND p_i AND e) }`: each receiver is paired with its own purpose and the Type's single EF. An OP join records that receiver, its purpose, the provider, and the provider Type whose EF it receives. `purpose` is the receiver's why; `signal` is how that purpose is satisfied in this meeting.

The join's role is receiver-relative: `hard dependency` is necessary for that receiving purpose; `property` supplies a property in that context; `supportive` contributes without being necessary for that purpose. The same provider can have different roles for different receivers. Type membership is a binding, not an invented OP join.

For an Element's own requirements, that Element becomes the receiver. Identify the capability/property it needs, its purpose for receiving it, and the provider whose Type EF satisfies it. Reuse the provider's identity when it is encountered again. Follow this purposeful frontier at the resolution needed for the current analysis.

Place a property at its applicable origin. It can be visible toward a Defining Element or namespace trunk while retaining its originating branch; that visibility does not apply it to unrelated siblings. A local installer property does not become a property of every actual sharing a broad Type.

Function and Encounter describe meaningful narrowing relationships in the typology. A Function identifies a more specific operative capability; an Encounter identifies a recognizable variant of a Type's function. Shallow intake records Functions only; Encounters belong to deep intake. Each namespace position still names a meaningful Type. A Type can participate differently relative to its parent and children.

Structural records describe the collected artifact. Additional advice, critique, and proposed changes are attached knowledge. Source evidence, reused input, and analysis activity remain traceable without turning their assessment metadata into the artifact's function.
