# Type namespace authoring

The Namespace narrows in specificity as it extends. Use the Type’s most common universal name, expressed as a singular proper noun, and reverse its words into period-separated components.

Locate the position in the existing Namespace that speaks to the Element at its most general specificity. This position may occur within a more specific path. Reuse the components through that position, then append the remaining modifier components that identify the Element in its full specificity.

Record the number of words in the full name as `length`, including reused components. Extract the proper name by reversing the final `length` Namespace components and joining them with spaces.

Define the Type with the most basic universal statement that uses ancestral proper nouns in reverse namespace order in a semantically proper statement, without naming or defining its child Encounters or Functions. The Type's description remains universal; the actual Element's particular account belongs to deep intake.

Every prefix must express a meaningful Type. Function and Encounter are narrowing semantics, not extra namespace trunks. `code.loop.main` and `code.engine.game` express functional Types. Language such as `code.cpp` does not: language is a method of defining functionality, not a functional aspect. Genre such as `code.game.platformer` does not: genre is not function. Classifier scaffolding such as `code.language.cpp` or `code.game.genre.platformer` is a taxonomy and is banned. Encodings alone are not Types; an encoder or decoder can supply a function.

Preserve the established bases `code`, `document`, `media`, `data`, and `exterior`, and the established `ext` alias. Exterior means outside the project; external to a functionality but still in the repository is a different boundary. Preserve explicit root labels and the maintained exterior naming exception.

Namespace components use the maintained singular alphanumeric naming rules. A Type's compact `parametric_elements` array names its tunable qualities/quantities at that Type; a value adjustment alone does not establish that a receiver's purpose has been satisfied. Use the supplied alias rules to resolve alternate names and avoid duplicate Type identities.

For example, Network Driver belongs at `code.system.driver.network` with `length: 2` when `code.system.driver.video` already exists. Reuse the meaningful Driver position rather than appending Network beneath Video Driver.
