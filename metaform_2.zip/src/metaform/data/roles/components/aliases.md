# Aliases

Aliases are required semantic runs of the namespace.

They must be preserved because they teach the distinction between the type and alternate names for that type.

All **metatype records** contain an `aliases` array. The purpose of this array is to prevent duplicates and ease searching.

## C

```text
code.c
code.c.c11
code.c.11                <- alias
```

## C++

```text
code.cpp
code.cc                  <- alias
code.cxx                 <- alias
code.cplusplus           <- alias
```

## C++11

```text
code.cpp.cxx11
code.cpp.cpp11           <- alias
code.cpp.11              <- alias
```

The alias forms do not replace or restructure the typology represented by the primary path.

## Intake clarification — 2026-09-08

Rich's supplied clarification:

> you also need the alias array, for the leaf (last word in the schema)   the most basic universal aliases that would likely be searched last part of the name space in alphanumric only, the purpose is to eliminate double entry and ease searching the name space they block those aliases from being used by other elements

> yes names can be reused they only reserve them at that specific address

---
