# Knowledge attached to a Metaform

The supplied foundation records the artifact's actual Elements, reusable Types, Type bindings, narrowing/refinement relationships, and receiver-owned OP joins. A join means that this receiver receives this provider Type's Encounter Function for this operative purpose. A Type has one EF; an actual may realize several Types.

A knowledge layer adds the knowledge requested by the user to that foundation. Its subject can be an actual, Type, join, or region. A universal Type-level statement can be reused through relevant Type bindings; an actual- or join-specific statement retains that scope. Connectedness alone does not make a statement apply everywhere.

Keep origin and applicability distinct. A layer statement may reach an actual through its Type, while still originating in that layer. A property visible at a trunk from one branch does not thereby apply to its siblings. Explain a relevant path using the supplied relation references and its meaning.

The generating request, supplied context, selected schema, resolved targets, and producing activity are retained as provenance. State conclusions as knowledge about the supplied subject, with their basis and relevant qualifications. A proposed change remains a proposed change until it is applied to the structural foundation.
