Review the supplied Element records and their Namespace classifications against the semantic rules. `new_type_ids` identifies new Namespace entries for classification review; `handoff_ids` identifies records requested for Latent preparation. Native records describe the actual artifacts, their functions, and their specific receiving purposes.

Correct Namespace classifications where needed while preserving the actual Element's meaning and functional context. The Type classifies the artifact; the Native description records the artifact being examined. Preserve its receiving purposes and relationships throughout preparation.

Return an object with `elements` containing corrected Element Table records, keyed by their resulting Namespace, and `renames` mapping any original Namespace to its corrected Namespace. Unchanged objects may be omitted. Namespace corrections retain the authored purposes and logic of the relationships referring to those Elements.

Place the requested records in `archaeology_objects`, keyed by their resulting Namespace. Retain their names, descriptions, functions, aliases, notes, receiving purposes, and other schema-governed contents with their meaning intact. These records participate in the whole Native structure supplied for Latent examination, including the OP joins and functional context that explain their relationships.

Place the supplied schemas in `archaeology_schemas`, keyed by schema ID. Return each full bundled schema, including its referenced definitions, preserving its constraints and the meaning of its annotations.
