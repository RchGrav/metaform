> **Historical core source.** The dual-pass and project-stripped categorical framing below predates the current Native foundation and attached-knowledge contract. Current semantics are defined by the project SPEC and the versioned role components. This source is retained for provenance; its historical authority statements do not override that current contract.

# Metaform

## Authority and scope

This Core defines Metaform's ontology, the meaning of the Inference Metaform, the authority boundaries of inference storage, and the relationship between Intake and later operational work. **Metaform Intake** governs the detailed dual-pass Intake procedure. Subordinate chassis and module contracts may define mechanics, schemas, commands, and storage access, but they do not redefine the canonical terms or the Intake process stated here.

A capable agent can know how to do the work and still spend a large part of its reasoning resolving what the work is talking about. General workflows have to speak broadly. They say things such as "the Artifact," "the mechanism," "the component," or "the Receiving Entity." When those references reach an unfamiliar project unresolved, the working agent must first decide what each one means there. A plausible early interpretation can look correct, change how the next instruction is read, and carry forward until the visible failure is far removed from the inference that caused it.

Metaform changes the shape and location of that inference. Metaform is an **Inference Metaform Modeler**, abbreviated **IMM**. It begins with the concrete workpiece, abstracts from the workpiece to the broad categorical Types and relationships that describe it, removes the project from the categorical investigation, and commissions independent inference against those Types. The resulting categorical records and relationships are then merged with the project-native relationship shape to form an **Inference Metaform**.

The "meta" is the reversal of perspective. The workpiece is used to identify the Types that matter; the Types are then investigated without the workpiece; the resulting Type-shaped inference is later applied back to work on the concrete Artifact. Metaform does not store a larger description of the project and call that inference. It stores independently reusable categorical shapes that can be selected and composed around a project when an operation needs them.

A general workflow may need to refer to the mechanism through which input reaches a Receiving Entity. When the relevant Artifact Type is a game's control scheme, Metaform can have independently inferred categorical information describing its Elements, single Encounter Function, Receiving Entity → Operative Purpose links, dependencies, and joins. The project-native graph separately records how those Types actually participate in the repository. Metaform can then lexicalize the general workflow from the merged Inference Metaform. Lexicalization is not simple token replacement: the selected Element Names, Element Descriptions, each Type's Encounter Function, Receiving Entity → Operative Purpose links, participant relationships, and join logic may materially change the instruction presented to an agent while preserving the workflow's intent.

The innovation is not a larger rulebook. Artifact Type identity and structure are expressed through relational shape rather than through a frozen inventory of implementation properties. The graph stays coarse enough to preserve useful categorical structure without flooding later contexts with exhaustive implementation detail. Changing the focal Element changes the Type under investigation and therefore changes the inference frame without requiring the originating project to accompany that shift.

Categorical inference stays exact to its focal Artifact Type. A game engine does not become C++ merely because one project implements it in C++. `code.cpp` can be investigated as its own reusable Artifact Type, while the repository-native graph records that a particular project's game engine uses it. The merged graph can use both bodies of inference without writing a project-specific fact into either global Artifact Type record.

Metaform does not change model weights, and it does not decide workpiece uncertainty in advance. It amortizes inference by separating the workpiece-born typology from project-blind latent inference, preserving both relational shapes, and using their merged Inference Metaform to lexicalize later workflows and prompts without asking every operational agent to reconstruct the same categorical structure from the workpiece.

---

## The problem

An agent wastes useful reasoning when it must rediscover the same categorical structure every time it performs a task: which Artifact Type is focal, what its major Elements are, how those Elements participate, which EFs belong to those Types and which OP relationships connect them, and how a workflow should speak about those relationships.

That reconstruction is expensive because it occurs while project files, defects, implementation choices, local terminology, current constraints, and the user's immediate goal already occupy the context. The project is useful evidence for the current operation, but it also biases any attempt to infer what is generally true of the Type itself.

Retrieval can return potentially relevant material. It does not by itself establish the Type shape of the workpiece, distinguish project-native relationships from reusable categorical relationships, or determine how a general workflow should be lexicalized from both.

A code scaffold does not solve this either. A scaffold exposes files and arrangements. It does not supply categorical inference for the Types represented by those files.

Metaform separates these jobs. An agent inside the repository abstracts the workpiece into a coarse functional typology and project-native relationship graph. Separate latent inference then examines each requested Artifact Type without the repository or its local joins. The two shapes can be compared and merged only after the independent categorical inference exists.

## Inference amortization

Inference cost is the amount of reasoning capacity consumed during an operation. It is not limited to token price, processing cost, or elapsed time.

**Metaform amortizes inference by building reusable categorical Type shapes outside the project context and later combining them with the project's own relationship shape when an operation needs them.**

The project-facing pass spends inference to identify what the workpiece is broadly made of and how those Types participate in this repository. Latent inference spends inference separately to understand those Types as Types. Later work can reuse the result instead of reconstructing both shapes while performing the current operation.

Inference has been amortized when later work can use an existing Inference Metaform without repeating the categorical investigation, while the operational agent remains free to respond to project evidence that differs from the categorical form.

Work can happen without completed categorical inference. That work is not receiving Metaform's inference-amortization benefit. The benefit begins after the Artifact Type records, major Elements, and joins required by the later operation are available.

## Master Glossary

This block is canonical prefix data for Metaform prompts that perform typology or latent inference. It is included in the prefix sent to both the Native Expert and the Latent Expert. The terms are operating context for model inference, not decorative documentation.

* **Element:** A thing that is capable of being named, identified, or worthy of note. A who or what that is internal or external and tied to an Artifact Type, including the Artifact Type itself. Elements include components, relationships, settings, quantities, qualities, subparts, Receiving Entities, functions, purposes, encounters, joins, signals, and procedures.
* **AT: Artifact Type:** A coarse graph object consisting of structural shape that describes the shared properties of an Element's type, establishing the structural criteria for an Inference Metaform model. These properties create a metaform of the workpiece type that can amortize inference by lexicalizing workflows and converting abstract concepts into imperatives that live in a reified knowledge hypergraph structure.
* **DT: Digital Typology:** Describes the expert process of arranging the Elements of a workpiece into a graph of nodes and edges, where encounter joins style and function joins purpose, creating one of the two layers of an Inference Metaform.
* **RE: Receiving Entity (The "Who" or "What" bearing an OP):** The person, group, system, component, or other participant with an Operative Purpose for the Encounter Function of an Element when classifying its typology as an Artifact Type. A Receiving Entity can be internal or external to the Artifact.
* **EF: Encounter Function (The "How" Description):** The mechanism, interface, relationship, or method through which an Artifact or Element performs its purpose for its Receiving Entity. It explains how the effect is delivered, encountered, used, or experienced.
* **OP: Operative Purpose (The "Why" Join):** The objective, value, or intended effect that drives an Artifact or Element's function for its Receiving Entity. It explains why the Artifact or Element exists at the level currently being examined.
* **ET: Element Table:** A table keyed by ID (namespace string), with fields for `entity_desc`, `entity_schema`, and `entity_json_obj`.
* **ED: Element Description:** The most common and concise description of an Element when examined as its Artifact Type. This is not decorative; it is used for inference.
* **EN: Element Name:** The most common and concise name of an Element when examined as its Artifact Type. This is not decorative; it is used for inference.
* **NS: Namespace Scope (Only Alpha and Periods):** The unique scope of all Elements, excluding Elements that answer to who, Parametric Elements, and the actual reified joins. The four base valid types are `code`, `document`, `media`, and `data`.
* **DE: Defining Element:** An Element that is named and abstracted into an Artifact Type and then analyzed by the Latent Expert, whose job is to analyze its Type's identity, Operative Purpose, Encounter Function, and Receiving Entity.
* **NE: Notable Element:** An internal Element with its own boundaries and surfaces for change. It carries the identity of an internal subsystem, but it does not carry the identity of the root Artifact Type. It is named because Elements address it or because it is a dependency of other Elements.
* **PE: Parametric Element:** A quality or quantity that can be tuned by changing a value. It does not have a specific named identity in individual Artifacts of that Type. It lives in a simple array and uses a one-word or `snake_case` name.
* **SE: Stylistic Element:** An Element that imbues a distinctive nature that groups others in the class or Type that share this quality. SE does more than describe function; it tangibly changes the encounter of Elements it is joined with, and that effect permeates all the way through to the Operative Purpose of the upstream Receiving Entity beyond the Element it is directly joined with. Genre is like this.
* **Native Expert:** A task-focused agent purpose born in a project folder for the sole purpose of mapping its relational, functional, and stylistic typology. It identifies the project's Defining Element and describes the functional Elements at the Type level, whether implemented in the project or supplied by a framework. It does so by constructing a coarse yet precise graph starting with the DE's NS, EN, ED, and OP joins to receive the EF provided by a linked element. The Native Expert must add an OP join to satisfy each dependency one at a time. To do so the Native Expert must determine if the NS of the element already exists by filtering the object list using Metaform CLI or MCP, then dumping the info of candidates. If no match is found, it authors a new, local NS object, completes its EN, ED, and optionally one or two aliases only if warranted. When complete it may join SE where needed with a transitive join that will travel through to the DE.
* **Latent Expert:** An expert typology agent who receives the Native Expert's objects one at a time without any OP, who works through the same procedure as the Native Expert using pure inference without knowledge of the project. When complete the two graphs are merged by matching the NS with fields indicating the source of every OP and the resulting reified knowledge hypergraph is populated deterministically as the Inference Metaform layer of the project-specific `metaform.kg` SQLite3 file.
* **Inference Metaform:** A pliable non-manifold triangle mesh comprised of a double blind semantic structure that acts as a navigation layer of a reified knowledge hypergraph enabling contextual join rubrics for thresholds and conditions to control agentic workflows, meaning expansion via metaform prompting imperatives, project targeted imperatives and knowledge extraction via unbiased inference, unlocking advanced refactoring capabilities, porting projects from one language to another, creating photo processing pipelines, written story structure analysis, enhancing agent creativity, enforcing operation completeness, and more. (That's only what we have tested!)

## Artifacts and Artifact Types

An **Artifact** is the concrete workpiece currently being examined, revised, generated, or otherwise acted upon. An **Artifact Type** is the coarse categorical graph object used to describe the structural shape shared by Elements of that Type. The two are not interchangeable.

A workpiece can cause one or more Artifact Types to be requested. The workpiece is used by the project-facing typology pass to determine which Types and local relationships are relevant. The workpiece itself is not passed into isolated latent inference.

Project-specific implementation facts, defects, architecture, history, current user guidance, and repository-local joins do not become categorical Artifact Type inference merely because they were visible when the Type was requested.

Artifact Type records are intentionally coarse. Their purpose is not to reproduce the implementation at another level of abstraction. They contain enough structural shape to support later inference, relationship reasoning, lexicalization, workflow selection, and further focal investigation without exhausting context on recursively enumerated detail.

## Artifact Type identity

Artifact Type identity is represented through one Encounter Function for the Artifact Type and the complete set of Receiving Entity and Operative Purpose relationships carried by OP joins to that Encounter Function.

For Artifact Type \(T\), let \(EF_T\) be the one canonical Encounter Function recorded for the Type:

$$
C(T)=\{c_1,c_2,\ldots,c_n\}
$$

Each \(c_i\) is one canonical conjunction:

$$
(\text{Receiving Entity}_i, EF_T, \text{Operative Purpose}_i)
$$

Each conjunction forms one functional triangle in the Inference Metaform: the Receiving Entity, the Operative Purpose it bears, and the Encounter Function provided by the linked Element. A Namespace-scoped Element can participate in multiple such triangles. Naming preserves the reusable identity of the Element while the repeated RE–OP–EF shape preserves its functional relationships without forcing the graph into a fixed hierarchy.

The complete set forms the identity shape. The Encounter Function belongs to the Artifact Type object and is named once. Each OP join names the Receiving Entity that bears the OP and the linked Element whose EF that OP is for; the EF is not duplicated on the join. When a Receiving Entity is another Namespace-scoped Artifact Type, the OP join also provides the directed graph relationship from the receiver Type to the EF-owning Type. The Artifact Type may participate in several OP joins when each Receiving Entity has a meaningfully distinct, nameable Operative Purpose for that same Encounter Function.

When several apparent Receiving Entities do not have significantly different or independently nameable Operative Purposes, inference uses the most specific general Receiving Entity that represents them together. They describe the same Type relationship rather than several separate ones.

### Candidate reuse and canonical naming

The Native Expert uses the Namespace, EN, ED, and EF to find the shortest existing categorical Type that fits its inference. It performs one Namespace search through Metaform CLI or MCP. Metaform resolves that search across the project-local and global Namespace stores and returns one candidate set; the Native Expert does not search the two stores separately. The Native Expert dumps the candidate information needed to compare their meanings. Existing records are reused when their names, descriptions, and Encounter Function describe the Type the Native Expert is trying to name. A mismatch does not cause the workpiece to fail; the Native Expert continues searching or authors a new local Namespace Scope that fits the inferred Type.

This lookup is semantic reasoning rather than exact string equality. EN and ED are deliberately concise because they are used to orient later agents and to discriminate nearby categorical Types. EF is part of the check because two similarly named Types can differ materially in how they function or are encountered. A newly authored Namespace object is created locally first; its later addition to the global knowledge graph is a Metaform system step rather than a second search or a direct global write by the Native Expert.

OP relationships observed in the repository are not used to make the project-blind Latent Expert conform its inference to the project. They remain in the native typology layer until the independent latent inference layer is available.

### Identity-preserving mutation

Let:

$$
E:A\rightarrow\mathcal{C}
$$

be the identity encoder over Artifact realizations, resolving each realization to its categorical Artifact Type identity shape.

For mutation \(\mu\), same-Type identity is preserved when:

$$
E(\mu(a))=E(a)
$$

or equivalently:

$$
E\circ\mu=E
$$

over the operative domain.

Mutation may change local realization while preserving the categorical relationship shape. Metaform does not need a list of immutable implementation properties to preserve that Type identity.

### Parametric changes and task completion

A Parametric Element can change while the Artifact remains the same Type. Whether changing only a parameter fulfills a current operation is decided by that operation, its workflow, and the user. A parametric change does not by itself create another independently named Artifact Type.

## Element participation and focal perspective

The Master Glossary establishes the Element concepts. Typology and latent inference determine how those Elements participate in the focal Artifact Type.

Metaform deliberately avoids exhaustive recursive enumeration. The useful unit is a major Element whose presence, function, encounter, dependency, purpose, or stylistic effect changes how the focal Type should be understood.

A **Defining Element** is coarse enough and independently meaningful enough to warrant its own Artifact Type investigation. Once named, it becomes a new focal Type for latent inference. The new investigation does not receive the repository that caused the Element to be identified.

A **Notable Element** remains internal to the current focal Type. It has boundaries and surfaces for change and may be referenced by other Elements, but its current role does not require a separate categorical investigation merely because it is noteworthy.

A **Parametric Element** is a tunable quality or quantity. It remains compact and does not recursively expand into another Type merely because its value can change.

A **Stylistic Element** affects encounter rather than merely describing function. Genre, style, constructional character, or another distinctive nature can alter the encounter of the Element it is joined with and influence an upstream Receiving Entity's Operative Purpose. A Stylistic Element can therefore contribute real graph semantics without replacing the base functional Type of the project.

### Coarse expansion rule

The Native Expert expands the project typology only while another useful relationship is exposed.

Being addressed by another Element or satisfying a dependency does not by itself make an Element Defining. A Notable Element can be named because Elements address it or because it is a dependency of other Elements while remaining internal to the root Artifact Type. An Element is Defining when it is named and abstracted into an Artifact Type for independent latent inference. Parametric Elements remain compact rather than expanding into their own Namespace objects.

This is a granularity rule for constructing a useful graph, not a semantic quality gate. The objective is to preserve enough structure for later inference while preventing the graph from being flooded with every implementation part that can be named.

### Focal perspective

Reasoning over the graph is perspectival. For a focal Element \(v\), Metaform treats \(v\) as the Artifact Type under investigation. The Element's own categorical relationships establish that frame. Moving focus to a Defining Element changes the focal Type without carrying the originating project's local joins into the latent inference pass.

The stored categorical record does not change when focal perspective changes. What changes is which record supplies the root of the current investigation.

EN, ED, EF, OP, Element participation, and join logic are operational inference. None is decorative.

## Namespace

The Namespace is the categorical addressing surface used to identify reusable Elements that receive Namespace Scope.

### Four base scopes

The Namespace begins with four base valid Types:

1. `code`
2. `document`
3. `media`
4. `data`

The Native Expert begins by deciding which of these broad Types best describes the workpiece. It then attaches one or more modifiers only as needed to express the shortest common categorical Type that fits the inference.

Examples:

```text
code
code.game
code.game.engine
code.cpp

document
document.letter

media
media.image

data
data.schema
```

Bad inference:

```text
code.language.*          <- not valid
```

The [Programming Language rule](../../../../docs/semantics/inference_metaform_rules.md#programming-language)
states:

> `code.language` does not qualify because `code` refers to types of languages. `language` in the namespace is evoking class: a space filler to ensure alignment in the taxonomy namespace.

Namespace scopes use alphabetic terms separated only by periods. The Native Expert prefers the most common, simplest Element terms and tunes for the shortest scope that accurately names the Type.

The Namespace is interpreted, not parsed into Domain, Class, Type, Variant, or Element positions. Tooling parses dots for browsing and filtering. The model interprets the complete address and its modifiers as categorical language.

### Namespace placement

Placement contributes context to later inference. `code.game.engine` is investigated as an engine, of a game, in code. The shortest fitting scope is preferred because every additional modifier should contribute meaningful categorical information rather than incidental project detail.

The Native Expert checks whether a selected scope already exists through the single Metaform Namespace search surface. That surface composes project-local and global Namespace objects before returning candidates. If an existing record's EN, ED, and EF fit the intended Type, the Native Expert reuses that record. If they materially mismatch, the Native Expert continues searching or authors a new local scope that fits the inference.

A more specific scope is not chosen merely because a genre, mood, style, or other sense strongly describes the current project. The base functional Type remains as general as it can while still being accurate. A separately useful Stylistic Element can be named and joined after the functional typology is established.

### Namespace context

Dots establish deterministic browsing boundaries and contribute categorical context. Parent records remain independently stored; they are not copied into descendants merely because their addresses share a prefix.

Namespace placement can be exposed to latent inference and later operations when that context is useful. Namespace ancestry alone does not establish Element participation. Native and categorical relationships establish how independently named Types participate together.

### Discovery

Namespace tooling can browse exact scopes and wildcard neighborhoods. Metaform CLI and MCP expose one composed search over project-local and global Namespace objects; storage location is resolved by Metaform rather than by the reasoning agent. `*` can be used within a scope or at the end of a query to discover candidate Types. Wildcards are query syntax; they do not change the ontology or create records.

Literal Namespace lookup and relationship-category projection remain distinct operations. A presentation can show a shorthand such as `code.game.elements`, but the underlying query identifies `code.game` as the focal Type and `elements` as the requested projection so a legitimate free-form scope is not reinterpreted as an operator.

## Knowledge graph

Metaform stores reusable categorical inference in a heterogeneous reified knowledge hypergraph. The graph is built from independently addressable Artifact Type records, local Element structures, Receiving Entities, Parametric Elements, explicit joins, and other schema-governed reusable records.

The graph does not store the workpiece as an Artifact Type. Project-specific relationships are represented in the repository-native layer and repository-local joins.

### Native typology layer

The Native Expert operates inside the repository and creates the project's **Digital Typology**. This is the project-native layer of the later Inference Metaform.

The Native Expert:

1. chooses one of the four base Types;
2. adds the shortest common modifiers needed to name the base functional Artifact Type;
3. searches the composed project-local and global Namespace through Metaform CLI or MCP and dumps candidate information;
4. reuses an existing Namespace record when its EN, ED, and EF fit, or authors a new local Namespace object with NS, EN, ED, and optionally one or two aliases when no candidate fits;
5. lists major Elements in the coarsest useful sense;
6. adds one project-native OP join at a time to satisfy each dependency by receiving the EF provided by the linked Element;
7. shifts focus through the Elements required by the typology while distinguishing Defining, Notable, Parametric, and Stylistic roles according to the Master Glossary;
8. stores Parametric Elements compactly; and
9. optionally names a Stylistic Element when genre, mood, style, constructional character, or another sense materially changes encounter and improves the project's typology.

Every Namespace object has EN and ED. The local Element listing names participating IDs and records the project-native OP relationships. Together those node descriptions and project-local OP edges form the repository's native graph.

New Namespace objects are authored only in the local Intake layer. After the native pass completes, Metaform adds those Namespace objects from local to the global Element Table while omitting the native project-native OP relationships. This centralizes creation in the local pass while making the reusable named nodes available through the same composed Namespace search surface.

The native OP graph describes what is true of this repository. Promoting the node does not promote the repository's OP relationships.

### latent inference layer

The Latent Expert is blind to the repository and blind to the repository-native joins produced by Digital Typology.

The Latent Expert receives the native objects one at a time with the native OP relationships removed. The object retains its NS, EN, ED, aliases when present, schema-governed node data, and any other non-OP fields. It does not receive the project that caused the object to be named, repository files, or the project-native OP edges. The global Namespace remains available through Metaform CLI or MCP so the Latent Expert can reuse existing objects while applying the same typological procedure as the Native Expert through pure inference.

The Latent Expert investigates each object as an Artifact Type in isolation. It builds the Type's one Encounter Function, independently authors its own Receiving Entity → Operative Purpose joins, and infers major dependencies, required Elements, and structural considerations. It uses existing Namespace objects when they fit and names new categorical Elements only when required by the typological procedure.

The Latent Expert can walk categorical structure back toward the four base Types and outward through required Elements. Existing inference is reused rather than repeated. Each newly required Defining Element becomes focal in its own isolated investigation.

Latent inference remains coarse. Its question is not "what could possibly be part of this Type?" but "what would an expert need to define or account for to understand this Type?" It stops before exhaustive implementation detail floods the graph.

### Ordinary edges

An ordinary edge connects two graph participants when the relationship can be fully expressed between those participants without needing a separate relationship object.

### Reified joins

When a relationship carries multiple participants, distinct OP perspectives, roles, conditions, evidence, purpose, or join logic, Metaform represents the relationship as a reified join.

The graph preserves three relationship layers:

1. **native joins** — project-origin relationships produced by Digital Typology;
2. **archaeology joins** — independent categorical relationships inferred without the project; and
3. **merged joins** — repository-composed relationships in which the native and latent inference shapes refer to the same participating Elements and both OP statements are retained rather than flattened into one.

The origin of each relationship remains attributable. A merged join does not erase the project-native OP or the independently inferred OP. When the two perspectives differ, the difference is information available to later reasoning.

Relationship categories can be constrained by the schema that owns them when an enum materially improves deterministic querying. OP joins, Element participation, dependency, Stylistic participation, Namespace relationships, and other established categories can therefore be queried without converting semantic purpose or join logic into closed text.

The EF belongs to the Artifact Type object and is not repeated on an OP join. Each OP join independently names the Receiving Entity bearing the OP and the linked Element whose EF that OP is for. The Native Expert and Latent Expert each author their own OP joins in their own inference layer. When a Receiving Entity is another Namespace-scoped Artifact Type, the OP join projects to a directed AT-to-AT graph edge while resolving the EF from the linked object.

Purpose, participant meaning, and join logic remain semantic inference. They are not decorative labels.

### Global and repository-local authority

Digital Typology produces repository-native OP joins and can author new Namespace objects locally. Metaform promotes those newly authored Namespace objects to the global Element Table with their native OP joins removed from the promoted copy. Latent inference independently authors reusable global OP joins and adds categorical EF, dependency, Element, and other schema-assigned inference. Merged relationships belong to the repository composition because they describe how the project's native shape and global categorical shape meet.

A project-native relationship does not modify a global Artifact Type record. A later repository can reuse the same categorical Type and produce a different native relationship shape.

### Schema-bounded inference

A schema and inference purpose define what an latent inference pass is assigned to infer. The fact that a model could infer more fields is not sufficient reason to collect them.

The graph seeks major reusable inference. Additional inference belongs in another explicitly defined operation, another focal Artifact Type, or the current workpiece rather than being added merely because it is available.

## Inference Metaform

An **Inference Metaform** is the project's pliable non-manifold semantic mesh produced by composing Digital Typology with independent latent inference. Its functional geometry is carried by the Element relationships in which a Receiving Entity bears an Operative Purpose for the Encounter Function provided by a linked Element. The two inference perspectives remain isolated until Metaform merges them by Namespace Scope and preserves the source of each OP.

It contains the shape needed for inference: concise categorical descriptions, major dependencies, the single Encounter Function recorded on each Artifact Type, independent RE → OP relationships, project-native Operative Purpose relationships, Receiving Entities where applicable, Element participation, stylistic encounter effects, and the joins that explain how those perspectives relate.

The Inference Metaform is not the workpiece and is not a project scaffold. It does not prescribe files, classes, physical arrangement, architecture, or an inventory of allowed mutations. It records a coarse relational shape from which later agents can infer more effectively about the concrete project.

The two source layers remain distinguishable inside the merged form. The native layer says how the repository describes its own participating Types. The latent inference layer says what independent expert inference says about each Type without knowing this repository. Merged joins let later reasoning see where those perspectives coincide, supplement one another, or differ.

The Inference Metaform is therefore more than retrieved knowledge and less than a model of the project. It is a reusable metaprompt ingredient: a Type-shaped graph that Metaform can select from when constructing operational context.

### Lexicalization

Metaform can lexicalize a workflow or task prompt from the selected Inference Metaform.

Lexicalization can replace unresolved abstract references with EN and ED, express which EF is relevant, identify the OP being acted on, name the applicable RE, state project-native and categorical relationships, and include join logic needed by the task.

The selected inference can materially reshape an instruction. The constraint is not that the words remain similar; the workflow's intent remains the same.

Inference amortization and the Inference Metaform are separate concepts. The Inference Metaform is the reusable relational form. Inference amortization is the benefit obtained when later agents use that form rather than repeating the categorical investigation while working on the project.

## Intake

Intake establishes the project-native typology, commissions missing categorical latent inference, and makes the resulting Inference Metaform available to the repository.

Intake has two deliberately different inference contexts.

### Native Expert

The **Native Expert** is the project-facing agent. It is autochthonous because it operates from inside the repository context and begins from what the workpiece actually is.

Its task is Digital Typology, not global categorical definition.

The Native Expert can inspect the repository as deeply as needed to understand the project, but its graph output remains coarse. It abstracts outward from concrete implementation to the broad categories and relationships that later categorical investigation should amortize.

It begins with `code`, `document`, `media`, or `data`, then attaches the smallest common modifiers needed to name the project's base functional Type. It prefers the shortest Namespace and most common Element terms that accurately express the Type.

For each selected scope it performs one search through Metaform CLI or MCP. Metaform composes project-local and global Namespace objects into the returned candidate set. EN, ED, and EF orient reuse. A fitting existing Type is reused; a mismatched Type is not rewritten to fit the project. When no candidate fits, the Native Expert authors the new Namespace object locally with NS, EN, ED, and optionally one or two aliases.

The agent then identifies major Elements in both relationship directions:

- Elements whose EF serves an OP of the focal Element; and
- Elements whose OP depends on the EF of the focal Element.

It shifts focus to independently useful Elements and repeats the process only while additional external functional relationships justify another Type. Elements without such outward relationships can remain internal or Notable instead of becoming whole new categorical records. Parametric qualities remain PE values rather than graph expansion.

After the functional typology is established, the Native Expert may name a Stylistic Element that better describes the project's genre, mood, style, constructional character, or another non-functional sense. Its encounter can be joined so that its effect participates in the OP of the upstream Receiving Entity without replacing the project's base functional Type.

Every node the native graph names receives EN and ED. Every relationship entry identifies the participating Element and the short project-native OP describing why the relationship exists for this repository.

The Native Expert's structured node objects and native OP graph originate locally. After the pass, Metaform copies newly authored Namespace objects into the global Element Table without their native OP relationships. The native OP relationships remain project-origin data and are later merged with latent inference in the project-specific Inference Metaform.

### Latent Expert

The **Latent Expert** performs isolated categorical inference.

For each requested Artifact Type, the Latent Expert receives:

- the complete Master Glossary prefix;
- one native object at a time;
- that object's NS, EN, ED, optional aliases, and other non-OP schema fields;
- the applicable Artifact Type schema and inference purpose; and
- access through Metaform CLI or MCP to the composed Namespace for reusable objects.

Before the handoff, Metaform removes the native OP relationships from the object. It does **not** remove EN or ED.

The Latent Expert does **not** receive:

- the repository;
- repository files or implementation details;
- the repository-native join table;
- the Native Expert's project-specific prose beyond the structured non-OP object fields; or
- the project-native OP edges that caused the Type to participate in this repository.

The Latent Expert independently infers the focal Type's one EF and its own RE → OP relationships for that EF. It identifies major Elements, dependencies, Receiving Entities, internal Notable Elements, Parametric Elements, and any other schema-assigned categorical structure required to understand that exact Type.

When another independently useful Element is required, the Latent Expert reuses an existing Namespace record or names a new one in the most general specific manner that fits the categorical inference. That Element becomes another Artifact Type investigation. The originating project remains absent.

The Latent Expert works backward through categorical scope as needed until the root context is established and outward through major required Elements until further expansion ceases to add independently useful functional structure.

### Merge

After required latent inference exists, Metaform combines the native typology with the categorical graph.

The merge preserves provenance and does not collapse the two inference sources.

A native relationship remains a native relationship. An latent inference relationship remains an independent categorical relationship. The merge aligns the independently authored native and latent OP joins by Receiving Entity, EF-owning Artifact Type, and relationship category when the schema distinguishes one. For a Namespace-scoped receiver, this is the directed relationship from the receiver Artifact Type to the Artifact Type whose single EF that OP is for. When the same directed relationship exists in both layers, Metaform creates a merged relationship in addition to retaining both source OP joins. The merged relationship retains both OP statements and where each originated; it does not replace either source join.

The target EF remains on its Artifact Type object and is never copied into the merged relationship. Other relationship categories retain the same source-layer provenance without being treated as OP links.

The result is the repository's Inference Metaform.

### Intake output

Intake establishes or requests:

- the base functional Artifact Type;
- the shortest fitting Namespace Scope;
- EN and ED for every independently named node;
- the project-native Element relationships and short OP statements;
- newly authored local Namespace objects promoted by Metaform into the global Element Table without their native OP relationships;
- internal or Notable Elements that do not warrant separate categorical expansion;
- Parametric Elements stored compactly;
- optional Stylistic Elements whose encounter materially changes the project typology;
- Artifact Type requests for Defining Elements requiring independent latent inference;
- each latent inference-produced Artifact Type's one EF, its RE → OP relationships, dependencies, and major Elements;
- native, latent inference, and merged joins with attributable origin; and
- the merged Inference Metaform available to later operations.

No requested semantic field is decorative. EN, ED, EF, OP, RE, Element participation, join category, and join logic are all inputs to later model inference, graph queries, lexicalization, workflow construction, or execution prompting.

### What must already be true before workflows are specialized

Before an ontology-dependent workflow or prompt is lexicalized, the Artifact Type records and relationships required by that operation must be available.

The later operation receives selected inference, not an undifferentiated graph dump. The current workpiece remains the operational agent's evidence. The Inference Metaform supplies categorical and project-relational orientation around that evidence.

---

## Storage

Metaform stores categorical and repository-composed inference in SQLite knowledge-graph databases while JSON remains the schema-specific representation of each Element or Artifact Type record.

The storage model reflects the refined process directly:

- the **Element Table** stores independently addressable namespace-scoped records;
- each record's JSON object stores its own categorical structure and local Element listing;
- joins store relationships independently of object nesting; and
- repository databases can contain native, copied latent inference, and merged relationships without modifying global records.

### Storage roots

Metaform keeps reusable categorical inference in the global Metaform root and workpiece-specific composition in a workpiece-local inference database.

```text
~/.metaform/inference/metaform.kg
<repo>/.metaform/inference/metaform.kg
~/.metaform/inference/{encoded_filesystem_path}/metaform.kg
```

The first path is the global database. It contains reusable Namespace objects promoted from local Intake with their native OP relationships removed, together with latent inference-produced categorical inference and latent inference joins.

The second path is the repository-local database. It contains the global Namespace and categorical records required by that repository, their copied latent inference relationships, the Native Expert's native OP relationships, and merged joins that compose the two layers for the repository.

The third path is the non-repository workpiece-local database. It carries the same workpiece-specific authority as the repository-local database without mixing that workpiece's native or merged relationships into the global categorical database.

The `metaform.kg` databases are authoritative for the inference records and relationships assigned to them. Origin-local `metaform.db` remains authoritative for workflow execution state and module-owned runtime state. Neither store replaces the other.

### Element Table

The common independently addressable table is the **Element Table (ET)**.

Conceptually:

```text
ET[id] = {
    entity_desc,
    entity_schema,
    entity_json_obj
}
```

The `id` is the Namespace Scope string. `entity_desc` exposes the ED needed for fast lookup and orientation. `entity_schema` identifies the schema governing the JSON record. `entity_json_obj` contains the complete schema-specific object, including EN and the categorical fields assigned by that schema.

A compact SQLite representation is:

```sql
CREATE TABLE elements (
    id              TEXT PRIMARY KEY,
    entity_desc     TEXT NOT NULL,
    entity_schema   TEXT NOT NULL,
    entity_json_obj TEXT NOT NULL
);
```

This replaces the older generic `name / description / role / data` wrapper as the primary Core description because `role` is no longer a sufficient representation of the refined relational model. Role, function, encounter, purpose, and influence are expressed through the schema-specific JSON and joins instead of one generic string.

### Artifact Type JSON object

Every independently investigated Artifact Type has one JSON object under its Namespace ID.

The exact schema remains separately registered, but the Core requires the object to be capable of carrying:

- EN;
- ED;
- one EF for the Artifact Type;
- a coarse Element listing;
- internal or Notable Element information;
- Parametric Elements;
- applicable Stylistic Element information; and
- schema-specific provenance needed to attribute the inference.

Receiving Entity and Operative Purpose relationships are not embedded as a `receivers` field in the Artifact Type JSON object. The Native Expert and Latent Expert each author their own OP joins separately in their respective graph layers. When several candidate Receiving Entities would carry materially the same OP, inference uses the most specific general Receiving Entity rather than duplicating the same relationship under several names.

The `joins` listing holds other explicit relationships, such as Stylistic or dependency relationships, with their category, purpose, and join logic.

Conceptually:

```json
{
  "code.game.engine": {
    "en": "game engine",
    "ed": "code that runs a game's simulation, rendering, audio, and input each frame",
    "function": "run the game's active systems through a runtime loop",
    "joins": {
      "code.game.platformer": {
        "type": "stylistic",
        "purpose": "shape encounters toward run-and-jump play",
        "join_logic": "the platformer style changes the encounter of joined game Elements"
      }
    },
    "parametric_elements": [
      "fps",
      "tick_rate"
    ]
  }
}
```

The example shows shape, not a complete Artifact Type schema.

Notable Elements may receive their own Namespace Scope while remaining internal to the root Artifact Type and without becoming Defining or requiring an latent inference pass. Defining Elements are the Elements abstracted into Artifact Types for independent latent inference. Receiving Entities, Parametric Elements, and reified joins are excluded from Namespace Scope by the Master Glossary. Receiving Entities are represented through the OP joins in which they participate rather than through a special field on the Artifact Type object.

### Join records

The submitted Artifact Type JSON does not embed Receiving Entity or OP relationships. The Native Expert and Latent Expert each author their own OP joins separately from the Artifact Type object, and Metaform commits those joins with the source layer that produced them. When global latent inference inference is copied into a repository `metaform.kg`, its latent OP joins are copied intact beside the repository's native OP joins. A merged relationship is an additional repository composition and does not replace either source OP join. Namespace-scoped relationships can use the common projection below. A non-Namespace Receiving Entity is carried by the applicable schema-specific OP join rather than by a `receivers` field.

The common join projection carries:

```text
object_id
join_scope
element_id
type
purpose
schema_id
join_logic
```

For the refined process, `join_scope` records the relationship layer:

```text
native
archaeology
merged
```

`type` is the schema-governed relationship category used for deterministic filtering. It can distinguish Receiving Entity participation, Element participation, dependency, Stylistic participation, Namespace relationship, or another category established by the applicable schema.

For a Namespace-scoped OP join, `object_id` is the Receiving Entity Artifact Type bearing the OP and `element_id` is the Artifact Type whose EF that OP is for. `purpose` carries the concise OP statement. `join_logic` carries the reasoning required to interpret the relationship. The target EF is resolved from the linked Artifact Type object and is not duplicated in the relationship row. Other Namespace-scoped relationship categories use the same projection fields according to their own schema semantics.

A compact SQLite table is:

```sql
CREATE TABLE joins (
    object_id   TEXT NOT NULL,
    join_scope  TEXT NOT NULL,
    element_id  TEXT NOT NULL,
    type        TEXT NOT NULL,
    purpose     TEXT NOT NULL,
    schema_id   TEXT NOT NULL,
    join_logic  TEXT NOT NULL
);

CREATE INDEX joins_by_object
ON joins(object_id);

CREATE INDEX joins_by_element
ON joins(element_id);

CREATE INDEX joins_by_scope_type
ON joins(join_scope, type);
```

A reified join that needs more than the common projection is itself stored under its registered join schema. In particular, a repository-owned merged join retains both the native OP statement and the latent inference OP statement, together with their provenance, rather than choosing one as the canonical answer. Namespace node identity may be reusable globally after local promotion, and latent inference relationships are reusable global inference; the native OP statement and the merged composition remain repository-owned.

The common table remains the traversal and filtering surface. The schema-specific join object retains the fuller relationship semantics.

### Recursive graph assembly

Any independently addressable Artifact Type can be used as the starting point for graph resolution. Metaform loads the focal ET record, loads its incident joins, resolves the records at the other ends of those joins, and continues according to the query or operation being performed.

The loader tracks already loaded IDs. When several relationships reach the same record, that record is loaded once while all relationship paths remain present.

Cycles, reciprocal relationships, merged joins, and several paths to one Element are expected graph structure.

The in-memory graph therefore has three primary views:

```text
elements:
    id -> { entity_desc, entity_schema, entity_json_obj }

joins:
    relationship rows and reified join objects

adjacency:
    id -> incident relationships
```

### Repository graph assembly

Repository initialization begins from the base functional Artifact Type identified by Digital Typology.

Metaform resolves the required global Namespace objects and latent inference inference and copies the applicable records and latent OP joins into repository `metaform.kg`. The repository's native OP joins produced by the Native Expert remain present beside them. Metaform then creates merged joins where the native and latent inference relationship shapes meet.

The copied global records and latent OP joins retain their global origin. Native OP joins remain repository-owned. Merged joins are repository-owned compositions. None of these steps replaces either source OP join.

For example:

```text
Latent inference:
code.game.engine
    -> code.game.physics              [categorical OP for the physics EF]

Native repository:
code.game.engine
    -> code.game.physics              [this repository's OP for the physics EF]

Merged repository view:
code.game.engine
    -> code.game.physics              [both OP perspectives retained]

Repo-only dependency:
code.game.engine
    -> code.cpp        [this repository actually uses C++]
```

A repository can therefore have a project-shaped Inference Metaform without teaching the global engine Type that every engine is C++.

### Focal Inference Metaform view

A focal view selects only the records and joins required by the current operation.

For a focal Artifact Type `v`:

```text
Artifact Type under investigation: v
Categorical record: ET[v]
Native relationships: incident joins where join_scope = native
Latent inference relationships: incident joins where join_scope = archaeology
Merged relationships: incident joins where join_scope = merged
Elements: participants selected through Element relationship categories
Other context: relationship categories requested by the operation
```

The focal view does not infer Element participation merely because two records are connected.

### Relationship-category filtering

Because join `type` is schema-governed, graph consumers can deterministically request relationship projections without flattening semantic content.

Conceptually:

```python
def connected_by_category(graph, focal_id, relationship_types, scopes=None):
    result = []

    for join in graph.adjacency.get(focal_id, []):
        if join["type"] not in relationship_types:
            continue
        if scopes is not None and join["join_scope"] not in scopes:
            continue

        other_id = (
            join["element_id"] if join["object_id"] == focal_id else join["object_id"]
        )

        result.append(
            {
                "id": other_id,
                "element": graph.elements.get(other_id),
                "join": join,
            }
        )

    return result
```

The same graph supports literal Namespace lookup, wildcard discovery, category projections, native-versus-latent inference comparison, merged views, reachability, prompt construction, and workflow lexicalization.

### Export

A resolved graph can be exported without merging categorical records into project-native data.

Conceptually:

```json
{
  "elements": {
    "code.game.engine": {
      "entity_desc": "...",
      "entity_schema": "...",
      "entity_json_obj": {}
    }
  },
  "joins": [
    {
      "object_id": "code.game.engine",
      "join_scope": "merged",
      "element_id": "code.cpp",
      "type": "...",
      "purpose": "...",
      "schema_id": "...",
      "join_logic": "..."
    }
  ]
}
```

The ET key remains the Namespace ID. Join scope preserves whether a relationship originated in the native typology, latent inference, or the merge.

### Repository pinning and authority

Repository copies are pinned to the global categorical inference from which the repository Inference Metaform was assembled. A later global change does not silently rewrite the repository's native or merged relationships underneath it.

The global database is authoritative for reusable Namespace objects, latent inference-enriched categorical records, and latent inference joins. The repository database is authoritative for its copied global records, native OP joins, merged joins, and project-specific composition.

Repository-local relationships are not a back-channel into global categorical inference.

---

## Local operational reasoning

An operational agent works from a selected local view. It does not receive the entire knowledge hypergraph and does not repeat the Native Expert's Digital Typology or the Latent Expert's categorical investigation inside every task.

For the current operation, Metaform can supply the focal Artifact Type record, relevant EN and ED, selected Elements, each focal Type's EF and RE → OP relationships, native joins, latent inference joins, merged joins, procedures, rubrics, workflows, and other inference required by that assignment.

The operational agent still performs workpiece-specific reasoning. It examines the actual implementation, current evidence, user request, and current operating conditions. The Inference Metaform orients that reasoning; it does not replace it or predict the workpiece.

### Blind subagents and semantic handoff

Subagents are blind unless a workflow explicitly states otherwise.

When Metaform assigns blind work, the orchestrating agent is not the semantic prompt transport. Metaform prepares the engagement and supplies the assigned prompt and permitted inputs through the workflow mechanism. The orchestrator does not paraphrase hidden semantic context into the blind worker's assignment.

Only declared structured data crosses an agent or workflow-step boundary. Previous-agent prose does not become inherited context merely because it ran earlier.

## Prompt and agent construction

The Master Glossary is prefix data for the Native Expert and Latent Expert and for other model-facing Metaform prompts whose reasoning depends on these ontology terms.

No semantic field requested from those agents is decorative. The prompt tells the model that EN, ED, EF, OP, RE, Element classification, stylistic encounter, relationship category, purpose, and join logic are consumed by later inference and prompt construction.

Metaform constructs prompts and tasks in an agent-shaped form rather than as unrelated ad hoc strings. A common assignment can identify:

- the role performing the operation;
- the canonical glossary prefix;
- the focal Type or workpiece context;
- the exact source data available to the role;
- the context deliberately withheld;
- the operation purpose;
- the selected graph records and relationships;
- available tools or commands;
- structured inputs; and
- the required output shape.

A format shaper renders that assignment for each supported harness. When Metaform has an integration for a harness, it deterministically constructs the equivalent role/frontmatter/task shape that harness understands. In universal mode, Metaform expresses the same assignment instructively in the representation available to the receiving system.

Deterministic construction controls what context and mechanics reach the model. It does not make semantic inference deterministic.

## Workflow compilation

Metaform works through step-by-step workflows. Workflow compilation is one consumer of the Inference Metaform; it does not define the Inference Metaform itself.

### Specialization and lexicalization

Workflow JSON carries `intent` separately from the agent-facing `prompt`. Compilation can lexicalize the rendered prompt while preserving the step's intended work:

$$
Intent(C_M(s))=Intent(s)
$$

Metaform can specialize a general workflow by selecting:

- the focal Artifact Type record;
- relevant ancestor or related categorical records;
- native, latent inference, and merged relationships;
- EN and ED;
- major Elements;
- each selected Artifact Type's EF and Receiving Entity → OP links;
- Stylistic Elements and encounter effects where applicable;
- procedures and rubrics; and
- the current operation and user guidance.

Lexicalization is not simple token replacement. The selected Inference Metaform can materially reshape the instruction while preserving the operation's intent.

A workflow definition remains separate from the Artifact Type records and repository joins it uses. Graph associations and provenance identify the selected inference rather than copying the full graph into every workflow.

The executable workflow document remains governed by its registered workflow schema. Catalog metadata, graph associations, selected-inference provenance, and authoring records remain separate records unless that workflow schema is deliberately revised. They do not become undeclared workflow keys or copies of Artifact Type records.

### Execution

During execution, the specialized workflow is applied to the concrete workpiece and current conditions.

The working agent receives only the rendered instructions, permitted tools and commands, structured inputs, and selected inference relevant to its assignment. It does not have to reconstruct the same categorical graph before beginning the workpiece-specific operation.

### What is decided before execution

Metaform prepares inference already established by the selected categorical and repository-composed graph. It leaves decisions that depend on the current workpiece, current conditions, or unfolding work for the operational agent.

**Prepared when available in the Inference Metaform:**

- EN and ED;
- coarse Type structure;
- each selected Artifact Type's EF and Receiving Entity → OP links;
- applicable REs;
- major Elements;
- Parametric and Stylistic Element context when relevant;
- dependencies and relationship categories;
- native, latent inference, and merged join logic; and
- lexicalized workflow instructions derived from selected inference.

**Left to the working agent:**

- the workpiece's current contents and condition;
- the user's current goal;
- current environmental or operational limits;
- observations produced during the task;
- ambiguity that exists only in this instance; and
- decisions that depend on evidence produced as the task develops.

---

## Experience

Metaform accumulates experience by preserving categorical inference that can be reused after the current task and by preserving evidence about how that inference was used.

This can include better EN or ED wording, newly identified Defining Elements, corrected Encounter Functions, clearer Receiving Entity → Operative Purpose relationships, improved joins, useful procedures, workflow improvements, and evidence that a particular prompt or graph shape produced weak or strong operational results.

This process does not change model weights. It changes the inference and deterministic context available to later operations.

A Namespace object authored locally during Digital Typology is promoted to the global Element Table as reusable node identity with its native OP relationships removed. Repository-specific OP relationships and other facts about one workpiece remain repository-local. Latent inference supplies the reusable categorical functional inference that can be attached globally to those nodes.

Metaform can distinguish:

- a project-native observation;
- a project-native OP relationship;
- independently inferred latent inference;
- a merged relationship retaining both perspectives;
- categorical inference established for an exact Artifact Type; and
- later evidence about how those records performed in workflows or prompts.

Later self-targeting can use that evidence to revise the records, prompts, schemas, workflows, or mechanics to which the evidence actually applies.

## Paradigm

The current operating model is the **Paradigm**. It covers how Metaform abstracts from a workpiece, commissions independent Type inference, assembles an Inference Metaform, supplies that form to later operations, and keeps project-native and categorical knowledge distinct.

A material change to that operating concept is a **Paradigm Shift**. New categorical knowledge or a corrected relationship is not automatically a Paradigm Shift.

Metaform reviews its organization when evidence shows that:

- several Namespace names describe the same categorical Type;
- one Namespace name is being used for materially different Types;
- EN, ED, or EF no longer accurately discriminate a Type;
- an Element currently treated as internal needs independent latent inference;
- a Defining Element is producing unnecessary granularity and should remain internal;
- a project-native relationship has been written into global categorical inference;
- an latent inference relationship has been biased by repository context;
- native and latent inference OP perspectives should be represented by a merged join;
- a relationship category or join schema no longer expresses how later consumers need to query it; or
- more or less categorical inference should be prepared in advance to improve later operations.

### Operational flow

1. The Native Expert enters the repository and performs Digital Typology.
2. It selects `code`, `document`, `media`, or `data` and adds the shortest common modifiers needed to identify the base functional Type.
3. For each dependency it performs one Metaform CLI or MCP Namespace search; Metaform searches project-local and global Namespace objects together and returns one candidate set.
4. It reuses a fitting object or authors a new local NS object with EN, ED, and optionally one or two aliases.
5. It records native OP joins one at a time from the Element bearing the OP to the linked Element that provides the required EF, and applies Stylistic joins where needed.
6. After the local pass completes, Metaform promotes newly authored Namespace objects from local to global while removing their native OP relationships.
7. Metaform hands the native objects to the Latent Expert one at a time without native OP relationships.
8. Each Latent Expert works without knowledge of the project, uses pure inference and the composed Namespace search, and infers the Type's EF, RE → OP relationships, dependencies, major Elements, and other schema-assigned categorical structure.
9. Metaform stores latent inference inference and latent inference joins against the reusable global Namespace objects.
10. Repository initialization copies the required global records and latent OP joins into repository `metaform.kg`, retains the native OP joins already produced locally, and creates merged joins by matching Namespace Scope while retaining both source joins and the source of every OP.
11. The resulting repository graph provides the Inference Metaform used by later graph queries, prompt construction, workflow selection, and lexicalization.
12. The operational agent performs the concrete workpiece task using the selected local context.
13. Later evidence can revise only the categorical records, native relationships, merged joins, prompts, workflows, schemas, or mechanics to which that evidence applies.

---

## Schema registry

The JSON Schema registry is separate from `metaform.kg`. It is a dictionary of independently addressable JSON Schema resources.

- The dictionary key is the schema's canonical identifier.
- The dictionary value is the complete JSON Schema resource.
- The resource's internal `$id` is the same canonical identifier.

The registry itself is a dictionary container, not a JSON Schema. Registered schemas can refer to one another with `$ref`.

The Core requires the schema registry to represent the refined ET and relationship model without forcing every record into one generic semantic shape.

### Element Table record schema

The ET projection is intentionally small:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://metaform.local/schemas/metaform.element-table-entry.schema.json",
  "type": "object",
  "properties": {
    "entity_desc": { "type": "string" },
    "entity_schema": { "type": "string" },
    "entity_json_obj": { "type": "object" }
  },
  "required": ["entity_desc", "entity_schema", "entity_json_obj"],
  "additionalProperties": false
}
```

The dictionary key supplies the Namespace ID and is not duplicated inside the ET projection. EN remains part of the schema-specific `entity_json_obj` because the human-readable Element Name and the canonical Namespace ID are different pieces of inference.

### Element Table dictionary schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://metaform.local/schemas/metaform.element-table.schema.json",
  "type": "object",
  "additionalProperties": {
    "$ref": "https://metaform.local/schemas/metaform.element-table-entry.schema.json"
  }
}
```

### Common join projection

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://metaform.local/schemas/metaform.join.schema.json",
  "type": "object",
  "properties": {
    "object_id": { "type": "string" },
    "join_scope": {
      "type": "string",
      "enum": ["native", "archaeology", "merged"]
    },
    "element_id": { "type": "string" },
    "type": { "type": "string" },
    "purpose": { "type": "string" },
    "schema_id": { "type": "string" },
    "join_logic": { "type": "string" }
  },
  "required": [
    "object_id",
    "join_scope",
    "element_id",
    "type",
    "purpose",
    "schema_id",
    "join_logic"
  ],
  "additionalProperties": false
}
```

A schema-specific reified join can add the structured participants, native OP, latent inference OP, source references, evidence, and other fields required by that relationship. The common projection exists for deterministic traversal and filtering; it does not flatten the full join semantics.

### Assembled graph schema

An assembled graph contains the ET dictionary and explicit join set:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://metaform.local/schemas/metaform.graph.schema.json",
  "type": "object",
  "properties": {
    "elements": {
      "$ref": "https://metaform.local/schemas/metaform.element-table.schema.json"
    },
    "joins": {
      "type": "array",
      "items": {
        "$ref": "https://metaform.local/schemas/metaform.join.schema.json"
      }
    }
  },
  "required": ["elements", "joins"],
  "additionalProperties": false
}
```

The Artifact Type schema, reified join schemas, workflow schemas, procedure schemas, rubric schemas, and other resources remain independently registered. The Core does not require their instances to share one flattened JSON shape.

---

Metaform is an Inference Metaform Modeler. Its Native Expert abstracts a concrete workpiece into a coarse native Digital Typology. Its Latent Experts investigate the named Artifact Types independently of the repository. Metaform preserves both shapes, merges their applicable relationships into the repository Inference Metaform, and uses selected parts of that form to lexicalize workflows and construct later operational context. The workpiece remains the operational agent's concrete evidence; the Inference Metaform supplies the reusable categorical shape around it.
