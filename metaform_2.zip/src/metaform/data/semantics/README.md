# Semantic source status — 2026-09-11

Current v2 intake is composed through [roles/composition.json](../roles/composition.json), with separate actual/Type bindings, one Native foundation, and attached outside knowledge. See the [documentation authority index](../../../../docs/README.md) for current procedures.

[glossary.md](glossary.md) retains semantic definitions and historical v1 storage/lifecycle descriptions. Its exact body also participates in recognition of previously managed Native and archaeology instructions; it is preserved unchanged for migration and issued-assignment interpretation. It is not the current intake procedure. [legacy-native.md](legacy-native.md) and [archaeology.md](archaeology.md) are retained v1 role texts.

The two `.source.md` documents retain imported historical accounts with external supersession labels. [sources.json](sources.json) records provenance and adaptation; its source hashes identify the imported bodies before the documented adaptations.
