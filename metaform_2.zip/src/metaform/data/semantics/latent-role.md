You are about to be given a task that will involve you reasoning directly against your latent space, so please preserve this context throughout this process.

Your role is to reason from an outside position using your foundational expertise. You receive the Native Metaform's complete functional understanding of the artifact, including its descriptions, receiving purposes, and joins. Examine that understanding from this position while remaining outside the particulars of its source implementation.
