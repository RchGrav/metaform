"""Working-folder bindings in the base db (SPEC sections 9 and 13).

A binding records which working folder is bound to which assignment. It replaces the on-disk
`.agentid/nonce` marker: `begin` records the folder, `done` clears it, the CLI detects the
working folder and reads the record, and a record with no activity for 24 hours acts as
absent, with no message. Reads are direct and read-only and never start the service.

The table lives in the base db of the user's home, `service/knowledge.sqlite3`, whatever home
the assignment itself belongs to. A second home is consulted when a caller names one, which is
how a portable copy finds the bindings its packet carried.
"""
import json
import os
import shutil
import sqlite3
import tempfile
from contextlib import closing, contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

IDLE = timedelta(hours=24)
SCHEMA = ("CREATE TABLE IF NOT EXISTS bindings(folder TEXT PRIMARY KEY, nonce TEXT NOT NULL, project TEXT NOT NULL,"
          " body TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL);"
          "CREATE TABLE IF NOT EXISTS agents(pid INTEGER PRIMARY KEY, ppid INTEGER NOT NULL, folder TEXT NOT NULL,"
          " project TEXT NOT NULL, nonce TEXT, started TEXT NOT NULL)")


def now():
    return datetime.now(timezone.utc).isoformat()


def base_home(home=None):
    return Path(home or os.environ.get("METAFORM_HOME") or Path.home() / ".metaform").expanduser().resolve()


def database(home=None):
    return base_home(home) / "service" / "knowledge.sqlite3"


def _homes(homes=None):
    selected = []
    for home in [base_home(), *(homes or [])]:
        if home is None:
            continue
        resolved = Path(home).expanduser().resolve()
        if resolved not in selected:
            selected.append(resolved)
    return selected


@contextmanager
def writing(home=None):
    path = database(home)
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path, timeout=30)) as db:
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript(SCHEMA)
        db.execute("BEGIN IMMEDIATE")
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise


@contextmanager
def reading(home=None):
    """A read that writes nothing: the file and its write-ahead log are copied and the copy is
    opened read-only, so a read creates neither the database nor its sidecars."""
    path = database(home)
    if not path.is_file():
        yield None
        return
    with tempfile.TemporaryDirectory(prefix="metaform-bindings-") as directory:
        snapshot = Path(directory) / "knowledge.sqlite3"
        shutil.copyfile(path, snapshot)
        try:
            shutil.copyfile(str(path) + "-wal", str(snapshot) + "-wal")
        except FileNotFoundError:
            pass
        with closing(sqlite3.connect(snapshot.as_uri() + "?mode=ro", uri=True)) as db:
            db.row_factory = sqlite3.Row
            if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='bindings'").fetchone():
                yield None
                return
            yield db


def agent(pid, ppid, folder, project, nonce=None, home=None):
    """A server process announces itself: its own pid, the ppid of the harness that spawned it, and where it
    was started. Each agent is one process, so the process is how the system tells agents apart. The nonce is
    sent once and stays linked to the parent: a later process of the same harness inherits it."""
    ppid = int(ppid)
    nonce = nonce or linked(ppid, home)
    with writing(home) as db:
        db.execute("INSERT OR REPLACE INTO agents VALUES(?,?,?,?,?,?)",
                   (int(pid), ppid, str(Path(folder).resolve()), str(Path(project).resolve()), nonce, now()))
    return nonce


def linked(ppid, home=None):
    """The nonce linked to a harness: sent once by any of its processes, read back by all of them."""
    for selected in _homes([home]):
        with reading(selected) as db:
            if db is None or not db.execute(
                    "SELECT 1 FROM sqlite_master WHERE type='table' AND name='agents'").fetchone():
                continue
            row = db.execute("SELECT nonce FROM agents WHERE ppid=? AND nonce IS NOT NULL ORDER BY started DESC",
                             (int(ppid),)).fetchone()
            if row is not None:
                return row[0]
    return None


def record(folder, body, home=None, created=None, updated=None):
    stamp = now()
    with writing(home) as db:
        db.execute("INSERT OR REPLACE INTO bindings VALUES(?,?,?,?,?,?)",
                   (str(Path(folder).resolve()), str(body["nonce"]), str(body["project"]), json.dumps(body),
                    created or stamp, updated or stamp))


def _live(row):
    """The record's body when it is current; None when it is idle past a day or unreadable."""
    try:
        updated = datetime.fromisoformat(row["updated"])
        if updated.tzinfo is None:
            updated = updated.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - updated > IDLE:
            return None
        body = json.loads(row["body"])
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None
    return body if isinstance(body, dict) else None


def lookup(folder=None, home=None):
    """The binding of a folder or its nearest bound ancestor, or None. An idle or unreadable record is absent."""
    from .continuation import recorded_assignment

    start = Path(folder or Path.cwd()).resolve()
    for selected in _homes([home]):
        with reading(selected) as db:
            if db is None:
                continue
            for parent in [start, *start.parents]:
                row = db.execute("SELECT body, updated FROM bindings WHERE folder=?", (str(parent),)).fetchone()
                if row is None:
                    continue
                body = _live(row)
                if body is not None and recorded_assignment(body):
                    return body | {"folder": str(parent)}
    return None


def touch(folder, homes=None):
    """A command run under the binding is activity."""
    for selected in _homes(homes):
        if not database(selected).is_file():
            continue
        with writing(selected) as db:
            db.execute("UPDATE bindings SET updated=? WHERE folder=?", (now(), str(Path(folder).resolve())))


def clear(folder, homes=None):
    for selected in _homes(homes):
        if not database(selected).is_file():
            continue
        with writing(selected) as db:
            db.execute("DELETE FROM bindings WHERE folder=?", (str(Path(folder).resolve()),))


def clear_matching(predicate, homes=None):
    """Remove every record whose body the predicate accepts."""
    for selected in _homes(homes):
        if not database(selected).is_file():
            continue
        with writing(selected) as db:
            for row in db.execute("SELECT folder, body FROM bindings").fetchall():
                try:
                    body = json.loads(row["body"])
                except json.JSONDecodeError:
                    continue
                if isinstance(body, dict) and predicate(body):
                    db.execute("DELETE FROM bindings WHERE folder=?", (row["folder"],))


def rows(project, homes=None):
    """Every record bound to a project, for export."""
    found = {}
    for selected in _homes(homes):
        with reading(selected) as db:
            if db is None:
                continue
            for row in db.execute("SELECT folder, body, created, updated FROM bindings WHERE project=?", (str(project),)):
                try:
                    body = json.loads(row["body"])
                except json.JSONDecodeError:
                    continue
                found.setdefault(row["folder"], {"folder": row["folder"], "body": body,
                                                 "created": row["created"], "updated": row["updated"]})
    return list(found.values())
