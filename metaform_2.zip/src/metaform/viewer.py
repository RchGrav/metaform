from __future__ import annotations

import argparse
import importlib.resources
import threading
import asyncio
import json
import fnmatch
import tempfile
import shutil
from pathlib import Path

from .graph import join_participants, type_ids

from flask import (
    redirect,
    Flask,
    jsonify,
    render_template_string,
    request,
    Response,
    send_from_directory,
)


def create_app(metaform=None, instance_id=None, *, owner=None):
    from .util import read_json, write_json

    app = Flask(__name__, static_folder=None)
    previews = {}
    preview_lock = threading.RLock()
    from flask import g
    from werkzeug.local import LocalProxy
    initial = metaform
    projects = {initial.project_id: initial} if initial is not None else {}
    catalog_path = owner.directory / "projects.json" if owner is not None else None
    remembered = read_json(catalog_path, []) if catalog_path is not None else []
    project_lock = threading.RLock()
    opening = {}
    metaform = LocalProxy(lambda: getattr(g, "metaform", initial))

    def project_catalog():
        from .service import RemoteKnowledge
        from uuid import NAMESPACE_URL, uuid5

        with project_lock:
            current, saved = dict(projects), list(remembered)
        entries = {key: selected.project_context() if selected.project.is_dir() else
                   {"project_id": selected.project_id, "name": selected.project_name, "path": str(selected.project),
                    "knowledge_mode": selected.knowledge_mode, "assignment": None, "mode": None}
                   for key, selected in current.items()}
        paths = {entry["path"] for entry in entries.values()}
        if owner is not None:
            records = [*owner.project_records(), *saved]
        else:
            records = []
            homes = {selected.home for selected in current.values() if selected.knowledge_mode != "portable"}
            for home in sorted(homes):
                if (home / "service" / "knowledge.sqlite3").is_file():
                    records.extend(entry | {"home": str(home)} for entry in
                                   RemoteKnowledge(home, None).call("project.list", {}))
        for entry in records:
            if entry["path"] in paths:
                continue
            key = entry["project_id"]
            if key in entries:
                key += "-" + uuid5(NAMESPACE_URL, entry["path"]).hex
            entries[key] = entry
            paths.add(entry["path"])
        return {key: entry | {"url": "/projects/" + key + "/", "missing": not Path(entry["path"]).is_dir()}
                for key, entry in entries.items()}

    def open_project(path, home=None):
        from .app import App
        from .util import read_json
        from uuid import NAMESPACE_URL, uuid5

        if not isinstance(path, (str, Path)) or not str(path).strip():
            raise ValueError("Enter an existing project folder")
        project = Path(str(path).strip()).expanduser()
        if not project.is_absolute() and initial is not None:
            project = initial.project / project
        project = project.resolve()
        if not project.is_dir():
            raise ValueError("Project folder does not exist: " + str(project))
        with project_lock:
            project_open_lock = opening.setdefault(project, threading.Lock())
        with project_open_lock:
            with project_lock:
                existing = next(((key, selected) for key, selected in projects.items()
                                 if selected.project == project), None)
            if existing is not None:
                key, selected = existing
                return selected.project_context() | {"url": "/projects/" + key + "/"}
            if owner is None and initial is not None:
                selected = initial.select_project(project)
            else:
                identity = read_json(project / ".metaform" / "project.json", {})
                selected_home = identity.get("service_home") or home or Path.home() / ".metaform"
                selected = App(project, selected_home, binding=False,
                               knowledge_client=owner.knowledge_client if owner is not None else None)
            if owner is not None:
                selected._service_owner = owner
            key = selected.project_id
            catalog = project_catalog()
            with project_lock:
                if (key in projects and projects[key].project != project
                        or key in catalog and catalog[key]["path"] != str(project)):
                    key += "-" + uuid5(NAMESPACE_URL, str(project)).hex
                projects[key] = selected
                if catalog_path is not None:
                    record = {"project_id": selected.project_id, "name": selected.project_name,
                              "path": str(selected.project), "home": str(selected.home),
                              "knowledge_mode": selected.knowledge_mode}
                    remembered[:] = [entry for entry in remembered if entry["path"] != str(selected.project)]
                    remembered.append(record)
                    write_json(catalog_path, remembered)
            return selected.project_context() | {"url": "/projects/" + key + "/"}

    app.extensions["metaform_open_project"] = open_project

    def forget_projects(path=None, missing=False):
        """Drop a project from the catalog and the registry: by folder, or every one whose folder is gone."""
        target = str(Path(str(path).strip()).expanduser().resolve()) if isinstance(path, str) and path.strip() else None
        if target is None and not missing:
            raise ValueError("Name the project folder to forget, or ask for every missing one")
        chosen = sorted({entry["path"] for entry in project_catalog().values()
                         if (target is not None and entry["path"] == target)
                         or (missing and not Path(entry["path"]).is_dir())})
        for folder in chosen:
            with project_lock:
                for key, selected in list(projects.items()):
                    if str(selected.project) == folder and selected is not initial:
                        projects.pop(key)
                remembered[:] = [entry for entry in remembered if entry["path"] != folder]
                if catalog_path is not None:
                    write_json(catalog_path, remembered)
            if owner is not None:
                owner.forget_project(folder)
        return {"forgotten": chosen}

    app.extensions["metaform_forget_projects"] = forget_projects

    @app.before_request
    def select_request_project():
        from flask import abort
        from werkzeug.routing import RequestRedirect
        origin = request.headers.get("Origin")
        if (request.method not in {"GET", "HEAD", "OPTIONS"} and origin is not None
                and origin != request.host_url.rstrip("/")):
            abort(403, "Browser mutations must come from the workbench origin")
        if isinstance(request.routing_exception, RequestRedirect):
            return
        identifier = (request.view_args or {}).pop("project_id", None)
        with project_lock:
            selected = projects.get(identifier) if identifier else initial
        if identifier and selected is None:
            entry = project_catalog().get(identifier)
            if entry is None:
                abort(404, "Unknown project")
            if not Path(entry["path"]).is_dir():
                abort(404, "Project folder does not exist: " + entry["path"])
            opened = open_project(entry["path"], entry.get("home"))
            if opened["url"] != "/projects/" + identifier + "/":
                abort(404, "Project identity changed; reopen its current project URL")
            with project_lock:
                selected = projects[identifier]
        g.metaform = selected
        g.project_prefix = "/projects/" + (identifier or initial.project_id) if selected else ""
        if selected is None and not (
            request.path in {"/", "/projects", "/api/health", "/api/projects", "/api/projects/open", "/api/projects/forget"}
            or request.path.startswith(("/static/", "/v1/"))
        ):
            abort(400, "Select a project using its /projects/<id>/ URL")

    @app.errorhandler(Exception)
    def error(exc):
        from werkzeug.exceptions import HTTPException

        return jsonify({"error": str(exc)}), exc.code if isinstance(
            exc, HTTPException
        ) else 400

    import time
    from collections import deque
    trace = deque(maxlen=400)
    app.extensions["metaform_trace"] = trace

    @app.before_request
    def start_call_timer():
        g.call_started = time.perf_counter()

    @app.after_request
    def record_call(response):
        started = getattr(g, "call_started", None)
        path = request.path[request.path.index("/api/"):] if "/api/" in request.path else request.path
        if started is not None and path.startswith("/api/") and path != "/api/trace":
            trace.append({"at": time.time(), "method": request.method, "path": path,
                          "query": request.query_string.decode() or None, "status": response.status_code,
                          "ms": round((time.perf_counter() - started) * 1000, 1),
                          "bytes": response.calculate_content_length()})
        return response

    @app.get("/api/trace")
    def trace_calls():
        """The calls the page made, newest last, with server time and payload size."""
        calls = list(trace)
        if request.args.get("clear"):
            trace.clear()
        return jsonify(calls)

    @app.get("/api/health")
    def health():
        return jsonify({**(owner.endpoint if owner is not None and hasattr(owner, "endpoint") else {}),
                        "product": "metaform-viewer", "instance_id": instance_id})

    @app.get("/static/<path:name>")
    def static_file(name):
        root = importlib.resources.files("metaform") / "static"
        if name not in {"explorer.js", "explorer.css", "vendor/cytoscape.min.js", "vendor/cytoscape-dagre.js"}:
            return "Not found", 404
        return Response(
            (root / name).read_text(),
            mimetype={".js": "text/javascript", ".css": "text/css", ".json": "application/json"}[Path(name).suffix],
        )

    def chooser():
        return render_template_string(
            (importlib.resources.files("metaform") / "templates" / "projects.html").read_text(),
            projects=list(project_catalog().values()),
        )

    def last_opened_url():
        """The page of the project opened most recently, in this process or remembered by the service."""
        with project_lock:
            keys = list(projects)
            saved = list(remembered)
        if keys:
            return "/projects/" + keys[-1] + "/"
        for entry in reversed(saved):
            if not Path(entry["path"]).is_dir():
                continue
            match = next((item["url"] for item in project_catalog().values() if item["path"] == entry["path"]), None)
            if match:
                return match
        return None

    @app.get("/")
    def index():
        if g.metaform is None:
            landing = last_opened_url()
            return redirect(landing) if landing else chooser()
        return render_template_string(
            (importlib.resources.files("metaform") / "templates" / "explorer.html").read_text(),
            project_prefix=g.project_prefix,
        )

    @app.get("/projects")
    def projects_page():
        return chooser()

    drives = {}
    app.extensions["metaform_drives"] = drives

    def drive_view(entry):
        return {key: entry.get(key) for key in ("run_id", "harness", "status", "error", "started", "ended")}

    def start_drive(target, run_identifier, harness):
        """Run intake.drive for one run on a background thread; the page polls the run."""
        import threading
        from .registry import Registry

        entry = drives[run_identifier] = {"run_id": run_identifier, "harness": harness, "status": "running",
                                          "started": time.time(), "result": None, "error": None}

        def work():
            try:
                entry["result"] = asyncio.run(Registry(target).call(
                    "intake.drive", {"run_id": run_identifier, "harness": harness}, internal=True))
                entry["status"] = "finished"
            except Exception as exc:
                entry["status"] = "failed"
                entry["error"] = str(exc)
            entry["ended"] = time.time()

        threading.Thread(target=work, daemon=True, name="metaform-drive-" + run_identifier).start()
        return entry

    def harness_choices():
        import shutil
        choices = [{"name": "codex", "available": bool(shutil.which("codex"))}]
        for name, entry in (metaform.config.get("harnesses") or {}).items():
            if name in {"codex", "mcp"}:
                continue
            command = (entry or {}).get("command") or []
            choices.append({"name": name, "available": bool(command) and (bool(shutil.which(command[0])) or Path(command[0]).is_file())})
        return choices

    @app.get("/api/jobs")
    def jobs():
        """Every recorded run, newest first, with any drive this workbench is running for it."""
        with metaform.db() as db:
            runs = [dict(row) for row in db.execute("SELECT id,workflow,status,updated FROM runs ORDER BY updated DESC LIMIT 200")]
        for run in runs:
            entry = drives.get(run["id"])
            run["drive"] = drive_view(entry) if entry else None
        return jsonify({"runs": runs, "harnesses": harness_choices()})

    @app.post("/api/jobs/intake")
    def jobs_intake():
        """Start a Native intake and drive it with the chosen harness on a background thread."""
        from .registry import Registry

        body = request.get_json() or {}
        target = g.metaform
        job = asyncio.run(Registry(target).call("intake.start", body.get("inputs") or {}, internal=True))
        entry = start_drive(target, job["run_id"], body.get("harness", "codex"))
        return jsonify({"run_id": job["run_id"], "request_id": job.get("request_id"), "drive": drive_view(entry)})

    @app.post("/api/jobs/drive")
    def jobs_drive():
        body = request.get_json() or {}
        return jsonify(drive_view(start_drive(g.metaform, body["run_id"], body.get("harness", "codex"))))

    @app.get("/api/run/<identifier>/events")
    def run_events(identifier):
        with metaform.db() as db:
            rows = [dict(row) | {"body": json.loads(row["body"])} for row in db.execute(
                "SELECT id,kind,body,created FROM events WHERE run_id=? ORDER BY id", (identifier,))]
        return jsonify(rows)

    @app.get("/api/prompt/<path:identifier>")
    def prompt_get(identifier):
        from .prompts import get

        return jsonify(get(metaform, identifier))

    @app.post("/api/prompt/<path:identifier>")
    def prompt_put(identifier):
        """Save edited prompt text; the next assignment composed from it uses the new revision."""
        from .prompts import get, put

        record = {**get(metaform, identifier), "id": identifier, "text": (request.get_json() or {})["text"]}
        return jsonify(put(metaform, record))

    @app.get("/api/agent/instructions")
    def agent_instructions():
        """The instructions the MCP server sends the agent on connect."""
        from .onboarding import instructions

        return jsonify({"instructions": instructions(metaform)})

    @app.get("/api/agent/tools")
    def agent_tools():
        """The tool list the MCP server offers the agent, with each input schema."""
        from .registry import Registry

        registry = Registry(metaform)
        tools = [{"name": "abort", "description": "Leave the active module and return to the router.",
                  "inputSchema": {"type": "object", "properties": {}}}]
        tools.extend(command.definition(metaform) for command in registry.visible().values())
        return jsonify({"tools": sorted(tools, key=lambda tool: tool["name"])})

    @app.get("/api/report")
    def report():
        from .modules.web import report

        return jsonify(report(metaform, {}, None))

    @app.get("/api/pending")
    def pending_status():
        from .modules.web import pending

        return jsonify(pending(metaform))

    def perspective_scope(perspective):
        scopes = {"inference": None, "contextual": "native", "latent": "archaeology"}
        if perspective not in scopes:
            raise ValueError("Unknown Metaform perspective: " + perspective)
        return scopes[perspective]

    @app.get("/api/graph")
    def graph():
        query = request.args.get("q", "*")
        graph = (
            metaform.global_graph
            if request.args.get("storage") == "global"
            else metaform.graph
        )
        scope = perspective_scope(request.args.get("perspective", "inference"))
        return jsonify(graph.search(query, scope=scope))

    @app.get("/api/network")
    def network():
        storage = request.args.get("storage", "project")
        graph = metaform.global_graph if storage == "global" else metaform.graph
        perspective = request.args.get("perspective", "inference")
        comparison = graph.similarity()
        similarity = comparison if perspective == "similarity" else None
        memberships = {
            (source, identifier): join["membership"]
            for join in comparison["joins"]
            for source, identifiers in join["sources"].items()
            for identifier in identifiers
        }
        scope = None if similarity is not None else perspective_scope(perspective)
        query = request.args.get("q", "*")
        layer = None if similarity is not None else request.args.get("layer") or None
        records = {} if similarity is not None else {r["id"]: r for r in graph.search(scope=scope)}
        joins = {j["id"]: j for j in (similarity["joins"] if similarity is not None else graph.joins(scope=scope))}

        def references(join):
            return {p["ref"] for p in join_participants(join) if p.get("ref")}

        sources = {scope} if scope else {"native", "archaeology", "merged"}
        record_ids = set(similarity["elements"]) if similarity is not None else {
            identifier for identifier, record in records.items()
            if sources.intersection(record.get("sources", []))
        }
        join_ids = set(joins) if similarity is not None else {
            identifier for identifier, join in joins.items()
            if join.get("join_scope") in sources
        }

        def include_participants(selected):
            # Include referenced joins as joins, preserving joins on joins.
            pending = list(selected)
            seen = set()
            refs = set()
            while pending:
                identifier = pending.pop()
                if identifier in seen:
                    continue
                seen.add(identifier)
                for ref in references(joins[identifier]):
                    refs.add(ref)
                    if ref in joins and ref not in seen:
                        selected.add(ref)
                        pending.append(ref)
            return refs

        record_ids.update(include_participants(join_ids) - set(joins))
        source_records = {}
        if perspective == "inference":
            for source in ("native", "archaeology"):
                for record in graph.search(scope=source):
                    source_records.setdefault(record["id"], {})[source] = record
        layers = sorted({records[i]["layer"] for i in record_ids if i in records})
        if query != "*" or layer:
            matched = {
                identifier for identifier in record_ids
                if fnmatch.fnmatchcase(identifier.lower(), query.lower())
                or ("*" not in query and query.lower() in identifier.lower())
            } if similarity is not None else {r["id"] for r in graph.search(query, layer, scope=scope)}
            if similarity is None:
                for identifier, record in records.items():
                    for variant in [record, *source_records.get(identifier, {}).values()]:
                        if ((not layer or variant["layer"] == layer)
                                and any(fnmatch.fnmatchcase(identifier.lower(), query.lower())
                                        or ("*" not in query and query.lower() in identifier.lower())
                                        for identifier in type_ids(variant))):
                            matched.add(identifier)
            record_ids.intersection_update(matched)
            join_ids = {
                identifier for identifier in join_ids
                if references(joins[identifier]).intersection(record_ids)
            }
            record_ids.update(include_participants(join_ids) - set(joins))

        classification_ids = set()
        if similarity is None:
            for identifier in list(record_ids):
                for variant in [records.get(identifier, {}), *source_records.get(identifier, {}).values()]:
                    for type_id in type_ids(variant):
                        while type_id:
                            classification_ids.add(type_id)
                            type_id = type_id.rpartition(".")[0]
            for identifier in sorted(classification_ids):
                record = (records.get(identifier) or graph.get(identifier, scope="authored")
                          or (metaform.global_graph.get(identifier) if storage == "project" else None))
                if record is not None and not type_ids(record):
                    records[identifier] = record
                    record_ids.add(identifier)

        nodes = {}
        for identifier in sorted(record_ids):
            if similarity is not None:
                nodes[identifier] = dict(similarity["elements"][identifier], id=identifier, name=identifier, kind="structure")
                continue
            record = records.get(identifier)
            nodes[identifier] = (
                dict(record, id=identifier, kind="element", name=record["entity_json_obj"].get("en", identifier))
                if record else
                {"id": identifier, "name": identifier, "kind": "reference", "sources": []}
            )
            if record and identifier in source_records:
                nodes[identifier]["source_records"] = source_records[identifier]
            if identifier in classification_ids:
                nodes[identifier]["classification_context"] = True
        edges = []
        for identifier in sorted(join_ids):
            join = joins[identifier]
            receiver, provider = join.get("object_id"), join.get("element_id")
            participants = join.get("participants", [])
            if not receiver and not provider:
                receivers = [p["ref"] for p in participants if p.get("role") == "receiver" and p.get("ref")]
                providers = [p["ref"] for p in participants if p.get("role") == "ef_owner" and p.get("ref")]
                if len(receivers) == len(providers) == 1:
                    receiver, provider = receivers[0], providers[0]
            # A direct edge represents a known receiving relationship only.
            # Other hyperedges remain intact in the separate joins collection.
            if (
                not receiver or not provider
                or receiver in joins or provider in joins
                or receiver not in nodes or provider not in nodes
                or any(p.get("ref") and p["ref"] not in {receiver, provider} for p in participants)
                or any(
                    p.get("ref") and p.get("role") in {"receiver", "ef_owner"}
                    and p["ref"] != {"receiver": receiver, "ef_owner": provider}[p["role"]]
                    for p in participants
                )
            ):
                continue
            edges.append({
                "id": identifier, "join_id": identifier,
                "source": provider, "target": receiver,
                "label": join["membership"] if similarity is not None else join.get("purpose", ""), "type": join["type"],
                "membership": join.get("membership") if similarity is not None or join.get("join_scope") == "merged"
                else memberships.get((join.get("join_scope"), identifier)),
            })
        return jsonify({
            "nodes": list(nodes.values()), "edges": edges, "layers": layers,
            "joins": [joins[identifier] for identifier in sorted(join_ids)],
            "backend": metaform.configuration()["active"].get("graph_backend", "sqlite"),
            "storage": storage,
            "perspective": perspective,
            "context": (metaform.get("native_context") or {})
            if storage == "project" and perspective in {"inference", "contextual"} else {},
        })

    @app.get("/api/element/<path:identifier>")
    def element(identifier):
        graph = (
            metaform.global_graph
            if request.args.get("storage") == "global"
            else metaform.graph
        )
        scope = perspective_scope(request.args.get("perspective", "inference"))
        record = graph.get(identifier, scope=scope)
        result = {
            "record": record,
            "joins": graph.joins(identifier, scope=scope),
            "provenance": [
                observation for observation in graph.provenance(identifier)
                if scope is None or observation["source"] == scope
            ],
        }
        if (
            graph is metaform.graph
            and record
            and record["entity_schema"] == "metaform:prompt"
        ):
            from . import prompts

            result["prompt"] = prompts.get(metaform, identifier)
        return jsonify(result)

    @app.post("/api/element/<path:identifier>")
    def edit(identifier):
        data = request.get_json()
        graph = (
            metaform.global_graph if data.get("storage") == "global" else metaform.graph
        )
        scope = perspective_scope(data.get("perspective", "inference"))
        if "join" in data:
            targets = {identifier, data["join"].get("id")}
            records = [data["join"], *[join for join in graph.joins() if join["id"] in targets]]
            if any(join.get("join_scope") == "merged" or join.get("schema_id") == "metaform:merged-join" for join in records):
                raise ValueError("Shape-similarity records are read-only; edit the Contextual or Latent source join.")
            result = graph.put({"joins": [data["join"]]}, scope or "edited")
        else:
            result = graph.put(
                {"elements": {identifier: data["record"]}},
                scope or "edited",
                data.get("layer", "elements"),
            )
        return jsonify(result)

    @app.get("/api/workflows")
    def workflows():
        from .workflow import Engine

        return jsonify(
            [
                {
                    "id": r["id"][9:],
                    "source": r["entity_json_obj"],
                    "executable": Engine(metaform).definition(r["id"][9:]),
                }
                for r in metaform.graph.search()
                if r["entity_schema"] == "metaform:workflow"
            ]
        )

    @app.get("/api/run/<identifier>")
    def run(identifier):
        return jsonify(metaform.load_run(identifier))

    @app.post("/api/semantic/<command>")
    def semantic_call(command):
        from .registry import Registry

        return jsonify(asyncio.run(Registry(g.metaform).call(command, request.get_json() or {})))

    @app.post("/api/call/<command>")
    def call(command):
        from .registry import Registry

        return jsonify(
            asyncio.run(
                Registry(g.metaform).call(
                    command, request.get_json() or {}, internal=True
                )
            )
        )

    @app.post("/api/workflow/import")
    def workflow_import():
        from .workflow import import_workflow

        return jsonify(import_workflow(metaform, request.get_json()))

    @app.get("/api/community")
    def community():
        return jsonify(
            {
                "repository": "https://github.com/RchGrav/metaform",
                "modules": [
                    str(metaform.home / "modules"),
                    str(metaform.root / "modules"),
                ],
            }
        )

    @app.get("/api/history")
    def versions():
        from .history import initialize

        return jsonify(initialize(metaform))

    @app.post("/api/preview")
    def preview():
        from uuid import uuid4
        from .history import initialize, reconstruct

        manifest = initialize(metaform)
        versions = request.get_json().get("versions") or list(manifest["versions"]) or ["origin"]
        result = []
        with preview_lock:
            for version in versions:
                key = (metaform.project, version)
                if key not in previews:
                    folder = Path(tempfile.mkdtemp(prefix="metaform-preview-"))
                    try:
                        reconstruct(metaform, version, folder)
                    except BaseException:
                        shutil.rmtree(folder)
                        raise
                    previews[key] = {"id": uuid4().hex, "folder": folder}
                item = previews[key]
                result.append({"version": version, "url": request.host_url.rstrip("/")
                               + g.project_prefix + "/api/preview/" + item["id"] + "/"})
        return jsonify(result)

    @app.get("/api/preview/<preview_id>/")
    @app.get("/api/preview/<preview_id>/<path:name>")
    def preview_file(preview_id, name=""):
        from flask import abort, make_response, redirect
        from urllib.parse import quote
        from werkzeug.security import safe_join

        with preview_lock:
            item = next((value for key, value in previews.items()
                         if key[0] == metaform.project and value["id"] == preview_id), None)
        if item is None:
            abort(404, "Preview is closed or belongs to another project")
        folder = item["folder"]
        target = safe_join(str(folder), name)
        if target is None:
            abort(404)
        target = Path(target)
        if target.is_dir():
            if not request.path.endswith("/"):
                return redirect(request.path + "/")
            if (target / "index.html").is_file():
                response = send_from_directory(folder, str((target / "index.html").relative_to(folder)))
            else:
                entries = [{"name": child.name + ("/" if child.is_dir() else ""),
                            "url": quote(child.name, safe="") + ("/" if child.is_dir() else "")}
                           for child in sorted(target.iterdir(), key=lambda value: value.name)]
                response = make_response(render_template_string(
                    '<!doctype html><title>Preview files</title><h1>Preview files</h1><ul>{% for entry in entries %}<li><a href="{{ entry.url }}">{{ entry.name }}</a></li>{% endfor %}</ul>',
                    entries=entries))
        else:
            response = send_from_directory(folder, name)
        response.headers["Content-Security-Policy"] = "sandbox allow-scripts allow-forms allow-popups allow-downloads"
        response.headers["Access-Control-Allow-Origin"] = "*"
        return response

    @app.post("/api/preview/stop")
    def stop_previews():
        with preview_lock:
            for key, item in list(previews.items()):
                if key[0] == metaform.project:
                    shutil.rmtree(item["folder"])
                    del previews[key]
        return jsonify({"stopped": True})

    def close_resources():
        with preview_lock:
            for key, item in list(previews.items()):
                shutil.rmtree(item["folder"])
                del previews[key]

    app.extensions["metaform_close"] = close_resources

    @app.get("/api/settings")
    def settings():
        return jsonify(
            {
                "project": str(metaform.project),
                "project_id": metaform.project_id,
                "name": metaform.project_name,
                "knowledge_mode": metaform.knowledge_mode,
                "assignment": metaform.binding,
                "backend": metaform.configuration()["active"].get("graph_backend", "sqlite"),
                "harnesses": list(metaform.config.get("harnesses", {})),
                "author": "Richard Graver",
                "repository": "https://github.com/RchGrav/metaform",
            }
        )

    @app.get("/api/projects")
    def project_list():
        return jsonify(list(project_catalog().values()))

    @app.post("/api/projects/forget")
    def project_forget():
        arguments = request.get_json() or {}
        return jsonify(forget_projects(arguments.get("path"), bool(arguments.get("missing", False))))

    @app.post("/api/projects/open")
    def project_open():
        arguments = request.get_json() or {}
        if g.metaform is not None and metaform.binding:
            raise ValueError("Project selection cannot change a bound assignment")
        path = arguments.get("path")
        if isinstance(path, str) and path.strip() and g.metaform is not None:
            path = metaform.project / Path(path.strip()).expanduser()
        return jsonify(open_project(path, arguments.get("home")))

    @app.get("/api/dump")
    def dump():
        response = jsonify(metaform.graph.export())
        response.headers["Content-Disposition"] = (
            'attachment; filename="metaform-graph.json"'
        )
        return response

    for rule in list(app.url_map.iter_rules()):
        if rule.rule.startswith("/static/"):
            continue
        app.add_url_rule("/projects/<project_id>" + rule.rule,
                         endpoint="project_" + rule.endpoint,
                         view_func=app.view_functions[rule.endpoint], methods=rule.methods)
    return app


def main():
    from .service import open_viewer

    parser = argparse.ArgumentParser(description="Open a project in the shared Metaform server.")
    parser.add_argument("--project", default=str(Path.cwd()))
    parser.add_argument("--home", default=None)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    from .app import App
    selected = App(args.project, args.home, binding=False)
    print(json.dumps(open_viewer(selected.project, selected.home, args.host, args.port)))


if __name__ == "__main__":
    main()
