"""Portable, owner-aware closure over one captured knowledge revision.

``DictionarySnapshot(capture)`` accepts ``{revision, partitions, schemas?}``:
``partitions`` maps owner names to ordinary graph exports (elements keyed by ID,
joins and observations as lists); ``schemas`` maps owner to schema-ID/body maps.
Optional ``runtime_assets`` uses the same owner/ID map. ``archive_dependencies``
is a list of ``{owner, kind, id, body, provenance}`` entries.

Readers expose ``revision``, ``roots(owner)``, ``record(RecordKey)``,
``resolve(str | {ref, owner?, kind?, field?}, author_owner)``,
``incident_element(address, owners)``, ``incident_join(key, owners)``,
``source_observations(key)``, and ``owner_observations(owner)``. Keys returned by
resolution remain logical keys when bodies are absent. ``dependencies(body)``
returns typed references; readers may omit it to use the built-in extractors.
All bodies returned by the dictionary adapter are detached copies. Store adapters
must capture their data in one read transaction before constructing this reader,
or provide the same methods over a live read transaction.
"""
from __future__ import annotations

import copy
import json
from collections import defaultdict, deque
from dataclasses import asdict

from .graph import scoped_export
from .knowledge import KnowledgeSnapshot, RecordKey, reference_fields
from .similarity import compare
from .util import digest, dumps


def _similarity(body):
    return body is not None and (
        body.get("join_scope") == "merged"
        or body.get("schema_id") == "metaform:merged-join"
    )


class DictionarySnapshot(KnowledgeSnapshot):
    """Detached dictionary capture with one owner/reference index construction."""

    def __init__(self, capture):
        super().__init__(capture["revision"], capture["partitions"], capture.get("schemas"))
        self.runtime_assets = copy.deepcopy(capture.get("runtime_assets", {}))
        self.archive_dependencies = copy.deepcopy(capture.get("archive_dependencies", []))
        self._element_incidence = defaultdict(list)
        self._join_incidence = defaultdict(set)
        self._observations = defaultdict(list)
        for owner, graph in self.partitions.items():
            for observation in graph.get("observations", []):
                self._observations[RecordKey(owner, "element", observation["element_id"])].append(observation)
            for join in graph.get("joins", []):
                key = RecordKey(owner, "join", join["id"])
                for ref in reference_fields(join):
                    resolved = self.resolve(ref, owner)
                    # A ref resolved to a join is not an Element-address shortcut.
                    if any(target.kind == "element" for target in resolved):
                        self._element_incidence[ref["ref"]].append((key, ref.get("owner")))
                    for target in resolved:
                        if target.kind == "join":
                            self._join_incidence[target].add(key)

    def record(self, key):
        if key.kind == "runtime_asset":
            return copy.deepcopy(self.runtime_assets.get(key.owner, {}).get(key.id))
        return super().record(key)

    def incident_element(self, address, owners):
        return sorted({key for key, explicit in self._element_incidence.get(address, [])
                       if key.owner in owners and (explicit is None or explicit in owners)})

    def incident_join(self, key, owners):
        return sorted(candidate for candidate in self._join_incidence.get(key, ()) if candidate.owner in owners)

    def source_observations(self, key):
        return copy.deepcopy(self._observations.get(key, []))

    def dependencies(self, record):
        return execution_dependencies(record)


class SqlKnowledgeSnapshot(KnowledgeSnapshot):
    """Indexed reader over an already-open KnowledgeStore read transaction.

    ``db`` uses sqlite3.Row. The caller reads ``revision`` in that transaction
    first and keeps it open until ``project_closure`` returns. No global graph
    export or owner-wide global record enumeration is performed.
    """

    def __init__(self, db, project_id, revision, runtime_assets=None, schemas=None):
        self.db = db
        self.project_id = project_id
        self.owners = {"global", project_id if project_id.startswith("project:") else "project:" + project_id}
        self.revision = revision
        self.runtime_assets = copy.deepcopy(runtime_assets or {})
        self.schemas = copy.deepcopy(schemas or {})
        self._records = {}
        self.archive_dependencies = []

    def record(self, key):
        if key.owner not in self.owners:
            return None
        if key.kind == "runtime_asset":
            return copy.deepcopy(self.runtime_assets.get(key.owner, {}).get(key.id))
        if key not in self._records:
            body = None
            if key.kind == "element":
                row = self.db.execute("SELECT entity_desc,entity_schema,entity_json_obj,layer FROM elements WHERE owner=? AND id=?", (key.owner, key.id)).fetchone()
                if row is not None:
                    body = {"entity_desc": row["entity_desc"], "entity_schema": row["entity_schema"],
                            "entity_json_obj": json.loads(row["entity_json_obj"]), "layer": row["layer"]}
            elif key.kind in {"join", "schema"}:
                table = "joins" if key.kind == "join" else "schemas"
                row = self.db.execute(f"SELECT body FROM {table} WHERE owner=? AND id=?", (key.owner, key.id)).fetchone()
                if row is not None:
                    body = json.loads(row["body"])
                elif key.kind == "schema":
                    body = self.schemas.get(key.owner, {}).get(key.id)
            self._records[key] = body
        return copy.deepcopy(self._records[key])

    def roots(self, owner):
        return [RecordKey(owner, kind, row["id"])
                for kind, table in (("element", "elements"), ("join", "joins"))
                for row in self.db.execute(f"SELECT id FROM {table} WHERE owner=? ORDER BY id", (owner,))]

    def _incident_candidates(self, address, owners):
        for owner in sorted(owners):
            rows = self.db.execute("""
                SELECT id,body FROM joins WHERE owner=? AND id IN (
                    SELECT id FROM joins WHERE owner=? AND object_id=?
                    UNION SELECT id FROM joins WHERE owner=? AND element_id=?
                    UNION SELECT join_id FROM participants WHERE owner=? AND ref=?
                ) ORDER BY id
            """, (owner, owner, address, owner, address, owner, address))
            for row in rows:
                key = RecordKey(owner, "join", row["id"])
                body = json.loads(row["body"])
                self._records[key] = body
                yield key, body

    def incident_element(self, address, owners):
        return [key for key, body in self._incident_candidates(address, owners)
                if any(ref["ref"] == address and
                       (not ref.get("owner") or ref["owner"] in owners) and
                       any(target.kind == "element" for target in self.resolve(ref, key.owner))
                       for ref in reference_fields(body))]

    def incident_join(self, key, owners):
        return [candidate for candidate, body in self._incident_candidates(key.id, owners)
                if any(key in self.resolve(ref, candidate.owner) for ref in reference_fields(body))]

    def _observation_rows(self, clause, parameters):
        return [{name: row[name] for name in ("id", "element_id", "source", "created")}
                | {"record": json.loads(row["record"])}
                for row in self.db.execute("SELECT * FROM observations WHERE " + clause + " ORDER BY created,id", parameters)]

    def source_observations(self, key):
        return self._observation_rows("owner=? AND element_id=?", (key.owner, key.id))

    def owner_observations(self, owner):
        return self._observation_rows("owner=?", (owner,))

    def dependencies(self, record):
        return execution_dependencies(record)


def execution_dependencies(record):
    """Read explicit executable/schema fields, never references inferred from prose.

    Accepts an Element body, workflow definition, saved run/job, or module manifest.
    Results are ``{ref, kind, field, owner?}`` dictionaries. File references are
    runtime assets; materializing their bytes and rewriting saved definitions is
    the export staging layer's responsibility.
    """
    result = []

    def add(value, kind, field, prefix=""):
        if isinstance(value, str) and value:
            result.append({"ref": prefix + value if prefix and not value.startswith(prefix) else value,
                           "kind": kind, "field": field})
        elif isinstance(value, dict) and isinstance(value.get("ref"), str):
            result.append(dict(value, **({"kind": kind} if "kind" not in value and kind is not None else {}), field=field))

    def schema(value, path):
        if isinstance(value, str):
            if not value.startswith("#"):
                add(value.split("#", 1)[0], "schema", path)
        elif isinstance(value, dict):
            ref = value.get("$ref")
            if isinstance(ref, str) and not ref.startswith("#"):
                add(ref.split("#", 1)[0], "schema", path + ".$ref")
            for name, child in value.items():
                if isinstance(child, (dict, list)):
                    schema(child, path + "." + name)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                if isinstance(child, (dict, list)):
                    schema(child, f"{path}[{index}]")

    def visit(value, path=""):
        if not isinstance(value, dict):
            return
        field = lambda name: f"{path}.{name}" if path else name
        if "entity_schema" in value:
            schema(value["entity_schema"], field("entity_schema"))
            if value.get("entity_schema") in {"metaform:workflow", "metaform:step", "metaform:prompt", "metaform:semantic-rule", "metaform:module"}:
                visit(value.get("entity_json_obj"), field("entity_json_obj"))
        if "$ref" in value or "$id" in value:
            schema(value, path)
        for name in ("schema", "response_schema"):
            if name in value:
                schema(value[name], field(name))
        add(value.get("workflow"), "element", field("workflow"), "workflow:")
        for name in ("prompt_ref", "focal", "rule"):
            add(value.get(name), "element", field(name))
        for index, code in enumerate(value.get("rule_codes", [])):
            add(code, "element", field(f"rule_codes[{index}]"), "rule:")
        for index, rule in enumerate(value.get("rules", [])):
            if isinstance(rule, dict):
                add(rule.get("content", {}).get("rule_code"), "element", field(f"rules[{index}].content.rule_code"), "rule:")
        for name in ("module", "module_id"):
            add(value.get(name), "runtime_asset", field(name), "module:")
        add(value.get("tool"), "runtime_asset", field("tool"), "command:")
        for index, command in enumerate(value.get("tools", [])):
            add(command, "runtime_asset", field(f"tools[{index}]"), "command:")
        for index, module in enumerate(value.get("modules", [])):
            add(module, "runtime_asset", field(f"modules[{index}]"), "module:")
        prompt = value.get("prompt")
        if isinstance(prompt, str) and prompt.startswith("file:"):
            add(prompt, "runtime_asset", field("prompt"))
        if value.get("kind") == "parallel":
            for index, branch in enumerate(value.get("branches", [])):
                name = field(f"branches[{index}]")
                if isinstance(branch, str):
                    add(branch, "element", name, "workflow:")
                else:
                    visit(branch, name)
        for name in ("definition", "pending", "prepared", "prepared_inputs", "prompt_snapshot"):
            visit(value.get(name), field(name))
        for name in ("steps", "stack", "transitions"):
            children = value.get(name, [])
            if isinstance(children, list):
                for index, child in enumerate(children):
                    visit(child, field(f"{name}[{index}]"))
        for name, assignment in value.get("assignments", {}).items():
            visit(assignment, field(f"assignments.{name}"))
        # Intake jobs retain their focal Type in inputs.id.
        if value.get("role") == "latent_expert" or value.get("kind") == "intake":
            add(value.get("inputs", {}).get("id"), "element", field("inputs.id"))
            visit(value.get("inputs", {}).get("object"), field("inputs.object"))
        for name in ("graph", "inference"):
            captured_graph = value.get(name)
            if isinstance(captured_graph, dict):
                join_ids = {body["id"] for body in captured_graph.get("joins", [])}
                for identifier, body in captured_graph.get("elements", {}).items():
                    add(identifier, "element", field(name + ".elements"))
                    visit(body, field(name + ".elements." + identifier))
                for body in captured_graph.get("joins", []):
                    for ref in reference_fields(body):
                        ref = _captured_reference(ref, join_ids)
                        add(ref, ref.get("kind", None if ref.get("owner") else "element"), field(name + ".joins." + ref["field"]))
        portable = value.get("portable", {})
        if isinstance(portable, dict):
            for index, ref in enumerate(portable.get("knowledge_refs", [])):
                add(ref, "element", field(f"portable.knowledge_refs[{index}]"))
            for index, resource in enumerate(portable.get("files", [])):
                add(resource, "runtime_asset", field(f"portable.files[{index}]"))

    visit(record)
    return list({dumps(ref): ref for ref in result}.values())


def _captured_reference(reference, join_ids, author_owner=None):
    reference = dict(reference)
    if ("kind" not in reference and reference["ref"] in join_ids
            and ("owner" not in reference or reference["owner"] == author_owner)):
        reference["kind"] = "join"
    return reference


def _snapshot_members(inference, focal, author_owner):
    refs = [{"ref": identifier, "kind": "element", "field": "inference.elements"}
            for identifier in set(inference.get("elements", {})) | {focal}]
    join_ids = {join["id"] for join in inference.get("joins", [])}
    refs.extend(dict(_captured_reference(ref, join_ids, author_owner), field="inference.joins." + ref["field"])
                for join in inference.get("joins", []) for ref in reference_fields(join))
    return refs


def project_closure(snapshot, project_id, execution_roots=()):
    """Select complete current incident closure and separate historical evidence."""
    if isinstance(snapshot, dict):
        snapshot = DictionarySnapshot(snapshot)
    project_owner = project_id if project_id.startswith("project:") else "project:" + project_id
    owners = {project_owner, "global"}
    graphs = {owner: {"elements": {}, "joins": [], "observations": []} for owner in owners}
    queue = deque()
    visited, expanded = set(), set()
    unresolved = {}
    evidence = {}
    archives, schemas, assets = {}, {}, {}
    dependencies = getattr(snapshot, "dependencies", execution_dependencies)

    def issue(origin, ref, reason):
        item = {"from": asdict(origin), "field": ref.get("field", "root"),
                "ref": ref["ref"], "reason": reason}
        if ref.get("owner") is not None:
            item["requested_owner"] = ref["owner"]
        unresolved[dumps(item)] = item

    def enqueue(ref, origin):
        if isinstance(ref, str):
            ref = {"ref": ref}
        keys = snapshot.resolve(ref, origin.owner)
        for key in keys:
            queue.append((key, origin, ref))

    def retain_observation(owner, observation):
        identity = (owner, observation["id"])
        if identity not in evidence:
            evidence[identity] = observation
            graphs[owner]["observations"].append(observation)

    for key in snapshot.roots(project_owner):
        queue.append((key, key, {"ref": key.id, "field": "root"}))
    for observation in snapshot.owner_observations(project_owner):
        retain_observation(project_owner, observation)
    execution_origin = RecordKey(project_owner, "execution", project_id)
    for root in execution_roots:
        if isinstance(root, RecordKey):
            queue.append((root, execution_origin, {"ref": root.id, "owner": root.owner, "kind": root.kind}))
        elif isinstance(root, str) or "ref" in root:
            enqueue(root, execution_origin)
        else:
            for ref in execution_dependencies(root):
                enqueue(ref, execution_origin)

    def entry(target, key, body, provenance):
        identity = (key, digest(body))
        if identity not in target:
            target[identity] = {**asdict(key), "body": copy.deepcopy(body), "provenance": []}
        if provenance not in target[identity]["provenance"]:
            target[identity]["provenance"].append(provenance)

    while queue:
        key, origin, ref = queue.popleft()
        if key.owner not in owners:
            issue(origin, ref, "outside_project")
            continue
        body = snapshot.record(key)
        if _similarity(body) and key.kind == "join":
            continue
        # Report each referring field even when a missing key was already visited.
        if body is None:
            issue(origin, ref, "missing")
        if key.kind in {"schema", "runtime_asset"} and body is not None:
            entry(schemas if key.kind == "schema" else assets, key, body, asdict(origin))
        if key in visited:
            continue
        visited.add(key)
        if key.kind == "element" and key.id not in expanded:
            expanded.add(key.id)
            queue.extend((incident, incident, {"ref": incident.id, "field": "incident"})
                         for incident in snapshot.incident_element(key.id, owners))
        elif key.kind == "join":
            queue.extend((incident, incident, {"ref": incident.id, "field": "incident"})
                         for incident in snapshot.incident_join(key, owners))
        if body is None:
            continue
        if key.kind == "element":
            graphs[key.owner]["elements"][key.id] = body
            for owner in sorted(owners - {key.owner}):
                variant = RecordKey(owner, "element", key.id)
                if snapshot.record(variant) is not None:
                    queue.append((variant, key, {"ref": key.id, "field": "owner_variant"}))
            observations = snapshot.source_observations(key)
            for observation in observations:
                retain_observation(key.owner, observation)
            completions = [o for o in observations if o["source"] == "archaeology-complete" and "inference" in o["record"]]
            if completions:
                latest = max(completions, key=lambda o: (o.get("created", ""), o["id"]))
                for member in _snapshot_members(latest["record"]["inference"], key.id, key.owner):
                    enqueue(member, key)
        elif key.kind == "join":
            graphs[key.owner]["joins"].append(body)
            for member in reference_fields(body):
                enqueue(member, key)
        for dep in dependencies({"schema": body} if key.kind == "schema" else body):
            enqueue(dep, key)

    # Evidence closure follows explicit refs only, never current incidence.
    archive_queue = deque()
    historical_seen = set()
    captured = defaultdict(dict)
    for (owner, identifier), observation in evidence.items():
        provenance = {"owner": owner, "kind": "observation", "id": identifier}
        inference = observation["record"].get("inference", {})
        for name, body in inference.get("elements", {}).items():
            key = RecordKey(owner, "element", name)
            captured[(owner, identifier)][key] = body
        for body in inference.get("joins", []):
            key = RecordKey(owner, "join", body["id"])
            captured[(owner, identifier)][key] = body
        for key, body in captured[(owner, identifier)].items():
            archive_queue.append((key, body, provenance, (owner, identifier)))
        for dep in dependencies({name: body for name, body in observation["record"].items() if name != "inference"}):
            local_key = RecordKey(dep.get("owner", owner), dep.get("kind", "element"), dep["ref"])
            keys = [local_key] if local_key in captured[(owner, identifier)] else snapshot.resolve(dep, owner)
            for key in keys:
                archive_queue.append((key, None, provenance, (owner, identifier)))
    archived_bodies = {RecordKey(item["owner"], item["kind"], item["id"]): item["body"]
                       for item in getattr(snapshot, "archive_dependencies", [])}
    while archive_queue:
        key, body, provenance, context = archive_queue.popleft()
        ref = {"ref": key.id, "owner": key.owner, "field": "archive_dependency"}
        origin = RecordKey(**provenance)
        if key.owner not in owners:
            issue(origin, ref, "outside_project")
            continue
        if body is None:
            body = captured[context].get(key)
            if body is None:
                body = snapshot.record(key)
            if body is None:
                body = archived_bodies.get(key)
        if body is None:
            issue(origin, ref, "missing")
            continue
        target = schemas if key.kind == "schema" else assets if key.kind == "runtime_asset" else archives
        entry(target, key, body, provenance)
        identity = (key, digest(body), context)
        if identity in historical_seen:
            continue
        historical_seen.add(identity)
        refs = dependencies({"schema": body} if key.kind == "schema" else body)
        if key.kind == "join":
            refs = list(reference_fields(body)) + list(refs)
        for dep in refs:
            # Captured reified joins retain their original identities even after
            # their current record has disappeared.
            explicit_owner = dep.get("owner", key.owner)
            possible = [RecordKey(explicit_owner, kind, dep["ref"])
                        for kind in ([dep["kind"]] if dep.get("kind") else ["element", "join"])]
            found = [candidate for candidate in possible if candidate in captured[context]]
            for resolved in found[:1] or snapshot.resolve(dep, key.owner):
                archive_queue.append((resolved, None, provenance, context))

    for graph in graphs.values():
        graph["elements"] = dict(sorted(graph["elements"].items()))
        graph["joins"].sort(key=lambda j: j["id"])
        graph["observations"].sort(key=lambda o: (o.get("created", ""), o["id"]))
    for partition in (archives, schemas, assets):
        for item in partition.values():
            item["provenance"].sort(key=dumps)
    local = graphs[project_owner]
    return {"revision": snapshot.revision, "knowledge_digest_version": 2,
            "project": local, "global": graphs["global"],
            "archive_dependencies": sorted(archives.values(), key=dumps),
            "similarity": compare(scoped_export(local, "native"), scoped_export(local, "archaeology"),
                                  owner=project_owner, resolve=snapshot.resolve),
            "schemas": sorted(schemas.values(), key=dumps),
            "runtime_assets": sorted(assets.values(), key=dumps),
            "unresolved": sorted(unresolved.values(), key=dumps)}


def selected_digest(snapshot, runs=(), *, home=None, project=None):
    """Version-2 digest of selected source/evidence and normalized saved runs."""
    roots = [(str(root), symbol) for root, symbol in ((home, "$home"), (project, "$project")) if root is not None]

    def normalize(run):
        if not roots:
            return copy.deepcopy(run)
        from .portable import relocate_run

        if isinstance(run.get("body"), dict):
            return dict(run, body=relocate_run(run["body"], roots, normalize=True))
        return relocate_run(run, roots, normalize=True)

    selected = {name: copy.deepcopy(snapshot.get(name, []))
                for name in ("project", "global", "archive_dependencies", "schemas")}
    for name in ("project", "global"):
        for field in ("joins", "observations"):
            selected[name][field] = sorted(selected[name].get(field, []), key=dumps)
    for name in ("archive_dependencies", "schemas"):
        selected[name] = sorted(selected[name], key=dumps)
    selected["runs"] = sorted((normalize(run) for run in runs), key=dumps)
    selected["knowledge_digest_version"] = 2
    return digest(selected)
