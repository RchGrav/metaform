"""Authored inference instructions and the exact inputs used to exercise them."""

from __future__ import annotations

import copy
import importlib.resources
from pathlib import Path
import json

from .util import digest, now

INTAKE_RULE_CODES = ["r1", "r2", "r3", "r4", "r5"]
LEGACY_INTAKE_REVISIONS = {
    "prompt:metaform.intake.native": {
        "54449ba7e309d60998d63e9ce290089397d01c1404525c9d657e134037d785fe",
        "058f1f255f2f149d2f7176dfac552862f44cff05b0e7f6df57ca8e14b94f314d",
        "d41f556615d7da4f90b8f9085eb060ceba6d88fe9bf4dea3f1f7849fbc277b7b",
        "80232033604ad5b7d561ff922210906cf2832ce677356f3e2c2323bb7f3b9b2c",
        "552cca93e9fb404dc2304b334897a70328c3c04b313e76d6b98ec05ad6c50304",
        "5d0aa69282d0ab1e3636c7cc826e36bd4aa5ba08559ec67ee1a8a4102ea14d46",
        "24349c2e8dd3fbdf9fdfd76e96cd1f1c97ed8c949df54dcc476e360b3acce463",
        "76f899b40d055935cca7f3d7422548df65487e169d4770af57fc06c7f7c470c8",
        "db6b6641e40cbbafd54cbbe4329a73e432997cf5d891250df2383dbda18b15da",
        "0bb5648b0e23a5e79cd5508b359c5b87a59d0d5c91fab92261fe2674c1a6933e",
        "eb88a6a858cec14dba64fbdf44651781f6de1f18f1eae349c285f7d0e7034059",
        "b2a9f8ba78955a2b6a2468bf1e6dd9374cd05a33277020e27faecc46d59a6924",
        "048eec417a0f1af3a4aa5ce2c91fd6b7b525dca0f15c181bbe7f7b060485c5ac",
        "a330ff6b94e50ee9ddad73e493fef3154c6b38271b5b63b4a6939b2b0761a3b8",
    },
    "prompt:metaform.intake.archaeology": {
        "8fc786662c14edfacdd6f801f1c1df6c5b2ffdef8f50473379e8bdb0a6421c77",
        "81c16b6909c20d815b65ca97fc085badfcc0002f23ffc5f3f15f556ae393bf93",
        "8200946ddeccf3835d66be54d5b601ab99f048cd0f8d921df0cccac8b1c84711",
        "3b4485a1f80c829240f6339f6901b7683a7bbcf3577931ec7d589bbdca744daf",
        "58f78cd029ca5e332dba45b9a5bb21b60ab3b13fca52cb8d319c075662c4df35",
        "f3f504fbef9c745ce8783b5c037fe1d52ec4996e929e2898a2abc245017bc0df",
        "a43ca0f7c1698d3e3e3a66d45ffcf33efea101cd176b6386850a47a0bd09a6e6",
        "1a3ec7258b20c6b7f50fbf9ea7047a7d92375036e7023b1359e1592c0dad27da",
        "3bdabc17bd13fc6a967d4cb15e96f5d8df4bbb872ab434576ecebae0fd8c172e",
        "ffe46efb00809804d9158ab7a0ed6c7bf75cad1f91b2e767b7a6158d48407c9e",
        "41ef3fd08c1ee87a223a56d8b88c617ec23635ea936ccc96045dd41d7b8eb041",
    },
    "prompt:metaform.intake.proof": {
        "cb0094fe95e15c69cdc4da6c7317a74a91ba4cb2296dc1d5158bbac2a3b813dd",
        "42dc6ba39705abb5a3ef81ec5801d3b0f5da07b2f3c18870736dcad31559b960",
        "b5782a5849716a574a43135fc32c4d7e184bccc7f587ca009ed4a41574b865d6",
        "da7c9a42d59e954c7984d3a4931a066fc8a6b0e2bc0777b18d3b347f04cba057",
        "793759e5c2ca69b8614da2e9fb21ff16b6f9182eb75a0b828ea3578cc51eace5",
        "ec950109b1d43d85230852ae714a64fa017014be349dbe9759f28529c1d09d24",
        "8b395b740ba07a0f6367db7ab24edba6fd2d0fb2813584e2be722fcc9c0aa35e",
    },
}


def semantic_equations():
    text = (
        importlib.resources.files("metaform")
        / "data" / "semantics" / "semantic-equation-reuse.md"
    ).read_text()
    return {
        "source": "docs/semantics/semantic_equation_reuse_rule.md",
        "text": text,
        "revision": digest(text),
    }


def seed(app):
    data = importlib.resources.files("metaform") / "data"
    documents = (
        json.loads((data / "prompts.json").read_text())
        if (data / "prompts.json").is_file()
        else []
    )
    definition = role_definitions()
    for role, spec in definition["roles"].items():
        text = (data / "roles" / spec["prompt"]).read_text(encoding="utf-8")
        documents.append({
            "id": role_prompt_id(role), "name": {"intake": "Coarse artifact intake",
                "blindspots": "Outside-in blind-spot analysis"}.get(role, role),
            "text": text, "rule_codes": spec.get("rule_codes", []), "components": spec["components"],
            "schema": spec["output_schema"], "contract_version": "2",
            "managed": {"role": role, "revision": digest(text), "source": spec["prompt"],
                        "components": spec["components"], "schema": spec["output_schema"],
                        "rule_codes": spec.get("rule_codes", [])},
        })
    changed = {}
    for prompt in documents:
        stored = app.graph.get(prompt["id"])
        if not stored:
            changed[prompt["id"]] = _record(prompt)
            continue
        current = stored["entity_json_obj"]
        revision = digest(current["text"])
        managed = current.get("managed", {})
        if (revision in LEGACY_INTAKE_REVISIONS.get(prompt["id"], set())
                or managed.get("revision") == revision):
            updated = dict(current, **{key: value for key, value in prompt.items()
                                      if key not in {"name", "rule_codes"}})
            for key in ("components", "schema"):
                if key in managed and current.get(key) != managed[key]:
                    updated[key] = current.get(key)
            if managed and current.get("rule_codes", []) == managed.get("rule_codes", []):
                updated["rule_codes"] = prompt["rule_codes"]
            if current.get("rule_codes") == INTAKE_RULE_CODES and current.get("contract_version") != "2":
                updated["rule_codes"] = prompt["rule_codes"]
            if current.get("name") in {"Contextual intake", "Native Expert", "Latent archaeology",
                                       "Latent Expert", "Coarse artifact intake", "Outside-in blind-spot analysis"}:
                updated["name"] = prompt["name"]
            if updated != current:
                changed[prompt["id"]] = _record(updated)
    if changed:
        app.graph.put({"elements": changed}, "authored", "prompts")


def role_definitions():
    return json.loads((importlib.resources.files("metaform") / "data" / "roles"
                       / "composition.json").read_text(encoding="utf-8"))


def role_prompt_id(role):
    return {"intake": "prompt:metaform.intake.native",
            "blindspots": "prompt:metaform.intake.archaeology"}.get(role, "prompt:metaform.role." + role)


def _composition_provenance(authored, spec, components, source_schema):
    from difflib import unified_diff
    from . import schemas

    data = importlib.resources.files("metaform") / "data" / "roles"
    managed = {
        "text": (data / spec["prompt"]).read_text(encoding="utf-8"),
        "rule_codes": spec.get("rule_codes", []),
        "schema": {"reference": spec["output_schema"],
                   "document": schemas.builtins()[spec["output_schema"].split("#", 1)[0]]},
        "components": [{"id": component, "source": component,
                        "text": (data / component).read_text(encoding="utf-8")}
                       for component in spec["components"]],
    }
    selected = {
        "text": authored["text"],
        "rule_codes": authored.get("rule_codes", []),
        "schema": {"reference": authored.get("schema") or spec["output_schema"], "document": source_schema},
        "components": [{key: component[key] for key in ("id", "source", "text")} for component in components],
    }
    differences = []
    for field, current in selected.items():
        baseline = managed[field]
        if current == baseline:
            continue
        before = baseline if isinstance(baseline, str) else json.dumps(baseline, indent=2, sort_keys=True, ensure_ascii=False)
        after = current if isinstance(current, str) else json.dumps(current, indent=2, sort_keys=True, ensure_ascii=False)
        report = "".join(unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                      fromfile="managed/" + field, tofile="authored/" + field, n=2))
        differences.append({"field": field, "managed_revision": digest(baseline),
                            "authored_revision": digest(current), "diff": report})
    return {"managed": authored.get("managed"), "authored_override": bool(differences),
            "composition_status": "authored_override" if differences else (
                "managed" if authored.get("managed") else "matches_managed_template"),
            "differences": differences}


def compose_role(app, role, inputs):
    """Snapshot a focused role, retaining source instructions separately from data."""
    from . import schemas

    definitions = role_definitions()
    spec = definitions["roles"][role]
    identifier = role_prompt_id(role)
    authored = get(app, identifier)
    prepared = snapshot(app, identifier)
    data = importlib.resources.files("metaform") / "data" / "roles"
    components = []
    for component in dict.fromkeys(authored.get("components", spec["components"])):
        override = app.config.get("semantic_sources", {}).get("aliases") if component == "components/aliases.md" else None
        source = str(override) if override else component
        text = Path(override).read_text(encoding="utf-8") if override else (data / component).read_text(encoding="utf-8")
        components.append({"id": component, "revision": digest(text), "text": text, "source": source})
    schema_ref = authored.get("schema") or spec["output_schema"]
    output_schema = schemas.bundled(app, schema_ref)
    source_schema = copy.deepcopy(schemas.registry(app)[schema_ref.split("#", 1)[0]]) if isinstance(schema_ref, str) else copy.deepcopy(schema_ref)
    return copy.deepcopy(prepared | {
        "role": role, "contract_version": "2", "components": components,
        "prompt": "\n\n".join([prepared["source_prompt"], *(c["text"] for c in components)]),
        "schema_ref": schema_ref, "schema": output_schema,
        "output_schema": source_schema, "output_schema_revision": digest(source_schema),
        "inputs": inputs, "composition": {"version": definitions["version"],
            "revision": digest(spec), "definition": spec},
        "provenance": _composition_provenance(authored, spec, components, source_schema),
    })


def grounding_context(app, arguments, task):
    """Prepare the common selected-region view and retain its revisioned inputs."""
    from .models import list_models
    from .read_model import read_model

    if arguments.get("model") is None and arguments.get("target") is None and not list_models(app):
        return None
    selected = {key: copy.deepcopy(arguments[key]) for key in ("model", "depth", "limit", "max_chars", "layers") if key in arguments}
    selected.update(target=arguments.get("target", arguments.get("focal")), task=task)
    envelope = read_model(app, "model.ground", selected)
    identifier = "context:" + digest(envelope)
    if app.get(identifier) is None:
        app.set(identifier, envelope)
    return {"context_ref": identifier, "region": envelope, "model": envelope["model"],
            "targets": [envelope["resolved_target"]] if envelope.get("resolved_target") else [],
            "context_dependencies": copy.deepcopy(envelope["dependencies"])}


def inference_payload(assignment):
    """Keep exact provenance in storage and send each composed instruction once."""
    payload = copy.deepcopy(assignment)
    if payload.get("contract_version") == "2":
        if payload.get("source_prompt") and payload["source_prompt"] in payload.get("prompt", ""):
            payload.pop("source_prompt")
        for component in payload.get("components", []):
            if component.get("text") and component["text"] in payload.get("prompt", ""):
                component.pop("text")
        payload.pop("output_schema", None)
        payload.pop("composition", None)
        payload.get("provenance", {}).pop("differences", None)
    if payload.get("role") == "knowledge-tool":
        for context in payload.get("inputs", {}).get("contexts", {}).values():
            for origin in context.get("property_context", []):
                origin.pop("path", None)
                origin.pop("visibility_path", None)
    return payload


def _record(prompt):
    identifier = prompt["id"]
    data = dict(prompt)
    data["en"] = data.get("name", identifier)
    data["revision"] = digest(data["text"])
    return {
        "entity_desc": data.get("description", data["en"]),
        "entity_schema": "metaform:prompt",
        "entity_json_obj": data,
    }


def put(app, prompt):
    record = _record(prompt)
    app.graph.put({"elements": {prompt["id"]: record}}, "authored", "prompts")
    return record


def get(app, identifier):
    record = app.graph.get(identifier) or app.global_graph.get(identifier)
    if record is None:
        raise ValueError(f"Unknown prompt: {identifier}")
    prompt = record["entity_json_obj"]
    if identifier in {
        "prompt:metaform.intake.native", "prompt:metaform.intake.proof",
        "prompt:metaform.intake.archaeology"
    }:
        # Older stored intake prompts receive the established rules without
        # replacing their authored text. Explicit attachments remain editable.
        prompt.setdefault("rule_codes", list(INTAKE_RULE_CODES))
    return prompt


def snapshot(app, identifier):
    from . import rulebook

    prompt = get(app, identifier)
    return {
        "prompt_ref": identifier,
        "prompt_revision": digest(prompt["text"]),
        "source_prompt": prompt["text"],
        "schema": prompt.get("schema"),
        "rules": rulebook.prepare(app, prompt.get("rule_codes", [])),
    }


def assemble(app, focal, depth=None, scope=None, category=None):
    if getattr(app, "knowledge", None) is not None:
        return app.knowledge.call("knowledge.assemble", {
            "focal": focal, "depth": depth, "scope": scope, "category": category,
        })
    return app.graph.assemble(focal, depth, scope, category)


def prepare(app, identifier, inputs=None, focal=None, depth=None):
    from .workflow import render

    prepared = snapshot(app, identifier)
    values = inputs or {}
    role = next((role for role in role_definitions()["roles"] if role_prompt_id(role) == identifier), None)
    if role is not None:
        composed = compose_role(app, role, values)
        prepared.update({key: composed[key] for key in ("composition", "provenance")})
    try:
        rendered = render(prepared["source_prompt"], values)
    except ValueError as error:
        # Preparation is an editor preview; an executable workflow still renders
        # its declared template with complete inputs when it issues the job.
        rendered = prepared["source_prompt"]
        prepared["annotations"] = [{"kind": "missing_template_input", "message": str(error)}]
    return prepared | {
        "prompt": rendered,
        "inputs": values,
        "graph": assemble(app, focal, depth) if focal else {},
    }


def record_test(app, prepared, answer, note=""):
    identifier = "test:" + app.identifier()
    record = {
        "entity_desc": "Prompt test",
        "entity_schema": "metaform:prompt-test",
        "entity_json_obj": {
            "en": "Test",
            "prepared": prepared,
            "answer": answer,
            "note": note,
            "created": now(),
        },
    }
    app.graph.put(
        {
            "elements": {identifier: record},
            "joins": [
                {
                    "object_id": prepared["prompt_ref"],
                    "element_id": identifier,
                    "type": "prompt_test",
                    "purpose": "Observe the response to this prompt revision",
                }
            ],
        },
        "test",
        "tests",
    )
    return {"id": identifier, **record["entity_json_obj"]}
