"""Parent-linked work versions containing ordinary, independently extractable files."""

from __future__ import annotations

import difflib
import fnmatch
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import tarfile
from pathlib import Path

from filelock import FileLock

from .util import digest, now, read_json, write_json
from .locking import snapshot_locked


def root(app):
    path = app.root / "history"
    path.mkdir(parents=True, exist_ok=True)
    return path


def safe_path(root, relative):
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"Archive path escapes its destination: {relative}")
    result = root / path
    if not result.parent.resolve().is_relative_to(root.resolve()):
        raise ValueError(
            f"Archive path crosses a link outside its destination: {relative}"
        )
    return result


def excluded(relative, patterns):
    path = Path(relative)
    return any(
        fnmatch.fnmatch(candidate.as_posix(), pattern)
        for candidate in (path, *path.parents)
        if candidate != Path(".")
        for pattern in patterns
    )


def scan(folder, excludes=()):
    result = {}
    folder = Path(folder)
    for parent, directories, files in os.walk(folder, followlinks=False):
        parent = Path(parent)
        directories[:] = [
            d
            for d in directories
            if not excluded((parent / d).relative_to(folder), excludes)
        ]
        names = files + [d for d in directories if (parent / d).is_symlink()]
        for name in names:
            path = parent / name
            relative = path.relative_to(folder).as_posix()
            if excluded(relative, excludes):
                continue
            mode = stat.S_IMODE(path.lstat().st_mode)
            if path.is_symlink():
                result[relative] = {"symlink": os.readlink(path), "mode": mode}
            elif path.is_file():
                result[relative] = {
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "mode": mode,
                }
    return result


def exclusions(app):
    return [".git", ".metaform", ".agentid", *app.config.get("history_exclude", [])]


def copy_entry(source, destination, info):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if "symlink" in info:
        # Link targets remain metadata until a reconstructed working copy is requested.
        return
    shutil.copyfile(source, destination)
    destination.chmod(info["mode"])


def initialize(app):
    directory = root(app)
    file = directory / "manifest.json"
    if file.exists():
        return read_json(file)
    origin = directory / "origin"
    origin.mkdir(exist_ok=True)
    commit = None
    baseline_kind = "working_directory"
    if shutil.which("git"):
        result = subprocess.run(
            ["git", "-C", str(app.project), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
        )
        if (
            result.returncode == 0
            and Path(result.stdout.strip()).resolve() == app.project
        ):
            sha = subprocess.run(
                ["git", "-C", str(app.project), "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
            )
            archive = subprocess.run(
                ["git", "-C", str(app.project), "archive", "HEAD"], capture_output=True
            )
            if sha.returncode == archive.returncode == 0:
                commit = sha.stdout.strip()
                baseline_kind = "git_commit"
                with tarfile.open(fileobj=io.BytesIO(archive.stdout)) as tar:
                    for entry in tar.getmembers():
                        if excluded(entry.name, exclusions(app)):
                            continue
                        target = safe_path(origin, entry.name)
                        if entry.isdir():
                            target.mkdir(parents=True, exist_ok=True)
                        elif entry.isfile():
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.write_bytes(tar.extractfile(entry).read())
                            # Git records the executable bit; git archive's group
                            # write bit is a tar default, not a source mode change.
                            target.chmod(0o755 if entry.mode & 0o111 else 0o644)
                        elif entry.issym():
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.symlink_to(entry.linkname)
    if baseline_kind == "working_directory":
        files = scan(app.project, exclusions(app))
        for name, info in files.items():
            copy_entry(app.project / name, safe_path(origin, name), info)
    else:
        files = scan(origin)
        for name, info in files.items():
            if "symlink" in info:
                (origin / name).unlink()
    sha = digest(files)
    manifest = {
        "format": "metaform-history/1",
        "origin_sha256": sha,
        "mform_sha_id": sha + "_0000",
        "mform_id": sha[:12] + "0000",
        "suffix": 0,
        "base_commit": commit,
        "baseline_kind": baseline_kind,
        "created": now(),
        "origin": files,
        "versions": {},
        "head": "origin",
    }
    write_json(file, manifest)
    return manifest


def files_at(manifest, version):
    if version == "origin":
        return {
            name: info | {"stored": "origin/" + name}
            for name, info in manifest["origin"].items()
        }
    entry = manifest["versions"][version]
    files = files_at(manifest, entry["parent"])
    for name, info in entry["changes"].items():
        if info is None:
            files.pop(name, None)
        else:
            files[name] = info | {"stored": "versions/" + version + "/files/" + name}
    return files


@snapshot_locked
def checkpoint(app, name="", parent=None, provenance=None, captured=None):
    captured = captured or capture_knowledge(app)
    directory = root(app)
    with FileLock(directory / "history.lock"):
        manifest = initialize(app)
        parent = parent or manifest["head"]
        before = {
            p: {k: v for k, v in r.items() if k != "stored"}
            for p, r in files_at(manifest, parent).items()
        }
        after = scan(app.project, exclusions(app))
        changes = {
            p: after.get(p)
            for p in sorted(before.keys() | after.keys())
            if before.get(p) != after.get(p)
        }
        identifier = app.identifier()
        entry = {
            "id": identifier,
            "parent": parent,
            "name": name or "Checkpoint",
            "created": now(),
            "changes": changes,
            "provenance": provenance or {},
            "knowledge_digest": captured["digest"],
            "knowledge_digest_version": 2,
            "invocation": str(app.invocation),
            "target": str(app.project),
        }
        for path, info in changes.items():
            if info is not None:
                copy_entry(
                    app.project / path,
                    safe_path(directory / "versions" / identifier / "files", path),
                    info,
                )
        write_json(
            directory / "versions" / identifier / "metaform.json", captured["closure"]["project"]
        )
        write_json(directory / "versions" / identifier / "global.json", captured["closure"]["global"])
        write_json(directory / "versions" / identifier / "knowledge.json", captured["closure"])
        write_json(directory / "versions" / identifier / "provenance.json", entry)
        manifest["versions"][identifier] = entry
        manifest["head"] = identifier
        write_json(directory / "manifest.json", manifest)
    app.event(
        "history.checkpoint",
        {"version": identifier, "parent": parent, "changes": len(changes)},
    )
    return entry


def normalized_runs(app, state):
    """Normalize executable locations and nonce material, retaining authored answers."""
    from .portable import relocate_run

    mappings = [(str(app.home), "$home"), (str(app.project), "$project")]
    runs = []
    for row in sorted(state["runs"], key=lambda r: r["id"]):
        body = relocate_run(json.loads(row["body"]), mappings, normalize=True)
        runs.append({"id": row["id"], "body": body})
    return runs


@snapshot_locked
def capture_knowledge(app, state=None):
    from .portable import state_dump
    from .knowledge_export import execution_dependencies, selected_digest

    state = state if state is not None else state_dump(app)
    roots = []
    for row in state["runs"]:
        run = json.loads(row["body"])
        # Intake is a chassis lifecycle rather than an imported workflow record.
        # Retain its captured jobs and semantic dependencies as execution roots.
        if run.get("kind") == "intake":
            run.pop("workflow", None)
        roots.extend(execution_dependencies(run))
    from .registry import Registry
    registry = Registry(app)
    assets = registry.portable_dependencies(app.config.get("portable_modules", []))
    roots.extend(assets["knowledge_refs"])
    roots.extend({"kind": "runtime_asset", "ref": "module:" + module["id"]} for module in assets["modules"])
    runtime_assets = registry.portable_manifests()
    closure = app.knowledge.call("knowledge.snapshot", {
        "execution_roots": roots, "runtime_assets": runtime_assets,
    })
    module_ids = {entry["body"]["id"] for entry in closure.get("runtime_assets", []) if "id" in entry["body"]}
    module_ids.update(app.config.get("portable_modules", []))
    assets = registry.portable_dependencies(module_ids)
    return {"state": state, "closure": closure, "modules": assets, "digest": selected_digest(closure, normalized_runs(app, state))}


def knowledge_digest(app, version=2):
    if version == 1:
        return legacy_knowledge_digest(app)
    return capture_knowledge(app)["digest"]


def legacy_knowledge_digest(app):
    """Compare existing v1 history without rewriting its recorded digest contract."""
    graph = app.graph.export()
    global_graph = app.global_graph.export()
    with app.db() as db:
        runs = []
        for row in db.execute("SELECT id,body FROM runs ORDER BY id"):
            body = json.loads(row["body"])
            job = body.get("pending")
            if job:
                job.pop("nonce", None)
                job.pop("begin", None)
            if job and job.get("workfolder"):
                path = Path(job["workfolder"])
                for root_path, symbol in [
                    (app.home, "$home"),
                    (app.project, "$project"),
                ]:
                    if path.is_relative_to(root_path):
                        job["workfolder"] = (
                            symbol + "/" + path.relative_to(root_path).as_posix()
                        )
                        break
            runs.append({"id": row["id"], "body": body})
    return digest(
        {
            "project": {k: graph[k] for k in ("elements", "joins")},
            "global": {k: global_graph[k] for k in ("elements", "joins")},
            "runs": runs,
        }
    )




def reconstruct(app, version, destination, pending_symlinks=None):
    directory = root(app)
    manifest = initialize(app)
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    for relative, info in files_at(manifest, version).items():
        path = safe_path(destination, relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        if "symlink" in info:
            if pending_symlinks is not None:
                pending_symlinks.append((path, info["symlink"]))
                continue
            if path.exists() or path.is_symlink():
                path.unlink()
            path.symlink_to(info["symlink"])
        else:
            source = safe_path(directory, info["stored"])
            if hashlib.sha256(source.read_bytes()).hexdigest() != info["sha256"]:
                raise ValueError(f"Stored file is damaged: {relative}")
            copy_entry(source, path, info)
    return {"version": version, "path": str(destination)}


def diff(app, version):
    directory = root(app)
    manifest = initialize(app)
    if version == "origin":
        return {"version": version, "files": []}
    entry = manifest["versions"][version]
    before = files_at(manifest, entry["parent"])
    after = files_at(manifest, version)
    output = []
    for name, info in entry["changes"].items():
        item = {
            "path": name,
            "status": "deleted"
            if info is None
            else "added"
            if name not in before
            else "modified",
        }
        try:
            old = (
                (directory / before[name]["stored"]).read_text()
                if name in before and "symlink" not in before[name]
                else ""
            )
            new = (
                (directory / after[name]["stored"]).read_text()
                if name in after and "symlink" not in after[name]
                else ""
            )
            item["diff"] = "".join(
                difflib.unified_diff(
                    old.splitlines(True), new.splitlines(True), "a/" + name, "b/" + name
                )
            )
            if "\0" in old or "\0" in new:
                item.pop("diff")
                item["binary"] = True
        except UnicodeError:
            item["binary"] = True
        output.append(item)
    return {"version": version, "parent": entry["parent"], "files": output}


def inclusive(local, incoming):
    return local["origin_sha256"] == incoming["origin_sha256"] and all(
        incoming["versions"].get(k) == v for k, v in local["versions"].items()
    )
