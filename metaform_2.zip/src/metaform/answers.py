"""Read a model's XML answer into the shape the expansion consumes.

The reader never rejects an answer and never raises on one: the contract describes a shape, and whatever came
back is made to fit while every mismatch is recorded for observation (SPEC section 14). When a document is cut
short, the records that closed are still read and the document is marked incomplete. That salvage is the reason
an answer is XML: a truncated answer loses the record it was writing, not the whole intake.

The document's own vocabulary is kept. `ef_ref` on a join names the element whose Encounter Function satisfies
the receiver's Operative Purpose, and it is read into `provider`.
"""

import re
import xml.etree.ElementTree as ET

RECORDS = ("artifact", "element", "join", "subtype")


def read(text):
    """The answer as a dict: artifact, elements, joins, subtypes, mismatches, and whether it parsed whole."""
    mismatches = []
    try:
        nodes = [ET.fromstring(text)]
        complete = True
    except ET.ParseError as error:
        complete = False
        mismatches.append({"code": "incomplete_document", "message": str(error),
                           "detail": "The document did not parse whole; the records that closed were read."})
        nodes = _salvaged(text, mismatches)

    artifact, elements, joins, subtypes = None, [], [], []
    for node in nodes:
        for found in _each(node, "artifact"):
            artifact = artifact or _artifact(found)
        for found in _each(node, "element"):
            elements.append(_element(found, mismatches))
        for found in _each(node, "join"):
            joins.append(_join(found, mismatches))
        for found in _each(node, "subtype"):
            address = found.get("namespace") or (found.text or "").strip() or None
            if address is None:
                mismatches.append({"code": "missing_field", "field": "namespace", "at": "subtype",
                                   "message": "A subtype is a full namespace address."})
                continue
            subtypes.append(address)

    known = {element["id"] for element in elements if element["id"]}
    for join in joins:
        # `re` is the id of the element bearing the OP, so it must be an element of this answer. `ef_ref` is the
        # id of the element or the shared EF type this join connects, so a name outside this answer is expected.
        if join["re"] is not None and join["re"] not in known:
            mismatches.append({"code": "unresolved_reference", "field": "re", "at": join["id"], "value": join["re"],
                               "message": "The receiving entity names an element this answer does not carry."})
    defining = [element["id"] for element in elements if element["role"] == "DE"]
    if len(defining) != 1:
        mismatches.append({"code": "unresolved_defining_element", "roots": defining,
                           "message": "The shape names exactly one Defining Element; this answer names %d."
                                      % len(defining)})
    return {"artifact": artifact, "elements": elements, "joins": joins, "subtypes": subtypes,
            "mismatches": mismatches, "complete": complete}


def _each(node, name):
    return [node] if node.tag == name else node.iter(name)


def _salvaged(text, mismatches):
    """Every complete record in a document that did not parse whole, in the order it was written."""
    found = []
    for name in RECORDS:
        pattern = r"<%s\b[^>]*/>|<%s\b[^>]*>.*?</%s>" % (name, name, name)
        for match in re.finditer(pattern, text, re.DOTALL):
            try:
                found.append((match.start(), ET.fromstring(match.group(0))))
            except ET.ParseError as error:
                mismatches.append({"code": "unreadable_record", "at": name, "message": str(error)})
    return [node for _, node in sorted(found, key=lambda item: item[0])]


def _text(node, name):
    found = node.find(name)
    return None if found is None or found.text is None else found.text.strip()


def _required(value, field, at, mismatches):
    if value is None:
        mismatches.append({"code": "missing_field", "field": field, "at": at,
                           "message": "The answer carries no %s for this record." % field})
    return value


def _artifact(node):
    return {"type": node.get("type"), "name": node.get("name"), "description": (node.text or "").strip() or None}


def _element(node, mismatches):
    identifier = node.get("id")
    length = node.get("name_length")
    if length is not None and not str(length).lstrip("-").isdigit():
        mismatches.append({"code": "unexpected_value", "field": "name_length", "at": identifier, "value": length,
                           "message": "name_length is a lookback segment count within the address."})
        length = None
    return {"id": identifier,
            "role": _required(node.get("role"), "role", identifier, mismatches),
            "namespace": _required(node.get("namespace"), "namespace", identifier, mismatches),
            "name_length": int(length) if length is not None else None,
            "ef": _required(_text(node, "ef"), "ef", identifier, mismatches)}


def _join(node, mismatches):
    identifier = node.get("id")
    refs = {}
    for ref in node.iter("ref"):
        key = ref.get("key")
        if key is None:
            mismatches.append({"code": "missing_field", "field": "key", "at": identifier,
                               "message": "A reference is keyed by the name the artifact uses for it."})
            continue
        refs[key] = (ref.text or "").strip() or None
    combined = [{"entity": entity.get("name"), "relation": _text(entity, "relation"),
                 "observation": _text(entity, "observation")} for entity in node.iter("entity")]
    # The prompt requires a join to express re, ef_ref, op, relation and observation.
    return {"id": identifier,
            "re": _required(node.get("re"), "re", identifier, mismatches),
            "provider": _required(node.get("ef_ref") or node.get("provider"), "ef_ref", identifier, mismatches),
            "op": _required(_text(node, "op"), "op", identifier, mismatches),
            "relation": _required(_text(node, "relation"), "relation", identifier, mismatches),
            "observation": _required(_text(node, "observation"), "observation", identifier, mismatches),
            "refs": refs, "combined": combined}


def contribution(reading):
    """The reading as the contribution the coarse expansion consumes.

    The document names elements by a short id and places them by namespace address; the expansion works in
    addresses, so joins are resolved from ids to the addresses they name. The Defining Element is carried
    because the answer declares it with `role="DE"` and nothing then has to infer it.
    """
    address = {element["id"]: element["namespace"] for element in reading["elements"]
               if element.get("id") and element.get("namespace")}

    elements = {}
    for element in reading["elements"]:
        position = element.get("namespace")
        if not position:
            continue
        record = {"ef": element.get("ef") or ""}
        if element.get("name_length") is not None:
            record["name_length"] = element["name_length"]
        elements[position] = record

    joins = []
    for join in reading["joins"]:
        record = {"receiver": address.get(join.get("re"), join.get("re")),
                  "provider": address.get(join.get("provider"), join.get("provider")),
                  "purpose": join.get("op") or ""}
        for field in ("relation", "observation"):
            if join.get(field):
                record[field] = join[field]
        if join.get("refs"):
            record["refs"] = dict(join["refs"])
        combined = {entry["entity"]: {"relation": entry.get("relation"), "observation": entry.get("observation")}
                    for entry in join.get("combined") or [] if entry.get("entity")}
        if combined:
            record["combined"] = combined
        joins.append(record)

    declared = next((element for element in reading["elements"] if element.get("role") == "DE"), None)
    shape = {"elements": elements, "joins": joins, "subtypes": list(reading["subtypes"])}
    if declared is not None and declared.get("namespace"):
        shape["defining"] = declared["namespace"]
    return shape
