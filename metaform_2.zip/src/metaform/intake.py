"""Versioned artifact intake with resumable contribution and assignment snapshots."""

from __future__ import annotations

import copy
import importlib.resources
import json
from pathlib import Path

from . import schemas, workfolders
from .locking import run_locked
from .util import digest, now


def semantic_text(name):
    return (importlib.resources.files("metaform") / "data" / "semantics" / name).read_text(encoding="utf-8")


class Intake:
    def __init__(self, app):
        self.app = app

    def start(self, inputs=None):
        return self._start("native", contract_version="2", inputs=inputs)

    def examine(self, request="Examine this artifact for blind spots.", target=None, model=None):
        from .layers import blindspots
        return blindspots(self.app, request=request, target=target, model=model)

    def _start(self, stage, contract_version="1", inputs=None):
        run = {
            "id": self.app.identifier(), "workflow": "metaform.intake", "kind": "intake",
            "status": "running", "stage": stage, "contract_version": contract_version,
            "pending": None, "assignments": {}, "receipts": {}, "created": now(),
        }
        if contract_version == "2":
            run["model"] = {"project": self.app.project_id, "model": "model:" + self.app.identifier()}
            run["inputs"] = copy.deepcopy(inputs or {})
            from .change_report import capture
            artifact_context = run["inputs"].get("artifact_context")
            run["source_baseline"] = capture(self.app, run["id"],
                planned=isinstance(artifact_context, dict) and bool(artifact_context.get("plan")))
            run["contributions"] = {"types": {}, "elements": {}, "bindings": [],
                                    "narrowings": [], "refinements": [], "joins": []}
            run["submissions"] = []
            run["referenced_types"] = {record["owner"] + "|" + record["id"]: copy.deepcopy(record)
                                       for record in run["inputs"].get("reusable_types", {}).values()}
            from .coarse import bases
            from .models import adapt_type
            for identifier, record in bases().items():
                typed = adapt_type(self.app.global_graph.get(identifier), identifier, "global") or {"id": identifier, "owner": "global", **record}
                run["referenced_types"].setdefault("global|" + identifier, typed)
        if stage == "archaeology":
            run["native_graph"] = self._native_snapshot()
        self.app.save_run(run)
        self.app.enter("intake", run["id"])
        return self.next(run["id"])

    def _native_snapshot(self):
        graph = self.app.graph.export(scope="native")
        return {**copy.deepcopy(self.app.get("native_context") or {}),
                "elements": graph["elements"], "joins": graph["joins"],
                "references": self._references(graph)}

    def _references(self, native):
        from .knowledge import reference_fields
        from .graph import type_ids

        owner = "project:" + self.app.project_id
        stores = {owner: self.app.graph, "global": self.app.global_graph}
        known = {owner: {"elements": dict(native["elements"]),
                         "joins": {join["id"]: join for join in native["joins"]}}}
        captured = {}
        pending = [(owner, join) for join in native["joins"]]
        pending.extend(
            (owner, {"element_id": type_id})
            for record in native["elements"].values()
            for type_id in type_ids(record)
        )
        checked = set()
        while pending:
            author, join = pending.pop()
            for ref in reference_fields(join):
                owners = [ref["owner"]] if ref.get("owner") else list(dict.fromkeys([author, "global"]))
                for target in owners:
                    if target not in stores:
                        continue
                    kinds = [ref["kind"]] if ref.get("kind") else ["element", "join"]
                    found = False
                    for kind in kinds:
                        if kind not in {"element", "join"}:
                            continue
                        collection = kind + "s"
                        key = (target, kind, ref["ref"])
                        if ref["ref"] in known.get(target, {}).get(collection, {}):
                            found = True
                            break
                        if key in checked:
                            continue
                        checked.add(key)
                        store = stores[target]
                        record = store.get(ref["ref"]) if kind == "element" else next(
                            (item for item in store.joins(ref["ref"]) if item["id"] == ref["ref"]), None)
                        if record is None:
                            continue
                        known.setdefault(target, {"elements": {}, "joins": {}})[collection][ref["ref"]] = record
                        capture = captured.setdefault(target, {"elements": {}, "joins": []})
                        if kind == "element":
                            capture["elements"][ref["ref"]] = record
                            pending.extend((target, {"element_id": type_id})
                                           for type_id in type_ids(record))
                        else:
                            capture["joins"].append(record)
                            pending.append((target, record))
                        found = True
                        break
                    if found:
                        break
        for target, graph in captured.items():
            registered = schemas.registry(self.app, owner=target)
            graph["schemas"] = {identifier: schemas.bundled(self.app, identifier, owner=target)
                                for identifier in {r["entity_schema"] for r in graph["elements"].values()}
                                if identifier in registered}
        return captured

    def _assignment(self, run):
        from .continuation import publish
        from .prompts import snapshot

        if run.get("contract_version", "1") == "2":
            return self._foundation_assignment(run)
        native = run["stage"] == "native"
        prepared = snapshot(self.app, "prompt:metaform.intake." + run["stage"])
        from .prompts import get
        if (get(self.app, prepared["prompt_ref"]).get("contract_version") == "2"
                and get(self.app, prepared["prompt_ref"]).get("managed", {}).get("revision") == prepared["prompt_revision"]):
            source = semantic_text("legacy-native.md" if native else "archaeology.md")
            prepared.update(source_prompt=source, prompt_revision=digest(source))
        aliases = self.app.config.get("semantic_sources", {}).get("aliases")
        alias_text = Path(aliases).read_text(encoding="utf-8") if aliases else semantic_text("aliases.md")
        assignment = {
            **prepared, "contract_version": "1", "run_id": run["id"], "request_id": self.app.identifier(),
            "status": "awaiting_answer", "role": "native_expert" if native else "latent_expert",
            "prompt": prepared["source_prompt"] + "\n\n" + alias_text,
            "schema": schemas.bundled(self.app, "metaform:graph"),
            "context": "project" if native else "fresh", "inputs": {},
            "completion": (
                "Save the graph incrementally with intake.put as you construct it. "
                "The final JSON answer contains only unsaved Elements, joins, or context. "
                'When all work is saved, finish with {"elements": {}, "joins": []}. '
                "Saved records remain part of the completed pass and are included in the Native handoff."
            ),
            "tools": ["intake.search", "intake.get", "intake.put"],
            "source_status": {"aliases": "configured" if aliases else "bundled",
                              "aliases_revision": digest(alias_text)},
            "tool_bindings": {"Namespace search": "intake.search",
                              "Element and receiving-purpose relationships": "intake.get",
                              "author Elements and joins": "intake.put"},
        }
        assignment["inputs"]["schemas"] = {
            identifier: schemas.bundled(self.app, identifier)
            for identifier in ("metaform:element", "metaform:actual-element", "metaform:operative-purpose-join")
        }
        if native:
            assignment["workfolder"] = str(self.app.project)
            assignment["tools"].extend(["intake.files", "intake.read"])
            assignment["inputs"]["native"] = self._native_snapshot()
        else:
            assignment["system_prompt"] = semantic_text("latent-role.md")
            assignment["system_prompt_revision"] = digest(assignment["system_prompt"])
            assignment["inputs"]["native"] = copy.deepcopy(run["native_graph"])
            registered = schemas.registry(self.app)
            assignment["inputs"]["schemas"].update({
                identifier: schemas.bundled(self.app, identifier)
                for identifier in sorted({r["entity_schema"] for r in run["native_graph"]["elements"].values()})
                if identifier in registered
            })
            folder = workfolders.create(self.app, empty=True)
            assignment.update(workfolder=folder["path"], workfolder_id=folder["id"])
        publish(self.app, assignment, "intake")
        run["pending"] = assignment
        self.app.save_run(run)
        self.app.event("assignment", assignment, run["id"])
        self.app.trace("assignment", assignment, run["id"])
        return assignment

    def _foundation_assignment(self, run):
        from .continuation import publish
        from .prompts import compose_role
        from .modules.intake import project_files

        inputs = {"artifact_context": {"project": str(self.app.project), "owner": "project:" + self.app.project_id},
                  "evidence_handles": [], "reusable_types": {}, "existing_model": None,
                  **copy.deepcopy(run["inputs"])}
        if "source_manifest" not in inputs:
            baseline = run.get("source_baseline")
            inputs["source_manifest"] = {"files": sorted(baseline["files"]) if baseline is not None
                                         else project_files(self.app.project, self.app.home)}
        inputs["reusable_types"] = {**{key: copy.deepcopy(record) for key, record in run.get("referenced_types", {}).items()},
                                    **(inputs.get("reusable_types") or {})}
        prepared = compose_role(self.app, "intake", inputs)
        assignment = {**prepared, "run_id": run["id"], "request_id": self.app.identifier(),
            "status": "awaiting_answer", "role": "native_expert", "context": "project",
            "workfolder": str(self.app.project),
            "completion": "Save contributions incrementally with intake.put. The final answer contains unsaved contributions; return {} when all contributions have been saved.",
            "tools": ["intake.search", "intake.get", "intake.put", "intake.files", "intake.read"],
            "tool_bindings": {"Namespace search": "intake.search", "Element and receiving-purpose relationships": "intake.get",
                              "author contributions": "intake.put"}}
        publish(self.app, assignment, "intake")
        run["pending"] = assignment
        run["assignment_snapshot"] = copy.deepcopy(assignment)
        self.app.save_run(run)
        self.app.event("assignment", assignment, run["id"])
        self.app.trace("assignment", assignment, run["id"])
        return assignment

    def draft(self, run):
        snapshot = {"artifact": {}, "understanding": {}, **copy.deepcopy(run["contributions"]),
                    "schema_version": "2", "model": copy.deepcopy(run["model"])}
        from .models import ref_key
        needed = set()
        def collect(value):
            if isinstance(value, dict):
                if value.get("kind") == "type":
                    needed.add(ref_key(value))
                for child in value.values():
                    collect(child)
            elif isinstance(value, list):
                for child in value:
                    collect(child)
        collect(snapshot)
        for owner, kind, identifier in list(needed):
            if kind == "type":
                parent = identifier.rpartition(".")[0]
                while parent:
                    needed.add((owner, "type", parent))
                    parent = parent.rpartition(".")[0]
        known = run.get("referenced_types", {})
        for record in known.values():
            if record.get("body_omitted"):
                continue
            if (record["owner"], "type", record["id"]) in needed:
                self._include_type(snapshot, record)
        snapshot["model"]["revision"] = "draft:" + digest(snapshot)
        return snapshot

    @staticmethod
    def _include_type(snapshot, record):
        key = record["id"]
        if key in snapshot["types"] and snapshot["types"][key].get("owner") != record["owner"]:
            key = record["owner"] + "|" + key
        snapshot["types"].setdefault(key, copy.deepcopy(record))

    def read_context(self, run, query):
        from .models import adapt_type
        snapshot = self.draft(run)
        for record in run.get("inputs", {}).get("reusable_types", {}).values():
            self._include_type(snapshot, record)
        for owner, graph in (("global", self.app.global_graph), ("project:" + self.app.project_id, self.app.graph)):
            candidates = graph.search(query)
            for record in candidates:
                typed = adapt_type(record, record["id"], owner)
                if typed:
                    self._include_type(snapshot, typed)
            for binding in snapshot["bindings"]:
                ref = binding["type"]
                if ref["owner"] == owner:
                    typed = adapt_type(graph.get(ref["id"]), ref["id"], owner)
                    if typed:
                        self._include_type(snapshot, typed)
        from .models import _resolve_stored_types
        _resolve_stored_types(snapshot, {"global": self.app.global_graph, "project:" + self.app.project_id: self.app.graph},
                              include_supplied_parents=True)
        snapshot["model"]["revision"] = "draft:" + digest({k: v for k, v in snapshot.items() if k != "model"})
        return snapshot

    @run_locked
    def record_context(self, run_id, envelope, source_snapshot):
        run = self.app.load_run(run_id)
        run.setdefault("context_reads", []).append(copy.deepcopy(envelope))
        types = {(record.get("owner"), record.get("id")): record for record in source_snapshot["types"].values()}
        for item in envelope["records"]:
            ref = item["ref"]
            if ref["kind"] == "type":
                record = types.get((ref["owner"], ref["id"]))
                if record is not None:
                    run.setdefault("referenced_types", {})[ref["owner"] + "|" + ref["id"]] = copy.deepcopy(record)
        self.app.save_run(run)

    @run_locked
    def record_evidence(self, run_id, evidence):
        run = self.app.load_run(run_id)
        run.setdefault("source_evidence", []).append(copy.deepcopy(evidence))
        self.app.save_run(run)

    def _next(self, run, request_id=None):
        from .continuation import present

        pending = run.get("pending")
        if request_id is not None:
            if run["status"] == "running" and pending and pending["request_id"] == request_id:
                return present(pending)
            if request_id in run.get("receipts", {}) and run["stage"] == "complete":
                return self._finish(run) if run["status"] == "running" else self._result(run)
            raise ValueError("This request is not pending in the intake run")
        if run["status"] != "running":
            return self._result(run)
        if pending:
            return present(pending)
        if run["stage"] == "complete":
            return self._finish(run)
        return self._assignment(run)

    @run_locked
    def next(self, run_id, request_id=None):
        return self._next(self.app.load_run(run_id), request_id)

    @run_locked
    def apply(self, run_id):
        run = self.app.load_run(run_id)
        if run["stage"] != "complete":
            raise ValueError("Submit the pending intake assignment before publishing the foundation")
        return self._finish(run) if run["status"] == "running" else self._result(run)

    @run_locked
    def batch(self, run_id, limit=None):
        run = self.app.load_run(run_id)
        if limit is not None and limit < 1:
            raise ValueError("Assignment limit must be positive")
        return [self._next(run)]

    def _put(self, run, graph):
        if run.get("contract_version", "1") == "2":
            from .coarse import expand
            notes = schemas.annotations(self.app, run["assignment_snapshot"]["schema"], graph)
            run["submissions"].append({"answer": copy.deepcopy(graph), "annotations": notes, "created": now()})
            if not isinstance(graph, dict):
                notes.append({"path": [], "code": "not_an_object", "message": "The answer is not an object; it is recorded and not stored."})
                return {"recorded": True, "contract_version": "2"}
            for field in graph:
                if field not in {"elements", "joins", "subtypes", "defining"}:
                    notes.append({"path": [field], "code": "unexpected_field", "field": field,
                                  "message": "The prompt did not ask for this field; it is recorded here and not stored."})
            coarse = run.setdefault("coarse", {"elements": {}, "joins": [], "subtypes": []})
            coarse.setdefault("subtypes", [])
            if graph.get("defining"):
                coarse["defining"] = graph["defining"]
            before = copy.deepcopy(coarse)
            if isinstance(graph.get("elements"), dict):
                coarse["elements"].update(copy.deepcopy(graph["elements"]))
            previous = {(join.get("receiver"), join.get("provider"), join.get("purpose")): join for join in coarse["joins"]}
            for join in graph.get("joins") or []:
                if isinstance(join, dict):
                    previous[(join.get("receiver"), join.get("provider"), join.get("purpose"))] = copy.deepcopy(join)
            coarse["joins"] = list(previous.values())
            for value in (graph.get("subtypes") if isinstance(graph.get("subtypes"), list) else []):
                if value not in coarse["subtypes"]:
                    coarse["subtypes"].append(copy.deepcopy(value))
            if coarse != before:
                known = {record["id"]: record for record in run.get("referenced_types", {}).values()
                         if record.get("id") and not record.get("body_omitted")}
                expanded = expand(coarse, "project:" + self.app.project_id, known)
                for record in expanded.pop("reused").values():
                    run.setdefault("referenced_types", {}).setdefault(record["owner"] + "|" + record["id"], record)
                notes.extend({"path": [], **diagnostic} for diagnostic in expanded.pop("diagnostics"))
                run["submissions"][-1]["expanded"] = copy.deepcopy(expanded)
                run["contributions"] = expanded
            return {"recorded": True, "contract_version": "2"}
        source = run["stage"]
        result = self.app.graph.put(graph, source)
        context = {key: copy.deepcopy(value) for key, value in graph.items()
                   if key not in {"elements", "joins", "observations"}}
        if source == "native":
            self.app.set("native_context", {**(self.app.get("native_context") or {}), **context})
        else:
            run.setdefault("latent_context", {}).update(context)
            authored = run.setdefault("latent_graph", {"elements": {}, "joins": []})
            authored["elements"].update(copy.deepcopy(graph.get("elements", {})))
            previous = {join.get("id") or digest(join): join for join in authored["joins"]}
            previous.update({join.get("id") or digest(join): copy.deepcopy(join) for join in graph.get("joins", [])})
            authored["joins"] = list(previous.values())
        return result

    @run_locked
    def put(self, run_id, graph, request_id=None):
        run = self.app.load_run(run_id)
        if run["status"] != "running" or run["stage"] == "complete":
            raise ValueError("This intake pass has completed")
        if request_id is not None:
            self._next(run, request_id)
        result = self._put(run, graph)
        self.app.save_run(run)
        return result

    @run_locked
    def submit(self, run_id, request_id, answer):
        run = self.app.load_run(run_id)
        if request_id in run["receipts"]:
            self._cleanup_completed(run, request_id)
            return run["receipts"][request_id]
        job = self._next(run, request_id)
        if isinstance(answer, dict) and answer.get("status") == "blocked":
            self.app.event("intake.blocked", {"answer": answer, "role": job["role"]}, run_id)
            return {"run_id": run_id, "request_id": request_id, "status": "blocked", "answer": answer}
        notes = schemas.annotations(self.app, job["schema"], answer)
        source = run["stage"]
        self._put(run, answer)
        self.app.event("intake.answer", {"answer": answer, "annotations": notes, "role": job["role"]}, run_id)
        if run.get("contract_version", "1") == "2":
            run["stage"] = "complete"
        elif source == "native":
            run["native_graph"] = self._native_snapshot()
            run["stage"] = "archaeology"
        else:
            run["stage"] = "complete"
        run["pending"] = None
        if job.get("workfolder_id"):
            run.setdefault("cleanup_by_request", {})[request_id] = job["workfolder_id"]
        receipt = {"run_id": run_id, "recorded": True, "source": source,
                   "remaining": 0 if run["stage"] == "complete" else 1,
                   "contract_version": run.get("contract_version", "1"),
                   "next": "intake.apply" if run["stage"] == "complete" else "intake.next"}
        run["receipts"][request_id] = receipt
        self.app.save_run(run)
        self._cleanup_completed(run, request_id)
        return receipt

    def _result(self, run):
        result = {"run_id": run["id"], "status": run["status"], "result": run.get("result")}
        if run.get("contract_version") == "2":
            result["annotations"] = [copy.deepcopy(note) for submission in run.get("submissions", [])
                                     for note in submission.get("annotations", [])]
            result["diagnostics"] = copy.deepcopy(run.get("diagnostics", []))
        if run.get("contract_version") == "2" and run.get("result"):
            model = run["result"]
            result.update(model=model, contract_version="2")
            if run["status"] == "complete":
                from .registry import Registry
                coordinator = copy.copy(self.app)
                coordinator.binding = None
                if "guide.start" in Registry(coordinator).visible():
                    result["next"] = {"command": "guide.start", "arguments": {"model": model}}
        return result

    def _finish(self, run):
        if run.get("contract_version", "1") == "2":
            from .models import publish_foundation
            snapshot = self.draft(run)
            job = run["assignment_snapshot"]
            activity = {"id": "activity:" + run["id"], "owner": "project:" + self.app.project_id,
                "kind": "intake", "inputs": [{"assignment": copy.deepcopy(job)},
                                               {"submissions": [{k: copy.deepcopy(v) for k, v in submission.items() if k != "expanded"}
                                                                for submission in run["submissions"]]},
                                               {"context_reads": copy.deepcopy(run.get("context_reads", []))}],
                "outputs": [{"owner": item.get("owner", "project:" + self.app.project_id), "kind": kind, "id": identifier}
                            for kind in ("type", "element") for identifier, item in snapshot[kind + "s"].items()],
                "prompt": {"id": job["prompt_ref"], "revision": job["prompt_revision"], "text": job["source_prompt"]},
                "components": copy.deepcopy(job["components"]),
                "source_evidence": copy.deepcopy(run.get("source_evidence", [])),
                "execution": {"run_id": run["id"], "contract_version": "2"}}
            if "source_baseline" in run:
                activity["inputs"].append({"source_baseline": copy.deepcopy(run["source_baseline"])})
            snapshot["activities"] = [activity]
            result = publish_foundation(self.app, snapshot)
            from .models import capture_model
            run.update(status="complete", result=result, diagnostics=capture_model(self.app, result).get("diagnostics", []))
            self.app.save_run(run)
            self.app.leave()
            self.app.event("intake.complete", {"model": result, "contract_version": "2"}, run["id"])
            return self._result(run)
        self.app.graph.replace_scope(run["latent_graph"], "archaeology")
        run.update(status="complete", result=self.app.graph.merge_perspectives())
        self.app.save_run(run)
        self.app.leave()
        self.app.event("intake.complete", run["result"], run["id"])
        return {"run_id": run["id"], "status": "complete", "result": run["result"]}

    def _cleanup_completed(self, run, request_id):
        from .continuation import retire
        retire(self.app, run, request_id)
        identifier = run.get("cleanup_by_request", {}).get(request_id)
        if identifier is None:
            return
        with self.app.db() as db:
            retained = db.execute("SELECT 1 FROM workfolders WHERE id=?", (identifier,)).fetchone()
        if retained is not None:
            workfolders.cleanup(self.app, identifier)
        del run["cleanup_by_request"][request_id]
        self.app.save_run(run)
