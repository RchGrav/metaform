from __future__ import annotations

import importlib
import asyncio
import importlib.resources
import importlib.util
import inspect
import json
import hashlib
import sys
import types
from dataclasses import dataclass
from pathlib import Path


LAUNCHER_COMMANDS = {
    'done': 'Finish this bound assignment and clean up its nonce',
    "abort": "Abort the active operation and return to the router",
    "skill": "Print the concierge introduction",
    "mcp": "Connect an AI harness over stdio MCP",
    "begin": "Receive a stored worker assignment",
    "install": "Install the command and connect an AI harness",
}


def reference_schema(shape, prefix):
    if not isinstance(shape, dict):
        raise ValueError(f"{prefix} must be an object")
    for field in ("description", "title"):
        if field in shape and not isinstance(shape[field], str):
            raise ValueError(f"{prefix}.{field} must be a string")
    properties = shape.get("properties", {})
    if not isinstance(properties, dict):
        raise ValueError(f"{prefix}.properties must be an object")
    for name, child in properties.items():
        reference_schema(child, f"{prefix}.properties.{name}")
    required = shape.get("required", [])
    if not isinstance(required, list) or any(not isinstance(name, str) for name in required):
        raise ValueError(f"{prefix}.required must be an array of strings")


def read_manifest(path):
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON {exc.msg} at line {exc.lineno}, column {exc.colno}") from exc
    if not isinstance(manifest, dict):
        raise ValueError("root must be an object")
    if not isinstance(manifest.get("id"), str) or not manifest["id"]:
        raise ValueError("id must be a nonempty string")
    for field in ("name", "title", "description", "guidance"):
        if field in manifest and not isinstance(manifest[field], str):
            raise ValueError(f"{field} must be a string")
    if not isinstance(manifest.get("commands", []), list):
        raise ValueError("commands must be an array")
    if not isinstance(manifest.get("settings", {}), dict):
        raise ValueError("settings must be an object")
    for key, shape in manifest.get("settings", {}).items():
        reference_schema(shape, f"settings.{key}")
    for index, entry in enumerate(manifest.get("commands", [])):
        prefix = f"commands[{index}]"
        if not isinstance(entry, dict):
            raise ValueError(f"{prefix} must be an object")
        for field in ("name", "handler"):
            if not isinstance(entry.get(field), str) or not entry[field]:
                raise ValueError(f"{prefix}.{field} must be a nonempty string")
        if ":" not in entry["handler"]:
            raise ValueError(f"{prefix}.handler must name a module or file and function separated by ':'")
        reference_schema(entry.get("inputSchema", {}), f"{prefix}.inputSchema")
        aliases = entry.get("aliases", [])
        if not isinstance(aliases, list) or any(not isinstance(alias, str) or not alias for alias in aliases):
            raise ValueError(f"{prefix}.aliases must be an array of nonempty strings")
    return manifest


@dataclass
class Command:
    module: str
    name: str
    description: str
    schema: dict
    handler: str
    manifest: dict
    directory: object
    always_available: bool = False
    hidden_when: object = False
    output_schema: object = None
    resource_kind: str | None = None
    reference_only: bool = False
    read_only: bool = False
    source_path: object = None

    @property
    def key(self):
        return f"{self.module}.{self.name}"

    def definition(self, app):
        from .schemas import bundled

        result = {"name": self.key, "description": self.description, "inputSchema": self.schema}
        if self.output_schema is not None:
            result["outputSchema"] = bundled(app, self.output_schema)
            result["outputSchema"].setdefault("type", "object")
        return result


class Registry:
    def __init__(self, app):
        self.app = app

    def discover(self):
        self.app.module_errors = []
        roots = [
            importlib.resources.files("metaform") / "data" / "modules",
            self.app.home / "modules",
            self.app.root / "modules",
        ]
        roots.extend(
            Path(p).expanduser() for p in self.app.config.get("module_paths", [])
        )
        roots.extend(Path(p) for p in getattr(self.app, "_module_reference_paths", []))
        commands = {}
        for root in roots:
            if not root.is_dir():
                continue
            for item in sorted(root.iterdir(), key=lambda p: p.name):
                manifest_path = item / "module.json" if item.is_dir() else item
                if not manifest_path.is_file() or not manifest_path.name.endswith(
                    ".json"
                ):
                    continue
                try:
                    manifest = read_manifest(manifest_path)
                    pending = {}
                    for entry in manifest.get("commands", []):
                        command = Command(
                            manifest["id"],
                            entry["name"],
                            entry.get("description", ""),
                            entry.get("inputSchema", {"type": "object", "properties": {}}),
                            entry["handler"],
                            manifest,
                            manifest_path.parent,
                            entry.get("always_available", False),
                            entry.get("hidden_when", False),
                            entry.get("outputSchema"),
                            entry.get("resourceKind"),
                            entry.get("reference_only", False),
                            entry.get("read_only", False),
                            manifest_path,
                        )
                        if command.key in commands or command.key in pending:
                            raise ValueError(
                                f"Duplicate command {command.key}: {manifest_path}"
                            )
                        pending[command.key] = command
                except (OSError, ValueError, TypeError, KeyError) as exc:
                    self.app.module_errors.append(f"Invalid module manifest {manifest_path}: {exc}")
                    continue
                commands.update(pending)
        names = set(LAUNCHER_COMMANDS) | {command.module for command in commands.values()}
        invalid = set()
        for command in commands.values():
            entry = next(item for item in command.manifest["commands"] if item["name"] == command.name)
            if command.module in LAUNCHER_COMMANDS:
                self.app.module_errors.append(f"Invalid module manifest {command.source_path}: id conflicts with launcher {command.module}")
                invalid.add(command.module)
            for alias in entry.get("aliases", []):
                if alias in names:
                    self.app.module_errors.append(f"Invalid module manifest {command.source_path}: commands.{command.name}.aliases conflicts with {alias}")
                    invalid.add(command.module)
                names.add(alias)
        return {key: command for key, command in commands.items() if command.module not in invalid}

    def manifests(self):
        return {command.module: command.manifest for command in self.discover().values()}

    def settings(self):
        return {identifier: manifest.get("settings", {}) for identifier, manifest in self.manifests().items()
                if manifest.get("settings")}

    def defaults(self):
        return {key: shape["default"] for settings in self.settings().values()
                for key, shape in settings.items() if "default" in shape}

    def reference(self, module=None, command=None):
        from .onboarding import registered_modules
        modules = registered_modules(self.app, reference=True)
        if module:
            modules = [item for item in modules if item["id"] == module]
            if not modules:
                raise ValueError(f"Unknown module: {module}")
        if command:
            for item in modules:
                item["commands"] = [entry for entry in item["commands"]
                                    if entry["name"] in {command, item["id"] + "." + command}]
            if not any(item["commands"] for item in modules):
                raise ValueError(f"Unknown command: {command}")
        return {"modules": modules, "configuration": self.app.configuration(),
                **({"diagnostics": self.app.module_errors} if self.app.module_errors else {})}

    def visible(self):
        commands = self.discover()
        mode = self.app.get("mode")
        explicitly_disabled = set(self.app.get("disabled_commands", []))
        disabled = set(explicitly_disabled)
        run = self.app.load_run(mode["run_id"]) if mode and mode.get("run_id") else {}
        if mode and not self.app.binding and (not run or run.get("status") == "running"):
            disabled.update(
                key
                for key, c in commands.items()
                if c.module != mode["module"] and not c.always_available
            )
        from .logic import evaluate

        if self.app.binding:
            request_id = self.app.binding.get("request_id")
            job = run.get("assignments", {}).get(request_id) or run.get("pending") or {}
            tools = set(job.get("tools", [])) if job.get("request_id") == request_id else set()
            module = "intake" if self.app.binding["module"] == "intake" else "workflow"
            tools.update({module + ".answer", module + ".next"})
            tools.update(command.key for command in commands.values() if command.module == module
                         and any(entry.get("binding_available") for entry in command.manifest["commands"]
                                 if entry["name"] == command.name))
            commands = {key: command for key, command in commands.items() if key in tools}
        disabled.update(
            key
            for key, c in commands.items()
            if c.hidden_when and evaluate(c.hidden_when, {"mode": mode, "run": run})
        )
        return {
            key: c
            for key, c in commands.items()
            if key not in explicitly_disabled and (key not in disabled or c.always_available)
        }

    def portable_manifests(self):
        """Available metadata; closure determines which manifests are dependencies."""
        project_owner = "project:" + self.app.project_id
        result = {"global": {}, project_owner: {}}
        project_modules = (self.app.root / "modules").resolve()
        for command in self.discover().values():
            local = isinstance(command.directory, Path) and command.directory.resolve().is_relative_to(project_modules)
            catalog = result[project_owner if local else "global"]
            catalog["module:" + command.module] = command.manifest
            catalog["command:" + command.key] = {"module": command.module}
        return result

    def portable_dependencies(self, selected=()):
        """Declared resources for selected shared and all project modules."""
        selected = set(selected)
        configured = [Path(p).expanduser().resolve() for p in self.app.config.get("module_paths", [])]
        project_modules = (self.app.root / "modules").resolve()
        builtin = importlib.resources.files("metaform") / "data" / "modules"
        modules, references, unresolved = {}, [], []
        for command in self.discover().values():
            if command.module in modules or str(command.directory) == str(builtin):
                continue
            directory = Path(command.directory).resolve()
            local = directory.is_relative_to(project_modules)
            if not (local or command.module in selected or command.key in selected
                    or any(directory.is_relative_to(p) for p in configured)):
                continue
            declaration = command.manifest.get("portable", {})
            files = []
            for name in declaration.get("files", []):
                path = (directory / name).resolve()
                if path.exists():
                    files.append(str(path))
                else:
                    unresolved.append({"module": command.module, "path": str(path), "reason": "missing_runtime_asset"})
            for ref in declaration.get("knowledge_refs", []):
                reference = {"ref": ref} if isinstance(ref, str) else dict(ref)
                reference.setdefault("kind", "element")
                if not local:
                    reference.setdefault("owner", "global")
                references.append(reference)
            modules[command.module] = {
                "id": command.module, "directory": str(directory),
                "manifest": command.manifest, "files": files,
            }
        return {"modules": list(modules.values()), "knowledge_refs": references, "unresolved": unresolved}

    def load(self, command):
        module_path, function_name = command.handler.split(":", 1)
        if module_path.endswith(".py"):
            directory = Path(command.directory).resolve()
            name = (
                "_metaform_plugin_"
                + hashlib.sha256(str(directory).encode()).hexdigest()
            )
            if name not in sys.modules:
                initializer = directory / "__init__.py"
                if initializer.is_file():
                    spec = importlib.util.spec_from_file_location(
                        name, initializer, submodule_search_locations=[str(directory)]
                    )
                    package = importlib.util.module_from_spec(spec)
                    sys.modules[name] = package
                    try:
                        spec.loader.exec_module(package)
                    except BaseException:
                        sys.modules.pop(name, None)
                        raise
                else:
                    package = types.ModuleType(name)
                    package.__path__ = [str(directory)]
                    package.__package__ = name
                    sys.modules[name] = package
            relative = Path(module_path).with_suffix("")
            parts = list(relative.parts)
            if parts[-1] == "__init__":
                parts.pop()
            module = importlib.import_module(".".join([name, *parts]))
        else:
            module = importlib.import_module(module_path)
        return getattr(module, function_name)

    async def call(self, key, arguments=None, context=None, *, internal=False):
        if key == "abort":
            return self.app.abort()
        commands = (
            self.visible()
            if not internal
            else {
                k: c
                for k, c in self.discover().items()
                if k not in self.app.get("disabled_commands", [])
            }
        )
        if key not in commands:
            raise ValueError(f"Unknown command: {key}")
        command = commands[key]
        arguments = arguments or {}
        self.app.trace("request", {"command": key, "arguments": arguments})
        try:
            from .module_api import handler_context
            result = self.load(command)(handler_context(self.app, command, context), arguments, context)
            if inspect.isawaitable(result):
                result = await result
            if not (command.reference_only or command.read_only):
                await self.after_call()
            self.app.trace("response", {"command": key, "result": result})
            return result
        except Exception as exc:
            import traceback

            self.app.trace(
                "error",
                {
                    "command": key,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                },
            )
            raise

    async def raw(self, argv, context=None):
        mode = self.app.get("mode")
        command = next(
            (c for c in self.discover().values() if c.module == mode["module"]), None
        )
        if not command or not command.manifest.get("raw_handler"):
            raise ValueError("The active module has no raw input handler")
        command.handler = command.manifest["raw_handler"]
        self.app.trace("raw.request", {"module": command.module, "argv": argv})
        from .module_api import handler_context
        result = self.load(command)(handler_context(self.app, command, context), argv, context)
        result = await result if inspect.isawaitable(result) else result
        await self.after_call()
        self.app.trace("raw.response", {"module": command.module, "result": result})
        return result

    def disables_argparse(self):
        if self.app.binding:
            return False
        mode = self.app.get("mode")
        return bool(
            mode
            and any(
                c.module == mode["module"] and c.manifest.get("disable_argparse")
                for c in self.discover().values()
            )
        )

    async def after_call(self):
        import threading
        from .packaging import auto_build, BuildCancelled

        cancel = threading.Event()
        work = asyncio.create_task(asyncio.to_thread(auto_build, self.app, cancel))
        try:
            built = await asyncio.shield(work)
        except asyncio.CancelledError:
            cancel.set()
            try:
                await asyncio.shield(work)
            except BuildCancelled:
                pass
            raise
        if built:
            self.app.set("built_hash", built["source_hash"])
            self.app.event("package.built", built)
