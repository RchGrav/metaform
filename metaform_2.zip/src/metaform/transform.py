"""Explicit structural patches and their recorded knowledge consequences."""
from __future__ import annotations

import copy

from .models import (COLLECTIONS, capture_model, list_models, publish_foundation,
                     records, ref_key, structural_projection)
from .util import digest
from .locking import snapshot_locked


def _index(snapshot):
    return {(record['owner'], kind, record['id']): record for _, _, kind, record in records(snapshot)}


def _set(snapshot, target, value):
    collection = next((name for name, kind in COLLECTIONS.items() if kind == target['kind']), None)
    if collection is None:
        raise ValueError('Unknown structural record kind: ' + target['kind'])
    entries = snapshot[collection]
    if isinstance(entries, dict):
        existing_key = next((identifier for identifier, record in entries.items()
                             if (record.get('owner'), record.get('id')) == (target['owner'], target['id'])), None)
        if existing_key is not None:
            del entries[existing_key]
        if value is not None:
            identifier = value['id']
            if identifier in entries:
                identifier = value['owner'] + ':' + identifier
            entries[identifier] = copy.deepcopy(value)
    else:
        entries[:] = [record for record in entries if (record.get('owner'), record.get('id')) != (target['owner'], target['id'])]
        if value is not None:
            entries.append(copy.deepcopy(value))


def _relocate_references(snapshot, mapping):
    def move(ref):
        if isinstance(ref, dict) and ref_key(ref) in mapping:
            return copy.deepcopy(ref | mapping[ref_key(ref)])
        return ref

    snapshot['artifact'] = move(snapshot.get('artifact'))
    fields = {'element': ('artifact',), 'binding': ('element', 'type'),
              'narrowing': ('parent', 'child'), 'refinement': ('parent', 'child'),
              'join': ('receiver', 'provider', 'provider_type')}
    for _, _, kind, record in records(snapshot):
        for field in fields.get(kind, ()):
            if field in record:
                record[field] = move(record[field])
        if kind == 'join':
            for participant in record.get('participants', []):
                participant['ref'] = move(participant.get('ref'))
            scope = record.get('scope', {})
            if 'target' in scope:
                scope['target'] = move(scope['target'])
            if 'targets' in scope:
                scope['targets'] = [move(ref) for ref in scope['targets']]


def patch_snapshot(snapshot, operations):
    result = copy.deepcopy(snapshot)
    for operation in operations:
        target, action = operation['target'], operation['op']
        index = _index(result)
        existing = index.get(ref_key(target))
        if action == 'add':
            if existing is not None:
                raise ValueError('Record already exists: ' + str(target))
            value = operation['record']
        elif existing is None:
            raise ValueError('Record is absent: ' + str(target))
        elif action == 'remove':
            value = None
        elif action == 'update':
            value = operation['record']
        elif action in ('relocate', 'replace'):
            replacement = operation['replacement']
            if action == 'relocate' and target['kind'] == 'type':
                branch = [record for _, _, kind, record in records(result)
                          if kind == 'type' and record['owner'] == target['owner']
                          and (record['id'] == target['id'] or record['id'].startswith(target['id'] + '.'))]
                moves = []
                branch_keys = {(record['owner'], 'type', record['id']) for record in branch}
                for record in branch:
                    old = {'owner': record['owner'], 'kind': 'type', 'id': record['id']}
                    new = replacement | {'id': replacement['id'] + record['id'][len(target['id']):]}
                    if ref_key(new) in index and ref_key(new) not in branch_keys:
                        raise ValueError('Relocation target already exists: ' + str(new))
                    value = copy.deepcopy(record)
                    value.update(id=new['id'], owner=new['owner'])
                    value['aliases'] = list(dict.fromkeys([*value.get('aliases', []), old['id']]))
                    moves.append((old, new, value))
                for old, _, _ in moves:
                    _set(result, old, None)
                for old, new, value in moves:
                    _set(result, new, value)
                _relocate_references(result, {ref_key(old): new for old, new, _ in moves})
                continue
            if ref_key(replacement) != ref_key(target) and ref_key(replacement) in index:
                if action == 'relocate':
                    raise ValueError('Relocation target already exists: ' + str(replacement))
                value = None
            else:
                value = copy.deepcopy(operation.get('record', existing))
                value.update(id=replacement['id'], owner=replacement['owner'])
            _set(result, target, None)
            if value is not None:
                if action == 'relocate' and target['kind'] == 'type':
                    value['aliases'] = list(dict.fromkeys([*value.get('aliases', []), target['id']]))
                _set(result, replacement, value)
            _relocate_references(result, {ref_key(target): replacement})
            continue
        else:
            raise ValueError('Unknown transformation operation: ' + action)
        if value is not None and (value.get('id'), value.get('owner')) != (target['id'], target['owner']):
            raise ValueError('An update cannot silently change record identity: ' + str(target))
        _set(result, target, value)
    return result


def compare_snapshots(source, destination):
    before, after = _index(structural_projection(source)), _index(structural_projection(destination))
    return [{'target': dict(zip(('owner', 'kind', 'id'), key)),
             'before': before.get(key), 'after': after.get(key),
             'change': 'add' if key not in before else 'remove' if key not in after else 'update'}
            for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]


def apply_transformation(app, patch, *, expected_head=None):
    source = capture_model(app, patch['source'])
    intended = patch_snapshot(source, patch['operations'])
    model_name = patch['destination_model']
    heads = {head['model']: head for head in list_models(app)}
    base = heads.get(model_name)
    if base:
        current = capture_model(app, base)
        prior = next((activity for activity in current.get('activities', [])
                      if activity.get('id') == patch['id']), None)
        if prior and prior.get('transformation') == patch:
            if expected_head is not None:
                base = _original_transformation_revision(app, base, patch)
            return _complete_transformation(app, source, base, patch)
        if model_name != source['model']['model']:
            raise ValueError('Destination model already exists: ' + model_name)
    if expected_head is not None and base != expected_head:
        raise ValueError('The model changed since this deletion preview; refresh the preview before deleting.')
    if base and base != source['model']:
        current = capture_model(app, base)
        source_index, current_index = _index(source), _index(current)
        intended_index = _index(intended)
        changes = [key for key in source_index.keys() | intended_index.keys()
                   if source_index.get(key) != intended_index.get(key)]
        conflicts = [dict(zip(('owner', 'kind', 'id'), key)) for key in changes
                     if source_index.get(key) != current_index.get(key)]
        if conflicts:
            raise ValueError('Conflicting transformation records: ' + str(conflicts))
        for key in changes:
            _set(current, dict(zip(('owner', 'kind', 'id'), key)), intended_index.get(key))
        if intended.get('artifact') != source.get('artifact'):
            current['artifact'] = intended['artifact']
        intended = current
    intended['model'] = {'project': app.project_id, 'model': model_name}
    if patch.get('expansion'):
        intended.setdefault('expansions', []).append(copy.deepcopy(patch['expansion']))
    intended.setdefault('activities', []).append({
        'id': patch['id'], 'owner': 'project:' + app.project_id, 'kind': 'transformation',
        'inputs': [source['model']], 'outputs': [operation['target'] for operation in patch['operations']],
        'transformation': copy.deepcopy(patch), 'rebased_onto': base})
    destination = publish_foundation(app, intended, base=base if base is not None else False)
    return _complete_transformation(app, source, destination, patch)


def _relation_references(kind, record):
    fields = {'binding': ('element', 'type'), 'narrowing': ('parent', 'child'),
              'refinement': ('parent', 'child'), 'join': ('receiver', 'provider', 'provider_type')}
    values = [record.get(field) for field in fields.get(kind, ())]
    if kind == 'join':
        values.extend(participant.get('ref') for participant in record.get('participants', []))
        scope = record.get('scope', {})
        if isinstance(scope, dict):
            values.append(scope.get('target'))
            if isinstance(scope.get('targets'), list):
                values.extend(scope['targets'])
    return {ref_key(value) for value in values if isinstance(value, dict)
            and all(isinstance(value.get(field), str) for field in ('owner', 'kind', 'id'))}


def _original_transformation_revision(app, model, patch):
    from .models import _revision_id

    while True:
        envelope = app.graph.get(_revision_id(model['model'], model['revision']))['entity_json_obj']
        previous = envelope.get('base')
        if previous is None:
            return model
        prior = capture_model(app, previous)
        if not any(activity.get('transformation') == patch for activity in prior.get('activities', [])):
            return model
        model = previous


@snapshot_locked
def delete_record(app, model, target, *, preview=True, reason='Delete the selected erroneous record.'):
    """Delete one record and its incident relations, retaining other semantic entities."""
    if not isinstance(model, dict) or not model.get('revision'):
        raise ValueError('Deletion requires an exact model revision from model.discover.')
    if not isinstance(target, dict) or target.get('kind') not in {'element', 'type', 'join'}:
        raise ValueError('Select an owner-qualified Element, Type or join to delete.')
    source = capture_model(app, model)
    index = _index(source)
    selected = ref_key(target)
    if selected not in index:
        raise ValueError('Record is absent: ' + str(target))
    removed = {selected}
    relations = {key: _relation_references(key[1], record) for key, record in index.items()
                 if key[1] in {'binding', 'narrowing', 'refinement', 'join'}}
    while True:
        dependent = {key for key, references in relations.items() if references & removed}
        if dependent <= removed:
            break
        removed.update(dependent)
    affected = [dict(zip(('owner', 'kind', 'id'), key)) for key in [selected, *sorted(removed - {selected})]]
    patch = {'id': 'delete:' + digest([source['model'], affected, reason]), 'source': source['model'],
             'destination_model': source['model']['model'], 'purpose': reason,
             'operations': [{'op': 'remove', 'target': ref, 'reason': reason} for ref in affected], 'mapping': []}
    intended = patch_snapshot(source, patch['operations'])
    from .models import foundation_diagnostics
    details = {'preview': preview is not False, 'source': source['model'], 'target': affected[0],
               'affected': affected, 'diagnostics': foundation_diagnostics(intended)}
    if preview is not False:
        intended['model'] = source['model'] | {'revision': 'preview:' + digest(structural_projection(intended))}
        return details | {'model': source['model'], 'impact': _impact_snapshots(app, source, intended, [])}
    return details | apply_transformation(app, patch, expected_head=source['model'])



def _complete_transformation(app, source, destination, patch):
    from .layers import associate_destination, schedule_reinference

    mapping = effective_mapping(source, capture_model(app, destination), patch.get('mapping', []), patch['operations'])
    report = impact(app, source['model'], destination, mapping)
    report['mapping'] = copy.deepcopy(patch.get('mapping', []))
    associate_destination(app, source['model'], destination, report['decisions'], mapping, report['selector_changes'])
    return {'model': destination, 'source': source['model'], 'mapping': copy.deepcopy(patch.get('mapping', [])),
            'effective_mapping': mapping, 'impact': report,
            'reinference': schedule_reinference(app, source['model'], destination, report['decisions'], mapping, patch['id'], report['selector_changes'])}


def effective_mapping(source, destination, mapping, operations=()):
    """Resolve explicit relocation branches only where the destination contains their moved identities."""
    result = copy.deepcopy(mapping)
    for operation in operations:
        if operation['op'] != 'relocate':
            continue
        move = {'from': operation['target'], 'to': operation['replacement'],
                'meaning_preserved': True, 'reason': operation['reason']}
        existing = next((i for i, item in enumerate(result) if ref_key(item['from']) == ref_key(move['from']) and not item.get('scope')), None)
        if existing is None:
            result.append(copy.deepcopy(move))
        else:
            result[existing] = copy.deepcopy(move)
    moves = [item for item in result if item.get('meaning_preserved') and not item.get('scope')]
    destination_index = _index(destination)
    for _, _, kind, record in records(source):
        original = {'owner': record['owner'], 'kind': kind, 'id': record['id']}
        current, traversed, applied = original, set(), set()
        used = None
        while ref_key(current) not in traversed:
            traversed.add(ref_key(current))
            matches = [item for item in moves
                       if ref_key(item['from']) not in applied
                       and current['owner'] == item['from']['owner'] and kind == item['from']['kind']
                       and (current['id'] == item['from']['id'] or
                            (kind == 'type' and current['id'].startswith(item['from']['id'] + '.')))]
            if not matches:
                break
            used = max(matches, key=lambda item: len(item['from']['id']))
            applied.add(ref_key(used['from']))
            suffix = current['id'][len(used['from']['id']):]
            current = used['to'] | {'id': used['to']['id'] + suffix}
        if used is None or ref_key(current) == ref_key(original) or ref_key(current) not in destination_index:
            continue
        expanded = {'from': original, 'to': current, 'meaning_preserved': True, 'reason': used['reason']}
        existing = next((i for i, item in enumerate(result) if ref_key(item['from']) == ref_key(original) and not item.get('scope')), None)
        if existing is None:
            result.append(expanded)
        else:
            result[existing] = expanded
    return result


def _mapped_references(value, relocations):
    if isinstance(value, list):
        return [_mapped_references(item, relocations) for item in value]
    if not isinstance(value, dict):
        return value
    if all(isinstance(value.get(field), str) for field in ('owner', 'kind', 'id')) and ref_key(value) in relocations:
        return copy.deepcopy(value | relocations[ref_key(value)])
    return {field: _mapped_references(item, relocations) for field, item in value.items()}


def _comparison_snapshot(snapshot, relocations, *, relocate=True):
    """Normalize relocated identities and qualified references in a disposable comparison view."""
    result = copy.deepcopy(snapshot)
    moved_aliases = {}
    for key, target in relocations.items():
        if key[1] == 'type':
            moved_aliases.setdefault(ref_key(target), set()).add(key[2])
    references = relocations if relocate else {}
    for collection in COLLECTIONS:
        result[collection] = {} if collection in ('types', 'elements') else []
    result['artifact'] = _mapped_references(result.get('artifact'), references)
    for _, _, kind, record in records(snapshot):
        source = {'owner': record['owner'], 'kind': kind, 'id': record['id']}
        target = references.get(ref_key(source), source)
        value = _mapped_references(record, references)
        value.update(id=target['id'], owner=target['owner'])
        if kind == 'type':
            value['aliases'] = [alias for alias in value.get('aliases', []) if alias not in moved_aliases.get(ref_key(target), set())]
        _set(result, target, value)
    return result


def clone_model(app, source, destination_model, purpose=''):
    source = capture_model(app, source)['model']
    identifier = 'clone:' + digest([source, destination_model])
    destination = next((model for model in list_models(app) if model['model'] == destination_model), None)
    if destination is not None:
        prior = next((activity for activity in capture_model(app, destination).get('activities', [])
                      if activity.get('id') == identifier), None)
        if prior is not None:
            return apply_transformation(app, copy.deepcopy(prior['transformation']))
    return apply_transformation(app, {'id': identifier,
        'source': source, 'destination_model': destination_model, 'purpose': purpose,
        'operations': [], 'mapping': []})


def impact(app, source, destination, mapping):
    return _impact_snapshots(app, capture_model(app, source), capture_model(app, destination), mapping)


def _impact_snapshots(app, before, after, mapping):
    from .layers import active_attachments, inspect_layer, list_layers, _destination_selection

    source = before['model']
    effective = effective_mapping(before, after, mapping)
    relocations = {ref_key(item['from']): item['to'] for item in effective if item.get('meaning_preserved') and not item.get('scope')}
    compared_before = _comparison_snapshot(before, relocations)
    compared_after = _comparison_snapshot(after, relocations, relocate=False)
    old_records, new_records = _index(structural_projection(compared_before)), _index(structural_projection(compared_after))
    attachments = active_attachments(app, source)
    selector_changes = []
    selector_diagnostics = []
    for layer in list_layers(app, source):
        layer_ref = {'owner': layer['owner'], 'kind': 'layer', 'id': layer['id']}
        bundle = inspect_layer(app, layer_ref, source)
        selector = (bundle.get('association') or {}).get('selector', bundle['recipe']['selector'])
        destination_selector = _destination_selection({'selector': selector}, effective)['selector']
        old = selector_targets(compared_before, _mapped_references(selector, relocations))
        new = selector_targets(compared_after, destination_selector)
        if old is None or new is None:
            selector_diagnostics.append({'layer': layer_ref, 'selector': copy.deepcopy(selector),
                'destination_selector': destination_selector,
                'reason': 'This selector has no deterministic subject-selection adapter; population changes were not inferred.'})
            continue
        old_refs, new_refs = {ref_key(ref): ref for ref in old}, {ref_key(ref): ref for ref in new}
        if old_refs.keys() != new_refs.keys():
            selector_changes.append({'layer': layer_ref, 'generation': layer['generation'],
                'selector': copy.deepcopy(selector), 'destination_selector': destination_selector,
                'added': [new_refs[key] for key in sorted(new_refs.keys() - old_refs.keys())],
                'removed': [old_refs[key] for key in sorted(old_refs.keys() - new_refs.keys())],
                'resolved_targets': new})
    decisions = []
    for item in attachments:
        target = {'owner': item['owner'], 'kind': 'knowledge', 'id': item['id']}
        subject = item.get('subject', {})
        moved = relocations.get(ref_key(subject))
        relocated_context = any(_mapped_references(item.get(field), relocations) != item.get(field)
                                for field in ('subject', 'applicability', 'dependencies', 'target_index'))
        reasons = []
        unresolved = []
        if not item.get('dependencies'):
            unresolved.append({'target': target, 'reason': 'The attachment has no recorded input dependencies.'})
        for dependency in item.get('dependencies', []):
            if dependency.get('kind') == 'record':
                ref = dependency.get('target', {})
                if ref.get('kind') in ('knowledge', 'layer', 'generation'):
                    continue
                if ref.get('kind') == 'model':
                    old, new = structural_projection(compared_before), structural_projection(compared_after)
                else:
                    old = old_records.get(ref_key(relocations.get(ref_key(ref), ref)))
                    new = new_records.get(ref_key(relocations.get(ref_key(ref), ref)))
                if old is None and new is None:
                    unresolved.append({'target': ref, 'reason': 'The recorded premise is absent from both revisions.'})
                fields = dependency.get('fields', ['*'])
                if fields != ['*']:
                    old = {field: old.get(field) for field in fields} if old else None
                    new = {field: new.get(field) for field in fields} if new else None
                if old != new:
                    reasons.append({'target': ref, 'reason': 'A supplied record projection changed.'})
            elif dependency.get('kind') == 'selector':
                selector = dependency.get('selector', {})
                normalized_selector = _mapped_references(selector, relocations)
                old = selector_fingerprint(compared_before, normalized_selector)
                new = selector_fingerprint(compared_after, normalized_selector)
                if old is None or new is None:
                    unresolved.append({'selector': selector, 'reason': 'This selector has no deterministic comparison adapter.'})
                elif old != new:
                    reason = {'selector': selector, 'reason': 'The selected population changed, including added or absent context.'}
                    old_targets = selector_targets(compared_before, normalized_selector)
                    new_targets = selector_targets(compared_after, normalized_selector)
                    if old_targets is not None and new_targets is not None:
                        old_refs = {ref_key(ref): ref for ref in old_targets}
                        new_refs = {ref_key(ref): ref for ref in new_targets}
                        reason.update(added=[new_refs[key] for key in sorted(new_refs.keys() - old_refs.keys())],
                                      removed=[old_refs[key] for key in sorted(old_refs.keys() - new_refs.keys())])
                    reasons.append(reason)
            elif dependency.get('kind') not in ('schema', 'prompt', 'component'):
                unresolved.append({'dependency': dependency, 'reason': 'Dependency comparison is not recorded.'})
        if ref_key(moved or subject) not in new_records:
            action = 'invalidate'
            reasons.append({'target': subject, 'reason': 'The attachment subject is absent in the destination.'})
        elif item.get('authored') or item.get('provenance', {}).get('source') == 'authored':
            action = 'relocate' if relocated_context else 'preserve'
        elif any(change['layer'] == item.get('layer') and any(ref_key(ref) == ref_key(moved or subject)
                 for ref in change['removed']) for change in selector_changes):
            action = 'invalidate'
            reasons.append({'target': subject, 'reason': 'The attachment subject no longer matches the recorded layer selector.'})
        elif reasons:
            action = 'regenerate'
        elif unresolved or not item.get('dependencies'):
            action = 'reconsider'
        else:
            action = 'relocate' if relocated_context else 'preserve'
        decisions.append({'target': target, 'layer': item.get('layer'), 'subject': subject,
                          'action': action, 'reasons': reasons + unresolved})
    by_id = {ref_key(decision['target']): decision for decision in decisions}
    changed = True
    while changed:
        changed = False
        affected = {ref_key(decision['target']) for decision in decisions
                    if decision['action'] in ('invalidate', 'regenerate', 'reconsider')}
        affected.update(ref_key(item[field]) for item in attachments
                        if ref_key({'owner': item['owner'], 'kind': 'knowledge', 'id': item['id']}) in affected
                        for field in ('layer', 'generation') if item.get(field))
        for item in attachments:
            decision = by_id[(item['owner'], 'knowledge', item['id'])]
            if (decision['action'] not in ('preserve', 'relocate') or item.get('authored')
                    or item.get('provenance', {}).get('source') == 'authored'):
                continue
            upstream = [dependency['target'] for dependency in item.get('dependencies', [])
                        if ref_key(dependency.get('target', {})) in affected]
            if upstream:
                decision.update(action='regenerate', reasons=[{'target': ref, 'reason': 'Derived knowledge depends on an affected generation.'} for ref in upstream])
                changed = True
    return {'source': before['model'], 'destination': after['model'],
            'changes': compare_snapshots(before, after), 'mapping': copy.deepcopy(mapping), 'effective_mapping': effective,
            'decisions': decisions, 'selector_changes': selector_changes, 'selector_diagnostics': selector_diagnostics}


def selector_targets(snapshot, selector):
    """Resolve only selectors with an explicit, existing subject-selection contract."""
    from .namespace import browse_namespace, member_bindings, resolve_target

    kind = selector.get('kind')
    index = _index(snapshot)
    if kind in ('target', 'subjects', 'targets'):
        refs = [selector['target']] if kind == 'target' and selector.get('target') else selector.get('targets', [])
    elif kind in ('enumerator.context', 'knowledge_tool.context'):
        from .knowledge_tool import context_projection
        refs = context_projection(snapshot, selector.get('target'))['records']
    elif kind == 'type.members':
        target = resolve_target(snapshot, selector.get('target')).get('ref')
        if not target or target['kind'] != 'type':
            return []
        refs = [binding['element'] for binding in member_bindings(
            snapshot, target, selector.get('parameters', {}).get('descendants', False))]
    elif kind == 'namespace.browse':
        try:
            refs = browse_namespace(snapshot, selector.get('target'),
                                    category=selector.get('parameters', {}).get('category'))['selected_refs']
        except (ValueError, KeyError):
            return None
    else:
        return None
    selected = {ref_key(ref): ref for ref in refs if ref_key(ref) in index}
    return [copy.deepcopy(selected[key]) for key in sorted(selected)]


def selector_fingerprint(snapshot, selector):
    """Compare the recorded selection, including its negative context."""
    from .read_model import read_snapshot

    kind = selector.get('kind', '')
    if kind == 'model':
        return digest(sorted(_index(snapshot)))
    if kind in ('subjects', 'targets'):
        index = _index(snapshot)
        return digest([ref for ref in selector.get('targets', []) if ref_key(ref) in index])
    if kind == 'target':
        return digest(ref_key(selector.get('target', {})) in _index(snapshot))
    if kind in ('enumerator.context', 'knowledge_tool.context'):
        from .knowledge_tool import context_projection
        return digest(context_projection(snapshot, selector.get('target')))
    if '.' in kind:
        arguments = copy.deepcopy(selector.get('parameters', {}))
        if 'target' in selector:
            arguments['target'] = selector['target']
        try:
            result = read_snapshot(snapshot, kind, arguments)
            return next((dependency['fingerprint'] for dependency in reversed(result['dependencies'])
                         if dependency.get('kind') == 'selector'
                         and dependency.get('selector', {}).get('kind') == kind), None)
        except (ValueError, KeyError):
            return None
    return None
