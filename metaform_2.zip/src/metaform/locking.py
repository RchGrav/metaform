"""Cross-process serialization of short state transitions and assignments."""

from contextlib import asynccontextmanager, contextmanager
from functools import wraps
import os
from threading import Lock

from filelock import FileLock, Timeout

from .util import digest


def lock(app, key):
    directory = app.root / "locks"
    directory.mkdir(exist_ok=True)
    return FileLock(directory / (digest(key) + ".lock"), timeout=30)


# Reusing the same FileLock is essential: nested calls can cross App instances.
_snapshot_locks = {}
_snapshot_registry_lock = Lock()


@contextmanager
def snapshot_lock(app):
    path = (app.root / "locks" / "snapshot.lock").resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    key = (os.getpid(), str(path))
    with _snapshot_registry_lock:
        claim = _snapshot_locks.setdefault(key, FileLock(path, timeout=30))
    with claim:
        yield


def snapshot_locked(function):
    @wraps(function)
    def invoke(app_or_self, *args, **kwargs):
        app = getattr(app_or_self, "app", app_or_self)
        with snapshot_lock(app):
            return function(app_or_self, *args, **kwargs)
    return invoke


def run_locked(method):
    @wraps(method)
    def invoke(self, run_id, *args, **kwargs):
        with snapshot_lock(self.app), lock(self.app, "run:" + run_id):
            return method(self, run_id, *args, **kwargs)

    return invoke


@asynccontextmanager
async def assignment_lock(app, request_id):
    claim = lock(app, "assignment:" + request_id)
    try:
        claim.acquire(timeout=0)
    except Timeout:
        yield False
        return
    try:
        yield True
    finally:
        claim.release()
