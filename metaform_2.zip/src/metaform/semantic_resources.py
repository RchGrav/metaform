"""Version-addressed resources backed by the available semantic commands."""

from urllib.parse import parse_qs, quote, unquote, urlsplit

from .registry import Registry


def templates(app):
    return [
        {"name": command.key, "description": command.description,
         "uriTemplate": "metaform://model/{project}/{model}/{revision}/"
                        + ('{kind}' if command.resource_kind == '*' else quote(command.resource_kind, safe="")) + "/{id}{?owner}",
         "mimeType": "application/json"}
        for command in Registry(app).visible().values() if command.resource_kind
    ]


async def read(app, uri):
    parsed = urlsplit(uri)
    parts = [unquote(part) for part in parsed.path.lstrip("/").split("/")]
    if parsed.scheme != "metaform" or parsed.netloc != "model" or len(parts) != 5:
        raise ValueError("Unknown model resource: " + uri)
    project, model, revision, kind, identifier = parts
    commands = [command for command in Registry(app).visible().values()
                if command.resource_kind == kind]
    if not commands:
        commands = [command for command in Registry(app).visible().values() if command.resource_kind == '*']
    if len(commands) != 1:
        raise ValueError("No unambiguous available resource command for kind: " + kind)
    target = {'kind': kind, 'id': identifier}
    owner = parse_qs(parsed.query).get("owner")
    if owner:
        target = {"owner": owner[0], "kind": kind, "id": identifier}
    return await Registry(app).call(commands[0].key, {
        "model": {"project": project, "model": model, "revision": revision}, "target": target})
