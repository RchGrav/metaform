"""Metaform. Importing the package loads no modules or transports."""

__version__ = "0.2.0"
