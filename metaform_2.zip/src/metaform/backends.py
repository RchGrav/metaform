"""SQLite and portable JSON graph storage."""

from __future__ import annotations

import copy
import fnmatch
from collections import Counter
from pathlib import Path

from filelock import FileLock

from .graph import Graph, join_participants, renamed_elements, scoped_export, scoped_join_references
from .util import digest, now, read_json, write_json


def normalized(graph, source, layer):
    result = {"elements": {}, "joins": [], "observations": []}
    for identifier, value in graph.get("elements", {}).items():
        record = copy.deepcopy(value)
        record.setdefault("layer", layer)
        result["elements"][identifier] = record
        if source != "imported":
            result["observations"].append(
                {
                    "id": digest([identifier, source, value]),
                    "element_id": identifier,
                    "source": source,
                    "record": record,
                    "created": now(),
                }
            )
    for value in graph.get("joins", []):
        join = copy.deepcopy(value)
        join["join_scope"] = (
            source
            if source in {"native", "archaeology", "merged"}
            else join.get("join_scope", source)
        )
        identifier = join.get("id") or digest(join)
        if join["join_scope"] in {"native", "archaeology"}:
            join.setdefault("source_id", identifier)
            identifier = "join:" + digest([join["join_scope"], join["source_id"]])
        join["id"] = identifier
        result["joins"].append(join)
    result["observations"].extend(copy.deepcopy(graph.get("observations", [])))
    return result


def replaced_scope(original, graph, source, layer="elements", owner=None):
    """Replace one authored perspective while retaining every other source."""
    authored = {"elements": graph.get("elements", {}), "joins": graph.get("joins", [])}
    authored = scoped_join_references(authored, source,
                                     [j for j in original["joins"] if j.get("join_scope") == source], owner)
    incoming = normalized(authored, source, layer)
    data = copy.deepcopy(original)
    affected = {o["element_id"] for o in data["observations"] if o["source"] == source}
    data["observations"] = [o for o in data["observations"] if o["source"] != source]
    latest = {o["element_id"]: o["record"] for o in sorted(data["observations"], key=lambda o: (o["created"], o["id"]))}
    for identifier in affected:
        if identifier in latest:
            data["elements"][identifier] = copy.deepcopy(latest[identifier])
        else:
            data["elements"].pop(identifier, None)
    data["elements"].update(incoming["elements"])
    data["observations"] = sorted(data["observations"] + incoming["observations"], key=lambda o: o["id"])
    joins = {j["id"]: j for j in data["joins"] if j.get("join_scope") != source}
    joins.update({j["id"]: j for j in incoming["joins"]})
    data["joins"] = sorted(joins.values(), key=lambda j: j["id"])
    return data, {"elements": len(incoming["elements"]), "joins": len(incoming["joins"])}


def matches(identifier, record, query):
    data = record["entity_json_obj"]
    names = [identifier, data.get("en", ""), *data.get("aliases", [])]
    return any(fnmatch.fnmatchcase(str(n).lower(), query.lower()) for n in names) or (
        "*" not in query
        and query.lower()
        in (record["entity_desc"] + " " + " ".join(map(str, names))).lower()
    )


class JSONGraph(Graph):
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def export(self, scope=None):
        value = read_json(self.path, {"elements": {}, "joins": [], "observations": []})
        return scoped_export(value, scope)

    def put(self, graph, source="native", layer="elements", *, _raw=False):
        if source in {"native", "archaeology"}:
            graph = scoped_join_references(graph, source, self.joins(scope=source), getattr(self, "owner", None))
        incoming = copy.deepcopy(graph) if _raw else normalized(graph, source, layer)
        with FileLock(str(self.path) + ".lock"):
            data = self.export()
            data["elements"].update(incoming["elements"])
            for key in ("joins", "observations"):
                rows = {r["id"]: r for r in data[key]}
                for row in incoming[key]:
                    if key == "observations":
                        if row["id"] not in rows or row["created"] > rows[row["id"]]["created"]:
                            rows[row["id"]] = row
                    else:
                        rows[row["id"]] = row
                data[key] = sorted(rows.values(), key=lambda r: r["id"])
            write_json(self.path, data)
        return {"elements": len(incoming["elements"]), "joins": len(incoming["joins"])}

    def replace_scope(self, graph, source, layer="elements"):
        with FileLock(str(self.path) + ".lock"):
            data, result = replaced_scope(self.export(), graph, source, layer, getattr(self, "owner", None))
            write_json(self.path, data)
        return result

    def rename_elements(self, mapping):
        with FileLock(str(self.path) + ".lock"):
            data, result = renamed_elements(self.export(), mapping, getattr(self, "owner", None))
            if result["elements"]:
                write_json(self.path, data)
        return result

    def get(self, identifier, scope=None):
        if scope is not None:
            return Graph.get(self, identifier, scope)
        record = self.export()["elements"].get(identifier)
        return (
            {k: record[k] for k in ("entity_desc", "entity_schema", "entity_json_obj")}
            if record
            else None
        )

    def search(self, query="*", layer=None, scope=None):
        data = self.export(scope)
        return [
            dict(
                record,
                id=identifier,
                sources=sorted(
                    {
                        o["source"]
                        for o in data["observations"]
                        if o["element_id"] == identifier
                    }
                ),
            )
            for identifier, record in sorted(data["elements"].items())
            if (layer is None or record.get("layer") == layer)
            and matches(identifier, record, query)
        ]

    def joins(self, identifier=None, scope=None, category=None):
        return [
            j
            for j in self.export(scope)["joins"]
            if (category is None or j["type"] == category)
            and (
                identifier is None
                or identifier
                in {
                    j["id"],
                    j.get("object_id"),
                    j.get("element_id"),
                    *(p.get("ref") for p in j.get("participants", [])),
                }
            )
        ]

    def provenance(self, identifier):
        return [
            {k: o[k] for k in ("source", "record", "created")}
            for o in sorted(
                self.export()["observations"], key=lambda o: (o["created"], o["id"])
            )
            if o["element_id"] == identifier
        ]

    def delete_joins(self, object_id=None, category=None, scope=None):
        with FileLock(str(self.path) + ".lock"):
            data = self.export()
            data["joins"] = [
                j
                for j in data["joins"]
                if not (
                    (object_id is None or j.get("object_id") == object_id)
                    and (category is None or j["type"] == category)
                    and (scope is None or j.get("join_scope") == scope)
                )
            ]
            write_json(self.path, data)

    def stats(self):
        data = self.export()
        return {
            "elements": len(data["elements"]),
            "joins": len(data["joins"]),
            "observations": len(data["observations"]),
            "participants": sum(
                len(join_participants(j)) for j in data["joins"]
            ),
            "layers": dict(
                Counter(r.get("layer", "elements") for r in data["elements"].values())
            ),
            "scopes": dict(Counter(j.get("join_scope") for j in data["joins"])),
        }

    def clean(self):
        return self.merge_perspectives() | {"integrity": "ok"}


def graph_suffix(backend):
    try:
        return {"sqlite": ".kg", "json": ".json"}[backend]
    except (KeyError, TypeError):
        raise ValueError("Unknown graph backend: " + str(backend)) from None


def open_graph(path, backend):
    graph_suffix(backend)
    return {"sqlite": Graph, "json": JSONGraph}[backend](path)
