"""Serializable expressions on explicitly authored workflow transitions."""

from __future__ import annotations

import operator


def lookup(data, path, default=None):
    if path in (None, ""):
        return data
    for part in str(path).split("."):
        if isinstance(data, dict) and part in data:
            data = data[part]
        elif isinstance(data, list) and part.isdigit() and int(part) < len(data):
            data = data[int(part)]
        else:
            return default
    return data


def evaluate(expression, data, strict=False):
    if not isinstance(expression, dict):
        return (
            [evaluate(v, data, strict) for v in expression]
            if isinstance(expression, list)
            else expression
        )
    if len(expression) != 1:
        if strict:
            raise ValueError("A condition object must contain one expression operator")
        return {k: evaluate(v, data, strict) for k, v in expression.items()}
    op, operands = next(iter(expression.items()))
    if op == "literal":
        return operands
    values = operands if isinstance(operands, list) else [operands]
    if op == "var":
        return lookup(data, values[0], values[1] if len(values) > 1 else None)
    if op == "and":
        result = True
        for v in values:
            result = evaluate(v, data, strict)
            if not result:
                break
        return result
    if op == "or":
        for v in values:
            result = evaluate(v, data, strict)
            if result:
                return result
        return result if values else False
    if op == "if":
        for i in range(0, len(values) - 1, 2):
            if evaluate(values[i], data, strict):
                return evaluate(values[i + 1], data, strict)
        return evaluate(values[-1], data, strict) if len(values) % 2 else None
    if op in {"map", "all"}:
        items = evaluate(values[0], data, strict)
        results = (evaluate(values[1], data | {"item": item, "index": index}, strict)
                   for index, item in enumerate(items))
        return list(results) if op == "map" else all(results)
    args = [evaluate(v, data, strict) for v in values]
    operations = {
        "==": operator.eq,
        "===": operator.eq,
        "!=": operator.ne,
        ">": operator.gt,
        ">=": operator.ge,
        "<": operator.lt,
        "<=": operator.le,
        "+": operator.add,
        "-": operator.sub,
        "*": operator.mul,
        "/": operator.truediv,
        "%": operator.mod,
        "!": operator.not_,
        "in": lambda a, b: a in b,
        "cat": lambda *v: "".join(map(str, v)),
        "count": len,
    }
    if op not in operations:
        if strict:
            raise ValueError(f"Unknown condition operation {op!r}")
        return {op: evaluate(operands, data, strict)}
    return operations[op](*args)
