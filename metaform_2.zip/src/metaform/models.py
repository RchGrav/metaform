"""Revisioned semantic records over the existing owner-qualified knowledge store."""
from __future__ import annotations

import copy
from collections import OrderedDict, defaultdict

from .knowledge import KnowledgeError
from .util import digest

FOUNDATION_SCHEMA = 'urn:metaform:schema:foundation:2'
REVISION_SCHEMA = 'urn:metaform:schema:model-revision:2'
HEAD_SCHEMA = 'urn:metaform:schema:model-head:2'
COLLECTIONS = {'types': 'type', 'elements': 'element', 'bindings': 'binding',
               'narrowings': 'narrowing', 'refinements': 'refinement', 'joins': 'join', 'subtypes': 'subtype'}
REFERENCE_FIELDS = {'binding': ('element', 'type'), 'narrowing': ('parent', 'child'),
                    'refinement': ('parent', 'child'), 'join': ('receiver', 'provider', 'provider_type'),
                    'element': ('artifact',), 'subtype': ('parent',)}


def ref_key(ref):
    return tuple(ref.get(field) for field in ('owner', 'kind', 'id'))


def records(snapshot):
    for collection, kind in COLLECTIONS.items():
        values = snapshot.get(collection, {}) if collection in ('types', 'elements') else snapshot.get(collection, [])
        rows = values.items() if isinstance(values, dict) else enumerate(values)
        for position, record in rows:
            yield collection, position, kind, record


def adapt_type(record, identifier, owner):
    """Project an existing Type definition without supplying missing meaning."""
    if record is None:
        return None
    if record.get('entity_schema') == 'metaform:element':
        data = record.get('entity_json_obj', {})
        if data.get('type_ids') or data.get('type_id'):
            return None
        result = {'id': identifier, 'owner': owner}
        if 'entity_desc' in record:
            result['description'] = copy.deepcopy(record['entity_desc'])
        result.update({k: copy.deepcopy(data[k]) for k in ('ef', 'length', 'aliases', 'parametric_elements') if k in data})
        if data.get('en') and ('.' not in identifier or identifier.startswith(('exterior.', 'ext.'))):
            result['display_name'] = data['en']
        if 'svg' in data:
            result['presentation'] = {'svg': data['svg']}
        return result
    if record.get('entity_schema') == FOUNDATION_SCHEMA + '#/$defs/Type':
        return copy.deepcopy(record['entity_json_obj'])
    if record.get('id') == identifier and record.get('owner') == owner and 'ef' in record:
        return copy.deepcopy(record)
    return None


def _resolve_stored_types(snapshot, graphs, *, include_supplied_parents=False):
    """Resolve missing references; a completed snapshot retains its supplied Type set."""
    available = {(r.get('owner'), r.get('id')) for r in snapshot.get('types', {}).values()}
    requested = [(owner, identifier.rpartition('.')[0], None) for owner, identifier in available
                 if include_supplied_parents and '.' in identifier]

    for _, _, kind, record in records(snapshot):
        references = [record.get(field) for field in REFERENCE_FIELDS.get(kind, ())]
        if kind == 'join':
            references.extend(participant.get('ref') for participant in record.get('participants', []))
            scope = record.get('scope', {})
            if isinstance(scope, dict):
                references.append(scope.get('target'))
                if isinstance(scope.get('targets'), list):
                    references.extend(scope['targets'])
        requested.extend((ref['owner'], ref['id'], ref.get('revision')) for ref in references
                         if isinstance(ref, dict) and ref.get('kind') == 'type'
                         and all(isinstance(ref.get(field), str) for field in ('owner', 'id')))
    visited = set()
    while requested:
        owner, identifier, revision = requested.pop()
        if (owner, identifier, revision) in visited:
            continue
        visited.add((owner, identifier, revision))
        if (owner, identifier) in available:
            continue
        graph = graphs.get(owner)
        record = adapt_type(graph.get(identifier), identifier, owner) if graph else None
        if record is None or revision is not None and record.get('revision') != revision:
            continue
        key = identifier if identifier not in snapshot.setdefault('types', {}) else owner + '|' + identifier
        snapshot['types'][key] = record
        available.add((owner, identifier))
        parent = identifier.rpartition('.')[0]
        if parent:
            requested.append((owner, parent, None))


def build_indexes(snapshot):
    """Rebuild access indexes; keys preserve owner, kind and canonical identity."""
    indexes = {name: defaultdict(list) for name in (
        'namespace_children', 'aliases', 'reservations', 'element_bindings', 'type_bindings', 'incident_joins', 'refinements')}
    indexes['records'] = {}
    for _, _, kind, record in records(snapshot):
        key = (record.get('owner'), kind, record.get('id'))
        indexes['records'][key] = record
        if kind == 'type':
            identifier = record.get('id', '')
            parent = identifier.rpartition('.')[0]
            indexes['namespace_children'][(record.get('owner'), 'type', parent)].append(record)
            from .namespace import expanded_aliases
            for alias in expanded_aliases(record):
                for spelling in dict.fromkeys((alias['name'], alias['address']['id'])):
                    indexes['aliases'][(record.get('owner'), 'type', spelling)].append(record)
        elif kind == 'binding':
            indexes['element_bindings'][ref_key(record.get('element', {}))].append(record)
            indexes['type_bindings'][ref_key(record.get('type', {}))].append(record)
        elif kind == 'join':
            participants = [record.get(f) for f in ('receiver', 'provider')]
            participants += [p.get('ref') for p in record.get('participants', [])]
            for participant in {ref_key(p) for p in participants if isinstance(p, dict)}:
                indexes['incident_joins'][participant].append(record)
        elif kind == 'refinement':
            indexes['refinements'][ref_key(record.get('parent', {}))].append(record)
    from .namespace import namespace_reservations
    indexes['reservations'] = namespace_reservations(snapshot)
    return indexes


def structural_projection(snapshot):
    """Structural meaning excludes presentation, evidence and execution metadata."""
    projected = {k: copy.deepcopy(snapshot[k]) for k in ('artifact', 'understanding', *COLLECTIONS) if k in snapshot}
    for _, _, _, record in records(projected):
        for key in ('presentation', 'evidence', 'created', 'updated', 'revision', 'provenance'):
            record.pop(key, None)
    for collection in ('bindings', 'narrowings', 'refinements', 'joins'):
        projected[collection] = sorted(projected.get(collection, []), key=lambda r: (r.get('owner', ''), r.get('id', '')))
    return projected


def functional_account(snapshot):
    """Keep Native meaning and evidence, with intake execution capture as references."""
    account = copy.deepcopy(snapshot)
    for activity in account.get('activities', []):
        if activity.get('kind') != 'intake':
            continue
        activity.pop('inputs', None)
        for evidence in activity.get('source_evidence', []):
            evidence.pop('text', None)
            evidence.pop('data', None)
        for component in activity.get('components', []):
            component.pop('text', None)
        if isinstance(activity.get('prompt'), dict):
            activity['prompt'].pop('text', None)
    return account


def foundation_diagnostics(snapshot, schema_registry=None):
    from .schemas import builtins, check
    all_schemas = schema_registry or builtins()
    diagnostics = [{'code': 'schema', 'path': note['path'], 'message': note['message']}
                   for note in check(all_schemas[FOUNDATION_SCHEMA], snapshot, all_schemas)]
    indexes = build_indexes(snapshot)
    from .namespace import namespace_reservation_diagnostics
    diagnostics.extend(namespace_reservation_diagnostics(snapshot))
    seen = set()
    checks = [(['artifact'], snapshot.get('artifact'))]
    for collection, position, kind, record in records(snapshot):
        key = (record.get('owner'), kind, record.get('id'))
        if key in seen:
            diagnostics.append({'code': 'duplicate_id', 'path': [collection, position], 'ref': dict(zip(('owner', 'kind', 'id'), key)), 'message': 'Duplicate owner-qualified record identity.'})
        seen.add(key)
        checks.extend(([collection, position, field], record.get(field)) for field in REFERENCE_FIELDS.get(kind, ()))
        if kind == 'narrowing':
            child, parent = record.get('child', {}), record.get('parent', {})
            expected_parent = child.get('id', '').rpartition('.')[0]
            if parent.get('id') != expected_parent:
                diagnostics.append({'code': 'narrowing_parent_mismatch', 'path': [collection, position, 'parent'],
                    'ref': parent, 'child': child, 'expected_parent': expected_parent,
                    'message': 'Narrowing parent differs from the canonical direct namespace parent.'})
        if kind == 'join':
            checks.extend(([collection, position, 'participants', i, 'ref'], p.get('ref')) for i, p in enumerate(record.get('participants', [])))
            provider, facet = record.get('provider', {}), record.get('provider_type', {})
            if facet and provider.get('kind') == 'element' and not any(ref_key(b.get('type', {})) == ref_key(facet) for b in indexes['element_bindings'].get(ref_key(provider), [])):
                diagnostics.append({'code': 'unbound_provider_type', 'path': [collection, position, 'provider_type'], 'message': 'Provider Element has no binding to this Type facet.', 'ref': facet})
            elif facet and provider.get('kind') == 'type' and ref_key(provider) != ref_key(facet):
                diagnostics.append({'code': 'provider_type_mismatch', 'path': [collection, position, 'provider_type'], 'message': 'Type provider and provider Type facet differ.', 'ref': facet})
    for path, ref in checks:
        if isinstance(ref, dict):
            record = indexes['records'].get(ref_key(ref))
            if record is None:
                diagnostics.append({'code': 'unresolved_reference', 'path': path, 'ref': ref, 'message': 'Referenced owner-qualified record is absent from this revision.'})
            elif ref.get('revision') and ref['revision'] != record.get('revision', snapshot.get('model', {}).get('revision')):
                diagnostics.append({'code': 'reference_revision_mismatch', 'path': path, 'ref': ref, 'actual_revision': record.get('revision', snapshot.get('model', {}).get('revision')), 'message': 'The supplied record does not match the pinned revision.'})
    return diagnostics


def capture_model(app, model=None):
    return app.knowledge.call('model.capture', {'model': model})


def resolve_model(app, model=None):
    return app.knowledge.call('model.resolve', {'model': model})


def list_models(app):
    return app.knowledge.call('model.list', {})


def publish_foundation(app, snapshot, base=None):
    return app.knowledge.call('model.publish', {'snapshot': snapshot, 'base': base})


def _envelope(schema, body):
    return {'entity_schema': schema, 'entity_desc': 'Metaform model revision' if schema == REVISION_SCHEMA else 'Metaform model head',
            'entity_json_obj': body, 'layer': 'models'}


def _head_id(model):
    return 'model-head:' + digest(model)


def _revision_id(model, revision):
    return 'model-revision:' + digest([model, revision])


_INDEXED = OrderedDict()


def _indexed_revision(snapshot):
    """Index a published revision once. Revision ids are content digests, so the key is stable."""
    from .namespace import IndexedSnapshot
    model = snapshot.get('model', {})
    key = (model.get('project'), model.get('model'), model.get('revision'))
    if not key[2]:
        return IndexedSnapshot(snapshot)
    indexed = _INDEXED.get(key)
    if indexed is None:
        indexed = _INDEXED[key] = IndexedSnapshot(snapshot)
        indexed.revision_key = key
        while len(_INDEXED) > 8:
            _INDEXED.popitem(last=False)
    else:
        _INDEXED.move_to_end(key)
    return indexed


def model_operation(graph, project_id, operation, arguments, global_graph=None):
    """Called inside the knowledge backend's transaction or portable write lock."""
    owner = 'project:' + project_id
    heads = []
    if operation == 'model.list' or operation in {'model.capture', 'model.resolve', 'model.read'} and arguments.get('model') is None:
        heads = [record['entity_json_obj']['model'] for record in graph.export()['elements'].values() if record.get('entity_schema') == HEAD_SCHEMA]
        heads.sort(key=lambda r: r['model'])
    if operation == 'model.list':
        return heads
    if operation == 'model.read':
        from .read_model import read_snapshot
        snapshot = model_operation(graph, project_id, 'model.capture', {'model': arguments.get('model'), '_projection': True})
        from .namespace import IndexedSnapshot
        if not isinstance(snapshot, IndexedSnapshot):
            snapshot = _indexed_revision(snapshot)
        snapshot = snapshot.with_collections(arguments.get('collections', {}))
        return read_snapshot(snapshot, arguments['operation'], arguments.get('arguments', {}))
    if operation in {'model.capture', 'model.resolve'}:
        selected = arguments.get('model')
        if selected is None:
            if len(heads) != 1:
                raise KnowledgeError('model_not_found' if not heads else 'ambiguous_model', 'Select a model from this project.', {'candidates': heads})
            selected = heads[0]
        elif isinstance(selected, str):
            selected = {'project': project_id, 'model': selected}
        if selected.get('project', project_id) != project_id:
            raise KnowledgeError('invalid_owner', 'Model belongs to another project.', selected)
        model = selected.get('model')
        if not selected.get('revision'):
            head = graph.get(_head_id(model))
            if head:
                selected = head['entity_json_obj']['model']
        if operation == 'model.resolve':
            if not selected.get('revision'):
                raise KnowledgeError('model_not_found', 'Model revision is unavailable.', selected)
            identifier = _revision_id(model, selected['revision'])
            if not (graph.has(identifier) if hasattr(graph, 'has') else graph.get(identifier) is not None):
                raise KnowledgeError('model_not_found', 'Model revision is unavailable.', selected)
            return {'project': project_id, 'model': model, 'revision': selected['revision']}
        record = graph.get(_revision_id(model, selected.get('revision')))
        if record is None:
            raise KnowledgeError('model_not_found', 'Model revision is unavailable.', selected)
        snapshot = record['entity_json_obj']['snapshot']
        return snapshot if arguments.get('_projection') else copy.deepcopy(snapshot)
    if operation != 'model.publish':
        raise KnowledgeError('unknown_operation', 'Unknown operation: ' + operation)
    snapshot = copy.deepcopy(arguments['snapshot'])
    _resolve_stored_types(snapshot, {owner: graph, 'global': global_graph})
    model = snapshot.get('model', {}).get('model')
    if not model:
        raise KnowledgeError('invalid_model', 'Publishing requires a model identity.', {'path': ['model', 'model']})
    if snapshot.get('model', {}).get('project', project_id) != project_id:
        raise KnowledgeError('invalid_owner', 'Model belongs to another project.', snapshot['model'])
    head = graph.get(_head_id(model))
    current = head['entity_json_obj']['model'] if head else None
    base = arguments.get('base')
    if base is False:
        if current is not None:
            raise KnowledgeError('revision_conflict', 'Foundation already exists.', {'expected': None, 'current': current})
    elif base is not None:
        expected = base['model'] if isinstance(base.get('model'), dict) else base
        if expected != current:
            raise KnowledgeError('revision_conflict', 'Foundation changed since the supplied base revision.', {'expected': expected, 'current': current})
    snapshot['model'] = {'project': project_id, 'model': model}
    snapshot.pop('structural_hash', None)
    previous_diagnostics = [d for d in snapshot.pop('diagnostics', []) if d.get('source') == 'migration']
    revision = digest(snapshot)
    model_ref = {'project': project_id, 'model': model, 'revision': revision}
    snapshot['model'] = model_ref
    snapshot['structural_hash'] = digest(structural_projection(snapshot))
    snapshot['diagnostics'] = previous_diagnostics + foundation_diagnostics(snapshot)
    identifier = _revision_id(model, revision)
    existing = graph.get(identifier)
    if existing:
        # Identical inputs reuse the immutable value, including its original diagnostics.
        snapshot = existing['entity_json_obj']['snapshot']
    revision_record = _envelope(REVISION_SCHEMA, {'model': model_ref, 'snapshot': snapshot, 'base': current})
    additions = {_head_id(model): _envelope(HEAD_SCHEMA, {'model': model_ref})}
    if not existing:
        additions[identifier] = revision_record
    graph.put({'elements': additions}, source='foundation', layer='models')
    return model_ref


def import_v1(app, snapshot, source_context):
    """Retain a historical input and map only its Native structural account."""
    import base64
    import json
    from .graph import scoped_export, type_ids

    context = copy.deepcopy(source_context)
    raw = copy.deepcopy(snapshot)
    if isinstance(snapshot, (str, bytes)):
        raw = {'encoding': 'base64', 'bytes': base64.b64encode(snapshot.encode() if isinstance(snapshot, str) else snapshot).decode()}
        snapshot = json.loads(snapshot)
    else:
        snapshot = copy.deepcopy(snapshot)
    if isinstance(context.get('source_bytes'), bytes):
        context['source_bytes'] = {'encoding': 'base64', 'bytes': base64.b64encode(context['source_bytes']).decode()}
    source_id = 'v1-source:' + digest([raw, context])
    owner = 'project:' + app.project_id
    evidence = [{'source': source_id}]
    diagnostics, mapping = [], []

    def diagnostic(code, path, message, **details):
        diagnostics.append({'code': code, 'path': path, 'message': message, 'source': 'migration', **details})

    def reference(identifier, kind='element', selected_owner=owner):
        if isinstance(identifier, dict):
            return {'owner': identifier.get('owner', selected_owner), 'kind': identifier.get('kind', kind), 'id': identifier.get('id', identifier.get('ref'))}
        return {'owner': selected_owner, 'kind': kind, 'id': identifier}

    outside = copy.deepcopy(snapshot.get('archaeology', snapshot.get('latent')))
    if 'native' in snapshot:
        native = snapshot['native']
        partitions = {owner: native, 'global': snapshot.get('global', {})}
    elif 'partitions' in snapshot:
        partitions = snapshot['partitions']
        native = partitions.get(owner, {})
    elif 'project' in snapshot and isinstance(snapshot['project'], dict):
        native = snapshot['project']
        partitions = {owner: native, 'global': snapshot.get('global', {})}
    else:
        native = snapshot
        partitions = {owner: native}
    native = copy.deepcopy(native)
    selected = {}
    for record_owner, graph in partitions.items():
        if record_owner not in (owner, 'global'):
            diagnostic('outside_project', ['partitions', record_owner], 'Source owner is outside this project; retained in source history.')
            continue
        graph = copy.deepcopy(graph)
        graph.setdefault('elements', {})
        graph.setdefault('joins', [])
        graph.setdefault('observations', [])
        scopes = {o.get('source') for o in graph['observations']}
        if 'native' in scopes:
            native_graph = scoped_export(graph, 'native')
            # Reusable authored Types are available without importing outside proposals.
            for identifier, record in graph['elements'].items():
                if identifier not in native_graph['elements'] and record.get('entity_schema') == 'metaform:element':
                    observations = [o for o in graph['observations'] if o.get('element_id') == identifier and o.get('source') not in ('archaeology', 'merged')]
                    if observations:
                        native_graph['elements'][identifier] = sorted(observations, key=lambda o: (o.get('created', ''), o.get('id', '')))[-1]['record']
            if record_owner == owner and outside is None and 'archaeology' in scopes:
                outside = scoped_export(graph, 'archaeology')
            graph = native_graph
        else:
            excluded = {o.get('element_id') for o in graph['observations'] if o.get('source') in ('archaeology', 'merged')}
            retained = {o.get('element_id') for o in graph['observations'] if o.get('source') not in ('archaeology', 'merged')}
            graph['elements'] = {k: v for k, v in graph['elements'].items() if k not in excluded - retained}
            graph['joins'] = [j for j in graph['joins'] if j.get('join_scope') not in ('archaeology', 'merged')]
        selected[record_owner] = graph
    understanding = native.get('understanding', snapshot.get('understanding'))
    artifact = context.get('artifact', native.get('artifact'))
    if artifact is None and isinstance(understanding, dict):
        de = understanding.get('defining_element')
        artifact = de.get('ref') if isinstance(de, dict) else de
    if artifact is None:
        defining = [identifier for identifier, record in selected.get(owner, {}).get('elements', {}).items() if record.get('entity_json_obj', {}).get('defining_element') is True]
        if len(defining) == 1:
            artifact = defining[0]
    model = context.get('model', 'import:' + digest([app.project_id, source_id])[:16])
    if isinstance(model, dict):
        model = model['model']
    foundation = {'schema_version': '2', 'model': {'project': app.project_id, 'model': model},
                  'types': {}, 'elements': {}, 'bindings': [], 'narrowings': [], 'refinements': [], 'joins': [],
                  'source_snapshots': [{'id': source_id, 'source_context': context, 'snapshot': raw}],
                  'diagnostics': diagnostics}
    if artifact is not None:
        foundation['artifact'] = reference(artifact)
    else:
        diagnostic('unresolved_artifact', ['artifact'], 'Source does not identify a single Defining Element.')
    if understanding is not None:
        foundation['understanding'] = understanding
    if outside is not None:
        foundation['historical_outside_results'] = [{'id': source_id + ':outside', 'source': 'archaeology', 'status': 'historical', 'snapshot': outside, 'source_snapshot': source_id}]

    original_records = {}
    for record_owner, graph in selected.items():
        for identifier, original in graph['elements'].items():
            data = original.get('entity_json_obj', {})
            kind = 'element' if original.get('entity_schema') == 'metaform:actual-element' or type_ids(original) else 'type' if original.get('entity_schema') == 'metaform:element' else None
            if kind is None:
                continue
            record = {'id': identifier, 'owner': record_owner, 'evidence': copy.deepcopy(evidence)}
            original_records[(record_owner, kind, identifier)] = original
            if 'entity_desc' in original:
                record['description'] = copy.deepcopy(original['entity_desc'])
            if kind == 'type':
                record.update(adapt_type(original, identifier, record_owner))
            else:
                if 'description' in data:
                    record['description'] = copy.deepcopy(data['description'])
                for target, field in (('name', 'en'), ('summary', 'summary'), ('boundary', 'boundary')):
                    if field in data:
                        record[target] = copy.deepcopy(data[field])
                if 'artifact' in foundation:
                    record['artifact'] = copy.deepcopy(foundation['artifact'])
            collection = 'types' if kind == 'type' else 'elements'
            key = identifier if identifier not in foundation[collection] else record_owner + '|' + identifier
            foundation[collection][key] = record
            mapping.append({'source': {'owner': record_owner, 'kind': 'element', 'id': identifier}, 'target': reference(identifier, kind, record_owner)})

    def resolve(identifier, record_owner, field=None, source=None, kind=None):
        if isinstance(identifier, dict):
            target = reference(identifier, kind or 'element', record_owner)
            return target
        explicit_owner = (source or {}).get('reference_owners', {}).get(field)
        owners = [explicit_owner] if explicit_owner else list(dict.fromkeys((record_owner, 'global')))
        kinds = (kind,) if kind else ('element', 'type', 'join')
        for candidate_owner in owners:
            for candidate_kind in kinds:
                if (candidate_owner, candidate_kind, identifier) in original_records:
                    return reference(identifier, candidate_kind, candidate_owner)
        return reference(identifier, kind or 'element', owners[0])

    for key, original in list(original_records.items()):
        record_owner, kind, identifier = key
        if kind == 'element':
            for type_id in type_ids(original):
                target = resolve(type_id, record_owner, kind='type')
                binding = {'id': 'binding:' + digest([record_owner, identifier, target]), 'owner': record_owner,
                           'element': reference(identifier, 'element', record_owner), 'type': target, 'evidence': copy.deepcopy(evidence)}
                foundation['bindings'].append(binding)
        elif kind == 'type' and '.' in identifier:
            parent = resolve(identifier.rpartition('.')[0], record_owner, kind='type')
            narrowing = {'id': 'narrowing:' + digest([record_owner, identifier]), 'owner': record_owner,
                         'parent': parent, 'child': reference(identifier, 'type', record_owner), 'evidence': copy.deepcopy(evidence)}
            semantic = original.get('entity_json_obj', {}).get('narrowing', {})
            if isinstance(semantic, dict):
                narrowing.update({k: semantic[k] for k in ('reason',) if k in semantic})
            foundation['narrowings'].append(narrowing)
            if 'reason' not in narrowing:
                diagnostic('unresolved_narrowing', ['narrowings', len(foundation['narrowings']) - 1], 'Namespace placement is retained; narrowing meaning needs semantic evidence.', ref=narrowing['child'])

    for record_owner, graph in selected.items():
        for join in graph['joins']:
            if join.get('type') in ('hard dependency', 'property', 'supportive'):
                original_records[(record_owner, 'join', join['id'])] = join
    indexes = build_indexes(foundation)
    for (record_owner, kind, identifier), original in original_records.items():
        if kind != 'join':
            continue
        join = {'id': identifier, 'owner': record_owner, 'role': original['type'], 'evidence': copy.deepcopy(evidence)}
        for target, field in (('receiver', 'object_id'), ('provider', 'element_id')):
            if field in original:
                join[target] = resolve(original[field], record_owner, field, original)
        join.update({k: copy.deepcopy(original[k]) for k in ('purpose', 'signal', 'join_logic', 'scope', 'classification', 'is_soft', 'property_type') if k in original})
        if 'participants' in original:
            join['participants'] = [dict(p, ref=resolve(p['ref'], p.get('owner', record_owner), kind=p.get('kind'))) if 'ref' in p else copy.deepcopy(p) for p in original['participants']]
        provider = join.get('provider', {})
        candidates = [provider] if provider.get('kind') == 'type' else [b['type'] for b in indexes['element_bindings'].get(ref_key(provider), [])]
        if 'provider_type' in original:
            join['provider_type'] = resolve(original['provider_type'], record_owner, kind='type')
        elif len(candidates) == 1 and ref_key(candidates[0]) in indexes['records']:
            join['provider_type'] = candidates[0]
        else:
            diagnostic('unresolved_provider_type', ['joins', len(foundation['joins']), 'provider_type'], 'Historical join does not identify one known provider Type facet.', candidates=candidates, original=original)
        foundation['joins'].append(join)
        mapping.append({'source': reference(identifier, 'join', record_owner), 'target': reference(identifier, 'join', record_owner)})
    foundation['migration_mapping'] = mapping
    model_ref = publish_foundation(app, foundation)
    return {'model': model_ref, 'mapping': mapping, 'diagnostics': capture_model(app, model_ref)['diagnostics']}
