"""Authored semantic rules and the exact material used to prime inference."""

from __future__ import annotations

import importlib.resources
import json

from . import schemas
from .util import digest


LEGACY_MANAGED_REVISIONS = {'r1': '7d3c471f09192d12d6edc3624b6434bb62e64d5aefab787e1c2868b388d064c9', 'r2': '7f725eee7c3391845d1a717d3443c12b9a1fa4f2a83fba686910c2674909e96f'}


def seed(app):
    path = importlib.resources.files("metaform") / "data" / "rulebook.json"
    for rule in json.loads(path.read_text(encoding="utf-8")):
        stored = app.graph.get("rule:" + rule["rule_code"])
        if stored is None or digest(stored["entity_json_obj"]) == LEGACY_MANAGED_REVISIONS.get(rule["rule_code"]):
            put(app, rule)


def put(app, rule):
    record = {
        "entity_desc": rule["purpose"],
        "entity_schema": "metaform:semantic-rule",
        "entity_json_obj": rule,
    }
    app.graph.put(
        {"elements": {"rule:" + rule["rule_code"]: record}}, "authored", "rulebook"
    )
    return {
        "rule": rule,
        "annotations": schemas.annotations(app, "metaform:semantic-rule", rule),
    }


def get(app, rule_code):
    identifier = "rule:" + rule_code
    record = app.graph.get(identifier) or app.global_graph.get(identifier)
    if record is None or record["entity_schema"] != "metaform:semantic-rule":
        raise ValueError(f"Unknown semantic rule: {rule_code}")
    return record["entity_json_obj"]


def prepare(app, rule_codes, concise_only=False):
    snapshots = []
    for code in dict.fromkeys(rule_codes):
        rule = get(app, code)
        snapshots.append(
            {
                "revision": digest(rule),
                "content": {
                    k: v for k, v in rule.items() if not concise_only or k != "priming"
                },
            }
        )
    return snapshots
