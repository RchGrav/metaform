from __future__ import annotations

import fnmatch
import copy
import json
import sqlite3
from collections import deque
from contextlib import contextmanager
from pathlib import Path

from .util import digest, dumps, now


def join_participants(join):
    return join.get("participants") or [
        {"role": role, "ref": join[field]}
        for field, role in (("object_id", "receiver"), ("element_id", "ef_owner"))
        if field in join
    ]


def type_ids(record):
    """Read an actual record's Type references without changing stored content."""
    data = (record or {}).get("entity_json_obj", {})
    identifiers = data.get("type_ids", [data.get("type_id")])
    return list(dict.fromkeys(identifier for identifier in identifiers
                              if isinstance(identifier, str) and identifier))


def type_members(elements, focal):
    """Select actual Elements classified at a Type or beneath its namespace."""
    focal_record = elements.get(focal, {})
    if type_ids(focal_record) or focal_record.get("entity_schema") == "metaform:actual-element":
        return []
    return [identifier for identifier, record in elements.items()
            if any(type_id == focal or type_id.startswith(focal + ".") for type_id in type_ids(record))]


def is_type_definition(record):
    return (record is not None and record.get("entity_schema") == "metaform:element"
            and not type_ids(record))


def scoped_export(data, scope):
    if scope is None:
        return data
    observations = [o for o in data["observations"] if o["source"] == scope]
    elements = {}
    for observation in sorted(observations, key=lambda o: (o["created"], o["id"])):
        identifier = observation["element_id"]
        if identifier in data["elements"]:
            record = copy.deepcopy(observation["record"])
            record.setdefault("layer", "elements")
            elements[identifier] = record
    return {
        "elements": elements,
        "joins": [j for j in data["joins"] if j.get("join_scope") == scope],
        "observations": observations,
    }


def scoped_join_references(graph, source, previous=(), owner=None):
    if source not in {"native", "archaeology"}:
        return graph
    graph = copy.deepcopy(graph)
    identifiers = {j.get("source_id", j["id"]): j["id"] for j in previous}
    for join in graph.get("joins", []):
        original = join.get(
            "source_id", join.get("id") or digest(dict(join, join_scope=source))
        )
        join.setdefault("id", original)
        join.setdefault("source_id", original)
        identifiers[original] = "join:" + digest([source, original])
        identifiers[join["id"]] = identifiers[original]
    for join in graph.get("joins", []):
        for field in ("object_id", "element_id"):
            if field in join and join.get("reference_owners", {}).get(field, owner) == owner:
                join[field] = identifiers.get(join[field], join[field])
        for participant in join.get("participants", []):
            if participant.get("ref") in identifiers and participant.get("owner", owner) == owner:
                participant["ref"] = identifiers[participant["ref"]]
    return graph


def renamed_elements(graph, mapping, owner=None):
    """Remap identifiers simultaneously without rewriting authored record content."""
    if not isinstance(mapping, dict) or any(
        not isinstance(old, str) or not old or not isinstance(new, str) or not new
        for old, new in mapping.items()
    ):
        raise ValueError("Element renames require nonempty string identifiers")
    mapping = {old: new for old, new in mapping.items() if old != new}
    original = graph["elements"]
    missing = set(mapping) - original.keys()
    if missing:
        raise ValueError("Unknown elements to rename: " + ", ".join(sorted(missing)))
    occupied = {join["id"] for join in graph["joins"]} | {
        "observation:" + observation["id"] for observation in graph["observations"]
    }
    if set(mapping.values()) & occupied:
        raise ValueError("Element rename conflicts with a join or observation identifier")
    data = copy.deepcopy(graph)
    elements = {}
    for identifier, record in original.items():
        target = mapping.get(identifier, identifier)
        if target in original and target not in mapping:
            if original[target]["entity_schema"] != record["entity_schema"]:
                raise ValueError("Element rename conflicts with a different schema: " + target)
            # An established canonical target wins; source observations survive.
            elements[target] = copy.deepcopy(original[target])
        elif target in elements and elements[target] != record:
            raise ValueError("Ambiguous element rename collision: " + target)
        else:
            elements[target] = copy.deepcopy(record)
    data["elements"] = elements
    changed_joins = 0
    for join in data["joins"]:
        before = copy.deepcopy(join)
        for field in ("object_id", "element_id"):
            if field in join and join.get("reference_owners", {}).get(field, owner) == owner:
                join[field] = mapping.get(join[field], join[field])
        for participant in join.get("participants", []):
            if participant.get("ref") in mapping and participant.get("owner", owner) == owner:
                participant["ref"] = mapping[participant["ref"]]
        changed_joins += join != before
    changed_observations = 0
    for observation in data["observations"]:
        identifier = observation["element_id"]
        if identifier in mapping:
            observation["element_id"] = mapping[identifier]
            changed_observations += 1
    return data, {
        "elements": len(mapping),
        "joins": changed_joins,
        "observations": changed_observations,
    }


class Graph:
    """ET plus first-class, role-bearing relations and attributed observations."""

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.db() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS elements(id TEXT PRIMARY KEY, entity_desc TEXT NOT NULL,
                    entity_schema TEXT NOT NULL, entity_json_obj TEXT NOT NULL, layer TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS observations(id TEXT PRIMARY KEY, element_id TEXT NOT NULL,
                    source TEXT NOT NULL, record TEXT NOT NULL, created TEXT NOT NULL,
                    FOREIGN KEY(element_id) REFERENCES elements(id) ON DELETE CASCADE);
                CREATE TABLE IF NOT EXISTS joins(id TEXT PRIMARY KEY, object_id TEXT NOT NULL,
                    element_id TEXT NOT NULL, type TEXT NOT NULL, join_scope TEXT NOT NULL,
                    body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS participants(join_id TEXT NOT NULL, ordinal INTEGER NOT NULL,
                    role TEXT NOT NULL, ref TEXT, value TEXT, PRIMARY KEY(join_id,ordinal),
                    FOREIGN KEY(join_id) REFERENCES joins(id) ON DELETE CASCADE);
                CREATE INDEX IF NOT EXISTS join_source ON joins(object_id,type,join_scope);
                CREATE INDEX IF NOT EXISTS join_target ON joins(element_id,type,join_scope);
                CREATE INDEX IF NOT EXISTS participant_ref ON participants(ref);
                CREATE INDEX IF NOT EXISTS observation_source ON observations(element_id,source);
            """)

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=30)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        try:
            with db:
                yield db
        finally:
            db.close()

    def import_raw(self, graph):
        """Import stored records without authoring observations or changing identities."""
        return self.put(graph, "imported", _raw=True)

    def replace_scope(self, graph, source, layer="elements"):
        from .backends import replaced_scope

        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            original = {
                "elements": {r["id"]: {"entity_desc": r["entity_desc"], "entity_schema": r["entity_schema"],
                                       "entity_json_obj": json.loads(r["entity_json_obj"]), "layer": r["layer"]}
                             for r in db.execute("SELECT * FROM elements")},
                "joins": [json.loads(r[0]) for r in db.execute("SELECT body FROM joins")],
                "observations": [dict(r) | {"record": json.loads(r["record"])} for r in db.execute("SELECT * FROM observations")],
            }
            data, result = replaced_scope(original, graph, source, layer, getattr(self, "owner", None))
            db.execute("DELETE FROM joins")
            db.execute("DELETE FROM elements")
            db.executemany("INSERT INTO elements VALUES(?,?,?,?,?)", [
                (identifier, r["entity_desc"], r["entity_schema"], dumps(r["entity_json_obj"]), r.get("layer", "elements"))
                for identifier, r in data["elements"].items()])
            for join in data["joins"]:
                db.execute("INSERT INTO joins VALUES(?,?,?,?,?,?)", (join["id"], join.get("object_id", ""),
                           join.get("element_id", ""), join["type"], join["join_scope"], dumps(join)))
                db.executemany("INSERT INTO participants VALUES(?,?,?,?,?)", [
                    (join["id"], i, p.get("role", ""), p.get("ref"), dumps(p.get("value")))
                    for i, p in enumerate(join_participants(join))])
            db.executemany("INSERT INTO observations VALUES(?,?,?,?,?)", [
                (o["id"], o["element_id"], o["source"], dumps(o["record"]), o["created"]) for o in data["observations"]])
        return result

    def put(self, graph, source="native", layer="elements", *, _raw=False):
        if source in {"native", "archaeology"}:
            graph = scoped_join_references(graph, source, self.joins(scope=source), getattr(self, "owner", None))
        elements = graph.get("elements", {})
        joins = graph.get("joins", [])
        with self.db() as db:
            for identifier, record in elements.items():
                data = record["entity_json_obj"]
                db.execute(
                    "INSERT INTO elements VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET entity_desc=excluded.entity_desc, entity_schema=excluded.entity_schema, entity_json_obj=excluded.entity_json_obj, layer=excluded.layer",
                    (
                        identifier,
                        record["entity_desc"],
                        record["entity_schema"],
                        dumps(data),
                        record.get("layer", layer),
                    ),
                )
                if not _raw:
                    db.execute(
                        "INSERT INTO observations VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record, created=excluded.created",
                        (
                            digest([identifier, source, record]),
                            identifier,
                            source,
                            dumps(dict(record, layer=record.get("layer", layer))),
                            now(),
                        ),
                    )
            for raw in joins:
                join = dict(raw)
                if not _raw:
                    join["join_scope"] = (
                        source
                        if source in {"native", "archaeology", "merged"}
                        else join.get("join_scope", source)
                    )
                    identifier = join.get("id") or digest(join)
                    if join["join_scope"] in {"native", "archaeology"}:
                        join.setdefault("source_id", identifier)
                        identifier = "join:" + digest(
                            [join["join_scope"], join["source_id"]]
                        )
                    join["id"] = identifier
                identifier = join["id"]
                members = join_participants(join)
                db.execute(
                    "INSERT INTO joins VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET object_id=excluded.object_id, element_id=excluded.element_id, type=excluded.type, join_scope=excluded.join_scope, body=excluded.body",
                    (
                        identifier,
                        join.get("object_id", ""),
                        join.get("element_id", ""),
                        join["type"],
                        join["join_scope"],
                        dumps(join),
                    ),
                )
                db.execute("DELETE FROM participants WHERE join_id=?", (identifier,))
                db.executemany(
                    "INSERT INTO participants VALUES(?,?,?,?,?)",
                    [
                        (identifier, i, p.get("role", ""), p.get("ref"), dumps(p.get("value")))
                        for i, p in enumerate(members)
                    ],
                )
            for observation in graph.get("observations", []):
                db.execute(
                    "INSERT INTO observations VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET record=excluded.record, created=excluded.created WHERE excluded.created > observations.created",
                    (
                        observation["id"],
                        observation["element_id"],
                        observation["source"],
                        dumps(observation["record"]),
                        observation["created"],
                    ),
                )
        return {"elements": len(elements), "joins": len(joins)}

    def get(self, identifier, scope=None):
        if scope is not None:
            records = [o["record"] for o in self.provenance(identifier) if o["source"] == scope]
            return (
                {key: records[-1][key] for key in ("entity_desc", "entity_schema", "entity_json_obj")}
                if records else None
            )
        with self.db() as db:
            row = db.execute(
                "SELECT * FROM elements WHERE id=?", (identifier,)
            ).fetchone()
        if not row:
            return None
        return {
            "entity_desc": row["entity_desc"],
            "entity_schema": row["entity_schema"],
            "entity_json_obj": json.loads(row["entity_json_obj"]),
        }

    def rename_elements(self, mapping):
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            original = {
                "elements": {
                    row["id"]: {
                        "entity_desc": row["entity_desc"],
                        "entity_schema": row["entity_schema"],
                        "entity_json_obj": json.loads(row["entity_json_obj"]),
                        "layer": row["layer"],
                    }
                    for row in db.execute("SELECT * FROM elements")
                },
                "joins": [json.loads(row[0]) for row in db.execute("SELECT body FROM joins")],
                "observations": [
                    dict(row) | {"record": json.loads(row["record"])}
                    for row in db.execute("SELECT * FROM observations")
                ],
            }
            data, result = renamed_elements(original, mapping, getattr(self, "owner", None))
            if not result["elements"]:
                return result
            for identifier, record in data["elements"].items():
                if original["elements"].get(identifier) == record:
                    continue
                db.execute(
                    "INSERT INTO elements VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET entity_desc=excluded.entity_desc, entity_schema=excluded.entity_schema, entity_json_obj=excluded.entity_json_obj, layer=excluded.layer",
                    (identifier, record["entity_desc"], record["entity_schema"],
                     dumps(record["entity_json_obj"]), record["layer"]),
                )
            for observation in data["observations"]:
                db.execute(
                    "UPDATE observations SET element_id=? WHERE id=?",
                    (observation["element_id"], observation["id"]),
                )
            for identifier in original["elements"].keys() - data["elements"].keys():
                db.execute("DELETE FROM elements WHERE id=?", (identifier,))
            for before, join in zip(original["joins"], data["joins"]):
                if before != join:
                    db.execute(
                        "UPDATE joins SET object_id=?, element_id=?, body=? WHERE id=?",
                        (join.get("object_id", ""), join.get("element_id", ""), dumps(join), join["id"]),
                    )
            db.execute("DELETE FROM participants")
            db.executemany("INSERT INTO participants VALUES(?,?,?,?,?)", [
                (join["id"], i, p.get("role", ""), p.get("ref"), dumps(p.get("value")))
                for join in data["joins"] for i, p in enumerate(join_participants(join))
            ])
        return result

    def provenance(self, identifier):
        with self.db() as db:
            rows = db.execute(
                "SELECT source,record,created FROM observations WHERE element_id=? ORDER BY created,id",
                (identifier,),
            ).fetchall()
        return [
            {
                "source": r["source"],
                "record": json.loads(r["record"]),
                "created": r["created"],
            }
            for r in rows
        ]

    def search(self, query="*", layer=None, scope=None):
        if scope is not None:
            data = self.export(scope)
            rows = [
                dict(record, id=identifier, entity_json_obj=dumps(record["entity_json_obj"]))
                for identifier, record in sorted(data["elements"].items())
                if layer is None or record.get("layer") == layer
            ]
            sources = {identifier: {scope} for identifier in data["elements"]}
        else:
            with self.db() as db:
                rows = db.execute(
                    "SELECT * FROM elements"
                    + (" WHERE layer=?" if layer else "")
                    + " ORDER BY id",
                    (layer,) if layer else (),
                ).fetchall()
                sources = {}
                for observation in db.execute(
                    "SELECT DISTINCT element_id,source FROM observations"
                ):
                    sources.setdefault(observation["element_id"], set()).add(
                        observation["source"]
                    )
        results = []
        for row in rows:
            data = json.loads(row["entity_json_obj"])
            names = [row["id"], data.get("en", ""), *data.get("aliases", [])]
            if any(
                fnmatch.fnmatchcase(str(n).lower(), query.lower()) for n in names
            ) or (
                "*" not in query
                and query.lower()
                in (row["entity_desc"] + " " + " ".join(map(str, names))).lower()
            ):
                results.append(
                    {
                        "id": row["id"],
                        "entity_desc": row["entity_desc"],
                        "entity_schema": row["entity_schema"],
                        "entity_json_obj": data,
                        "layer": row["layer"],
                        "sources": sorted(sources.get(row["id"], set())),
                    }
                )
        return results

    def joins(self, identifier=None, scope=None, category=None):
        clauses, args = [], []
        if identifier is not None:
            clauses.append(
                "(id=? OR object_id=? OR element_id=? OR id IN (SELECT join_id FROM participants WHERE ref=?))"
            )
            args.extend([identifier] * 4)
        for column, value in [("join_scope", scope), ("type", category)]:
            if value is not None:
                clauses.append(column + "=?")
                args.append(value)
        with self.db() as db:
            rows = db.execute(
                "SELECT body FROM joins"
                + (" WHERE " + " AND ".join(clauses) if clauses else "")
                + " ORDER BY id",
                args,
            ).fetchall()
        return [json.loads(r[0]) for r in rows]

    def assemble(self, focal, depth=None, scope=None, category=None):
        elements, joins, visited, unresolved = {}, {}, set(), set()
        queue = deque([(focal, 0)])
        focal_record = self.get(focal, scope=scope)
        if focal_record is None:
            authored = self.get(focal, scope="authored")
            if is_type_definition(authored):
                focal_record = authored
        if not type_ids(focal_record) and (focal_record or {}).get("entity_schema") != "metaform:actual-element":
            records = {row["id"]: row for row in self.search(scope=scope)}
            # Classification selects the focal contents; only real joins use depth.
            queue.extend((identifier, 0) for identifier in type_members(records, focal))
        while queue:
            identifier, distance = queue.popleft()
            if identifier in visited:
                continue
            visited.add(identifier)
            record = focal_record if identifier == focal else self.get(identifier, scope=scope)
            if record is not None:
                elements[identifier] = record
            elif not any(j["id"] == identifier for j in self.joins(identifier)):
                unresolved.add(identifier)
            if depth is not None and distance >= depth:
                continue
            for join in self.joins(identifier, scope, category):
                joins[join["id"]] = join
                refs = {
                    join["id"],
                    join.get("object_id"),
                    join.get("element_id"),
                    *(p.get("ref") for p in join.get("participants", [])),
                } - {None}
                queue.extend((ref, distance + 1) for ref in refs if ref not in visited)
        # Include each selected Element's Type as context without traversing its
        # joins or importing the Element's classification siblings.
        classifications = dict.fromkeys(type_id for record in elements.values() for type_id in type_ids(record))
        for type_id in classifications:
            if type_id not in elements:
                classification = self.get(type_id, scope=scope)
                if classification is None:
                    authored = self.get(type_id, scope="authored")
                    if is_type_definition(authored):
                        classification = authored
                if classification is not None:
                    elements[type_id] = classification
        return {
            "elements": elements,
            "joins": list(joins.values()),
            "unresolved": sorted(unresolved),
        }

    def export(self, scope=None):
        with self.db() as db:
            observations = [
                dict(r) | {"record": json.loads(r["record"])}
                for r in db.execute("SELECT * FROM observations ORDER BY id")
            ]
        return scoped_export({
            "elements": {
                r["id"]: {
                    k: r[k]
                    for k in (
                        "entity_desc",
                        "entity_schema",
                        "entity_json_obj",
                        "layer",
                    )
                }
                for r in self.search()
            },
            "joins": self.joins(),
            "observations": observations,
        }, scope)

    def similarity(self):
        from .knowledge import KnowledgeSnapshot
        from .similarity import compare

        owner = getattr(self, "owner", None)
        capture = getattr(self, "knowledge_snapshot", None)
        snapshot = capture() if capture is not None else {"revision": None, "partitions": {owner: self.export()}}
        reader = KnowledgeSnapshot(snapshot["revision"], snapshot["partitions"])
        graph = reader.partitions[owner]
        return compare(scoped_export(graph, "native"), scoped_export(graph, "archaeology"),
                       owner=owner, resolve=reader.resolve)

    def merge_perspectives(self):
        joins = self.similarity()["joins"]
        self.delete_joins(scope="merged")
        self.put({"joins": joins}, "merged")
        return {
            "native": len(self.joins(scope="native")),
            "archaeology": len(self.joins(scope="archaeology")),
            "merged": len(joins),
        }

    def stats(self):
        with self.db() as db:
            counts = {
                t: db.execute(f"SELECT count(*) FROM {t}").fetchone()[0]
                for t in ("elements", "joins", "observations", "participants")
            }
            counts["layers"] = dict(
                db.execute("SELECT layer,count(*) FROM elements GROUP BY layer")
            )
            counts["scopes"] = dict(
                db.execute("SELECT join_scope,count(*) FROM joins GROUP BY join_scope")
            )
        return counts

    def delete_joins(self, object_id=None, category=None, scope=None):
        clauses, values = [], []
        for column, value in [
            ("object_id", object_id),
            ("type", category),
            ("join_scope", scope),
        ]:
            if value is not None:
                clauses.append(column + "=?")
                values.append(value)
        with self.db() as db:
            db.execute(
                "DELETE FROM joins"
                + (" WHERE " + " AND ".join(clauses) if clauses else ""),
                values,
            )

    def clean(self):
        # Rebuild only derived merged records; source observations are retained.
        with self.db() as db:
            db.execute("DELETE FROM joins WHERE join_scope='merged'")
        result = self.merge_perspectives()
        with self.db() as db:
            result["integrity"] = db.execute("PRAGMA integrity_check").fetchone()[0]
            result["foreign_keys"] = [
                tuple(r) for r in db.execute("PRAGMA foreign_key_check")
            ]
        return result


def composed_search(app, query="*", layer=None, node_only=False, scope=None):
    if hasattr(app, "knowledge"):
        return app.knowledge.call("graph.search", {
            "owners": ["global", "project:" + app.project_id],
            "query": query, "layer": layer, "scope": scope,
        })
    found = {}
    for storage, graph in [("global", app.global_graph), ("project", app.graph)]:
        for record in graph.search(query, layer, scope=scope):
            previous = found.get(record["id"], {})
            record["storage"] = sorted(set(previous.get("storage", [])) | {storage})
            record["sources"] = sorted(
                set(previous.get("sources", [])) | set(record["sources"])
            )
            found[record["id"]] = record
    return [found[k] for k in sorted(found)]
