"""Expand a coarse intake contribution into foundation storage records.

The contribution is the prompt's output and nothing more: notable elements keyed
by namespace position with one EF each, and joins carrying the receiver's
Operative Purpose. Everything storage needs beyond that is derived here, the
same way every time, so the model is never handed a place to describe more.
"""
from __future__ import annotations

import copy

from .util import digest


def bases():
    """The four bases every intake knows: reusable positions in the global registry, never re-authored per project."""
    import importlib.resources
    import json

    return json.loads((importlib.resources.files("metaform") / "data" / "bases.json").read_text(encoding="utf-8"))


def reversed_name(position):
    return " ".join(reversed(position.split(".")))


def positions_of(position):
    parts = position.split(".")
    return [".".join(parts[:index]) for index in range(1, len(parts) + 1)]


def expand(contribution, owner, known):
    """Return storage collections for one contribution.

    `known` maps a namespace position to an existing Type record; a known
    position is referenced by its owner and reported under `reused` instead of
    being authored again. Every other position on the way to a notable element
    becomes a project Type whose EF is empty until deep intake speaks to it.
    """
    def ref(kind, identifier, record_owner=owner):
        return {"owner": record_owner, "kind": kind, "id": identifier}

    diagnostics = []

    def unexpected(record, allowed, at):
        for field in record:
            if field not in allowed:
                diagnostics.append({"code": "unexpected_field", "field": field, "at": at,
                                    "message": "The prompt did not ask for this field; it is recorded here and not stored."})

    named = {}
    for name, value in (contribution.get("elements") or {}).items():
        record = value if isinstance(value, dict) else {}
        unexpected(record, {"ef", "name_length"}, name)
        if not isinstance(record.get("ef"), str):
            diagnostics.append({"code": "missing_field", "field": "ef", "at": name, "message": "The notable element has no Encounter Function."})
        segments = len(name.split("."))
        length = record.get("name_length")
        if length is not None and not (isinstance(length, int) and not isinstance(length, bool) and 1 <= length <= segments):
            diagnostics.append({"code": "unexpected_value", "field": "name_length", "at": name, "value": length,
                                "message": "name_length is a lookback segment count within the address; the whole reversed name is used."})
            length = None
        named[name] = {"ef": record.get("ef") if isinstance(record.get("ef"), str) else "",
                       "length": length if length is not None else segments}

    joins = []
    for position, value in enumerate(contribution.get("joins") or []):
        record = value if isinstance(value, dict) else {}
        unexpected(record, {"receiver", "provider", "purpose", "relation", "observation", "combined", "refs"}, position)
        for field in ("receiver", "provider", "purpose"):
            if not isinstance(record.get(field), str):
                diagnostics.append({"code": "missing_field", "field": field, "at": position, "message": "The join has no " + field + "."})
        if not isinstance(record.get("receiver"), str) or not isinstance(record.get("provider"), str):
            continue
        joins.append({"receiver": record["receiver"], "provider": record["provider"],
                      "purpose": record.get("purpose") if isinstance(record.get("purpose"), str) else "",
                      "relation": record.get("relation") if isinstance(record.get("relation"), str) else None,
                      "observation": record.get("observation") if isinstance(record.get("observation"), str) else None,
                      "combined": record.get("combined") if isinstance(record.get("combined"), dict) else None,
                      "refs": record.get("refs") if isinstance(record.get("refs"), dict) else None})

    for join in joins:
        for participant in (join["receiver"], join["provider"]):
            if participant not in named:
                diagnostics.append({"code": "unnamed_join_participant", "ref": participant,
                                    "message": "A join names an element that is not a notable element of this contribution."})
    providers = {join["provider"] for join in joins}
    roots = sorted(name for name in named if name not in providers)
    # An answer that declares its Defining Element is taken at its word; only an answer that does not is inferred.
    defining = contribution.get("defining") or (roots[0] if len(roots) == 1 else None)
    if defining is None:
        diagnostics.append({"code": "unresolved_defining_element", "roots": roots,
                            "message": "Shallow intake starts at one Defining Element; the joins leave these elements without a receiver."})
    artifact = ref("element", defining) if defining else None

    owners = {}
    types = {}
    reused = {}
    for name in sorted(named):
        for position in positions_of(name):
            if position in owners:
                continue
            record = known.get(position)
            if record is not None:
                owners[position] = record["owner"]
                reused[position] = copy.deepcopy(record)
                continue
            owners[position] = owner
            types[position] = {"id": position, "owner": owner, "description": reversed_name(position),
                               "ef": named[position]["ef"] if position in named else "",
                               "length": named[position]["length"] if position in named else len(position.split(".")), "aliases": []}

    elements = {name: {"id": name, "owner": owner, "name": reversed_name(name), "artifact": artifact} for name in sorted(named)}
    bindings = [{"id": "binding:" + digest([owner, name]), "owner": owner,
                 "element": ref("element", name), "type": ref("type", name, owners[name])} for name in sorted(named)]

    narrowings = []
    seen = set()
    for name in sorted(named):
        chain = positions_of(name)
        for parent, child in zip(chain, chain[1:]):
            if (parent, child) in seen:
                continue
            seen.add((parent, child))
            narrowings.append({"id": "narrowing:" + digest([owner, parent, child]), "owner": owner,
                               "parent": ref("type", parent, owners[parent]), "child": ref("type", child, owners[child])})

    expanded_joins = []
    for join in joins:
        record = {"id": "join:" + digest([owner, join["receiver"], join["provider"], join["purpose"]]), "owner": owner,
                  "receiver": ref("element", join["receiver"]), "provider": ref("element", join["provider"]),
                  "provider_type": ref("type", join["provider"], owners.get(join["provider"], owner)),
                  "purpose": join["purpose"], "role": "hard dependency"}
        for field in ("relation", "observation", "refs"):
            if join.get(field):
                record[field] = copy.deepcopy(join[field])
        if join.get("combined"):
            record["combined"] = copy.deepcopy(join["combined"])
        expanded_joins.append(record)

    subtypes = []
    for value in contribution.get("subtypes") or []:
        if not isinstance(value, str) or not value:
            diagnostics.append({"code": "unexpected_value", "field": "subtypes", "value": value,
                                "message": "A subtype is a full namespace address; this entry is recorded and not held."})
            continue
        ancestors = [position for position in positions_of(value)[:-1] if position in named]
        parent = ref("type", ancestors[-1], owners[ancestors[-1]]) if ancestors else None
        if parent is None:
            diagnostics.append({"code": "unplaced_subtype", "ref": value,
                                "message": "The subtype lies beneath no notable element of this contribution; it is held without a main type."})
        subtypes.append({"id": value, "owner": owner, "parent": parent, "status": "inactive"})

    return {"artifact": artifact, "types": types, "elements": elements, "bindings": bindings,
            "narrowings": narrowings, "refinements": [], "joins": expanded_joins, "subtypes": subtypes,
            "reused": reused, "diagnostics": diagnostics}
