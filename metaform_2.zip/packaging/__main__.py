import os
import sys

sys.path.insert(0, sys.path[0] + "/_portable")
os.environ.setdefault("METAFORM_PORTABLE", "1")
from metaform.cli import main

raise SystemExit(main())
