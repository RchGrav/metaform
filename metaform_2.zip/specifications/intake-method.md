# Digital Typology, the method

```mermaid
---
config:
  layout: elk
---
flowchart TB
    start(["Start with the target artifact"]) --> identify["Identify the artifact type and its minimal purpose"]
    identify --> de["Define exactly one DE<br>Defining Element"]
    de --> requirements["Find each NE as a required categorical element"]
    requirements --> classify["Classify each element as DE, SE, PE, or NE"]
    classify --> op["Name the artifact-specific OP<br>Operative Purpose"]
    op --> join["Create a Join<br>RE + EF + OP + relation + observation"]
    join --> next["Treat the current element as the next RE"]
    next --> discover@{ label: "Find that RE's remaining OPs" }
    discover --> more{"More notable elements required?"}
    more -- Yes --> requirements
    more -- No --> anneal["Anneal the graph"]
    anneal --> combine{"Can elements share one common join?"}
    combine -- Yes --> absorb["Combine them into a common namespace element"]
    absorb --> preserve["Preserve combined-away entities<br>with active relations and atomic observations"]
    preserve --> subtype["Record annealed-away subtypes"]
    subtype --> validate["Validate namespace addresses and name lengths"]
    combine -- No --> validate
    validate --> constrain["Verify artifact-specific data appears only in OPs"]
    constrain --> minimal{"Is the shape minimal, coarse, shallow, and extensible?"}
    minimal -- No --> anneal
    minimal -- Yes --> complete(["Complete base memory graph shape"])

    discover@{ shape: rect}
     start:::startEnd
     identify:::analysis
     de:::analysis
     requirements:::analysis
     classify:::analysis
     op:::analysis
     join:::graphStyle
     next:::analysis
     discover:::analysis
     more:::decision
     anneal:::analysis
     combine:::decision
     absorb:::analysis
     preserve:::analysis
     subtype:::analysis
     validate:::validation
     constrain:::graphStyle
     minimal:::decision
     complete:::startEnd
    classDef startEnd stroke:#4ade80,fill:#f0fdf4,color:#111827
    classDef analysis stroke:#818cf8,fill:#eef2ff,color:#111827
    classDef graphStyle stroke:#2dd4bf,fill:#f0fdfa,color:#111827
    classDef decision stroke:#fb923c,fill:#fff7ed,color:#111827
    classDef validation stroke:#a78bfa,fill:#f5f3ff,color:#111827
```
