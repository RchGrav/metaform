# Specifications index

The specifications state what Metaform is required to do. They are the source
for implementation; documentation under `docs/` describes what the checkout
does and how to use it.

| Specification | Scope |
| --- | --- |
| [Metaform specification](../docs/SPEC.md) | The semantic contract, chassis guidance and help standard, nonce-scoped menus, startup and onboarding, first-run provisioning for unfamiliar harnesses, provenance and prompt objects and porting through medium change (section 15), acceptance scenarios. |
| [Intake, Digital Typology](intake.xml) | The intake prompt in XML: the seven sections, the response instructions, and the response schema every answer follows. |
| [Receiving Entity](re.schema.json) | The RE record: ef, name_length, aliases, and the joins dictionary; a join is op, relation, observation, refs. |
| [The method](intake-method.md) | Rich's flowchart of the intake method. |
| [Intake](intake.md) | Rich's authored coarse intake prompt, Digital Archeology: the seven sections every operation prompt takes, the namespace rules and validity examples, the method, the constraints. The installed prompt is this file. |
| [Shared knowledge service and portable projects](../feature-briefs/shared-knowledge-service-and-portable-projects-specification.md) | The knowledge service, portable projects, offline continuation. |
| [Native Metaform variants](../feature-briefs/native-metaform-variants-specification.md) | Cloned and regenerated variants of a foundation. |
| [Next version](../docs/next-version.md) | Workflow execution, handoff and continuity, nonce issuance and cleanup. |
| [Workbench brief](../docs/workbench-brief.md) | The workbench as an explorer of the MCP surface and a job viewer. |
